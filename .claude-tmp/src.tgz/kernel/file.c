//
// Support functions for system calls that involve file descriptors.
//

#include "types.h"
#include "aarch64.h"
#include "defs.h"
#include "param.h"
#include "fs.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "file.h"
#include "stat.h"
#include "proc.h"
#include "device.h"
#include "epoll.h"
#include "fcntl.h"

struct {
  struct spinlock lock;
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
  initlock(&ftable.lock, "ftable");
  epollinit();
}

// Allocate a file structure.
struct file*
filealloc(void)
{
  struct file *f;

  acquire(&ftable.lock);
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    if(f->ref == 0){
      memset(f, 0, sizeof(*f));
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
  return 0;
}

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
  acquire(&ftable.lock);
  if(f->ref < 1)
    panic("filedup");
  f->ref++;
  release(&ftable.lock);
  return f;
}

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
  struct file ff;

  acquire(&ftable.lock);
  if(f->ref < 1)
    panic("fileclose");
  if(--f->ref > 0){
    release(&ftable.lock);
    return;
  }
  ff = *f;
  f->ref = 0;
  f->type = FD_NONE;
  release(&ftable.lock);

  if(ff.type == FD_PIPE){
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    if(ff.type == FD_DEVICE)
      chrdev_release(&ff);
    begin_op();
    iput(ff.ip);
    end_op();
  } else if(ff.type == FD_VNODE){
    vfsclose(ff.vn);
  } else if(ff.type == FD_SOCKET){
    if(ff.socket >= 0)
      net_tcp_close(ff.socket);
  } else if(ff.type == FD_EPOLL){
    epollclose(ff.epoll);
  } else if(ff.type == FD_PTY){
    ptyclose(ff.pty, ff.pty_master);
  }
}

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
  struct proc *p = myproc();
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    ilock(f->ip);
    stati(f->ip, &st);
    iunlock(f->ip);
    if(copyout(p->vm->pagetable, addr, (char *)&st, sizeof(st)) < 0)
      return -1;
    return 0;
  } else if(f->type == FD_VNODE){
    if(vfsstat(f->vn, &st) < 0)
      return -1;
    if(copyout(p->vm->pagetable, addr, (char *)&st, sizeof(st)) < 0)
      return -1;
    return 0;
  }
  return -1;
}

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
  int r = 0;

  if(f->readable == 0)
    return -1;

  if(f->type == FD_PIPE){
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    r = chrdev_read(f, 1, addr, n);
  } else if(f->type == FD_INODE){
    ilock(f->ip);
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
      f->off += r;
    iunlock(f->ip);
  } else if(f->type == FD_PTY){
    r = ptyread(f->pty, f->pty_master, addr, n);
  } else if(f->type == FD_SOCKET){
    r = net_tcp_read(f->socket, addr, n, (f->flags & O_NONBLOCK) != 0);
  } else if(f->type == FD_VNODE){
    if((r = vfsread(f->vn, 1, addr, f->off, n)) > 0)
      f->off += r;
  } else {
    panic("fileread");
  }

  return r;
}

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    return -1;

  if(f->type == FD_PIPE){
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    ret = chrdev_write(f->major, 1, addr, n);
  } else if(f->type == FD_INODE){
    // write a few blocks at a time to avoid exceeding
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
        f->off += r;
      iunlock(f->ip);
      end_op();

      if(r != n1){
        // error from writei
        break;
      }
      i += r;
    }
    ret = (i == n ? n : -1);
  } else if(f->type == FD_VNODE){
    if((ret = vfswrite(f->vn, 1, addr, f->off, n)) > 0)
      f->off += ret;
  } else if(f->type == FD_SOCKET){
    ret = net_tcp_write(f->socket, addr, n, (f->flags & O_NONBLOCK) != 0);
  } else if(f->type == FD_PTY){
    ret = ptywrite(f->pty, f->pty_master, addr, n);
  } else {
    panic("filewrite");
  }

  return ret;
}
