
user/_mygres:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000b18 <.plt>:
 b18:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 b1c:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 b20:	f946be11 	ldr	x17, [x16, #3448]
 b24:	9135e210 	add	x16, x16, #0xd78
 b28:	d61f0220 	br	x17
 b2c:	d503201f 	nop
 b30:	d503201f 	nop
 b34:	d503201f 	nop

0000000000000b38 <strcpy@plt>:
 b38:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 b3c:	f946c211 	ldr	x17, [x16, #3456]
 b40:	91360210 	add	x16, x16, #0xd80
 b44:	d61f0220 	br	x17

0000000000000b48 <waitpid@plt>:
 b48:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 b4c:	f946c611 	ldr	x17, [x16, #3464]
 b50:	91362210 	add	x16, x16, #0xd88
 b54:	d61f0220 	br	x17

0000000000000b58 <socket_accept@plt>:
 b58:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 b5c:	f946ca11 	ldr	x17, [x16, #3472]
 b60:	91364210 	add	x16, x16, #0xd90
 b64:	d61f0220 	br	x17

0000000000000b68 <printf@plt>:
 b68:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 b6c:	f946ce11 	ldr	x17, [x16, #3480]
 b70:	91366210 	add	x16, x16, #0xd98
 b74:	d61f0220 	br	x17

0000000000000b78 <sync_destroy@plt>:
 b78:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 b7c:	f946d211 	ldr	x17, [x16, #3488]
 b80:	91368210 	add	x16, x16, #0xda0
 b84:	d61f0220 	br	x17

0000000000000b88 <memmove@plt>:
 b88:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 b8c:	f946d611 	ldr	x17, [x16, #3496]
 b90:	9136a210 	add	x16, x16, #0xda8
 b94:	d61f0220 	br	x17

0000000000000b98 <munmap@plt>:
 b98:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 b9c:	f946da11 	ldr	x17, [x16, #3504]
 ba0:	9136c210 	add	x16, x16, #0xdb0
 ba4:	d61f0220 	br	x17

0000000000000ba8 <gets@plt>:
 ba8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 bac:	f946de11 	ldr	x17, [x16, #3512]
 bb0:	9136e210 	add	x16, x16, #0xdb8
 bb4:	d61f0220 	br	x17

0000000000000bb8 <getpid@plt>:
 bb8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 bbc:	f946e211 	ldr	x17, [x16, #3520]
 bc0:	91370210 	add	x16, x16, #0xdc0
 bc4:	d61f0220 	br	x17

0000000000000bc8 <memcpy@plt>:
 bc8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 bcc:	f946e611 	ldr	x17, [x16, #3528]
 bd0:	91372210 	add	x16, x16, #0xdc8
 bd4:	d61f0220 	br	x17

0000000000000bd8 <malloc@plt>:
 bd8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 bdc:	f946ea11 	ldr	x17, [x16, #3536]
 be0:	91374210 	add	x16, x16, #0xdd0
 be4:	d61f0220 	br	x17

0000000000000be8 <ftruncate@plt>:
 be8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 bec:	f946ee11 	ldr	x17, [x16, #3544]
 bf0:	91376210 	add	x16, x16, #0xdd8
 bf4:	d61f0220 	br	x17

0000000000000bf8 <mmap@plt>:
 bf8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 bfc:	f946f211 	ldr	x17, [x16, #3552]
 c00:	91378210 	add	x16, x16, #0xde0
 c04:	d61f0220 	br	x17

0000000000000c08 <write@plt>:
 c08:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c0c:	f946f611 	ldr	x17, [x16, #3560]
 c10:	9137a210 	add	x16, x16, #0xde8
 c14:	d61f0220 	br	x17

0000000000000c18 <fstat@plt>:
 c18:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c1c:	f946fa11 	ldr	x17, [x16, #3568]
 c20:	9137c210 	add	x16, x16, #0xdf0
 c24:	d61f0220 	br	x17

0000000000000c28 <kill@plt>:
 c28:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c2c:	f946fe11 	ldr	x17, [x16, #3576]
 c30:	9137e210 	add	x16, x16, #0xdf8
 c34:	d61f0220 	br	x17

0000000000000c38 <wait@plt>:
 c38:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c3c:	f9470211 	ldr	x17, [x16, #3584]
 c40:	91380210 	add	x16, x16, #0xe00
 c44:	d61f0220 	br	x17

0000000000000c48 <sync_create@plt>:
 c48:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c4c:	f9470611 	ldr	x17, [x16, #3592]
 c50:	91382210 	add	x16, x16, #0xe08
 c54:	d61f0220 	br	x17

0000000000000c58 <read@plt>:
 c58:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c5c:	f9470a11 	ldr	x17, [x16, #3600]
 c60:	91384210 	add	x16, x16, #0xe10
 c64:	d61f0220 	br	x17

0000000000000c68 <unlink@plt>:
 c68:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c6c:	f9470e11 	ldr	x17, [x16, #3608]
 c70:	91386210 	add	x16, x16, #0xe18
 c74:	d61f0220 	br	x17

0000000000000c78 <fork@plt>:
 c78:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c7c:	f9471211 	ldr	x17, [x16, #3616]
 c80:	91388210 	add	x16, x16, #0xe20
 c84:	d61f0220 	br	x17

0000000000000c88 <memset@plt>:
 c88:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c8c:	f9471611 	ldr	x17, [x16, #3624]
 c90:	9138a210 	add	x16, x16, #0xe28
 c94:	d61f0220 	br	x17

0000000000000c98 <socket_listen@plt>:
 c98:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 c9c:	f9471a11 	ldr	x17, [x16, #3632]
 ca0:	9138c210 	add	x16, x16, #0xe30
 ca4:	d61f0220 	br	x17

0000000000000ca8 <strcmp@plt>:
 ca8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 cac:	f9471e11 	ldr	x17, [x16, #3640]
 cb0:	9138e210 	add	x16, x16, #0xe38
 cb4:	d61f0220 	br	x17

0000000000000cb8 <fsync@plt>:
 cb8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 cbc:	f9472211 	ldr	x17, [x16, #3648]
 cc0:	91390210 	add	x16, x16, #0xe40
 cc4:	d61f0220 	br	x17

0000000000000cc8 <pread@plt>:
 cc8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 ccc:	f9472611 	ldr	x17, [x16, #3656]
 cd0:	91392210 	add	x16, x16, #0xe48
 cd4:	d61f0220 	br	x17

0000000000000cd8 <clock_us@plt>:
 cd8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 cdc:	f9472a11 	ldr	x17, [x16, #3664]
 ce0:	91394210 	add	x16, x16, #0xe50
 ce4:	d61f0220 	br	x17

0000000000000ce8 <exit@plt>:
 ce8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 cec:	f9472e11 	ldr	x17, [x16, #3672]
 cf0:	91396210 	add	x16, x16, #0xe58
 cf4:	d61f0220 	br	x17

0000000000000cf8 <atoi@plt>:
 cf8:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 cfc:	f9473211 	ldr	x17, [x16, #3680]
 d00:	91398210 	add	x16, x16, #0xe60
 d04:	d61f0220 	br	x17

0000000000000d08 <strlen@plt>:
 d08:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d0c:	f9473611 	ldr	x17, [x16, #3688]
 d10:	9139a210 	add	x16, x16, #0xe68
 d14:	d61f0220 	br	x17

0000000000000d18 <open@plt>:
 d18:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d1c:	f9473a11 	ldr	x17, [x16, #3696]
 d20:	9139c210 	add	x16, x16, #0xe70
 d24:	d61f0220 	br	x17

0000000000000d28 <sync_signal@plt>:
 d28:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d2c:	f9473e11 	ldr	x17, [x16, #3704]
 d30:	9139e210 	add	x16, x16, #0xe78
 d34:	d61f0220 	br	x17

0000000000000d38 <sched_yield@plt>:
 d38:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d3c:	f9474211 	ldr	x17, [x16, #3712]
 d40:	913a0210 	add	x16, x16, #0xe80
 d44:	d61f0220 	br	x17

0000000000000d48 <mkdir@plt>:
 d48:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d4c:	f9474611 	ldr	x17, [x16, #3720]
 d50:	913a2210 	add	x16, x16, #0xe88
 d54:	d61f0220 	br	x17

0000000000000d58 <pwrite@plt>:
 d58:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d5c:	f9474a11 	ldr	x17, [x16, #3728]
 d60:	913a4210 	add	x16, x16, #0xe90
 d64:	d61f0220 	br	x17

0000000000000d68 <close@plt>:
 d68:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d6c:	f9474e11 	ldr	x17, [x16, #3736]
 d70:	913a6210 	add	x16, x16, #0xe98
 d74:	d61f0220 	br	x17

0000000000000d78 <sync_wait@plt>:
 d78:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d7c:	f9475211 	ldr	x17, [x16, #3744]
 d80:	913a8210 	add	x16, x16, #0xea0
 d84:	d61f0220 	br	x17

0000000000000d88 <free@plt>:
 d88:	d0000030 	adrp	x16, 6000 <pgwire_connection+0x1ba0>
 d8c:	f9475611 	ldr	x17, [x16, #3752]
 d90:	913aa210 	add	x16, x16, #0xea8
 d94:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000d98 <main>:
  printf("              stress [WORKERS [TRANSACTIONS_PER_WORKER]]\n");
}

int
main(int argc, char **argv)
{
     d98:	d11683ff 	sub	sp, sp, #0x5a0
     d9c:	a9007bfd 	stp	x29, x30, [sp]
     da0:	910003fd 	mov	x29, sp
     da4:	a90153f3 	stp	x19, x20, [sp, #16]
     da8:	a9025bf5 	stp	x21, x22, [sp, #32]
     dac:	a90363f7 	stp	x23, x24, [sp, #48]
     db0:	f90023f9 	str	x25, [sp, #64]
  if(argc < 2){
     db4:	7100041f 	cmp	w0, #0x1
     db8:	5400008c 	b.gt	dc8 <main+0x30>
    usage();
     dbc:	94000574 	bl	238c <usage>
    exit(run_postmaster(workers) < 0);
  }

  struct ipc_client client;
  if(ipc_client_attach(&client) < 0)
    exit(1);
     dc0:	52800020 	mov	w0, #0x1                   	// #1
     dc4:	14000038 	b	ea4 <main+0x10c>
     dc8:	aa0103f4 	mov	x20, x1
  if(strcmp(argv[1], "init") == 0)
     dcc:	2a0003f5 	mov	w21, w0
     dd0:	b0000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
     dd4:	91183021 	add	x1, x1, #0x60c
     dd8:	f9400680 	ldr	x0, [x20, #8]
     ddc:	97ffffb3 	bl	ca8 <strcmp@plt>
     de0:	35000820 	cbnz	w0, ee4 <main+0x14c>
  ensure_directories();
     de4:	94000a3a 	bl	36cc <ensure_directories.isra.0>
  int fd = open(DB_PATH, O_CREATE | O_RDWR | O_TRUNC);
     de8:	b0000036 	adrp	x22, 5000 <pgwire_connection+0xba0>
     dec:	9100c2d6 	add	x22, x22, #0x30
     df0:	5280c041 	mov	w1, #0x602                 	// #1538
     df4:	aa1603e0 	mov	x0, x22
     df8:	97ffffc8 	bl	d18 <open@plt>
     dfc:	2a0003f5 	mov	w21, w0
  if(fd < 0)
     e00:	37f804c0 	tbnz	w0, #31, e98 <main+0x100>
  memset(&disk_header, 0, sizeof(disk_header));
     e04:	f0000033 	adrp	x19, 7000 <wal_buffer+0x110>
     e08:	913bc273 	add	x19, x19, #0xef0
     e0c:	52820002 	mov	w2, #0x1000                	// #4096
     e10:	52800001 	mov	w1, #0x0                   	// #0
     e14:	aa1303e0 	mov	x0, x19
     e18:	97ffff9c 	bl	c88 <memset@plt>
  disk_header.magic = DB_MAGIC;
     e1c:	d2888840 	mov	x0, #0x4442                	// #17474
     e20:	f2a9ab20 	movk	x0, #0x4d59, lsl #16
     e24:	d2800801 	mov	x1, #0x40                  	// #64
     e28:	f2c00020 	movk	x0, #0x1, lsl #32
     e2c:	f2c08001 	movk	x1, #0x400, lsl #32
     e30:	a9000660 	stp	x0, x1, [x19]
  h->checksum = hash_bytes(h, sizeof(*h));
     e34:	52820001 	mov	w1, #0x1000                	// #4096
     e38:	aa1303e0 	mov	x0, x19
  h->checksum = 0;
     e3c:	b9002a7f 	str	wzr, [x19, #40]
  h->checksum = hash_bytes(h, sizeof(*h));
     e40:	940004e1 	bl	21c4 <hash_bytes>
  int ok = ftruncate(fd, bytes) == 0 &&
     e44:	d2820001 	mov	x1, #0x1000                	// #4096
     e48:	f2a00021 	movk	x1, #0x1, lsl #16
  h->checksum = hash_bytes(h, sizeof(*h));
     e4c:	b9002a60 	str	w0, [x19, #40]
  int ok = ftruncate(fd, bytes) == 0 &&
     e50:	2a1503e0 	mov	w0, w21
     e54:	97ffff65 	bl	be8 <ftruncate@plt>
     e58:	2a0003f4 	mov	w20, w0
             sizeof(disk_header) && fsync(fd) == 0;
     e5c:	35000260 	cbnz	w0, ea8 <main+0x110>
           pwrite(fd, &disk_header, sizeof(disk_header), 0) ==
     e60:	aa1303e1 	mov	x1, x19
     e64:	2a1503e0 	mov	w0, w21
     e68:	d2800003 	mov	x3, #0x0                   	// #0
     e6c:	52820002 	mov	w2, #0x1000                	// #4096
     e70:	97ffffba 	bl	d58 <pwrite@plt>
  int ok = ftruncate(fd, bytes) == 0 &&
     e74:	7140041f 	cmp	w0, #0x1, lsl #12
     e78:	540000a1 	b.ne	e8c <main+0xf4>  // b.any
             sizeof(disk_header) && fsync(fd) == 0;
     e7c:	2a1503e0 	mov	w0, w21
     e80:	97ffff8e 	bl	cb8 <fsync@plt>
     e84:	7100001f 	cmp	w0, #0x0
     e88:	1a9f17f4 	cset	w20, eq	// eq = none
  close(fd);
     e8c:	2a1503e0 	mov	w0, w21
     e90:	97ffffb6 	bl	d68 <close@plt>
  if(!ok || clear_wal() < 0)
     e94:	350000f4 	cbnz	w20, eb0 <main+0x118>
    return -1;
     e98:	12800000 	mov	w0, #0xffffffff            	// #-1
    exit(initialize_database() < 0);
     e9c:	3100041f 	cmn	w0, #0x1
     ea0:	1a9f17e0 	cset	w0, eq	// eq = none
     ea4:	97ffff91 	bl	ce8 <exit@plt>
             sizeof(disk_header) && fsync(fd) == 0;
     ea8:	52800014 	mov	w20, #0x0                   	// #0
     eac:	17fffff8 	b	e8c <main+0xf4>
  if(!ok || clear_wal() < 0)
     eb0:	94000572 	bl	2478 <clear_wal>
     eb4:	3100041f 	cmn	w0, #0x1
     eb8:	54ffff20 	b.eq	e9c <main+0x104>  // b.none
  unlink(OLD_SHM_PATH);
     ebc:	b0000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
     ec0:	91184400 	add	x0, x0, #0x611
     ec4:	97ffff69 	bl	c68 <unlink@plt>
  printf("mygres: initialized %s rows=%d\n", DB_PATH, MAX_ROWS);
     ec8:	aa1603e1 	mov	x1, x22
     ecc:	b0000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
     ed0:	9118a800 	add	x0, x0, #0x62a
     ed4:	52808002 	mov	w2, #0x400                 	// #1024
     ed8:	97ffff24 	bl	b68 <printf@plt>
  return 0;
     edc:	52800000 	mov	w0, #0x0                   	// #0
     ee0:	17ffffef 	b	e9c <main+0x104>
  if(strcmp(argv[1], "server") == 0){
     ee4:	f9400680 	ldr	x0, [x20, #8]
     ee8:	b0000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
     eec:	91192821 	add	x1, x1, #0x64a
     ef0:	b0000036 	adrp	x22, 5000 <pgwire_connection+0xba0>
     ef4:	91005ad6 	add	x22, x22, #0x16
     ef8:	97ffff6c 	bl	ca8 <strcmp@plt>
     efc:	2a0003f7 	mov	w23, w0
     f00:	35003aa0 	cbnz	w0, 1654 <main+0x8bc>
    uint workers = argc >= 3 ? atoi(argv[2]) : MAX_WORKERS;
     f04:	71000abf 	cmp	w21, #0x2
     f08:	54000180 	b.eq	f38 <main+0x1a0>  // b.none
     f0c:	f9400a80 	ldr	x0, [x20, #16]
     f10:	97ffff7a 	bl	cf8 <atoi@plt>
     f14:	2a0003f5 	mov	w21, w0
  if(workers == 0 || workers > MAX_WORKERS){
     f18:	51000400 	sub	w0, w0, #0x1
     f1c:	71000c1f 	cmp	w0, #0x3
     f20:	540000e9 	b.ls	f3c <main+0x1a4>  // b.plast
    printf("mygres: workers must be between 1 and %d\n", MAX_WORKERS);
     f24:	b0000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
     f28:	91194400 	add	x0, x0, #0x651
     f2c:	52800081 	mov	w1, #0x4                   	// #4
     f30:	97ffff0e 	bl	b68 <printf@plt>
    return -1;
     f34:	17ffffa3 	b	dc0 <main+0x28>
    uint workers = argc >= 3 ? atoi(argv[2]) : MAX_WORKERS;
     f38:	52800095 	mov	w21, #0x4                   	// #4
  memset(db, 0, sizeof(*db));
     f3c:	52800202 	mov	w2, #0x10                  	// #16
     f40:	52800001 	mov	w1, #0x0                   	// #0
     f44:	910243e0 	add	x0, sp, #0x90
     f48:	97ffff50 	bl	c88 <memset@plt>
  db->shm_bytes = roundup_page(sizeof(struct shm_state));
     f4c:	d2860000 	mov	x0, #0x3000                	// #12288
     f50:	f2a00020 	movk	x0, #0x1, lsl #16
  int fd = open(DB_PATH, O_RDONLY);
     f54:	b0000033 	adrp	x19, 5000 <pgwire_connection+0xba0>
     f58:	52800001 	mov	w1, #0x0                   	// #0
  db->shm_bytes = roundup_page(sizeof(struct shm_state));
     f5c:	f9004fe0 	str	x0, [sp, #152]
  int fd = open(DB_PATH, O_RDONLY);
     f60:	9100c260 	add	x0, x19, #0x30
     f64:	97ffff6d 	bl	d18 <open@plt>
     f68:	2a0003f4 	mov	w20, w0
  if(fd < 0 || read_db_header(fd, &disk_header) < 0){
     f6c:	37f800c0 	tbnz	w0, #31, f84 <main+0x1ec>
     f70:	94000874 	bl	3140 <read_db_header.constprop.0>
     f74:	3100041f 	cmn	w0, #0x1
      close(fd);
     f78:	2a1403e0 	mov	w0, w20
  if(fd < 0 || read_db_header(fd, &disk_header) < 0){
     f7c:	540000c1 	b.ne	f94 <main+0x1fc>  // b.any
      close(fd);
     f80:	97ffff7a 	bl	d68 <close@plt>
    printf("mygres: database is not initialized; run 'mygres init'\n");
     f84:	b0000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
     f88:	9119ec00 	add	x0, x0, #0x67b
    printf("mygres: stale IPC page; restart /bin/mygresd\n");
     f8c:	97fffef7 	bl	b68 <printf@plt>
    return -1;
     f90:	17ffff8c 	b	dc0 <main+0x28>
  close(fd);
     f94:	97ffff75 	bl	d68 <close@plt>
  db->shm = mmap(0, db->shm_bytes, PROT_READ | PROT_WRITE,
     f98:	f9404fe1 	ldr	x1, [sp, #152]
     f9c:	d2800005 	mov	x5, #0x0                   	// #0
     fa0:	12800004 	mov	w4, #0xffffffff            	// #-1
     fa4:	52800423 	mov	w3, #0x21                  	// #33
     fa8:	52800062 	mov	w2, #0x3                   	// #3
     fac:	d2800000 	mov	x0, #0x0                   	// #0
     fb0:	97ffff12 	bl	bf8 <mmap@plt>
     fb4:	f9004be0 	str	x0, [sp, #144]
  if(db->shm == MAP_FAILED){
     fb8:	b100041f 	cmn	x0, #0x1
     fbc:	54fff020 	b.eq	dc0 <main+0x28>  // b.none
  memset((void *)db->shm, 0, sizeof(*db->shm));
     fc0:	52800001 	mov	w1, #0x0                   	// #0
     fc4:	52840802 	mov	w2, #0x2040                	// #8256
     fc8:	72a00022 	movk	w2, #0x1, lsl #16
     fcc:	97ffff2f 	bl	c88 <memset@plt>
  db->shm->magic = SHM_MAGIC;
     fd0:	f9404be0 	ldr	x0, [sp, #144]
     fd4:	d28a6901 	mov	x1, #0x5348                	// #21320
     fd8:	f2a9ab21 	movk	x1, #0x4d59, lsl #16
     fdc:	f2c00021 	movk	x1, #0x1, lsl #32
     fe0:	f8004001 	stur	x1, [x0, #4]
  shared_lock(&db->shm->lock);
     fe4:	94000545 	bl	24f8 <shared_lock>
  if(recover_locked(db, verbose) < 0){
     fe8:	910243e0 	add	x0, sp, #0x90
     fec:	94000951 	bl	3530 <recover_locked.constprop.0>
     ff0:	3100041f 	cmn	w0, #0x1
     ff4:	540000e1 	b.ne	1010 <main+0x278>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
     ff8:	f9404be1 	ldr	x1, [sp, #144]
     ffc:	52800000 	mov	w0, #0x0                   	// #0
    1000:	889ffc20 	stlr	w0, [x1]
    munmap(db->shm, db->shm_bytes);
    1004:	a94907e0 	ldp	x0, x1, [sp, #144]
    1008:	97fffee4 	bl	b98 <munmap@plt>
    return -1;
    100c:	17ffff6d 	b	dc0 <main+0x28>
  fd = open(DB_PATH, O_RDONLY);
    1010:	9100c260 	add	x0, x19, #0x30
    1014:	52800001 	mov	w1, #0x0                   	// #0
    1018:	97ffff40 	bl	d18 <open@plt>
    101c:	2a0003f4 	mov	w20, w0
              !db->shm->ready || db->shm->db_txid != disk_header.txid;
    1020:	37f80160 	tbnz	w0, #31, 104c <main+0x2b4>
  int stale = fd < 0 || read_db_header(fd, &disk_header) < 0 ||
    1024:	94000847 	bl	3140 <read_db_header.constprop.0>
    1028:	3100041f 	cmn	w0, #0x1
    102c:	54000080 	b.eq	103c <main+0x2a4>  // b.none
              !db->shm->ready || db->shm->db_txid != disk_header.txid;
    1030:	f9404be1 	ldr	x1, [sp, #144]
  int stale = fd < 0 || read_db_header(fd, &disk_header) < 0 ||
    1034:	b9400c20 	ldr	w0, [x1, #12]
    1038:	35000340 	cbnz	w0, 10a0 <main+0x308>
              !db->shm->ready || db->shm->db_txid != disk_header.txid;
    103c:	52800033 	mov	w19, #0x1                   	// #1
    close(fd);
    1040:	2a1403e0 	mov	w0, w20
    1044:	97ffff49 	bl	d68 <close@plt>
  if(stale && reload_shared_locked(db) < 0){
    1048:	340000b3 	cbz	w19, 105c <main+0x2c4>
    104c:	910243e0 	add	x0, sp, #0x90
    1050:	9400085f 	bl	31cc <reload_shared_locked>
    1054:	3100041f 	cmn	w0, #0x1
    1058:	54fffd00 	b.eq	ff8 <main+0x260>  // b.none
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    105c:	f9404be1 	ldr	x1, [sp, #144]
    1060:	52800000 	mov	w0, #0x0                   	// #0
    1064:	889ffc20 	stlr	w0, [x1]
  ensure_directories();
    1068:	94000999 	bl	36cc <ensure_directories.isra.0>
  fd = open(IPC_PATH, O_CREATE | O_RDWR | O_TRUNC);
    106c:	aa1603e0 	mov	x0, x22
    1070:	5280c041 	mov	w1, #0x602                 	// #1538
    1074:	97ffff29 	bl	d18 <open@plt>
    1078:	2a0003f4 	mov	w20, w0
  if(fd < 0 || ftruncate(fd, PAGE_SIZE) < 0){
    107c:	37f800c0 	tbnz	w0, #31, 1094 <main+0x2fc>
    1080:	d2820001 	mov	x1, #0x1000                	// #4096
    1084:	97fffed9 	bl	be8 <ftruncate@plt>
    1088:	36f80180 	tbz	w0, #31, 10b8 <main+0x320>
      close(fd);
    108c:	2a1403e0 	mov	w0, w20
    1090:	97ffff36 	bl	d68 <close@plt>
  destroy_postmaster_database(&db);
    1094:	910243e0 	add	x0, sp, #0x90
    1098:	9400050c 	bl	24c8 <destroy_postmaster_database>
  return -1;
    109c:	17ffff49 	b	dc0 <main+0x28>
              !db->shm->ready || db->shm->db_txid != disk_header.txid;
    10a0:	f9400821 	ldr	x1, [x1, #16]
    10a4:	d0000020 	adrp	x0, 7000 <wal_buffer+0x110>
    10a8:	f9478000 	ldr	x0, [x0, #3840]
    10ac:	eb00003f 	cmp	x1, x0
    10b0:	1a9f07f3 	cset	w19, ne	// ne = any
    10b4:	17ffffe3 	b	1040 <main+0x2a8>
  ipc = mmap(0, PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    10b8:	2a1403e4 	mov	w4, w20
    10bc:	d2800005 	mov	x5, #0x0                   	// #0
    10c0:	52800023 	mov	w3, #0x1                   	// #1
    10c4:	52800062 	mov	w2, #0x3                   	// #3
    10c8:	d2820001 	mov	x1, #0x1000                	// #4096
    10cc:	d2800000 	mov	x0, #0x0                   	// #0
    10d0:	97fffeca 	bl	bf8 <mmap@plt>
    10d4:	aa0003f3 	mov	x19, x0
  close(fd);
    10d8:	2a1403e0 	mov	w0, w20
    10dc:	97ffff23 	bl	d68 <close@plt>
  if(ipc == MAP_FAILED)
    10e0:	b100067f 	cmn	x19, #0x1
    10e4:	54fffd80 	b.eq	1094 <main+0x2fc>  // b.none
  memset(ipc, 0, PAGE_SIZE);
    10e8:	52820002 	mov	w2, #0x1000                	// #4096
    10ec:	52800001 	mov	w1, #0x0                   	// #0
    10f0:	aa1303e0 	mov	x0, x19
    10f4:	97fffee5 	bl	c88 <memset@plt>
  ipc->magic = IPC_MAGIC;
    10f8:	d2892a00 	mov	x0, #0x4950                	// #18768
    10fc:	f2a9ab20 	movk	x0, #0x4d59, lsl #16
    1100:	f2c00020 	movk	x0, #0x1, lsl #32
    1104:	f9000260 	str	x0, [x19]
  ipc->generation = (uint32)clock_us();
    1108:	9100e279 	add	x25, x19, #0x38
  for(uint i = 0; i < workers; i++){
    110c:	52800014 	mov	w20, #0x0                   	// #0
  ipc->generation = (uint32)clock_us();
    1110:	97fffef2 	bl	cd8 <clock_us@plt>
    1114:	b9000e60 	str	w0, [x19, #12]
  ipc->nworkers = workers;
    1118:	aa1903f8 	mov	x24, x25
  ipc->postmaster_pid = getpid();
    111c:	97fffea7 	bl	bb8 <getpid@plt>
    1120:	29025660 	stp	w0, w21, [x19, #16]
    ipc->slots[i].request_sem = sync_create(SYNC_SEM, 0);
    1124:	52800001 	mov	w1, #0x0                   	// #0
    1128:	52800040 	mov	w0, #0x2                   	// #2
    112c:	97fffec7 	bl	c48 <sync_create@plt>
    1130:	b9000300 	str	w0, [x24]
    ipc->slots[i].response_sem = sync_create(SYNC_SEM, 0);
    1134:	52800001 	mov	w1, #0x0                   	// #0
    1138:	52800040 	mov	w0, #0x2                   	// #2
    113c:	97fffec3 	bl	c48 <sync_create@plt>
    1140:	b9000700 	str	w0, [x24, #4]
    if(ipc->slots[i].request_sem < 0 || ipc->slots[i].response_sem < 0){
    1144:	b9400301 	ldr	w1, [x24]
    1148:	2a010000 	orr	w0, w0, w1
    114c:	36f80240 	tbz	w0, #31, 1194 <main+0x3fc>
    1150:	52800015 	mov	w21, #0x0                   	// #0
        if(ipc->slots[j].request_sem >= 0)
    1154:	b9400320 	ldr	w0, [x25]
    1158:	37f80040 	tbnz	w0, #31, 1160 <main+0x3c8>
          sync_destroy(ipc->slots[j].request_sem);
    115c:	97fffe87 	bl	b78 <sync_destroy@plt>
        if(ipc->slots[j].response_sem >= 0)
    1160:	b9400720 	ldr	w0, [x25, #4]
    1164:	37f80040 	tbnz	w0, #31, 116c <main+0x3d4>
          sync_destroy(ipc->slots[j].response_sem);
    1168:	97fffe84 	bl	b78 <sync_destroy@plt>
      for(uint j = 0; j <= i; j++){
    116c:	110006b5 	add	w21, w21, #0x1
    1170:	910a0339 	add	x25, x25, #0x280
    1174:	6b1402bf 	cmp	w21, w20
    1178:	54fffee9 	b.ls	1154 <main+0x3bc>  // b.plast
      munmap(ipc, PAGE_SIZE);
    117c:	d2820001 	mov	x1, #0x1000                	// #4096
    1180:	aa1303e0 	mov	x0, x19
    1184:	97fffe85 	bl	b98 <munmap@plt>
      unlink(IPC_PATH);
    1188:	aa1603e0 	mov	x0, x22
    118c:	97fffeb7 	bl	c68 <unlink@plt>
      return 0;
    1190:	17ffffc1 	b	1094 <main+0x2fc>
  for(uint i = 0; i < workers; i++){
    1194:	11000694 	add	w20, w20, #0x1
    1198:	910a0318 	add	x24, x24, #0x280
    119c:	6b1402bf 	cmp	w21, w20
    11a0:	54fffc21 	b.ne	1124 <main+0x38c>  // b.any
    11a4:	9100a279 	add	x25, x19, #0x28
  int started = 0, pgwire_pid = 0;
    11a8:	52800015 	mov	w21, #0x0                   	// #0
    11ac:	aa1903f8 	mov	x24, x25
    int pid = fork();
    11b0:	97fffeb2 	bl	c78 <fork@plt>
    if(pid < 0)
    11b4:	37f817a0 	tbnz	w0, #31, 14a8 <main+0x710>
    if(pid == 0)
    11b8:	35001580 	cbnz	w0, 1468 <main+0x6d0>
  slot->worker_pid = getpid();
    11bc:	97fffe7f 	bl	bb8 <getpid@plt>
    11c0:	2a1503f4 	mov	w20, w21
    11c4:	d2805001 	mov	x1, #0x280                 	// #640
    11c8:	9b014e94 	madd	x20, x20, x1, x19
    11cc:	b9002a80 	str	w0, [x20, #40]
  __sync_synchronize();
    11d0:	d5033bbf 	dmb	ish
    atomic_publish(&slot->state, SLOT_RESPONSE);
    11d4:	91008273 	add	x19, x19, #0x20
  switch(request->command){
    11d8:	90000037 	adrp	x23, 5000 <pgwire_connection+0xba0>
    11dc:	9130b2f7 	add	x23, x23, #0xc2c
    request = slot->request;
    11e0:	91010298 	add	x24, x20, #0x40
    atomic_publish(&slot->state, SLOT_RESPONSE);
    11e4:	9ba14eb5 	umaddl	x21, w21, w1, x19
    if(sync_wait(slot->request_sem) < 0)
    11e8:	b9403a80 	ldr	w0, [x20, #56]
    11ec:	97fffee3 	bl	d78 <sync_wait@plt>
    11f0:	37f80660 	tbnz	w0, #31, 12bc <main+0x524>
    if(slot->state != SLOT_REQUEST)
    11f4:	b9402280 	ldr	w0, [x20, #32]
    11f8:	7100081f 	cmp	w0, #0x2
    11fc:	54ffff61 	b.ne	11e8 <main+0x450>  // b.any
    request = slot->request;
    1200:	aa1803e1 	mov	x1, x24
    1204:	d2804302 	mov	x2, #0x218                 	// #536
    1208:	910e23e0 	add	x0, sp, #0x388
    120c:	97fffe6f 	bl	bc8 <memcpy@plt>
    1210:	29484e96 	ldp	w22, w19, [x20, #64]
  memset(response, 0, sizeof(*response));
    1214:	910363e0 	add	x0, sp, #0xd8
    request = slot->request;
    1218:	b9404a99 	ldr	w25, [x20, #72]
  memset(response, 0, sizeof(*response));
    121c:	52800902 	mov	w2, #0x48                  	// #72
    1220:	52800001 	mov	w1, #0x0                   	// #0
    1224:	97fffe99 	bl	c88 <memset@plt>
  response->status = -1;
    1228:	12800000 	mov	w0, #0xffffffff            	// #-1
    122c:	b900dbe0 	str	w0, [sp, #216]
  switch(request->command){
    1230:	0b0002c0 	add	w0, w22, w0
    1234:	71001c1f 	cmp	w0, #0x7
    1238:	540000c8 	b.hi	1250 <main+0x4b8>  // b.pmore
    123c:	78605ae0 	ldrh	w0, [x23, w0, uxtw #1]
    1240:	10000061 	adr	x1, 124c <main+0x4b4>
    1244:	8b20a820 	add	x0, x1, w0, sxth #2
    1248:	d61f0000 	br	x0
    response->status = 0;
    124c:	b900dbff 	str	wzr, [sp, #216]
  shared_lock(&db->shm->lock);
    1250:	f9404be0 	ldr	x0, [sp, #144]
    1254:	940004a9 	bl	24f8 <shared_lock>
  response->txid = db->shm->db_txid;
    1258:	f9404be0 	ldr	x0, [sp, #144]
    125c:	f9400801 	ldr	x1, [x0, #16]
    1260:	f90077e1 	str	x1, [sp, #232]
  response->rows = db->shm->nrows;
    1264:	f9400c01 	ldr	x1, [x0, #24]
    1268:	f9007fe1 	str	x1, [sp, #248]
  response->commits = db->shm->commits;
    126c:	f9401001 	ldr	x1, [x0, #32]
    1270:	f90083e1 	str	x1, [sp, #256]
  response->recoveries = db->shm->recoveries;
    1274:	f9401401 	ldr	x1, [x0, #40]
    1278:	f90087e1 	str	x1, [sp, #264]
  response->index_hits = db->shm->index_hits;
    127c:	f9401801 	ldr	x1, [x0, #48]
    1280:	f9008be1 	str	x1, [sp, #272]
  response->index_misses = db->shm->index_misses;
    1284:	f9401c01 	ldr	x1, [x0, #56]
    1288:	f9008fe1 	str	x1, [sp, #280]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    128c:	52800001 	mov	w1, #0x0                   	// #0
    1290:	889ffc01 	stlr	w1, [x0]
    slot->response = response;
    1294:	910363e1 	add	x1, sp, #0xd8
    1298:	91096280 	add	x0, x20, #0x258
    129c:	d2800902 	mov	x2, #0x48                  	// #72
    12a0:	97fffe4a 	bl	bc8 <memcpy@plt>
  asm volatile("stlr %w0, [%1]" :: "r"(value), "r"(word) : "memory");
    12a4:	52800060 	mov	w0, #0x3                   	// #3
    12a8:	889ffea0 	stlr	w0, [x21]
    if(sync_signal(slot->response_sem, 1) < 0)
    12ac:	b9403e80 	ldr	w0, [x20, #60]
    12b0:	52800021 	mov	w1, #0x1                   	// #1
    12b4:	97fffe9d 	bl	d28 <sync_signal@plt>
    12b8:	36fff980 	tbz	w0, #31, 11e8 <main+0x450>
      exit(0);
    12bc:	52800000 	mov	w0, #0x0                   	// #0
    12c0:	17fffef9 	b	ea4 <main+0x10c>
  shared_lock(&db->shm->lock);
    12c4:	f9404be0 	ldr	x0, [sp, #144]
    response->key = request->key;
    12c8:	b900dff9 	str	w25, [sp, #220]
  shared_lock(&db->shm->lock);
    12cc:	9400048b 	bl	24f8 <shared_lock>
  int slot = index_lookup(db->shm, key, 1);
    12d0:	f9404be8 	ldr	x8, [sp, #144]
    12d4:	2a1903e1 	mov	w1, w25
    12d8:	52800022 	mov	w2, #0x1                   	// #1
    12dc:	aa0803e0 	mov	x0, x8
    12e0:	940009b5 	bl	39b4 <index_lookup>
  if(slot >= 0){
    12e4:	3100041f 	cmn	w0, #0x1
    12e8:	540001c0 	b.eq	1320 <main+0x588>  // b.none
    *value = db->shm->rows[slot].value;
    12ec:	2a0003e1 	mov	w1, w0
    12f0:	8b011902 	add	x2, x8, x1, lsl #6
      *txid = db->shm->rows[slot].txid;
    12f4:	8b011901 	add	x1, x8, x1, lsl #6
    *value = db->shm->rows[slot].value;
    12f8:	f9502442 	ldr	x2, [x2, #8264]
      *txid = db->shm->rows[slot].txid;
    12fc:	f9502821 	ldr	x1, [x1, #8272]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    1300:	52800003 	mov	w3, #0x0                   	// #0
    1304:	889ffd03 	stlr	w3, [x8]
  return slot >= 0 ? 0 : 1;
    1308:	3100041f 	cmn	w0, #0x1
    response->value = value;
    130c:	f90073e2 	str	x2, [sp, #224]
  return slot >= 0 ? 0 : 1;
    1310:	1a9f17e0 	cset	w0, eq	// eq = none
    response->status = db_get(db, request->key, &value, &txid);
    1314:	b900dbe0 	str	w0, [sp, #216]
    response->row_txid = txid;
    1318:	f9007be1 	str	x1, [sp, #240]
    break;
    131c:	17ffffcd 	b	1250 <main+0x4b8>
  uint64 value = 0, txid = 0;
    1320:	d2800001 	mov	x1, #0x0                   	// #0
    1324:	d2800002 	mov	x2, #0x0                   	// #0
    1328:	17fffff6 	b	1300 <main+0x568>
    if(request->nops > MAX_TX_OPS)
    132c:	7100827f 	cmp	w19, #0x20
    1330:	54fff908 	b.hi	1250 <main+0x4b8>  // b.pmore
    memset(&tx, 0, sizeof(tx));
    1334:	52800001 	mov	w1, #0x0                   	// #0
    1338:	9105e3e0 	add	x0, sp, #0x178
    133c:	52804202 	mov	w2, #0x210                 	// #528
    1340:	97fffe52 	bl	c88 <memset@plt>
    tx.active = 1;
    1344:	52800020 	mov	w0, #0x1                   	// #1
    1348:	9105e3e3 	add	x3, sp, #0x178
    134c:	b9017be0 	str	w0, [sp, #376]
    tx.nops = request->nops;
    1350:	910e23e0 	add	x0, sp, #0x388
    for(uint i = 0; i < tx.nops; i++){
    1354:	52800001 	mov	w1, #0x0                   	// #0
    tx.nops = request->nops;
    1358:	b9017ff3 	str	w19, [sp, #380]
    for(uint i = 0; i < tx.nops; i++){
    135c:	6b13003f 	cmp	w1, w19
    1360:	54000141 	b.ne	1388 <main+0x5f0>  // b.any
    response->status = tx_commit(db, &tx,
    1364:	710022df 	cmp	w22, #0x8
    1368:	9105e3e1 	add	x1, sp, #0x178
    136c:	1a9f17e2 	cset	w2, eq	// eq = none
    1370:	910243e0 	add	x0, sp, #0x90
    1374:	940009ba 	bl	3a5c <tx_commit>
    1378:	7100081f 	cmp	w0, #0x2
    137c:	1a9f1000 	csel	w0, w0, wzr, ne	// ne = any
      response->status = check_database(db);
    1380:	b900dbe0 	str	w0, [sp, #216]
    1384:	17ffffb3 	b	1250 <main+0x4b8>
      if(request->ops[i].type != OP_PUT &&
    1388:	b9401802 	ldr	w2, [x0, #24]
    138c:	51000442 	sub	w2, w2, #0x1
    1390:	7100045f 	cmp	w2, #0x1
    1394:	54fff808 	b.hi	1294 <main+0x4fc>  // b.pmore
      tx.ops[i] = request->ops[i];
    1398:	a9419404 	ldp	x4, x5, [x0, #24]
      if(request->ops[i].type != OP_PUT &&
    139c:	91004000 	add	x0, x0, #0x10
    for(uint i = 0; i < tx.nops; i++){
    13a0:	11000421 	add	w1, w1, #0x1
      tx.ops[i] = request->ops[i];
    13a4:	a9811464 	stp	x4, x5, [x3, #16]!
    for(uint i = 0; i < tx.nops; i++){
    13a8:	17ffffed 	b	135c <main+0x5c4>
  shared_lock(&db->shm->lock);
    13ac:	f9404be0 	ldr	x0, [sp, #144]
        printf("key=%d value=%l xmin=%l slot=%d\n",
    13b0:	90000039 	adrp	x25, 5000 <pgwire_connection+0xba0>
    13b4:	911acf39 	add	x25, x25, #0x6b3
  uint64 count = 0;
    13b8:	d2800016 	mov	x22, #0x0                   	// #0
  for(uint i = 0; i < MAX_ROWS; i++)
    13bc:	52800013 	mov	w19, #0x0                   	// #0
  shared_lock(&db->shm->lock);
    13c0:	9400044e 	bl	24f8 <shared_lock>
    if(db->shm->rows[i].state == ROW_USED){
    13c4:	f9404be1 	ldr	x1, [sp, #144]
    13c8:	d37a7e60 	ubfiz	x0, x19, #6, #32
    13cc:	8b000021 	add	x1, x1, x0
    13d0:	b9604020 	ldr	w0, [x1, #8256]
    13d4:	7100041f 	cmp	w0, #0x1
    13d8:	54000101 	b.ne	13f8 <main+0x660>  // b.any
        printf("key=%d value=%l xmin=%l slot=%d\n",
    13dc:	f9502422 	ldr	x2, [x1, #8264]
      count++;
    13e0:	910006d6 	add	x22, x22, #0x1
        printf("key=%d value=%l xmin=%l slot=%d\n",
    13e4:	f9502823 	ldr	x3, [x1, #8272]
    13e8:	2a1303e4 	mov	w4, w19
    13ec:	b9604421 	ldr	w1, [x1, #8260]
    13f0:	aa1903e0 	mov	x0, x25
    13f4:	97fffddd 	bl	b68 <printf@plt>
  for(uint i = 0; i < MAX_ROWS; i++)
    13f8:	11000673 	add	w19, w19, #0x1
    13fc:	7110027f 	cmp	w19, #0x400
    1400:	54fffe21 	b.ne	13c4 <main+0x62c>  // b.any
  uint64 expected = db->shm->nrows;
    1404:	f9404be0 	ldr	x0, [sp, #144]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    1408:	52800002 	mov	w2, #0x0                   	// #0
  uint64 txid = db->shm->db_txid;
    140c:	a9414c01 	ldp	x1, x19, [x0, #16]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    1410:	889ffc02 	stlr	w2, [x0]
  printf("mygres: txid=%l rows=%l scanned=%l\n", txid, expected, count);
    1414:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1418:	911b5000 	add	x0, x0, #0x6d4
    141c:	aa1603e3 	mov	x3, x22
    1420:	aa1303e2 	mov	x2, x19
    1424:	97fffdd1 	bl	b68 <printf@plt>
  return count == expected ? 0 : -1;
    1428:	eb16027f 	cmp	x19, x22
    142c:	5a9f03e0 	csetm	w0, ne	// ne = any
    1430:	17ffffd4 	b	1380 <main+0x5e8>
    shared_lock(&db->shm->lock);
    1434:	f9404be0 	ldr	x0, [sp, #144]
    1438:	94000430 	bl	24f8 <shared_lock>
    response->status = recover_locked(db, 1);
    143c:	910243e0 	add	x0, sp, #0x90
    1440:	9400083c 	bl	3530 <recover_locked.constprop.0>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    1444:	f9404be1 	ldr	x1, [sp, #144]
    response->status = recover_locked(db, 1);
    1448:	b900dbe0 	str	w0, [sp, #216]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    144c:	52800000 	mov	w0, #0x0                   	// #0
    1450:	889ffc20 	stlr	w0, [x1]
    if(response->status == 0)
    1454:	b940dbe0 	ldr	w0, [sp, #216]
    1458:	35ffefc0 	cbnz	w0, 1250 <main+0x4b8>
      response->status = check_database(db);
    145c:	910243e0 	add	x0, sp, #0x90
    1460:	94000795 	bl	32b4 <check_database>
    1464:	17ffffc7 	b	1380 <main+0x5e8>
    started++;
    1468:	110006b5 	add	w21, w21, #0x1
    ipc->slots[i].worker_pid = pid;
    146c:	b9000320 	str	w0, [x25]
  for(uint i = 0; i < workers; i++){
    1470:	910a0339 	add	x25, x25, #0x280
    1474:	6b1402bf 	cmp	w21, w20
    1478:	54ffe9c1 	b.ne	11b0 <main+0x418>  // b.any
  pgwire_pid = fork();
    147c:	97fffdff 	bl	c78 <fork@plt>
    1480:	2a0003f7 	mov	w23, w0
  if(pgwire_pid == 0)
    1484:	35000860 	cbnz	w0, 1590 <main+0x7f8>
  int listener = socket_listen(5432, 8);
    1488:	52800101 	mov	w1, #0x8                   	// #8
    148c:	5282a700 	mov	w0, #0x1538                	// #5432
    1490:	97fffe02 	bl	c98 <socket_listen@plt>
    1494:	2a0003f3 	mov	w19, w0
  if(listener < 0){
    1498:	36f80320 	tbz	w0, #31, 14fc <main+0x764>
    printf("mygres: cannot listen on PostgreSQL port 5432\n");
    149c:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    14a0:	911be000 	add	x0, x0, #0x6f8
    14a4:	17fffeba 	b	f8c <main+0x1f4>
  if(started != (int)workers){
    14a8:	d2800019 	mov	x25, #0x0                   	// #0
    14ac:	6b15029f 	cmp	w20, w21
    14b0:	54fffe60 	b.eq	147c <main+0x6e4>  // b.none
      if(ipc->slots[i].worker_pid)
    14b4:	52805014 	mov	w20, #0x280                 	// #640
    for(int i = 0; i < started; i++)
    14b8:	6b1902bf 	cmp	w21, w25
    14bc:	540000cc 	b.gt	14d4 <main+0x73c>
    for(int i = 0; i < started; i++)
    14c0:	6b1502ff 	cmp	w23, w21
    14c4:	54000141 	b.ne	14ec <main+0x754>  // b.any
  destroy_ipc_state(ipc);
    14c8:	aa1303e0 	mov	x0, x19
    14cc:	94000618 	bl	2d2c <destroy_ipc_state>
    14d0:	17fffef1 	b	1094 <main+0x2fc>
      if(ipc->slots[i].worker_pid)
    14d4:	9bb47f20 	umull	x0, w25, w20
    14d8:	b8606b00 	ldr	w0, [x24, x0]
    14dc:	34000040 	cbz	w0, 14e4 <main+0x74c>
        kill(ipc->slots[i].worker_pid);
    14e0:	97fffdd2 	bl	c28 <kill@plt>
    for(int i = 0; i < started; i++)
    14e4:	91000739 	add	x25, x25, #0x1
    14e8:	17fffff4 	b	14b8 <main+0x720>
      wait(0);
    14ec:	d2800000 	mov	x0, #0x0                   	// #0
    for(int i = 0; i < started; i++)
    14f0:	110006f7 	add	w23, w23, #0x1
      wait(0);
    14f4:	97fffdd1 	bl	c38 <wait@plt>
    for(int i = 0; i < started; i++)
    14f8:	17fffff2 	b	14c0 <main+0x728>
      printf("mygres: cannot fork remote backend\n");
    14fc:	90000035 	adrp	x21, 5000 <pgwire_connection+0xba0>
    1500:	911d72b5 	add	x21, x21, #0x75c
  printf("mygres: pgwire listener pid=%d port=5432 auth=trust\n", getpid());
    1504:	97fffdad 	bl	bb8 <getpid@plt>
    1508:	2a0003e1 	mov	w1, w0
    150c:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1510:	911c9c00 	add	x0, x0, #0x727
    1514:	97fffd95 	bl	b68 <printf@plt>
    int connection = socket_accept(listener);
    1518:	2a1303e0 	mov	w0, w19
    151c:	97fffd8f 	bl	b58 <socket_accept@plt>
    1520:	2a0003f4 	mov	w20, w0
    if(connection < 0)
    1524:	37f80300 	tbnz	w0, #31, 1584 <main+0x7ec>
    int pid = fork();
    1528:	97fffdd4 	bl	c78 <fork@plt>
    152c:	2a0003f6 	mov	w22, w0
    if(pid == 0){
    1530:	35000120 	cbnz	w0, 1554 <main+0x7bc>
      close(listener);
    1534:	2a1303e0 	mov	w0, w19
    1538:	97fffe0c 	bl	d68 <close@plt>
      pgwire_connection(connection, db);
    153c:	910243e1 	add	x1, sp, #0x90
    1540:	2a1403e0 	mov	w0, w20
    1544:	94000bc7 	bl	4460 <pgwire_connection>
      close(connection);
    1548:	2a1403e0 	mov	w0, w20
    154c:	97fffe07 	bl	d68 <close@plt>
    1550:	17ffff5b 	b	12bc <main+0x524>
    close(connection);
    1554:	2a1403e0 	mov	w0, w20
    1558:	97fffe04 	bl	d68 <close@plt>
    if(pid < 0)
    155c:	36f80076 	tbz	w22, #31, 1568 <main+0x7d0>
      printf("mygres: cannot fork remote backend\n");
    1560:	aa1503e0 	mov	x0, x21
    1564:	97fffd81 	bl	b68 <printf@plt>
    while(waitpid(-1, 0, 1) > 0)
    1568:	52800022 	mov	w2, #0x1                   	// #1
    156c:	d2800001 	mov	x1, #0x0                   	// #0
    1570:	12800000 	mov	w0, #0xffffffff            	// #-1
    1574:	97fffd75 	bl	b48 <waitpid@plt>
    1578:	7100001f 	cmp	w0, #0x0
    157c:	54ffff6c 	b.gt	1568 <main+0x7d0>
    1580:	17ffffe6 	b	1518 <main+0x780>
  close(listener);
    1584:	2a1303e0 	mov	w0, w19
    1588:	97fffdf8 	bl	d68 <close@plt>
  exit(1);
    158c:	17fffe0d 	b	dc0 <main+0x28>
  if(pgwire_pid < 0){
    1590:	36f801a0 	tbz	w0, #31, 15c4 <main+0x82c>
    1594:	d2800015 	mov	x21, #0x0                   	// #0
      kill(ipc->slots[i].worker_pid);
    1598:	52805016 	mov	w22, #0x280                 	// #640
    159c:	9bb67ea0 	umull	x0, w21, w22
    for(uint i = 0; i < workers; i++)
    15a0:	910006b5 	add	x21, x21, #0x1
      kill(ipc->slots[i].worker_pid);
    15a4:	b8606b00 	ldr	w0, [x24, x0]
    15a8:	97fffda0 	bl	c28 <kill@plt>
    for(uint i = 0; i < workers; i++)
    15ac:	6b15029f 	cmp	w20, w21
    15b0:	54ffff68 	b.hi	159c <main+0x804>  // b.pmore
    while(wait(0) >= 0)
    15b4:	d2800000 	mov	x0, #0x0                   	// #0
    15b8:	97fffda0 	bl	c38 <wait@plt>
    15bc:	36ffffc0 	tbz	w0, #31, 15b4 <main+0x81c>
    15c0:	17ffffc2 	b	14c8 <main+0x730>
  atomic_publish(&ipc->ready, 1);
    15c4:	91002275 	add	x21, x19, #0x8
  asm volatile("stlr %w0, [%1]" :: "r"(value), "r"(word) : "memory");
    15c8:	52800020 	mov	w0, #0x1                   	// #1
    15cc:	889ffea0 	stlr	w0, [x21]
  printf("mygres: postmaster pid=%d anonymous-shared=%l bytes workers=%d\n",
    15d0:	97fffd7a 	bl	bb8 <getpid@plt>
    15d4:	2a0003e1 	mov	w1, w0
    15d8:	f9404fe2 	ldr	x2, [sp, #152]
    15dc:	2a1403e3 	mov	w3, w20
    15e0:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    15e4:	911e0000 	add	x0, x0, #0x780
    15e8:	97fffd60 	bl	b68 <printf@plt>
  printf("mygres: clients rendezvous through %s\n", IPC_PATH);
    15ec:	aa1603e1 	mov	x1, x22
    15f0:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    15f4:	911f0000 	add	x0, x0, #0x7c0
    15f8:	97fffd5c 	bl	b68 <printf@plt>
  printf("mygres: PostgreSQL wire protocol listening on TCP 5432\n");
    15fc:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1600:	911f9c00 	add	x0, x0, #0x7e7
    1604:	97fffd59 	bl	b68 <printf@plt>
  wait(0);
    1608:	d2800000 	mov	x0, #0x0                   	// #0
    160c:	97fffd8b 	bl	c38 <wait@plt>
  asm volatile("stlr %w0, [%1]" :: "r"(value), "r"(word) : "memory");
    1610:	52800000 	mov	w0, #0x0                   	// #0
    1614:	889ffea0 	stlr	w0, [x21]
    1618:	d2800015 	mov	x21, #0x0                   	// #0
    if(ipc->slots[i].worker_pid)
    161c:	52805016 	mov	w22, #0x280                 	// #640
    1620:	9bb67ea0 	umull	x0, w21, w22
    1624:	b8606b00 	ldr	w0, [x24, x0]
    1628:	34000040 	cbz	w0, 1630 <main+0x898>
      kill(ipc->slots[i].worker_pid);
    162c:	97fffd7f 	bl	c28 <kill@plt>
  for(uint i = 0; i < workers; i++)
    1630:	910006b5 	add	x21, x21, #0x1
    1634:	6b15029f 	cmp	w20, w21
    1638:	54ffff48 	b.hi	1620 <main+0x888>  // b.pmore
    kill(pgwire_pid);
    163c:	2a1703e0 	mov	w0, w23
    1640:	97fffd7a 	bl	c28 <kill@plt>
  while(wait(0) >= 0)
    1644:	d2800000 	mov	x0, #0x0                   	// #0
    1648:	97fffd7c 	bl	c38 <wait@plt>
    164c:	36ffffc0 	tbz	w0, #31, 1644 <main+0x8ac>
    1650:	17ffff9e 	b	14c8 <main+0x730>
  memset(client, 0, sizeof(*client));
    1654:	52800302 	mov	w2, #0x18                  	// #24
    1658:	52800001 	mov	w1, #0x0                   	// #0
    165c:	910163e0 	add	x0, sp, #0x58
    1660:	97fffd8a 	bl	c88 <memset@plt>
  fd = open(IPC_PATH, O_RDWR);
    1664:	aa1603e0 	mov	x0, x22
  client->bytes = PAGE_SIZE;
    1668:	d2820017 	mov	x23, #0x1000                	// #4096
  fd = open(IPC_PATH, O_RDWR);
    166c:	52800041 	mov	w1, #0x2                   	// #2
  client->bytes = PAGE_SIZE;
    1670:	f90033f7 	str	x23, [sp, #96]
  fd = open(IPC_PATH, O_RDWR);
    1674:	97fffda9 	bl	d18 <open@plt>
    1678:	2a0003f3 	mov	w19, w0
  if(fd < 0){
    167c:	36f80080 	tbz	w0, #31, 168c <main+0x8f4>
    printf("mygres: server is not running; start /bin/mygresd\n");
    1680:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1684:	91207c00 	add	x0, x0, #0x81f
    1688:	17fffe41 	b	f8c <main+0x1f4>
  client->state = mmap(0, PAGE_SIZE, PROT_READ | PROT_WRITE,
    168c:	2a0003e4 	mov	w4, w0
    1690:	aa1703e1 	mov	x1, x23
    1694:	d2800005 	mov	x5, #0x0                   	// #0
    1698:	52800023 	mov	w3, #0x1                   	// #1
    169c:	52800062 	mov	w2, #0x3                   	// #3
    16a0:	d2800000 	mov	x0, #0x0                   	// #0
    16a4:	97fffd55 	bl	bf8 <mmap@plt>
    16a8:	f9002fe0 	str	x0, [sp, #88]
  close(fd);
    16ac:	2a1303e0 	mov	w0, w19
    16b0:	97fffdae 	bl	d68 <close@plt>
  if(client->state == MAP_FAILED){
    16b4:	f9402fe0 	ldr	x0, [sp, #88]
    16b8:	b100041f 	cmn	x0, #0x1
    16bc:	54000061 	b.ne	16c8 <main+0x930>  // b.any
    client->state = 0;
    16c0:	f9002fff 	str	xzr, [sp, #88]
    return -1;
    16c4:	17fffdbf 	b	dc0 <main+0x28>
  if(client->state->magic != IPC_MAGIC ||
    16c8:	b9400002 	ldr	w2, [x0]
    16cc:	52892a01 	mov	w1, #0x4950                	// #18768
    16d0:	72a9ab21 	movk	w1, #0x4d59, lsl #16
    16d4:	6b01005f 	cmp	w2, w1
    16d8:	54000141 	b.ne	1700 <main+0x968>  // b.any
    16dc:	b9400401 	ldr	w1, [x0, #4]
    16e0:	7100043f 	cmp	w1, #0x1
    16e4:	540000e1 	b.ne	1700 <main+0x968>  // b.any
     client->state->version != DB_VERSION || !client->state->ready ||
    16e8:	b9400801 	ldr	w1, [x0, #8]
    16ec:	340000a1 	cbz	w1, 1700 <main+0x968>
    16f0:	b9401401 	ldr	w1, [x0, #20]
    16f4:	51000421 	sub	w1, w1, #0x1
    16f8:	71000c3f 	cmp	w1, #0x3
    16fc:	540000e9 	b.ls	1718 <main+0x980>  // b.plast
    munmap(client->state, PAGE_SIZE);
    1700:	d2820001 	mov	x1, #0x1000                	// #4096
    1704:	97fffd25 	bl	b98 <munmap@plt>
    printf("mygres: stale IPC page; restart /bin/mygresd\n");
    1708:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    170c:	91214800 	add	x0, x0, #0x852
    client->state = 0;
    1710:	f9002fff 	str	xzr, [sp, #88]
    printf("mygres: stale IPC page; restart /bin/mygresd\n");
    1714:	17fffe1e 	b	f8c <main+0x1f4>
  client->next_request = ((uint64)(uint32)getpid()) << 32;
    1718:	97fffd28 	bl	bb8 <getpid@plt>
    171c:	d3607c00 	lsl	x0, x0, #32
    1720:	f90037e0 	str	x0, [sp, #104]

  int r = -1;
  struct ipc_response response;
  if(strcmp(argv[1], "status") == 0){
    1724:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1728:	91220021 	add	x1, x1, #0x880
    172c:	f9400680 	ldr	x0, [x20, #8]
    1730:	97fffd5e 	bl	ca8 <strcmp@plt>
    1734:	34000500 	cbz	w0, 17d4 <main+0xa3c>
    r = submit_simple(&client, IPC_PING, &response);
    if(r == 0)
      printf("mygres: postmaster pid=%d workers=%d ready\n",
             client.state->postmaster_pid, client.state->nworkers);
  } else if(strcmp(argv[1], "shell") == 0)
    1738:	f9400680 	ldr	x0, [x20, #8]
    173c:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1740:	9122cc21 	add	x1, x1, #0x8b3
    1744:	97fffd59 	bl	ca8 <strcmp@plt>
    1748:	2a0003f3 	mov	w19, w0
    174c:	35003480 	cbnz	w0, 1ddc <main+0x1044>
  memset(&tx, 0, sizeof(tx));
    1750:	52804202 	mov	w2, #0x210                 	// #528
    1754:	52800001 	mov	w1, #0x0                   	// #0
    1758:	9105e3f5 	add	x21, sp, #0x178
    printf(tx.active ? "mygres=*# " : "mygres=# ");
    175c:	90000036 	adrp	x22, 5000 <pgwire_connection+0xba0>
    1760:	9117ded6 	add	x22, x22, #0x5f7
    1764:	90000037 	adrp	x23, 5000 <pgwire_connection+0xba0>
    1768:	91180af7 	add	x23, x23, #0x602
    176c:	d284c018 	mov	x24, #0x2600                	// #9728
  memset(&tx, 0, sizeof(tx));
    1770:	aa1503e0 	mov	x0, x21
    1774:	f2c00038 	movk	x24, #0x1, lsl #32
    1778:	97fffd44 	bl	c88 <memset@plt>
  printf("mygres shell: PostgreSQL-style read-committed transactions\n");
    177c:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1780:	9122e400 	add	x0, x0, #0x8b9
    1784:	97fffcf9 	bl	b68 <printf@plt>
  shell_help();
    1788:	940002e9 	bl	232c <shell_help>
    printf(tx.active ? "mygres=*# " : "mygres=# ");
    178c:	b9417be0 	ldr	w0, [sp, #376]
    1790:	7100001f 	cmp	w0, #0x0
    1794:	9a9602e0 	csel	x0, x23, x22, eq	// eq = none
    1798:	97fffcf4 	bl	b68 <printf@plt>
    if(gets(line, sizeof(line)) == 0)
    179c:	910363e0 	add	x0, sp, #0xd8
    17a0:	52801401 	mov	w1, #0xa0                  	// #160
    17a4:	97fffd01 	bl	ba8 <gets@plt>
    17a8:	b40002c0 	cbz	x0, 1800 <main+0xa68>
  char *p = line;
    17ac:	910363e0 	add	x0, sp, #0xd8
    words[n++] = p;
    17b0:	9101c3e3 	add	x3, sp, #0x70
    if(gets(line, sizeof(line)) == 0)
    17b4:	d2800001 	mov	x1, #0x0                   	// #0
  while(*p && n < max){
    17b8:	39400002 	ldrb	w2, [x0]
    17bc:	340005a2 	cbz	w2, 1870 <main+0xad8>
    17c0:	f100103f 	cmp	x1, #0x4
    17c4:	540002e1 	b.ne	1820 <main+0xa88>  // b.any
    *p = 0;
    17c8:	2a0103f9 	mov	w25, w1
    17cc:	3900001f 	strb	wzr, [x0]
    if(n == 0)
    17d0:	1400002a 	b	1878 <main+0xae0>
    r = submit_simple(&client, IPC_PING, &response);
    17d4:	910e23e2 	add	x2, sp, #0x388
    17d8:	910163e0 	add	x0, sp, #0x58
    17dc:	52800021 	mov	w1, #0x1                   	// #1
    17e0:	9400063e 	bl	30d8 <submit_simple>
    17e4:	2a0003f3 	mov	w19, w0
    if(r == 0)
    17e8:	350000c0 	cbnz	w0, 1800 <main+0xa68>
             client.state->postmaster_pid, client.state->nworkers);
    17ec:	f9402fe1 	ldr	x1, [sp, #88]
      printf("mygres: postmaster pid=%d workers=%d ready\n",
    17f0:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    17f4:	91221c00 	add	x0, x0, #0x887
    17f8:	29420821 	ldp	w1, w2, [x1, #16]
    17fc:	97fffcdb 	bl	b68 <printf@plt>
  if(client->state){
    1800:	f9402fe0 	ldr	x0, [sp, #88]
    1804:	b4000080 	cbz	x0, 1814 <main+0xa7c>
    munmap(client->state, client->bytes);
    1808:	f94033e1 	ldr	x1, [sp, #96]
    180c:	97fffce3 	bl	b98 <munmap@plt>
    client->state = 0;
    1810:	f9002fff 	str	xzr, [sp, #88]
  } else {
    usage();
  }

  ipc_client_detach(&client);
  exit(r < 0);
    1814:	531f7e60 	lsr	w0, w19, #31
    1818:	17fffda3 	b	ea4 <main+0x10c>
      *p++ = 0;
    181c:	3800141f 	strb	wzr, [x0], #1
    while(*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')
    1820:	39400002 	ldrb	w2, [x0]
    1824:	7100805f 	cmp	w2, #0x20
    1828:	54000088 	b.hi	1838 <main+0xaa0>  // b.pmore
    182c:	9ac22704 	lsr	x4, x24, x2
    1830:	3707ff64 	tbnz	w4, #0, 181c <main+0xa84>
    if(!*p)
    1834:	340001e2 	cbz	w2, 1870 <main+0xad8>
    words[n++] = p;
    1838:	f8217860 	str	x0, [x3, x1, lsl #3]
    while(*p && *p != ' ' && *p != '\t' && *p != '\r' && *p != '\n')
    183c:	39400002 	ldrb	w2, [x0]
    1840:	121a7844 	and	w4, w2, #0xffffffdf
    1844:	340000a4 	cbz	w4, 1858 <main+0xac0>
    1848:	7100285f 	cmp	w2, #0xa
    184c:	540000a8 	b.hi	1860 <main+0xac8>  // b.pmore
    1850:	7100205f 	cmp	w2, #0x8
    1854:	540000a9 	b.ls	1868 <main+0xad0>  // b.plast
    1858:	91000421 	add	x1, x1, #0x1
    185c:	17ffffd7 	b	17b8 <main+0xa20>
    1860:	7100345f 	cmp	w2, #0xd
    1864:	54ffffa0 	b.eq	1858 <main+0xac0>  // b.none
      p++;
    1868:	91000400 	add	x0, x0, #0x1
    186c:	17fffff4 	b	183c <main+0xaa4>
    1870:	2a0103f9 	mov	w25, w1
    if(n == 0)
    1874:	34fff8c1 	cbz	w1, 178c <main+0x9f4>
    if(strcmp(word[0], "BEGIN") == 0 || strcmp(word[0], "begin") == 0){
    1878:	f9403bf4 	ldr	x20, [sp, #112]
    187c:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1880:	91081c21 	add	x1, x1, #0x207
    1884:	aa1403e0 	mov	x0, x20
    1888:	97fffd08 	bl	ca8 <strcmp@plt>
    188c:	340000c0 	cbz	w0, 18a4 <main+0xb0c>
    1890:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1894:	91073821 	add	x1, x1, #0x1ce
    1898:	aa1403e0 	mov	x0, x20
    189c:	97fffd03 	bl	ca8 <strcmp@plt>
    18a0:	35000200 	cbnz	w0, 18e0 <main+0xb48>
      if(tx.active)
    18a4:	b9417be0 	ldr	w0, [sp, #376]
    18a8:	340000a0 	cbz	w0, 18bc <main+0xb24>
        printf("ERROR: transaction already active\n");
    18ac:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    18b0:	9123d400 	add	x0, x0, #0x8f5
        printf("BEGIN\n");
    18b4:	97fffcad 	bl	b68 <printf@plt>
    18b8:	17ffffb5 	b	178c <main+0x9f4>
        memset(&tx, 0, sizeof(tx));
    18bc:	aa1503e0 	mov	x0, x21
    18c0:	52804202 	mov	w2, #0x210                 	// #528
    18c4:	52800001 	mov	w1, #0x0                   	// #0
    18c8:	97fffcf0 	bl	c88 <memset@plt>
        tx.active = 1;
    18cc:	52800020 	mov	w0, #0x1                   	// #1
    18d0:	b9017be0 	str	w0, [sp, #376]
        printf("BEGIN\n");
    18d4:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    18d8:	91246000 	add	x0, x0, #0x918
    18dc:	17fffff6 	b	18b4 <main+0xb1c>
    } else if(strcmp(word[0], "COMMIT") == 0 || strcmp(word[0], "commit") == 0){
    18e0:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    18e4:	9108a021 	add	x1, x1, #0x228
    18e8:	aa1403e0 	mov	x0, x20
    18ec:	97fffcef 	bl	ca8 <strcmp@plt>
    18f0:	340000c0 	cbz	w0, 1908 <main+0xb70>
    18f4:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    18f8:	91083421 	add	x1, x1, #0x20d
    18fc:	aa1403e0 	mov	x0, x20
    1900:	97fffcea 	bl	ca8 <strcmp@plt>
    1904:	350004e0 	cbnz	w0, 19a0 <main+0xc08>
      if(!tx.active)
    1908:	b9417be0 	ldr	w0, [sp, #376]
    190c:	35000080 	cbnz	w0, 191c <main+0xb84>
        printf("ERROR: no active transaction\n");
    1910:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1914:	91247c00 	add	x0, x0, #0x91f
    1918:	17ffffe7 	b	18b4 <main+0xb1c>
  memset(&request, 0, sizeof(request));
    191c:	52804302 	mov	w2, #0x218                 	// #536
    1920:	52800001 	mov	w1, #0x0                   	// #0
    1924:	910e23e0 	add	x0, sp, #0x388
    1928:	97fffcd8 	bl	c88 <memset@plt>
  request.command = wal_only ? IPC_PREPARE : IPC_COMMIT;
    192c:	52800060 	mov	w0, #0x3                   	// #3
  request.nops = tx->nops;
    1930:	b9417fe2 	ldr	w2, [sp, #380]
    1934:	aa1503e3 	mov	x3, x21
    1938:	910e23e1 	add	x1, sp, #0x388
  request.command = wal_only ? IPC_PREPARE : IPC_COMMIT;
    193c:	b9038be0 	str	w0, [sp, #904]
  for(uint i = 0; i < tx->nops; i++)
    1940:	52800000 	mov	w0, #0x0                   	// #0
  request.nops = tx->nops;
    1944:	b9038fe2 	str	w2, [sp, #908]
  for(uint i = 0; i < tx->nops; i++)
    1948:	6b00005f 	cmp	w2, w0
    194c:	540001a1 	b.ne	1980 <main+0xbe8>  // b.any
  if(ipc_submit(client, &request, response) < 0)
    1950:	910243e2 	add	x2, sp, #0x90
    1954:	910e23e1 	add	x1, sp, #0x388
    1958:	910163e0 	add	x0, sp, #0x58
    195c:	94000578 	bl	2f3c <ipc_submit>
    1960:	3100041f 	cmn	w0, #0x1
    1964:	54000180 	b.eq	1994 <main+0xbfc>  // b.none
  return response->status;
    1968:	b94093e0 	ldr	w0, [sp, #144]
  tx->active = 0;
    196c:	b9017bff 	str	wzr, [sp, #376]
        if(submit_transaction(client, &tx, 0, &response) == 0)
    1970:	35000120 	cbnz	w0, 1994 <main+0xbfc>
        printf("COMMIT\n");
    1974:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1978:	9124f400 	add	x0, x0, #0x93d
    197c:	17ffffce 	b	18b4 <main+0xb1c>
  for(uint i = 0; i < tx->nops; i++)
    1980:	91004021 	add	x1, x1, #0x10
    1984:	11000400 	add	w0, w0, #0x1
    request.ops[i] = tx->ops[i];
    1988:	a9c11464 	ldp	x4, x5, [x3, #16]!
    198c:	a9009424 	stp	x4, x5, [x1, #8]
  for(uint i = 0; i < tx->nops; i++)
    1990:	17ffffee 	b	1948 <main+0xbb0>
          printf("ERROR: commit failed\n");
    1994:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1998:	91251400 	add	x0, x0, #0x945
    199c:	17ffffc6 	b	18b4 <main+0xb1c>
    } else if(strcmp(word[0], "ROLLBACK") == 0 || strcmp(word[0], "rollback") == 0){
    19a0:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    19a4:	9108e021 	add	x1, x1, #0x238
    19a8:	aa1403e0 	mov	x0, x20
    19ac:	97fffcbf 	bl	ca8 <strcmp@plt>
    19b0:	340000c0 	cbz	w0, 19c8 <main+0xc30>
    19b4:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    19b8:	9108bc21 	add	x1, x1, #0x22f
    19bc:	aa1403e0 	mov	x0, x20
    19c0:	97fffcba 	bl	ca8 <strcmp@plt>
    19c4:	35000140 	cbnz	w0, 19ec <main+0xc54>
      if(!tx.active)
    19c8:	b9417be0 	ldr	w0, [sp, #376]
    19cc:	34fffa20 	cbz	w0, 1910 <main+0xb78>
        memset(&tx, 0, sizeof(tx));
    19d0:	aa1503e0 	mov	x0, x21
    19d4:	52804202 	mov	w2, #0x210                 	// #528
    19d8:	52800001 	mov	w1, #0x0                   	// #0
    19dc:	97fffcab 	bl	c88 <memset@plt>
        printf("ROLLBACK\n");
    19e0:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    19e4:	91256c00 	add	x0, x0, #0x95b
    19e8:	17ffffb3 	b	18b4 <main+0xb1c>
    } else if((strcmp(word[0], "PUT") == 0 || strcmp(word[0], "put") == 0) && n == 3){
    19ec:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    19f0:	91259421 	add	x1, x1, #0x965
    19f4:	aa1403e0 	mov	x0, x20
    19f8:	97fffcac 	bl	ca8 <strcmp@plt>
    19fc:	340000c0 	cbz	w0, 1a14 <main+0xc7c>
    1a00:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1a04:	9125a421 	add	x1, x1, #0x969
    1a08:	aa1403e0 	mov	x0, x20
    1a0c:	97fffca7 	bl	ca8 <strcmp@plt>
    1a10:	350005a0 	cbnz	w0, 1ac4 <main+0xd2c>
    1a14:	71000f3f 	cmp	w25, #0x3
    1a18:	54000561 	b.ne	1ac4 <main+0xd2c>  // b.any
      if(parse_u64(word[1], &key) < 0 || key > 0xffffffffU ||
    1a1c:	f9403fe0 	ldr	x0, [sp, #120]
    1a20:	910143e1 	add	x1, sp, #0x50
    1a24:	940004af 	bl	2ce0 <parse_u64>
    1a28:	3100041f 	cmn	w0, #0x1
    1a2c:	54000140 	b.eq	1a54 <main+0xcbc>  // b.none
    1a30:	f9402be6 	ldr	x6, [sp, #80]
    1a34:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    1a38:	eb0000df 	cmp	x6, x0
    1a3c:	540000c8 	b.hi	1a54 <main+0xcbc>  // b.pmore
         parse_u64(word[2], &value) < 0)
    1a40:	f94043e0 	ldr	x0, [sp, #128]
    1a44:	910243e1 	add	x1, sp, #0x90
    1a48:	940004a6 	bl	2ce0 <parse_u64>
      if(parse_u64(word[1], &key) < 0 || key > 0xffffffffU ||
    1a4c:	3100041f 	cmn	w0, #0x1
    1a50:	54000081 	b.ne	1a60 <main+0xcc8>  // b.any
        printf("ERROR: PUT expects an unsigned 32-bit key and integer value\n");
    1a54:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1a58:	9125b400 	add	x0, x0, #0x96d
    1a5c:	17ffff96 	b	18b4 <main+0xb1c>
      else if(tx.active){
    1a60:	b9417be0 	ldr	w0, [sp, #376]
        if(tx_stage(&tx, OP_PUT, key, value) < 0)
    1a64:	f9404be3 	ldr	x3, [sp, #144]
      else if(tx.active){
    1a68:	34000140 	cbz	w0, 1a90 <main+0xcf8>
        if(tx_stage(&tx, OP_PUT, key, value) < 0)
    1a6c:	2a0603e2 	mov	w2, w6
    1a70:	aa1503e0 	mov	x0, x21
    1a74:	52800021 	mov	w1, #0x1                   	// #1
    1a78:	94000495 	bl	2ccc <tx_stage>
    1a7c:	3100041f 	cmn	w0, #0x1
    1a80:	54000161 	b.ne	1aac <main+0xd14>  // b.any
          printf("ERROR: transaction has too many operations\n");
    1a84:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1a88:	9126a800 	add	x0, x0, #0x9aa
    1a8c:	17ffff8a 	b	18b4 <main+0xb1c>
        if(submit_one(client, OP_PUT, key, value, 0, &response) == 0)
    1a90:	910e23e5 	add	x5, sp, #0x388
    1a94:	2a0603e2 	mov	w2, w6
    1a98:	910163e0 	add	x0, sp, #0x58
    1a9c:	52800004 	mov	w4, #0x0                   	// #0
    1aa0:	52800021 	mov	w1, #0x1                   	// #1
    1aa4:	94000719 	bl	3708 <submit_one>
    1aa8:	35000080 	cbnz	w0, 1ab8 <main+0xd20>
          printf("PUT 1\n");
    1aac:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1ab0:	91275800 	add	x0, x0, #0x9d6
    1ab4:	17ffff80 	b	18b4 <main+0xb1c>
          printf("ERROR: PUT failed\n");
    1ab8:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1abc:	91277400 	add	x0, x0, #0x9dd
    1ac0:	17ffff7d 	b	18b4 <main+0xb1c>
    } else if((strcmp(word[0], "DELETE") == 0 || strcmp(word[0], "delete") == 0) && n == 2){
    1ac4:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1ac8:	9127c021 	add	x1, x1, #0x9f0
    1acc:	aa1403e0 	mov	x0, x20
    1ad0:	97fffc76 	bl	ca8 <strcmp@plt>
    1ad4:	340000c0 	cbz	w0, 1aec <main+0xd54>
    1ad8:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1adc:	910bf821 	add	x1, x1, #0x2fe
    1ae0:	aa1403e0 	mov	x0, x20
    1ae4:	97fffc71 	bl	ca8 <strcmp@plt>
    1ae8:	350004e0 	cbnz	w0, 1b84 <main+0xdec>
    1aec:	71000b3f 	cmp	w25, #0x2
    1af0:	540004a1 	b.ne	1b84 <main+0xdec>  // b.any
      if(parse_u64(word[1], &key) < 0 || key > 0xffffffffU)
    1af4:	f9403fe0 	ldr	x0, [sp, #120]
    1af8:	910243e1 	add	x1, sp, #0x90
    1afc:	94000479 	bl	2ce0 <parse_u64>
    1b00:	3100041f 	cmn	w0, #0x1
    1b04:	540000a0 	b.eq	1b18 <main+0xd80>  // b.none
    1b08:	f9404be2 	ldr	x2, [sp, #144]
    1b0c:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    1b10:	eb00005f 	cmp	x2, x0
    1b14:	54000089 	b.ls	1b24 <main+0xd8c>  // b.plast
        printf("ERROR: DELETE expects an unsigned 32-bit key\n");
    1b18:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1b1c:	9127dc00 	add	x0, x0, #0x9f7
    1b20:	17ffff65 	b	18b4 <main+0xb1c>
      else if(tx.active){
    1b24:	b9417be0 	ldr	w0, [sp, #376]
    1b28:	34000140 	cbz	w0, 1b50 <main+0xdb8>
        if(tx_stage(&tx, OP_DELETE, key, 0) < 0)
    1b2c:	2a1903e1 	mov	w1, w25
    1b30:	aa1503e0 	mov	x0, x21
    1b34:	d2800003 	mov	x3, #0x0                   	// #0
    1b38:	94000465 	bl	2ccc <tx_stage>
    1b3c:	3100041f 	cmn	w0, #0x1
    1b40:	54fffa20 	b.eq	1a84 <main+0xcec>  // b.none
          printf("DELETE staged\n");
    1b44:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1b48:	91289400 	add	x0, x0, #0xa25
    1b4c:	17ffff5a 	b	18b4 <main+0xb1c>
        if(submit_one(client, OP_DELETE, key, 0, 0, &response) == 0)
    1b50:	910e23e5 	add	x5, sp, #0x388
    1b54:	2a1903e1 	mov	w1, w25
    1b58:	910163e0 	add	x0, sp, #0x58
    1b5c:	52800004 	mov	w4, #0x0                   	// #0
    1b60:	d2800003 	mov	x3, #0x0                   	// #0
    1b64:	940006e9 	bl	3708 <submit_one>
    1b68:	35000080 	cbnz	w0, 1b78 <main+0xde0>
          printf("DELETE\n");
    1b6c:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1b70:	9128d000 	add	x0, x0, #0xa34
    1b74:	17ffff50 	b	18b4 <main+0xb1c>
          printf("ERROR: DELETE failed\n");
    1b78:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1b7c:	9128f000 	add	x0, x0, #0xa3c
    1b80:	17ffff4d 	b	18b4 <main+0xb1c>
    } else if((strcmp(word[0], "GET") == 0 || strcmp(word[0], "get") == 0) && n == 2){
    1b84:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1b88:	91294821 	add	x1, x1, #0xa52
    1b8c:	aa1403e0 	mov	x0, x20
    1b90:	97fffc46 	bl	ca8 <strcmp@plt>
    1b94:	340000c0 	cbz	w0, 1bac <main+0xe14>
    1b98:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1b9c:	91295821 	add	x1, x1, #0xa56
    1ba0:	aa1403e0 	mov	x0, x20
    1ba4:	97fffc41 	bl	ca8 <strcmp@plt>
    1ba8:	35000640 	cbnz	w0, 1c70 <main+0xed8>
    1bac:	71000b3f 	cmp	w25, #0x2
    1bb0:	54000601 	b.ne	1c70 <main+0xed8>  // b.any
      if(parse_u64(word[1], &key) < 0 || key > 0xffffffffU)
    1bb4:	f9403fe0 	ldr	x0, [sp, #120]
    1bb8:	910243e1 	add	x1, sp, #0x90
    1bbc:	94000449 	bl	2ce0 <parse_u64>
    1bc0:	3100041f 	cmn	w0, #0x1
    1bc4:	540000a0 	b.eq	1bd8 <main+0xe40>  // b.none
    1bc8:	f9404bf4 	ldr	x20, [sp, #144]
    1bcc:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    1bd0:	eb00029f 	cmp	x20, x0
    1bd4:	54000089 	b.ls	1be4 <main+0xe4c>  // b.plast
        printf("ERROR: GET expects an unsigned 32-bit key\n");
    1bd8:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1bdc:	91296800 	add	x0, x0, #0xa5a
    1be0:	17ffff35 	b	18b4 <main+0xb1c>
        if(tx.active)
    1be4:	b9417be0 	ldr	w0, [sp, #376]
    1be8:	340000a0 	cbz	w0, 1bfc <main+0xe64>
          for(int i = (int)tx.nops - 1; i >= 0; i--)
    1bec:	b9417fe0 	ldr	w0, [sp, #380]
    1bf0:	51000400 	sub	w0, w0, #0x1
    1bf4:	93407c00 	sxtw	x0, w0
    1bf8:	36f80160 	tbz	w0, #31, 1c24 <main+0xe8c>
          r = submit_get(client, key, &response);
    1bfc:	910e23e2 	add	x2, sp, #0x388
    1c00:	2a1403e1 	mov	w1, w20
    1c04:	910163e0 	add	x0, sp, #0x58
    1c08:	94000518 	bl	3068 <submit_get>
          value = response.value;
    1c0c:	f941cbe2 	ldr	x2, [sp, #912]
          xmin = response.row_txid;
    1c10:	f941d3e3 	ldr	x3, [sp, #928]
        if(r == 0)
    1c14:	34000200 	cbz	w0, 1c54 <main+0xebc>
          printf("(0 rows)\n");
    1c18:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1c1c:	912ac000 	add	x0, x0, #0xab0
    1c20:	17ffff25 	b	18b4 <main+0xb1c>
            if(tx.ops[i].key == key){
    1c24:	8b0012a1 	add	x1, x21, x0, lsl #4
    1c28:	b9401421 	ldr	w1, [x1, #20]
    1c2c:	eb01029f 	cmp	x20, x1
    1c30:	540001c1 	b.ne	1c68 <main+0xed0>  // b.any
              r = tx.ops[i].type == OP_DELETE ? 1 : 0;
    1c34:	d37c7c00 	ubfiz	x0, x0, #4, #32
    1c38:	91004000 	add	x0, x0, #0x10
        if(r == 0)
    1c3c:	b8606aa1 	ldr	w1, [x21, x0]
    1c40:	7100083f 	cmp	w1, #0x2
    1c44:	54fffea0 	b.eq	1c18 <main+0xe80>  // b.none
              value = tx.ops[i].value;
    1c48:	910603e1 	add	x1, sp, #0x180
              xmin = 0;       // uncommitted row has no server txid yet
    1c4c:	d2800003 	mov	x3, #0x0                   	// #0
              value = tx.ops[i].value;
    1c50:	f8606822 	ldr	x2, [x1, x0]
          printf(" key | value | xmin\n %d | %l | %l\n(1 row)\n",
    1c54:	2a1403e1 	mov	w1, w20
    1c58:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1c5c:	912a1400 	add	x0, x0, #0xa85
    1c60:	97fffbc2 	bl	b68 <printf@plt>
    1c64:	17fffeca 	b	178c <main+0x9f4>
            if(tx.ops[i].key == key){
    1c68:	d1000400 	sub	x0, x0, #0x1
    1c6c:	17ffffe3 	b	1bf8 <main+0xe60>
    } else if(strcmp(word[0], "SCAN") == 0 || strcmp(word[0], "scan") == 0){
    1c70:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1c74:	912ae821 	add	x1, x1, #0xaba
    1c78:	aa1403e0 	mov	x0, x20
    1c7c:	97fffc0b 	bl	ca8 <strcmp@plt>
    1c80:	340000c0 	cbz	w0, 1c98 <main+0xf00>
    1c84:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1c88:	912afc21 	add	x1, x1, #0xabf
    1c8c:	aa1403e0 	mov	x0, x20
    1c90:	97fffc06 	bl	ca8 <strcmp@plt>
    1c94:	350000c0 	cbnz	w0, 1cac <main+0xf14>
      submit_simple(client, IPC_SCAN, &response);
    1c98:	910e23e2 	add	x2, sp, #0x388
    1c9c:	52800081 	mov	w1, #0x4                   	// #4
      submit_simple(client, IPC_CHECK, &response);
    1ca0:	910163e0 	add	x0, sp, #0x58
    1ca4:	9400050d 	bl	30d8 <submit_simple>
    } else if(strcmp(word[0], "CHECK") == 0 || strcmp(word[0], "check") == 0){
    1ca8:	17fffeb9 	b	178c <main+0x9f4>
    1cac:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1cb0:	912b1021 	add	x1, x1, #0xac4
    1cb4:	aa1403e0 	mov	x0, x20
    1cb8:	97fffbfc 	bl	ca8 <strcmp@plt>
    1cbc:	340000c0 	cbz	w0, 1cd4 <main+0xf3c>
    1cc0:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1cc4:	912b2821 	add	x1, x1, #0xaca
    1cc8:	aa1403e0 	mov	x0, x20
    1ccc:	97fffbf7 	bl	ca8 <strcmp@plt>
    1cd0:	35000080 	cbnz	w0, 1ce0 <main+0xf48>
      submit_simple(client, IPC_CHECK, &response);
    1cd4:	910e23e2 	add	x2, sp, #0x388
    1cd8:	528000a1 	mov	w1, #0x5                   	// #5
    1cdc:	17fffff1 	b	1ca0 <main+0xf08>
    } else if(strcmp(word[0], "STATS") == 0 || strcmp(word[0], "stats") == 0){
    1ce0:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1ce4:	912b4021 	add	x1, x1, #0xad0
    1ce8:	aa1403e0 	mov	x0, x20
    1cec:	97fffbef 	bl	ca8 <strcmp@plt>
    1cf0:	340000c0 	cbz	w0, 1d08 <main+0xf70>
    1cf4:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1cf8:	912b5821 	add	x1, x1, #0xad6
    1cfc:	aa1403e0 	mov	x0, x20
    1d00:	97fffbea 	bl	ca8 <strcmp@plt>
    1d04:	35000240 	cbnz	w0, 1d4c <main+0xfb4>
      if(submit_simple(client, IPC_STATS, &response) < 0){
    1d08:	910e23e2 	add	x2, sp, #0x388
    1d0c:	910163e0 	add	x0, sp, #0x58
    1d10:	528000c1 	mov	w1, #0x6                   	// #6
    1d14:	940004f1 	bl	30d8 <submit_simple>
    1d18:	36f80080 	tbz	w0, #31, 1d28 <main+0xf90>
        printf("ERROR: STATS failed\n");
    1d1c:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1d20:	912b7000 	add	x0, x0, #0xadc
    1d24:	17fffee4 	b	18b4 <main+0xb1c>
      printf("txid=%l rows=%l commits=%l recoveries=%l index-hit=%l miss=%l\n",
    1d28:	910ea3e7 	add	x7, sp, #0x3a8
    1d2c:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1d30:	912e7c00 	add	x0, x0, #0xb9f
    1d34:	f941cfe1 	ldr	x1, [sp, #920]
    1d38:	a9400ce2 	ldp	x2, x3, [x7]
    1d3c:	a94114e4 	ldp	x4, x5, [x7, #16]
    1d40:	f941e7e6 	ldr	x6, [sp, #968]
    1d44:	97fffb89 	bl	b68 <printf@plt>
    } else if(strcmp(word[0], "STATS") == 0 || strcmp(word[0], "stats") == 0){
    1d48:	17fffe91 	b	178c <main+0x9f4>
    } else if(strcmp(word[0], "HELP") == 0 || strcmp(word[0], "help") == 0){
    1d4c:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1d50:	912bc421 	add	x1, x1, #0xaf1
    1d54:	aa1403e0 	mov	x0, x20
    1d58:	97fffbd4 	bl	ca8 <strcmp@plt>
    1d5c:	340000c0 	cbz	w0, 1d74 <main+0xfdc>
    1d60:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1d64:	912bd821 	add	x1, x1, #0xaf6
    1d68:	aa1403e0 	mov	x0, x20
    1d6c:	97fffbcf 	bl	ca8 <strcmp@plt>
    1d70:	35000060 	cbnz	w0, 1d7c <main+0xfe4>
      shell_help();
    1d74:	9400016e 	bl	232c <shell_help>
    1d78:	17fffe85 	b	178c <main+0x9f4>
    } else if(strcmp(word[0], "QUIT") == 0 || strcmp(word[0], "quit") == 0 ||
    1d7c:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1d80:	912bec21 	add	x1, x1, #0xafb
    1d84:	aa1403e0 	mov	x0, x20
    1d88:	97fffbc8 	bl	ca8 <strcmp@plt>
    1d8c:	34000160 	cbz	w0, 1db8 <main+0x1020>
    1d90:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1d94:	912c0021 	add	x1, x1, #0xb00
    1d98:	aa1403e0 	mov	x0, x20
    1d9c:	97fffbc3 	bl	ca8 <strcmp@plt>
    1da0:	340000c0 	cbz	w0, 1db8 <main+0x1020>
              strcmp(word[0], "\\q") == 0){
    1da4:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1da8:	912c1421 	add	x1, x1, #0xb05
    1dac:	aa1403e0 	mov	x0, x20
    1db0:	97fffbbe 	bl	ca8 <strcmp@plt>
    } else if(strcmp(word[0], "QUIT") == 0 || strcmp(word[0], "quit") == 0 ||
    1db4:	350000e0 	cbnz	w0, 1dd0 <main+0x1038>
      if(tx.active)
    1db8:	b9417be0 	ldr	w0, [sp, #376]
    1dbc:	34ffd220 	cbz	w0, 1800 <main+0xa68>
        printf("ROLLBACK (shell closed with active transaction)\n");
    1dc0:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1dc4:	912c2000 	add	x0, x0, #0xb08
    1dc8:	97fffb68 	bl	b68 <printf@plt>
    1dcc:	17fffe8d 	b	1800 <main+0xa68>
      printf("ERROR: unknown command; type HELP\n");
    1dd0:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1dd4:	912ce400 	add	x0, x0, #0xb39
    1dd8:	17fffeb7 	b	18b4 <main+0xb1c>
  else if(strcmp(argv[1], "put") == 0 && argc == 4){
    1ddc:	f9400680 	ldr	x0, [x20, #8]
    1de0:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1de4:	9125a421 	add	x1, x1, #0x969
    1de8:	97fffbb0 	bl	ca8 <strcmp@plt>
    1dec:	35000340 	cbnz	w0, 1e54 <main+0x10bc>
    1df0:	710012bf 	cmp	w21, #0x4
    1df4:	54000301 	b.ne	1e54 <main+0x10bc>  // b.any
    if(parse_u64(argv[2], &key) == 0 && key <= 0xffffffffU &&
    1df8:	f9400a80 	ldr	x0, [x20, #16]
    1dfc:	910363e1 	add	x1, sp, #0xd8
    1e00:	940003b8 	bl	2ce0 <parse_u64>
    1e04:	350000a0 	cbnz	w0, 1e18 <main+0x1080>
    1e08:	f9406fe6 	ldr	x6, [sp, #216]
    1e0c:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    1e10:	eb0000df 	cmp	x6, x0
    1e14:	54000069 	b.ls	1e20 <main+0x1088>  // b.plast
  int r = -1;
    1e18:	12800013 	mov	w19, #0xffffffff            	// #-1
    1e1c:	17fffe79 	b	1800 <main+0xa68>
       parse_u64(argv[3], &value) == 0)
    1e20:	f9400e80 	ldr	x0, [x20, #24]
    1e24:	9105e3e1 	add	x1, sp, #0x178
    1e28:	940003ae 	bl	2ce0 <parse_u64>
    if(parse_u64(argv[2], &key) == 0 && key <= 0xffffffffU &&
    1e2c:	35ffff60 	cbnz	w0, 1e18 <main+0x1080>
      r = submit_one(&client, OP_PUT, key, value, 0, &response);
    1e30:	f940bfe3 	ldr	x3, [sp, #376]
    1e34:	910e23e5 	add	x5, sp, #0x388
    1e38:	2a0603e2 	mov	w2, w6
    1e3c:	52800004 	mov	w4, #0x0                   	// #0
    1e40:	52800021 	mov	w1, #0x1                   	// #1
      r = submit_one(&client, OP_PUT, key, value, 1, &response);
    1e44:	910163e0 	add	x0, sp, #0x58
    1e48:	94000630 	bl	3708 <submit_one>
  return submit_simple(client, IPC_CHECK, &response);
    1e4c:	2a0003f3 	mov	w19, w0
    1e50:	17fffe6c 	b	1800 <main+0xa68>
  } else if(strcmp(argv[1], "get") == 0 && argc == 3){
    1e54:	f9400680 	ldr	x0, [x20, #8]
    1e58:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1e5c:	91295821 	add	x1, x1, #0xa56
    1e60:	97fffb92 	bl	ca8 <strcmp@plt>
    1e64:	350003e0 	cbnz	w0, 1ee0 <main+0x1148>
    1e68:	71000ebf 	cmp	w21, #0x3
    1e6c:	540003a1 	b.ne	1ee0 <main+0x1148>  // b.any
    if(parse_u64(argv[2], &key) == 0 && key <= 0xffffffffU){
    1e70:	f9400a80 	ldr	x0, [x20, #16]
    1e74:	9105e3e1 	add	x1, sp, #0x178
    1e78:	9400039a 	bl	2ce0 <parse_u64>
    1e7c:	35fffce0 	cbnz	w0, 1e18 <main+0x1080>
    1e80:	f940bff4 	ldr	x20, [sp, #376]
    1e84:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    1e88:	eb00029f 	cmp	x20, x0
    1e8c:	54fffc68 	b.hi	1e18 <main+0x1080>  // b.pmore
      r = submit_get(&client, key, &response);
    1e90:	910e23e2 	add	x2, sp, #0x388
    1e94:	2a1403e1 	mov	w1, w20
    1e98:	910163e0 	add	x0, sp, #0x58
    1e9c:	94000473 	bl	3068 <submit_get>
    1ea0:	2a0003f3 	mov	w19, w0
      if(r == 0)
    1ea4:	35000100 	cbnz	w0, 1ec4 <main+0x112c>
        printf("mygres: key=%d value=%l xmin=%l\n", (uint32)key,
    1ea8:	f941cbe2 	ldr	x2, [sp, #912]
    1eac:	2a1403e1 	mov	w1, w20
    1eb0:	f941d3e3 	ldr	x3, [sp, #928]
    1eb4:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1eb8:	912d7000 	add	x0, x0, #0xb5c
    1ebc:	97fffb2b 	bl	b68 <printf@plt>
    1ec0:	17fffe50 	b	1800 <main+0xa68>
      else if(r == 1)
    1ec4:	7100041f 	cmp	w0, #0x1
    1ec8:	54ffc9c1 	b.ne	1800 <main+0xa68>  // b.any
        printf("mygres: key=%d not found\n", (uint32)key);
    1ecc:	2a1403e1 	mov	w1, w20
    1ed0:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1ed4:	912df400 	add	x0, x0, #0xb7d
    1ed8:	97fffb24 	bl	b68 <printf@plt>
  } else if(strcmp(argv[1], "get") == 0 && argc == 3){
    1edc:	17fffe49 	b	1800 <main+0xa68>
  } else if(strcmp(argv[1], "delete") == 0 && argc == 3){
    1ee0:	f9400680 	ldr	x0, [x20, #8]
    1ee4:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1ee8:	910bf821 	add	x1, x1, #0x2fe
    1eec:	97fffb6f 	bl	ca8 <strcmp@plt>
    1ef0:	35000200 	cbnz	w0, 1f30 <main+0x1198>
    1ef4:	71000ebf 	cmp	w21, #0x3
    1ef8:	540001c1 	b.ne	1f30 <main+0x1198>  // b.any
    if(parse_u64(argv[2], &key) == 0 && key <= 0xffffffffU)
    1efc:	f9400a80 	ldr	x0, [x20, #16]
    1f00:	9105e3e1 	add	x1, sp, #0x178
    1f04:	94000377 	bl	2ce0 <parse_u64>
    1f08:	35fff880 	cbnz	w0, 1e18 <main+0x1080>
    1f0c:	f940bfe2 	ldr	x2, [sp, #376]
    1f10:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    1f14:	eb00005f 	cmp	x2, x0
    1f18:	54fff808 	b.hi	1e18 <main+0x1080>  // b.pmore
      r = submit_one(&client, OP_DELETE, key, 0, 0, &response);
    1f1c:	910e23e5 	add	x5, sp, #0x388
    1f20:	52800004 	mov	w4, #0x0                   	// #0
    1f24:	d2800003 	mov	x3, #0x0                   	// #0
    1f28:	52800041 	mov	w1, #0x2                   	// #2
    1f2c:	17ffffc6 	b	1e44 <main+0x10ac>
  } else if(strcmp(argv[1], "scan") == 0)
    1f30:	f9400680 	ldr	x0, [x20, #8]
    1f34:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1f38:	912afc21 	add	x1, x1, #0xabf
    1f3c:	97fffb5b 	bl	ca8 <strcmp@plt>
    1f40:	350000c0 	cbnz	w0, 1f58 <main+0x11c0>
    r = submit_simple(&client, IPC_SCAN, &response);
    1f44:	910e23e2 	add	x2, sp, #0x388
    1f48:	52800081 	mov	w1, #0x4                   	// #4
  return submit_simple(client, IPC_CHECK, &response);
    1f4c:	910163e0 	add	x0, sp, #0x58
    1f50:	94000462 	bl	30d8 <submit_simple>
    1f54:	17ffffbe 	b	1e4c <main+0x10b4>
  else if(strcmp(argv[1], "check") == 0)
    1f58:	f9400680 	ldr	x0, [x20, #8]
    1f5c:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1f60:	912b2821 	add	x1, x1, #0xaca
    1f64:	97fffb51 	bl	ca8 <strcmp@plt>
    1f68:	35000080 	cbnz	w0, 1f78 <main+0x11e0>
  return submit_simple(client, IPC_CHECK, &response);
    1f6c:	910e23e2 	add	x2, sp, #0x388
    1f70:	528000a1 	mov	w1, #0x5                   	// #5
    1f74:	17fffff6 	b	1f4c <main+0x11b4>
  else if(strcmp(argv[1], "stats") == 0){
    1f78:	f9400680 	ldr	x0, [x20, #8]
    1f7c:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1f80:	912b5821 	add	x1, x1, #0xad6
    1f84:	97fffb49 	bl	ca8 <strcmp@plt>
    1f88:	35000200 	cbnz	w0, 1fc8 <main+0x1230>
    r = submit_simple(&client, IPC_STATS, &response);
    1f8c:	910e23e2 	add	x2, sp, #0x388
    1f90:	910163e0 	add	x0, sp, #0x58
    1f94:	528000c1 	mov	w1, #0x6                   	// #6
    1f98:	94000450 	bl	30d8 <submit_simple>
    1f9c:	2a0003f3 	mov	w19, w0
    if(r == 0)
    1fa0:	35ffc300 	cbnz	w0, 1800 <main+0xa68>
      printf("mygres: txid=%l rows=%l commits=%l recoveries=%l index-hit=%l miss=%l\n",
    1fa4:	910ea3e6 	add	x6, sp, #0x3a8
    1fa8:	90000020 	adrp	x0, 5000 <pgwire_connection+0xba0>
    1fac:	912e5c00 	add	x0, x0, #0xb97
    1fb0:	f941cfe1 	ldr	x1, [sp, #920]
    1fb4:	a9400cc2 	ldp	x2, x3, [x6]
    1fb8:	a94114c4 	ldp	x4, x5, [x6, #16]
    1fbc:	f941e7e6 	ldr	x6, [sp, #968]
    1fc0:	97fffaea 	bl	b68 <printf@plt>
    1fc4:	17fffe0f 	b	1800 <main+0xa68>
  } else if(strcmp(argv[1], "recover") == 0){
    1fc8:	f9400680 	ldr	x0, [x20, #8]
    1fcc:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1fd0:	912f7821 	add	x1, x1, #0xbde
    1fd4:	97fffb35 	bl	ca8 <strcmp@plt>
    1fd8:	35000080 	cbnz	w0, 1fe8 <main+0x1250>
    r = submit_simple(&client, IPC_RECOVER, &response);
    1fdc:	910e23e2 	add	x2, sp, #0x388
    1fe0:	528000e1 	mov	w1, #0x7                   	// #7
    1fe4:	17ffffda 	b	1f4c <main+0x11b4>
  } else if(strcmp(argv[1], "prepare") == 0 && argc == 4){
    1fe8:	f9400680 	ldr	x0, [x20, #8]
    1fec:	90000021 	adrp	x1, 5000 <pgwire_connection+0xba0>
    1ff0:	912f9821 	add	x1, x1, #0xbe6
    1ff4:	97fffb2d 	bl	ca8 <strcmp@plt>
    1ff8:	350002a0 	cbnz	w0, 204c <main+0x12b4>
    1ffc:	710012bf 	cmp	w21, #0x4
    2000:	54000261 	b.ne	204c <main+0x12b4>  // b.any
    if(parse_u64(argv[2], &key) == 0 && key <= 0xffffffffU &&
    2004:	f9400a80 	ldr	x0, [x20, #16]
    2008:	910363e1 	add	x1, sp, #0xd8
    200c:	94000335 	bl	2ce0 <parse_u64>
    2010:	35fff040 	cbnz	w0, 1e18 <main+0x1080>
    2014:	f9406fe6 	ldr	x6, [sp, #216]
    2018:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    201c:	eb0000df 	cmp	x6, x0
    2020:	54ffefc8 	b.hi	1e18 <main+0x1080>  // b.pmore
       parse_u64(argv[3], &value) == 0)
    2024:	f9400e80 	ldr	x0, [x20, #24]
    2028:	9105e3e1 	add	x1, sp, #0x178
    202c:	9400032d 	bl	2ce0 <parse_u64>
    if(parse_u64(argv[2], &key) == 0 && key <= 0xffffffffU &&
    2030:	35ffef40 	cbnz	w0, 1e18 <main+0x1080>
      r = submit_one(&client, OP_PUT, key, value, 1, &response);
    2034:	f940bfe3 	ldr	x3, [sp, #376]
    2038:	52800024 	mov	w4, #0x1                   	// #1
    203c:	910e23e5 	add	x5, sp, #0x388
    2040:	2a0603e2 	mov	w2, w6
    2044:	2a0403e1 	mov	w1, w4
    2048:	17ffff7f 	b	1e44 <main+0x10ac>
  } else if(strcmp(argv[1], "stress") == 0){
    204c:	f9400680 	ldr	x0, [x20, #8]
    2050:	f0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    2054:	912fb821 	add	x1, x1, #0xbee
    2058:	97fffb14 	bl	ca8 <strcmp@plt>
    205c:	2a0003f6 	mov	w22, w0
    2060:	35000ae0 	cbnz	w0, 21bc <main+0x1424>
    uint workers = argc >= 3 ? atoi(argv[2]) : 4;
    2064:	71000abf 	cmp	w21, #0x2
    2068:	540006a0 	b.eq	213c <main+0x13a4>  // b.none
    206c:	f9400a80 	ldr	x0, [x20, #16]
    2070:	97fffb22 	bl	cf8 <atoi@plt>
    2074:	2a0003f7 	mov	w23, w0
    uint operations = argc >= 4 ? atoi(argv[3]) : 50;
    2078:	71000ebf 	cmp	w21, #0x3
    207c:	540005c0 	b.eq	2134 <main+0x139c>  // b.none
    2080:	f9400e80 	ldr	x0, [x20, #24]
    2084:	97fffb1d 	bl	cf8 <atoi@plt>
    2088:	2a0003f4 	mov	w20, w0
  if(workers == 0 || workers > 8 || operations == 0)
    208c:	510006e0 	sub	w0, w23, #0x1
    2090:	71001c1f 	cmp	w0, #0x7
    2094:	54ffec28 	b.hi	1e18 <main+0x1080>  // b.pmore
    2098:	34ffec14 	cbz	w20, 1e18 <main+0x1080>
  uint64 start = clock_us();
    209c:	97fffb0f 	bl	cd8 <clock_us@plt>
    20a0:	aa0003f8 	mov	x24, x0
  for(uint w = 0; w < workers; w++){
    20a4:	52800013 	mov	w19, #0x0                   	// #0
    int pid = fork();
    20a8:	97fffaf4 	bl	c78 <fork@plt>
    if(pid < 0)
    20ac:	37ffeb60 	tbnz	w0, #31, 1e18 <main+0x1080>
    if(pid == 0){
    20b0:	350004c0 	cbnz	w0, 2148 <main+0x13b0>
      client->next_request = ((uint64)(uint32)getpid()) << 32;
    20b4:	97fffac1 	bl	bb8 <getpid@plt>
    20b8:	d3607c00 	lsl	x0, x0, #32
    20bc:	f90037e0 	str	x0, [sp, #104]
        uint64 value = (uint64)w * 1000000UL + i;
    20c0:	52884800 	mov	w0, #0x4240                	// #16960
    20c4:	72a001e0 	movk	w0, #0xf, lsl #16
        uint32 key = (w * operations + i) % (MAX_ROWS / 2);
    20c8:	1b137e97 	mul	w23, w20, w19
      for(uint i = 0; i < operations; i++){
    20cc:	52800015 	mov	w21, #0x0                   	// #0
        uint64 value = (uint64)w * 1000000UL + i;
    20d0:	9ba07e73 	umull	x19, w19, w0
        uint32 key = (w * operations + i) % (MAX_ROWS / 2);
    20d4:	0b1502f6 	add	w22, w23, w21
        if(submit_one(client, OP_PUT, key, value, 0, &response) < 0)
    20d8:	910e23e5 	add	x5, sp, #0x388
    20dc:	aa1303e3 	mov	x3, x19
    20e0:	120022c2 	and	w2, w22, #0x1ff
    20e4:	910163e0 	add	x0, sp, #0x58
    20e8:	52800004 	mov	w4, #0x0                   	// #0
    20ec:	52800021 	mov	w1, #0x1                   	// #1
    20f0:	94000586 	bl	3708 <submit_one>
    20f4:	37ff6660 	tbnz	w0, #31, dc0 <main+0x28>
        if((i & 31U) == 0){
    20f8:	f24012bf 	tst	x21, #0x1f
    20fc:	54000121 	b.ne	2120 <main+0x1388>  // b.any
          if(submit_get(client, key, &response) != 0 ||
    2100:	910e23e2 	add	x2, sp, #0x388
    2104:	120022c1 	and	w1, w22, #0x1ff
    2108:	910163e0 	add	x0, sp, #0x58
    210c:	940003d7 	bl	3068 <submit_get>
    2110:	35ff6580 	cbnz	w0, dc0 <main+0x28>
    2114:	f941cbe0 	ldr	x0, [sp, #912]
    2118:	eb13001f 	cmp	x0, x19
    211c:	54ff6521 	b.ne	dc0 <main+0x28>  // b.any
      for(uint i = 0; i < operations; i++){
    2120:	110006b5 	add	w21, w21, #0x1
    2124:	91000673 	add	x19, x19, #0x1
    2128:	6b1402bf 	cmp	w21, w20
    212c:	54fffd43 	b.cc	20d4 <main+0x133c>  // b.lo, b.ul, b.last
    2130:	17fffc63 	b	12bc <main+0x524>
    uint operations = argc >= 4 ? atoi(argv[3]) : 50;
    2134:	52800654 	mov	w20, #0x32                  	// #50
    2138:	17ffffd5 	b	208c <main+0x12f4>
    213c:	52800654 	mov	w20, #0x32                  	// #50
    uint workers = argc >= 3 ? atoi(argv[2]) : 4;
    2140:	52800097 	mov	w23, #0x4                   	// #4
    2144:	17ffffd6 	b	209c <main+0x1304>
  for(uint w = 0; w < workers; w++){
    2148:	11000673 	add	w19, w19, #0x1
    214c:	6b1302ff 	cmp	w23, w19
    2150:	54fffac1 	b.ne	20a8 <main+0x1310>  // b.any
  for(uint w = 0; w < workers; w++){
    2154:	52800015 	mov	w21, #0x0                   	// #0
    wait(&status);
    2158:	910e23e0 	add	x0, sp, #0x388
    int status = 0;
    215c:	b9038bff 	str	wzr, [sp, #904]
    wait(&status);
    2160:	97fffab6 	bl	c38 <wait@plt>
  for(uint w = 0; w < workers; w++){
    2164:	110006b5 	add	w21, w21, #0x1
    if(status != 0)
    2168:	b9438be0 	ldr	w0, [sp, #904]
    216c:	7100001f 	cmp	w0, #0x0
    2170:	1a9f07e0 	cset	w0, ne	// ne = any
    2174:	2a0002d6 	orr	w22, w22, w0
  for(uint w = 0; w < workers; w++){
    2178:	6b1302bf 	cmp	w21, w19
    217c:	54fffee1 	b.ne	2158 <main+0x13c0>  // b.any
  uint64 elapsed = clock_us() - start;
    2180:	97fffad6 	bl	cd8 <clock_us@plt>
  printf("mygres: stress workers=%d commits=%d elapsed=%l us %s\n",
    2184:	cb180003 	sub	x3, x0, x24
    2188:	1b147ea2 	mul	w2, w21, w20
    218c:	710002df 	cmp	w22, #0x0
    2190:	f0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    2194:	91013421 	add	x1, x1, #0x4d
    2198:	f0000004 	adrp	x4, 5000 <pgwire_connection+0xba0>
    219c:	91012084 	add	x4, x4, #0x48
    21a0:	9a810084 	csel	x4, x4, x1, eq	// eq = none
    21a4:	f0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    21a8:	912fd400 	add	x0, x0, #0xbf5
    21ac:	2a1503e1 	mov	w1, w21
    21b0:	97fffa6e 	bl	b68 <printf@plt>
  if(failed)
    21b4:	34ffedd6 	cbz	w22, 1f6c <main+0x11d4>
    21b8:	17ffff18 	b	1e18 <main+0x1080>
    usage();
    21bc:	94000074 	bl	238c <usage>
    21c0:	17ffff16 	b	1e18 <main+0x1080>

00000000000021c4 <hash_bytes>:
{
    21c4:	aa0003e5 	mov	x5, x0
    h *= 16777619U;
    21c8:	52803264 	mov	w4, #0x193                 	// #403
    21cc:	72a02004 	movk	w4, #0x100, lsl #16
  uint32 h = 2166136261U;
    21d0:	5293b8a0 	mov	w0, #0x9dc5                	// #40389
    21d4:	72b02380 	movk	w0, #0x811c, lsl #16
{
    21d8:	d2800003 	mov	x3, #0x0                   	// #0
    h ^= p[i];
    21dc:	386368a2 	ldrb	w2, [x5, x3]
  for(uint i = 0; i < n; i++){
    21e0:	91000463 	add	x3, x3, #0x1
    h ^= p[i];
    21e4:	4a000042 	eor	w2, w2, w0
    h *= 16777619U;
    21e8:	1b047c40 	mul	w0, w2, w4
  for(uint i = 0; i < n; i++){
    21ec:	6b03003f 	cmp	w1, w3
    21f0:	54ffff68 	b.hi	21dc <hash_bytes+0x18>  // b.pmore
}
    21f4:	d65f03c0 	ret

00000000000021f8 <valid_row>:
{
    21f8:	aa0003e6 	mov	x6, x0
    21fc:	d2800000 	mov	x0, #0x0                   	// #0
    if(p[i] != 0){
    2200:	386068c1 	ldrb	w1, [x6, x0]
    2204:	35000141 	cbnz	w1, 222c <valid_row+0x34>
  for(uint i = 0; i < sizeof(*r); i++)
    2208:	91000400 	add	x0, x0, #0x1
    220c:	f101001f 	cmp	x0, #0x40
    2210:	54ffff81 	b.ne	2200 <valid_row+0x8>  // b.any
    return 1;
    2214:	52800020 	mov	w0, #0x1                   	// #1
}
    2218:	d65f03c0 	ret
          r->state == ROW_TOMB) && saved == got;
    221c:	6b0000ff 	cmp	w7, w0
    2220:	1a9f17e0 	cset	w0, eq	// eq = none
}
    2224:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2228:	d65f03c0 	ret
{
    222c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  uint32 got = hash_bytes(r, sizeof(*r));
    2230:	52800801 	mov	w1, #0x40                  	// #64
    2234:	aa0603e0 	mov	x0, x6
{
    2238:	910003fd 	mov	x29, sp
  uint32 saved = r->checksum;
    223c:	b94018c7 	ldr	w7, [x6, #24]
  r->checksum = 0;
    2240:	b90018df 	str	wzr, [x6, #24]
  uint32 got = hash_bytes(r, sizeof(*r));
    2244:	97ffffe0 	bl	21c4 <hash_bytes>
          r->state == ROW_TOMB) && saved == got;
    2248:	b94000c1 	ldr	w1, [x6]
  r->checksum = saved;
    224c:	b90018c7 	str	w7, [x6, #24]
          r->state == ROW_TOMB) && saved == got;
    2250:	7100083f 	cmp	w1, #0x2
    2254:	54fffe49 	b.ls	221c <valid_row+0x24>  // b.plast
    2258:	52800000 	mov	w0, #0x0                   	// #0
    225c:	17fffff2 	b	2224 <valid_row+0x2c>

0000000000002260 <pg_be32>:
}
    2260:	5ac00800 	rev	w0, w0
    2264:	d65f03c0 	ret

0000000000002268 <pg_u64toa>:
{
    2268:	d10083ff 	sub	sp, sp, #0x20
    226c:	d2800003 	mov	x3, #0x0                   	// #0
    reverse[n++] = '0' + value % 10;
    2270:	910003e2 	mov	x2, sp
    2274:	d2800146 	mov	x6, #0xa                   	// #10
    2278:	9ac60805 	udiv	x5, x0, x6
  } while(value);
    227c:	f100241f 	cmp	x0, #0x9
    reverse[n++] = '0' + value % 10;
    2280:	9b0680a4 	msub	x4, x5, x6, x0
    value /= 10;
    2284:	aa0503e0 	mov	x0, x5
    reverse[n++] = '0' + value % 10;
    2288:	1100c084 	add	w4, w4, #0x30
    228c:	38226864 	strb	w4, [x3, x2]
  } while(value);
    2290:	aa0303e4 	mov	x4, x3
    2294:	91000463 	add	x3, x3, #0x1
    2298:	54ffff08 	b.hi	2278 <pg_u64toa+0x10>  // b.pmore
    reverse[n++] = '0' + value % 10;
    229c:	11000483 	add	w3, w4, #0x1
    buffer[i] = reverse[n - i - 1];
    22a0:	8b244042 	add	x2, x2, w4, uxtw
    reverse[n++] = '0' + value % 10;
    22a4:	d2800000 	mov	x0, #0x0                   	// #0
    buffer[i] = reverse[n - i - 1];
    22a8:	cb0003e5 	neg	x5, x0
    22ac:	38656845 	ldrb	w5, [x2, x5]
    22b0:	38206825 	strb	w5, [x1, x0]
  for(int i = 0; i < n; i++)
    22b4:	91000400 	add	x0, x0, #0x1
    22b8:	51000405 	sub	w5, w0, #0x1
    22bc:	6b05009f 	cmp	w4, w5
    22c0:	54ffff4c 	b.gt	22a8 <pg_u64toa+0x40>
  buffer[n] = 0;
    22c4:	3823483f 	strb	wzr, [x1, w3, uxtw]
}
    22c8:	910083ff 	add	sp, sp, #0x20
    22cc:	d65f03c0 	ret

00000000000022d0 <pg_skip_space>:
  while(*text == ' ' || *text == '\t' || *text == '\r' || *text == '\n')
    22d0:	d284c002 	mov	x2, #0x2600                	// #9728
    22d4:	f2c00022 	movk	x2, #0x1, lsl #32
    22d8:	39400001 	ldrb	w1, [x0]
    22dc:	7100803f 	cmp	w1, #0x20
    22e0:	54000068 	b.hi	22ec <pg_skip_space+0x1c>  // b.pmore
    22e4:	9ac12441 	lsr	x1, x2, x1
    22e8:	37000041 	tbnz	w1, #0, 22f0 <pg_skip_space+0x20>
}
    22ec:	d65f03c0 	ret
    text++;
    22f0:	91000400 	add	x0, x0, #0x1
    22f4:	17fffff9 	b	22d8 <pg_skip_space+0x8>

00000000000022f8 <pg_cstring>:
{
    22f8:	aa0003e2 	mov	x2, x0
  char *value = (char *)*cursor;
    22fc:	f9400000 	ldr	x0, [x0]
  while(*cursor < end && **cursor)
    2300:	aa0003e3 	mov	x3, x0
    2304:	eb03003f 	cmp	x1, x3
    2308:	540000e9 	b.ls	2324 <pg_cstring+0x2c>  // b.plast
    230c:	38401465 	ldrb	w5, [x3], #1
    2310:	35000065 	cbnz	w5, 231c <pg_cstring+0x24>
  (*cursor)++;
    2314:	f9000043 	str	x3, [x2]
}
    2318:	d65f03c0 	ret
    (*cursor)++;
    231c:	f9000043 	str	x3, [x2]
    2320:	17fffff9 	b	2304 <pg_cstring+0xc>
    return 0;
    2324:	d2800000 	mov	x0, #0x0                   	// #0
    2328:	17fffffc 	b	2318 <pg_cstring+0x20>

000000000000232c <shell_help>:
{
    232c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  printf("BEGIN                         start transaction\n");
    2330:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    2334:	91371000 	add	x0, x0, #0xdc4
{
    2338:	910003fd 	mov	x29, sp
  printf("BEGIN                         start transaction\n");
    233c:	97fffa0b 	bl	b68 <printf@plt>
  printf("PUT key value                 stage/commit an indexed row\n");
    2340:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    2344:	9137d400 	add	x0, x0, #0xdf5
    2348:	97fffa08 	bl	b68 <printf@plt>
  printf("GET key                       index lookup\n");
    234c:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    2350:	9138c000 	add	x0, x0, #0xe30
    2354:	97fffa05 	bl	b68 <printf@plt>
  printf("DELETE key                    stage/commit a tombstone\n");
    2358:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    235c:	91397000 	add	x0, x0, #0xe5c
    2360:	97fffa02 	bl	b68 <printf@plt>
  printf("COMMIT | ROLLBACK             finish transaction\n");
    2364:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    2368:	913a5000 	add	x0, x0, #0xe94
    236c:	97fff9ff 	bl	b68 <printf@plt>
  printf("SCAN | CHECK | STATS          inspect database\n");
    2370:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    2374:	913b1800 	add	x0, x0, #0xec6
    2378:	97fff9fc 	bl	b68 <printf@plt>
}
    237c:	a8c17bfd 	ldp	x29, x30, [sp], #16
  printf("QUIT                          leave shell\n");
    2380:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    2384:	913bd800 	add	x0, x0, #0xef6
    2388:	17fff9f8 	b	b68 <printf@plt>

000000000000238c <usage>:
{
    238c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  printf("usage: mygres init|server [WORKERS]|status|shell\n");
    2390:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    2394:	913c8400 	add	x0, x0, #0xf21
{
    2398:	910003fd 	mov	x29, sp
  printf("usage: mygres init|server [WORKERS]|status|shell\n");
    239c:	97fff9f3 	bl	b68 <printf@plt>
  printf("              put KEY VALUE|get KEY|delete KEY|scan\n");
    23a0:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    23a4:	913d4c00 	add	x0, x0, #0xf53
    23a8:	97fff9f0 	bl	b68 <printf@plt>
  printf("              check|stats|recover|prepare KEY VALUE\n");
    23ac:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    23b0:	913e2000 	add	x0, x0, #0xf88
    23b4:	97fff9ed 	bl	b68 <printf@plt>
}
    23b8:	a8c17bfd 	ldp	x29, x30, [sp], #16
  printf("              stress [WORKERS [TRANSACTIONS_PER_WORKER]]\n");
    23bc:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    23c0:	913ef400 	add	x0, x0, #0xfbd
    23c4:	17fff9e9 	b	b68 <printf@plt>

00000000000023c8 <rebuild_index>:
{
    23c8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  memset(s->index, 0, sizeof(s->index));
    23cc:	52840002 	mov	w2, #0x2000                	// #8192
    23d0:	52800001 	mov	w1, #0x0                   	// #0
{
    23d4:	910003fd 	mov	x29, sp
    23d8:	f9000bf3 	str	x19, [sp, #16]
    23dc:	aa0003f3 	mov	x19, x0
  memset(s->index, 0, sizeof(s->index));
    23e0:	91010000 	add	x0, x0, #0x40
    23e4:	97fffa29 	bl	c88 <memset@plt>
  for(uint i = 0; i < MAX_ROWS; i++)
    23e8:	d2840800 	mov	x0, #0x2040                	// #8256
    23ec:	8b000263 	add	x3, x19, x0
  key *= 0x7feb352dU;
    23f0:	5286a5a5 	mov	w5, #0x352d                	// #13613
    23f4:	72affd65 	movk	w5, #0x7feb, lsl #16
  key *= 0x846ca68bU;
    23f8:	5294d166 	mov	w6, #0xa68b                	// #42635
    23fc:	72b08d86 	movk	w6, #0x846c, lsl #16
  memset(s->index, 0, sizeof(s->index));
    2400:	d2800022 	mov	x2, #0x1                   	// #1
    if(s->rows[i].state == ROW_USED && index_insert(s, i) < 0)
    2404:	b9400060 	ldr	w0, [x3]
    2408:	7100041f 	cmp	w0, #0x1
    240c:	540001c1 	b.ne	2444 <rebuild_index+0x7c>  // b.any
  uint32 key = s->rows[slot].key;
    2410:	b9400460 	ldr	w0, [x3, #4]
  for(uint probe = 0; probe < INDEX_SIZE; probe++){
    2414:	52800004 	mov	w4, #0x0                   	// #0
  key ^= key >> 16;
    2418:	4a404000 	eor	w0, w0, w0, lsr #16
  key *= 0x7feb352dU;
    241c:	1b057c00 	mul	w0, w0, w5
  key ^= key >> 15;
    2420:	4a403c00 	eor	w0, w0, w0, lsr #15
  key *= 0x846ca68bU;
    2424:	1b067c00 	mul	w0, w0, w6
  key ^= key >> 16;
    2428:	4a404000 	eor	w0, w0, w0, lsr #16
    uint pos = (start + probe) % INDEX_SIZE;
    242c:	0b000081 	add	w1, w4, w0
    2430:	d37e2821 	ubfiz	x1, x1, #2, #11
    2434:	8b010261 	add	x1, x19, x1
    if(s->index[pos] == 0){
    2438:	b9404027 	ldr	w7, [x1, #64]
    243c:	35000107 	cbnz	w7, 245c <rebuild_index+0x94>
      s->index[pos] = slot + 1;
    2440:	b9004022 	str	w2, [x1, #64]
  for(uint i = 0; i < MAX_ROWS; i++)
    2444:	91000442 	add	x2, x2, #0x1
    2448:	91010063 	add	x3, x3, #0x40
    244c:	f110045f 	cmp	x2, #0x401
    2450:	54fffda1 	b.ne	2404 <rebuild_index+0x3c>  // b.any
  return 0;
    2454:	52800000 	mov	w0, #0x0                   	// #0
    2458:	14000005 	b	246c <rebuild_index+0xa4>
  for(uint probe = 0; probe < INDEX_SIZE; probe++){
    245c:	11000484 	add	w4, w4, #0x1
    2460:	7120009f 	cmp	w4, #0x800
    2464:	54fffe41 	b.ne	242c <rebuild_index+0x64>  // b.any
      return -1;
    2468:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    246c:	f9400bf3 	ldr	x19, [sp, #16]
    2470:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2474:	d65f03c0 	ret

0000000000002478 <clear_wal>:
{
    2478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  int fd = open(WAL_PATH, O_CREATE | O_RDWR | O_TRUNC);
    247c:	d0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    2480:	913fdc00 	add	x0, x0, #0xff7
{
    2484:	910003fd 	mov	x29, sp
  int fd = open(WAL_PATH, O_CREATE | O_RDWR | O_TRUNC);
    2488:	5280c041 	mov	w1, #0x602                 	// #1538
{
    248c:	a90153f3 	stp	x19, x20, [sp, #16]
  int fd = open(WAL_PATH, O_CREATE | O_RDWR | O_TRUNC);
    2490:	97fffa22 	bl	d18 <open@plt>
  if(fd < 0)
    2494:	37f80160 	tbnz	w0, #31, 24c0 <clear_wal+0x48>
    2498:	2a0003f3 	mov	w19, w0
  int ok = fsync(fd) == 0;
    249c:	97fffa07 	bl	cb8 <fsync@plt>
    24a0:	2a0003f4 	mov	w20, w0
  close(fd);
    24a4:	2a1303e0 	mov	w0, w19
    24a8:	97fffa30 	bl	d68 <close@plt>
  return ok ? 0 : -1;
    24ac:	7100029f 	cmp	w20, #0x0
    24b0:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    24b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    24b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    24bc:	d65f03c0 	ret
    return -1;
    24c0:	12800000 	mov	w0, #0xffffffff            	// #-1
    24c4:	17fffffc 	b	24b4 <clear_wal+0x3c>

00000000000024c8 <destroy_postmaster_database>:
{
    24c8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    24cc:	910003fd 	mov	x29, sp
    24d0:	f9000bf3 	str	x19, [sp, #16]
    24d4:	aa0003f3 	mov	x19, x0
  if(db->shm){
    24d8:	f9400000 	ldr	x0, [x0]
    24dc:	b4000080 	cbz	x0, 24ec <destroy_postmaster_database+0x24>
    munmap(db->shm, db->shm_bytes);
    24e0:	f9400661 	ldr	x1, [x19, #8]
    24e4:	97fff9ad 	bl	b98 <munmap@plt>
    db->shm = 0;
    24e8:	f900027f 	str	xzr, [x19]
}
    24ec:	f9400bf3 	ldr	x19, [sp, #16]
    24f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    24f4:	d65f03c0 	ret

00000000000024f8 <shared_lock>:
{
    24f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    24fc:	910003fd 	mov	x29, sp
    2500:	a90153f3 	stp	x19, x20, [sp, #16]
    2504:	aa0003f3 	mov	x19, x0
      asm volatile("stxr %w0, %w1, [%2]"
    2508:	52800034 	mov	w20, #0x1                   	// #1
    asm volatile("ldaxr %w0, [%1]"
    250c:	885ffe60 	ldaxr	w0, [x19]
    if(old == 0){
    2510:	350000c0 	cbnz	w0, 2528 <shared_lock+0x30>
      asm volatile("stxr %w0, %w1, [%2]"
    2514:	88007e74 	stxr	w0, w20, [x19]
      if(failed == 0)
    2518:	350000a0 	cbnz	w0, 252c <shared_lock+0x34>
}
    251c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2520:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2524:	d65f03c0 	ret
      asm volatile("clrex" ::: "memory");
    2528:	d5033f5f 	clrex
    sched_yield();
    252c:	97fffa03 	bl	d38 <sched_yield@plt>
  for(;;){
    2530:	17fffff7 	b	250c <shared_lock+0x14>

0000000000002534 <read_db_row>:
{
    2534:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return PAGE_SIZE + (uint64)slot * sizeof(struct db_row);
    2538:	11010023 	add	w3, w1, #0x40
{
    253c:	910003fd 	mov	x29, sp
    2540:	f9000bf3 	str	x19, [sp, #16]
    2544:	aa0203f3 	mov	x19, x2
     pread(fd, r, sizeof(*r), row_offset(slot)) != sizeof(*r))
    2548:	d37ae463 	lsl	x3, x3, #6
    254c:	aa1303e1 	mov	x1, x19
    2550:	52800802 	mov	w2, #0x40                  	// #64
    2554:	97fff9dd 	bl	cc8 <pread@plt>
  if(slot >= MAX_ROWS ||
    2558:	7101001f 	cmp	w0, #0x40
    255c:	54000101 	b.ne	257c <read_db_row+0x48>  // b.any
  return valid_row(r) ? 0 : -1;
    2560:	aa1303e0 	mov	x0, x19
    2564:	97ffff25 	bl	21f8 <valid_row>
    2568:	52000000 	eor	w0, w0, #0x1
    256c:	4b0003e0 	neg	w0, w0
}
    2570:	f9400bf3 	ldr	x19, [sp, #16]
    2574:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2578:	d65f03c0 	ret
    return -1;
    257c:	12800000 	mov	w0, #0xffffffff            	// #-1
    2580:	17fffffc 	b	2570 <read_db_row+0x3c>

0000000000002584 <pg_get16>:
{
    2584:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  memmove(&value, buffer, 2);
    2588:	aa0003e1 	mov	x1, x0
    258c:	52800042 	mov	w2, #0x2                   	// #2
{
    2590:	910003fd 	mov	x29, sp
  memmove(&value, buffer, 2);
    2594:	91007be0 	add	x0, sp, #0x1e
    2598:	97fff97c 	bl	b88 <memmove@plt>
}
    259c:	79403fe0 	ldrh	w0, [sp, #30]
    25a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    25a4:	5ac00400 	rev16	w0, w0
    25a8:	d65f03c0 	ret

00000000000025ac <pg_get32>:
{
    25ac:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  memmove(&value, buffer, 4);
    25b0:	aa0003e1 	mov	x1, x0
    25b4:	52800082 	mov	w2, #0x4                   	// #4
{
    25b8:	910003fd 	mov	x29, sp
  memmove(&value, buffer, 4);
    25bc:	910073e0 	add	x0, sp, #0x1c
    25c0:	97fff972 	bl	b88 <memmove@plt>
  return pg_be32(value);
    25c4:	b9401fe0 	ldr	w0, [sp, #28]
}
    25c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
  return pg_be32(value);
    25cc:	17ffff25 	b	2260 <pg_be32>

00000000000025d0 <pg_put16>:
{
    25d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  return (value << 8) | (value >> 8);
    25d4:	5ac00442 	rev16	w2, w2
{
    25d8:	910003fd 	mov	x29, sp
    25dc:	f9000bf3 	str	x19, [sp, #16]
    25e0:	aa0103f3 	mov	x19, x1
  memmove(buffer + *position, &value, 2);
    25e4:	9100bbe1 	add	x1, sp, #0x2e
  value = pg_be16(value);
    25e8:	79005fe2 	strh	w2, [sp, #46]
  memmove(buffer + *position, &value, 2);
    25ec:	52800042 	mov	w2, #0x2                   	// #2
    25f0:	b9400263 	ldr	w3, [x19]
    25f4:	8b030000 	add	x0, x0, x3
    25f8:	97fff964 	bl	b88 <memmove@plt>
  *position += 2;
    25fc:	b9400260 	ldr	w0, [x19]
    2600:	11000800 	add	w0, w0, #0x2
    2604:	b9000260 	str	w0, [x19]
}
    2608:	f9400bf3 	ldr	x19, [sp, #16]
    260c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2610:	d65f03c0 	ret

0000000000002614 <pg_put32>:
{
    2614:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2618:	aa0003e3 	mov	x3, x0
  value = pg_be32(value);
    261c:	2a0203e0 	mov	w0, w2
{
    2620:	910003fd 	mov	x29, sp
    2624:	f9000bf3 	str	x19, [sp, #16]
    2628:	aa0103f3 	mov	x19, x1
  value = pg_be32(value);
    262c:	97ffff0d 	bl	2260 <pg_be32>
    2630:	b9002fe0 	str	w0, [sp, #44]
  memmove(buffer + *position, &value, 4);
    2634:	9100b3e1 	add	x1, sp, #0x2c
    2638:	52800082 	mov	w2, #0x4                   	// #4
    263c:	b9400260 	ldr	w0, [x19]
    2640:	8b000060 	add	x0, x3, x0
    2644:	97fff951 	bl	b88 <memmove@plt>
  *position += 4;
    2648:	b9400260 	ldr	w0, [x19]
    264c:	11001000 	add	w0, w0, #0x4
    2650:	b9000260 	str	w0, [x19]
}
    2654:	f9400bf3 	ldr	x19, [sp, #16]
    2658:	a8c37bfd 	ldp	x29, x30, [sp], #48
    265c:	d65f03c0 	ret

0000000000002660 <pg_write_all>:
{
    2660:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2664:	910003fd 	mov	x29, sp
    2668:	a90153f3 	stp	x19, x20, [sp, #16]
    266c:	2a0203f4 	mov	w20, w2
  int done = 0;
    2670:	52800013 	mov	w19, #0x0                   	// #0
{
    2674:	a9025bf5 	stp	x21, x22, [sp, #32]
    2678:	2a0003f6 	mov	w22, w0
    267c:	aa0103f5 	mov	x21, x1
  while(done < length){
    2680:	6b14027f 	cmp	w19, w20
    2684:	540000cb 	b.lt	269c <pg_write_all+0x3c>  // b.tstop
  return 0;
    2688:	52800000 	mov	w0, #0x0                   	// #0
}
    268c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2690:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2694:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2698:	d65f03c0 	ret
    int n = write(fd, (char *)buffer + done, length - done);
    269c:	4b130282 	sub	w2, w20, w19
    26a0:	8b33c2a1 	add	x1, x21, w19, sxtw
    26a4:	2a1603e0 	mov	w0, w22
    26a8:	97fff958 	bl	c08 <write@plt>
    if(n <= 0)
    26ac:	7100001f 	cmp	w0, #0x0
    26b0:	5400006d 	b.le	26bc <pg_write_all+0x5c>
    done += n;
    26b4:	0b000273 	add	w19, w19, w0
    26b8:	17fffff2 	b	2680 <pg_write_all+0x20>
      return -1;
    26bc:	12800000 	mov	w0, #0xffffffff            	// #-1
    26c0:	17fffff3 	b	268c <pg_write_all+0x2c>

00000000000026c4 <pg_send>:
{
    26c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    26c8:	910003fd 	mov	x29, sp
    26cc:	a90153f3 	stp	x19, x20, [sp, #16]
    26d0:	2a0003f3 	mov	w19, w0
  uint32 length = pg_be32(payload_length + 4);
    26d4:	11001060 	add	w0, w3, #0x4
    26d8:	b9002fe3 	str	w3, [sp, #44]
    26dc:	97fffee1 	bl	2260 <pg_be32>
{
    26e0:	aa0203f4 	mov	x20, x2
  memmove(header + 1, &length, sizeof(length));
    26e4:	52800082 	mov	w2, #0x4                   	// #4
  uint32 length = pg_be32(payload_length + 4);
    26e8:	b90037e0 	str	w0, [sp, #52]
  memmove(header + 1, &length, sizeof(length));
    26ec:	9100e7e0 	add	x0, sp, #0x39
  header[0] = type;
    26f0:	3900e3e1 	strb	w1, [sp, #56]
  memmove(header + 1, &length, sizeof(length));
    26f4:	9100d3e1 	add	x1, sp, #0x34
    26f8:	97fff924 	bl	b88 <memmove@plt>
  if(pg_write_all(fd, header, sizeof(header)) < 0)
    26fc:	9100e3e1 	add	x1, sp, #0x38
    2700:	2a1303e0 	mov	w0, w19
    2704:	528000a2 	mov	w2, #0x5                   	// #5
    2708:	97ffffd6 	bl	2660 <pg_write_all>
    270c:	3100041f 	cmn	w0, #0x1
    2710:	540000e0 	b.eq	272c <pg_send+0x68>  // b.none
  return payload_length ? pg_write_all(fd, payload, payload_length) : 0;
    2714:	b9402fe3 	ldr	w3, [sp, #44]
    2718:	34000103 	cbz	w3, 2738 <pg_send+0x74>
    271c:	2a0303e2 	mov	w2, w3
    2720:	aa1403e1 	mov	x1, x20
    2724:	2a1303e0 	mov	w0, w19
    2728:	97ffffce 	bl	2660 <pg_write_all>
}
    272c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2730:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2734:	d65f03c0 	ret
  return payload_length ? pg_write_all(fd, payload, payload_length) : 0;
    2738:	52800000 	mov	w0, #0x0                   	// #0
    273c:	17fffffc 	b	272c <pg_send+0x68>

0000000000002740 <pg_send_ready>:
{
    2740:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  char status = transaction ? 'T' : 'I';
    2744:	7100003f 	cmp	w1, #0x0
    2748:	52800a82 	mov	w2, #0x54                  	// #84
{
    274c:	910003fd 	mov	x29, sp
  char status = transaction ? 'T' : 'I';
    2750:	52800921 	mov	w1, #0x49                  	// #73
    2754:	1a820021 	csel	w1, w1, w2, eq	// eq = none
  return pg_send(fd, 'Z', &status, 1);
    2758:	52800023 	mov	w3, #0x1                   	// #1
    275c:	91007fe2 	add	x2, sp, #0x1f
  char status = transaction ? 'T' : 'I';
    2760:	39007fe1 	strb	w1, [sp, #31]
  return pg_send(fd, 'Z', &status, 1);
    2764:	52800b41 	mov	w1, #0x5a                  	// #90
    2768:	97ffffd7 	bl	26c4 <pg_send>
}
    276c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2770:	d65f03c0 	ret

0000000000002774 <pg_send_parameter>:
{
    2774:	a9b17bfd 	stp	x29, x30, [sp, #-240]!
    2778:	910003fd 	mov	x29, sp
    277c:	a90153f3 	stp	x19, x20, [sp, #16]
    2780:	a9025bf5 	stp	x21, x22, [sp, #32]
    2784:	a90363f7 	stp	x23, x24, [sp, #48]
    2788:	aa0203f7 	mov	x23, x2
    278c:	aa0103f8 	mov	x24, x1
    2790:	f90023f9 	str	x25, [sp, #64]
    2794:	2a0003f9 	mov	w25, w0
  uint n = strlen(name) + 1, v = strlen(value) + 1;
    2798:	aa0103e0 	mov	x0, x1
    279c:	97fff95b 	bl	d08 <strlen@plt>
    27a0:	11000413 	add	w19, w0, #0x1
    27a4:	aa1703e0 	mov	x0, x23
    27a8:	97fff958 	bl	d08 <strlen@plt>
    27ac:	11000414 	add	w20, w0, #0x1
  if(n + v > sizeof(payload))
    27b0:	0b140276 	add	w22, w19, w20
    27b4:	710282df 	cmp	w22, #0xa0
    27b8:	540002a8 	b.hi	280c <pg_send_parameter+0x98>  // b.pmore
  memmove(payload, name, n);
    27bc:	910143f5 	add	x21, sp, #0x50
    27c0:	2a1303e2 	mov	w2, w19
    27c4:	aa1803e1 	mov	x1, x24
    27c8:	aa1503e0 	mov	x0, x21
    27cc:	97fff8ef 	bl	b88 <memmove@plt>
  memmove(payload + n, value, v);
    27d0:	2a1403e2 	mov	w2, w20
    27d4:	aa1703e1 	mov	x1, x23
    27d8:	8b3342a0 	add	x0, x21, w19, uxtw
    27dc:	97fff8eb 	bl	b88 <memmove@plt>
  return pg_send(fd, 'S', payload, n + v);
    27e0:	2a1603e3 	mov	w3, w22
    27e4:	aa1503e2 	mov	x2, x21
    27e8:	2a1903e0 	mov	w0, w25
    27ec:	52800a61 	mov	w1, #0x53                  	// #83
    27f0:	97ffffb5 	bl	26c4 <pg_send>
}
    27f4:	f94023f9 	ldr	x25, [sp, #64]
    27f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    27fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2800:	a94363f7 	ldp	x23, x24, [sp, #48]
    2804:	a8cf7bfd 	ldp	x29, x30, [sp], #240
    2808:	d65f03c0 	ret
    return -1;
    280c:	12800000 	mov	w0, #0xffffffff            	// #-1
    2810:	17fffff9 	b	27f4 <pg_send_parameter+0x80>

0000000000002814 <pg_send_row_description>:
{
    2814:	d10a03ff 	sub	sp, sp, #0x280
    2818:	a9007bfd 	stp	x29, x30, [sp]
    281c:	910003fd 	mov	x29, sp
    2820:	a90153f3 	stp	x19, x20, [sp, #16]
  pg_put16(payload, &position, fields);
    2824:	910203f3 	add	x19, sp, #0x80
    2828:	d2800014 	mov	x20, #0x0                   	// #0
{
    282c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2830:	2a0003f6 	mov	w22, w0
    2834:	2a0103f5 	mov	w21, w1
  pg_put16(payload, &position, fields);
    2838:	aa1303e0 	mov	x0, x19
{
    283c:	a90363f7 	stp	x23, x24, [sp, #48]
    2840:	a9046bf9 	stp	x25, x26, [sp, #64]
    2844:	aa0203f9 	mov	x25, x2
    2848:	aa0303fa 	mov	x26, x3
  pg_put16(payload, &position, fields);
    284c:	2a0103e2 	mov	w2, w1
    2850:	9101f3e1 	add	x1, sp, #0x7c
{
    2854:	a90573fb 	stp	x27, x28, [sp, #80]
    2858:	aa0403fb 	mov	x27, x4
  uint position = 0;
    285c:	b9007fff 	str	wzr, [sp, #124]
  pg_put16(payload, &position, fields);
    2860:	97ffff5c 	bl	25d0 <pg_put16>
    if(pg_add_field(payload, &position, names[i], oids[i], widths[i]) < 0)
    2864:	f8747b21 	ldr	x1, [x25, x20, lsl #3]
  uint n = strlen(name) + 1;
    2868:	f90037e1 	str	x1, [sp, #104]
    if(pg_add_field(payload, &position, names[i], oids[i], widths[i]) < 0)
    286c:	b8747b58 	ldr	w24, [x26, x20, lsl #2]
    2870:	78747b77 	ldrh	w23, [x27, x20, lsl #1]
  uint n = strlen(name) + 1;
    2874:	aa0103e0 	mov	x0, x1
    2878:	97fff924 	bl	d08 <strlen@plt>
    287c:	11000402 	add	w2, w0, #0x1
  if(*position + n + 18 > 512)
    2880:	b9407fe0 	ldr	w0, [sp, #124]
    2884:	0b00005c 	add	w28, w2, w0
    2888:	11004b83 	add	w3, w28, #0x12
    288c:	7108007f 	cmp	w3, #0x200
    2890:	540005a8 	b.hi	2944 <pg_send_row_description+0x130>  // b.pmore
  memmove(buffer + *position, name, n); *position += n;
    2894:	f94037e1 	ldr	x1, [sp, #104]
    2898:	8b204260 	add	x0, x19, w0, uxtw
  for(int i = 0; i < fields; i++)
    289c:	91000694 	add	x20, x20, #0x1
  memmove(buffer + *position, name, n); *position += n;
    28a0:	97fff8ba 	bl	b88 <memmove@plt>
    28a4:	b9007ffc 	str	w28, [sp, #124]
  pg_put32(buffer, position, 0);          // table OID
    28a8:	9101f3e1 	add	x1, sp, #0x7c
    28ac:	aa1303e0 	mov	x0, x19
    28b0:	52800002 	mov	w2, #0x0                   	// #0
    28b4:	97ffff58 	bl	2614 <pg_put32>
  pg_put16(buffer, position, 0);          // attribute number
    28b8:	9101f3e1 	add	x1, sp, #0x7c
    28bc:	aa1303e0 	mov	x0, x19
    28c0:	52800002 	mov	w2, #0x0                   	// #0
    28c4:	97ffff43 	bl	25d0 <pg_put16>
  pg_put32(buffer, position, oid);        // type OID
    28c8:	2a1803e2 	mov	w2, w24
    28cc:	9101f3e1 	add	x1, sp, #0x7c
    28d0:	aa1303e0 	mov	x0, x19
    28d4:	97ffff50 	bl	2614 <pg_put32>
  pg_put16(buffer, position, width);      // type width (-1 becomes 0xffff)
    28d8:	2a1703e2 	mov	w2, w23
    28dc:	9101f3e1 	add	x1, sp, #0x7c
    28e0:	aa1303e0 	mov	x0, x19
    28e4:	97ffff3b 	bl	25d0 <pg_put16>
  pg_put32(buffer, position, 0xffffffffU);// type modifier
    28e8:	9101f3e1 	add	x1, sp, #0x7c
    28ec:	aa1303e0 	mov	x0, x19
    28f0:	12800002 	mov	w2, #0xffffffff            	// #-1
    28f4:	97ffff48 	bl	2614 <pg_put32>
  pg_put16(buffer, position, 0);          // text format
    28f8:	9101f3e1 	add	x1, sp, #0x7c
    28fc:	aa1303e0 	mov	x0, x19
    2900:	52800002 	mov	w2, #0x0                   	// #0
    2904:	97ffff33 	bl	25d0 <pg_put16>
  for(int i = 0; i < fields; i++)
    2908:	eb1402bf 	cmp	x21, x20
    290c:	54fffac1 	b.ne	2864 <pg_send_row_description+0x50>  // b.any
  return pg_send(fd, 'T', payload, position);
    2910:	b9407fe3 	ldr	w3, [sp, #124]
    2914:	aa1303e2 	mov	x2, x19
    2918:	2a1603e0 	mov	w0, w22
    291c:	52800a81 	mov	w1, #0x54                  	// #84
    2920:	97ffff69 	bl	26c4 <pg_send>
}
    2924:	a9407bfd 	ldp	x29, x30, [sp]
    2928:	a94153f3 	ldp	x19, x20, [sp, #16]
    292c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2930:	a94363f7 	ldp	x23, x24, [sp, #48]
    2934:	a9446bf9 	ldp	x25, x26, [sp, #64]
    2938:	a94573fb 	ldp	x27, x28, [sp, #80]
    293c:	910a03ff 	add	sp, sp, #0x280
    2940:	d65f03c0 	ret
      return -1;
    2944:	12800000 	mov	w0, #0xffffffff            	// #-1
    2948:	17fffff7 	b	2924 <pg_send_row_description+0x110>

000000000000294c <pg_send_data_row>:
{
    294c:	d10983ff 	sub	sp, sp, #0x260
    2950:	a9007bfd 	stp	x29, x30, [sp]
    2954:	910003fd 	mov	x29, sp
    2958:	a90153f3 	stp	x19, x20, [sp, #16]
  pg_put16(payload, &position, fields);
    295c:	910183f4 	add	x20, sp, #0x60
    2960:	2a0103f3 	mov	w19, w1
{
    2964:	a9025bf5 	stp	x21, x22, [sp, #32]
  pg_put16(payload, &position, fields);
    2968:	d2800015 	mov	x21, #0x0                   	// #0
{
    296c:	a90363f7 	stp	x23, x24, [sp, #48]
    2970:	2a0003f8 	mov	w24, w0
    2974:	aa0203f7 	mov	x23, x2
  pg_put16(payload, &position, fields);
    2978:	aa1403e0 	mov	x0, x20
    297c:	2a0103e2 	mov	w2, w1
    2980:	910173e1 	add	x1, sp, #0x5c
{
    2984:	f90023f9 	str	x25, [sp, #64]
  uint position = 0;
    2988:	b9005fff 	str	wzr, [sp, #92]
  pg_put16(payload, &position, fields);
    298c:	97ffff11 	bl	25d0 <pg_put16>
    if(values[i] == 0){
    2990:	f8757ae0 	ldr	x0, [x23, x21, lsl #3]
    2994:	b5000280 	cbnz	x0, 29e4 <pg_send_data_row+0x98>
      pg_put32(payload, &position, 0xffffffffU);
    2998:	910173e1 	add	x1, sp, #0x5c
    299c:	aa1403e0 	mov	x0, x20
    29a0:	12800002 	mov	w2, #0xffffffff            	// #-1
    29a4:	97ffff1c 	bl	2614 <pg_put32>
  for(int i = 0; i < fields; i++){
    29a8:	910006b5 	add	x21, x21, #0x1
    29ac:	eb15027f 	cmp	x19, x21
    29b0:	54ffff01 	b.ne	2990 <pg_send_data_row+0x44>  // b.any
  return pg_send(fd, 'D', payload, position);
    29b4:	b9405fe3 	ldr	w3, [sp, #92]
    29b8:	aa1403e2 	mov	x2, x20
    29bc:	2a1803e0 	mov	w0, w24
    29c0:	52800881 	mov	w1, #0x44                  	// #68
    29c4:	97ffff40 	bl	26c4 <pg_send>
}
    29c8:	f94023f9 	ldr	x25, [sp, #64]
    29cc:	a9407bfd 	ldp	x29, x30, [sp]
    29d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    29d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    29d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    29dc:	910983ff 	add	sp, sp, #0x260
    29e0:	d65f03c0 	ret
    uint n = strlen(values[i]);
    29e4:	97fff8c9 	bl	d08 <strlen@plt>
    29e8:	2a0003f9 	mov	w25, w0
    if(position + 4 + n > sizeof(payload))
    29ec:	b9405fe1 	ldr	w1, [sp, #92]
    29f0:	11001021 	add	w1, w1, #0x4
    29f4:	0b000021 	add	w1, w1, w0
    29f8:	7108003f 	cmp	w1, #0x200
    29fc:	540001a8 	b.hi	2a30 <pg_send_data_row+0xe4>  // b.pmore
    pg_put32(payload, &position, n);
    2a00:	2a0003e2 	mov	w2, w0
    2a04:	910173e1 	add	x1, sp, #0x5c
    2a08:	aa1403e0 	mov	x0, x20
    2a0c:	97ffff02 	bl	2614 <pg_put32>
    memmove(payload + position, values[i], n);
    2a10:	f8757ae1 	ldr	x1, [x23, x21, lsl #3]
    2a14:	2a1903e2 	mov	w2, w25
    2a18:	b9405ff6 	ldr	w22, [sp, #92]
    2a1c:	8b364280 	add	x0, x20, w22, uxtw
    position += n;
    2a20:	0b1902d6 	add	w22, w22, w25
    memmove(payload + position, values[i], n);
    2a24:	97fff859 	bl	b88 <memmove@plt>
    position += n;
    2a28:	b9005ff6 	str	w22, [sp, #92]
    2a2c:	17ffffdf 	b	29a8 <pg_send_data_row+0x5c>
      return -1;
    2a30:	12800000 	mov	w0, #0xffffffff            	// #-1
    2a34:	17ffffe5 	b	29c8 <pg_send_data_row+0x7c>

0000000000002a38 <pg_send_command>:
{
    2a38:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2a3c:	910003fd 	mov	x29, sp
    2a40:	f9000bf3 	str	x19, [sp, #16]
    2a44:	2a0003f3 	mov	w19, w0
  return pg_send(fd, 'C', tag, strlen(tag) + 1);
    2a48:	aa0103e0 	mov	x0, x1
    2a4c:	f90017e1 	str	x1, [sp, #40]
    2a50:	97fff8ae 	bl	d08 <strlen@plt>
    2a54:	11000403 	add	w3, w0, #0x1
    2a58:	f94017e2 	ldr	x2, [sp, #40]
    2a5c:	2a1303e0 	mov	w0, w19
}
    2a60:	f9400bf3 	ldr	x19, [sp, #16]
  return pg_send(fd, 'C', tag, strlen(tag) + 1);
    2a64:	52800861 	mov	w1, #0x43                  	// #67
}
    2a68:	a8c37bfd 	ldp	x29, x30, [sp], #48
  return pg_send(fd, 'C', tag, strlen(tag) + 1);
    2a6c:	17ffff16 	b	26c4 <pg_send>

0000000000002a70 <pg_send_text_result>:
{
    2a70:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2a74:	910003fd 	mov	x29, sp
  char *values[1] = { value };
    2a78:	a9030be1 	stp	x1, x2, [sp, #48]
  uint32 oids[1] = { 25 };                // TEXTOID
    2a7c:	52800321 	mov	w1, #0x19                  	// #25
{
    2a80:	a90153f3 	stp	x19, x20, [sp, #16]
    2a84:	2a0003f3 	mov	w19, w0
    2a88:	aa0303f4 	mov	x20, x3
  uint32 oids[1] = { 25 };                // TEXTOID
    2a8c:	b9002be1 	str	w1, [sp, #40]
  uint16 widths[1] = { 0xffff };
    2a90:	12800001 	mov	w1, #0xffffffff            	// #-1
    2a94:	790043e1 	strh	w1, [sp, #32]
         pg_send_command(fd, tag) < 0 ? -1 : 0;
    2a98:	35000144 	cbnz	w4, 2ac0 <pg_send_text_result+0x50>
         pg_send_data_row(fd, 1, values) < 0 ||
    2a9c:	9100e3e2 	add	x2, sp, #0x38
    2aa0:	2a1303e0 	mov	w0, w19
    2aa4:	52800021 	mov	w1, #0x1                   	// #1
    2aa8:	97ffffa9 	bl	294c <pg_send_data_row>
  return (describe && pg_send_row_description(fd, 1, names, oids, widths) < 0) ||
    2aac:	3100041f 	cmn	w0, #0x1
    2ab0:	54000181 	b.ne	2ae0 <pg_send_text_result+0x70>  // b.any
}
    2ab4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ab8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2abc:	d65f03c0 	ret
  return (describe && pg_send_row_description(fd, 1, names, oids, widths) < 0) ||
    2ac0:	910083e4 	add	x4, sp, #0x20
    2ac4:	9100a3e3 	add	x3, sp, #0x28
    2ac8:	9100c3e2 	add	x2, sp, #0x30
    2acc:	52800021 	mov	w1, #0x1                   	// #1
    2ad0:	97ffff51 	bl	2814 <pg_send_row_description>
    2ad4:	3100041f 	cmn	w0, #0x1
    2ad8:	54fffe21 	b.ne	2a9c <pg_send_text_result+0x2c>  // b.any
    2adc:	17fffff6 	b	2ab4 <pg_send_text_result+0x44>
         pg_send_command(fd, tag) < 0 ? -1 : 0;
    2ae0:	aa1403e1 	mov	x1, x20
    2ae4:	2a1303e0 	mov	w0, w19
    2ae8:	97ffffd4 	bl	2a38 <pg_send_command>
         pg_send_data_row(fd, 1, values) < 0 ||
    2aec:	3100041f 	cmn	w0, #0x1
    2af0:	5a9f13e0 	csetm	w0, eq	// eq = none
         pg_send_command(fd, tag) < 0 ? -1 : 0;
    2af4:	17fffff0 	b	2ab4 <pg_send_text_result+0x44>

0000000000002af8 <pg_send_error>:
{
    2af8:	a9a87bfd 	stp	x29, x30, [sp, #-384]!
    2afc:	910003fd 	mov	x29, sp
    2b00:	a90363f7 	stp	x23, x24, [sp, #48]
    2b04:	2a0003f8 	mov	w24, w0
  payload[pos++] = 'S';
    2b08:	52800a60 	mov	w0, #0x53                  	// #83
{
    2b0c:	aa0203f7 	mov	x23, x2
  memmove(payload + pos, "ERROR", 6); pos += 6;
    2b10:	528000c2 	mov	w2, #0x6                   	// #6
{
    2b14:	a90153f3 	stp	x19, x20, [sp, #16]
  memmove(payload + pos, "ERROR", 6); pos += 6;
    2b18:	f0000013 	adrp	x19, 5000 <pgwire_connection+0xba0>
    2b1c:	910103f4 	add	x20, sp, #0x40
{
    2b20:	a9025bf5 	stp	x21, x22, [sp, #32]
    2b24:	aa0103f5 	mov	x21, x1
  memmove(payload + pos, "ERROR", 6); pos += 6;
    2b28:	91004261 	add	x1, x19, #0x10
  payload[pos++] = 'S';
    2b2c:	390103e0 	strb	w0, [sp, #64]
  memmove(payload + pos, "ERROR", 6); pos += 6;
    2b30:	910107e0 	add	x0, sp, #0x41
    2b34:	97fff815 	bl	b88 <memmove@plt>
  memmove(payload + pos, "ERROR", 6); pos += 6;
    2b38:	91004261 	add	x1, x19, #0x10
  payload[pos++] = 'V';
    2b3c:	52800ac0 	mov	w0, #0x56                  	// #86
  memmove(payload + pos, "ERROR", 6); pos += 6;
    2b40:	528000c2 	mov	w2, #0x6                   	// #6
  payload[pos++] = 'V';
    2b44:	39011fe0 	strb	w0, [sp, #71]
  memmove(payload + pos, "ERROR", 6); pos += 6;
    2b48:	910123e0 	add	x0, sp, #0x48
    2b4c:	97fff80f 	bl	b88 <memmove@plt>
  payload[pos++] = 'C';
    2b50:	52800860 	mov	w0, #0x43                  	// #67
    2b54:	39013be0 	strb	w0, [sp, #78]
  memmove(payload + pos, code, strlen(code) + 1); pos += strlen(code) + 1;
    2b58:	aa1503e0 	mov	x0, x21
    2b5c:	97fff86b 	bl	d08 <strlen@plt>
    2b60:	aa1503e1 	mov	x1, x21
    2b64:	11000402 	add	w2, w0, #0x1
    2b68:	91013fe0 	add	x0, sp, #0x4f
    2b6c:	97fff807 	bl	b88 <memmove@plt>
    2b70:	aa1503e0 	mov	x0, x21
    2b74:	97fff865 	bl	d08 <strlen@plt>
  payload[pos++] = 'M';
    2b78:	11004415 	add	w21, w0, #0x11
  memmove(payload + pos, code, strlen(code) + 1); pos += strlen(code) + 1;
    2b7c:	2a0003f3 	mov	w19, w0
  payload[pos++] = 'M';
    2b80:	11004000 	add	w0, w0, #0x10
    2b84:	528009a1 	mov	w1, #0x4d                  	// #77
  if(pos + n + 1 > sizeof(payload))
    2b88:	11004a73 	add	w19, w19, #0x12
  payload[pos++] = 'M';
    2b8c:	38206a81 	strb	w1, [x20, x0]
  uint n = strlen(message) + 1;
    2b90:	aa1703e0 	mov	x0, x23
    2b94:	97fff85d 	bl	d08 <strlen@plt>
    2b98:	11000416 	add	w22, w0, #0x1
  if(pos + n + 1 > sizeof(payload))
    2b9c:	0b160273 	add	w19, w19, w22
    n = sizeof(payload) - pos - 1;
    2ba0:	528027e0 	mov	w0, #0x13f                 	// #319
  if(pos + n + 1 > sizeof(payload))
    2ba4:	7105027f 	cmp	w19, #0x140
    n = sizeof(payload) - pos - 1;
    2ba8:	4b150000 	sub	w0, w0, w21
    2bac:	1a8092d6 	csel	w22, w22, w0, ls	// ls = plast
  memmove(payload + pos, message, n); pos += n;
    2bb0:	aa1703e1 	mov	x1, x23
    2bb4:	2a1603e2 	mov	w2, w22
    2bb8:	8b354280 	add	x0, x20, w21, uxtw
    2bbc:	97fff7f3 	bl	b88 <memmove@plt>
  payload[pos++] = 0;
    2bc0:	0b1502c2 	add	w2, w22, w21
  memmove(payload + pos, message, n); pos += n;
    2bc4:	0b1502c3 	add	w3, w22, w21
  return pg_send(fd, 'E', payload, pos) < 0 ? -1 : 1;
    2bc8:	11000463 	add	w3, w3, #0x1
    2bcc:	2a1803e0 	mov	w0, w24
    2bd0:	528008a1 	mov	w1, #0x45                  	// #69
  payload[pos++] = 0;
    2bd4:	38226a9f 	strb	wzr, [x20, x2]
  return pg_send(fd, 'E', payload, pos) < 0 ? -1 : 1;
    2bd8:	aa1403e2 	mov	x2, x20
    2bdc:	97fffeba 	bl	26c4 <pg_send>
    2be0:	3100041f 	cmn	w0, #0x1
}
    2be4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2be8:	1a9f0400 	csinc	w0, w0, wzr, eq	// eq = none
    2bec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2bf0:	a94363f7 	ldp	x23, x24, [sp, #48]
    2bf4:	a8d87bfd 	ldp	x29, x30, [sp], #384
    2bf8:	d65f03c0 	ret

0000000000002bfc <pg_read_all>:
{
    2bfc:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c00:	910003fd 	mov	x29, sp
    2c04:	a90153f3 	stp	x19, x20, [sp, #16]
    2c08:	2a0203f4 	mov	w20, w2
  int done = 0;
    2c0c:	52800013 	mov	w19, #0x0                   	// #0
{
    2c10:	a9025bf5 	stp	x21, x22, [sp, #32]
    2c14:	2a0003f6 	mov	w22, w0
    2c18:	aa0103f5 	mov	x21, x1
  while(done < length){
    2c1c:	6b14027f 	cmp	w19, w20
    2c20:	540000cb 	b.lt	2c38 <pg_read_all+0x3c>  // b.tstop
  return 0;
    2c24:	52800000 	mov	w0, #0x0                   	// #0
}
    2c28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2c2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2c30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2c34:	d65f03c0 	ret
    int n = read(fd, (char *)buffer + done, length - done);
    2c38:	4b130282 	sub	w2, w20, w19
    2c3c:	8b33c2a1 	add	x1, x21, w19, sxtw
    2c40:	2a1603e0 	mov	w0, w22
    2c44:	97fff805 	bl	c58 <read@plt>
    if(n <= 0)
    2c48:	7100001f 	cmp	w0, #0x0
    2c4c:	5400006d 	b.le	2c58 <pg_read_all+0x5c>
    done += n;
    2c50:	0b000273 	add	w19, w19, w0
    2c54:	17fffff2 	b	2c1c <pg_read_all+0x20>
      return -1;
    2c58:	12800000 	mov	w0, #0xffffffff            	// #-1
    2c5c:	17fffff3 	b	2c28 <pg_read_all+0x2c>

0000000000002c60 <tx_stage.part.0>:
  for(uint i = 0; i < tx->nops; i++)
    2c60:	aa0003e6 	mov	x6, x0
    2c64:	d2800004 	mov	x4, #0x0                   	// #0
    2c68:	b8404cc5 	ldr	w5, [x6, #4]!
    2c6c:	6b0400bf 	cmp	w5, w4
    2c70:	54000128 	b.hi	2c94 <tx_stage.part.0+0x34>  // b.pmore
  if(tx->nops >= MAX_TX_OPS)
    2c74:	71007cbf 	cmp	w5, #0x1f
    2c78:	54000268 	b.hi	2cc4 <tx_stage.part.0+0x64>  // b.pmore
  tx->ops[tx->nops].type = type;
    2c7c:	8b255004 	add	x4, x0, w5, uxtw #4
  tx->nops++;
    2c80:	110004a5 	add	w5, w5, #0x1
  tx->ops[tx->nops].type = type;
    2c84:	29020881 	stp	w1, w2, [x4, #16]
  tx->ops[tx->nops].value = value;
    2c88:	f9000c83 	str	x3, [x4, #24]
  tx->nops++;
    2c8c:	b9000405 	str	w5, [x0, #4]
  return 0;
    2c90:	14000009 	b	2cb4 <tx_stage.part.0+0x54>
    if(tx->ops[i].key == key){
    2c94:	11000487 	add	w7, w4, #0x1
    2c98:	d37cece7 	lsl	x7, x7, #4
    2c9c:	b86768c7 	ldr	w7, [x6, x7]
    2ca0:	6b0200ff 	cmp	w7, w2
    2ca4:	540000c1 	b.ne	2cbc <tx_stage.part.0+0x5c>  // b.any
      tx->ops[i].type = type;
    2ca8:	8b245004 	add	x4, x0, w4, uxtw #4
    2cac:	b9001081 	str	w1, [x4, #16]
      tx->ops[i].value = value;
    2cb0:	f9000c83 	str	x3, [x4, #24]
      return 0;
    2cb4:	52800000 	mov	w0, #0x0                   	// #0
}
    2cb8:	d65f03c0 	ret
    if(tx->ops[i].key == key){
    2cbc:	91000484 	add	x4, x4, #0x1
    2cc0:	17ffffeb 	b	2c6c <tx_stage.part.0+0xc>
    return -1;
    2cc4:	12800000 	mov	w0, #0xffffffff            	// #-1
    2cc8:	17fffffc 	b	2cb8 <tx_stage.part.0+0x58>

0000000000002ccc <tx_stage>:
  if(!tx->active)
    2ccc:	b9400004 	ldr	w4, [x0]
    2cd0:	34000044 	cbz	w4, 2cd8 <tx_stage+0xc>
  for(uint i = 0; i < tx->nops; i++)
    2cd4:	17ffffe3 	b	2c60 <tx_stage.part.0>
}
    2cd8:	12800000 	mov	w0, #0xffffffff            	// #-1
    2cdc:	d65f03c0 	ret

0000000000002ce0 <parse_u64>:
  if(!s || !*s)
    2ce0:	b5000060 	cbnz	x0, 2cec <parse_u64+0xc>
    return -1;
    2ce4:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    2ce8:	d65f03c0 	ret
  if(!s || !*s)
    2cec:	39400002 	ldrb	w2, [x0]
    2cf0:	34ffffa2 	cbz	w2, 2ce4 <parse_u64+0x4>
  uint64 n = 0;
    2cf4:	d2800003 	mov	x3, #0x0                   	// #0
    n = n * 10 + (*s - '0');
    2cf8:	d2800144 	mov	x4, #0xa                   	// #10
  for(; *s; s++){
    2cfc:	39400002 	ldrb	w2, [x0]
    2d00:	35000082 	cbnz	w2, 2d10 <parse_u64+0x30>
  return 0;
    2d04:	52800000 	mov	w0, #0x0                   	// #0
  *out = n;
    2d08:	f9000023 	str	x3, [x1]
  return 0;
    2d0c:	17fffff7 	b	2ce8 <parse_u64+0x8>
    if(*s < '0' || *s > '9')
    2d10:	5100c042 	sub	w2, w2, #0x30
    2d14:	12001c45 	and	w5, w2, #0xff
    2d18:	710024bf 	cmp	w5, #0x9
    2d1c:	54fffe48 	b.hi	2ce4 <parse_u64+0x4>  // b.pmore
    n = n * 10 + (*s - '0');
    2d20:	9b040863 	madd	x3, x3, x4, x2
  for(; *s; s++){
    2d24:	91000400 	add	x0, x0, #0x1
    2d28:	17fffff5 	b	2cfc <parse_u64+0x1c>

0000000000002d2c <destroy_ipc_state>:
  if(ipc == 0)
    2d2c:	b4000400 	cbz	x0, 2dac <destroy_ipc_state+0x80>
{
    2d30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  atomic_publish(&ipc->ready, 0);
    2d34:	91002001 	add	x1, x0, #0x8
{
    2d38:	910003fd 	mov	x29, sp
    2d3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2d40:	aa0003f3 	mov	x19, x0
  asm volatile("stlr %w0, [%1]" :: "r"(value), "r"(word) : "memory");
    2d44:	52800000 	mov	w0, #0x0                   	// #0
{
    2d48:	f90013f5 	str	x21, [sp, #32]
  asm volatile("stlr %w0, [%1]" :: "r"(value), "r"(word) : "memory");
    2d4c:	889ffc20 	stlr	w0, [x1]
destroy_ipc_state(struct ipc_state *ipc)
    2d50:	9100e275 	add	x21, x19, #0x38
  for(uint i = 0; i < ipc->nworkers && i < MAX_WORKERS; i++){
    2d54:	52800014 	mov	w20, #0x0                   	// #0
    2d58:	b9401660 	ldr	w0, [x19, #20]
    2d5c:	6b00029f 	cmp	w20, w0
    2d60:	54000143 	b.cc	2d88 <destroy_ipc_state+0x5c>  // b.lo, b.ul, b.last
  munmap(ipc, PAGE_SIZE);
    2d64:	aa1303e0 	mov	x0, x19
    2d68:	d2820001 	mov	x1, #0x1000                	// #4096
    2d6c:	97fff78b 	bl	b98 <munmap@plt>
}
    2d70:	f94013f5 	ldr	x21, [sp, #32]
  unlink(IPC_PATH);
    2d74:	f0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    2d78:	91005800 	add	x0, x0, #0x16
}
    2d7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d80:	a8c37bfd 	ldp	x29, x30, [sp], #48
  unlink(IPC_PATH);
    2d84:	17fff7b9 	b	c68 <unlink@plt>
  for(uint i = 0; i < ipc->nworkers && i < MAX_WORKERS; i++){
    2d88:	7100129f 	cmp	w20, #0x4
    2d8c:	54fffec0 	b.eq	2d64 <destroy_ipc_state+0x38>  // b.none
    sync_destroy(ipc->slots[i].request_sem);
    2d90:	b94002a0 	ldr	w0, [x21]
  for(uint i = 0; i < ipc->nworkers && i < MAX_WORKERS; i++){
    2d94:	11000694 	add	w20, w20, #0x1
    sync_destroy(ipc->slots[i].request_sem);
    2d98:	97fff778 	bl	b78 <sync_destroy@plt>
    sync_destroy(ipc->slots[i].response_sem);
    2d9c:	b94006a0 	ldr	w0, [x21, #4]
    2da0:	910a02b5 	add	x21, x21, #0x280
    2da4:	97fff775 	bl	b78 <sync_destroy@plt>
  for(uint i = 0; i < ipc->nworkers && i < MAX_WORKERS; i++){
    2da8:	17ffffec 	b	2d58 <destroy_ipc_state+0x2c>
    2dac:	d65f03c0 	ret

0000000000002db0 <pg_send_kv_result>:
{
    2db0:	a9b57bfd 	stp	x29, x30, [sp, #-176]!
    2db4:	910003fd 	mov	x29, sp
    2db8:	a90153f3 	stp	x19, x20, [sp, #16]
    2dbc:	aa0103f3 	mov	x19, x1
  char *names[2] = { "key", "value" };
    2dc0:	f0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    2dc4:	910a3821 	add	x1, x1, #0x28e
    2dc8:	f9002fe1 	str	x1, [sp, #88]
    2dcc:	f0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    2dd0:	9100a821 	add	x1, x1, #0x2a
    2dd4:	f90033e1 	str	x1, [sp, #96]
  uint32 oids[2] = { 23, 20 };             // INT4OID, INT8OID
    2dd8:	d28002e1 	mov	x1, #0x17                  	// #23
    2ddc:	f2c00281 	movk	x1, #0x14, lsl #32
{
    2de0:	a9025bf5 	stp	x21, x22, [sp, #32]
    2de4:	2a0203f4 	mov	w20, w2
    2de8:	a90363f7 	stp	x23, x24, [sp, #48]
    2dec:	2a0003f6 	mov	w22, w0
  uint32 oids[2] = { 23, 20 };             // INT4OID, INT8OID
    2df0:	f9002be1 	str	x1, [sp, #80]
  uint16 widths[2] = { 4, 8 };
    2df4:	52800081 	mov	w1, #0x4                   	// #4
    2df8:	72a00101 	movk	w1, #0x8, lsl #16
    2dfc:	b9004be1 	str	w1, [sp, #72]
  if(describe && pg_send_row_description(fd, 2, names, oids, widths) < 0)
    2e00:	350002c3 	cbnz	w3, 2e58 <pg_send_kv_result+0xa8>
pg_send_kv_result(int fd, struct db_row *rows, uint count, int describe)
    2e04:	52800800 	mov	w0, #0x40                  	// #64
    2e08:	2a1403f8 	mov	w24, w20
    2e0c:	910243f5 	add	x21, sp, #0x90
    char *values[2] = { key, value };
    2e10:	9101e3f7 	add	x23, sp, #0x78
    2e14:	9ba04e94 	umaddl	x20, w20, w0, x19
  for(uint i = 0; i < count; i++){
    2e18:	eb14027f 	cmp	x19, x20
    2e1c:	54000361 	b.ne	2e88 <pg_send_kv_result+0xd8>  // b.any
  char tag[32] = "SELECT ";
    2e20:	d288aa60 	mov	x0, #0x4553                	// #17747
    2e24:	f2a8a980 	movk	x0, #0x454c, lsl #16
    2e28:	d2800001 	mov	x1, #0x0                   	// #0
    2e2c:	f2ca8860 	movk	x0, #0x5443, lsl #32
    2e30:	f2e00400 	movk	x0, #0x20, lsl #48
    2e34:	a90907e0 	stp	x0, x1, [sp, #144]
  pg_u64toa(count, tag + 7);
    2e38:	91025fe1 	add	x1, sp, #0x97
    2e3c:	aa1803e0 	mov	x0, x24
  char tag[32] = "SELECT ";
    2e40:	a90a7fff 	stp	xzr, xzr, [sp, #160]
  pg_u64toa(count, tag + 7);
    2e44:	97fffd09 	bl	2268 <pg_u64toa>
  return pg_send_command(fd, tag);
    2e48:	2a1603e0 	mov	w0, w22
    2e4c:	aa1503e1 	mov	x1, x21
    2e50:	97fffefa 	bl	2a38 <pg_send_command>
    2e54:	14000008 	b	2e74 <pg_send_kv_result+0xc4>
  if(describe && pg_send_row_description(fd, 2, names, oids, widths) < 0)
    2e58:	910123e4 	add	x4, sp, #0x48
    2e5c:	910143e3 	add	x3, sp, #0x50
    2e60:	910163e2 	add	x2, sp, #0x58
    2e64:	52800041 	mov	w1, #0x2                   	// #2
    2e68:	97fffe6b 	bl	2814 <pg_send_row_description>
    2e6c:	3100041f 	cmn	w0, #0x1
    2e70:	54fffca1 	b.ne	2e04 <pg_send_kv_result+0x54>  // b.any
}
    2e74:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e78:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e7c:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e80:	a8cb7bfd 	ldp	x29, x30, [sp], #176
    2e84:	d65f03c0 	ret
    pg_u64toa(rows[i].key, key);
    2e88:	b9400660 	ldr	w0, [x19, #4]
    2e8c:	aa1703e1 	mov	x1, x23
    char *values[2] = { key, value };
    2e90:	a906d7f7 	stp	x23, x21, [sp, #104]
    pg_u64toa(rows[i].key, key);
    2e94:	97fffcf5 	bl	2268 <pg_u64toa>
    pg_u64toa(rows[i].value, value);
    2e98:	aa1503e1 	mov	x1, x21
    2e9c:	f9400660 	ldr	x0, [x19, #8]
    2ea0:	97fffcf2 	bl	2268 <pg_u64toa>
    if(pg_send_data_row(fd, 2, values) < 0)
    2ea4:	52800041 	mov	w1, #0x2                   	// #2
    2ea8:	9101a3e2 	add	x2, sp, #0x68
    2eac:	2a1603e0 	mov	w0, w22
    2eb0:	97fffea7 	bl	294c <pg_send_data_row>
    2eb4:	3100041f 	cmn	w0, #0x1
    2eb8:	54fffde0 	b.eq	2e74 <pg_send_kv_result+0xc4>  // b.none
    2ebc:	91010273 	add	x19, x19, #0x40
  for(uint i = 0; i < count; i++){
    2ec0:	17ffffd6 	b	2e18 <pg_send_kv_result+0x68>

0000000000002ec4 <pg_numbers.constprop.0>:
pg_numbers(char *text, uint64 *numbers, int maximum)
    2ec4:	aa0003e2 	mov	x2, x0
  while(*text && count < maximum){
    2ec8:	d2800003 	mov	x3, #0x0                   	// #0
      value = value * 10 + (*text++ - '0');
    2ecc:	d2800146 	mov	x6, #0xa                   	// #10
  while(*text && count < maximum){
    2ed0:	39400044 	ldrb	w4, [x2]
    2ed4:	2a0303e0 	mov	w0, w3
    2ed8:	34000184 	cbz	w4, 2f08 <pg_numbers.constprop.0+0x44>
    2edc:	f100107f 	cmp	x3, #0x4
    2ee0:	54000061 	b.ne	2eec <pg_numbers.constprop.0+0x28>  // b.any
    2ee4:	14000009 	b	2f08 <pg_numbers.constprop.0+0x44>
      text++;
    2ee8:	91000442 	add	x2, x2, #0x1
    while(*text && (*text < '0' || *text > '9'))
    2eec:	39400044 	ldrb	w4, [x2]
    2ef0:	5100c085 	sub	w5, w4, #0x30
    2ef4:	7100009f 	cmp	w4, #0x0
    2ef8:	12001ca5 	and	w5, w5, #0xff
    2efc:	7a4918a0 	ccmp	w5, #0x9, #0x0, ne	// ne = any
    2f00:	54ffff48 	b.hi	2ee8 <pg_numbers.constprop.0+0x24>  // b.pmore
    if(!*text)
    2f04:	35000184 	cbnz	w4, 2f34 <pg_numbers.constprop.0+0x70>
}
    2f08:	d65f03c0 	ret
      value = value * 10 + (*text++ - '0');
    2f0c:	9b060084 	madd	x4, x4, x6, x0
    2f10:	91000442 	add	x2, x2, #0x1
    while(*text >= '0' && *text <= '9')
    2f14:	39400040 	ldrb	w0, [x2]
    2f18:	5100c000 	sub	w0, w0, #0x30
    2f1c:	12001c05 	and	w5, w0, #0xff
    2f20:	710024bf 	cmp	w5, #0x9
    2f24:	54ffff49 	b.ls	2f0c <pg_numbers.constprop.0+0x48>  // b.plast
    numbers[count++] = value;
    2f28:	f8237824 	str	x4, [x1, x3, lsl #3]
    2f2c:	91000463 	add	x3, x3, #0x1
    2f30:	17ffffe8 	b	2ed0 <pg_numbers.constprop.0+0xc>
    uint64 value = 0;
    2f34:	d2800004 	mov	x4, #0x0                   	// #0
    2f38:	17fffff7 	b	2f14 <pg_numbers.constprop.0+0x50>

0000000000002f3c <ipc_submit>:
{
    2f3c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2f40:	910003fd 	mov	x29, sp
    2f44:	a90153f3 	stp	x19, x20, [sp, #16]
    2f48:	aa0003f4 	mov	x20, x0
    2f4c:	52805013 	mov	w19, #0x280                 	// #640
    2f50:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f54:	aa0103f6 	mov	x22, x1
    2f58:	f90023f9 	str	x25, [sp, #64]
    2f5c:	aa0203f9 	mov	x25, x2
    2f60:	a90363f7 	stp	x23, x24, [sp, #48]
    asm volatile("stxr %w0, %w1, [%2]"
    2f64:	52800038 	mov	w24, #0x1                   	// #1
    if(!client->state->ready)
    2f68:	f9400280 	ldr	x0, [x20]
    2f6c:	b9400800 	ldr	w0, [x0, #8]
    2f70:	34000540 	cbz	w0, 3018 <ipc_submit+0xdc>
    for(uint i = 0; i < client->state->nworkers; i++)
    2f74:	52800001 	mov	w1, #0x0                   	// #0
    2f78:	d2800403 	mov	x3, #0x20                  	// #32
    2f7c:	f9400280 	ldr	x0, [x20]
    2f80:	b9401402 	ldr	w2, [x0, #20]
    2f84:	6b01005f 	cmp	w2, w1
    2f88:	54000068 	b.hi	2f94 <ipc_submit+0x58>  // b.pmore
    sched_yield();
    2f8c:	97fff76b 	bl	d38 <sched_yield@plt>
    if(!client->state->ready)
    2f90:	17fffff6 	b	2f68 <ipc_submit+0x2c>
      if(atomic_claim(&client->state->slots[i].state,
    2f94:	9bb30c35 	umaddl	x21, w1, w19, x3
    2f98:	8b150000 	add	x0, x0, x21
    asm volatile("ldaxr %w0, [%1]"
    2f9c:	885ffc02 	ldaxr	w2, [x0]
    if(old != expected){
    2fa0:	34000082 	cbz	w2, 2fb0 <ipc_submit+0x74>
      asm volatile("clrex" ::: "memory");
    2fa4:	d5033f5f 	clrex
    for(uint i = 0; i < client->state->nworkers; i++)
    2fa8:	11000421 	add	w1, w1, #0x1
    2fac:	17fffff4 	b	2f7c <ipc_submit+0x40>
    asm volatile("stxr %w0, %w1, [%2]"
    2fb0:	88177c18 	stxr	w23, w24, [x0]
    if(failed == 0)
    2fb4:	35ffff57 	cbnz	w23, 2f9c <ipc_submit+0x60>
        slot = &client->state->slots[i];
    2fb8:	f9400298 	ldr	x24, [x20]
  slot->client_pid = getpid();
    2fbc:	97fff6ff 	bl	bb8 <getpid@plt>
  slot->request = *request;
    2fc0:	aa1603e1 	mov	x1, x22
    2fc4:	d2804302 	mov	x2, #0x218                 	// #536
        slot = &client->state->slots[i];
    2fc8:	8b150313 	add	x19, x24, x21
  slot->client_pid = getpid();
    2fcc:	b9000660 	str	w0, [x19, #4]
  slot->request_id = ++client->next_request;
    2fd0:	f9400a80 	ldr	x0, [x20, #16]
    2fd4:	91000400 	add	x0, x0, #0x1
    2fd8:	f9000a80 	str	x0, [x20, #16]
    2fdc:	f9000a60 	str	x0, [x19, #16]
  slot->request = *request;
    2fe0:	91008260 	add	x0, x19, #0x20
    2fe4:	97fff6f9 	bl	bc8 <memcpy@plt>
  memset(&slot->response, 0, sizeof(slot->response));
    2fe8:	9108e260 	add	x0, x19, #0x238
    2fec:	52800902 	mov	w2, #0x48                  	// #72
    2ff0:	52800001 	mov	w1, #0x0                   	// #0
    2ff4:	97fff725 	bl	c88 <memset@plt>
  asm volatile("stlr %w0, [%1]" :: "r"(value), "r"(word) : "memory");
    2ff8:	52800040 	mov	w0, #0x2                   	// #2
    2ffc:	889ffe60 	stlr	w0, [x19]
  if(sync_signal(slot->request_sem, 1) < 0 ||
    3000:	b9401a60 	ldr	w0, [x19, #24]
    3004:	52800021 	mov	w1, #0x1                   	// #1
    3008:	97fff748 	bl	d28 <sync_signal@plt>
    300c:	36f80140 	tbz	w0, #31, 3034 <ipc_submit+0xf8>
  asm volatile("stlr %w0, [%1]" :: "r"(value), "r"(word) : "memory");
    3010:	52800000 	mov	w0, #0x0                   	// #0
    3014:	889ffe60 	stlr	w0, [x19]
      return -1;
    3018:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    301c:	f94023f9 	ldr	x25, [sp, #64]
    3020:	a94153f3 	ldp	x19, x20, [sp, #16]
    3024:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3028:	a94363f7 	ldp	x23, x24, [sp, #48]
    302c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3030:	d65f03c0 	ret
     sync_wait(slot->response_sem) < 0 || slot->state != SLOT_RESPONSE){
    3034:	b9401e60 	ldr	w0, [x19, #28]
    3038:	97fff750 	bl	d78 <sync_wait@plt>
  if(sync_signal(slot->request_sem, 1) < 0 ||
    303c:	37fffea0 	tbnz	w0, #31, 3010 <ipc_submit+0xd4>
     sync_wait(slot->response_sem) < 0 || slot->state != SLOT_RESPONSE){
    3040:	b8756b00 	ldr	w0, [x24, x21]
    3044:	71000c1f 	cmp	w0, #0x3
    3048:	54fffe41 	b.ne	3010 <ipc_submit+0xd4>  // b.any
  *response = slot->response;
    304c:	9108e261 	add	x1, x19, #0x238
    3050:	aa1903e0 	mov	x0, x25
    3054:	d2800902 	mov	x2, #0x48                  	// #72
    3058:	97fff6dc 	bl	bc8 <memcpy@plt>
  asm volatile("stlr %w0, [%1]" :: "r"(value), "r"(word) : "memory");
    305c:	889ffe77 	stlr	w23, [x19]
  return 0;
    3060:	52800000 	mov	w0, #0x0                   	// #0
    3064:	17ffffee 	b	301c <ipc_submit+0xe0>

0000000000003068 <submit_get>:
{
    3068:	d10943ff 	sub	sp, sp, #0x250
    306c:	a9007bfd 	stp	x29, x30, [sp]
    3070:	910003fd 	mov	x29, sp
    3074:	a90153f3 	stp	x19, x20, [sp, #16]
    3078:	2a0103f3 	mov	w19, w1
    307c:	aa0203f4 	mov	x20, x2
  memset(&request, 0, sizeof(request));
    3080:	52800001 	mov	w1, #0x0                   	// #0
    3084:	52804302 	mov	w2, #0x218                 	// #536
{
    3088:	f90013f5 	str	x21, [sp, #32]
    308c:	aa0003f5 	mov	x21, x0
  memset(&request, 0, sizeof(request));
    3090:	9100e3e0 	add	x0, sp, #0x38
    3094:	97fff6fd 	bl	c88 <memset@plt>
  request.command = IPC_GET;
    3098:	52800040 	mov	w0, #0x2                   	// #2
  return ipc_submit(client, &request, response) < 0 ? -1 : response->status;
    309c:	aa1403e2 	mov	x2, x20
    30a0:	9100e3e1 	add	x1, sp, #0x38
  request.command = IPC_GET;
    30a4:	b9003be0 	str	w0, [sp, #56]
  return ipc_submit(client, &request, response) < 0 ? -1 : response->status;
    30a8:	aa1503e0 	mov	x0, x21
  request.key = key;
    30ac:	b90043f3 	str	w19, [sp, #64]
  return ipc_submit(client, &request, response) < 0 ? -1 : response->status;
    30b0:	97ffffa3 	bl	2f3c <ipc_submit>
    30b4:	350000e0 	cbnz	w0, 30d0 <submit_get+0x68>
    30b8:	b9400280 	ldr	w0, [x20]
}
    30bc:	f94013f5 	ldr	x21, [sp, #32]
    30c0:	a9407bfd 	ldp	x29, x30, [sp]
    30c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30c8:	910943ff 	add	sp, sp, #0x250
    30cc:	d65f03c0 	ret
  return ipc_submit(client, &request, response) < 0 ? -1 : response->status;
    30d0:	12800000 	mov	w0, #0xffffffff            	// #-1
    30d4:	17fffffa 	b	30bc <submit_get+0x54>

00000000000030d8 <submit_simple>:
{
    30d8:	d10943ff 	sub	sp, sp, #0x250
    30dc:	a9007bfd 	stp	x29, x30, [sp]
    30e0:	910003fd 	mov	x29, sp
    30e4:	a90153f3 	stp	x19, x20, [sp, #16]
    30e8:	2a0103f3 	mov	w19, w1
    30ec:	aa0203f4 	mov	x20, x2
  memset(&request, 0, sizeof(request));
    30f0:	52800001 	mov	w1, #0x0                   	// #0
    30f4:	52804302 	mov	w2, #0x218                 	// #536
{
    30f8:	f90013f5 	str	x21, [sp, #32]
    30fc:	aa0003f5 	mov	x21, x0
  memset(&request, 0, sizeof(request));
    3100:	9100e3e0 	add	x0, sp, #0x38
    3104:	97fff6e1 	bl	c88 <memset@plt>
  return ipc_submit(client, &request, response) < 0 ? -1 : response->status;
    3108:	aa1403e2 	mov	x2, x20
    310c:	9100e3e1 	add	x1, sp, #0x38
    3110:	aa1503e0 	mov	x0, x21
  request.command = command;
    3114:	b9003bf3 	str	w19, [sp, #56]
  return ipc_submit(client, &request, response) < 0 ? -1 : response->status;
    3118:	97ffff89 	bl	2f3c <ipc_submit>
    311c:	350000e0 	cbnz	w0, 3138 <submit_simple+0x60>
    3120:	b9400280 	ldr	w0, [x20]
}
    3124:	f94013f5 	ldr	x21, [sp, #32]
    3128:	a9407bfd 	ldp	x29, x30, [sp]
    312c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3130:	910943ff 	add	sp, sp, #0x250
    3134:	d65f03c0 	ret
  return ipc_submit(client, &request, response) < 0 ? -1 : response->status;
    3138:	12800000 	mov	w0, #0xffffffff            	// #-1
    313c:	17fffffa 	b	3124 <submit_simple+0x4c>

0000000000003140 <read_db_header.constprop.0>:
read_db_header(int fd, struct db_header *h)
    3140:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return pread(fd, h, sizeof(*h), 0) == sizeof(*h) && valid_header(h) ? 0 : -1;
    3144:	d2800003 	mov	x3, #0x0                   	// #0
    3148:	52820002 	mov	w2, #0x1000                	// #4096
read_db_header(int fd, struct db_header *h)
    314c:	910003fd 	mov	x29, sp
    3150:	a90153f3 	stp	x19, x20, [sp, #16]
  return pread(fd, h, sizeof(*h), 0) == sizeof(*h) && valid_header(h) ? 0 : -1;
    3154:	90000034 	adrp	x20, 7000 <wal_buffer+0x110>
    3158:	913bc293 	add	x19, x20, #0xef0
    315c:	aa1303e1 	mov	x1, x19
    3160:	97fff6da 	bl	cc8 <pread@plt>
    3164:	7140041f 	cmp	w0, #0x1, lsl #12
    3168:	540000a0 	b.eq	317c <read_db_header.constprop.0+0x3c>  // b.none
    316c:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    3170:	a94153f3 	ldp	x19, x20, [sp, #16]
    3174:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3178:	d65f03c0 	ret
  uint32 got = hash_bytes(h, sizeof(*h));
    317c:	2a0003e1 	mov	w1, w0
  uint32 saved = h->checksum;
    3180:	b9402a66 	ldr	w6, [x19, #40]
  uint32 got = hash_bytes(h, sizeof(*h));
    3184:	aa1303e0 	mov	x0, x19
  h->checksum = 0;
    3188:	b9002a7f 	str	wzr, [x19, #40]
  uint32 got = hash_bytes(h, sizeof(*h));
    318c:	97fffc0e 	bl	21c4 <hash_bytes>
  return h->magic == DB_MAGIC && h->version == DB_VERSION &&
    3190:	d2888841 	mov	x1, #0x4442                	// #17474
    3194:	f2a9ab21 	movk	x1, #0x4d59, lsl #16
  h->checksum = saved;
    3198:	b9002a66 	str	w6, [x19, #40]
  return h->magic == DB_MAGIC && h->version == DB_VERSION &&
    319c:	f9477a82 	ldr	x2, [x20, #3824]
    31a0:	f2c00021 	movk	x1, #0x1, lsl #32
    31a4:	eb01005f 	cmp	x2, x1
    31a8:	54fffe21 	b.ne	316c <read_db_header.constprop.0+0x2c>  // b.any
         h->row_size == sizeof(struct db_row) && h->max_rows == MAX_ROWS &&
    31ac:	f9400662 	ldr	x2, [x19, #8]
    31b0:	d2800801 	mov	x1, #0x40                  	// #64
    31b4:	f2c08001 	movk	x1, #0x400, lsl #32
    31b8:	eb01005f 	cmp	x2, x1
    31bc:	54fffd81 	b.ne	316c <read_db_header.constprop.0+0x2c>  // b.any
    31c0:	6b0000df 	cmp	w6, w0
    31c4:	5a9f03e0 	csetm	w0, ne	// ne = any
  return pread(fd, h, sizeof(*h), 0) == sizeof(*h) && valid_header(h) ? 0 : -1;
    31c8:	17ffffea 	b	3170 <read_db_header.constprop.0+0x30>

00000000000031cc <reload_shared_locked>:
{
    31cc:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  int fd = open(DB_PATH, O_RDONLY);
    31d0:	52800001 	mov	w1, #0x0                   	// #0
{
    31d4:	910003fd 	mov	x29, sp
    31d8:	a90153f3 	stp	x19, x20, [sp, #16]
    31dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31e0:	aa0003f6 	mov	x22, x0
  int fd = open(DB_PATH, O_RDONLY);
    31e4:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    31e8:	9100c000 	add	x0, x0, #0x30
{
    31ec:	a90363f7 	stp	x23, x24, [sp, #48]
  int fd = open(DB_PATH, O_RDONLY);
    31f0:	97fff6ca 	bl	d18 <open@plt>
  if(fd < 0 || read_db_header(fd, &disk_header) < 0){
    31f4:	37f805c0 	tbnz	w0, #31, 32ac <reload_shared_locked+0xe0>
    31f8:	2a0003f4 	mov	w20, w0
    31fc:	d2800015 	mov	x21, #0x0                   	// #0
    3200:	97ffffd0 	bl	3140 <read_db_header.constprop.0>
    3204:	2a0003f3 	mov	w19, w0
    3208:	3100041f 	cmn	w0, #0x1
    320c:	54000180 	b.eq	323c <reload_shared_locked+0x70>  // b.none
    if(read_db_row(fd, i, &db->shm->rows[i]) < 0){
    3210:	52800817 	mov	w23, #0x40                  	// #64
    3214:	d2840818 	mov	x24, #0x2040                	// #8256
    3218:	f94002c0 	ldr	x0, [x22]
    321c:	9bb762a2 	umaddl	x2, w21, w23, x24
    3220:	2a1503e1 	mov	w1, w21
    3224:	8b020002 	add	x2, x0, x2
    3228:	2a1403e0 	mov	w0, w20
    322c:	97fffcc2 	bl	2534 <read_db_row>
    3230:	2a0003f3 	mov	w19, w0
    3234:	3100041f 	cmn	w0, #0x1
    3238:	54000121 	b.ne	325c <reload_shared_locked+0x90>  // b.any
      close(fd);
    323c:	2a1403e0 	mov	w0, w20
    3240:	97fff6ca 	bl	d68 <close@plt>
}
    3244:	2a1303e0 	mov	w0, w19
    3248:	a94153f3 	ldp	x19, x20, [sp, #16]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	a94363f7 	ldp	x23, x24, [sp, #48]
    3254:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3258:	d65f03c0 	ret
  for(uint i = 0; i < MAX_ROWS; i++){
    325c:	910006b5 	add	x21, x21, #0x1
    3260:	f11002bf 	cmp	x21, #0x400
    3264:	54fffda1 	b.ne	3218 <reload_shared_locked+0x4c>  // b.any
  close(fd);
    3268:	2a1403e0 	mov	w0, w20
    326c:	97fff6bf 	bl	d68 <close@plt>
  if(rebuild_index(db->shm) < 0)
    3270:	f94002c0 	ldr	x0, [x22]
    3274:	97fffc55 	bl	23c8 <rebuild_index>
    3278:	2a0003f3 	mov	w19, w0
    327c:	3100041f 	cmn	w0, #0x1
    3280:	54fffe20 	b.eq	3244 <reload_shared_locked+0x78>  // b.none
  db->shm->db_txid = disk_header.txid;
    3284:	90000020 	adrp	x0, 7000 <wal_buffer+0x110>
    3288:	913bc000 	add	x0, x0, #0xef0
    328c:	f94002c1 	ldr	x1, [x22]
  db->shm->nrows = disk_header.nrows;
    3290:	a9410002 	ldp	x2, x0, [x0, #16]
  db->shm->db_txid = disk_header.txid;
    3294:	a9010022 	stp	x2, x0, [x1, #16]
  db->shm->ready = 1;
    3298:	52800020 	mov	w0, #0x1                   	// #1
    329c:	b9000c20 	str	w0, [x1, #12]
  __sync_synchronize();
    32a0:	d5033bbf 	dmb	ish
  return 0;
    32a4:	52800013 	mov	w19, #0x0                   	// #0
    32a8:	17ffffe7 	b	3244 <reload_shared_locked+0x78>
    return -1;
    32ac:	12800013 	mov	w19, #0xffffffff            	// #-1
    32b0:	17ffffe5 	b	3244 <reload_shared_locked+0x78>

00000000000032b4 <check_database>:
{
    32b4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  int fd = open(DB_PATH, O_RDONLY);
    32b8:	52800001 	mov	w1, #0x0                   	// #0
{
    32bc:	910003fd 	mov	x29, sp
    32c0:	a90153f3 	stp	x19, x20, [sp, #16]
    32c4:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c8:	aa0003f6 	mov	x22, x0
  int fd = open(DB_PATH, O_RDONLY);
    32cc:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    32d0:	9100c000 	add	x0, x0, #0x30
    32d4:	97fff691 	bl	d18 <open@plt>
  if(fd < 0 || read_db_header(fd, &disk_header) < 0){
    32d8:	36f800e0 	tbz	w0, #31, 32f4 <check_database+0x40>
    return -1;
    32dc:	12800013 	mov	w19, #0xffffffff            	// #-1
}
    32e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32e4:	2a1303e0 	mov	w0, w19
    32e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    32ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32f0:	d65f03c0 	ret
    32f4:	2a0003f5 	mov	w21, w0
  if(fd < 0 || read_db_header(fd, &disk_header) < 0){
    32f8:	97ffff92 	bl	3140 <read_db_header.constprop.0>
    32fc:	2a0003f3 	mov	w19, w0
    3300:	3100041f 	cmn	w0, #0x1
    3304:	54000081 	b.ne	3314 <check_database+0x60>  // b.any
      close(fd);
    3308:	2a1503e0 	mov	w0, w21
    330c:	97fff697 	bl	d68 <close@plt>
      return -1;
    3310:	17fffff4 	b	32e0 <check_database+0x2c>
    if(read_db_row(fd, i, &disk_row) < 0){
    3314:	f0000002 	adrp	x2, 6000 <pgwire_connection+0x1ba0>
    3318:	913ac042 	add	x2, x2, #0xeb0
  for(uint i = 0; i < MAX_ROWS; i++){
    331c:	52800001 	mov	w1, #0x0                   	// #0
  uint64 count = 0;
    3320:	d2800014 	mov	x20, #0x0                   	// #0
    if(read_db_row(fd, i, &disk_row) < 0){
    3324:	2a1503e0 	mov	w0, w21
    3328:	b9003fe1 	str	w1, [sp, #60]
    332c:	97fffc82 	bl	2534 <read_db_row>
    3330:	2a0003f3 	mov	w19, w0
    3334:	3100041f 	cmn	w0, #0x1
    3338:	b9403fe1 	ldr	w1, [sp, #60]
    333c:	f0000000 	adrp	x0, 6000 <pgwire_connection+0x1ba0>
    3340:	913ac002 	add	x2, x0, #0xeb0
    3344:	540000a1 	b.ne	3358 <check_database+0xa4>  // b.any
      printf("mygres: corrupt row slot=%d\n", i);
    3348:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    334c:	91014800 	add	x0, x0, #0x52
    3350:	97fff606 	bl	b68 <printf@plt>
    3354:	17ffffed 	b	3308 <check_database+0x54>
    if(disk_row.state == ROW_USED)
    3358:	b9400040 	ldr	w0, [x2]
  for(uint i = 0; i < MAX_ROWS; i++){
    335c:	11000421 	add	w1, w1, #0x1
      count++;
    3360:	7100041f 	cmp	w0, #0x1
    3364:	9a941694 	cinc	x20, x20, eq	// eq = none
  for(uint i = 0; i < MAX_ROWS; i++){
    3368:	7110003f 	cmp	w1, #0x400
    336c:	54fffdc1 	b.ne	3324 <check_database+0x70>  // b.any
  close(fd);
    3370:	2a1503e0 	mov	w0, w21
  if(count != disk_header.nrows){
    3374:	90000035 	adrp	x21, 7000 <wal_buffer+0x110>
    3378:	913bc2b5 	add	x21, x21, #0xef0
  close(fd);
    337c:	97fff67b 	bl	d68 <close@plt>
  if(count != disk_header.nrows){
    3380:	f9400ea1 	ldr	x1, [x21, #24]
    3384:	eb14003f 	cmp	x1, x20
    3388:	540000c0 	b.eq	33a0 <check_database+0xec>  // b.none
    printf("mygres: header rows=%l but disk scan found=%l\n",
    338c:	aa1403e2 	mov	x2, x20
    3390:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    3394:	9101bc00 	add	x0, x0, #0x6f
    3398:	97fff5f4 	bl	b68 <printf@plt>
    return -1;
    339c:	17ffffd0 	b	32dc <check_database+0x28>
  shared_lock(&db->shm->lock);
    33a0:	f94002c0 	ldr	x0, [x22]
    33a4:	97fffc55 	bl	24f8 <shared_lock>
  int ok = rebuild_index(db->shm) == 0 && db->shm->nrows == count &&
    33a8:	f94002c0 	ldr	x0, [x22]
    33ac:	97fffc07 	bl	23c8 <rebuild_index>
    33b0:	f94002c1 	ldr	x1, [x22]
    33b4:	340001c0 	cbz	w0, 33ec <check_database+0x138>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    33b8:	52800000 	mov	w0, #0x0                   	// #0
    33bc:	889ffc20 	stlr	w0, [x1]
  printf("mygres: CHECK %s txid=%l rows=%l hash-index=%d buckets\n",
    33c0:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    33c4:	91013421 	add	x1, x1, #0x4d
    33c8:	52800013 	mov	w19, #0x0                   	// #0
    33cc:	f9400aa2 	ldr	x2, [x21, #16]
    33d0:	aa1403e3 	mov	x3, x20
  return ok ? 0 : -1;
    33d4:	51000673 	sub	w19, w19, #0x1
  printf("mygres: CHECK %s txid=%l rows=%l hash-index=%d buckets\n",
    33d8:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    33dc:	91027800 	add	x0, x0, #0x9e
    33e0:	52810004 	mov	w4, #0x800                 	// #2048
    33e4:	97fff5e1 	bl	b68 <printf@plt>
  return ok ? 0 : -1;
    33e8:	17ffffbe 	b	32e0 <check_database+0x2c>
  int ok = rebuild_index(db->shm) == 0 && db->shm->nrows == count &&
    33ec:	f9400c22 	ldr	x2, [x1, #24]
    33f0:	eb14005f 	cmp	x2, x20
    33f4:	54fffe41 	b.ne	33bc <check_database+0x108>  // b.any
           db->shm->db_txid == disk_header.txid;
    33f8:	f9400823 	ldr	x3, [x1, #16]
    33fc:	f9400aa2 	ldr	x2, [x21, #16]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3400:	889ffc20 	stlr	w0, [x1]
  printf("mygres: CHECK %s txid=%l rows=%l hash-index=%d buckets\n",
    3404:	eb02007f 	cmp	x3, x2
    3408:	54fffdc1 	b.ne	33c0 <check_database+0x10c>  // b.any
    340c:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3410:	91012021 	add	x1, x1, #0x48
    3414:	52800033 	mov	w19, #0x1                   	// #1
    3418:	17ffffed 	b	33cc <check_database+0x118>

000000000000341c <write_db_from_wal.constprop.0>:
write_db_from_wal(struct wal_page *w)
    341c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  int fd = open(DB_PATH, O_RDWR);
    3420:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    3424:	9100c000 	add	x0, x0, #0x30
write_db_from_wal(struct wal_page *w)
    3428:	910003fd 	mov	x29, sp
  int fd = open(DB_PATH, O_RDWR);
    342c:	52800041 	mov	w1, #0x2                   	// #2
write_db_from_wal(struct wal_page *w)
    3430:	a90153f3 	stp	x19, x20, [sp, #16]
    3434:	a9025bf5 	stp	x21, x22, [sp, #32]
  int fd = open(DB_PATH, O_RDWR);
    3438:	97fff638 	bl	d18 <open@plt>
  if(fd < 0 || read_db_header(fd, &disk_header) < 0){
    343c:	36f800e0 	tbz	w0, #31, 3458 <write_db_from_wal.constprop.0+0x3c>
    return -1;
    3440:	12800014 	mov	w20, #0xffffffff            	// #-1
}
    3444:	2a1403e0 	mov	w0, w20
    3448:	a94153f3 	ldp	x19, x20, [sp, #16]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3454:	d65f03c0 	ret
    3458:	2a0003f3 	mov	w19, w0
  if(fd < 0 || read_db_header(fd, &disk_header) < 0){
    345c:	97ffff39 	bl	3140 <read_db_header.constprop.0>
    3460:	2a0003f4 	mov	w20, w0
    3464:	3100041f 	cmn	w0, #0x1
    3468:	54000400 	b.eq	34e8 <write_db_from_wal.constprop.0+0xcc>  // b.none
    346c:	f0000014 	adrp	x20, 6000 <pgwire_connection+0x1ba0>
    3470:	913bc294 	add	x20, x20, #0xef0
    3474:	aa1403f5 	mov	x21, x20
  for(uint i = 0; i < w->nops; i++)
    3478:	52800016 	mov	w22, #0x0                   	// #0
    347c:	b9400ea0 	ldr	w0, [x21, #12]
    3480:	6b0002df 	cmp	w22, w0
    3484:	54000383 	b.cc	34f4 <write_db_from_wal.constprop.0+0xd8>  // b.lo, b.ul, b.last
  disk_header.txid = w->txid;
    3488:	90000026 	adrp	x6, 7000 <wal_buffer+0x110>
    348c:	913bc0c6 	add	x6, x6, #0xef0
  disk_header.nrows = w->target_count;
    3490:	a94106a0 	ldp	x0, x1, [x21, #16]
  disk_header.txid = w->txid;
    3494:	a90104c0 	stp	x0, x1, [x6, #16]
  h->checksum = hash_bytes(h, sizeof(*h));
    3498:	52820001 	mov	w1, #0x1000                	// #4096
  disk_header.checkpoint_lsn = w->txid;
    349c:	f90010c0 	str	x0, [x6, #32]
  h->checksum = hash_bytes(h, sizeof(*h));
    34a0:	aa0603e0 	mov	x0, x6
  h->checksum = 0;
    34a4:	b90028df 	str	wzr, [x6, #40]
  h->checksum = hash_bytes(h, sizeof(*h));
    34a8:	97fffb47 	bl	21c4 <hash_bytes>
    34ac:	b90028c0 	str	w0, [x6, #40]
  if(pwrite(fd, &disk_header, sizeof(disk_header), 0) !=
    34b0:	2a0103e2 	mov	w2, w1
    34b4:	2a1303e0 	mov	w0, w19
    34b8:	aa0603e1 	mov	x1, x6
    34bc:	d2800003 	mov	x3, #0x0                   	// #0
    34c0:	97fff626 	bl	d58 <pwrite@plt>
    34c4:	7140041f 	cmp	w0, #0x1, lsl #12
    34c8:	54000281 	b.ne	3518 <write_db_from_wal.constprop.0+0xfc>  // b.any
       sizeof(disk_header) || fsync(fd) < 0){
    34cc:	2a1303e0 	mov	w0, w19
    34d0:	97fff5fa 	bl	cb8 <fsync@plt>
    34d4:	37f80220 	tbnz	w0, #31, 3518 <write_db_from_wal.constprop.0+0xfc>
  close(fd);
    34d8:	2a1303e0 	mov	w0, w19
  return 0;
    34dc:	52800014 	mov	w20, #0x0                   	// #0
  close(fd);
    34e0:	97fff622 	bl	d68 <close@plt>
  return 0;
    34e4:	17ffffd8 	b	3444 <write_db_from_wal.constprop.0+0x28>
      close(fd);
    34e8:	2a1303e0 	mov	w0, w19
    34ec:	97fff61f 	bl	d68 <close@plt>
    34f0:	17ffffd5 	b	3444 <write_db_from_wal.constprop.0+0x28>
  return PAGE_SIZE + (uint64)slot * sizeof(struct db_row);
    34f4:	b9402e83 	ldr	w3, [x20, #44]
    if(pwrite(fd, &w->ops[i].row, sizeof(struct db_row),
    34f8:	9100c281 	add	x1, x20, #0x30
    34fc:	2a1303e0 	mov	w0, w19
    3500:	52800802 	mov	w2, #0x40                  	// #64
  return PAGE_SIZE + (uint64)slot * sizeof(struct db_row);
    3504:	91010063 	add	x3, x3, #0x40
    if(pwrite(fd, &w->ops[i].row, sizeof(struct db_row),
    3508:	d37ae463 	lsl	x3, x3, #6
    350c:	97fff613 	bl	d58 <pwrite@plt>
    3510:	7101001f 	cmp	w0, #0x40
    3514:	54000080 	b.eq	3524 <write_db_from_wal.constprop.0+0x108>  // b.none
    close(fd);
    3518:	2a1303e0 	mov	w0, w19
    351c:	97fff613 	bl	d68 <close@plt>
    return -1;
    3520:	17ffffc8 	b	3440 <write_db_from_wal.constprop.0+0x24>
    if(pwrite(fd, &w->ops[i].row, sizeof(struct db_row),
    3524:	91014294 	add	x20, x20, #0x50
  for(uint i = 0; i < w->nops; i++)
    3528:	110006d6 	add	w22, w22, #0x1
    352c:	17ffffd4 	b	347c <write_db_from_wal.constprop.0+0x60>

0000000000003530 <recover_locked.constprop.0>:
recover_locked(struct database *db, int verbose)
    3530:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  int fd = open(WAL_PATH, O_RDONLY);
    3534:	52800001 	mov	w1, #0x0                   	// #0
recover_locked(struct database *db, int verbose)
    3538:	910003fd 	mov	x29, sp
    353c:	a90153f3 	stp	x19, x20, [sp, #16]
    3540:	a9025bf5 	stp	x21, x22, [sp, #32]
    3544:	aa0003f5 	mov	x21, x0
  int fd = open(WAL_PATH, O_RDONLY);
    3548:	b0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    354c:	913fdc00 	add	x0, x0, #0xff7
    3550:	97fff5f2 	bl	d18 <open@plt>
  if(fd < 0)
    3554:	37f80200 	tbnz	w0, #31, 3594 <recover_locked.constprop.0+0x64>
    3558:	2a0003f4 	mov	w20, w0
  if(fstat(fd, &st) < 0){
    355c:	910123e1 	add	x1, sp, #0x48
    3560:	97fff5ae 	bl	c18 <fstat@plt>
    3564:	36f80100 	tbz	w0, #31, 3584 <recover_locked.constprop.0+0x54>
    close(fd);
    3568:	2a1403e0 	mov	w0, w20
    356c:	97fff5ff 	bl	d68 <close@plt>
    return -1;
    3570:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    3574:	a94153f3 	ldp	x19, x20, [sp, #16]
    3578:	a9425bf5 	ldp	x21, x22, [sp, #32]
    357c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3580:	d65f03c0 	ret
  if(st.size == 0){
    3584:	f9402fe0 	ldr	x0, [sp, #88]
    3588:	b50000a0 	cbnz	x0, 359c <recover_locked.constprop.0+0x6c>
    close(fd);
    358c:	2a1403e0 	mov	w0, w20
    3590:	97fff5f6 	bl	d68 <close@plt>
    return 0;
    3594:	52800000 	mov	w0, #0x0                   	// #0
    3598:	17fffff7 	b	3574 <recover_locked.constprop.0+0x44>
  int n = pread(fd, w, sizeof(*w), 0);
    359c:	f0000016 	adrp	x22, 6000 <pgwire_connection+0x1ba0>
    35a0:	913bc2d3 	add	x19, x22, #0xef0
    35a4:	aa1303e1 	mov	x1, x19
    35a8:	d2800003 	mov	x3, #0x0                   	// #0
    35ac:	52820002 	mov	w2, #0x1000                	// #4096
    35b0:	2a1403e0 	mov	w0, w20
    35b4:	97fff5c5 	bl	cc8 <pread@plt>
    35b8:	2a0003e1 	mov	w1, w0
  close(fd);
    35bc:	2a1403e0 	mov	w0, w20
  int n = pread(fd, w, sizeof(*w), 0);
    35c0:	b9003fe1 	str	w1, [sp, #60]
  close(fd);
    35c4:	97fff5e9 	bl	d68 <close@plt>
  if(n != sizeof(*w) || !valid_wal(w))
    35c8:	b9403fe1 	ldr	w1, [sp, #60]
    35cc:	7140043f 	cmp	w1, #0x1, lsl #12
    35d0:	54000100 	b.eq	35f0 <recover_locked.constprop.0+0xc0>  // b.none
      printf("mygres: discard incomplete/corrupt WAL\n");
    35d4:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    35d8:	91035800 	add	x0, x0, #0xd6
    35dc:	97fff563 	bl	b68 <printf@plt>
}
    35e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    35e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35e8:	a8c67bfd 	ldp	x29, x30, [sp], #96
  return clear_wal();
    35ec:	17fffba3 	b	2478 <clear_wal>
  uint32 saved = w->checksum;
    35f0:	b9402266 	ldr	w6, [x19, #32]
  uint32 got = hash_bytes(w, sizeof(*w));
    35f4:	aa1303e0 	mov	x0, x19
  w->checksum = 0;
    35f8:	b900227f 	str	wzr, [x19, #32]
  uint32 got = hash_bytes(w, sizeof(*w));
    35fc:	97fffaf2 	bl	21c4 <hash_bytes>
  if(w->magic != WAL_MAGIC || w->version != DB_VERSION ||
    3600:	f9477ac2 	ldr	x2, [x22, #3824]
    3604:	d28ae981 	mov	x1, #0x574c                	// #22348
    3608:	f2a9ab21 	movk	x1, #0x4d59, lsl #16
  w->checksum = saved;
    360c:	b9002266 	str	w6, [x19, #32]
  if(w->magic != WAL_MAGIC || w->version != DB_VERSION ||
    3610:	f2c00021 	movk	x1, #0x1, lsl #32
    3614:	eb01005f 	cmp	x2, x1
    3618:	54fffde1 	b.ne	35d4 <recover_locked.constprop.0+0xa4>  // b.any
    361c:	b9400a61 	ldr	w1, [x19, #8]
    3620:	7100043f 	cmp	w1, #0x1
    3624:	54fffd81 	b.ne	35d4 <recover_locked.constprop.0+0xa4>  // b.any
     w->committed != 1 || w->nops > MAX_TX_OPS || saved != got)
    3628:	b9400e69 	ldr	w9, [x19, #12]
    362c:	7100813f 	cmp	w9, #0x20
    3630:	54fffd28 	b.hi	35d4 <recover_locked.constprop.0+0xa4>  // b.pmore
    3634:	6b0000df 	cmp	w6, w0
    3638:	54fffce1 	b.ne	35d4 <recover_locked.constprop.0+0xa4>  // b.any
    363c:	9100c268 	add	x8, x19, #0x30
  for(uint i = 0; i < w->nops; i++)
    3640:	5280000a 	mov	w10, #0x0                   	// #0
    3644:	6b0a013f 	cmp	w9, w10
    3648:	54000281 	b.ne	3698 <recover_locked.constprop.0+0x168>  // b.any
    printf("mygres: WAL REDO tx=%l operations=%d\n",
    364c:	f9400a61 	ldr	x1, [x19, #16]
    3650:	2a0903e2 	mov	w2, w9
    3654:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    3658:	9103f800 	add	x0, x0, #0xfe
    365c:	97fff543 	bl	b68 <printf@plt>
  if(write_db_from_wal(&wal_buffer) < 0)
    3660:	97ffff6f 	bl	341c <write_db_from_wal.constprop.0>
    3664:	3100041f 	cmn	w0, #0x1
    3668:	54fff860 	b.eq	3574 <recover_locked.constprop.0+0x44>  // b.none
  db->shm->ready = 0;
    366c:	f94002a0 	ldr	x0, [x21]
    3670:	b9000c1f 	str	wzr, [x0, #12]
  if(reload_shared_locked(db) < 0)
    3674:	aa1503e0 	mov	x0, x21
    3678:	97fffed5 	bl	31cc <reload_shared_locked>
    367c:	3100041f 	cmn	w0, #0x1
    3680:	54fff7a0 	b.eq	3574 <recover_locked.constprop.0+0x44>  // b.none
  db->shm->recoveries++;
    3684:	f94002a1 	ldr	x1, [x21]
    3688:	f9401420 	ldr	x0, [x1, #40]
    368c:	91000400 	add	x0, x0, #0x1
    3690:	f9001420 	str	x0, [x1, #40]
    3694:	17ffffd3 	b	35e0 <recover_locked.constprop.0+0xb0>
    if(w->ops[i].slot >= MAX_ROWS ||
    3698:	b85fc100 	ldur	w0, [x8, #-4]
    369c:	710ffc1f 	cmp	w0, #0x3ff
    36a0:	54fff9a8 	b.hi	35d4 <recover_locked.constprop.0+0xa4>  // b.pmore
       (w->ops[i].type != OP_PUT && w->ops[i].type != OP_DELETE) ||
    36a4:	b85f8100 	ldur	w0, [x8, #-8]
    36a8:	51000400 	sub	w0, w0, #0x1
    if(w->ops[i].slot >= MAX_ROWS ||
    36ac:	7100041f 	cmp	w0, #0x1
    36b0:	54fff928 	b.hi	35d4 <recover_locked.constprop.0+0xa4>  // b.pmore
       !valid_row(&w->ops[i].row))
    36b4:	aa0803e0 	mov	x0, x8
    36b8:	97fffad0 	bl	21f8 <valid_row>
       (w->ops[i].type != OP_PUT && w->ops[i].type != OP_DELETE) ||
    36bc:	34fff8c0 	cbz	w0, 35d4 <recover_locked.constprop.0+0xa4>
    36c0:	91014108 	add	x8, x8, #0x50
  for(uint i = 0; i < w->nops; i++)
    36c4:	1100054a 	add	w10, w10, #0x1
    36c8:	17ffffdf 	b	3644 <recover_locked.constprop.0+0x114>

00000000000036cc <ensure_directories.isra.0>:
ensure_directories(void)
    36cc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  mkdir("/var");
    36d0:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    36d4:	91049000 	add	x0, x0, #0x124
ensure_directories(void)
    36d8:	910003fd 	mov	x29, sp
  mkdir("/var");
    36dc:	97fff59b 	bl	d48 <mkdir@plt>
  mkdir("/var/lib");
    36e0:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    36e4:	9104a400 	add	x0, x0, #0x129
    36e8:	97fff598 	bl	d48 <mkdir@plt>
  mkdir("/var/run");
    36ec:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    36f0:	9104c800 	add	x0, x0, #0x132
    36f4:	97fff595 	bl	d48 <mkdir@plt>
}
    36f8:	a8c17bfd 	ldp	x29, x30, [sp], #16
  mkdir(DB_DIR);
    36fc:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    3700:	9104ec00 	add	x0, x0, #0x13b
    3704:	17fff591 	b	d48 <mkdir@plt>

0000000000003708 <submit_one>:
{
    3708:	d11203ff 	sub	sp, sp, #0x480
    370c:	a9007bfd 	stp	x29, x30, [sp]
    3710:	910003fd 	mov	x29, sp
    3714:	a90153f3 	stp	x19, x20, [sp, #16]
    3718:	aa0003f4 	mov	x20, x0
    371c:	aa0503f3 	mov	x19, x5
  memset(&tx, 0, sizeof(tx));
    3720:	910163e0 	add	x0, sp, #0x58
{
    3724:	a9025bf5 	stp	x21, x22, [sp, #32]
    3728:	2a0103f6 	mov	w22, w1
    372c:	2a0403f5 	mov	w21, w4
  memset(&tx, 0, sizeof(tx));
    3730:	52800001 	mov	w1, #0x0                   	// #0
{
    3734:	f9001bf7 	str	x23, [sp, #48]
    3738:	2a0203f7 	mov	w23, w2
  memset(&tx, 0, sizeof(tx));
    373c:	52804202 	mov	w2, #0x210                 	// #528
{
    3740:	f90027e3 	str	x3, [sp, #72]
  memset(&tx, 0, sizeof(tx));
    3744:	97fff551 	bl	c88 <memset@plt>
  tx.active = 1;
    3748:	f94027e3 	ldr	x3, [sp, #72]
    374c:	52800020 	mov	w0, #0x1                   	// #1
    3750:	2a1703e2 	mov	w2, w23
    3754:	2a1603e1 	mov	w1, w22
    3758:	b9005be0 	str	w0, [sp, #88]
  for(uint i = 0; i < tx->nops; i++)
    375c:	910163e0 	add	x0, sp, #0x58
    3760:	97fffd40 	bl	2c60 <tx_stage.part.0>
  if(tx_stage(&tx, type, key, value) < 0)
    3764:	3100041f 	cmn	w0, #0x1
    3768:	54000300 	b.eq	37c8 <submit_one+0xc0>  // b.none
  memset(&request, 0, sizeof(request));
    376c:	52804302 	mov	w2, #0x218                 	// #536
    3770:	52800001 	mov	w1, #0x0                   	// #0
    3774:	9109a3e0 	add	x0, sp, #0x268
    3778:	97fff544 	bl	c88 <memset@plt>
  request.command = wal_only ? IPC_PREPARE : IPC_COMMIT;
    377c:	710002bf 	cmp	w21, #0x0
    3780:	52800101 	mov	w1, #0x8                   	// #8
    3784:	52800060 	mov	w0, #0x3                   	// #3
    3788:	1a810000 	csel	w0, w0, w1, eq	// eq = none
  request.nops = tx->nops;
    378c:	b9405fe3 	ldr	w3, [sp, #92]
    3790:	9109a3e2 	add	x2, sp, #0x268
  request.command = wal_only ? IPC_PREPARE : IPC_COMMIT;
    3794:	b9026be0 	str	w0, [sp, #616]
  request.nops = tx->nops;
    3798:	910163e0 	add	x0, sp, #0x58
  for(uint i = 0; i < tx->nops; i++)
    379c:	52800001 	mov	w1, #0x0                   	// #0
  request.nops = tx->nops;
    37a0:	b9026fe3 	str	w3, [sp, #620]
  for(uint i = 0; i < tx->nops; i++)
    37a4:	6b01007f 	cmp	w3, w1
    37a8:	540001c1 	b.ne	37e0 <submit_one+0xd8>  // b.any
  if(ipc_submit(client, &request, response) < 0)
    37ac:	aa1303e2 	mov	x2, x19
    37b0:	9109a3e1 	add	x1, sp, #0x268
    37b4:	aa1403e0 	mov	x0, x20
    37b8:	97fffde1 	bl	2f3c <ipc_submit>
    37bc:	3100041f 	cmn	w0, #0x1
    37c0:	54000040 	b.eq	37c8 <submit_one+0xc0>  // b.none
  return response->status;
    37c4:	b9400260 	ldr	w0, [x19]
}
    37c8:	f9401bf7 	ldr	x23, [sp, #48]
    37cc:	a9407bfd 	ldp	x29, x30, [sp]
    37d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    37d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    37d8:	911203ff 	add	sp, sp, #0x480
    37dc:	d65f03c0 	ret
  for(uint i = 0; i < tx->nops; i++)
    37e0:	91004042 	add	x2, x2, #0x10
    37e4:	11000421 	add	w1, w1, #0x1
    request.ops[i] = tx->ops[i];
    37e8:	a9c11404 	ldp	x4, x5, [x0, #16]!
    37ec:	a9009444 	stp	x4, x5, [x2, #8]
  for(uint i = 0; i < tx->nops; i++)
    37f0:	17ffffed 	b	37a4 <submit_one+0x9c>

00000000000037f4 <pg_contains>:
  for(; *text; text++){
    37f4:	39400002 	ldrb	w2, [x0]
    37f8:	35000062 	cbnz	w2, 3804 <pg_contains+0x10>
  return 0;
    37fc:	52800000 	mov	w0, #0x0                   	// #0
}
    3800:	d65f03c0 	ret
  for(; *text; text++){
    3804:	d2800003 	mov	x3, #0x0                   	// #0
    while(*b && pg_lower(*a) == pg_lower(*b)){
    3808:	38636824 	ldrb	w4, [x1, x3]
    380c:	340001e4 	cbz	w4, 3848 <pg_contains+0x54>
    3810:	38636802 	ldrb	w2, [x0, x3]
    3814:	91000463 	add	x3, x3, #0x1
  return c >= 'A' && c <= 'Z' ? c + ('a' - 'A') : c;
    3818:	51010446 	sub	w6, w2, #0x41
    381c:	11008045 	add	w5, w2, #0x20
    3820:	710068df 	cmp	w6, #0x1a
    3824:	51010486 	sub	w6, w4, #0x41
    3828:	1a8230a2 	csel	w2, w5, w2, cc	// cc = lo, ul, last
    382c:	11008085 	add	w5, w4, #0x20
    3830:	710068df 	cmp	w6, #0x1a
    3834:	1a8430a4 	csel	w4, w5, w4, cc	// cc = lo, ul, last
    while(*b && pg_lower(*a) == pg_lower(*b)){
    3838:	6b02009f 	cmp	w4, w2
    383c:	54fffe60 	b.eq	3808 <pg_contains+0x14>  // b.none
  for(; *text; text++){
    3840:	91000400 	add	x0, x0, #0x1
    3844:	17ffffec 	b	37f4 <pg_contains>
      return 1;
    3848:	52800020 	mov	w0, #0x1                   	// #1
    384c:	17ffffed 	b	3800 <pg_contains+0xc>

0000000000003850 <pg_starts_with>:
{
    3850:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  while(*prefix)
    3854:	d2800004 	mov	x4, #0x0                   	// #0
{
    3858:	aa0103e6 	mov	x6, x1
    385c:	910003fd 	mov	x29, sp
  text = pg_skip_space(text);
    3860:	97fffa9c 	bl	22d0 <pg_skip_space>
  while(*prefix)
    3864:	386468c3 	ldrb	w3, [x6, x4]
    3868:	35000083 	cbnz	w3, 3878 <pg_starts_with+0x28>
  return 1;
    386c:	52800020 	mov	w0, #0x1                   	// #1
}
    3870:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3874:	d65f03c0 	ret
    if(pg_lower(*text++) != pg_lower(*prefix++))
    3878:	38646802 	ldrb	w2, [x0, x4]
    387c:	91000484 	add	x4, x4, #0x1
  return c >= 'A' && c <= 'Z' ? c + ('a' - 'A') : c;
    3880:	51010445 	sub	w5, w2, #0x41
    3884:	11008041 	add	w1, w2, #0x20
    3888:	710068bf 	cmp	w5, #0x1a
    388c:	11008065 	add	w5, w3, #0x20
    3890:	1a823022 	csel	w2, w1, w2, cc	// cc = lo, ul, last
    3894:	51010461 	sub	w1, w3, #0x41
    3898:	7100683f 	cmp	w1, #0x1a
    389c:	1a8330a3 	csel	w3, w5, w3, cc	// cc = lo, ul, last
    if(pg_lower(*text++) != pg_lower(*prefix++))
    38a0:	6b02007f 	cmp	w3, w2
    38a4:	54fffe00 	b.eq	3864 <pg_starts_with+0x14>  // b.none
      return 0;
    38a8:	52800000 	mov	w0, #0x0                   	// #0
    38ac:	17fffff1 	b	3870 <pg_starts_with+0x20>

00000000000038b0 <pg_describe_query>:
{
    38b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    38b4:	aa0103e7 	mov	x7, x1
    38b8:	2a0003e8 	mov	w8, w0
    38bc:	910003fd 	mov	x29, sp
  if(pg_starts_with(sql, "select") && pg_contains(sql, "from kv")){
    38c0:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    38c4:	91055021 	add	x1, x1, #0x154
    38c8:	aa0703e0 	mov	x0, x7
    38cc:	97ffffe1 	bl	3850 <pg_starts_with>
    38d0:	34000340 	cbz	w0, 3938 <pg_describe_query+0x88>
    38d4:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    38d8:	91056c21 	add	x1, x1, #0x15b
    38dc:	aa0703e0 	mov	x0, x7
    38e0:	97ffffc5 	bl	37f4 <pg_contains>
    38e4:	34000340 	cbz	w0, 394c <pg_describe_query+0x9c>
    char *names[2] = { "key", "value" };
    38e8:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    38ec:	910a3800 	add	x0, x0, #0x28e
    38f0:	f90013e0 	str	x0, [sp, #32]
    38f4:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    38f8:	9100a800 	add	x0, x0, #0x2a
    38fc:	f90017e0 	str	x0, [sp, #40]
    uint32 oids[2] = { 23, 20 };
    3900:	d28002e0 	mov	x0, #0x17                  	// #23
    return pg_send_row_description(fd, 2, names, oids, widths);
    3904:	910043e4 	add	x4, sp, #0x10
    uint32 oids[2] = { 23, 20 };
    3908:	f2c00280 	movk	x0, #0x14, lsl #32
    return pg_send_row_description(fd, 2, names, oids, widths);
    390c:	910063e3 	add	x3, sp, #0x18
    3910:	910083e2 	add	x2, sp, #0x20
    3914:	52800041 	mov	w1, #0x2                   	// #2
    uint32 oids[2] = { 23, 20 };
    3918:	f9000fe0 	str	x0, [sp, #24]
    uint16 widths[2] = { 4, 8 };
    391c:	52800080 	mov	w0, #0x4                   	// #4
    3920:	72a00100 	movk	w0, #0x8, lsl #16
    3924:	b90013e0 	str	w0, [sp, #16]
    return pg_send_row_description(fd, 1, names, oids, widths);
    3928:	2a0803e0 	mov	w0, w8
    392c:	97fffbba 	bl	2814 <pg_send_row_description>
}
    3930:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3934:	d65f03c0 	ret
  if(pg_starts_with(sql, "select") || pg_starts_with(sql, "show")){
    3938:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    393c:	91058c21 	add	x1, x1, #0x163
    3940:	aa0703e0 	mov	x0, x7
    3944:	97ffffc3 	bl	3850 <pg_starts_with>
    3948:	340002a0 	cbz	w0, 399c <pg_describe_query+0xec>
    char *names[1] = { pg_contains(sql, "version()") ? "version" : "?column?" };
    394c:	aa0703e0 	mov	x0, x7
    3950:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3954:	9105a021 	add	x1, x1, #0x168
    3958:	97ffffa7 	bl	37f4 <pg_contains>
    395c:	d0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    3960:	910e8c42 	add	x2, x2, #0x3a3
    3964:	7100001f 	cmp	w0, #0x0
    3968:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    396c:	91052c21 	add	x1, x1, #0x14b
    uint32 oids[1] = { 25 };
    3970:	52800320 	mov	w0, #0x19                  	// #25
    char *names[1] = { pg_contains(sql, "version()") ? "version" : "?column?" };
    3974:	9a820021 	csel	x1, x1, x2, eq	// eq = none
    return pg_send_row_description(fd, 1, names, oids, widths);
    3978:	910043e4 	add	x4, sp, #0x10
    397c:	910063e3 	add	x3, sp, #0x18
    3980:	910083e2 	add	x2, sp, #0x20
    uint32 oids[1] = { 25 };
    3984:	b9001be0 	str	w0, [sp, #24]
    uint16 widths[1] = { 0xffff };
    3988:	12800000 	mov	w0, #0xffffffff            	// #-1
    398c:	790023e0 	strh	w0, [sp, #16]
    char *names[1] = { pg_contains(sql, "version()") ? "version" : "?column?" };
    3990:	f90013e1 	str	x1, [sp, #32]
    return pg_send_row_description(fd, 1, names, oids, widths);
    3994:	52800021 	mov	w1, #0x1                   	// #1
    3998:	17ffffe4 	b	3928 <pg_describe_query+0x78>
}
    399c:	a8c37bfd 	ldp	x29, x30, [sp], #48
  return pg_send(fd, 'n', 0, 0);          // NoData
    39a0:	2a0803e0 	mov	w0, w8
    39a4:	52800003 	mov	w3, #0x0                   	// #0
    39a8:	d2800002 	mov	x2, #0x0                   	// #0
    39ac:	52800dc1 	mov	w1, #0x6e                  	// #110
    39b0:	17fffb45 	b	26c4 <pg_send>

00000000000039b4 <index_lookup>:
  key ^= key >> 16;
    39b4:	4a414023 	eor	w3, w1, w1, lsr #16
  key *= 0x7feb352dU;
    39b8:	5286a5a4 	mov	w4, #0x352d                	// #13613
    39bc:	72affd64 	movk	w4, #0x7feb, lsl #16
  for(uint probe = 0; probe < INDEX_SIZE; probe++){
    39c0:	52800005 	mov	w5, #0x0                   	// #0
  key *= 0x7feb352dU;
    39c4:	1b047c63 	mul	w3, w3, w4
  key *= 0x846ca68bU;
    39c8:	5294d164 	mov	w4, #0xa68b                	// #42635
    39cc:	72b08d84 	movk	w4, #0x846c, lsl #16
  key ^= key >> 15;
    39d0:	4a433c63 	eor	w3, w3, w3, lsr #15
  key *= 0x846ca68bU;
    39d4:	1b047c63 	mul	w3, w3, w4
  key ^= key >> 16;
    39d8:	4a434063 	eor	w3, w3, w3, lsr #16
    uint pos = (start + probe) % INDEX_SIZE;
    39dc:	0b0300a4 	add	w4, w5, w3
    uint entry = s->index[pos];
    39e0:	92402884 	and	x4, x4, #0x7ff
    39e4:	91004084 	add	x4, x4, #0x10
    39e8:	b8647804 	ldr	w4, [x0, x4, lsl #2]
    if(entry == 0){
    39ec:	350000e4 	cbnz	w4, 3a08 <index_lookup+0x54>
      if(account)
    39f0:	34000082 	cbz	w2, 3a00 <index_lookup+0x4c>
        s->index_misses++;
    39f4:	f9401c01 	ldr	x1, [x0, #56]
    39f8:	91000421 	add	x1, x1, #0x1
    39fc:	f9001c01 	str	x1, [x0, #56]
      return -1;
    3a00:	12800000 	mov	w0, #0xffffffff            	// #-1
    3a04:	14000011 	b	3a48 <index_lookup+0x94>
    uint slot = entry - 1;
    3a08:	51000484 	sub	w4, w4, #0x1
    if(slot < MAX_ROWS && s->rows[slot].state == ROW_USED &&
    3a0c:	710ffc9f 	cmp	w4, #0x3ff
    3a10:	540001e8 	b.hi	3a4c <index_lookup+0x98>  // b.pmore
    3a14:	d37a7c86 	ubfiz	x6, x4, #6, #32
    3a18:	8b060006 	add	x6, x0, x6
    3a1c:	b96040c7 	ldr	w7, [x6, #8256]
    3a20:	710004ff 	cmp	w7, #0x1
    3a24:	54000141 	b.ne	3a4c <index_lookup+0x98>  // b.any
    3a28:	b96044c6 	ldr	w6, [x6, #8260]
    3a2c:	6b0100df 	cmp	w6, w1
    3a30:	540000e1 	b.ne	3a4c <index_lookup+0x98>  // b.any
      if(account)
    3a34:	34000082 	cbz	w2, 3a44 <index_lookup+0x90>
        s->index_hits++;
    3a38:	f9401801 	ldr	x1, [x0, #48]
    3a3c:	91000421 	add	x1, x1, #0x1
    3a40:	f9001801 	str	x1, [x0, #48]
      return slot;
    3a44:	2a0403e0 	mov	w0, w4
}
    3a48:	d65f03c0 	ret
  for(uint probe = 0; probe < INDEX_SIZE; probe++){
    3a4c:	110004a5 	add	w5, w5, #0x1
    3a50:	712000bf 	cmp	w5, #0x800
    3a54:	54fffc41 	b.ne	39dc <index_lookup+0x28>  // b.any
    3a58:	17ffffe6 	b	39f0 <index_lookup+0x3c>

0000000000003a5c <tx_commit>:
{
    3a5c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3a60:	910003fd 	mov	x29, sp
    3a64:	a90153f3 	stp	x19, x20, [sp, #16]
    3a68:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a6c:	aa0103f6 	mov	x22, x1
    3a70:	a90363f7 	stp	x23, x24, [sp, #48]
    3a74:	a9046bf9 	stp	x25, x26, [sp, #64]
    3a78:	a90573fb 	stp	x27, x28, [sp, #80]
  if(!tx->active)
    3a7c:	b9400021 	ldr	w1, [x1]
    3a80:	35000141 	cbnz	w1, 3aa8 <tx_commit+0x4c>
    return -1;
    3a84:	12800013 	mov	w19, #0xffffffff            	// #-1
}
    3a88:	2a1303e0 	mov	w0, w19
    3a8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a90:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3a94:	a94363f7 	ldp	x23, x24, [sp, #48]
    3a98:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3a9c:	a94573fb 	ldp	x27, x28, [sp, #80]
    3aa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3aa4:	d65f03c0 	ret
    3aa8:	aa0003f5 	mov	x21, x0
  shared_lock(&db->shm->lock);
    3aac:	2a0203f8 	mov	w24, w2
    3ab0:	f9400000 	ldr	x0, [x0]
    3ab4:	97fffa91 	bl	24f8 <shared_lock>
  if(recover_locked(db, 1) < 0){
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	97fffe9d 	bl	3530 <recover_locked.constprop.0>
    3ac0:	2a0003f3 	mov	w19, w0
    3ac4:	3100041f 	cmn	w0, #0x1
    3ac8:	540000a1 	b.ne	3adc <tx_commit+0x80>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3acc:	f94002a1 	ldr	x1, [x21]
    3ad0:	52800000 	mov	w0, #0x0                   	// #0
    3ad4:	889ffc20 	stlr	w0, [x1]
    return -1;
    3ad8:	17ffffec 	b	3a88 <tx_commit+0x2c>
  memset(&wal_buffer, 0, sizeof(wal_buffer));
    3adc:	f0000013 	adrp	x19, 6000 <pgwire_connection+0x1ba0>
    3ae0:	913bc274 	add	x20, x19, #0xef0
    3ae4:	52800001 	mov	w1, #0x0                   	// #0
    3ae8:	aa1403e0 	mov	x0, x20
    3aec:	52820002 	mov	w2, #0x1000                	// #4096
    3af0:	97fff466 	bl	c88 <memset@plt>
  wal_buffer.magic = WAL_MAGIC;
    3af4:	d28ae980 	mov	x0, #0x574c                	// #22348
    3af8:	f2a9ab20 	movk	x0, #0x4d59, lsl #16
    3afc:	f2c00020 	movk	x0, #0x1, lsl #32
    3b00:	f9077a60 	str	x0, [x19, #3824]
  wal_buffer.committed = 1;
    3b04:	52800020 	mov	w0, #0x1                   	// #1
    3b08:	b9000a80 	str	w0, [x20, #8]
  wal_buffer.txid = db->shm->db_txid + 1;
    3b0c:	f94002a0 	ldr	x0, [x21]
  for(uint i = 0; i < tx->nops; i++){
    3b10:	5280001c 	mov	w28, #0x0                   	// #0
    wo->type = op->type;
    3b14:	d2800a19 	mov	x25, #0x50                  	// #80
    memset(&wo->row, 0, sizeof(wo->row));
    3b18:	d280061a 	mov	x26, #0x30                  	// #48
  wal_buffer.target_count = db->shm->nrows;
    3b1c:	a9410400 	ldp	x0, x1, [x0, #16]
  wal_buffer.txid = db->shm->db_txid + 1;
    3b20:	91000400 	add	x0, x0, #0x1
  wal_buffer.target_count = db->shm->nrows;
    3b24:	a9010680 	stp	x0, x1, [x20, #16]
  for(uint i = 0; i < tx->nops; i++){
    3b28:	b94006c0 	ldr	w0, [x22, #4]
  if(wal_buffer.nops == 0){
    3b2c:	b9400e88 	ldr	w8, [x20, #12]
  for(uint i = 0; i < tx->nops; i++){
    3b30:	6b1c001f 	cmp	w0, w28
    3b34:	540000e8 	b.hi	3b50 <tx_commit+0xf4>  // b.pmore
  if(wal_buffer.nops == 0){
    3b38:	35000b68 	cbnz	w8, 3ca4 <tx_commit+0x248>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3b3c:	f94002a0 	ldr	x0, [x21]
    tx->active = 0;
    3b40:	b90002df 	str	wzr, [x22]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3b44:	889ffc08 	stlr	w8, [x0]
    return 0;
    3b48:	52800013 	mov	w19, #0x0                   	// #0
  return 0;
    3b4c:	17ffffcf 	b	3a88 <tx_commit+0x2c>
    int slot = index_lookup(db->shm, op->key, 0);
    3b50:	8b3c52db 	add	x27, x22, w28, uxtw #4
    3b54:	52800002 	mov	w2, #0x0                   	// #0
    3b58:	f94002a9 	ldr	x9, [x21]
    3b5c:	b9401761 	ldr	w1, [x27, #20]
    3b60:	aa0903e0 	mov	x0, x9
    3b64:	97ffff94 	bl	39b4 <index_lookup>
    3b68:	2a0003f3 	mov	w19, w0
    if(op->type == OP_DELETE && slot < 0)
    3b6c:	b9401361 	ldr	w1, [x27, #16]
    3b70:	7100083f 	cmp	w1, #0x2
    3b74:	540000a1 	b.ne	3b88 <tx_commit+0x12c>  // b.any
    3b78:	3100041f 	cmn	w0, #0x1
    3b7c:	540008e1 	b.ne	3c98 <tx_commit+0x23c>  // b.any
  for(uint i = 0; i < tx->nops; i++){
    3b80:	1100079c 	add	w28, w28, #0x1
    3b84:	17ffffe9 	b	3b28 <tx_commit+0xcc>
    if(op->type == OP_PUT && slot < 0){
    3b88:	7100043f 	cmp	w1, #0x1
    3b8c:	54000321 	b.ne	3bf0 <tx_commit+0x194>  // b.any
    3b90:	3100041f 	cmn	w0, #0x1
    3b94:	540002e1 	b.ne	3bf0 <tx_commit+0x194>  // b.any
    if(s->rows[i].state == ROW_FREE)
    3b98:	d2840802 	mov	x2, #0x2040                	// #8256
    3b9c:	8b020124 	add	x4, x9, x2
    if(op->type == OP_PUT && slot < 0){
    3ba0:	d2800000 	mov	x0, #0x0                   	// #0
    3ba4:	2a0003e5 	mov	w5, w0
    3ba8:	aa1403e3 	mov	x3, x20
    for(uint j = 0; j < pending->nops; j++)
    3bac:	52800002 	mov	w2, #0x0                   	// #0
    3bb0:	14000006 	b	3bc8 <tx_commit+0x16c>
      if(pending->ops[j].slot == i){
    3bb4:	b9402c66 	ldr	w6, [x3, #44]
    3bb8:	91014063 	add	x3, x3, #0x50
    3bbc:	6b0500df 	cmp	w6, w5
    3bc0:	54000560 	b.eq	3c6c <tx_commit+0x210>  // b.none
    for(uint j = 0; j < pending->nops; j++)
    3bc4:	11000442 	add	w2, w2, #0x1
    3bc8:	6b08005f 	cmp	w2, w8
    3bcc:	54ffff41 	b.ne	3bb4 <tx_commit+0x158>  // b.any
    if(s->rows[i].state == ROW_FREE)
    3bd0:	d37a7c02 	ubfiz	x2, x0, #6, #32
    3bd4:	b8626882 	ldr	w2, [x4, x2]
    3bd8:	35000422 	cbnz	w2, 3c5c <tx_commit+0x200>
      return tomb >= 0 ? tomb : (int)i;
    3bdc:	3100067f 	cmn	w19, #0x1
    3be0:	1a801273 	csel	w19, w19, w0, ne	// ne = any
      wal_buffer.target_count++;
    3be4:	f9400e80 	ldr	x0, [x20, #24]
    3be8:	91000400 	add	x0, x0, #0x1
      wal_buffer.target_count--;
    3bec:	f9000e80 	str	x0, [x20, #24]
    wo->type = op->type;
    3bf0:	2a0803f7 	mov	w23, w8
    struct wal_op *wo = &wal_buffer.ops[wal_buffer.nops++];
    3bf4:	11000500 	add	w0, w8, #0x1
    memset(&wo->row, 0, sizeof(wo->row));
    3bf8:	9bb96908 	umaddl	x8, w8, w25, x26
    struct wal_op *wo = &wal_buffer.ops[wal_buffer.nops++];
    3bfc:	b9000e80 	str	w0, [x20, #12]
    memset(&wo->row, 0, sizeof(wo->row));
    3c00:	52800802 	mov	w2, #0x40                  	// #64
    wo->type = op->type;
    3c04:	9b1952f7 	madd	x23, x23, x25, x20
    3c08:	29054ee1 	stp	w1, w19, [x23, #40]
    memset(&wo->row, 0, sizeof(wo->row));
    3c0c:	8b080293 	add	x19, x20, x8
    3c10:	52800001 	mov	w1, #0x0                   	// #0
    3c14:	aa1303e0 	mov	x0, x19
    3c18:	97fff41c 	bl	c88 <memset@plt>
    wo->row.state = op->type == OP_PUT ? ROW_USED : ROW_TOMB;
    3c1c:	b9401360 	ldr	w0, [x27, #16]
    3c20:	52800041 	mov	w1, #0x2                   	// #2
    3c24:	7100041f 	cmp	w0, #0x1
    3c28:	1a810000 	csel	w0, w0, w1, eq	// eq = none
    3c2c:	b90032e0 	str	w0, [x23, #48]
    wo->row.key = op->key;
    3c30:	b9401760 	ldr	w0, [x27, #20]
    wo->row.txid = wal_buffer.txid;
    3c34:	f9400a81 	ldr	x1, [x20, #16]
    wo->row.key = op->key;
    3c38:	b90036e0 	str	w0, [x23, #52]
    wo->row.value = op->value;
    3c3c:	f9400f60 	ldr	x0, [x27, #24]
    wo->row.txid = wal_buffer.txid;
    3c40:	a90386e0 	stp	x0, x1, [x23, #56]
  r->checksum = hash_bytes(r, sizeof(*r));
    3c44:	aa1303e0 	mov	x0, x19
    3c48:	52800801 	mov	w1, #0x40                  	// #64
  r->checksum = 0;
    3c4c:	b9004aff 	str	wzr, [x23, #72]
  r->checksum = hash_bytes(r, sizeof(*r));
    3c50:	97fff95d 	bl	21c4 <hash_bytes>
    3c54:	b9004ae0 	str	w0, [x23, #72]
    3c58:	17ffffca 	b	3b80 <tx_commit+0x124>
    if(s->rows[i].state == ROW_TOMB && tomb < 0)
    3c5c:	7100085f 	cmp	w2, #0x2
    3c60:	54000061 	b.ne	3c6c <tx_commit+0x210>  // b.any
      tomb = i;
    3c64:	3100067f 	cmn	w19, #0x1
    3c68:	1a801273 	csel	w19, w19, w0, ne	// ne = any
  for(uint i = 0; i < MAX_ROWS; i++){
    3c6c:	91000400 	add	x0, x0, #0x1
    3c70:	f110001f 	cmp	x0, #0x400
    3c74:	54fff981 	b.ne	3ba4 <tx_commit+0x148>  // b.any
      if(slot < 0){
    3c78:	3100067f 	cmn	w19, #0x1
    3c7c:	54fffb41 	b.ne	3be4 <tx_commit+0x188>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3c80:	52800000 	mov	w0, #0x0                   	// #0
    3c84:	889ffd20 	stlr	w0, [x9]
        printf("mygres: table is full\n");
    3c88:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    3c8c:	9105c800 	add	x0, x0, #0x172
    3c90:	97fff3b6 	bl	b68 <printf@plt>
        return -1;
    3c94:	17ffff7d 	b	3a88 <tx_commit+0x2c>
      wal_buffer.target_count--;
    3c98:	f9400e80 	ldr	x0, [x20, #24]
    3c9c:	d1000400 	sub	x0, x0, #0x1
    3ca0:	17ffffd3 	b	3bec <tx_commit+0x190>
  w->checksum = hash_bytes(w, sizeof(*w));
    3ca4:	52820001 	mov	w1, #0x1000                	// #4096
    3ca8:	aa1403e0 	mov	x0, x20
  w->checksum = 0;
    3cac:	b900229f 	str	wzr, [x20, #32]
  w->checksum = hash_bytes(w, sizeof(*w));
    3cb0:	97fff945 	bl	21c4 <hash_bytes>
  int fd = open(WAL_PATH, O_CREATE | O_RDWR | O_TRUNC);
    3cb4:	5280c041 	mov	w1, #0x602                 	// #1538
  w->checksum = hash_bytes(w, sizeof(*w));
    3cb8:	b9002280 	str	w0, [x20, #32]
  int fd = open(WAL_PATH, O_CREATE | O_RDWR | O_TRUNC);
    3cbc:	b0000000 	adrp	x0, 4000 <pg_execute_query+0x188>
    3cc0:	913fdc00 	add	x0, x0, #0xff7
    3cc4:	97fff415 	bl	d18 <open@plt>
    3cc8:	2a0003f3 	mov	w19, w0
  if(fd < 0)
    3ccc:	37f80380 	tbnz	w0, #31, 3d3c <tx_commit+0x2e0>
  int ok = pwrite(fd, w, sizeof(*w), 0) == sizeof(*w) && fsync(fd) == 0;
    3cd0:	aa1403e1 	mov	x1, x20
    3cd4:	d2800003 	mov	x3, #0x0                   	// #0
    3cd8:	52820002 	mov	w2, #0x1000                	// #4096
    3cdc:	97fff41f 	bl	d58 <pwrite@plt>
    3ce0:	7140041f 	cmp	w0, #0x1, lsl #12
    3ce4:	54000281 	b.ne	3d34 <tx_commit+0x2d8>  // b.any
    3ce8:	2a1303e0 	mov	w0, w19
    3cec:	97fff3f3 	bl	cb8 <fsync@plt>
    3cf0:	7100001f 	cmp	w0, #0x0
    3cf4:	1a9f17f7 	cset	w23, eq	// eq = none
  close(fd);
    3cf8:	2a1303e0 	mov	w0, w19
    3cfc:	97fff41b 	bl	d68 <close@plt>
  return ok ? 0 : -1;
    3d00:	340001f7 	cbz	w23, 3d3c <tx_commit+0x2e0>
  if(wal_only){
    3d04:	34000258 	cbz	w24, 3d4c <tx_commit+0x2f0>
    printf("mygres: WAL durable tx=%l operations=%d; DB pages not written\n",
    3d08:	f9400a81 	ldr	x1, [x20, #16]
    3d0c:	d0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    3d10:	91062400 	add	x0, x0, #0x189
    3d14:	b9400e82 	ldr	w2, [x20, #12]
    3d18:	97fff394 	bl	b68 <printf@plt>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3d1c:	f94002a1 	ldr	x1, [x21]
    3d20:	52800000 	mov	w0, #0x0                   	// #0
    tx->active = 0;
    3d24:	b90002df 	str	wzr, [x22]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3d28:	889ffc20 	stlr	w0, [x1]
    return 2;
    3d2c:	52800053 	mov	w19, #0x2                   	// #2
    3d30:	17ffff56 	b	3a88 <tx_commit+0x2c>
  int ok = pwrite(fd, w, sizeof(*w), 0) == sizeof(*w) && fsync(fd) == 0;
    3d34:	52800017 	mov	w23, #0x0                   	// #0
    3d38:	17fffff0 	b	3cf8 <tx_commit+0x29c>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3d3c:	f94002a1 	ldr	x1, [x21]
    3d40:	52800000 	mov	w0, #0x0                   	// #0
    3d44:	889ffc20 	stlr	w0, [x1]
    return -1;
    3d48:	17ffff4f 	b	3a84 <tx_commit+0x28>
  if(write_db_from_wal(&wal_buffer) < 0){
    3d4c:	97fffdb4 	bl	341c <write_db_from_wal.constprop.0>
    3d50:	2a0003f3 	mov	w19, w0
    3d54:	f94002b7 	ldr	x23, [x21]
    3d58:	3100041f 	cmn	w0, #0x1
    3d5c:	54000300 	b.eq	3dbc <tx_commit+0x360>  // b.none
  for(uint i = 0; i < w->nops; i++)
    3d60:	b9400e99 	ldr	w25, [x20, #12]
    3d64:	9100c293 	add	x19, x20, #0x30
    3d68:	6b19031f 	cmp	w24, w25
    3d6c:	540002c1 	b.ne	3dc4 <tx_commit+0x368>  // b.any
  rebuild_index(db->shm);
    3d70:	aa1703e0 	mov	x0, x23
    3d74:	97fff995 	bl	23c8 <rebuild_index>
  db->shm->db_txid = w->txid;
    3d78:	f94002a0 	ldr	x0, [x21]
  db->shm->nrows = w->target_count;
    3d7c:	a9410a81 	ldp	x1, x2, [x20, #16]
  db->shm->db_txid = w->txid;
    3d80:	f9000801 	str	x1, [x0, #16]
  db->shm->ready = 1;
    3d84:	52800021 	mov	w1, #0x1                   	// #1
    3d88:	b9000c01 	str	w1, [x0, #12]
  db->shm->commits++;
    3d8c:	f9401001 	ldr	x1, [x0, #32]
    3d90:	91000421 	add	x1, x1, #0x1
    3d94:	a9018402 	stp	x2, x1, [x0, #24]
  __sync_synchronize();
    3d98:	d5033bbf 	dmb	ish
  if(clear_wal() < 0){
    3d9c:	97fff9b7 	bl	2478 <clear_wal>
    3da0:	2a0003f3 	mov	w19, w0
  shared_unlock(&db->shm->lock);
    3da4:	f94002a0 	ldr	x0, [x21]
  if(clear_wal() < 0){
    3da8:	3100067f 	cmn	w19, #0x1
    3dac:	540001e1 	b.ne	3de8 <tx_commit+0x38c>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3db0:	52800001 	mov	w1, #0x0                   	// #0
    3db4:	889ffc01 	stlr	w1, [x0]
    return -1;
    3db8:	17ffff34 	b	3a88 <tx_commit+0x2c>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3dbc:	889ffef8 	stlr	w24, [x23]
    return -1;
    3dc0:	17ffff32 	b	3a88 <tx_commit+0x2c>
    db->shm->rows[w->ops[i].slot] = w->ops[i].row;
    3dc4:	b85fc260 	ldur	w0, [x19, #-4]
    3dc8:	aa1303e1 	mov	x1, x19
    3dcc:	d2800802 	mov	x2, #0x40                  	// #64
  for(uint i = 0; i < w->nops; i++)
    3dd0:	11000718 	add	w24, w24, #0x1
    db->shm->rows[w->ops[i].slot] = w->ops[i].row;
    3dd4:	91020400 	add	x0, x0, #0x81
    3dd8:	91014273 	add	x19, x19, #0x50
    3ddc:	8b001ae0 	add	x0, x23, x0, lsl #6
    3de0:	97fff37a 	bl	bc8 <memcpy@plt>
  for(uint i = 0; i < w->nops; i++)
    3de4:	17ffffe1 	b	3d68 <tx_commit+0x30c>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3de8:	52800001 	mov	w1, #0x0                   	// #0
  tx->active = 0;
    3dec:	b90002df 	str	wzr, [x22]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    3df0:	889ffc01 	stlr	w1, [x0]
    3df4:	17ffff55 	b	3b48 <tx_commit+0xec>

0000000000003df8 <pg_auto_change>:
{
    3df8:	d10943ff 	sub	sp, sp, #0x250
    3dfc:	a9007bfd 	stp	x29, x30, [sp]
    3e00:	910003fd 	mov	x29, sp
    3e04:	a90153f3 	stp	x19, x20, [sp, #16]
    3e08:	2a0103f4 	mov	w20, w1
    3e0c:	aa0003f3 	mov	x19, x0
  memset(&tx, 0, sizeof(tx));
    3e10:	52800001 	mov	w1, #0x0                   	// #0
    3e14:	910103e0 	add	x0, sp, #0x40
{
    3e18:	f90013f5 	str	x21, [sp, #32]
    3e1c:	2a0203f5 	mov	w21, w2
  memset(&tx, 0, sizeof(tx));
    3e20:	52804202 	mov	w2, #0x210                 	// #528
{
    3e24:	f9001fe3 	str	x3, [sp, #56]
  memset(&tx, 0, sizeof(tx));
    3e28:	97fff398 	bl	c88 <memset@plt>
  tx.active = 1;
    3e2c:	f9401fe3 	ldr	x3, [sp, #56]
    3e30:	52800020 	mov	w0, #0x1                   	// #1
    3e34:	2a1503e2 	mov	w2, w21
    3e38:	2a1403e1 	mov	w1, w20
    3e3c:	b90043e0 	str	w0, [sp, #64]
  for(uint i = 0; i < tx->nops; i++)
    3e40:	910103e0 	add	x0, sp, #0x40
    3e44:	97fffb87 	bl	2c60 <tx_stage.part.0>
  return tx_stage(&tx, type, key, value) < 0 ? -1 :
    3e48:	35000140 	cbnz	w0, 3e70 <pg_auto_change+0x78>
         tx_commit(db, &tx, 0);
    3e4c:	910103e1 	add	x1, sp, #0x40
    3e50:	aa1303e0 	mov	x0, x19
    3e54:	52800002 	mov	w2, #0x0                   	// #0
    3e58:	97ffff01 	bl	3a5c <tx_commit>
}
    3e5c:	f94013f5 	ldr	x21, [sp, #32]
    3e60:	a9407bfd 	ldp	x29, x30, [sp]
    3e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e68:	910943ff 	add	sp, sp, #0x250
    3e6c:	d65f03c0 	ret
  return tx_stage(&tx, type, key, value) < 0 ? -1 :
    3e70:	12800000 	mov	w0, #0xffffffff            	// #-1
    3e74:	17fffffa 	b	3e5c <pg_auto_change+0x64>

0000000000003e78 <pg_execute_query>:
{
    3e78:	a9b57bfd 	stp	x29, x30, [sp, #-176]!
    3e7c:	910003fd 	mov	x29, sp
    3e80:	a90153f3 	stp	x19, x20, [sp, #16]
    3e84:	2a0003f3 	mov	w19, w0
    3e88:	aa0203f4 	mov	x20, x2
    3e8c:	aa0303e0 	mov	x0, x3
    3e90:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e94:	aa0103f5 	mov	x21, x1
    3e98:	a90363f7 	stp	x23, x24, [sp, #48]
    3e9c:	f90023f9 	str	x25, [sp, #64]
  sql = pg_skip_space(sql);
    3ea0:	97fff90c 	bl	22d0 <pg_skip_space>
  if(*sql == 0)
    3ea4:	39400001 	ldrb	w1, [x0]
    3ea8:	35000161 	cbnz	w1, 3ed4 <pg_execute_query+0x5c>
}
    3eac:	f94023f9 	ldr	x25, [sp, #64]
    return pg_send(fd, 'I', 0, 0);
    3eb0:	2a1303e0 	mov	w0, w19
}
    3eb4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    return pg_send(fd, 'I', 0, 0);
    3eb8:	52800003 	mov	w3, #0x0                   	// #0
}
    3ebc:	a94153f3 	ldp	x19, x20, [sp, #16]
    return pg_send(fd, 'I', 0, 0);
    3ec0:	d2800002 	mov	x2, #0x0                   	// #0
}
    3ec4:	a94363f7 	ldp	x23, x24, [sp, #48]
    return pg_send(fd, 'I', 0, 0);
    3ec8:	52800921 	mov	w1, #0x49                  	// #73
}
    3ecc:	a8cb7bfd 	ldp	x29, x30, [sp], #176
    return pg_send(fd, 'I', 0, 0);
    3ed0:	17fff9fd 	b	26c4 <pg_send>
  if(pg_starts_with(sql, "begin") || pg_starts_with(sql, "start transaction")){
    3ed4:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3ed8:	91073821 	add	x1, x1, #0x1ce
    3edc:	2a0403f6 	mov	w22, w4
    3ee0:	aa0003e7 	mov	x7, x0
    3ee4:	97fffe5b 	bl	3850 <pg_starts_with>
    3ee8:	350000c0 	cbnz	w0, 3f00 <pg_execute_query+0x88>
    3eec:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3ef0:	91075021 	add	x1, x1, #0x1d4
    3ef4:	aa0703e0 	mov	x0, x7
    3ef8:	97fffe56 	bl	3850 <pg_starts_with>
    3efc:	340003a0 	cbz	w0, 3f70 <pg_execute_query+0xf8>
    if(tx->active)
    3f00:	b9400280 	ldr	w0, [x20]
    3f04:	34000180 	cbz	w0, 3f34 <pg_execute_query+0xbc>
      return pg_send_error(fd, "25001", "transaction already active");
    3f08:	d0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    3f0c:	91079842 	add	x2, x2, #0x1e6
    3f10:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3f14:	91080421 	add	x1, x1, #0x201
}
    3f18:	f94023f9 	ldr	x25, [sp, #64]
  return pg_send_error(fd, "0A000", "SQL feature not supported by mygres");
    3f1c:	2a1303e0 	mov	w0, w19
}
    3f20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f24:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f28:	a94363f7 	ldp	x23, x24, [sp, #48]
    3f2c:	a8cb7bfd 	ldp	x29, x30, [sp], #176
  return pg_send_error(fd, "0A000", "SQL feature not supported by mygres");
    3f30:	17fffaf2 	b	2af8 <pg_send_error>
    memset(tx, 0, sizeof(*tx));
    3f34:	52800001 	mov	w1, #0x0                   	// #0
    3f38:	aa1403e0 	mov	x0, x20
    3f3c:	52804202 	mov	w2, #0x210                 	// #528
    3f40:	97fff352 	bl	c88 <memset@plt>
    return pg_send_command(fd, "BEGIN");
    3f44:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3f48:	91081c21 	add	x1, x1, #0x207
    tx->active = 1;
    3f4c:	52800020 	mov	w0, #0x1                   	// #1
    3f50:	b9000280 	str	w0, [x20]
}
    3f54:	f94023f9 	ldr	x25, [sp, #64]
                        pg_send_command(fd, "COMMIT");
    3f58:	2a1303e0 	mov	w0, w19
}
    3f5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f64:	a94363f7 	ldp	x23, x24, [sp, #48]
    3f68:	a8cb7bfd 	ldp	x29, x30, [sp], #176
                        pg_send_command(fd, "COMMIT");
    3f6c:	17fffab3 	b	2a38 <pg_send_command>
  if(pg_starts_with(sql, "commit")){
    3f70:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3f74:	91083421 	add	x1, x1, #0x20d
    3f78:	aa0703e0 	mov	x0, x7
    3f7c:	97fffe35 	bl	3850 <pg_starts_with>
    3f80:	34000220 	cbz	w0, 3fc4 <pg_execute_query+0x14c>
    int status = tx->active ? tx_commit(db, tx, 0) : 0;
    3f84:	b9400280 	ldr	w0, [x20]
    3f88:	34000180 	cbz	w0, 3fb8 <pg_execute_query+0x140>
    3f8c:	aa1403e1 	mov	x1, x20
    3f90:	aa1503e0 	mov	x0, x21
    3f94:	52800002 	mov	w2, #0x0                   	// #0
    3f98:	97fffeb1 	bl	3a5c <tx_commit>
    return status < 0 ? pg_send_error(fd, "XX000", "commit failed") :
    3f9c:	3100041f 	cmn	w0, #0x1
    3fa0:	540000c1 	b.ne	3fb8 <pg_execute_query+0x140>  // b.any
    3fa4:	d0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    3fa8:	91085042 	add	x2, x2, #0x214
    return status < 0 ? pg_send_error(fd, "XX000", "delete failed") :
    3fac:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3fb0:	91088821 	add	x1, x1, #0x222
    3fb4:	17ffffd9 	b	3f18 <pg_execute_query+0xa0>
                        pg_send_command(fd, "COMMIT");
    3fb8:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3fbc:	9108a021 	add	x1, x1, #0x228
    3fc0:	17ffffe5 	b	3f54 <pg_execute_query+0xdc>
  if(pg_starts_with(sql, "rollback")){
    3fc4:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3fc8:	9108bc21 	add	x1, x1, #0x22f
    3fcc:	aa0703e0 	mov	x0, x7
    3fd0:	97fffe20 	bl	3850 <pg_starts_with>
    3fd4:	34000100 	cbz	w0, 3ff4 <pg_execute_query+0x17c>
    memset(tx, 0, sizeof(*tx));
    3fd8:	52800001 	mov	w1, #0x0                   	// #0
    3fdc:	aa1403e0 	mov	x0, x20
    3fe0:	52804202 	mov	w2, #0x210                 	// #528
    3fe4:	97fff329 	bl	c88 <memset@plt>
    return pg_send_command(fd, "ROLLBACK");
    3fe8:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3fec:	9108e021 	add	x1, x1, #0x238
    3ff0:	17ffffd9 	b	3f54 <pg_execute_query+0xdc>
  if(pg_starts_with(sql, "select"))
    3ff4:	d0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    3ff8:	91055021 	add	x1, x1, #0x154
    3ffc:	aa0703e0 	mov	x0, x7
    4000:	97fffe14 	bl	3850 <pg_starts_with>
    4004:	340012a0 	cbz	w0, 4258 <pg_execute_query+0x3e0>
  int n = pg_numbers(sql, number, 4);
    4008:	910143f7 	add	x23, sp, #0x50
    400c:	aa0703e0 	mov	x0, x7
    4010:	aa1703e1 	mov	x1, x23
    4014:	97fffbac 	bl	2ec4 <pg_numbers.constprop.0>
  if(pg_contains(sql, "version()"))
    4018:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    401c:	9105a021 	add	x1, x1, #0x168
  int n = pg_numbers(sql, number, 4);
    4020:	2a0003f4 	mov	w20, w0
  if(pg_contains(sql, "version()"))
    4024:	aa0703e0 	mov	x0, x7
    4028:	97fffdf3 	bl	37f4 <pg_contains>
    402c:	340001e0 	cbz	w0, 4068 <pg_execute_query+0x1f0>
    return pg_send_text_result(fd, "version",
    4030:	b0000003 	adrp	x3, 5000 <pgwire_connection+0xba0>
    4034:	91090463 	add	x3, x3, #0x241
    4038:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    403c:	91092842 	add	x2, x2, #0x24a
    4040:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4044:	910e8c21 	add	x1, x1, #0x3a3
}
    4048:	f94023f9 	ldr	x25, [sp, #64]
    return pg_send_text_result(fd, "setting", "on", "SHOW", describe);
    404c:	2a1603e4 	mov	w4, w22
}
    4050:	a94363f7 	ldp	x23, x24, [sp, #48]
    return pg_send_text_result(fd, "setting", "on", "SHOW", describe);
    4054:	2a1303e0 	mov	w0, w19
}
    4058:	a9425bf5 	ldp	x21, x22, [sp, #32]
    405c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4060:	a8cb7bfd 	ldp	x29, x30, [sp], #176
    return pg_send_text_result(fd, "setting", "on", "SHOW", describe);
    4064:	17fffa83 	b	2a70 <pg_send_text_result>
  if(pg_contains(sql, "set_config"))
    4068:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    406c:	9109d421 	add	x1, x1, #0x275
    4070:	aa0703e0 	mov	x0, x7
    4074:	97fffde0 	bl	37f4 <pg_contains>
    4078:	340000c0 	cbz	w0, 4090 <pg_execute_query+0x218>
    return pg_send_text_result(fd, "set_config", "", "SELECT 1", describe);
    407c:	b0000003 	adrp	x3, 5000 <pgwire_connection+0xba0>
    4080:	91090463 	add	x3, x3, #0x241
    4084:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4088:	911ac842 	add	x2, x2, #0x6b2
    408c:	17ffffef 	b	4048 <pg_execute_query+0x1d0>
  if(!pg_contains(sql, "from kv")){
    4090:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4094:	91056c21 	add	x1, x1, #0x15b
    4098:	aa0703e0 	mov	x0, x7
    409c:	97fffdd6 	bl	37f4 <pg_contains>
    40a0:	350002c0 	cbnz	w0, 40f8 <pg_execute_query+0x280>
    pg_u64toa(n ? number[0] : 1, value_buffer);
    40a4:	f9402be0 	ldr	x0, [sp, #80]
    40a8:	7100029f 	cmp	w20, #0x0
    40ac:	9101c3e1 	add	x1, sp, #0x70
    40b0:	9a9f1400 	csinc	x0, x0, xzr, ne	// ne = any
    40b4:	97fff86d 	bl	2268 <pg_u64toa>
    return pg_send_text_result(fd, "?column?", value_buffer, "SELECT 1", describe);
    40b8:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    40bc:	91052c21 	add	x1, x1, #0x14b
    40c0:	b0000003 	adrp	x3, 5000 <pgwire_connection+0xba0>
    40c4:	91090463 	add	x3, x3, #0x241
    40c8:	2a1603e4 	mov	w4, w22
    40cc:	9101c3e2 	add	x2, sp, #0x70
    40d0:	2a1303e0 	mov	w0, w19
    40d4:	97fffa67 	bl	2a70 <pg_send_text_result>
      return pg_send_kv_result(fd, &row, 1, describe);
    40d8:	2a0003f3 	mov	w19, w0
}
    40dc:	f94023f9 	ldr	x25, [sp, #64]
    40e0:	2a1303e0 	mov	w0, w19
    40e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    40f0:	a8cb7bfd 	ldp	x29, x30, [sp], #176
    40f4:	d65f03c0 	ret
  if(pg_contains(sql, "where")){
    40f8:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    40fc:	910a0021 	add	x1, x1, #0x280
    4100:	aa0703e0 	mov	x0, x7
    4104:	97fffdbc 	bl	37f4 <pg_contains>
    4108:	34000580 	cbz	w0, 41b8 <pg_execute_query+0x340>
    memset(&row, 0, sizeof(row));
    410c:	9101c3e0 	add	x0, sp, #0x70
    4110:	52800802 	mov	w2, #0x40                  	// #64
    4114:	52800001 	mov	w1, #0x0                   	// #0
    4118:	97fff2dc 	bl	c88 <memset@plt>
    if(n == 0 || number[n - 1] > 0xffffffffU)
    411c:	340000d4 	cbz	w20, 4134 <pg_execute_query+0x2bc>
    4120:	51000694 	sub	w20, w20, #0x1
    4124:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    4128:	f8747af4 	ldr	x20, [x23, x20, lsl #3]
    412c:	eb00029f 	cmp	x20, x0
    4130:	54000109 	b.ls	4150 <pg_execute_query+0x2d8>  // b.plast
      return pg_send_error(fd, "22P02", "invalid key");
    4134:	2a1303e0 	mov	w0, w19
    4138:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    413c:	910a1842 	add	x2, x2, #0x286
    4140:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4144:	910a4821 	add	x1, x1, #0x292
    4148:	97fffa6c 	bl	2af8 <pg_send_error>
    414c:	17ffffe3 	b	40d8 <pg_execute_query+0x260>
  shared_lock(&db->shm->lock);
    4150:	f94002a0 	ldr	x0, [x21]
    4154:	97fff8e9 	bl	24f8 <shared_lock>
  int slot = index_lookup(db->shm, key, 1);
    4158:	f94002a8 	ldr	x8, [x21]
    415c:	2a1403e1 	mov	w1, w20
    4160:	52800022 	mov	w2, #0x1                   	// #1
    4164:	aa0803e0 	mov	x0, x8
    4168:	97fffe13 	bl	39b4 <index_lookup>
  if(slot >= 0){
    416c:	3100041f 	cmn	w0, #0x1
    4170:	54000121 	b.ne	4194 <pg_execute_query+0x31c>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    4174:	52800000 	mov	w0, #0x0                   	// #0
    4178:	889ffd00 	stlr	w0, [x8]
    return pg_send_kv_result(fd, &row, 0, describe);
    417c:	2a1603e3 	mov	w3, w22
    4180:	52800002 	mov	w2, #0x0                   	// #0
      return pg_send_kv_result(fd, &row, 1, describe);
    4184:	9101c3e1 	add	x1, sp, #0x70
    4188:	2a1303e0 	mov	w0, w19
    418c:	97fffb09 	bl	2db0 <pg_send_kv_result>
    4190:	17ffffd2 	b	40d8 <pg_execute_query+0x260>
    *value = db->shm->rows[slot].value;
    4194:	d37a7c00 	ubfiz	x0, x0, #6, #32
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    4198:	52800001 	mov	w1, #0x0                   	// #0
    *value = db->shm->rows[slot].value;
    419c:	8b000100 	add	x0, x8, x0
    41a0:	f9502400 	ldr	x0, [x0, #8264]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    41a4:	889ffd01 	stlr	w1, [x8]
      return pg_send_kv_result(fd, &row, 1, describe);
    41a8:	2a1603e3 	mov	w3, w22
      row.state = ROW_USED;
    41ac:	290e53e2 	stp	w2, w20, [sp, #112]
      row.value = value;
    41b0:	f9003fe0 	str	x0, [sp, #120]
      return pg_send_kv_result(fd, &row, 1, describe);
    41b4:	17fffff4 	b	4184 <pg_execute_query+0x30c>
  struct db_row *snapshot = malloc(MAX_ROWS * sizeof(struct db_row));
    41b8:	52a00020 	mov	w0, #0x10000               	// #65536
    41bc:	97fff287 	bl	bd8 <malloc@plt>
    41c0:	aa0003f7 	mov	x23, x0
  if(snapshot == 0)
    41c4:	b50000c0 	cbnz	x0, 41dc <pg_execute_query+0x364>
    return pg_send_error(fd, "53200", "out of memory");
    41c8:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    41cc:	910a6042 	add	x2, x2, #0x298
    41d0:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    41d4:	910a9821 	add	x1, x1, #0x2a6
    41d8:	17ffff50 	b	3f18 <pg_execute_query+0xa0>
  shared_lock(&db->shm->lock);
    41dc:	f94002a0 	ldr	x0, [x21]
    41e0:	97fff8c6 	bl	24f8 <shared_lock>
    if(db->shm->rows[i].state == ROW_USED)
    41e4:	f94002b8 	ldr	x24, [x21]
    41e8:	d2840800 	mov	x0, #0x2040                	// #8256
  uint count = 0;
    41ec:	52800015 	mov	w21, #0x0                   	// #0
    41f0:	91404b19 	add	x25, x24, #0x12, lsl #12
    41f4:	8b000314 	add	x20, x24, x0
    41f8:	91010339 	add	x25, x25, #0x40
    if(db->shm->rows[i].state == ROW_USED)
    41fc:	b9400280 	ldr	w0, [x20]
    4200:	7100041f 	cmp	w0, #0x1
    4204:	540000e1 	b.ne	4220 <pg_execute_query+0x3a8>  // b.any
      snapshot[count++] = db->shm->rows[i];
    4208:	d37a7ea0 	ubfiz	x0, x21, #6, #32
    420c:	110006b5 	add	w21, w21, #0x1
    4210:	aa1403e1 	mov	x1, x20
    4214:	8b0002e0 	add	x0, x23, x0
    4218:	d2800802 	mov	x2, #0x40                  	// #64
    421c:	97fff26b 	bl	bc8 <memcpy@plt>
  for(uint i = 0; i < MAX_ROWS; i++)
    4220:	91010294 	add	x20, x20, #0x40
    4224:	eb19029f 	cmp	x20, x25
    4228:	54fffea1 	b.ne	41fc <pg_execute_query+0x384>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(lock) : "memory");
    422c:	52800000 	mov	w0, #0x0                   	// #0
    4230:	889fff00 	stlr	w0, [x24]
  int result = pg_send_kv_result(fd, snapshot, count, describe);
    4234:	2a1603e3 	mov	w3, w22
    4238:	2a1503e2 	mov	w2, w21
    423c:	aa1703e1 	mov	x1, x23
    4240:	2a1303e0 	mov	w0, w19
    4244:	97fffadb 	bl	2db0 <pg_send_kv_result>
    4248:	2a0003f3 	mov	w19, w0
  free(snapshot);
    424c:	aa1703e0 	mov	x0, x23
    4250:	97fff2ce 	bl	d88 <free@plt>
    return pg_execute_select(fd, db, sql, describe);
    4254:	17ffffa2 	b	40dc <pg_execute_query+0x264>
  if(pg_starts_with(sql, "show"))
    4258:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    425c:	91058c21 	add	x1, x1, #0x163
    4260:	aa0703e0 	mov	x0, x7
    4264:	97fffd7b 	bl	3850 <pg_starts_with>
    4268:	34000100 	cbz	w0, 4288 <pg_execute_query+0x410>
    return pg_send_text_result(fd, "setting", "on", "SHOW", describe);
    426c:	b0000003 	adrp	x3, 5000 <pgwire_connection+0xba0>
    4270:	910ab063 	add	x3, x3, #0x2ac
    4274:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4278:	910ea042 	add	x2, x2, #0x3a8
    427c:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4280:	910ac421 	add	x1, x1, #0x2b1
    4284:	17ffff71 	b	4048 <pg_execute_query+0x1d0>
  if(pg_starts_with(sql, "set ") || pg_starts_with(sql, "reset "))
    4288:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    428c:	910aec21 	add	x1, x1, #0x2bb
    4290:	aa0703e0 	mov	x0, x7
    4294:	97fffd6f 	bl	3850 <pg_starts_with>
    4298:	35000120 	cbnz	w0, 42bc <pg_execute_query+0x444>
    429c:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    42a0:	910ae421 	add	x1, x1, #0x2b9
    42a4:	aa0703e0 	mov	x0, x7
    42a8:	97fffd6a 	bl	3850 <pg_starts_with>
    42ac:	340000e0 	cbz	w0, 42c8 <pg_execute_query+0x450>
    return pg_send_command(fd, pg_starts_with(sql, "set ") ? "SET" : "RESET");
    42b0:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    42b4:	91072021 	add	x1, x1, #0x1c8
    42b8:	17ffff27 	b	3f54 <pg_execute_query+0xdc>
    42bc:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    42c0:	91072821 	add	x1, x1, #0x1ca
    42c4:	17ffff24 	b	3f54 <pg_execute_query+0xdc>
  n = pg_numbers(sql, number, 4);
    42c8:	9101c3e9 	add	x9, sp, #0x70
    42cc:	aa0703e0 	mov	x0, x7
    42d0:	aa0903e1 	mov	x1, x9
    42d4:	97fffafc 	bl	2ec4 <pg_numbers.constprop.0>
  if(pg_starts_with(sql, "insert") && n >= 2 && number[0] <= 0xffffffffU){
    42d8:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    42dc:	910b0021 	add	x1, x1, #0x2c0
  n = pg_numbers(sql, number, 4);
    42e0:	2a0003e8 	mov	w8, w0
  if(pg_starts_with(sql, "insert") && n >= 2 && number[0] <= 0xffffffffU){
    42e4:	aa0703e0 	mov	x0, x7
    42e8:	97fffd5a 	bl	3850 <pg_starts_with>
    42ec:	34000300 	cbz	w0, 434c <pg_execute_query+0x4d4>
    42f0:	7100051f 	cmp	w8, #0x1
    42f4:	540002cd 	b.le	434c <pg_execute_query+0x4d4>
    42f8:	f9403be2 	ldr	x2, [sp, #112]
    42fc:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    4300:	eb00005f 	cmp	x2, x0
    4304:	54000248 	b.hi	434c <pg_execute_query+0x4d4>  // b.pmore
    int status = tx->active ? tx_stage(tx, OP_PUT, number[0], number[1]) :
    4308:	b9400280 	ldr	w0, [x20]
    430c:	52800021 	mov	w1, #0x1                   	// #1
    4310:	f9403fe3 	ldr	x3, [sp, #120]
    4314:	34000100 	cbz	w0, 4334 <pg_execute_query+0x4bc>
    4318:	aa1403e0 	mov	x0, x20
    431c:	97fffa6c 	bl	2ccc <tx_stage>
    return status < 0 ? pg_send_error(fd, "XX000", "insert failed") :
    4320:	3100041f 	cmn	w0, #0x1
    4324:	540000e1 	b.ne	4340 <pg_execute_query+0x4c8>  // b.any
    4328:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    432c:	910b1c42 	add	x2, x2, #0x2c7
    4330:	17ffff1f 	b	3fac <pg_execute_query+0x134>
                              pg_auto_change(db, OP_PUT, number[0], number[1]);
    4334:	aa1503e0 	mov	x0, x21
    4338:	97fffeb0 	bl	3df8 <pg_auto_change>
    433c:	17fffff9 	b	4320 <pg_execute_query+0x4a8>
                        pg_send_command(fd, "INSERT 0 1");
    4340:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4344:	910b5421 	add	x1, x1, #0x2d5
    4348:	17ffff03 	b	3f54 <pg_execute_query+0xdc>
  if(pg_starts_with(sql, "update") && n >= 2 && number[1] <= 0xffffffffU){
    434c:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4350:	910b8021 	add	x1, x1, #0x2e0
    4354:	aa0703e0 	mov	x0, x7
    4358:	97fffd3e 	bl	3850 <pg_starts_with>
    435c:	34000300 	cbz	w0, 43bc <pg_execute_query+0x544>
    4360:	7100051f 	cmp	w8, #0x1
    4364:	540002cd 	b.le	43bc <pg_execute_query+0x544>
    4368:	f9403fe2 	ldr	x2, [sp, #120]
    436c:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    4370:	eb00005f 	cmp	x2, x0
    4374:	54000248 	b.hi	43bc <pg_execute_query+0x544>  // b.pmore
    int status = tx->active ? tx_stage(tx, OP_PUT, number[1], number[0]) :
    4378:	b9400280 	ldr	w0, [x20]
    437c:	52800021 	mov	w1, #0x1                   	// #1
  if(pg_starts_with(sql, "insert") && n >= 2 && number[0] <= 0xffffffffU){
    4380:	f9403be3 	ldr	x3, [sp, #112]
    int status = tx->active ? tx_stage(tx, OP_PUT, number[1], number[0]) :
    4384:	34000100 	cbz	w0, 43a4 <pg_execute_query+0x52c>
    4388:	aa1403e0 	mov	x0, x20
    438c:	97fffa50 	bl	2ccc <tx_stage>
    return status < 0 ? pg_send_error(fd, "XX000", "update failed") :
    4390:	3100041f 	cmn	w0, #0x1
    4394:	540000e1 	b.ne	43b0 <pg_execute_query+0x538>  // b.any
    4398:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    439c:	910b9c42 	add	x2, x2, #0x2e7
    43a0:	17ffff03 	b	3fac <pg_execute_query+0x134>
                              pg_auto_change(db, OP_PUT, number[1], number[0]);
    43a4:	aa1503e0 	mov	x0, x21
    43a8:	97fffe94 	bl	3df8 <pg_auto_change>
    43ac:	17fffff9 	b	4390 <pg_execute_query+0x518>
                        pg_send_command(fd, "UPDATE 1");
    43b0:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    43b4:	910bd421 	add	x1, x1, #0x2f5
    43b8:	17fffee7 	b	3f54 <pg_execute_query+0xdc>
  if(pg_starts_with(sql, "delete") && n >= 1 && number[n - 1] <= 0xffffffffU){
    43bc:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    43c0:	910bf821 	add	x1, x1, #0x2fe
    43c4:	aa0703e0 	mov	x0, x7
    43c8:	97fffd22 	bl	3850 <pg_starts_with>
    43cc:	34000300 	cbz	w0, 442c <pg_execute_query+0x5b4>
    43d0:	340002e8 	cbz	w8, 442c <pg_execute_query+0x5b4>
    43d4:	51000508 	sub	w8, w8, #0x1
    43d8:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
    43dc:	f8687922 	ldr	x2, [x9, x8, lsl #3]
    43e0:	eb00005f 	cmp	x2, x0
    43e4:	54000248 	b.hi	442c <pg_execute_query+0x5b4>  // b.pmore
    int status = tx->active ? tx_stage(tx, OP_DELETE, number[n - 1], 0) :
    43e8:	b9400280 	ldr	w0, [x20]
    43ec:	d2800003 	mov	x3, #0x0                   	// #0
    43f0:	52800041 	mov	w1, #0x2                   	// #2
    43f4:	34000100 	cbz	w0, 4414 <pg_execute_query+0x59c>
    43f8:	aa1403e0 	mov	x0, x20
    43fc:	97fffa34 	bl	2ccc <tx_stage>
    return status < 0 ? pg_send_error(fd, "XX000", "delete failed") :
    4400:	3100041f 	cmn	w0, #0x1
    4404:	540000e1 	b.ne	4420 <pg_execute_query+0x5a8>  // b.any
    4408:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    440c:	910c1442 	add	x2, x2, #0x305
    4410:	17fffee7 	b	3fac <pg_execute_query+0x134>
                              pg_auto_change(db, OP_DELETE, number[n - 1], 0);
    4414:	aa1503e0 	mov	x0, x21
    4418:	97fffe78 	bl	3df8 <pg_auto_change>
    441c:	17fffff9 	b	4400 <pg_execute_query+0x588>
                        pg_send_command(fd, "DELETE 1");
    4420:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4424:	910c4c21 	add	x1, x1, #0x313
    4428:	17fffecb 	b	3f54 <pg_execute_query+0xdc>
  if(pg_starts_with(sql, "create table"))
    442c:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4430:	910c7021 	add	x1, x1, #0x31c
    4434:	aa0703e0 	mov	x0, x7
    4438:	97fffd06 	bl	3850 <pg_starts_with>
    443c:	34000080 	cbz	w0, 444c <pg_execute_query+0x5d4>
    return pg_send_command(fd, "CREATE TABLE");
    4440:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4444:	910ca421 	add	x1, x1, #0x329
    4448:	17fffec3 	b	3f54 <pg_execute_query+0xdc>
  return pg_send_error(fd, "0A000", "SQL feature not supported by mygres");
    444c:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4450:	910cd842 	add	x2, x2, #0x336
    4454:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4458:	910d6821 	add	x1, x1, #0x35a
    445c:	17fffeaf 	b	3f18 <pg_execute_query+0xa0>

0000000000004460 <pgwire_connection>:
{
    4460:	d283e40c 	mov	x12, #0x1f20                	// #7968
    4464:	cb2c63ff 	sub	sp, sp, x12
  memset(&tx, 0, sizeof(tx));
    4468:	52804202 	mov	w2, #0x210                 	// #528
{
    446c:	a9007bfd 	stp	x29, x30, [sp]
    4470:	910003fd 	mov	x29, sp
    4474:	a90153f3 	stp	x19, x20, [sp, #16]
    4478:	2a0003f3 	mov	w19, w0
  memset(&tx, 0, sizeof(tx));
    447c:	910303e0 	add	x0, sp, #0xc0
{
    4480:	a9025bf5 	stp	x21, x22, [sp, #32]
    if(code == PG_SSL_REQUEST || code == PG_GSS_REQUEST){
    4484:	529d3a34 	mov	w20, #0xe9d1                	// #59857
    4488:	72bf65b4 	movk	w20, #0xfb2d, lsl #16
{
    448c:	a90363f7 	stp	x23, x24, [sp, #48]
    if(pg_read_all(fd, message, length - 4) < 0)
    4490:	911b43f5 	add	x21, sp, #0x6d0
{
    4494:	a9046bf9 	stp	x25, x26, [sp, #64]
  memset(&extended, 0, sizeof(extended));
    4498:	913b43f9 	add	x25, sp, #0xed0
{
    449c:	a90573fb 	stp	x27, x28, [sp, #80]
    44a0:	f90033e1 	str	x1, [sp, #96]
  memset(&tx, 0, sizeof(tx));
    44a4:	52800001 	mov	w1, #0x0                   	// #0
    44a8:	97fff1f8 	bl	c88 <memset@plt>
  memset(&extended, 0, sizeof(extended));
    44ac:	aa1903e0 	mov	x0, x25
    44b0:	52820a02 	mov	w2, #0x1050                	// #4176
    44b4:	52800001 	mov	w1, #0x0                   	// #0
    44b8:	97fff1f4 	bl	c88 <memset@plt>
    if(pg_read_all(fd, &length, 4) < 0)
    44bc:	910283e1 	add	x1, sp, #0xa0
    44c0:	2a1303e0 	mov	w0, w19
    44c4:	52800082 	mov	w2, #0x4                   	// #4
    44c8:	97fff9cd 	bl	2bfc <pg_read_all>
    44cc:	3100041f 	cmn	w0, #0x1
    44d0:	540003e0 	b.eq	454c <pgwire_connection+0xec>  // b.none
    length = pg_be32(length);
    44d4:	b940a3e0 	ldr	w0, [sp, #160]
    44d8:	97fff762 	bl	2260 <pg_be32>
    if(length < 8 || length > sizeof(message))
    44dc:	51002001 	sub	w1, w0, #0x8
    length = pg_be32(length);
    44e0:	b900a3e0 	str	w0, [sp, #160]
    if(length < 8 || length > sizeof(message))
    44e4:	711fe03f 	cmp	w1, #0x7f8
    44e8:	54000328 	b.hi	454c <pgwire_connection+0xec>  // b.pmore
    if(pg_read_all(fd, message, length - 4) < 0)
    44ec:	51001002 	sub	w2, w0, #0x4
    44f0:	aa1503e1 	mov	x1, x21
    44f4:	2a1303e0 	mov	w0, w19
    44f8:	97fff9c1 	bl	2bfc <pg_read_all>
    44fc:	3100041f 	cmn	w0, #0x1
    4500:	54000260 	b.eq	454c <pgwire_connection+0xec>  // b.none
    memmove(&code, message, 4);
    4504:	aa1503e1 	mov	x1, x21
    4508:	910b43e0 	add	x0, sp, #0x2d0
    450c:	52800082 	mov	w2, #0x4                   	// #4
    4510:	97fff19e 	bl	b88 <memmove@plt>
    code = pg_be32(code);
    4514:	b942d3e0 	ldr	w0, [sp, #720]
    4518:	97fff752 	bl	2260 <pg_be32>
    if(code == PG_SSL_REQUEST || code == PG_GSS_REQUEST){
    451c:	0b140001 	add	w1, w0, w20
    code = pg_be32(code);
    4520:	b902d3e0 	str	w0, [sp, #720]
    if(code == PG_SSL_REQUEST || code == PG_GSS_REQUEST){
    4524:	7100043f 	cmp	w1, #0x1
    4528:	54000248 	b.hi	4570 <pgwire_connection+0x110>  // b.pmore
      char no = 'N';
    452c:	528009c0 	mov	w0, #0x4e                  	// #78
      if(pg_write_all(fd, &no, 1) < 0)
    4530:	910263e1 	add	x1, sp, #0x98
    4534:	52800022 	mov	w2, #0x1                   	// #1
      char no = 'N';
    4538:	390263e0 	strb	w0, [sp, #152]
      if(pg_write_all(fd, &no, 1) < 0)
    453c:	2a1303e0 	mov	w0, w19
    4540:	97fff848 	bl	2660 <pg_write_all>
    4544:	3100041f 	cmn	w0, #0x1
    4548:	54fffba1 	b.ne	44bc <pgwire_connection+0x5c>  // b.any
}
    454c:	a9407bfd 	ldp	x29, x30, [sp]
    4550:	d283e40c 	mov	x12, #0x1f20                	// #7968
    4554:	a94153f3 	ldp	x19, x20, [sp, #16]
    4558:	a9425bf5 	ldp	x21, x22, [sp, #32]
    455c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4560:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4564:	a94573fb 	ldp	x27, x28, [sp, #80]
    4568:	8b2c63ff 	add	sp, sp, x12
    456c:	d65f03c0 	ret
    if(code != PG_PROTOCOL_3){
    4570:	7140c01f 	cmp	w0, #0x30, lsl #12
    4574:	54000100 	b.eq	4594 <pgwire_connection+0x134>  // b.none
      pg_send_error(fd, "08P01", "only PostgreSQL protocol 3.0 is supported");
    4578:	2a1303e0 	mov	w0, w19
    457c:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4580:	910d8042 	add	x2, x2, #0x360
    4584:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4588:	910e2821 	add	x1, x1, #0x38a
    458c:	97fff95b 	bl	2af8 <pg_send_error>
      return -1;
    4590:	17ffffef 	b	454c <pgwire_connection+0xec>
  return pg_send(fd, type, &value, sizeof(value));
    4594:	910253e2 	add	x2, sp, #0x94
    4598:	2a1303e0 	mov	w0, w19
    459c:	52800083 	mov	w3, #0x4                   	// #4
    45a0:	52800a41 	mov	w1, #0x52                  	// #82
    45a4:	b90097ff 	str	wzr, [sp, #148]
    45a8:	97fff847 	bl	26c4 <pg_send>
  if(pg_send_i32(fd, 'R', 0) < 0 ||
    45ac:	3100041f 	cmn	w0, #0x1
    45b0:	54fffce0 	b.eq	454c <pgwire_connection+0xec>  // b.none
     pg_send_parameter(fd, "server_version", "16.0-mygres") < 0 ||
    45b4:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    45b8:	910e4042 	add	x2, x2, #0x390
    45bc:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    45c0:	910e7021 	add	x1, x1, #0x39c
    45c4:	2a1303e0 	mov	w0, w19
    45c8:	97fff86b 	bl	2774 <pg_send_parameter>
  if(pg_send_i32(fd, 'R', 0) < 0 ||
    45cc:	3100041f 	cmn	w0, #0x1
    45d0:	54fffbe0 	b.eq	454c <pgwire_connection+0xec>  // b.none
     pg_send_parameter(fd, "server_encoding", "UTF8") < 0 ||
    45d4:	b0000014 	adrp	x20, 5000 <pgwire_connection+0xba0>
    45d8:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    45dc:	910ec021 	add	x1, x1, #0x3b0
    45e0:	910eae82 	add	x2, x20, #0x3ab
    45e4:	2a1303e0 	mov	w0, w19
    45e8:	97fff863 	bl	2774 <pg_send_parameter>
     pg_send_parameter(fd, "server_version", "16.0-mygres") < 0 ||
    45ec:	3100041f 	cmn	w0, #0x1
    45f0:	54fffae0 	b.eq	454c <pgwire_connection+0xec>  // b.none
     pg_send_parameter(fd, "client_encoding", "UTF8") < 0 ||
    45f4:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    45f8:	910f0021 	add	x1, x1, #0x3c0
    45fc:	910eae82 	add	x2, x20, #0x3ab
    4600:	2a1303e0 	mov	w0, w19
    4604:	97fff85c 	bl	2774 <pg_send_parameter>
     pg_send_parameter(fd, "server_encoding", "UTF8") < 0 ||
    4608:	3100041f 	cmn	w0, #0x1
    460c:	54fffa00 	b.eq	454c <pgwire_connection+0xec>  // b.none
     pg_send_parameter(fd, "DateStyle", "ISO, MDY") < 0 ||
    4610:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4614:	910f4042 	add	x2, x2, #0x3d0
    4618:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    461c:	910f6421 	add	x1, x1, #0x3d9
    4620:	2a1303e0 	mov	w0, w19
    4624:	97fff854 	bl	2774 <pg_send_parameter>
     pg_send_parameter(fd, "client_encoding", "UTF8") < 0 ||
    4628:	3100041f 	cmn	w0, #0x1
    462c:	54fff900 	b.eq	454c <pgwire_connection+0xec>  // b.none
     pg_send_parameter(fd, "integer_datetimes", "on") < 0 ||
    4630:	b0000014 	adrp	x20, 5000 <pgwire_connection+0xba0>
    4634:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4638:	910f8c21 	add	x1, x1, #0x3e3
    463c:	910ea282 	add	x2, x20, #0x3a8
    4640:	2a1303e0 	mov	w0, w19
    4644:	97fff84c 	bl	2774 <pg_send_parameter>
     pg_send_parameter(fd, "DateStyle", "ISO, MDY") < 0 ||
    4648:	3100041f 	cmn	w0, #0x1
    464c:	54fff800 	b.eq	454c <pgwire_connection+0xec>  // b.none
     pg_send_parameter(fd, "standard_conforming_strings", "on") < 0)
    4650:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4654:	910fd421 	add	x1, x1, #0x3f5
    4658:	910ea282 	add	x2, x20, #0x3a8
    465c:	2a1303e0 	mov	w0, w19
    4660:	97fff845 	bl	2774 <pg_send_parameter>
     pg_send_parameter(fd, "integer_datetimes", "on") < 0 ||
    4664:	3100041f 	cmn	w0, #0x1
    4668:	54fff720 	b.eq	454c <pgwire_connection+0xec>  // b.none
  uint32 backend_key[2] = { pg_be32(getpid()), pg_be32((uint32)clock_us()) };
    466c:	97fff153 	bl	bb8 <getpid@plt>
    4670:	97fff6fc 	bl	2260 <pg_be32>
    4674:	b902d3e0 	str	w0, [sp, #720]
    4678:	97fff198 	bl	cd8 <clock_us@plt>
    467c:	97fff6f9 	bl	2260 <pg_be32>
  return pg_send(fd, 'K', backend_key, sizeof(backend_key)) < 0 ? -1 :
    4680:	910b43e2 	add	x2, sp, #0x2d0
    4684:	52800103 	mov	w3, #0x8                   	// #8
    4688:	52800961 	mov	w1, #0x4b                  	// #75
  uint32 backend_key[2] = { pg_be32(getpid()), pg_be32((uint32)clock_us()) };
    468c:	b902d7e0 	str	w0, [sp, #724]
  return pg_send(fd, 'K', backend_key, sizeof(backend_key)) < 0 ? -1 :
    4690:	2a1303e0 	mov	w0, w19
    4694:	97fff80c 	bl	26c4 <pg_send>
    4698:	35fff5a0 	cbnz	w0, 454c <pgwire_connection+0xec>
         pg_send_ready(fd, 0);
    469c:	2a1303e0 	mov	w0, w19
    46a0:	52800001 	mov	w1, #0x0                   	// #0
    46a4:	97fff827 	bl	2740 <pg_send_ready>
  if(pg_startup(fd) < 0)
    46a8:	3100041f 	cmn	w0, #0x1
    46ac:	54fff500 	b.eq	454c <pgwire_connection+0xec>  // b.none
      status = pg_send_error(fd, "0A000", "frontend message is not supported");
    46b0:	b0000000 	adrp	x0, 5000 <pgwire_connection+0xba0>
    46b4:	91175400 	add	x0, x0, #0x5d5
    46b8:	f9003be0 	str	x0, [sp, #112]
    if(pg_read_all(fd, &type, 1) < 0 || pg_read_all(fd, &length, 4) < 0)
    46bc:	91023fe1 	add	x1, sp, #0x8f
    46c0:	2a1303e0 	mov	w0, w19
    46c4:	52800022 	mov	w2, #0x1                   	// #1
    46c8:	97fff94d 	bl	2bfc <pg_read_all>
    46cc:	3100041f 	cmn	w0, #0x1
    46d0:	54fff3e0 	b.eq	454c <pgwire_connection+0xec>  // b.none
    46d4:	910243e1 	add	x1, sp, #0x90
    46d8:	2a1303e0 	mov	w0, w19
    46dc:	52800082 	mov	w2, #0x4                   	// #4
    46e0:	97fff947 	bl	2bfc <pg_read_all>
    46e4:	3100041f 	cmn	w0, #0x1
    46e8:	54fff320 	b.eq	454c <pgwire_connection+0xec>  // b.none
    length = pg_be32(length);
    46ec:	b94093e0 	ldr	w0, [sp, #144]
    46f0:	97fff6dc 	bl	2260 <pg_be32>
    if(length < 4 || length - 4 >= sizeof(message))
    46f4:	51001002 	sub	w2, w0, #0x4
    length = pg_be32(length);
    46f8:	b90093e0 	str	w0, [sp, #144]
    if(length < 4 || length - 4 >= sizeof(message))
    46fc:	711ffc5f 	cmp	w2, #0x7ff
    4700:	54fff268 	b.hi	454c <pgwire_connection+0xec>  // b.pmore
    if(pg_read_all(fd, message, length - 4) < 0)
    4704:	aa1503e1 	mov	x1, x21
    4708:	2a1303e0 	mov	w0, w19
    470c:	97fff93c 	bl	2bfc <pg_read_all>
    4710:	3100041f 	cmn	w0, #0x1
    4714:	54fff1c0 	b.eq	454c <pgwire_connection+0xec>  // b.none
    message[length - 4] = 0;
    4718:	b94093f4 	ldr	w20, [sp, #144]
    if(type == 'X')
    471c:	39423fe0 	ldrb	w0, [sp, #143]
    message[length - 4] = 0;
    4720:	51001281 	sub	w1, w20, #0x4
    4724:	51001294 	sub	w20, w20, #0x4
    4728:	38346abf 	strb	wzr, [x21, x20]
    if(type == 'X')
    472c:	7101601f 	cmp	w0, #0x58
    4730:	54fff0e0 	b.eq	454c <pgwire_connection+0xec>  // b.none
    if(type == 'S'){
    4734:	71014c1f 	cmp	w0, #0x53
    4738:	54000101 	b.ne	4758 <pgwire_connection+0x2f8>  // b.any
      if(pg_send_ready(fd, tx.active) < 0)
    473c:	b940c3e1 	ldr	w1, [sp, #192]
    4740:	2a1303e0 	mov	w0, w19
      extended.failed = 0;
    4744:	b91f1fff 	str	wzr, [sp, #7964]
      if(pg_send_ready(fd, tx.active) < 0)
    4748:	97fff7fe 	bl	2740 <pg_send_ready>
    474c:	3100041f 	cmn	w0, #0x1
    4750:	54fffb61 	b.ne	46bc <pgwire_connection+0x25c>  // b.any
    4754:	17ffff7e 	b	454c <pgwire_connection+0xec>
    if(extended.failed)
    4758:	b95f1ffa 	ldr	w26, [sp, #7964]
    475c:	35fffb1a 	cbnz	w26, 46bc <pgwire_connection+0x25c>
    if(type == 'Q'){
    4760:	7101441f 	cmp	w0, #0x51
    4764:	540002a1 	b.ne	47b8 <pgwire_connection+0x358>  // b.any
      status = pg_execute_query(fd, db, &tx, (char *)message, 1);
    4768:	f94033e1 	ldr	x1, [sp, #96]
    476c:	aa1503e3 	mov	x3, x21
    4770:	910303e2 	add	x2, sp, #0xc0
    4774:	2a1303e0 	mov	w0, w19
    4778:	52800024 	mov	w4, #0x1                   	// #1
    477c:	97fffdbf 	bl	3e78 <pg_execute_query>
      if(status >= 0)
    4780:	3100041f 	cmn	w0, #0x1
    4784:	54ffee40 	b.eq	454c <pgwire_connection+0xec>  // b.none
        status = pg_send_ready(fd, tx.active);
    4788:	b940c3e1 	ldr	w1, [sp, #192]
    478c:	2a1303e0 	mov	w0, w19
    4790:	97fff7ec 	bl	2740 <pg_send_ready>
    if(status < 0)
    4794:	3100041f 	cmn	w0, #0x1
    4798:	54ffeda0 	b.eq	454c <pgwire_connection+0xec>  // b.none
    if(type != 'Q' && status > 0)
    479c:	39423fe1 	ldrb	w1, [sp, #143]
    47a0:	7101443f 	cmp	w1, #0x51
    47a4:	54fff8c0 	b.eq	46bc <pgwire_connection+0x25c>  // b.none
    47a8:	7100041f 	cmp	w0, #0x1
    47ac:	54fff881 	b.ne	46bc <pgwire_connection+0x25c>  // b.any
      extended.failed = 1;
    47b0:	b91f1fe0 	str	w0, [sp, #7964]
    47b4:	17ffffc2 	b	46bc <pgwire_connection+0x25c>
    } else if(type == 'P')
    47b8:	7101401f 	cmp	w0, #0x50
    47bc:	54000881 	b.ne	48cc <pgwire_connection+0x46c>  // b.any
  uchar *cursor = message, *end = message + length;
    47c0:	8b1402b4 	add	x20, x21, x20
  char *name = pg_cstring(&cursor, end);
    47c4:	910b43e0 	add	x0, sp, #0x2d0
    47c8:	aa1403e1 	mov	x1, x20
  uchar *cursor = message, *end = message + length;
    47cc:	f9016bf5 	str	x21, [sp, #720]
  char *name = pg_cstring(&cursor, end);
    47d0:	97fff6ca 	bl	22f8 <pg_cstring>
    47d4:	aa0003e4 	mov	x4, x0
  char *sql = pg_cstring(&cursor, end);
    47d8:	910b43e0 	add	x0, sp, #0x2d0
    47dc:	97fff6c7 	bl	22f8 <pg_cstring>
  if(name == 0 || sql == 0 || cursor + 2 > end)
    47e0:	f100009f 	cmp	x4, #0x0
  char *sql = pg_cstring(&cursor, end);
    47e4:	aa0003f8 	mov	x24, x0
  if(name == 0 || sql == 0 || cursor + 2 > end)
    47e8:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    47ec:	540000a0 	b.eq	4800 <pgwire_connection+0x3a0>  // b.none
    47f0:	f9416be0 	ldr	x0, [sp, #720]
    47f4:	91000817 	add	x23, x0, #0x2
    47f8:	eb17029f 	cmp	x20, x23
    47fc:	540000c2 	b.cs	4814 <pgwire_connection+0x3b4>  // b.hs, b.nlast
    return pg_send_error(fd, "08P01", "malformed Parse message");
    4800:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4804:	91104442 	add	x2, x2, #0x411
    return pg_send_error(fd, "08P01", "malformed Describe message");
    4808:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    480c:	910e2821 	add	x1, x1, #0x38a
    4810:	14000083 	b	4a1c <pgwire_connection+0x5bc>
  int count = pg_get16(cursor);
    4814:	97fff75c 	bl	2584 <pg_get16>
    4818:	12003c16 	and	w22, w0, #0xffff
  cursor += 2;
    481c:	f9016bf7 	str	x23, [sp, #720]
  if(count > PG_MAX_PARAMS || cursor + count * 4 > end)
    4820:	710042df 	cmp	w22, #0x10
    4824:	5400008c 	b.gt	4834 <pgwire_connection+0x3d4>
    4828:	8b362af7 	add	x23, x23, w22, uxth #2
    482c:	eb17029f 	cmp	x20, x23
    4830:	540000c2 	b.cs	4848 <pgwire_connection+0x3e8>  // b.hs, b.nlast
    return pg_send_error(fd, "54000", "too many query parameters");
    4834:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4838:	9110a442 	add	x2, x2, #0x429
    return pg_send_error(fd, "54000", "bound query is too long");
    483c:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4840:	91110c21 	add	x1, x1, #0x443
    4844:	14000076 	b	4a1c <pgwire_connection+0x5bc>
  if(strlen(sql) >= sizeof(extended->statement))
    4848:	aa1803e0 	mov	x0, x24
    484c:	97fff12f 	bl	d08 <strlen@plt>
    4850:	711ffc1f 	cmp	w0, #0x7ff
    4854:	54000089 	b.ls	4864 <pgwire_connection+0x404>  // b.plast
    return pg_send_error(fd, "54000", "prepared statement is too long");
    4858:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    485c:	91112442 	add	x2, x2, #0x449
    4860:	17fffff7 	b	483c <pgwire_connection+0x3dc>
  strcpy(extended->statement, sql);
    4864:	aa1803e1 	mov	x1, x24
    4868:	aa1903e0 	mov	x0, x25
  for(int i = 0; i < count; i++, cursor += 4)
    486c:	d2800014 	mov	x20, #0x0                   	// #0
  strcpy(extended->statement, sql);
    4870:	97fff0b2 	bl	b38 <strcpy@plt>
  extended->parameter_count = count;
    4874:	b91f13f6 	str	w22, [sp, #7952]
  for(int i = 0; i < count; i++, cursor += 4)
    4878:	6b1402df 	cmp	w22, w20
    487c:	5400016c 	b.gt	48a8 <pgwire_connection+0x448>
  extended->statement_valid = 1;
    4880:	d283e287 	mov	x7, #0x1f14                	// #7956
    4884:	8b2763e1 	add	x1, sp, x7
    4888:	d2800020 	mov	x0, #0x1                   	// #1
  return pg_send(fd, '1', 0, 0);           // ParseComplete
    488c:	52800003 	mov	w3, #0x0                   	// #0
    4890:	d2800002 	mov	x2, #0x0                   	// #0
  extended->statement_valid = 1;
    4894:	f9000020 	str	x0, [x1]
  return pg_send(fd, '1', 0, 0);           // ParseComplete
    4898:	52800621 	mov	w1, #0x31                  	// #49
      status = pg_send(fd, '3', 0, 0);       // CloseComplete
    489c:	2a1303e0 	mov	w0, w19
    48a0:	97fff789 	bl	26c4 <pg_send>
    48a4:	17ffffbc 	b	4794 <pgwire_connection+0x334>
    extended->parameter_oid[i] = pg_get32(cursor);
    48a8:	f9416bf7 	ldr	x23, [sp, #720]
    48ac:	aa1703e0 	mov	x0, x23
    48b0:	97fff73f 	bl	25ac <pg_get32>
    48b4:	8b140b21 	add	x1, x25, x20, lsl #2
  for(int i = 0; i < count; i++, cursor += 4)
    48b8:	910012f7 	add	x23, x23, #0x4
    48bc:	91000694 	add	x20, x20, #0x1
    48c0:	f9016bf7 	str	x23, [sp, #720]
    extended->parameter_oid[i] = pg_get32(cursor);
    48c4:	b9100020 	str	w0, [x1, #4096]
  for(int i = 0; i < count; i++, cursor += 4)
    48c8:	17ffffec 	b	4878 <pgwire_connection+0x418>
    else if(type == 'B')
    48cc:	7101081f 	cmp	w0, #0x42
    48d0:	54001e21 	b.ne	4c94 <pgwire_connection+0x834>  // b.any
  uchar *cursor = message, *end = message + length;
    48d4:	8b1402b4 	add	x20, x21, x20
  if(pg_cstring(&cursor, end) == 0 || pg_cstring(&cursor, end) == 0 ||
    48d8:	910263e0 	add	x0, sp, #0x98
    48dc:	aa1403e1 	mov	x1, x20
  uchar *cursor = message, *end = message + length;
    48e0:	f9004ff5 	str	x21, [sp, #152]
  if(pg_cstring(&cursor, end) == 0 || pg_cstring(&cursor, end) == 0 ||
    48e4:	97fff685 	bl	22f8 <pg_cstring>
    48e8:	b4000140 	cbz	x0, 4910 <pgwire_connection+0x4b0>
    48ec:	910263e0 	add	x0, sp, #0x98
    48f0:	97fff682 	bl	22f8 <pg_cstring>
    48f4:	b40000e0 	cbz	x0, 4910 <pgwire_connection+0x4b0>
     cursor + 2 > end || !extended->statement_valid)
    48f8:	f9404fe0 	ldr	x0, [sp, #152]
    48fc:	91000817 	add	x23, x0, #0x2
  if(pg_cstring(&cursor, end) == 0 || pg_cstring(&cursor, end) == 0 ||
    4900:	eb17029f 	cmp	x20, x23
    4904:	54000063 	b.cc	4910 <pgwire_connection+0x4b0>  // b.lo, b.ul, b.last
     cursor + 2 > end || !extended->statement_valid)
    4908:	b95f17e1 	ldr	w1, [sp, #7956]
    490c:	350000c1 	cbnz	w1, 4924 <pgwire_connection+0x4c4>
    return pg_send_error(fd, "26000", "prepared statement does not exist");
    4910:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4914:	9111a042 	add	x2, x2, #0x468
  return pg_send_error(fd, "26000", "portal does not exist");
    4918:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    491c:	91122821 	add	x1, x1, #0x48a
    4920:	1400003f 	b	4a1c <pgwire_connection+0x5bc>
  int format_count = pg_get16(cursor);
    4924:	97fff718 	bl	2584 <pg_get16>
    4928:	12003c16 	and	w22, w0, #0xffff
  if(format_count > PG_MAX_PARAMS || cursor + format_count * 2 + 2 > end)
    492c:	710042df 	cmp	w22, #0x10
    4930:	540003ec 	b.gt	49ac <pgwire_connection+0x54c>
    4934:	110006c0 	add	w0, w22, #0x1
    4938:	d37f4000 	ubfiz	x0, x0, #1, #17
    493c:	8b0002e0 	add	x0, x23, x0
    4940:	eb00029f 	cmp	x20, x0
    4944:	54000343 	b.cc	49ac <pgwire_connection+0x54c>  // b.lo, b.ul, b.last
    4948:	aa1703fb 	mov	x27, x23
    formats[i] = pg_get16(cursor);
    494c:	910283fc 	add	x28, sp, #0xa0
  if(format_count > PG_MAX_PARAMS || cursor + format_count * 2 + 2 > end)
    4950:	d2800018 	mov	x24, #0x0                   	// #0
  for(int i = 0; i < format_count; i++, cursor += 2)
    4954:	6b1802df 	cmp	w22, w24
    4958:	5400030c 	b.gt	49b8 <pgwire_connection+0x558>
    495c:	d37f3edc 	ubfiz	x28, x22, #1, #16
  int count = pg_get16(cursor);
    4960:	8b1c02e0 	add	x0, x23, x28
    4964:	97fff708 	bl	2584 <pg_get16>
  if(count != extended->parameter_count || count > PG_MAX_PARAMS)
    4968:	b95f13e1 	ldr	w1, [sp, #7952]
  int count = pg_get16(cursor);
    496c:	12003c1b 	and	w27, w0, #0xffff
  if(count != extended->parameter_count || count > PG_MAX_PARAMS)
    4970:	6b20203f 	cmp	w1, w0, uxth
    4974:	540002e1 	b.ne	49d0 <pgwire_connection+0x570>  // b.any
    4978:	7100437f 	cmp	w27, #0x10
    497c:	540002ac 	b.gt	49d0 <pgwire_connection+0x570>
    4980:	91000ae3 	add	x3, x23, #0x2
    4984:	d2800017 	mov	x23, #0x0                   	// #0
    4988:	8b1c007c 	add	x28, x3, x28
  for(int i = 0; i < count; i++){
    498c:	6b17037f 	cmp	w27, w23
    4990:	5400026c 	b.gt	49dc <pgwire_connection+0x57c>
  if(cursor + 2 > end)
    4994:	91000b97 	add	x23, x28, #0x2
    4998:	eb17029f 	cmp	x20, x23
    499c:	54000c22 	b.cs	4b20 <pgwire_connection+0x6c0>  // b.hs, b.nlast
    return pg_send_error(fd, "08P01", "missing Bind result formats");
    49a0:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    49a4:	9114ac42 	add	x2, x2, #0x52b
    49a8:	17ffff98 	b	4808 <pgwire_connection+0x3a8>
    return pg_send_error(fd, "08P01", "malformed Bind formats");
    49ac:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    49b0:	91124042 	add	x2, x2, #0x490
    49b4:	17ffff95 	b	4808 <pgwire_connection+0x3a8>
    formats[i] = pg_get16(cursor);
    49b8:	aa1b03e0 	mov	x0, x27
    49bc:	91000b7b 	add	x27, x27, #0x2
    49c0:	97fff6f1 	bl	2584 <pg_get16>
    49c4:	78387b80 	strh	w0, [x28, x24, lsl #1]
  for(int i = 0; i < format_count; i++, cursor += 2)
    49c8:	91000718 	add	x24, x24, #0x1
    49cc:	17ffffe2 	b	4954 <pgwire_connection+0x4f4>
    return pg_send_error(fd, "08P01", "Bind parameter count mismatch");
    49d0:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    49d4:	91129c42 	add	x2, x2, #0x4a7
    49d8:	17ffff8c 	b	4808 <pgwire_connection+0x3a8>
    if(cursor + 4 > end)
    49dc:	91001381 	add	x1, x28, #0x4
    49e0:	eb01029f 	cmp	x20, x1
    49e4:	54000082 	b.cs	49f4 <pgwire_connection+0x594>  // b.hs, b.nlast
      return pg_send_error(fd, "08P01", "truncated Bind parameter");
    49e8:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    49ec:	91131442 	add	x2, x2, #0x4c5
    49f0:	17ffff86 	b	4808 <pgwire_connection+0x3a8>
    uint32 n = pg_get32(cursor);
    49f4:	aa1c03e0 	mov	x0, x28
    49f8:	f90037e1 	str	x1, [sp, #104]
    49fc:	97fff6ec 	bl	25ac <pg_get32>
    if(n == 0xffffffffU)
    4a00:	3100041f 	cmn	w0, #0x1
    4a04:	f94037e1 	ldr	x1, [sp, #104]
    4a08:	54000101 	b.ne	4a28 <pgwire_connection+0x5c8>  // b.any
      return pg_send_error(fd, "22004", "NULL parameters are not supported");
    4a0c:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4a10:	91137842 	add	x2, x2, #0x4de
    4a14:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4a18:	91140021 	add	x1, x1, #0x500
      status = pg_send_error(fd, "0A000", "frontend message is not supported");
    4a1c:	2a1303e0 	mov	w0, w19
    4a20:	97fff836 	bl	2af8 <pg_send_error>
    4a24:	17ffff5c 	b	4794 <pgwire_connection+0x334>
    if(cursor + n > end)
    4a28:	8b204022 	add	x2, x1, w0, uxtw
    4a2c:	f90037e2 	str	x2, [sp, #104]
    4a30:	2a0003e4 	mov	w4, w0
    4a34:	eb02029f 	cmp	x20, x2
    4a38:	54fffd83 	b.cc	49e8 <pgwire_connection+0x588>  // b.lo, b.ul, b.last
    if(pg_parameter_text(parameter[i], sizeof(parameter[i]), cursor, n,
    4a3c:	d37a7ef8 	ubfiz	x24, x23, #6, #32
    4a40:	910b43e2 	add	x2, sp, #0x2d0
    4a44:	8b020318 	add	x24, x24, x2
    int format = format_count == 0 ? 0 : formats[format_count == 1 ? 0 : i];
    4a48:	340000d6 	cbz	w22, 4a60 <pgwire_connection+0x600>
    4a4c:	710006df 	cmp	w22, #0x1
  if(format == 0){
    4a50:	910283e3 	add	x3, sp, #0xa0
    int format = format_count == 0 ? 0 : formats[format_count == 1 ? 0 : i];
    4a54:	9a9f12e2 	csel	x2, x23, xzr, ne	// ne = any
  if(format == 0){
    4a58:	78625862 	ldrh	w2, [x3, w2, uxtw #1]
    4a5c:	350001a2 	cbnz	w2, 4a90 <pgwire_connection+0x630>
    if(length + 1 > output_size)
    4a60:	11000402 	add	w2, w0, #0x1
    4a64:	7101005f 	cmp	w2, #0x40
    4a68:	54000528 	b.hi	4b0c <pgwire_connection+0x6ac>  // b.pmore
    memmove(output, data, length);
    4a6c:	2a0003e2 	mov	w2, w0
    4a70:	aa1803e0 	mov	x0, x24
    4a74:	f9003fe4 	str	x4, [sp, #120]
    4a78:	97fff044 	bl	b88 <memmove@plt>
    output[length] = 0;
    4a7c:	f9403fe4 	ldr	x4, [sp, #120]
    4a80:	38246b1f 	strb	wzr, [x24, x4]
  if(count != extended->parameter_count || count > PG_MAX_PARAMS)
    4a84:	f94037fc 	ldr	x28, [sp, #104]
    4a88:	910006f7 	add	x23, x23, #0x1
    4a8c:	17ffffc0 	b	498c <pgwire_connection+0x52c>
    if(pg_parameter_text(parameter[i], sizeof(parameter[i]), cursor, n,
    4a90:	913b43e2 	add	x2, sp, #0xed0
    4a94:	8b170842 	add	x2, x2, x23, lsl #2
    4a98:	b9500042 	ldr	w2, [x2, #4096]
  if((oid == 21 && length == 2))
    4a9c:	7100545f 	cmp	w2, #0x15
    4aa0:	7a420800 	ccmp	w0, #0x2, #0x0, eq	// eq = none
    4aa4:	540000e1 	b.ne	4ac0 <pgwire_connection+0x660>  // b.any
    value = pg_get16(data);
    4aa8:	aa0103e0 	mov	x0, x1
    4aac:	97fff6b6 	bl	2584 <pg_get16>
    4ab0:	92403c00 	and	x0, x0, #0xffff
  pg_u64toa(value, output);
    4ab4:	aa1803e1 	mov	x1, x24
    4ab8:	97fff5ec 	bl	2268 <pg_u64toa>
  return 0;
    4abc:	17fffff2 	b	4a84 <pgwire_connection+0x624>
  else if((oid == 23 && length == 4))
    4ac0:	71005c5f 	cmp	w2, #0x17
    4ac4:	7a440800 	ccmp	w0, #0x4, #0x0, eq	// eq = none
    4ac8:	540000a1 	b.ne	4adc <pgwire_connection+0x67c>  // b.any
    value = pg_get32(data);
    4acc:	aa0103e0 	mov	x0, x1
    4ad0:	97fff6b7 	bl	25ac <pg_get32>
    4ad4:	2a0003e0 	mov	w0, w0
    4ad8:	17fffff7 	b	4ab4 <pgwire_connection+0x654>
  else if(oid == 20 && length == 8)
    4adc:	7100505f 	cmp	w2, #0x14
    4ae0:	7a480800 	ccmp	w0, #0x8, #0x0, eq	// eq = none
    4ae4:	54000141 	b.ne	4b0c <pgwire_connection+0x6ac>  // b.any
    value = ((uint64)pg_get32(data) << 32) | pg_get32(data + 4);
    4ae8:	aa0103e0 	mov	x0, x1
    4aec:	97fff6b0 	bl	25ac <pg_get32>
    4af0:	b9007be0 	str	w0, [sp, #120]
    4af4:	91002380 	add	x0, x28, #0x8
    4af8:	97fff6ad 	bl	25ac <pg_get32>
    4afc:	2a0003e0 	mov	w0, w0
    4b00:	f9403fe1 	ldr	x1, [sp, #120]
    4b04:	aa018000 	orr	x0, x0, x1, lsl #32
    4b08:	17ffffeb 	b	4ab4 <pgwire_connection+0x654>
      return pg_send_error(fd, "0A000", "unsupported parameter format or type");
    4b0c:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4b10:	91141842 	add	x2, x2, #0x506
      return pg_send_error(fd, "0A000", "binary query results are not supported");
    4b14:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4b18:	910d6821 	add	x1, x1, #0x35a
    4b1c:	17ffffc0 	b	4a1c <pgwire_connection+0x5bc>
  int result_formats = pg_get16(cursor);
    4b20:	aa1c03e0 	mov	x0, x28
    4b24:	97fff698 	bl	2584 <pg_get16>
    4b28:	12003c16 	and	w22, w0, #0xffff
  cursor += 2;
    4b2c:	f9004ff7 	str	x23, [sp, #152]
  if(result_formats > PG_MAX_PARAMS || cursor + result_formats * 2 > end)
    4b30:	710042df 	cmp	w22, #0x10
    4b34:	5400008c 	b.gt	4b44 <pgwire_connection+0x6e4>
    4b38:	8b3626f7 	add	x23, x23, w22, uxth #1
    4b3c:	eb17029f 	cmp	x20, x23
    4b40:	540001e2 	b.cs	4b7c <pgwire_connection+0x71c>  // b.hs, b.nlast
    return pg_send_error(fd, "08P01", "malformed Bind result formats");
    4b44:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4b48:	91151c42 	add	x2, x2, #0x547
    4b4c:	17ffff2f 	b	4808 <pgwire_connection+0x3a8>
    if(pg_get16(cursor) != 0)
    4b50:	f9404ff4 	ldr	x20, [sp, #152]
    4b54:	aa1403e0 	mov	x0, x20
    4b58:	97fff68b 	bl	2584 <pg_get16>
    4b5c:	72003c1f 	tst	w0, #0xffff
    4b60:	54000080 	b.eq	4b70 <pgwire_connection+0x710>  // b.none
      return pg_send_error(fd, "0A000", "binary query results are not supported");
    4b64:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4b68:	91159442 	add	x2, x2, #0x565
    4b6c:	17ffffea 	b	4b14 <pgwire_connection+0x6b4>
  for(int i = 0; i < result_formats; i++, cursor += 2)
    4b70:	1100075a 	add	w26, w26, #0x1
    4b74:	91000a94 	add	x20, x20, #0x2
    4b78:	f9004ff4 	str	x20, [sp, #152]
    4b7c:	6b1a02df 	cmp	w22, w26
    4b80:	54fffe8c 	b.gt	4b50 <pgwire_connection+0x6f0>
      output[used++] = sql[i++];
    4b84:	d282da06 	mov	x6, #0x16d0                	// #5840
  for(uint i = 0; sql[i];){
    4b88:	913b43f4 	add	x20, sp, #0xed0
      output[used++] = sql[i++];
    4b8c:	8b2663fc 	add	x28, sp, x6
  for(uint i = 0; sql[i];){
    4b90:	52800000 	mov	w0, #0x0                   	// #0
  uint used = 0;
    4b94:	52800017 	mov	w23, #0x0                   	// #0
        number = number * 10 + (sql[i++] - '0');
    4b98:	52800156 	mov	w22, #0xa                   	// #10
  for(uint i = 0; sql[i];){
    4b9c:	38604a82 	ldrb	w2, [x20, w0, uxtw]
    4ba0:	35000142 	cbnz	w2, 4bc8 <pgwire_connection+0x768>
  output[used] = 0;
    4ba4:	d282da03 	mov	x3, #0x16d0                	// #5840
    4ba8:	8b2363e0 	add	x0, sp, x3
  return pg_send(fd, '2', 0, 0);           // BindComplete
    4bac:	d2800002 	mov	x2, #0x0                   	// #0
    4bb0:	52800003 	mov	w3, #0x0                   	// #0
    4bb4:	52800641 	mov	w1, #0x32                  	// #50
  output[used] = 0;
    4bb8:	3837481f 	strb	wzr, [x0, w23, uxtw]
  extended->portal_valid = 1;
    4bbc:	52800020 	mov	w0, #0x1                   	// #1
    4bc0:	b91f1be0 	str	w0, [sp, #7960]
  return pg_send(fd, '2', 0, 0);           // BindComplete
    4bc4:	17ffff36 	b	489c <pgwire_connection+0x43c>
    if(sql[i] == '$' && sql[i + 1] >= '1' && sql[i + 1] <= '9'){
    4bc8:	7100905f 	cmp	w2, #0x24
    4bcc:	54000101 	b.ne	4bec <pgwire_connection+0x78c>  // b.any
    4bd0:	11000401 	add	w1, w0, #0x1
    4bd4:	11000418 	add	w24, w0, #0x1
    4bd8:	38616a81 	ldrb	w1, [x20, x1]
    4bdc:	5100c421 	sub	w1, w1, #0x31
    4be0:	12001c21 	and	w1, w1, #0xff
    4be4:	7100203f 	cmp	w1, #0x8
    4be8:	540004c9 	b.ls	4c80 <pgwire_connection+0x820>  // b.plast
      if(used + 2 > output_size)
    4bec:	711ffeff 	cmp	w23, #0x7ff
    4bf0:	540004c0 	b.eq	4c88 <pgwire_connection+0x828>  // b.none
      output[used++] = sql[i++];
    4bf4:	11000418 	add	w24, w0, #0x1
    4bf8:	110006e4 	add	w4, w23, #0x1
    4bfc:	38374b82 	strb	w2, [x28, w23, uxtw]
    4c00:	1400001d 	b	4c74 <pgwire_connection+0x814>
        number = number * 10 + (sql[i++] - '0');
    4c04:	1b160821 	madd	w1, w1, w22, w2
    4c08:	11000718 	add	w24, w24, #0x1
    4c0c:	5100c021 	sub	w1, w1, #0x30
      while(sql[i] >= '0' && sql[i] <= '9')
    4c10:	38784a82 	ldrb	w2, [x20, w24, uxtw]
    4c14:	5100c040 	sub	w0, w2, #0x30
    4c18:	12001c00 	and	w0, w0, #0xff
    4c1c:	7100241f 	cmp	w0, #0x9
    4c20:	54ffff29 	b.ls	4c04 <pgwire_connection+0x7a4>  // b.plast
      if(number == 0 || number > (uint)count)
    4c24:	51000421 	sub	w1, w1, #0x1
    4c28:	6b01037f 	cmp	w27, w1
    4c2c:	540002e9 	b.ls	4c88 <pgwire_connection+0x828>  // b.plast
      char *value = parameter[number - 1];
    4c30:	d37a7c21 	ubfiz	x1, x1, #6, #32
    4c34:	910b43fa 	add	x26, sp, #0x2d0
    4c38:	8b01035a 	add	x26, x26, x1
      uint n = strlen(value);
    4c3c:	aa1a03e0 	mov	x0, x26
    4c40:	97fff032 	bl	d08 <strlen@plt>
      if(used + n + 1 > output_size)
    4c44:	0b170004 	add	w4, w0, w23
    4c48:	11000481 	add	w1, w4, #0x1
    4c4c:	7120003f 	cmp	w1, #0x800
    4c50:	540001c8 	b.hi	4c88 <pgwire_connection+0x828>  // b.pmore
      memmove(output + used, value, n);
    4c54:	d282da05 	mov	x5, #0x16d0                	// #5840
    4c58:	2a0003e2 	mov	w2, w0
    4c5c:	8b2563e0 	add	x0, sp, x5
    4c60:	aa1a03e1 	mov	x1, x26
    4c64:	8b374000 	add	x0, x0, w23, uxtw
    4c68:	b9006be4 	str	w4, [sp, #104]
    4c6c:	97ffefc7 	bl	b88 <memmove@plt>
    if(sql[i] == '$' && sql[i + 1] >= '1' && sql[i + 1] <= '9'){
    4c70:	b9406be4 	ldr	w4, [sp, #104]
  uint used = 0;
    4c74:	2a1803e0 	mov	w0, w24
    4c78:	2a0403f7 	mov	w23, w4
    4c7c:	17ffffc8 	b	4b9c <pgwire_connection+0x73c>
      uint number = 0;
    4c80:	52800001 	mov	w1, #0x0                   	// #0
    4c84:	17ffffe3 	b	4c10 <pgwire_connection+0x7b0>
    return pg_send_error(fd, "54000", "bound query is too long");
    4c88:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4c8c:	91163042 	add	x2, x2, #0x58c
    4c90:	17fffeeb 	b	483c <pgwire_connection+0x3dc>
    else if(type == 'D')
    4c94:	7101101f 	cmp	w0, #0x44
    4c98:	54000601 	b.ne	4d58 <pgwire_connection+0x8f8>  // b.any
  if(length < 2)
    4c9c:	7100043f 	cmp	w1, #0x1
    4ca0:	54000088 	b.hi	4cb0 <pgwire_connection+0x850>  // b.pmore
    return pg_send_error(fd, "08P01", "malformed Describe message");
    4ca4:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4ca8:	91169042 	add	x2, x2, #0x5a4
    4cac:	17fffed7 	b	4808 <pgwire_connection+0x3a8>
    4cb0:	395b43e0 	ldrb	w0, [sp, #1744]
  if(message[0] == 'S'){
    4cb4:	71014c1f 	cmp	w0, #0x53
    4cb8:	540003c1 	b.ne	4d30 <pgwire_connection+0x8d0>  // b.any
    pg_put16(payload, &position, extended->parameter_count);
    4cbc:	797e23e2 	ldrh	w2, [sp, #7952]
    4cc0:	910283e1 	add	x1, sp, #0xa0
    4cc4:	910b43e0 	add	x0, sp, #0x2d0
    for(int i = 0; i < extended->parameter_count; i++)
    4cc8:	d2800014 	mov	x20, #0x0                   	// #0
    uint position = 0;
    4ccc:	b900a3ff 	str	wzr, [sp, #160]
    pg_put16(payload, &position, extended->parameter_count);
    4cd0:	97fff640 	bl	25d0 <pg_put16>
    for(int i = 0; i < extended->parameter_count; i++)
    4cd4:	b95f13e0 	ldr	w0, [sp, #7952]
    4cd8:	6b14001f 	cmp	w0, w20
    4cdc:	540001cc 	b.gt	4d14 <pgwire_connection+0x8b4>
    if(!extended->statement_valid || pg_send(fd, 't', payload, position) < 0)
    4ce0:	b95f17e0 	ldr	w0, [sp, #7956]
    4ce4:	34ffc340 	cbz	w0, 454c <pgwire_connection+0xec>
    4ce8:	b940a3e3 	ldr	w3, [sp, #160]
    4cec:	910b43e2 	add	x2, sp, #0x2d0
    4cf0:	2a1303e0 	mov	w0, w19
    4cf4:	52800e81 	mov	w1, #0x74                  	// #116
    4cf8:	97fff673 	bl	26c4 <pg_send>
    4cfc:	3100041f 	cmn	w0, #0x1
    4d00:	54ffc260 	b.eq	454c <pgwire_connection+0xec>  // b.none
    return pg_describe_query(fd, extended->statement);
    4d04:	913b43e1 	add	x1, sp, #0xed0
    return pg_describe_query(fd, extended->portal);
    4d08:	2a1303e0 	mov	w0, w19
    4d0c:	97fffae9 	bl	38b0 <pg_describe_query>
    4d10:	17fffea1 	b	4794 <pgwire_connection+0x334>
      pg_put32(payload, &position, extended->parameter_oid[i]);
    4d14:	8b140b20 	add	x0, x25, x20, lsl #2
    4d18:	910283e1 	add	x1, sp, #0xa0
    4d1c:	91000694 	add	x20, x20, #0x1
    4d20:	b9500002 	ldr	w2, [x0, #4096]
    4d24:	910b43e0 	add	x0, sp, #0x2d0
    4d28:	97fff63b 	bl	2614 <pg_put32>
    for(int i = 0; i < extended->parameter_count; i++)
    4d2c:	17ffffea 	b	4cd4 <pgwire_connection+0x874>
  if(message[0] == 'P' && extended->portal_valid)
    4d30:	7101401f 	cmp	w0, #0x50
    4d34:	540000c1 	b.ne	4d4c <pgwire_connection+0x8ec>  // b.any
    4d38:	b95f1be0 	ldr	w0, [sp, #7960]
    4d3c:	34000080 	cbz	w0, 4d4c <pgwire_connection+0x8ec>
    return pg_describe_query(fd, extended->portal);
    4d40:	d282da02 	mov	x2, #0x16d0                	// #5840
    4d44:	8b2263e1 	add	x1, sp, x2
    4d48:	17fffff0 	b	4d08 <pgwire_connection+0x8a8>
  return pg_send_error(fd, "26000", "portal does not exist");
    4d4c:	b0000002 	adrp	x2, 5000 <pgwire_connection+0xba0>
    4d50:	9116fc42 	add	x2, x2, #0x5bf
    4d54:	17fffef1 	b	4918 <pgwire_connection+0x4b8>
    else if(type == 'E'){
    4d58:	7101141f 	cmp	w0, #0x45
    4d5c:	54000161 	b.ne	4d88 <pgwire_connection+0x928>  // b.any
      if(!extended.portal_valid)
    4d60:	b95f1be0 	ldr	w0, [sp, #7960]
    4d64:	34ffff40 	cbz	w0, 4d4c <pgwire_connection+0x8ec>
        status = pg_execute_query(fd, db, &tx, extended.portal, 0);
    4d68:	d282da01 	mov	x1, #0x16d0                	// #5840
    4d6c:	8b2163e3 	add	x3, sp, x1
    4d70:	f94033e1 	ldr	x1, [sp, #96]
    4d74:	910303e2 	add	x2, sp, #0xc0
    4d78:	2a1303e0 	mov	w0, w19
    4d7c:	52800004 	mov	w4, #0x0                   	// #0
    4d80:	97fffc3e 	bl	3e78 <pg_execute_query>
    4d84:	17fffe84 	b	4794 <pgwire_connection+0x334>
    } else if(type == 'C'){
    4d88:	71010c1f 	cmp	w0, #0x43
    4d8c:	54000101 	b.ne	4dac <pgwire_connection+0x94c>  // b.any
      extended.statement_valid = extended.portal_valid = 0;
    4d90:	d283e280 	mov	x0, #0x1f14                	// #7956
    4d94:	8b2063e0 	add	x0, sp, x0
      status = pg_send(fd, '3', 0, 0);       // CloseComplete
    4d98:	52800003 	mov	w3, #0x0                   	// #0
    4d9c:	d2800002 	mov	x2, #0x0                   	// #0
    4da0:	52800661 	mov	w1, #0x33                  	// #51
      extended.statement_valid = extended.portal_valid = 0;
    4da4:	f900001f 	str	xzr, [x0]
      status = pg_send(fd, '3', 0, 0);       // CloseComplete
    4da8:	17fffebd 	b	489c <pgwire_connection+0x43c>
    } else if(type == 'H')
    4dac:	7101201f 	cmp	w0, #0x48
    4db0:	54ffc860 	b.eq	46bc <pgwire_connection+0x25c>  // b.none
      status = pg_send_error(fd, "0A000", "frontend message is not supported");
    4db4:	f9403be2 	ldr	x2, [sp, #112]
    4db8:	b0000001 	adrp	x1, 5000 <pgwire_connection+0xba0>
    4dbc:	910d6821 	add	x1, x1, #0x35a
    4dc0:	17ffff17 	b	4a1c <pgwire_connection+0x5bc>
