user/mygres/main.o: user/mygres/main.c include/uapi/types.h \
 include/uapi/stat.h include/uapi/types.h include/uapi/mman.h \
 user/include/fcntl.h user/include/sys/types.h user/include/stddef.h \
 user/include/stdint.h include/uapi/fcntl.h user/user.h
