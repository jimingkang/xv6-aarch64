
user/_mygresd:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000278 <.plt>:
 278:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 27c:	b0000010 	adrp	x16, 1000 <main+0xd38>
 280:	f9424e11 	ldr	x17, [x16, #1176]
 284:	91126210 	add	x16, x16, #0x498
 288:	d61f0220 	br	x17
 28c:	d503201f 	nop
 290:	d503201f 	nop
 294:	d503201f 	nop

0000000000000298 <printf@plt>:
 298:	b0000010 	adrp	x16, 1000 <main+0xd38>
 29c:	f9425211 	ldr	x17, [x16, #1184]
 2a0:	91128210 	add	x16, x16, #0x4a0
 2a4:	d61f0220 	br	x17

00000000000002a8 <exec@plt>:
 2a8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2ac:	f9425611 	ldr	x17, [x16, #1192]
 2b0:	9112a210 	add	x16, x16, #0x4a8
 2b4:	d61f0220 	br	x17

00000000000002b8 <exit@plt>:
 2b8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2bc:	f9425a11 	ldr	x17, [x16, #1200]
 2c0:	9112c210 	add	x16, x16, #0x4b0
 2c4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000002c8 <main>:
// PostgreSQL-style convenience entry point.  The storage engine and client
// protocol live in /bin/mygres; this name makes the resident postmaster role
// explicit without linking a second copy of the engine into libc.
int
main(int argc, char **argv)
{
 2c8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  char *server_argv[4];
  server_argv[0] = "mygres";
 2cc:	90000002 	adrp	x2, 0 <.plt-0x278>
 2d0:	910cd842 	add	x2, x2, #0x336
{
 2d4:	910003fd 	mov	x29, sp
  server_argv[0] = "mygres";
 2d8:	f9000be2 	str	x2, [sp, #16]
  server_argv[1] = "server";
 2dc:	90000002 	adrp	x2, 0 <.plt-0x278>
 2e0:	910ca842 	add	x2, x2, #0x32a
 2e4:	f9000fe2 	str	x2, [sp, #24]
  server_argv[2] = argc > 1 ? argv[1] : "4";
 2e8:	7100041f 	cmp	w0, #0x1
 2ec:	5400018d 	b.le	31c <main+0x54>
 2f0:	f9400420 	ldr	x0, [x1, #8]
  server_argv[3] = 0;
  exec("/bin/mygres", server_argv);
 2f4:	910043e1 	add	x1, sp, #0x10
  server_argv[2] = argc > 1 ? argv[1] : "4";
 2f8:	a9027fe0 	stp	x0, xzr, [sp, #32]
  exec("/bin/mygres", server_argv);
 2fc:	90000000 	adrp	x0, 0 <.plt-0x278>
 300:	910cc400 	add	x0, x0, #0x331
 304:	97ffffe9 	bl	2a8 <exec@plt>
  printf("mygresd: cannot exec /bin/mygres\n");
 308:	90000000 	adrp	x0, 0 <.plt-0x278>
 30c:	910cf400 	add	x0, x0, #0x33d
 310:	97ffffe2 	bl	298 <printf@plt>
  exit(1);
 314:	52800020 	mov	w0, #0x1                   	// #1
 318:	97ffffe8 	bl	2b8 <exit@plt>
  server_argv[2] = argc > 1 ? argv[1] : "4";
 31c:	90000000 	adrp	x0, 0 <.plt-0x278>
 320:	910ca000 	add	x0, x0, #0x328
 324:	17fffff4 	b	2f4 <main+0x2c>
