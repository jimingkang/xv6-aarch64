user/mygres/mygresd.o: user/mygres/mygresd.c include/uapi/types.h \
 user/user.h
