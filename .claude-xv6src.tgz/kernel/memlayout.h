// Physical memory layout

// QEMU Raspberry Pi 3B / BCM2837 physical layout used by this port.
//
// 00000000 -- RAM
// 00080000 -- QEMU loads the 64-bit kernel image here
// 07000000 -- in-memory fs.img loaded by QEMU
// 3f000000 -- BCM2837 peripheral window
// 40000000 -- ARM local peripherals

// the kernel uses physical memory thus:
// 00080000 -- entry.S, then kernel text and data
// end -- start of kernel page allocation area
// PHYSTOP -- end RAM used by the kernel

#define EXTMEM    0x00000000L
#define PHYSTOP   0x07000000L               // keep the ramdisk out of kalloc
#define KERNPA    0x00080000L
#define EARLYTOP  0x00200000L
#define RAMDISK_PA 0x07000000L
#define RAMDISK_SIZE (1024*1024L)
// Physically contiguous DMA memory for the camera (Unicam writes frames
// here).  Above PHYSTOP, so kalloc never hands it out, and mapped
// non-cacheable, so no cache maintenance is needed around DMA.
#define CAMDMA_PA   0x07200000L
#define CAMDMA_SIZE (2*1024*1024L)

// Loadable-module arena.  A .ko's .text must be both writable (the loader
// copies it in and patches relocations) and executable (the kernel later
// branches into the driver's init and probe routines).  The rest of RAM above
// etext is mapped execute-never by kvmmake, so modules get their own region,
// carved above PHYSTOP exactly like the camera DMA buffer: out of kalloc's
// reach, and mapped read/write/execute in one shot.  This is the xv6 form of
// Linux's dedicated [module_start, module_end) vmalloc area.
#define MODAREA_PA   0x07400000L
#define MODAREA_SIZE (1024*1024L)
#define MODAREA      (KERNBASE + MODAREA_PA)

#define KERNBASE  0xffffff8000000000L     // First kernel virtual address
#define KERNLINK  (KERNBASE + KERNPA)     // virtual address where kernel is linked

#define V2P(a) (((uint64)(a)) - KERNBASE)
#define P2V(a) ((void *)(((char *)(a)) + KERNBASE))

#define V2P_WO(x) ((x) - KERNBASE)    // same as V2P, but without casts
#define P2V_WO(x) ((x) + KERNBASE)    // same as P2V, but without casts

// one beyond the highest possible virtual address.
#define MAXVA (KERNBASE + (1ULL<<38))

#define PERIPHERAL_BASE_PA 0x3f000000L
#define PERIPHERAL_BASE    (KERNBASE + PERIPHERAL_BASE_PA)
#define LOCAL_BASE_PA      0x40000000L
#define LOCAL_BASE         (KERNBASE + LOCAL_BASE_PA)

#define MINI_UART   (PERIPHERAL_BASE + 0x215000L)
#define DWC2_IRQ    9    // BCM2837 legacy GPU USB/DWC2 interrupt
#define UART0_IRQ   29   // BCM2837 AUX interrupt (Mini UART)
#define SDIO_IRQ    62   // BCM2837 Arasan EMMC/SDIO interrupt
#define CSI1_IRQ    39   // Unicam CSI1 (DTS: interrupts = <2 7>, GPU IRQ 32+7)
#define TIMER0_IRQ  27
#define IPI_RESCHED_IRQ 1000  // pseudo IRQ number: ARM-local mailbox 0

#define IRQCTRL     (PERIPHERAL_BASE + 0x00b000L)
#define RAMDISK     (KERNBASE + RAMDISK_PA)
#define CAMDMA      (KERNBASE + CAMDMA_PA)

// map kernel stacks beneath the trampoline,
// each surrounded by invalid guard pages.
#define KSTACK(p) (MAXVA - ((p)+1) * 2*PGSIZE)
