// File system implementation.  Five layers:
//   + Blocks: allocator for raw disk blocks.
//   + Log: crash recovery for multi-step updates.
//   + Files: inode allocator, reading, writing, metadata.
//   + Directories: inode with special contents (list of other inodes!)
//   + Names: paths like /usr/rtm/xv6/fs.c for convenient naming.
//
// This file contains the low-level file system manipulation
// routines.  The (higher-level) system call implementations
// are in sysfile.c.

#include <kernel/types.h>
#include "aarch64.h"
#include <kernel/defs.h>
#include <kernel/param.h>
#include <kernel/stat.h>
#include <kernel/spinlock.h>
#include <kernel/proc.h>
#include <kernel/sleeplock.h>
#include <kernel/fs.h>
#include <kernel/buf.h>
#include <kernel/file.h>
#include <kernel/device.h>
#include <kernel/blkdev.h>
#include <kernel/vfs.h>
#include <kernel/fs_trace.h>

#define min(a, b) ((a) < (b) ? (a) : (b))
// One on-disk xv6 superblock per mounted xv6 filesystem, indexed by block
// device number: the root on dev 1 and the RAM-disk instances (rootfs,
// devtmpfs).
static struct superblock sbs[NBLKDEV];
void fs_mountinit(void);
static struct inode_ops xv6_iops;
static struct inode_ops xv6_file_iops;
static struct inode_ops xv6_dir_iops;
static struct inode_ops xv6_device_iops;
static const struct file_operations xv6_file_fops;
static const struct file_operations xv6_dir_fops;

// ---------------------------------------------------------------------------
// VFS super blocks: one per mounted filesystem instance of any type,
// indexed by device number (see vfs.h).

static struct super_block supers[NSUPER];

struct super_block*
getsuper(uint dev)
{
  if(dev >= NSUPER || !supers[dev].used)
    return 0;
  return &supers[dev];
}

// Register (or re-register) the filesystem instance on dev.
int
fs_super_register(int dev, char *type, struct inode_ops *iop, uint rootino,
                  int readonly, int logged, int pathbased, void *priv)
{
  if(dev <= 0 || dev >= NSUPER)
    return -1;
  struct super_block *sb = &supers[dev];
  sb->dev = dev;
  safestrcpy(sb->type, type, sizeof(sb->type));
  sb->iop = iop;
  sb->rootino = rootino;
  sb->readonly = readonly;
  sb->logged = logged;
  sb->pathbased = pathbased;
  sb->priv = priv;
  sb->put_super = 0;
  __sync_synchronize();
  sb->used = 1;
  VFSTRACE("register_super: fs=%s dev=%d rootino=%d ro=%d logged=%d pathbased=%d\n",
           sb->type, sb->dev, sb->rootino, sb->readonly, sb->logged,
           sb->pathbased);
  FSTRACE("register_super: memory superblock installed\n");
  FSTRACE("  used=%d dev=%d type=%s iop=%p rootino=%d\n",
          sb->used, sb->dev, sb->type, (uint64)sb->iop, sb->rootino);
  FSTRACE("  readonly=%d logged=%d pathbased=%d priv=%p\n",
          sb->readonly, sb->logged, sb->pathbased, (uint64)sb->priv);
  return 0;
}

int
fs_super_set_put_super(int dev, int (*put_super)(struct super_block*))
{
  struct super_block *sb = getsuper(dev);
  if(sb == 0)
    return -1;
  sb->put_super = put_super;
  return 0;
}

static void
fs_super_unregister(int dev)
{
  if(dev <= 0 || dev >= NSUPER)
    return;
  struct super_block *sb = &supers[dev];
  sb->used = 0;
  __sync_synchronize();
  sb->dev = 0;
  sb->type[0] = 0;
  sb->iop = 0;
  sb->rootino = 0;
  sb->readonly = 0;
  sb->logged = 0;
  sb->pathbased = 0;
  sb->priv = 0;
  sb->put_super = 0;
}

static struct superblock*
getsb(uint dev)
{
  if(dev >= NBLKDEV || sbs[dev].magic != FSMAGIC)
    panic("getsb: device has no xv6 filesystem");
  return &sbs[dev];
}

// Read and check the superblock of dev (the "fill_super" step of a mount).
int
fs_readsuper(int dev)
{
  struct buf *bp;
  struct superblock s;

  if(dev <= 0 || dev >= NBLKDEV)
    return -1;
  bp = bread(dev, 1);
  if(bp->error){
    brelse(bp);
    return -1;
  }
  memmove(&s, bp->data, sizeof(s));
  brelse(bp);
  if(s.magic != FSMAGIC)
    return -1;
  sbs[dev] = s;
  FSTRACE("fill_super: read xv6fs disk block 1 into memory, dev=%d\n", dev);
  FSTRACE("  magic=%x (format identifier)\n", s.magic);
  FSTRACE("  size=%d (total filesystem blocks)\n", s.size);
  FSTRACE("  nblocks=%d (data blocks)\n", s.nblocks);
  FSTRACE("  ninodes=%d (inode capacity)\n", s.ninodes);
  FSTRACE("  nlog=%d (log region blocks)\n", s.nlog);
  FSTRACE("  logstart=%d (first log block)\n", s.logstart);
  FSTRACE("  inodestart=%d (first on-disk inode block)\n", s.inodestart);
  FSTRACE("  bmapstart=%d (first allocation-bitmap block)\n", s.bmapstart);
  fs_super_register(dev, "xv6fs", &xv6_iops, ROOTINO, 0, 1, 0, 0);
  return 0;
}

// Mount-time work for the disk root: superblock, then log recovery.
// Only the root has a log; RAM-disk instances write through (log_write()).
int
fsinit(int dev) {
  if(fs_readsuper(dev) < 0)
    return -1;
  initlog(dev, &sbs[dev]);
  return 0;
}

// xv6fs as a registered filesystem type.  fill_super: set the block size
// (Linux sb_set_blocksize), read and check block 1, register supers[dev];
// only the root also attaches the log, RAM disks write through.
static int
xv6fs_fill_super(int dev, int flags)
{
  if(blkdev_set_bsize(dev, BSIZE) < 0)
    return -1;
  if(flags & VFS_MOUNT_ROOTLOG)
    return fsinit(dev);
  return fs_readsuper(dev);
}

static struct fs_type xv6fs_type = {
  .name = "xv6fs",
  .get_sb = get_sb_bdev,
  .fill_super = xv6fs_fill_super,
};

// Zero a block.
static void
bzero(int dev, int bno)
{
  struct buf *bp;

  bp = bread(dev, bno);
  memset(bp->data, 0, BSIZE);
  log_write(bp);
  brelse(bp);
}

// Blocks.

// Allocate a zeroed disk block.
static uint
balloc(uint dev)
{
  int b, bi, m;
  struct buf *bp;

  struct superblock *sb = getsb(dev);
  bp = 0;
  for(b = 0; b < sb->size; b += BPB){
    bp = bread(dev, BBLOCK(b, (*sb)));
    for(bi = 0; bi < BPB && b + bi < sb->size; bi++){
      m = 1 << (bi % 8);
      if((bp->data[bi/8] & m) == 0){  // Is block free?
        bp->data[bi/8] |= m;  // Mark block in use.
        log_write(bp);
        brelse(bp);
        bzero(dev, b + bi);
        return b + bi;
      }
    }
    brelse(bp);
  }
  panic("balloc: out of blocks");
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, (*getsb(dev))));
  bi = b % BPB;
  m = 1 << (bi % 8);
  if((bp->data[bi/8] & m) == 0)
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
  log_write(bp);
  brelse(bp);
}

// Inodes.
//
// An inode describes a single unnamed file.
// The inode disk structure holds metadata: the file's type,
// its size, the number of links referring to it, and the
// list of blocks holding the file's content.
//
// The inodes are laid out sequentially on disk at
// sb.startinode. Each inode has a number, indicating its
// position on the disk.
//
// The kernel keeps a table of in-use inodes in memory
// to provide a place for synchronizing access
// to inodes used by multiple processes. The in-memory
// inodes include book-keeping information that is
// not stored on disk: ip->ref and ip->valid.
//
// An inode and its in-memory representation go through a
// sequence of states before they can be used by the
// rest of the file system code.
//
// * Allocation: an inode is allocated if its type (on disk)
//   is non-zero. ialloc() allocates, and iput() frees if
//   the reference and link counts have fallen to zero.
//
// * Referencing in table: an entry in the inode table
//   is free if ip->ref is zero. Otherwise ip->ref tracks
//   the number of in-memory pointers to the entry (open
//   files and current directories). iget() finds or
//   creates a table entry and increments its ref; iput()
//   decrements ref.
//
// * Valid: the information (type, size, &c) in an inode
//   table entry is only correct when ip->valid is 1.
//   ilock() reads the inode from
//   the disk and sets ip->valid, while iput() clears
//   ip->valid if ip->ref has fallen to zero.
//
// * Locked: file system code may only examine and modify
//   the information in an inode and its content if it
//   has first locked the inode.
//
// Thus a typical sequence is:
//   ip = iget(dev, inum)
//   ilock(ip)
//   ... examine and modify ip->xxx ...
//   iunlock(ip)
//   iput(ip)
//
// ilock() is separate from iget() so that system calls can
// get a long-term reference to an inode (as for an open file)
// and only lock it for short periods (e.g., in read()).
// The separation also helps avoid deadlock and races during
// pathname lookup. iget() increments ip->ref so that the inode
// stays in the table and pointers to it remain valid.
//
// Many internal file system functions expect the caller to
// have locked the inodes involved; this lets callers create
// multi-step atomic operations.
//
// The itable.lock spin-lock protects the allocation of itable
// entries. Since ip->ref indicates whether an entry is free,
// and ip->dev and ip->inum indicate which i-node an entry
// holds, one must hold itable.lock while using any of those fields.
//
// ip->i_rwsem protects all ip-> fields other than ref, dev and inum.
// Metadata-changing operations take it for write; lookup/read/stat may take
// it for read after the inode has been loaded from disk.

struct {
  struct spinlock lock;
  struct inode inode[NINODE];
} itable;

void
iinit()
{
  int i = 0;
  
  initlock(&itable.lock, "itable");
  for(i = 0; i < NINODE; i++) {
    init_rwsem(&itable.inode[i].i_rwsem, "inode");
  }
  loginit();
  fs_mountinit();
}


// Allocate an inode on device dev.
// Mark it as allocated by  giving it type type.
// Returns an unlocked but allocated and referenced inode.
struct inode*
ialloc(uint dev, short type)
{
  int inum;
  struct buf *bp;
  struct dinode *dip;

  struct superblock *sb = getsb(dev);
  for(inum = 1; inum < sb->ninodes; inum++){
    bp = bread(dev, IBLOCK(inum, (*sb)));
    dip = (struct dinode*)bp->data + inum%IPB;
    if(dip->type == 0){  // a free inode
      memset(dip, 0, sizeof(*dip));
      dip->type = type;
      log_write(bp);   // mark it allocated on the disk
      brelse(bp);
      return iget(dev, inum);
    }
    brelse(bp);
  }
  panic("ialloc: no inodes");
}

// Copy a modified in-memory inode to disk.
// Must be called after every change to an ip->xxx field
// that lives on disk.
// Caller must hold ip->i_rwsem for write.
void
iupdate(struct inode *ip)
{
  struct buf *bp;
  struct dinode *dip;

  bp = bread(ip->dev, IBLOCK(ip->inum, (*getsb(ip->dev))));
  dip = (struct dinode*)bp->data + ip->inum%IPB;
  dip->type = ip->type;
  dip->major = ip->major;
  dip->minor = ip->minor;
  dip->nlink = ip->nlink;
  dip->size = ip->size;
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
  log_write(bp);
  brelse(bp);
}

// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
// Find or make the in-memory inode (dev, inum).  Path-based filesystems
// (FAT32, procfs, netfs) derive inum from the path and also compare the
// path, so a hash collision cannot alias two files.
struct inode*
iget_path(uint dev, uint inum, char *path)
{
  struct inode *ip, *empty;
  struct super_block *sb = getsuper(dev);
  int bypath = sb && sb->pathbased && path;

  acquire(&itable.lock);

  // Is the inode already in the table?
  empty = 0;
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum &&
       (!bypath || strncmp(ip->path, path, MAXPATH) == 0)){
      ip->ref++;
      int slot = ip - itable.inode;
      int ref = ip->ref;
      int valid = ip->valid;
      release(&itable.lock);
      FSTRACE("iget_path: cache hit slot=%d fs=%s dev=%d ino=%d ref=%d valid=%d path=%s\n",
              slot, sb ? sb->type : "unknown", dev, inum, ref, valid,
              bypath ? path : "<inode-keyed>");
      return ip;
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
      empty = ip;
  }

  // Recycle an inode entry.
  if(empty == 0)
    panic("iget: no inodes");

  ip = empty;
  ip->dev = dev;
  ip->inum = inum;
  ip->ref = 1;
  ip->valid = 0;
  ip->iop = sb ? sb->iop : &xv6_iops;
  ip->i_fop = 0; // selected by read_inode after the on-disk type is known
  // The slot may previously have represented an inode from another
  // filesystem.  valid=0 prevents normal users from consuming old metadata,
  // but clearing it here also keeps diagnostics honest and prevents a backend
  // that only fills its common fields (for example ext2) from exposing stale
  // xv6fs block pointers in addrs[].  Do not clear the sleeplock itself: it is
  // initialized once by iinit().
  ip->type = 0;
  ip->major = 0;
  ip->minor = 0;
  ip->nlink = 0;
  ip->size = 0;
  memset(ip->addrs, 0, sizeof(ip->addrs));
  memset(ip->fsdata, 0, sizeof(ip->fsdata));
  if(bypath)
    safestrcpy(ip->path, path, MAXPATH);
  else
    ip->path[0] = 0;
  int slot = ip - itable.inode;
  release(&itable.lock);
  FSTRACE("iget_path: cache miss -> initialize itable[%d] fs=%s dev=%d ino=%d ref=1 valid=0 path=%s\n",
          slot, sb ? sb->type : "unknown", dev, inum,
          bypath ? path : "<inode-keyed>");

  if(sb && inum == sb->rootino)
    FSTRACE("iget_path: this itable slot is filesystem root; disk metadata remains lazy until ilock\n");

  return ip;
}

struct inode*
iget(uint dev, uint inum)
{
  return iget_path(dev, inum, 0);
}

// Increment reference count for ip.
// Returns ip to enable ip = idup(ip1) idiom.
struct inode*
idup(struct inode *ip)
{
  acquire(&itable.lock);
  ip->ref++;
  release(&itable.lock);
  return ip;
}

// Lock the given inode.
// Reads the inode from disk if necessary.
static int
xv6_read_inode(struct inode *ip)
{
  struct buf *bp;
  struct dinode *dip;

  bp = bread(ip->dev, IBLOCK(ip->inum, (*getsb(ip->dev))));
  dip = (struct dinode*)bp->data + ip->inum%IPB;
  FSTRACE("xv6_read_inode: dev=%d ino=%d disk-block=%d slot-in-block=%d\n",
          ip->dev, ip->inum, IBLOCK(ip->inum, (*getsb(ip->dev))),
          ip->inum % IPB);
  ip->type = dip->type;
  ip->major = dip->major;
  ip->minor = dip->minor;
  ip->nlink = dip->nlink;
  ip->size = dip->size;
  memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
  brelse(bp);
  if(ip->type == 0)
    panic("ilock: no type");
  // read_inode is the bootstrap operation installed from the superblock.
  // Once the on-disk type is known, select the Linux-style inode and default
  // file operation tables for this particular object.
  if(ip->type == T_DIR){
    ip->iop = &xv6_dir_iops;
    ip->i_fop = &xv6_dir_fops;
  } else if(ip->type == T_FILE){
    ip->iop = &xv6_file_iops;
    ip->i_fop = &xv6_file_fops;
  } else if(ip->type == T_DEVICE){
    ip->iop = &xv6_device_iops;
    ip->i_fop = 0; // chrdev_open() selects operations from the major number.
  } else {
    return -1;
  }
  return 0;
}

void
ilock(struct inode *ip)
{
  if(ip == 0 || ip->ref < 1)
    panic("ilock");

  down_write(&ip->i_rwsem);

  if(ip->valid == 0){
    struct super_block *sb = getsuper(ip->dev);
    int root = sb && ip->inum == sb->rootino;
    FSTRACE("ilock: metadata cache miss -> iop->read_inode fs=%s dev=%d ino=%d\n",
            sb ? sb->type : "unknown", ip->dev, ip->inum);
    if(ip->iop->read_inode(ip) < 0){
      // The object vanished behind our back (path-based filesystems):
      // present an empty, unlinked file instead of crashing.
      ip->type = T_FILE;
      ip->nlink = 0;
      ip->size = 0;
      ip->major = ip->minor = 0;
    }
    ip->valid = 1;
    if(root){
      FSTRACE("root inode loaded into itable[%d]\n",
              (int)(ip - itable.inode));
      FSTRACE("  dev=%d ino=%d ref=%d valid=%d iop=%p path=%s\n",
              ip->dev, ip->inum, ip->ref, ip->valid, (uint64)ip->iop,
              ip->path[0] ? ip->path : "<not stored: inode-keyed fs>");
      FSTRACE("  i_fop=%p (default file operations selected by inode type)\n",
              (uint64)ip->i_fop);
      FSTRACE("  type=%d major=%d minor=%d nlink=%d size=%p\n",
              ip->type, ip->major, ip->minor, ip->nlink, ip->size);
      for(int i = 0; i < NDIRECT; i++)
        FSTRACE("  addrs[%d]=%d (direct data-block pointer)\n", i,
                ip->addrs[i]);
      FSTRACE("  addrs[%d]=%d (single-indirect block pointer)\n",
              NDIRECT, ip->addrs[NDIRECT]);
      for(int i = 0; i < 4; i++)
        FSTRACE("  fsdata[%d]=%d (filesystem-private cached value)\n",
                i, ip->fsdata[i]);
    }
  } else {
    FSTRACE("ilock: metadata cache hit dev=%d ino=%d type=%d size=%p\n",
            ip->dev, ip->inum, ip->type, ip->size);
  }
}

// Acquire a shared inode lock.  Lazy inode loading modifies the cache, so the
// first reader temporarily upgrades by dropping the read lock and taking the
// write lock.  Rechecking valid after the transition handles another task
// winning that race.
void
ireadlock(struct inode *ip)
{
  if(ip == 0 || ip->ref < 1)
    panic("ireadlock");

  down_read(&ip->i_rwsem);
  if(ip->valid)
    return;
  up_read(&ip->i_rwsem);

  ilock(ip);
  iunlock(ip);
  down_read(&ip->i_rwsem);
}

// Unlock the given inode.
void
iunlock(struct inode *ip)
{
  if(ip == 0 || !rwsem_write_held(&ip->i_rwsem) || ip->ref < 1)
    panic("iunlock");

  up_write(&ip->i_rwsem);
}

void
ireadunlock(struct inode *ip)
{
  if(ip == 0 || ip->ref < 1)
    panic("ireadunlock");
  up_read(&ip->i_rwsem);
}

// Drop a reference to an in-memory inode.
// If that was the last reference, the inode table entry can
// be recycled.
// If that was the last reference and the inode has no links
// to it, free the inode (and its content) on disk.
// All calls to iput() must be inside a transaction in
// case it has to free the inode.
// xv6fs: an inode with no links and no references is truncated and freed.
static void
xv6_evict(struct inode *ip)
{
  if(ip->nlink != 0)
    return;
  itrunc(ip);
  ip->type = 0;
  iupdate(ip);
}

void
iput(struct inode *ip)
{
  acquire(&itable.lock);

  if(ip->ref == 1 && ip->valid && ip->iop->evict){
    // Last reference: let the filesystem release it (xv6fs frees unlinked
    // inodes, ext2 reclaims orphans).
    // ip->ref == 1 means no other process can have ip locked,
    // so this write acquisition won't block (or deadlock).
    down_write(&ip->i_rwsem);

    release(&itable.lock);

    ip->iop->evict(ip);
    ip->valid = 0;

    up_write(&ip->i_rwsem);

    acquire(&itable.lock);
  }

  ip->ref--;
  release(&itable.lock);
}

// Common idiom: unlock, then put.
void
iunlockput(struct inode *ip)
{
  iunlock(ip);
  iput(ip);
}

void
ireadunlockput(struct inode *ip)
{
  ireadunlock(ip);
  iput(ip);
}

// Inode content
//
// The content (data) associated with each inode is stored
// in blocks on the disk. The first NDIRECT block numbers
// are listed in ip->addrs[].  The next NINDIRECT blocks are
// listed in block ip->addrs[NDIRECT].

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
  uint addr, *a;
  struct buf *bp;
  uint filebn = bn;

  if(bn < NDIRECT){
    if((addr = ip->addrs[bn]) == 0)
      ip->addrs[bn] = addr = balloc(ip->dev);
    FSTRACE("bmap: dev=%d ino=%d file-block=%d -> disk-block=%d via addrs[%d] direct\n",
            ip->dev, ip->inum, filebn, addr, bn);
    return addr;
  }
  bn -= NDIRECT;

  if(bn < NINDIRECT){
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
    a = (uint*)bp->data;
    if((addr = a[bn]) == 0){
      a[bn] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);
    FSTRACE("bmap: dev=%d ino=%d file-block=%d -> disk-block=%d via addrs[%d] indirect[%d]\n",
            ip->dev, ip->inum, filebn, addr, NDIRECT, bn);
    return addr;
  }

  panic("bmap: out of range");
}

// Truncate inode (discard contents).
// Caller must hold ip->i_rwsem for write.
void
itrunc(struct inode *ip)
{
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    if(ip->addrs[i]){
      bfree(ip->dev, ip->addrs[i]);
      ip->addrs[i] = 0;
    }
  }

  if(ip->addrs[NDIRECT]){
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    a = (uint*)bp->data;
    for(j = 0; j < NINDIRECT; j++){
      if(a[j])
        bfree(ip->dev, a[j]);
    }
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
  iupdate(ip);
}

// Copy stat information from inode.
// Caller must hold ip->i_rwsem for read or write.
void
stati(struct inode *ip, struct stat *st)
{
  st->dev = ip->dev;
  st->ino = ip->inum;
  st->type = ip->type;
  st->nlink = ip->nlink;
  st->size = ip->size;
}

// Read data from inode.
// Caller must hold ip->i_rwsem for read or write.
// If user_dst==1, then dst is a user virtual address;
// otherwise, dst is a kernel address.
int
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    return 0;
  if(off + n > ip->size)
    n = ip->size - off;

  FSTRACE("readi: dev=%d ino=%d off=%d bytes=%d destination=%s\n",
          ip->dev, ip->inum, off, n, user_dst ? "user" : "kernel");

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    uint diskblock = bmap(ip, off/BSIZE);
    FSTRACE("readi: bread dev=%d disk-block=%d block-offset=%d\n",
            ip->dev, diskblock, off % BSIZE);
    bp = bread(ip->dev, diskblock);
    m = min(n - tot, BSIZE - off%BSIZE);
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
  }
  return tot;
}

// Write data to inode.
// Caller must hold ip->i_rwsem for write.
// If user_src==1, then src is a user virtual address;
// otherwise, src is a kernel address.
// Returns the number of bytes successfully written.
// If the return value is less than the requested n,
// there was an error of some kind.
int
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    return -1;
  if(off + n > MAXFILE*BSIZE)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
      brelse(bp);
      break;
    }
    log_write(bp);
    brelse(bp);
  }

  if(off > ip->size)
    ip->size = off;

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);

  return tot;
}

// Directories

int
namecmp(const char *s, const char *t)
{
  return strncmp(s, t, DIRSIZ);
}

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    panic("dirlookup not DIR");

  FSTRACE("dirlookup: scan directory dev=%d ino=%d size=%p for name='%s'\n",
          dp->dev, dp->inum, dp->size, name);

  for(off = 0; off < dp->size; off += sizeof(de)){
    int got = readi(dp, 0, (uint64)&de, off, sizeof(de));
    if(got != sizeof(de)){
      struct super_block *sb = getsuper(dp->dev);
      printf("dirlookup: short read cpu=%d fs=%s dev=%d ino=%d type=%d "
             "valid=%d size=%d off=%d got=%d name='%s' caller=%p\n",
             cpuid(), sb ? sb->type : "none", dp->dev, dp->inum, dp->type,
             dp->valid, dp->size, off, got, name,
             __builtin_return_address(0));
      panic("dirlookup read");
    }
    if(de.inum == 0)
      continue;
    char dename[DIRSIZ + 1];
    memmove(dename, de.name, DIRSIZ);
    dename[DIRSIZ] = 0;
    FSTRACE("dirlookup: dirent off=%d name='%s' ino=%d\n",
            off, dename, de.inum);
    if(namecmp(name, de.name) == 0){
      // entry matches path element
      if(poff)
        *poff = off;
      inum = de.inum;
      FSTRACE("dirlookup: match name='%s' -> iget(dev=%d, ino=%d)\n",
              name, dp->dev, inum);
      return iget(dp->dev, inum);
    }
  }

  FSTRACE("dirlookup: miss name='%s' in dev=%d ino=%d\n",
          name, dp->dev, dp->inum);
  return 0;
}

// Write a new directory entry (name, inum) into the directory dp.
int
dirlink(struct inode *dp, char *name, uint inum)
{
  int off;
  struct dirent de;
  struct inode *ip;

  // Check that name is not present.
  if((ip = dirlookup(dp, name, 0)) != 0){
    iput(ip);
    return -1;
  }

  // Look for an empty dirent.
  for(off = 0; off < dp->size; off += sizeof(de)){
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("dirlink read");
    if(de.inum == 0)
      break;
  }

  strncpy(de.name, name, DIRSIZ);
  de.inum = inum;
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    panic("dirlink");

  return 0;
}

// Paths

// Copy the next path element from path into name.
// Return a pointer to the element following the copied one.
// The returned path has no leading slashes,
// so the caller can check *path=='\0' to see if the name is the last one.
// If no name to remove, return 0.
//
// Examples:
//   skipelem("a/bb/c", name) = "bb/c", setting name = "a"
//   skipelem("///a//bb", name) = "bb", setting name = "a"
//   skipelem("a", name) = "", setting name = "a"
//   skipelem("", name) = skipelem("////", name) = 0
//
static char*
skipelem(char *path, char *name)
{
  char *s;
  int len;

  while(*path == '/')
    path++;
  if(*path == 0)
    return 0;
  s = path;
  while(*path != '/' && *path != 0)
    path++;
  len = path - s;
  if(len >= NAMEMAX)
    len = NAMEMAX - 1;
  memmove(name, s, len);
  name[len] = 0;
  while(*path == '/')
    path++;
  FSTRACE("skipelem: component='%s' remaining='%s'\n", name,
          *path ? path : "<end>");
  return path;
}

// Mounts of xv6 filesystems (compare Linux struct mount / vfsmount).
//
// A mount says "the directory mp is covered by the root directory of the
// filesystem on dev".  namex() crosses a mount when a lookup lands on a
// covered directory (follow_mount) and climbs back out of a mounted root
// on ".." (follow_dotdot).  fs_root is the namespace root "/": at boot it is
// the rootfs RAM disk; do_mounts.c later moves the real root over it and
// chroots there, exactly like Linux's prepare_namespace().  xv6 has one
// mount namespace, so "chroot" changes the root for every process.
//
// The table holds every mounted filesystem, of any type: each inode carries
// its filesystem's operations (vfs.h), so the same walk crosses from xv6fs
// into ext2, FAT32 or procfs.

#define NFSMOUNT 8

static struct {
  struct spinlock lock;
  struct fsmount {
    int used;
    int unmounting;           // hidden from new path walks while draining
    struct inode *mp;       // covered directory (holds a reference)
    uint dev;               // mounted filesystem; its root is (dev, ROOTINO)
    char fstype[12];
    char source[24];
    char path[MAXPATH];     // where it appears in the namespace, for display
  } m[NFSMOUNT];
} mtab;

static struct inode *fs_root;   // "/", see above

void
fs_mountinit(void)
{
  initlock(&mtab.lock, "mtab");
  register_filesystem(&xv6fs_type);
}

// The inode namex() starts absolute paths from.  Before do_mounts.c has
// set up the namespace (and for the legacy path), it is the disk root.
static struct inode*
rootdir(void)
{
  struct inode *ip = fs_root ? idup(fs_root) : iget(rootdev_dev(), ROOTINO);
  FSTRACE("rootdir: namespace '/' -> dev=%d ino=%d source=%s\n",
          ip->dev, ip->inum, fs_root ? "fs_root" : "ROOT_DEV fallback");
  return ip;
}

// Is ip the root directory of its filesystem?
static int
isfsroot(struct inode *ip)
{
  struct super_block *sb = getsuper(ip->dev);
  return ip->inum == (sb ? sb->rootino : ROOTINO);
}

static struct fsmount*
mount_covering(uint dev, uint inum)
{
  for(int i = 0; i < NFSMOUNT; i++)
    if(mtab.m[i].used && !mtab.m[i].unmounting &&
       mtab.m[i].mp->dev == dev &&
       mtab.m[i].mp->inum == inum)
      return &mtab.m[i];
  return 0;
}

static struct fsmount*
mount_of_dev(uint dev)
{
  for(int i = 0; i < NFSMOUNT; i++)
    if(mtab.m[i].used && mtab.m[i].dev == dev)
      return &mtab.m[i];
  return 0;
}

// If ip is covered by a mount, replace it with the mounted root (repeat for
// stacked mounts).  Consumes the caller's reference to ip.
static struct inode*
follow_mount(struct inode *ip)
{
  for(;;){
    acquire(&mtab.lock);
    struct fsmount *m = mount_covering(ip->dev, ip->inum);
    uint dev = m ? m->dev : 0;
    release(&mtab.lock);
    if(m == 0)
      return ip;
    FSTRACE("follow_mount: covered dev=%d ino=%d -> mounted dev=%d root\n",
            ip->dev, ip->inum, dev);
    struct super_block *sb = getsuper(dev);
    VFSTRACE("follow_mount: cover=(%d,%d) -> fs=%s dev=%d rootino=%d\n",
             ip->dev, ip->inum, sb ? sb->type : "unknown", dev,
             sb ? sb->rootino : ROOTINO);
    iput(ip);
    ip = fs_dev_root(dev);
  }
}

// Before looking up "..": stay put at the namespace root; at the root of a
// mounted filesystem, step down to the covered directory first so ".." is
// looked up in the parent filesystem.  Consumes the reference to ip.
static struct inode*
follow_dotdot(struct inode *ip)
{
  for(;;){
    if(fs_root && ip->dev == fs_root->dev && ip->inum == fs_root->inum){
      FSTRACE("follow_dotdot: already namespace root, stay dev=%d ino=%d\n",
              ip->dev, ip->inum);
      return ip;
    }
    if(!isfsroot(ip))
      return ip;
    acquire(&mtab.lock);
    struct fsmount *m = mount_of_dev(ip->dev);
    struct inode *mp = m ? idup(m->mp) : 0;
    release(&mtab.lock);
    if(mp == 0)
      return ip;
    FSTRACE("follow_dotdot: mounted root dev=%d ino=%d -> cover dev=%d ino=%d\n",
            ip->dev, ip->inum, mp->dev, mp->inum);
    iput(ip);
    ip = mp;
  }
}

// Root directory of the filesystem on dev (referenced, unlocked).
struct inode*
fs_dev_root(int dev)
{
  struct super_block *sb = getsuper(dev);
  return iget_path(dev, sb ? sb->rootino : ROOTINO, "/");
}

int
fs_is_mountpoint(struct inode *ip)
{
  acquire(&mtab.lock);
  int r = mount_covering(ip->dev, ip->inum) != 0 ||
          (isfsroot(ip) && mount_of_dev(ip->dev) != 0);
  release(&mtab.lock);
  return r;
}

// Attach the xv6 filesystem on dev (superblock already read) at directory
// mp.  Takes over the caller's reference to mp.
int
fs_mount(struct inode *mp, int dev, char *fstype, char *source, char *path)
{
  ilock(mp);
  int isdir = mp->type == T_DIR;
  iunlock(mp);
  if(!isdir)
    return -1;
  acquire(&mtab.lock);
  if(mount_covering(mp->dev, mp->inum) || mount_of_dev(dev)){
    release(&mtab.lock);
    return -1;
  }
  for(int i = 0; i < NFSMOUNT; i++){
    struct fsmount *m = &mtab.m[i];
    if(m->used)
      continue;
    m->used = 1;
    m->unmounting = 0;
    m->mp = mp;
    m->dev = dev;
    safestrcpy(m->fstype, fstype, sizeof(m->fstype));
    safestrcpy(m->source, source, sizeof(m->source));
    safestrcpy(m->path, path, sizeof(m->path));
    release(&mtab.lock);
    struct super_block *sb = getsuper(dev);
    (void)sb;
    FSTRACE("mount: path=%s cover=(dev=%d ino=%d) root=(fs=%s dev=%d ino=%d)\n",
            path, mp->dev, mp->inum, sb ? sb->type : fstype, dev,
            sb ? sb->rootino : ROOTINO);
    VFSTRACE("mount: source=%s target=%s type=%s cover=(%d,%d) root=(%d,%d)\n",
             source, path, sb ? sb->type : fstype, mp->dev, mp->inum, dev,
             sb ? sb->rootino : ROOTINO);
    return 0;
  }
  release(&mtab.lock);
  return -1;
}

// A mount can be destroyed only after all VFS inode references on its device
// have drained.  This includes open files and process cwd references; cached
// itable slots with ref==0 do not keep a filesystem busy.
static int
fs_dev_busy(uint dev)
{
  int busy = 0;
  acquire(&itable.lock);
  for(struct inode *ip = itable.inode; ip < itable.inode + NINODE; ip++)
    if(ip->ref > 0 && ip->dev == dev){
      busy = 1;
      break;
    }
  release(&itable.lock);
  return busy;
}

static int
mount_path_below(char *child, char *parent)
{
  int n = strlen(parent);
  return strncmp(child, parent, n) == 0 && child[n] == '/';
}

// Detach a non-root mount by its namespace path.  Marking it unmounting first
// prevents new namei() walks from entering it while existing inode references
// drain.  A failed busy check or filesystem shutdown restores the mount.
int
fs_umount(char *target)
{
  struct fsmount *m = 0;
  struct inode *mp = 0;
  struct super_block *sb;
  uint dev = 0;

  acquire(&mtab.lock);
  for(int i = 0; i < NFSMOUNT; i++){
    if(mtab.m[i].used && !mtab.m[i].unmounting &&
       strncmp(mtab.m[i].path, target, MAXPATH) == 0){
      m = &mtab.m[i];
      break;
    }
  }
  if(m == 0 || strncmp(target, "/", MAXPATH) == 0 ||
     (fs_root && fs_root->dev == m->dev)){
    release(&mtab.lock);
    return -1;
  }
  for(int i = 0; i < NFSMOUNT; i++){
    struct fsmount *c = &mtab.m[i];
    if(c != m && c->used &&
       (c->mp->dev == m->dev || mount_path_below(c->path, m->path))){
      release(&mtab.lock);
      return -1;                // detach child mounts first
    }
  }
  m->unmounting = 1;
  dev = m->dev;
  release(&mtab.lock);

  if(fs_dev_busy(dev))
    goto restore;
  sb = getsuper(dev);
  if(sb == 0 || (sb->put_super && sb->put_super(sb) < 0))
    goto restore;

  acquire(&mtab.lock);
  // No other unmount can recycle this entry while unmounting is set.
  mp = m->mp;
  memset(m, 0, sizeof(*m));
  release(&mtab.lock);
  fs_super_unregister(dev);
  iput(mp);
  VFSTRACE("umount: target=%s dev=%d complete\n", target, dev);
  return 0;

restore:
  acquire(&mtab.lock);
  if(m->used && m->dev == dev)
    m->unmounting = 0;
  release(&mtab.lock);
  VFSTRACE("umount: target=%s dev=%d busy-or-shutdown-failed\n", target, dev);
  return -1;
}

// MS_MOVE: the filesystem whose root directory is "from" is detached from
// where it is mounted and re-attached on directory "to", which is reached
// as topath.  Mounts below it (devtmpfs on /root/dev) move along; only
// their display paths change.  Consumes the reference to "to".
int
fs_move_mount(struct inode *from, struct inode *to, char *topath)
{
  struct inode *old;
  char oldpath[MAXPATH];
  acquire(&mtab.lock);
  struct fsmount *m = isfsroot(from) ? mount_of_dev(from->dev) : 0;
  if(m == 0 || m->unmounting || mount_covering(to->dev, to->inum)){
    release(&mtab.lock);
    return -1;
  }
  old = m->mp;
  m->mp = to;
  safestrcpy(oldpath, m->path, sizeof(oldpath));
  int n = strlen(oldpath);
  for(int i = 0; i < NFSMOUNT; i++){
    struct fsmount *c = &mtab.m[i];
    if(!c->used || strncmp(c->path, oldpath, n) != 0 ||
       (c->path[n] != 0 && c->path[n] != '/'))
      continue;
    char rest[MAXPATH];
    safestrcpy(rest, c->path + n, sizeof(rest));
    safestrcpy(c->path, topath, sizeof(c->path));
    if(rest[0]){
      int t = strlen(c->path);
      if(t == 1)                  // topath "/": avoid "//dev"
        t = 0;
      safestrcpy(c->path + t, rest, sizeof(c->path) - t);
    }
  }
  release(&mtab.lock);
  iput(old);
  return 0;
}

// chroot for the (single) namespace.
void
fs_set_root(struct inode *ip)
{
  struct inode *old = fs_root;
  fs_root = idup(ip);
  if(old)
    iput(old);
}

static char*
mstr(char *p, char *e, char *s)
{
  while(*s && p < e)
    *p++ = *s++;
  return p;
}

// /proc/mounts lines for the xv6-inode mounts ("source target type opts").
int
fs_mounts_format(char *buf, int n)
{
  char *p = buf, *e = buf + n;
  acquire(&mtab.lock);
  for(int i = 0; i < NFSMOUNT; i++){
    struct fsmount *m = &mtab.m[i];
    if(!m->used || m->unmounting)
      continue;
    p = mstr(p, e, m->source);
    p = mstr(p, e, " ");
    p = mstr(p, e, m->path);
    p = mstr(p, e, " ");
    p = mstr(p, e, m->fstype);
    struct super_block *sb = getsuper(m->dev);
    p = mstr(p, e, sb && sb->readonly ? " ro 0 0\n" : " rw 0 0\n");
  }
  release(&mtab.lock);
  return p - buf;
}

// Look up and return the inode for a path name.
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
  struct inode *ip, *next;
  char *original = path;
  (void)original;

  FSTRACE("namex: begin path='%s' mode=%s\n", original,
          nameiparent ? "lookup-parent" : "lookup-object");
  VFSTRACE("lookup: begin path=%s mode=%s\n", original,
           nameiparent ? "parent" : "object");

  if(*path == '/')
    ip = rootdir();
  else
    ip = idup(myproc()->cwd);

  while((path = skipelem(path, name)) != 0){
    FSTRACE("namex: component='%s' current=(dev=%d ino=%d) remaining='%s'\n",
            name, ip->dev, ip->inum, *path ? path : "<end>");
    VFSTRACE("lookup: component=%s at=(%d,%d) remaining=%s\n",
             name, ip->dev, ip->inum, *path ? path : "<end>");
    if(namecmp(name, "..") == 0)
      ip = follow_dotdot(ip);
    ireadlock(ip);
    if(ip->type != T_DIR){
      FSTRACE("namex: fail component='%s': current inode is type=%d, not directory\n",
              name, ip->type);
      ireadunlockput(ip);
      return 0;
    }
    if(nameiparent && *path == '\0'){
      // Stop one level early.
      FSTRACE("namex: parent result dev=%d ino=%d final-name='%s'\n",
              ip->dev, ip->inum, name);
      ireadunlock(ip);
      return ip;
    }
    FSTRACE("namex: dispatch lookup through inode_ops fs=%s directory=(%d,%d) name='%s'\n",
            getsuper(ip->dev) ? getsuper(ip->dev)->type : "unknown",
            ip->dev, ip->inum, name);
    if((next = ip->iop->lookup(ip, name)) == 0){
      VFSTRACE("lookup: miss path=%s component=%s at=(%d,%d)\n",
               original, name, ip->dev, ip->inum);
      FSTRACE("namex: lookup miss path='%s' component='%s'\n", original, name);
      ireadunlockput(ip);
      return 0;
    }
    VFSTRACE("lookup: hit component=%s -> (%d,%d)\n",
             name, next->dev, next->inum);
    FSTRACE("namex: lookup hit component='%s' -> dev=%d ino=%d; release parent\n",
            name, next->dev, next->inum);
    ireadunlockput(ip);
    ip = follow_mount(next);
  }
  if(nameiparent){
    FSTRACE("namex: fail path='%s': no final component for parent lookup\n",
            original);
    iput(ip);
    return 0;
  }
  FSTRACE("namex: success path='%s' -> dev=%d ino=%d\n",
          original, ip->dev, ip->inum);
  VFSTRACE("lookup: success path=%s -> (%d,%d) fs=%s\n", original,
           ip->dev, ip->inum,
           getsuper(ip->dev) ? getsuper(ip->dev)->type : "unknown");
  return ip;
}

struct inode*
namei(char *path)
{
  char name[NAMEMAX];
  FSTRACE("namei: public pathname lookup path='%s'\n", path);
  struct inode *ip = namex(path, 0, name);
  FSTRACE("namei: return path='%s' result=%s dev=%d ino=%d\n", path,
          ip ? "inode" : "NULL", ip ? ip->dev : 0, ip ? ip->inum : 0);
  return ip;
}

struct inode*
nameiparent(char *path, char *name)
{
  FSTRACE("nameiparent: public parent lookup path='%s'\n", path);
  struct inode *ip = namex(path, 1, name);
  FSTRACE("nameiparent: return parent=%s dev=%d ino=%d final-name='%s'\n",
          ip ? "inode" : "NULL", ip ? ip->dev : 0, ip ? ip->inum : 0,
          ip ? name : "<none>");
  return ip;
}

// Create name in directory dp (a referenced, unlocked inode; the reference
// is consumed).  Returns the new inode locked, or for T_FILE an existing
// file/device; 0 on failure.  Shared by open(O_CREATE)/mkdir/mknod and the
// kernel's own node creation (rootfs, devtmpfs).  Caller is in a
// transaction.
static struct inode*
xv6_create(struct inode *dp, char *name, short type, short major, short minor)
{
  struct inode *ip;

  ilock(dp);

  if((ip = dirlookup(dp, name, 0)) != 0){
    iunlockput(dp);
    ilock(ip);
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
      return ip;
    iunlockput(ip);
    return 0;
  }

  if((ip = ialloc(dp->dev, type)) == 0)
    panic("create: ialloc");

  ilock(ip);
  ip->major = major;
  ip->minor = minor;
  ip->nlink = 1;
  iupdate(ip);

  if(type == T_DIR){  // Create . and .. entries.
    dp->nlink++;  // for ".."
    iupdate(dp);
    // No ip->nlink++ for ".": avoid cyclic ref count.
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
      panic("create dots");
  }

  if(dirlink(dp, name, ip->inum) < 0)
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}

// ---------------------------------------------------------------------------
// The rest of the xv6fs inode operations.

static struct inode*
xv6_lookup(struct inode *dp, char *name)
{
  FSTRACE("xv6_lookup: inode_ops lookup directory=(dev=%d ino=%d) name='%s'\n",
          dp->dev, dp->inum, name);
  struct inode *ip = dirlookup(dp, name, 0);
  FSTRACE("xv6_lookup: result name='%s' -> %s dev=%d ino=%d\n",
          name, ip ? "inode" : "NULL", ip ? ip->dev : 0,
          ip ? ip->inum : 0);
  return ip;
}

// Is the directory dp empty except for "." and ".." ?
static int
isdirempty(struct inode *dp)
{
  int off;
  struct dirent de;

  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("isdirempty: readi");
    if(de.inum != 0)
      return 0;
  }
  return 1;
}

static int
xv6_unlink(struct inode *dp, char *name)
{
  struct inode *ip;
  struct dirent de;
  uint off;

  ilock(dp);
  // Cannot unlink "." or "..".
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0 ||
     (ip = dirlookup(dp, name, &off)) == 0){
    iunlock(dp);
    return -1;
  }
  ilock(ip);
  if(ip->nlink < 1)
    panic("unlink: nlink < 1");
  if(ip->type == T_DIR && !isdirempty(ip)){
    iunlockput(ip);
    iunlock(dp);
    return -1;
  }
  memset(&de, 0, sizeof(de));
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    panic("unlink: writei");
  if(ip->type == T_DIR){
    dp->nlink--;
    iupdate(dp);
  }
  iunlock(dp);
  ip->nlink--;
  iupdate(ip);
  iunlockput(ip);
  return 0;
}

static int
xv6_link(struct inode *dp, char *name, struct inode *ip)
{
  ilock(ip);
  if(ip->type == T_DIR){
    iunlock(ip);
    return -1;
  }
  ip->nlink++;
  iupdate(ip);
  iunlock(ip);

  ilock(dp);
  if(dirlink(dp, name, ip->inum) < 0){
    iunlock(dp);
    ilock(ip);
    ip->nlink--;
    iupdate(ip);
    iunlock(ip);
    return -1;
  }
  iunlock(dp);
  return 0;
}

// Rename a file (not a directory) within one xv6 filesystem: add the new
// name, then clear the old entry, in the caller's single log transaction.
static int
xv6_rename(struct inode *odp, char *oname, struct inode *ndp, char *nname)
{
  struct inode *ip, *t;
  struct dirent de;
  uint off;

  ilock(odp);
  ip = dirlookup(odp, oname, &off);
  iunlock(odp);
  if(ip == 0)
    return -1;
  ilock(ip);
  int isdir = ip->type == T_DIR;
  iunlock(ip);
  if(isdir){
    iput(ip);
    return -1;
  }
  ilock(ndp);
  if((t = dirlookup(ndp, nname, 0)) != 0){
    iunlock(ndp);
    int same = t == ip;
    iput(t);
    iput(ip);
    return same ? 0 : -1;        // replacing an existing name: not supported
  }
  if(dirlink(ndp, nname, ip->inum) < 0){
    iunlock(ndp);
    iput(ip);
    return -1;
  }
  iunlock(ndp);
  ilock(odp);
  if(readi(odp, 0, (uint64)&de, off, sizeof(de)) == sizeof(de) &&
     de.inum == ip->inum){
    memset(&de, 0, sizeof(de));
    if(writei(odp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
      panic("rename: writei");
  }
  iunlock(odp);
  iput(ip);
  return 0;
}

static int
xv6_read(struct inode *ip, int user_dst, uint64 dst, uint64 off, uint n)
{
  if(off > 0xffffffffULL || (uint64)n > 0x100000000ULL - off)
    return -1;
  return readi(ip, user_dst, dst, off, n);
}

static int
xv6_write(struct inode *ip, int user_src, uint64 src, uint64 off, uint n)
{
  if(off > 0xffffffffULL || (uint64)n > 0x100000000ULL - off)
    return -1;
  return writei(ip, user_src, src, off, n);
}

static int
xv6_truncate(struct inode *ip, uint64 size)
{
  if(ip->type != T_FILE || size != 0)
    return -1;
  itrunc(ip);
  return 0;
}

static int
xv6_fsync(struct inode *ip)
{
  // Writes commit synchronously through the log; sdflush is the card's
  // programming barrier.
  return sdflush();
}

static int
xv6_file_read_at(struct file *f, int user_dst, uint64 dst, uint64 off,
                  uint n)
{
  return xv6_read(f->ip, user_dst, dst, off, n);
}

static int
xv6_file_write_at(struct file *f, int user_src, uint64 src, uint64 off,
                   uint n)
{
  return xv6_write(f->ip, user_src, src, off, n);
}

static int
xv6_file_fsync(struct file *f, int dataonly)
{
  (void)dataonly;
  return xv6_fsync(f->ip);
}

static const struct file_operations xv6_file_fops = {
  .fread = generic_file_fread,
  .fwrite = generic_file_fwrite,
  .read_at = xv6_file_read_at,
  .write_at = xv6_file_write_at,
  .fsync = xv6_file_fsync,
  .poll = generic_file_poll,
};

static const struct file_operations xv6_dir_fops = {
  .fread = generic_file_fread,
  .read_at = xv6_file_read_at,
  .poll = generic_file_poll,
};

// Superblock bootstrap operations: iget installs this table before the inode
// type has been read. xv6_read_inode then switches iop/i_fop to one of the
// type-specific tables below.
static struct inode_ops xv6_iops = {
  .read_inode = xv6_read_inode,
  .evict = xv6_evict,
};

static struct inode_ops xv6_file_iops = {
  .read_inode = xv6_read_inode,
  .evict = xv6_evict,
  .truncate = xv6_truncate,
};

static struct inode_ops xv6_dir_iops = {
  .read_inode = xv6_read_inode,
  .evict = xv6_evict,
  .lookup = xv6_lookup,
  .create = xv6_create,
  .unlink = xv6_unlink,
  .link = xv6_link,
  .rename = xv6_rename,
};

static struct inode_ops xv6_device_iops = {
  .read_inode = xv6_read_inode,
  .evict = xv6_evict,
};

// ---------------------------------------------------------------------------
// Generic entry points used by the system calls and the kernel.  They check
// that the filesystem is writable and supports the operation.

static int
fs_writable(struct inode *ip)
{
  struct super_block *sb = getsuper(ip->dev);
  return !(sb && sb->readonly);
}

// Create name in directory dp (referenced, unlocked; reference consumed).
// Returns the inode locked, or 0.  Caller is in a transaction.
struct inode*
fs_create(struct inode *dp, char *name, short type, short major, short minor)
{
  if(!fs_writable(dp) || dp->iop->create == 0){
    iput(dp);
    return 0;
  }
  return dp->iop->create(dp, name, type, major, minor);
}

int
fs_unlink(struct inode *dp, char *name)
{
  if(!fs_writable(dp) || dp->iop->unlink == 0)
    return -1;
  return dp->iop->unlink(dp, name);
}

int
fs_link(struct inode *dp, char *name, struct inode *ip)
{
  if(dp->dev != ip->dev || !fs_writable(dp) || dp->iop->link == 0)
    return -1;
  return dp->iop->link(dp, name, ip);
}

int
fs_rename(struct inode *odp, char *oname, struct inode *ndp, char *nname)
{
  if(odp->dev != ndp->dev || !fs_writable(odp) || odp->iop->rename == 0)
    return -1;
  return odp->iop->rename(odp, oname, ndp, nname);
}

int
fs_is_readonly(struct inode *ip)
{
  return !fs_writable(ip);
}

// For filesystems whose directories are not xv6 dirent arrays: present the
// entries as a stream of xv6 struct dirent, one entry per sizeof(dirent)
// bytes of offset, as user space (ls) expects.
int
vfs_dir_read(struct inode *dp, int user_dst, uint64 dst, uint64 off, uint n,
             int (*readdir)(struct inode*, int, char*, uint*))
{
  struct dirent de;
  char name[NAMEMAX];
  uint ino;
  int total = 0;

  if(off % sizeof(de))
    return 0;
  while(n - total >= sizeof(de)){
    int index = (off + total) / sizeof(de);
    int r = readdir(dp, index, name, &ino);
    if(r <= 0)
      break;
    memset(&de, 0, sizeof(de));
    de.inum = ino == 0 ? 1 : (ino > 0xffff ? 0xffff : ino);
    int len = strlen(name);
    memmove(de.name, name, len < DIRSIZ ? len : DIRSIZ);
    if(either_copyout(user_dst, dst + total, &de, sizeof(de)) < 0)
      return total ? total : -1;
    total += sizeof(de);
  }
  return total;
}
