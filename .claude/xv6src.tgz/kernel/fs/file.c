//
// Support functions for system calls that involve file descriptors.
//

#include <kernel/types.h>
#include "aarch64.h"
#include <kernel/defs.h>
#include <kernel/param.h>
#include <kernel/fs.h>
#include <kernel/spinlock.h>
#include <kernel/sleeplock.h>
#include <kernel/file.h>
#include <kernel/vfs.h>
#include <kernel/stat.h>
#include <kernel/proc.h>
#include <kernel/device.h>
#include <kernel/epoll.h>
#include <kernel/fcntl.h>
#include <kernel/fs_trace.h>

struct {
  struct spinlock lock;
  struct file file[NFILE];
} ftable;

// Trace only the first operations after boot.  This diagnostic counter is
// deliberately approximate on SMP: a race may print one extra line, but it
// avoids pulling libgcc atomic helpers into the freestanding kernel.
#if VFS_TRACE
static int vfs_io_trace_budget = 0x7fffffff;

static int
vfs_io_trace_take(void)
{
  if(vfs_io_trace_budget <= 0)
    return 0;
  vfs_io_trace_budget--;
  return 1;
}
#endif

static char*
vfs_file_type_name(int type)
{
  switch(type){
  case FD_PIPE: return "pipe";
  case FD_INODE: return "inode";
  case FD_DEVICE: return "device";
  case FD_SOCKET: return "socket";
  case FD_EPOLL: return "epoll";
  default: return "none";
  }
}

static void
vfs_io_trace(char *op, struct file *f, char *method, uint64 off,
             int requested, int result)
{
  struct super_block *sb = f->ip ? getsuper(f->ip->dev) : 0;
  printf("vfs-trace: file_%s: type=%s method=f_op->%s f_op=%p",
         op, vfs_file_type_name(f->type), method, (uint64)f->f_op);
  if(f->ip)
    printf(" fs=%s dev=%d ino=%d", sb ? sb->type : "unknown",
           f->ip->dev, f->ip->inum);
  printf(" off=%p requested=%d result=%d\n", off, requested, result);
}

void
fileinit(void)
{
  initlock(&ftable.lock, "ftable");
  epollinit();
}

// Allocate a file structure.
struct file*
filealloc(void)
{
  struct file *f;

  acquire(&ftable.lock);
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    if(f->ref == 0){
      memset(f, 0, sizeof(*f));
      f->ref = 1;
      mutex_init(&f->pos_lock, "file-position");
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
  return 0;
}

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
  acquire(&ftable.lock);
  if(f->ref < 1)
    panic("filedup");
  f->ref++;
  release(&ftable.lock);
  return f;
}

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
  struct file ff;

  acquire(&ftable.lock);
  if(f->ref < 1)
    panic("fileclose");
  if(--f->ref > 0){
    release(&ftable.lock);
    return;
  }
  ff = *f;
  f->ref = 0;
  f->type = FD_NONE;
  release(&ftable.lock);

  VFSTRACE("file_close: type=%s f_op=%p dev=%d ino=%d\n",
           vfs_file_type_name(ff.type), (uint64)ff.f_op,
           ff.ip ? ff.ip->dev : 0, ff.ip ? ff.ip->inum : 0);

  if(ff.f_op && ff.f_op->release)
    ff.f_op->release(&ff);

  // Inodes are references owned by both regular and device file objects.
  // Their common lifetime is intentionally outside the operations table:
  // drivers release private state, then the file core drops the VFS inode.
  if(ff.ip){
    begin_op();
    iput(ff.ip);
    end_op();
  }
}

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
  struct proc *p = myproc();
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    ireadlock(f->ip);
    stati(f->ip, &st);
    VFSTRACE("file_stat: dev=%d ino=%d type=%d nlink=%d size=%p\n",
             st.dev, st.ino, st.type, st.nlink, st.size);
    ireadunlock(f->ip);
    if(copyout(p->vm->pagetable, addr, (char *)&st, sizeof(st)) < 0)
      return -1;
    return 0;
  }
  return -1;
}

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
  int r = 0;
  uint64 oldoff = f->off;
  int trace = 0;
#if VFS_TRACE
  trace = vfs_io_trace_take();
#endif

  if(f->readable == 0 || f->f_op == 0)
    return -1;
  if(f->f_op->fread)
    r = f->f_op->fread(f, 1, addr, n);
  else if(f->f_op->read)
    r = f->f_op->read(1, addr, n);
  else
    return -1;

  if(trace)
    vfs_io_trace("read", f, f->f_op->fread ? "fread" : "read",
                 oldoff, n, r);

  return r;
}

// Write n bytes from user address addr at offset off through the open file's
// filesystem operations; returns the bytes written.  xv6fs writes go through the log a
// few blocks per transaction (inode, indirect block, allocation blocks and
// 2 blocks of slop for non-aligned writes must fit in one transaction);
// other filesystems take the whole request.
static int
file_write_at(struct file *f, int user_src, uint64 addr, uint64 off, int n)
{
  struct inode *ip = f->ip;
  struct super_block *sb = getsuper(ip->dev);
  int max = (sb && sb->logged) ? ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE : n;
  int i = 0;

  if(f->f_op == 0 || f->f_op->write_at == 0)
    return -1;
  while(i < n){
    int n1 = n - i;
    if(n1 > max)
      n1 = max;
    begin_op();
    ilock(ip);
    int r = f->f_op->write_at(f, user_src, addr + i, off + i, n1);
    iunlock(ip);
    end_op();
    if(r <= 0)
      break;
    i += r;
    if(r != n1)
      break;
  }
  return i;
}

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
  int ret = 0;
  uint64 oldoff = f->off;
  int trace = 0;
#if VFS_TRACE
  trace = vfs_io_trace_take();
#endif

  if(f->writable == 0 || f->f_op == 0)
    return -1;
  if(f->f_op->fwrite)
    ret = f->f_op->fwrite(f, 1, addr, n);
  else if(f->f_op->write)
    ret = f->f_op->write(1, addr, n);
  else
    return -1;

  if(trace)
    vfs_io_trace("write", f, f->f_op->fwrite ? "fwrite" : "write",
                 oldoff, n, ret);

  return ret;
}

int
generic_file_fread(struct file *f, int user_dst, uint64 addr, int n)
{
  int r;
  if(f == 0 || f->ip == 0 || f->f_op == 0 || f->f_op->read_at == 0)
    return -1;
  mutex_lock(&f->pos_lock);
  ireadlock(f->ip);
  r = f->f_op->read_at(f, user_dst, addr, f->off, n);
  if(r > 0)
    f->off += r;
  ireadunlock(f->ip);
  mutex_unlock(&f->pos_lock);
  return r;
}

int
generic_file_fwrite(struct file *f, int user_src, uint64 addr, int n)
{
  if(!user_src)
    return -1;
  mutex_lock(&f->pos_lock);
  int done = file_write_at(f, user_src, addr, f->off, n);
  if(done > 0)
    f->off += done;
  mutex_unlock(&f->pos_lock);
  return done == n ? n : -1;
}

int
generic_file_poll(struct file *f, int events)
{
  int ready = 0;
  if(f->readable && (events & EPOLLIN))
    ready |= EPOLLIN;       // EOF is readable and returns zero bytes
  if(f->writable && (events & EPOLLOUT))
    ready |= EPOLLOUT;
  return ready;
}

int
file_inode_setup(struct file *f)
{
  if(f == 0 || f->ip == 0 || f->ip->i_fop == 0)
    return -1;
  f->f_op = f->ip->i_fop;
  return 0;
}

int
filepoll(struct file *f, int events)
{
  return f && f->f_op && f->f_op->poll ? f->f_op->poll(f, events) : 0;
}

int
fileioctl(struct file *f, uint64 cmd, uint64 arg)
{
  return f && f->f_op && f->f_op->ioctl ? f->f_op->ioctl(f, cmd, arg) : -1;
}

uint64
filemmap(struct file *f, uint64 addr, uint64 len, int prot, int flags,
         uint64 off)
{
  return f && f->f_op && f->f_op->mmap ?
    f->f_op->mmap(f, addr, len, prot, flags, off) : (uint64)-1;
}

int
filemunmap(struct file *f, uint64 addr, uint64 len)
{
  return f && f->f_op && f->f_op->munmap ?
    f->f_op->munmap(f, addr, len) : -1;
}

int
filepread(struct file *f, uint64 addr, int n, uint64 off)
{
  int r;
  if(n < 0 || !f->readable || f->type != FD_INODE || f->f_op == 0 ||
     f->f_op->read_at == 0)
    return -1;
  ireadlock(f->ip);
  r = f->f_op->read_at(f, 1, addr, off, n);
  ireadunlock(f->ip);
  VFSTRACE("file_pread: dev=%d ino=%d off=%p requested=%d result=%d\n",
           f->ip->dev, f->ip->inum, off, n, r);
  return r;
}

int
filepwrite(struct file *f, uint64 addr, int n, uint64 off)
{
  if(n < 0 || !f->writable || f->type != FD_INODE || f->f_op == 0 ||
     f->f_op->write_at == 0)
    return -1;
  int done = file_write_at(f, 1, addr, off, n);
  VFSTRACE("file_pwrite: dev=%d ino=%d off=%p requested=%d result=%d\n",
           f->ip->dev, f->ip->inum, off, n, done == n ? n : -1);
  return done == n ? n : -1;
}

int
filetruncate(struct file *f, uint64 size)
{
  int r = -1;
  if(!f->writable || f->type != FD_INODE)
    return -1;
  begin_op();
  ilock(f->ip);
  if(f->ip->iop->truncate)
    r = f->ip->iop->truncate(f->ip, size);
  iunlock(f->ip);
  end_op();
  VFSTRACE("file_truncate: dev=%d ino=%d size=%p result=%d\n",
           f->ip->dev, f->ip->inum, size, r);
  return r;
}

int
filefsync(struct file *f, int dataonly)
{
  int r = 0;
  if(f->type != FD_INODE || f->f_op == 0)
    return -1;
  VFSTRACE("file_%s: dispatch dev=%d ino=%d\n",
           dataonly ? "fdatasync" : "fsync", f->ip->dev, f->ip->inum);
  ilock(f->ip);
  if(f->f_op->fsync)
    r = f->f_op->fsync(f, dataonly);
  iunlock(f->ip);
  VFSTRACE("file_%s: complete dev=%d ino=%d result=%d\n",
           dataonly ? "fdatasync" : "fsync", f->ip->dev, f->ip->inum, r);
  return r;
}

// Read through an inode's default file operations while its caller holds the
// inode lock.  exec and the module loader have kernel buffers and do not own a
// userspace file descriptor, but they must use the same filesystem data path
// as read/pread instead of reaching through inode_operations.
int
file_inode_read_locked(struct inode *ip, int user_dst, uint64 dst,
                       uint64 off, uint n)
{
  if(ip == 0 || ip->i_fop == 0 || ip->i_fop->read_at == 0)
    return -1;
  struct file file;
  memset(&file, 0, sizeof(file));
  file.ip = ip;
  file.f_op = ip->i_fop;
  file.readable = 1;
  return file.f_op->read_at(&file, user_dst, dst, off, n);
}
