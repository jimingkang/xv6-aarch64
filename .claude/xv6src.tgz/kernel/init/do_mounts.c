// Mounting the root filesystem, the embedded-Linux way
// (compare Linux init/do_mounts.c, init/noinitramfs.c, drivers/base/devtmpfs.c).
//
// Linux without an initramfs boots like this:
//
//   init_mount_tree()     "/" is rootfs, a filesystem in RAM
//   default_rootfs()      mkdir /dev, mknod /dev/console, mkdir /root
//   devtmpfs_init()       a private RAM filesystem the driver core fills
//   prepare_namespace()   ROOT_DEV = name_to_dev_t(root=)   (rootdev.c)
//     mount_root()        mknod /dev/root, mount it on /root, chdir /root
//     devtmpfs_mount()    mount devtmpfs on dev (= /root/dev)
//     mount(".", "/", MS_MOVE)   the real root now covers rootfs
//     chroot(".")         and becomes "/" for init
//   run_init_process("/init")
//
// xv6 does the same steps in forkret() of the first process, because the
// buffer cache and inode locks need a process context.  Linux's rootfs and
// devtmpfs are ramfs/tmpfs; xv6's inode layer sits on the buffer cache, so
// here they are ordinary xv6 filesystems on two RAM disks (blkdev.c),
// formatted in memory at boot and gone at reboot.

#include <kernel/types.h>
#include "aarch64.h"
#include <kernel/param.h>
#include <kernel/spinlock.h>
#include <kernel/sleeplock.h>
#include <kernel/proc.h>
#include <kernel/fs.h>
#include <kernel/buf.h>
#include <kernel/file.h>
#include <kernel/stat.h>
#include <kernel/defs.h>
#include <kernel/blkdev.h>
#include <kernel/vfs.h>
#include <kernel/workqueue.h>
#include <kernel/device.h>
#include <kernel/input.h>

#define ROOTFS_DEV    BLKDEV_RAM(0)
#define DEVTMPFS_DEV  BLKDEV_RAM(1)

// Format an empty xv6 filesystem directly in RAM-disk memory, like mkfs:
// [ boot | super | inodes | bitmap | data ].  No log: RAM-disk blocks are
// written through (log_write()).
static void
ramfs_mkfs(int dev, uint nblocks, uint ninodes)
{
  struct superblock sb;
  uint ninodeblocks = ninodes / IPB + 1;
  uint nbitmap = nblocks / BPB + 1;
  uint datastart = 2 + ninodeblocks + nbitmap;

  memset(&sb, 0, sizeof(sb));
  sb.magic = FSMAGIC;
  sb.size = nblocks;
  sb.nblocks = nblocks - datastart;
  sb.ninodes = ninodes;
  sb.nlog = 0;
  sb.logstart = 2;
  sb.inodestart = 2;
  sb.bmapstart = 2 + ninodeblocks;
  memmove(ramdisk_ptr(dev, BSIZE), &sb, sizeof(sb));

  // Root directory: inode 1 with "." and ".." in the first data block.
  struct dinode *di = (struct dinode *)ramdisk_ptr(dev,
                        IBLOCK(ROOTINO, sb) * BSIZE) + ROOTINO % IPB;
  di->type = T_DIR;
  di->nlink = 1;
  di->size = 2 * sizeof(struct dirent);
  di->addrs[0] = datastart;
  struct dirent *de = (struct dirent *)ramdisk_ptr(dev, datastart * BSIZE);
  de[0].inum = ROOTINO;
  safestrcpy(de[0].name, ".", DIRSIZ);
  de[1].inum = ROOTINO;
  safestrcpy(de[1].name, "..", DIRSIZ);

  // Metadata blocks and the root directory block are in use.
  uchar *bm = ramdisk_ptr(dev, sb.bmapstart * BSIZE);
  for(uint b = 0; b <= datastart; b++)
    bm[b / 8] |= 1 << (b % 8);
}

static void
ramfs_create(int n, int dev, char *name, uint nblocks, uint ninodes)
{
  if(ramdisk_create(n, dev, name, nblocks * BSIZE, BSIZE) < 0)
    panic("ramfs: no RAM disk");
  ramfs_mkfs(dev, nblocks, ninodes);
  struct fs_type *t = get_fs_type("xv6fs");
  if(t == 0 || t->fill_super(dev, 0) < 0)
    panic("ramfs: bad superblock");
}

// Kernel-internal file system calls (Linux: init_mkdir(), init_mknod() ...).

static int
kmknod(char *path, short type, short major, short minor)
{
  struct inode *dp, *ip;
  char name[NAMEMAX];

  begin_op();
  if((dp = nameiparent(path, name)) == 0){
    end_op();
    return -1;
  }
  ip = fs_create(dp, name, type, major, minor);
  if(ip)
    iunlockput(ip);
  end_op();
  return ip ? 0 : -1;
}

static struct inode*
klookup(char *path)
{
  begin_op();
  struct inode *ip = namei(path);
  end_op();
  return ip;
}

static void
kput(struct inode *ip)
{
  begin_op();
  iput(ip);
  end_op();
}

static int
kchdir(char *path)
{
  struct proc *p = myproc();
  struct inode *ip = klookup(path);
  if(ip == 0)
    return -1;
  ilock(ip);
  int dir = ip->type == T_DIR;
  iunlock(ip);
  if(!dir){
    kput(ip);
    return -1;
  }
  if(p->cwd)
    kput(p->cwd);
  p->cwd = ip;
  return 0;
}

// ---------------------------------------------------------------------------
// devtmpfs: /dev maintained by the kernel.  Every device_register() object
// carrying a devnode/major/minor identity gets a node for exactly the same
// lifetime; hotplug changes are applied by a work item, never in IRQ context.

static int devtmpfs_ready;
static struct work_struct devtmpfs_work;
static struct spinlock devtmpfs_event_lock;
#define DEVTMPFS_EVENTS (2 * DEVICE_MAX)
struct devtmpfs_event {
  int used;
  int add;
  short major;
  short minor;
  char path[DEVICE_NAME_MAX];
};
static struct devtmpfs_event devtmpfs_events[DEVTMPFS_EVENTS];
static int devtmpfs_rescan;

// Create "a/b/name" below the devtmpfs root, making directories as needed.
// Existing nodes are left alone.  Returns 1 if a node was created.
static int
devtmpfs_create_node(char *path, short major, short minor)
{
  char elem[DIRSIZ];
  int created = 0;

  begin_op();
  struct inode *dp = fs_dev_root(DEVTMPFS_DEV), *ip;
  while(*path){
    char *e = path;
    int len;
    while(*e && *e != '/')
      e++;
    len = e - path;
    if(len >= DIRSIZ)
      len = DIRSIZ - 1;
    memmove(elem, path, len);
    elem[len] = 0;
    path = *e ? e + 1 : e;

    ilock(dp);
    ip = dirlookup(dp, elem, 0);
    iunlock(dp);
    if(ip){                           // exists: descend or stop
      iput(dp);
      dp = ip;
      continue;
    }
    ip = fs_create(dp, elem, *path ? T_DIR : T_DEVICE,
                   *path ? 0 : major, *path ? 0 : minor);   // consumes dp
    if(ip == 0){
      end_op();
      return created;
    }
    iunlock(ip);
    created = 1;
    dp = ip;
  }
  iput(dp);
  end_op();
  return created;
}

static int
devtmpfs_remove_node(char *path)
{
  char elem[DIRSIZ];
  int removed = 0;
  begin_op();
  struct inode *dp = fs_dev_root(DEVTMPFS_DEV), *ip;
  while(dp && *path){
    char *e = path;
    int len;
    while(*e && *e != '/')
      e++;
    len = e - path;
    if(len >= DIRSIZ)
      len = DIRSIZ - 1;
    memmove(elem, path, len);
    elem[len] = 0;
    path = *e ? e + 1 : e;
    if(*path == 0){
      removed = fs_unlink(dp, elem) == 0;
      break;
    }
    ilock(dp);
    ip = dirlookup(dp, elem, 0);
    iunlock(dp);
    iput(dp);
    dp = ip;
  }
  if(dp)
    iput(dp);
  end_op();
  return removed;
}

static int
devtmpfs_populate(void)
{
  int n = 0;
  for(int i = 0; i < DEVICE_MAX; i++){
    struct device *dev = device_at(i);
    if(dev == 0)
      break;
    if(dev->devnode)
      n += devtmpfs_create_node(dev->devnode, dev->dev_major,
                                dev->dev_minor);
  }
  return n;
}

static void
devtmpfs_worker(struct work_struct *w)
{
  int changed = 0;
  for(;;){
    struct devtmpfs_event event;
    int found = 0, rescan = 0;
    acquire(&devtmpfs_event_lock);
    for(int i = 0; i < DEVTMPFS_EVENTS; i++){
      if(!devtmpfs_events[i].used)
        continue;
      event = devtmpfs_events[i];
      devtmpfs_events[i].used = 0;
      found = 1;
      break;
    }
    if(!found && devtmpfs_rescan){
      devtmpfs_rescan = 0;
      rescan = 1;
    }
    release(&devtmpfs_event_lock);
    if(found)
      changed += event.add ?
        devtmpfs_create_node(event.path, event.major, event.minor) :
        devtmpfs_remove_node(event.path);
    else if(rescan)
      changed += devtmpfs_populate();
    else
      break;
  }
  if(changed)
    printf("devtmpfs: applied %d device node change%s\n", changed,
           changed == 1 ? "" : "s");
}

static void
devtmpfs_queue_device(struct device *dev, int add)
{
  if(!devtmpfs_ready || dev == 0 || dev->devnode == 0)
    return;
  acquire(&devtmpfs_event_lock);
  // Collapse repeated add/remove transitions for one hotplug object.  Besides
  // avoiding needless filesystem work this preserves the final state when a
  // device disconnects and reconnects before the worker gets CPU time.
  for(int i = 0; i < DEVTMPFS_EVENTS; i++){
    if(!devtmpfs_events[i].used ||
       strncmp(devtmpfs_events[i].path, dev->devnode,
               sizeof(devtmpfs_events[i].path)) != 0)
      continue;
    devtmpfs_events[i].add = add;
    devtmpfs_events[i].major = dev->dev_major;
    devtmpfs_events[i].minor = dev->dev_minor;
    release(&devtmpfs_event_lock);
    schedule_work(&devtmpfs_work);
    return;
  }
  for(int i = 0; i < DEVTMPFS_EVENTS; i++){
    if(devtmpfs_events[i].used)
      continue;
    devtmpfs_events[i].used = 1;
    devtmpfs_events[i].add = add;
    devtmpfs_events[i].major = dev->dev_major;
    devtmpfs_events[i].minor = dev->dev_minor;
    safestrcpy(devtmpfs_events[i].path, dev->devnode,
               sizeof(devtmpfs_events[i].path));
    release(&devtmpfs_event_lock);
    schedule_work(&devtmpfs_work);
    return;
  }
  // Creation can be recovered by a full discovery scan.  Coalescing plus two
  // slots per possible device makes deletion overflow unreachable under the
  // current bounded device model unless callers churn invalid identities.
  devtmpfs_rescan = 1;
  release(&devtmpfs_event_lock);
  schedule_work(&devtmpfs_work);
}

void
devtmpfs_device_add(struct device *dev)
{
  devtmpfs_queue_device(dev, 1);
}

void
devtmpfs_device_del(struct device *dev)
{
  devtmpfs_queue_device(dev, 0);
}

static void
devtmpfs_init(void)
{
  ramfs_create(1, DEVTMPFS_DEV, "ram1", 64, 48);
  initlock(&devtmpfs_event_lock, "devtmpfs-events");
  memset(devtmpfs_events, 0, sizeof(devtmpfs_events));
  init_work(&devtmpfs_work, devtmpfs_worker);
  int n = devtmpfs_populate();
  devtmpfs_ready = 1;
  printf("devtmpfs: initialized on ram1, %d nodes\n", n);
}

// Mount devtmpfs on "dev" relative to the current directory (Linux:
// devtmpfs_mount(), called with the cwd at the future root).
static void
devtmpfs_mount(char *path, char *shown)
{
  struct inode *mp = klookup(path);
  if(mp == 0 || fs_mount(mp, DEVTMPFS_DEV, "devtmpfs", "devtmpfs",
                         shown) < 0){
    printf("devtmpfs: error mounting on %s\n", shown);
    if(mp)
      kput(mp);
    return;
  }
  printf("devtmpfs: mounted\n");
}

// ---------------------------------------------------------------------------

// mount_root(): mount the filesystem on the block device named by the node
// devname on directory dir.  rootfstype= picks the registered type; its
// get_sb resolves devname with lookup_bdev() and runs fill_super (xv6fs:
// block size, superblock, log recovery; ext2: external journal recovery and
// superblock).  The result is an ordinary entry of the one mount
// table, so both are MS_MOVEd and chrooted the same way afterwards.
static void
mount_root(char *devname, char *dir)
{
  char *type = rootdev_fstype() == ROOTFS_EXT2 ? "ext2" : "xv6fs";
  int dev = vfs_get_sb(type, devname, VFS_MOUNT_ROOTLOG);
  if(dev < 0)
    panic("VFS: Unable to mount root fs on /dev/root");
  struct blkdev *bd = blkdev_get(dev);
  struct inode *mp = klookup(dir);
  if(mp == 0 || fs_mount(mp, dev, type, devname, dir) < 0)
    panic("VFS: cannot attach root");
  printf("VFS: Mounted root (%s filesystem) on device %d (/dev/root = %s).\n",
         type, dev, bd ? bd->name : "?");
}

void
prepare_namespace(void)
{
  struct proc *p = myproc();

  // rootfs: the first "/".
  ramfs_create(0, ROOTFS_DEV, "ram0", 32, 16);
  struct inode *r = fs_dev_root(ROOTFS_DEV);
  fs_set_root(r);
  p->cwd = r;
  kmknod("/dev", T_DIR, 0, 0);
  kmknod("/dev/console", T_DEVICE, CONSOLE, 0);
  kmknod("/root", T_DIR, 0, 0);
  printf("rootfs: ram0 is /, with /dev/console and /root\n");

  devtmpfs_init();

  // mount_root(): ROOT_DEV, chosen by rootdev_init() from root=, is the
  // root partition itself (mmcblk0pN), or mmcblk0 for a bare image.
  int rootdev = rootdev_dev();
  if(rootdev < 0)
    panic("prepare_namespace: no ROOT_DEV");
  kmknod("/dev/root", T_DEVICE, BLOCKDEV, rootdev);
  mount_root("/dev/root", "/root");
  if(kchdir("/root") < 0)
    panic("prepare_namespace: chdir /root");

  // A freshly made fs.img has no /dev yet (init used to create it); make
  // the mount point instead of booting without devtmpfs.
  struct inode *d = klookup("dev");
  if(d)
    kput(d);
  else if(kmknod("dev", T_DIR, 0, 0) == 0)
    printf("devtmpfs: created /dev on the root filesystem\n");
  devtmpfs_mount("dev", "/root/dev");

  // mount(".", "/", MS_MOVE): the root mount leaves /root and covers "/".
  struct inode *from = idup(p->cwd), *to = klookup("/");
  if(fs_move_mount(from, to, "/") < 0)
    panic("prepare_namespace: MS_MOVE");
  kput(from);

  // chroot("."): "/" is now the disk root for every process.
  fs_set_root(p->cwd);
  safestrcpy(p->cwdpath, "/", sizeof(p->cwdpath));
  printf("VFS: root moved over rootfs, chroot done; running /init\n");
}
