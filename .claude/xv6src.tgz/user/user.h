#ifndef XV6_USER_H
#define XV6_USER_H

#include <uapi/types.h>

struct stat;
struct rtcdate;
struct ext2_user_dirent;
struct epoll_event;
struct pollfd;

// system calls
int fork(void);
int exit(int) __attribute__((noreturn));
int wait(int*);
int waitpid(int, int*, int);
int pipe(int*);
int write(int, const void*, int);
int read(int, void*, int);
int close(int);
int kill(int);
int exec(char*, char**);
int open(const char*, int, ...);
int mknod(const char*, int, unsigned long);
int unlink(const char*);
int fstat(int fd, struct stat*);
int link(const char*, const char*);
int mkdir(const char*);
int chdir(const char*);
int dup(int);
int dup2(int, int);
int getpid(void);
int getppid(void);
int gettid(void);
char *getcwd(char*, int);
int readlink(const char*, char*, int);
int reboot(int);
int connect(int, const void*, int);
uint32 net_dns(void);
int clone(void (*)(void*), void*, void*);
int texit(int) __attribute__((noreturn));
int tjoin(int, int*);

#define THREAD_STACK_SIZE (4 * 4096)
typedef struct thread {
  int tid;
  void *stack;
} thread_t;
int thread_create(thread_t*, void (*)(void*), void*);
int thread_join(thread_t*, int*);
char* sbrk(int);
int sleep_ticks(int);
unsigned int sleep(unsigned int);
int usleep(unsigned int);
int uptime(void);
int ps(void*, int);
int ext2read(const char*, void*, int, uint64);
int ext2readdir(const char*, int, struct ext2_user_dirent*);
int sync_create(int, int);
int sync_wait(int);
int sync_signal(int, int);
int sync_reset(int);
int sync_atomic(int, int, int, int);
int sync_destroy(int);
int udp_bind(int);
int udp_unbind(int);
int udp_send(uint32, int, int, const void*, int);
int udp_recv(int, uint32*, uint16*, void*, int);
int udp_tryrecv(int, uint32*, uint16*, void*, int);
int udp_recv_timeout(int, uint32*, uint16*, void*, int, int);
int icmp_send(uint32, int, int, const void*, int);
int icmp_recv(int, uint32*, uint16*, void*, int);
int mount(const char*, const char*, const char*, int);
int umount(const char*);
int tty_attach(int);
int tty_set_foreground(int);
int vmdump(int);
int wifi_connect(const char*, const char*);
int net_dhcp(const char*);
int tcp_listen(int);
int tcp_accept(int);
int tcp_read(int, void*, int);
int tcp_write(int, const void*, int);
int tcp_close(int);
int socket_listen(int, int);
int socket_accept(int);
int epoll_create(void);
int epoll_ctl(int, int, int, struct epoll_event*);
int epoll_wait(int, struct epoll_event*, int, int);
int fcntl(int, int, ...);
int pty_open(int*);
int getrandom(void*, int);
int rename(const char*, const char*);
struct sched_info;
int sched_setscheduler(int pid, int policy, int priority);
int sched_getinfo(int pid, struct sched_info*);
int setnice(int pid, int nice);
int sched_setaffinity(int pid, uint mask);
int sched_yield(void);
uint64 clock_us(void);
int getcpu(void);
int socket(int, int, int);
int bind(int, const void*, int);
int listen(int, int);
long lseek(int, long, int);
int fsync(int);
int fdatasync(int);
int ftruncate(int, uint64);
int pread(int, void*, int, uint64);
int pwrite(int, const void*, int, uint64);
void *mmap(void*, unsigned long, int, int, int, long);
int munmap(void*, unsigned long);
int init_module(void*, unsigned long, const char*);
int delete_module(const char*);
int poll(struct pollfd*, unsigned long, int);
int ioctl(int, unsigned long, ...);

// ulib.c
int stat(const char*, struct stat*);
char* strcpy(char*, const char*);
char* strncpy(char*, const char*, int);
char* strcat(char*, const char*);
int strncmp(const char*, const char*, uint);
uint strnlen(const char*, uint);
void *memmove(void*, const void*, int);
char* strchr(const char*, char c);
int strcmp(const char*, const char*);
int fprintf(int, const char*, ...);
int printf(const char*, ...);
char* gets(char*, int max);
uint strlen(const char*);
void* memset(void*, int, uint);
void* malloc(uint);
void free(void*);
int atoi(const char*);
int memcmp(const void *, const void *, uint);
void *memcpy(void *, const void *, uint);

#endif
