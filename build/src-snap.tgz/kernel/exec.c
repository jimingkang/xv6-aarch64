#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "aarch64.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "elf.h"
#include "mmtrace.h"

static int loadseg(pde_t *pgdir, uint64 addr, struct inode *ip, uint offset, uint sz);

int
exec(char *path, char **argv)
{
  char *s, *last;
  int i, off;
  uint64 argc, sz = 0, sp, stackbase;
  uintptr ustack[MAXARG];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
  struct vmspace *vm = p->vm;

  // Replacing a shared address space underneath another thread is unsafe.
  // This first implementation requires callers to join all other threads
  // before exec. execing closes the race with a concurrent clone().
  acquire(&vm->lock);
  if(vm->refcount != 1 || vm->execing){
    release(&vm->lock);
    return -1;
  }
  vm->execing = 1;
  release(&vm->lock);

  begin_op();

  if((ip = namei(path)) == 0){
    end_op();
    acquire(&vm->lock);
    vm->execing = 0;
    release(&vm->lock);
    return -1;
  }
  ilock(ip);

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    goto bad;
  if(elf.magic != ELF_MAGIC
     || elf.elf[0] != 1 || elf.elf[1] != 1 || elf.machine != 40
     || elf.phentsize != sizeof(struct proghdr)
    )
    goto bad;

  uint64 free0 = kfreepages();
  if(MMTRACE(2))
    printf("exec: %s pid %d: inode %d, %d bytes, ELF entry %x, %d program headers\n",
           path, p->pid, ip->inum, ip->size, (uint)elf.entry, elf.phnum);
  p->mmtrace = 1;
  if((pagetable = uvmcreate()) == 0)
    goto bad;

  // Load program into memory.
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
      continue;
    if(MMTRACE(2))
      printf("exec:   LOAD VA %x memsz %x filesz %x file off %x flags %x\n",
             (uint)ph.vaddr, (uint)ph.memsz, (uint)ph.filesz, (uint)ph.off, ph.flags);
    if(ph.memsz < ph.filesz)
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
      goto bad;
    uint64 sz1;
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz)) == 0)
      goto bad;
    sz = sz1;
    if((ph.vaddr % PGSIZE) != 0)
      goto bad;
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
      goto bad;
  }
  iunlockput(ip);
  end_op();
  ip = 0;

  p = myproc();
  uint64 oldsz;

  // Allocate one inaccessible guard page followed by a multi-page user
  // stack.  One 4 KiB page was enough for the original tiny xv6 commands,
  // but is too small for networking/crypto applications such as tftp and
  // sshd, whose local packet buffers and printf/write call chains overlap.
  sz = PGROUNDUP(sz);
  uint64 sz1;
  if((sz1 = uvmalloc(pagetable, sz,
                     sz + (USTACKPAGES + 1)*PGSIZE)) == 0)
    goto bad;
  sz = sz1;
  uvmclear(pagetable, sz-(USTACKPAGES + 1)*PGSIZE);
  sp = sz;
  stackbase = sp - USTACKPAGES*PGSIZE;
  if(MMTRACE(2))
    printf("exec:   stack: guard page VA %x (PTE_U cleared), stack VA %x-%x\n",
           (uint)(stackbase - PGSIZE), (uint)stackbase, (uint)sz - 1);

  // Push argument strings, prepare rest of stack in ustack.
  for(argc = 0; argv[argc]; argc++) {
    if(argc >= MAXARG)
      goto bad;
    sp -= strlen(argv[argc]) + 1;
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    if(sp < stackbase)
      goto bad;
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
      goto bad;
    ustack[argc] = sp;
  }
  ustack[argc] = 0;

  // push the array of argv[] pointers.
  sp -= (argc+1) * sizeof(uintptr);
  sp -= sp % 16;
  if(sp < stackbase)
    goto bad;
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uintptr)) < 0)
    goto bad;

  // arguments to user main(argc, argv)
  // argc is returned via the system call return
  // value, which goes in x0.
  p->trapframe->x1 = sp;

  // Save program name for debugging.
  for(last=s=path; *s; s++)
    if(*s == '/')
      last = s+1;
  safestrcpy(p->name, last, sizeof(p->name));
    
  // Commit to the user image.
  acquire(&vm->lock);
  oldpagetable = vm->pagetable;
  oldsz = vm->sz;
  vm->pagetable = pagetable;
  vm->sz = sz;
  vm->execing = 0;
  release(&vm->lock);
  p->trapframe->elr = elf.entry;  // initial program counter = main
  p->trapframe->spsr = 0x10; // ARM user mode, IRQ enabled.
  p->trapframe->sp = sp; // initial stack pointer
  p->mmtrace = 0;
  if(MMTRACE(2))
    printf("exec: %s pid %d: sz %x sp %x entry %x, %d kalloc pages, new L1 root %x\n",
           path, p->pid, (uint)sz, (uint)sp, (uint)elf.entry,
           (int)(free0 - kfreepages()), (uint)(uintptr)pagetable);
  uvmsync_icache(pagetable, sz);
  switchuvm(p);
  // uvmdump(p->vm->pagetable, p->pid, p->name, "exec-image");
  uvmfree(oldpagetable, oldsz);

  return argc; // this ends up in x0, the first argument to main(argc, argv)

 bad:
  p->mmtrace = 0;
  acquire(&vm->lock);
  vm->execing = 0;
  release(&vm->lock);
  if(pagetable)
    uvmfree(pagetable, sz);
  if(ip){
    iunlockput(ip);
    end_op();
  }
  return -1;
}

// Load a program segment into pagetable at virtual address va.
// va must be page-aligned
// and the pages from va to va+sz must already be mapped.
// Returns 0 on success, -1 on failure.
static int
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    pa = uva2ka(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
      return -1;
    if(MMTRACE_PAGES())
      printf("exec:   readi inode %d off %x -> VA %x (pa %x) %d bytes\n",
             ip->inum, offset + i, (uint)(va + i), (uint)pa, n);
  }
  
  return 0;
}
