
user/_chrt:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  printf("pid %d's current scheduling priority: %d\n", si.pid, si.priority);
}

int
main(int argc, char *argv[])
{
   0:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
   c:	aa0103f4 	mov	x20, x1
  int policy = SCHED_RR, pflag = 0, i = 1, prio, pid;

  for(; i < argc && argv[i][0] == '-'; i++){
  10:	d2800033 	mov	x19, #0x1                   	// #1
{
  14:	a90363f7 	stp	x23, x24, [sp, #48]
    if(strcmp(argv[i], "-f") == 0) policy = SCHED_FIFO;
  18:	b0000018 	adrp	x24, 1000 <printf+0x130>
  1c:	91006718 	add	x24, x24, #0x19
{
  20:	2a0003f7 	mov	w23, w0
  24:	a9046bf9 	stp	x25, x26, [sp, #64]
    else if(strcmp(argv[i], "-r") == 0) policy = SCHED_RR;
  28:	b0000019 	adrp	x25, 1000 <printf+0x130>
  2c:	91007339 	add	x25, x25, #0x1c
{
  30:	a9025bf5 	stp	x21, x22, [sp, #32]
  int policy = SCHED_RR, pflag = 0, i = 1, prio, pid;
  34:	52800016 	mov	w22, #0x0                   	// #0
  38:	52800055 	mov	w21, #0x2                   	// #2
  for(; i < argc && argv[i][0] == '-'; i++){
  3c:	6b1302ff 	cmp	w23, w19
  40:	540000ad 	b.le	54 <main+0x54>
  44:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
  48:	39400001 	ldrb	w1, [x0]
  4c:	7100b43f 	cmp	w1, #0x2d
  50:	540001c0 	b.eq	88 <main+0x88>  // b.none
    else if(strcmp(argv[i], "-o") == 0) policy = SCHED_OTHER;
    else if(strcmp(argv[i], "-p") == 0) pflag = 1;
    else usage();
  }

  if(pflag && argc - i == 1){                 // chrt -p PID
  54:	4b1302f7 	sub	w23, w23, w19
  58:	2a1303f3 	mov	w19, w19
  5c:	340004d6 	cbz	w22, f4 <main+0xf4>
  60:	710006ff 	cmp	w23, #0x1
  64:	54000481 	b.ne	f4 <main+0xf4>  // b.any
    if(!parse_num(argv[i], &pid))
  68:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
  6c:	910183e1 	add	x1, sp, #0x60
  70:	94000090 	bl	2b0 <parse_num>
  74:	340002c0 	cbz	w0, cc <main+0xcc>
      usage();
    show(pid);
  78:	b94063e0 	ldr	w0, [sp, #96]
    if(sched_setscheduler(pid, policy, prio) < 0){
      fprintf(2, "chrt: failed to set pid %d to %s priority %d\n",
              pid, policy_name(policy), prio);
      exit(1);
    }
    show(pid);
  7c:	940000d1 	bl	3c0 <show>
    exit(0);
  80:	52800000 	mov	w0, #0x0                   	// #0
  84:	1400003f 	b	180 <main+0x180>
    if(strcmp(argv[i], "-f") == 0) policy = SCHED_FIFO;
  88:	aa1803e1 	mov	x1, x24
  8c:	94000113 	bl	4d8 <strcmp>
  90:	34000200 	cbz	w0, d0 <main+0xd0>
    else if(strcmp(argv[i], "-r") == 0) policy = SCHED_RR;
  94:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
  98:	aa1903e1 	mov	x1, x25
  9c:	9400010f 	bl	4d8 <strcmp>
  a0:	34000200 	cbz	w0, e0 <main+0xe0>
    else if(strcmp(argv[i], "-o") == 0) policy = SCHED_OTHER;
  a4:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
  a8:	b0000001 	adrp	x1, 1000 <printf+0x130>
  ac:	91007c21 	add	x1, x1, #0x1f
  b0:	9400010a 	bl	4d8 <strcmp>
  b4:	34000100 	cbz	w0, d4 <main+0xd4>
    else if(strcmp(argv[i], "-p") == 0) pflag = 1;
  b8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
  bc:	b0000001 	adrp	x1, 1000 <printf+0x130>
  c0:	91008821 	add	x1, x1, #0x22
  c4:	94000105 	bl	4d8 <strcmp>
  c8:	34000100 	cbz	w0, e8 <main+0xe8>
    else usage();
  cc:	940000b5 	bl	3a0 <usage>
    if(strcmp(argv[i], "-f") == 0) policy = SCHED_FIFO;
  d0:	52800020 	mov	w0, #0x1                   	// #1
  for(; i < argc && argv[i][0] == '-'; i++){
  d4:	91000673 	add	x19, x19, #0x1
  int policy = SCHED_RR, pflag = 0, i = 1, prio, pid;
  d8:	2a0003f5 	mov	w21, w0
  dc:	17ffffd8 	b	3c <main+0x3c>
    else if(strcmp(argv[i], "-r") == 0) policy = SCHED_RR;
  e0:	52800040 	mov	w0, #0x2                   	// #2
  e4:	17fffffc 	b	d4 <main+0xd4>
    else if(strcmp(argv[i], "-p") == 0) pflag = 1;
  e8:	2a1503e0 	mov	w0, w21
  ec:	52800036 	mov	w22, #0x1                   	// #1
  f0:	17fffff9 	b	d4 <main+0xd4>
  if(argc - i < 2 || !parse_num(argv[i], &prio))
  f4:	710006ff 	cmp	w23, #0x1
  f8:	54fffead 	b.le	cc <main+0xcc>
  fc:	d37df273 	lsl	x19, x19, #3
 100:	910173e1 	add	x1, sp, #0x5c
 104:	f8736a80 	ldr	x0, [x20, x19]
 108:	9400006a 	bl	2b0 <parse_num>
 10c:	2a0003f7 	mov	w23, w0
 110:	34fffde0 	cbz	w0, cc <main+0xcc>
  if(pflag){                                  // chrt -x -p PRIO PID
 114:	34000436 	cbz	w22, 198 <main+0x198>
    if(!parse_num(argv[i + 1], &pid))
 118:	8b130293 	add	x19, x20, x19
 11c:	910183e1 	add	x1, sp, #0x60
 120:	f9400660 	ldr	x0, [x19, #8]
 124:	94000063 	bl	2b0 <parse_num>
 128:	34fffd20 	cbz	w0, cc <main+0xcc>
    if(sched_setscheduler(pid, policy, prio) < 0){
 12c:	294bcff4 	ldp	w20, w19, [sp, #92]
 130:	2a1503e1 	mov	w1, w21
 134:	2a1403e2 	mov	w2, w20
 138:	2a1303e0 	mov	w0, w19
 13c:	94000234 	bl	a0c <sched_setscheduler>
 140:	36f80280 	tbz	w0, #31, 190 <main+0x190>
}

static __attribute__((unused)) const char *
policy_name(int policy)
{
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 144:	710006bf 	cmp	w21, #0x1
 148:	540001e0 	b.eq	184 <main+0x184>  // b.none
  if(policy == SCHED_RR) return "SCHED_RR";
  return "SCHED_OTHER";
 14c:	71000abf 	cmp	w21, #0x2
 150:	90000000 	adrp	x0, 0 <main>
 154:	913e5c00 	add	x0, x0, #0xf97
 158:	90000003 	adrp	x3, 0 <main>
 15c:	913e8c63 	add	x3, x3, #0xfa3
 160:	9a800063 	csel	x3, x3, x0, eq	// eq = none
      fprintf(2, "chrt: failed to set pid %d to %s priority %d\n",
 164:	b0000001 	adrp	x1, 1000 <printf+0x130>
 168:	91009421 	add	x1, x1, #0x25
 16c:	2a1403e4 	mov	w4, w20
 170:	2a1303e2 	mov	w2, w19
 174:	52800040 	mov	w0, #0x2                   	// #2
 178:	94000342 	bl	e80 <fprintf>
      exit(1);
 17c:	52800020 	mov	w0, #0x1                   	// #1
 180:	94000178 	bl	760 <exit>
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 184:	90000003 	adrp	x3, 0 <main>
 188:	913e3063 	add	x3, x3, #0xf8c
 18c:	17fffff6 	b	164 <main+0x164>
    show(pid);
 190:	2a1303e0 	mov	w0, w19
 194:	17ffffba 	b	7c <main+0x7c>
  }

  // chrt -x PRIO CMD ...: change ourselves, then exec (attributes survive exec).
  if(sched_setscheduler(0, policy, prio) < 0){
 198:	b9405ff8 	ldr	w24, [sp, #92]
 19c:	2a1503e1 	mov	w1, w21
 1a0:	52800000 	mov	w0, #0x0                   	// #0
 1a4:	2a1803e2 	mov	w2, w24
 1a8:	94000219 	bl	a0c <sched_setscheduler>
 1ac:	36f80240 	tbz	w0, #31, 1f4 <main+0x1f4>
 1b0:	710006bf 	cmp	w21, #0x1
 1b4:	540001a0 	b.eq	1e8 <main+0x1e8>  // b.none
  return "SCHED_OTHER";
 1b8:	71000abf 	cmp	w21, #0x2
 1bc:	90000001 	adrp	x1, 0 <main>
 1c0:	913e5c21 	add	x1, x1, #0xf97
 1c4:	90000000 	adrp	x0, 0 <main>
 1c8:	913e8c00 	add	x0, x0, #0xfa3
 1cc:	9a810002 	csel	x2, x0, x1, eq	// eq = none
    fprintf(2, "chrt: invalid %s priority %d\n", policy_name(policy), prio);
 1d0:	2a1803e3 	mov	w3, w24
 1d4:	b0000001 	adrp	x1, 1000 <printf+0x130>
 1d8:	91014c21 	add	x1, x1, #0x53
 1dc:	52800040 	mov	w0, #0x2                   	// #2
 1e0:	94000328 	bl	e80 <fprintf>
    exit(1);
 1e4:	17ffffe6 	b	17c <main+0x17c>
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 1e8:	90000002 	adrp	x2, 0 <main>
 1ec:	913e3042 	add	x2, x2, #0xf8c
 1f0:	17fffff8 	b	1d0 <main+0x1d0>
  }
  exec_cmd(&argv[i + 1]);
 1f4:	91002273 	add	x19, x19, #0x8
 1f8:	8b130299 	add	x25, x20, x19
// exec() argv[0] the way sh does: as given if it has a '/', else /bin, then /.
static __attribute__((unused)) void
exec_cmd(char **argv)
{
  char path[64];
  char *name = argv[0];
 1fc:	f8736a98 	ldr	x24, [x20, x19]
  int n;

  for(char *c = name; *c; c++)
 200:	aa1803e0 	mov	x0, x24
 204:	39400001 	ldrb	w1, [x0]
 208:	350002e1 	cbnz	w1, 264 <main+0x264>
 20c:	b0000002 	adrp	x2, 1000 <printf+0x130>
 210:	91004c42 	add	x2, x2, #0x13
 214:	910183f5 	add	x21, sp, #0x60
    if(*c == '/'){
      exec(name, argv);
      return;
    }
  for(int pass = 0; pass < 2; pass++){
    const char *prefix = pass == 0 ? "/bin/" : "/";
 218:	b000001a 	adrp	x26, 1000 <printf+0x130>
    n = 0;
    for(const char *c = prefix; *c; c++)
 21c:	d2800000 	mov	x0, #0x0                   	// #0
 220:	38606841 	ldrb	w1, [x2, x0]
 224:	350003a1 	cbnz	w1, 298 <main+0x298>
 228:	2a0003e2 	mov	w2, w0
      path[n++] = *c;
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 22c:	cb204300 	sub	x0, x24, w0, uxtw
 230:	38626801 	ldrb	w1, [x0, x2]
 234:	34000061 	cbz	w1, 240 <main+0x240>
 238:	7100f85f 	cmp	w2, #0x3e
 23c:	5400034d 	b.le	2a4 <main+0x2a4>
      path[n++] = *c;
    path[n] = 0;
 240:	38224abf 	strb	wzr, [x21, w2, uxtw]
    exec(path, argv);
 244:	aa1903e1 	mov	x1, x25
 248:	aa1503e0 	mov	x0, x21
 24c:	9400015a 	bl	7b4 <exec>
    const char *prefix = pass == 0 ? "/bin/" : "/";
 250:	91005f42 	add	x2, x26, #0x17
  for(int pass = 0; pass < 2; pass++){
 254:	710006df 	cmp	w22, #0x1
 258:	54000100 	b.eq	278 <main+0x278>  // b.none
 25c:	2a1703f6 	mov	w22, w23
 260:	17ffffef 	b	21c <main+0x21c>
    if(*c == '/'){
 264:	7100bc3f 	cmp	w1, #0x2f
 268:	54000141 	b.ne	290 <main+0x290>  // b.any
      exec(name, argv);
 26c:	aa1903e1 	mov	x1, x25
 270:	aa1803e0 	mov	x0, x24
 274:	94000150 	bl	7b4 <exec>
  fprintf(2, "chrt: exec %s failed\n", argv[i + 1]);
 278:	f8736a82 	ldr	x2, [x20, x19]
 27c:	b0000001 	adrp	x1, 1000 <printf+0x130>
 280:	9101c421 	add	x1, x1, #0x71
 284:	52800040 	mov	w0, #0x2                   	// #2
 288:	940002fe 	bl	e80 <fprintf>
  exit(1);
 28c:	17ffffbc 	b	17c <main+0x17c>
  for(char *c = name; *c; c++)
 290:	91000400 	add	x0, x0, #0x1
 294:	17ffffdc 	b	204 <main+0x204>
      path[n++] = *c;
 298:	38206aa1 	strb	w1, [x21, x0]
    for(const char *c = prefix; *c; c++)
 29c:	91000400 	add	x0, x0, #0x1
 2a0:	17ffffe0 	b	220 <main+0x220>
      path[n++] = *c;
 2a4:	38226aa1 	strb	w1, [x21, x2]
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 2a8:	91000442 	add	x2, x2, #0x1
 2ac:	17ffffe1 	b	230 <main+0x230>

00000000000002b0 <parse_num>:
{
 2b0:	aa0003e2 	mov	x2, x0
  if(*s == '-'){
 2b4:	39400000 	ldrb	w0, [x0]
 2b8:	7100b41f 	cmp	w0, #0x2d
 2bc:	540002c1 	b.ne	314 <parse_num+0x64>  // b.any
    s++;
 2c0:	91000442 	add	x2, x2, #0x1
    neg = 1;
 2c4:	52800025 	mov	w5, #0x1                   	// #1
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 2c8:	39400040 	ldrb	w0, [x2]
 2cc:	7100c01f 	cmp	w0, #0x30
 2d0:	540000c1 	b.ne	2e8 <parse_num+0x38>  // b.any
 2d4:	39400440 	ldrb	w0, [x2, #1]
 2d8:	121a7800 	and	w0, w0, #0xffffffdf
 2dc:	12001c00 	and	w0, w0, #0xff
 2e0:	7101601f 	cmp	w0, #0x58
 2e4:	540001c0 	b.eq	31c <parse_num+0x6c>  // b.none
 2e8:	52800000 	mov	w0, #0x0                   	// #0
 2ec:	52800003 	mov	w3, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 2f0:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
 2f4:	39400044 	ldrb	w4, [x2]
 2f8:	340001c4 	cbz	w4, 330 <parse_num+0x80>
      if(*s < '0' || *s > '9')
 2fc:	5100c084 	sub	w4, w4, #0x30
 300:	12001c80 	and	w0, w4, #0xff
 304:	7100241f 	cmp	w0, #0x9
 308:	54000449 	b.ls	390 <parse_num+0xe0>  // b.plast
      else return 0;
 30c:	52800000 	mov	w0, #0x0                   	// #0
}
 310:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
 314:	52800005 	mov	w5, #0x0                   	// #0
 318:	17ffffec 	b	2c8 <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
 31c:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
 320:	52800000 	mov	w0, #0x0                   	// #0
 324:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 328:	39400044 	ldrb	w4, [x2]
 32c:	350000c4 	cbnz	w4, 344 <parse_num+0x94>
  if(!any)
 330:	34ffff00 	cbz	w0, 310 <parse_num+0x60>
  *out = neg ? -v : v;
 334:	710000bf 	cmp	w5, #0x0
 338:	5a830463 	cneg	w3, w3, ne	// ne = any
 33c:	b9000023 	str	w3, [x1]
  return 1;
 340:	17fffff4 	b	310 <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 344:	5100c080 	sub	w0, w4, #0x30
 348:	12001c06 	and	w6, w0, #0xff
 34c:	710024df 	cmp	w6, #0x9
 350:	540000c9 	b.ls	368 <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 354:	51018480 	sub	w0, w4, #0x61
 358:	12001c00 	and	w0, w0, #0xff
 35c:	7100141f 	cmp	w0, #0x5
 360:	540000c8 	b.hi	378 <parse_num+0xc8>  // b.pmore
 364:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
 368:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
 36c:	91000442 	add	x2, x2, #0x1
 370:	52800020 	mov	w0, #0x1                   	// #1
 374:	17ffffed 	b	328 <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 378:	51010480 	sub	w0, w4, #0x41
 37c:	12001c00 	and	w0, w0, #0xff
 380:	7100141f 	cmp	w0, #0x5
 384:	54fffc48 	b.hi	30c <parse_num+0x5c>  // b.pmore
 388:	5100dc80 	sub	w0, w4, #0x37
 38c:	17fffff7 	b	368 <parse_num+0xb8>
      v = v * 10 + (*s - '0');
 390:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
 394:	91000442 	add	x2, x2, #0x1
 398:	52800020 	mov	w0, #0x1                   	// #1
 39c:	17ffffd6 	b	2f4 <parse_num+0x44>

00000000000003a0 <usage>:
{
 3a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: chrt -p PID\n"
 3a4:	90000001 	adrp	x1, 0 <main>
 3a8:	913cb021 	add	x1, x1, #0xf2c
{
 3ac:	910003fd 	mov	x29, sp
  fprintf(2, "usage: chrt -p PID\n"
 3b0:	52800040 	mov	w0, #0x2                   	// #2
 3b4:	940002b3 	bl	e80 <fprintf>
  exit(1);
 3b8:	52800020 	mov	w0, #0x1                   	// #1
 3bc:	940000e9 	bl	760 <exit>

00000000000003c0 <show>:
{
 3c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 3c4:	910003fd 	mov	x29, sp
  if(sched_getinfo(pid, &si) < 0){
 3c8:	9100a3e1 	add	x1, sp, #0x28
{
 3cc:	b9001fe0 	str	w0, [sp, #28]
  if(sched_getinfo(pid, &si) < 0){
 3d0:	94000192 	bl	a18 <sched_getinfo>
 3d4:	b9401fe2 	ldr	w2, [sp, #28]
 3d8:	36f800e0 	tbz	w0, #31, 3f4 <show+0x34>
    fprintf(2, "chrt: no process %d\n", pid);
 3dc:	90000001 	adrp	x1, 0 <main>
 3e0:	913eb021 	add	x1, x1, #0xfac
 3e4:	52800040 	mov	w0, #0x2                   	// #2
 3e8:	940002a6 	bl	e80 <fprintf>
    exit(1);
 3ec:	52800020 	mov	w0, #0x1                   	// #1
 3f0:	940000dc 	bl	760 <exit>
  printf("pid %d's current scheduling policy: %s\n", si.pid,
 3f4:	29450fe1 	ldp	w1, w3, [sp, #40]
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 3f8:	7100047f 	cmp	w3, #0x1
 3fc:	54000220 	b.eq	440 <show+0x80>  // b.none
  return "SCHED_OTHER";
 400:	7100087f 	cmp	w3, #0x2
 404:	90000000 	adrp	x0, 0 <main>
 408:	913e5c00 	add	x0, x0, #0xf97
 40c:	90000002 	adrp	x2, 0 <main>
 410:	913e8c42 	add	x2, x2, #0xfa3
 414:	9a800042 	csel	x2, x2, x0, eq	// eq = none
 418:	90000000 	adrp	x0, 0 <main>
 41c:	913f0400 	add	x0, x0, #0xfc1
 420:	940002ac 	bl	ed0 <printf>
  printf("pid %d's current scheduling priority: %d\n", si.pid, si.priority);
 424:	b9402be1 	ldr	w1, [sp, #40]
 428:	90000000 	adrp	x0, 0 <main>
 42c:	913fa400 	add	x0, x0, #0xfe9
 430:	b94033e2 	ldr	w2, [sp, #48]
 434:	940002a7 	bl	ed0 <printf>
}
 438:	a8c57bfd 	ldp	x29, x30, [sp], #80
 43c:	d65f03c0 	ret
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 440:	90000002 	adrp	x2, 0 <main>
 444:	913e3042 	add	x2, x2, #0xf8c
 448:	17fffff4 	b	418 <show+0x58>

000000000000044c <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 44c:	d2800002 	mov	x2, #0x0                   	// #0
 450:	38626823 	ldrb	w3, [x1, x2]
 454:	38226803 	strb	w3, [x0, x2]
 458:	91000442 	add	x2, x2, #0x1
 45c:	35ffffa3 	cbnz	w3, 450 <strcpy+0x4>
    ;
  return os;
}
 460:	d65f03c0 	ret

0000000000000464 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 464:	d2800003 	mov	x3, #0x0                   	// #0
 468:	4b030044 	sub	w4, w2, w3
 46c:	7100009f 	cmp	w4, #0x0
 470:	5400006d 	b.le	47c <strncpy+0x18>
 474:	38636825 	ldrb	w5, [x1, x3]
 478:	350000e5 	cbnz	w5, 494 <strncpy+0x30>
 47c:	8b030003 	add	x3, x0, x3
 480:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 484:	4b010082 	sub	w2, w4, w1
 488:	7100005f 	cmp	w2, #0x0
 48c:	540000ac 	b.gt	4a0 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 490:	d65f03c0 	ret
    *s++ = *t++;
 494:	38236805 	strb	w5, [x0, x3]
    n--;
 498:	91000463 	add	x3, x3, #0x1
 49c:	17fffff3 	b	468 <strncpy+0x4>
    *s++ = 0;
 4a0:	3821687f 	strb	wzr, [x3, x1]
 4a4:	91000421 	add	x1, x1, #0x1
 4a8:	17fffff7 	b	484 <strncpy+0x20>

00000000000004ac <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 4ac:	aa0003e2 	mov	x2, x0
 4b0:	39400043 	ldrb	w3, [x2]
 4b4:	aa0203e4 	mov	x4, x2
    s++;
 4b8:	91000442 	add	x2, x2, #0x1
  while(*s)
 4bc:	35ffffa3 	cbnz	w3, 4b0 <strcat+0x4>
 4c0:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 4c4:	38626823 	ldrb	w3, [x1, x2]
 4c8:	38226883 	strb	w3, [x4, x2]
 4cc:	91000442 	add	x2, x2, #0x1
 4d0:	35ffffa3 	cbnz	w3, 4c4 <strcat+0x18>
    ;
  return os;
}
 4d4:	d65f03c0 	ret

00000000000004d8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 4d8:	d2800002 	mov	x2, #0x0                   	// #0
 4dc:	38626803 	ldrb	w3, [x0, x2]
 4e0:	38626824 	ldrb	w4, [x1, x2]
 4e4:	34000083 	cbz	w3, 4f4 <strcmp+0x1c>
 4e8:	91000442 	add	x2, x2, #0x1
 4ec:	6b04007f 	cmp	w3, w4
 4f0:	54ffff60 	b.eq	4dc <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 4f4:	4b040060 	sub	w0, w3, w4
 4f8:	d65f03c0 	ret

00000000000004fc <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 4fc:	340001c2 	cbz	w2, 534 <strncmp+0x38>
 500:	39400003 	ldrb	w3, [x0]
 504:	34000083 	cbz	w3, 514 <strncmp+0x18>
 508:	39400024 	ldrb	w4, [x1]
 50c:	6b03009f 	cmp	w4, w3
 510:	540000a0 	b.eq	524 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 514:	39400000 	ldrb	w0, [x0]
 518:	39400021 	ldrb	w1, [x1]
 51c:	4b010000 	sub	w0, w0, w1
}
 520:	d65f03c0 	ret
    n--, p++, q++;
 524:	51000442 	sub	w2, w2, #0x1
 528:	91000400 	add	x0, x0, #0x1
 52c:	91000421 	add	x1, x1, #0x1
 530:	17fffff3 	b	4fc <strncmp>
    return 0;
 534:	52800000 	mov	w0, #0x0                   	// #0
 538:	17fffffa 	b	520 <strncmp+0x24>

000000000000053c <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 53c:	d1000402 	sub	x2, x0, #0x1
 540:	d2800001 	mov	x1, #0x0                   	// #0
 544:	aa0103e0 	mov	x0, x1
 548:	91000421 	add	x1, x1, #0x1
 54c:	38616843 	ldrb	w3, [x2, x1]
 550:	35ffffa3 	cbnz	w3, 544 <strlen+0x8>
    ;
  return n;
}
 554:	d65f03c0 	ret

0000000000000558 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 558:	d1000403 	sub	x3, x0, #0x1
 55c:	d2800002 	mov	x2, #0x0                   	// #0
 560:	2a0203e0 	mov	w0, w2
 564:	6b02003f 	cmp	w1, w2
 568:	54000089 	b.ls	578 <strnlen+0x20>  // b.plast
 56c:	91000442 	add	x2, x2, #0x1
 570:	38626864 	ldrb	w4, [x3, x2]
 574:	35ffff64 	cbnz	w4, 560 <strnlen+0x8>
    n++;
  return n;
}
 578:	d65f03c0 	ret

000000000000057c <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 57c:	d2800003 	mov	x3, #0x0                   	// #0
 580:	6b03005f 	cmp	w2, w3
 584:	54000048 	b.hi	58c <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 588:	d65f03c0 	ret
    cdst[i] = c;
 58c:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 590:	91000463 	add	x3, x3, #0x1
 594:	17fffffb 	b	580 <memset+0x4>

0000000000000598 <strchr>:

char*
strchr(const char *s, char c)
{
 598:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 59c:	39400002 	ldrb	w2, [x0]
 5a0:	35000062 	cbnz	w2, 5ac <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 5a4:	d2800000 	mov	x0, #0x0                   	// #0
}
 5a8:	d65f03c0 	ret
    if(*s == c)
 5ac:	6b01005f 	cmp	w2, w1
 5b0:	54ffffc0 	b.eq	5a8 <strchr+0x10>  // b.none
  for(; *s; s++)
 5b4:	91000400 	add	x0, x0, #0x1
 5b8:	17fffff9 	b	59c <strchr+0x4>

00000000000005bc <gets>:

char*
gets(char *buf, int max)
{
 5bc:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 5c0:	910003fd 	mov	x29, sp
 5c4:	a90153f3 	stp	x19, x20, [sp, #16]
 5c8:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 5cc:	d2800014 	mov	x20, #0x0                   	// #0
{
 5d0:	f9001bf7 	str	x23, [sp, #48]
 5d4:	2a0103f7 	mov	w23, w1
 5d8:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 5dc:	11000695 	add	w21, w20, #0x1
 5e0:	2a1403f6 	mov	w22, w20
 5e4:	6b1702bf 	cmp	w21, w23
 5e8:	540000ea 	b.ge	604 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 5ec:	91013fe1 	add	x1, sp, #0x4f
 5f0:	52800022 	mov	w2, #0x1                   	// #1
 5f4:	52800000 	mov	w0, #0x0                   	// #0
 5f8:	94000063 	bl	784 <read>
    if(cc < 1)
 5fc:	7100001f 	cmp	w0, #0x0
 600:	5400012c 	b.gt	624 <gets+0x68>
  for(i=0; i+1 < max; ){
 604:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 608:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 60c:	aa1303e0 	mov	x0, x19
 610:	f9401bf7 	ldr	x23, [sp, #48]
 614:	a94153f3 	ldp	x19, x20, [sp, #16]
 618:	a9425bf5 	ldp	x21, x22, [sp, #32]
 61c:	a8c57bfd 	ldp	x29, x30, [sp], #80
 620:	d65f03c0 	ret
    buf[i++] = c;
 624:	39413fe0 	ldrb	w0, [sp, #79]
 628:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 62c:	91000694 	add	x20, x20, #0x1
 630:	7100281f 	cmp	w0, #0xa
 634:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 638:	54fffd21 	b.ne	5dc <gets+0x20>  // b.any
 63c:	17fffff3 	b	608 <gets+0x4c>

0000000000000640 <stat>:

int
stat(const char *n, struct stat *st)
{
 640:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 644:	910003fd 	mov	x29, sp
 648:	a90153f3 	stp	x19, x20, [sp, #16]
 64c:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 650:	52800001 	mov	w1, #0x0                   	// #0
 654:	9400005b 	bl	7c0 <open>
  if(fd < 0)
 658:	37f80160 	tbnz	w0, #31, 684 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 65c:	aa1303e1 	mov	x1, x19
 660:	2a0003f4 	mov	w20, w0
 664:	94000060 	bl	7e4 <fstat>
 668:	2a0003f3 	mov	w19, w0
  close(fd);
 66c:	2a1403e0 	mov	w0, w20
 670:	9400004b 	bl	79c <close>
  return r;
}
 674:	2a1303e0 	mov	w0, w19
 678:	a94153f3 	ldp	x19, x20, [sp, #16]
 67c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 680:	d65f03c0 	ret
    return -1;
 684:	12800013 	mov	w19, #0xffffffff            	// #-1
 688:	17fffffb 	b	674 <stat+0x34>

000000000000068c <atoi>:

int
atoi(const char *s)
{
 68c:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 690:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 694:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 698:	39400043 	ldrb	w3, [x2]
 69c:	5100c061 	sub	w1, w3, #0x30
 6a0:	12001c21 	and	w1, w1, #0xff
 6a4:	7100243f 	cmp	w1, #0x9
 6a8:	54000049 	b.ls	6b0 <atoi+0x24>  // b.plast
  return n;
}
 6ac:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 6b0:	1b040c01 	madd	w1, w0, w4, w3
 6b4:	91000442 	add	x2, x2, #0x1
 6b8:	5100c020 	sub	w0, w1, #0x30
 6bc:	17fffff7 	b	698 <atoi+0xc>

00000000000006c0 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 6c0:	eb01001f 	cmp	x0, x1
 6c4:	54000263 	b.cc	710 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 6c8:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 6cc:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 6d0:	d2800003 	mov	x3, #0x0                   	// #0
 6d4:	d1000463 	sub	x3, x3, #0x1
 6d8:	11000464 	add	w4, w3, #0x1
 6dc:	0b020084 	add	w4, w4, w2
 6e0:	7100009f 	cmp	w4, #0x0
 6e4:	5400014d 	b.le	70c <memmove+0x4c>
      *--dst = *--src;
 6e8:	38636824 	ldrb	w4, [x1, x3]
 6ec:	382368a4 	strb	w4, [x5, x3]
 6f0:	17fffff9 	b	6d4 <memmove+0x14>
      *dst++ = *src++;
 6f4:	38636824 	ldrb	w4, [x1, x3]
 6f8:	38236804 	strb	w4, [x0, x3]
 6fc:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 700:	4b030044 	sub	w4, w2, w3
 704:	7100009f 	cmp	w4, #0x0
 708:	54ffff6c 	b.gt	6f4 <memmove+0x34>
  }
  return vdst;
}
 70c:	d65f03c0 	ret
 710:	d2800003 	mov	x3, #0x0                   	// #0
 714:	17fffffb 	b	700 <memmove+0x40>

0000000000000718 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 718:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 71c:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 720:	d2800004 	mov	x4, #0x0                   	// #0
 724:	eb02009f 	cmp	x4, x2
 728:	54000061 	b.ne	734 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 72c:	52800000 	mov	w0, #0x0                   	// #0
 730:	14000007 	b	74c <memcmp+0x34>
    if (*p1 != *p2) {
 734:	38646803 	ldrb	w3, [x0, x4]
 738:	91000484 	add	x4, x4, #0x1
 73c:	38646825 	ldrb	w5, [x1, x4]
 740:	6b05007f 	cmp	w3, w5
 744:	54ffff00 	b.eq	724 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 748:	4b050060 	sub	w0, w3, w5
}
 74c:	d65f03c0 	ret

0000000000000750 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 750:	17ffffdc 	b	6c0 <memmove>

0000000000000754 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 754:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 758:	d4000001 	svc	#0x0
 ret
 75c:	d65f03c0 	ret

0000000000000760 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 760:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 764:	d4000001 	svc	#0x0
 ret
 768:	d65f03c0 	ret

000000000000076c <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 76c:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 770:	d4000001 	svc	#0x0
 ret
 774:	d65f03c0 	ret

0000000000000778 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 778:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 77c:	d4000001 	svc	#0x0
 ret
 780:	d65f03c0 	ret

0000000000000784 <read>:
.global read
read:
 mov x7, #SYS_read
 784:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 788:	d4000001 	svc	#0x0
 ret
 78c:	d65f03c0 	ret

0000000000000790 <write>:
.global write
write:
 mov x7, #SYS_write
 790:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 794:	d4000001 	svc	#0x0
 ret
 798:	d65f03c0 	ret

000000000000079c <close>:
.global close
close:
 mov x7, #SYS_close
 79c:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 7a0:	d4000001 	svc	#0x0
 ret
 7a4:	d65f03c0 	ret

00000000000007a8 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 7a8:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 7ac:	d4000001 	svc	#0x0
 ret
 7b0:	d65f03c0 	ret

00000000000007b4 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 7b4:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 7b8:	d4000001 	svc	#0x0
 ret
 7bc:	d65f03c0 	ret

00000000000007c0 <open>:
.global open
open:
 mov x7, #SYS_open
 7c0:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 7c4:	d4000001 	svc	#0x0
 ret
 7c8:	d65f03c0 	ret

00000000000007cc <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 7cc:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 7d0:	d4000001 	svc	#0x0
 ret
 7d4:	d65f03c0 	ret

00000000000007d8 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 7d8:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 7dc:	d4000001 	svc	#0x0
 ret
 7e0:	d65f03c0 	ret

00000000000007e4 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 7e4:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 7e8:	d4000001 	svc	#0x0
 ret
 7ec:	d65f03c0 	ret

00000000000007f0 <link>:
.global link
link:
 mov x7, #SYS_link
 7f0:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 7f4:	d4000001 	svc	#0x0
 ret
 7f8:	d65f03c0 	ret

00000000000007fc <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 7fc:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 800:	d4000001 	svc	#0x0
 ret
 804:	d65f03c0 	ret

0000000000000808 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 808:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 80c:	d4000001 	svc	#0x0
 ret
 810:	d65f03c0 	ret

0000000000000814 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 814:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 818:	d4000001 	svc	#0x0
 ret
 81c:	d65f03c0 	ret

0000000000000820 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 820:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 824:	d4000001 	svc	#0x0
 ret
 828:	d65f03c0 	ret

000000000000082c <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 82c:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 830:	d4000001 	svc	#0x0
 ret
 834:	d65f03c0 	ret

0000000000000838 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 838:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 83c:	d4000001 	svc	#0x0
 ret
 840:	d65f03c0 	ret

0000000000000844 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 844:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 848:	d4000001 	svc	#0x0
 ret
 84c:	d65f03c0 	ret

0000000000000850 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 850:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 854:	d4000001 	svc	#0x0
 ret
 858:	d65f03c0 	ret

000000000000085c <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 85c:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 860:	d4000001 	svc	#0x0
 ret
 864:	d65f03c0 	ret

0000000000000868 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 868:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 86c:	d4000001 	svc	#0x0
 ret
 870:	d65f03c0 	ret

0000000000000874 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 874:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 878:	d4000001 	svc	#0x0
 ret
 87c:	d65f03c0 	ret

0000000000000880 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 880:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 884:	d4000001 	svc	#0x0
 ret
 888:	d65f03c0 	ret

000000000000088c <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 88c:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 890:	d4000001 	svc	#0x0
 ret
 894:	d65f03c0 	ret

0000000000000898 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 898:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 89c:	d4000001 	svc	#0x0
 ret
 8a0:	d65f03c0 	ret

00000000000008a4 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 8a4:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 8a8:	d4000001 	svc	#0x0
 ret
 8ac:	d65f03c0 	ret

00000000000008b0 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 8b0:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 8b4:	d4000001 	svc	#0x0
 ret
 8b8:	d65f03c0 	ret

00000000000008bc <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 8bc:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 8c0:	d4000001 	svc	#0x0
 ret
 8c4:	d65f03c0 	ret

00000000000008c8 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 8c8:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 8cc:	d4000001 	svc	#0x0
 ret
 8d0:	d65f03c0 	ret

00000000000008d4 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 8d4:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 8d8:	d4000001 	svc	#0x0
 ret
 8dc:	d65f03c0 	ret

00000000000008e0 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 8e0:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 8e4:	d4000001 	svc	#0x0
 ret
 8e8:	d65f03c0 	ret

00000000000008ec <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 8ec:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 8f0:	d4000001 	svc	#0x0
 ret
 8f4:	d65f03c0 	ret

00000000000008f8 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 8f8:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 8fc:	d4000001 	svc	#0x0
 ret
 900:	d65f03c0 	ret

0000000000000904 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 904:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 908:	d4000001 	svc	#0x0
 ret
 90c:	d65f03c0 	ret

0000000000000910 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 910:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 914:	d4000001 	svc	#0x0
 ret
 918:	d65f03c0 	ret

000000000000091c <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 91c:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 920:	d4000001 	svc	#0x0
 ret
 924:	d65f03c0 	ret

0000000000000928 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 928:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 92c:	d4000001 	svc	#0x0
 ret
 930:	d65f03c0 	ret

0000000000000934 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 934:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 938:	d4000001 	svc	#0x0
 ret
 93c:	d65f03c0 	ret

0000000000000940 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 940:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 944:	d4000001 	svc	#0x0
 ret
 948:	d65f03c0 	ret

000000000000094c <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 94c:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 950:	d4000001 	svc	#0x0
 ret
 954:	d65f03c0 	ret

0000000000000958 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 958:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 95c:	d4000001 	svc	#0x0
 ret
 960:	d65f03c0 	ret

0000000000000964 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 964:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 968:	d4000001 	svc	#0x0
 ret
 96c:	d65f03c0 	ret

0000000000000970 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 970:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 974:	d4000001 	svc	#0x0
 ret
 978:	d65f03c0 	ret

000000000000097c <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 97c:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 980:	d4000001 	svc	#0x0
 ret
 984:	d65f03c0 	ret

0000000000000988 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 988:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 98c:	d4000001 	svc	#0x0
 ret
 990:	d65f03c0 	ret

0000000000000994 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 994:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 998:	d4000001 	svc	#0x0
 ret
 99c:	d65f03c0 	ret

00000000000009a0 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 9a0:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 9a4:	d4000001 	svc	#0x0
 ret
 9a8:	d65f03c0 	ret

00000000000009ac <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 9ac:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 9b0:	d4000001 	svc	#0x0
 ret
 9b4:	d65f03c0 	ret

00000000000009b8 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 9b8:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 9bc:	d4000001 	svc	#0x0
 ret
 9c0:	d65f03c0 	ret

00000000000009c4 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 9c4:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 9c8:	d4000001 	svc	#0x0
 ret
 9cc:	d65f03c0 	ret

00000000000009d0 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 9d0:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 9d4:	d4000001 	svc	#0x0
 ret
 9d8:	d65f03c0 	ret

00000000000009dc <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 9dc:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 9e0:	d4000001 	svc	#0x0
 ret
 9e4:	d65f03c0 	ret

00000000000009e8 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 9e8:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 9ec:	d4000001 	svc	#0x0
 ret
 9f0:	d65f03c0 	ret

00000000000009f4 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 9f4:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 9f8:	d4000001 	svc	#0x0
 ret
 9fc:	d65f03c0 	ret

0000000000000a00 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 a00:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 a04:	d4000001 	svc	#0x0
 ret
 a08:	d65f03c0 	ret

0000000000000a0c <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 a0c:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 a10:	d4000001 	svc	#0x0
 ret
 a14:	d65f03c0 	ret

0000000000000a18 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 a18:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 a1c:	d4000001 	svc	#0x0
 ret
 a20:	d65f03c0 	ret

0000000000000a24 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 a24:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 a28:	d4000001 	svc	#0x0
 ret
 a2c:	d65f03c0 	ret

0000000000000a30 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 a30:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 a34:	d4000001 	svc	#0x0
 ret
 a38:	d65f03c0 	ret

0000000000000a3c <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 a3c:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 a40:	d4000001 	svc	#0x0
 ret
 a44:	d65f03c0 	ret

0000000000000a48 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 a48:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 a4c:	d4000001 	svc	#0x0
 ret
 a50:	d65f03c0 	ret

0000000000000a54 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 a54:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 a58:	d4000001 	svc	#0x0
 ret
 a5c:	d65f03c0 	ret

0000000000000a60 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 a60:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 a64:	d4000001 	svc	#0x0
 ret
 a68:	d65f03c0 	ret

0000000000000a6c <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 a6c:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 a70:	d4000001 	svc	#0x0
 ret
 a74:	d65f03c0 	ret

0000000000000a78 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 a78:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 a7c:	d4000001 	svc	#0x0
 ret
 a80:	d65f03c0 	ret

0000000000000a84 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 a84:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 a88:	d4000001 	svc	#0x0
 ret
 a8c:	d65f03c0 	ret

0000000000000a90 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 a90:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 a94:	d4000001 	svc	#0x0
 ret
 a98:	d65f03c0 	ret

0000000000000a9c <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 a9c:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 aa0:	d4000001 	svc	#0x0
 ret
 aa4:	d65f03c0 	ret

0000000000000aa8 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 aa8:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 aac:	d4000001 	svc	#0x0
 ret
 ab0:	d65f03c0 	ret

0000000000000ab4 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 ab4:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 ab8:	d4000001 	svc	#0x0
 ret
 abc:	d65f03c0 	ret

0000000000000ac0 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 ac0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 ac4:	52800022 	mov	w2, #0x1                   	// #1
{
 ac8:	910003fd 	mov	x29, sp
 acc:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 ad0:	91007fe1 	add	x1, sp, #0x1f
 ad4:	97ffff2f 	bl	790 <write>
 ad8:	7100041f 	cmp	w0, #0x1
}
 adc:	1a9f17e0 	cset	w0, eq	// eq = none
 ae0:	a8c27bfd 	ldp	x29, x30, [sp], #32
 ae4:	d65f03c0 	ret

0000000000000ae8 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 ae8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 aec:	910003fd 	mov	x29, sp
 af0:	a90153f3 	stp	x19, x20, [sp, #16]
 af4:	a9025bf5 	stp	x21, x22, [sp, #32]
 af8:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 afc:	6a417c7f 	tst	w3, w1, lsr #31
 b00:	54000300 	b.eq	b60 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 b04:	4b0103e1 	neg	w1, w1
    neg = 1;
 b08:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 b0c:	b0000003 	adrp	x3, 1000 <printf+0x130>
 b10:	91023863 	add	x3, x3, #0x8e
 b14:	9100c3f5 	add	x21, sp, #0x30
 b18:	d2800000 	mov	x0, #0x0                   	// #0
 b1c:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 b20:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 b24:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 b28:	2a0403e1 	mov	w1, w4
 b2c:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 b30:	38666866 	ldrb	w6, [x3, x6]
 b34:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 b38:	91000400 	add	x0, x0, #0x1
 b3c:	54ffff09 	b.ls	b1c <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 b40:	11000493 	add	w19, w4, #0x1
  if(neg)
 b44:	34000085 	cbz	w5, b54 <printint+0x6c>
    buf[i++] = '-';
 b48:	528005a0 	mov	w0, #0x2d                  	// #45
 b4c:	38334aa0 	strb	w0, [x21, w19, uxtw]
 b50:	11000893 	add	w19, w4, #0x2
 b54:	51000673 	sub	w19, w19, #0x1
 b58:	52800014 	mov	w20, #0x0                   	// #0
 b5c:	14000008 	b	b7c <printint+0x94>
  neg = 0;
 b60:	52800005 	mov	w5, #0x0                   	// #0
 b64:	17ffffea 	b	b0c <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 b68:	38736aa1 	ldrb	w1, [x21, x19]
 b6c:	2a1603e0 	mov	w0, w22
 b70:	d1000673 	sub	x19, x19, #0x1
 b74:	97ffffd3 	bl	ac0 <putc>
 b78:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 b7c:	3100067f 	cmn	w19, #0x1
 b80:	54ffff41 	b.ne	b68 <printint+0x80>  // b.any
  return written;
}
 b84:	a9425bf5 	ldp	x21, x22, [sp, #32]
 b88:	2a1403e0 	mov	w0, w20
 b8c:	a94153f3 	ldp	x19, x20, [sp, #16]
 b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
 b94:	d65f03c0 	ret

0000000000000b98 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 b98:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 b9c:	910003fd 	mov	x29, sp
 ba0:	a90153f3 	stp	x19, x20, [sp, #16]
 ba4:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 ba8:	52800015 	mov	w21, #0x0                   	// #0
{
 bac:	a90363f7 	stp	x23, x24, [sp, #48]
 bb0:	2a0003f7 	mov	w23, w0
 bb4:	a9046bf9 	stp	x25, x26, [sp, #64]
 bb8:	aa0103f9 	mov	x25, x1

  state = 0;
 bbc:	52800001 	mov	w1, #0x0                   	// #0
{
 bc0:	a90573fb 	stp	x27, x28, [sp, #80]
 bc4:	a9406053 	ldp	x19, x24, [x2]
 bc8:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 bcc:	39400320 	ldrb	w0, [x25]
 bd0:	35000120 	cbnz	w0, bf4 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 bd4:	2a1503e0 	mov	w0, w21
 bd8:	a94153f3 	ldp	x19, x20, [sp, #16]
 bdc:	a9425bf5 	ldp	x21, x22, [sp, #32]
 be0:	a94363f7 	ldp	x23, x24, [sp, #48]
 be4:	a9446bf9 	ldp	x25, x26, [sp, #64]
 be8:	a94573fb 	ldp	x27, x28, [sp, #80]
 bec:	a8c67bfd 	ldp	x29, x30, [sp], #96
 bf0:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 bf4:	2a0003f6 	mov	w22, w0
    if(state == 0){
 bf8:	35000101 	cbnz	w1, c18 <vprintf+0x80>
      if(c == '%'){
 bfc:	7100941f 	cmp	w0, #0x25
 c00:	54000ba0 	b.eq	d74 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 c04:	2a1603e1 	mov	w1, w22
 c08:	2a1703e0 	mov	w0, w23
 c0c:	97ffffad 	bl	ac0 <putc>
 c10:	0b0002b5 	add	w21, w21, w0
 c14:	14000057 	b	d70 <vprintf+0x1d8>
      if(c == 'd'){
 c18:	7101901f 	cmp	w0, #0x64
 c1c:	540002a1 	b.ne	c70 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 c20:	37f80174 	tbnz	w20, #31, c4c <vprintf+0xb4>
 c24:	91002e76 	add	x22, x19, #0xb
 c28:	2a1403fa 	mov	w26, w20
 c2c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c30:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 c34:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 c38:	b9400261 	ldr	w1, [x19]
 c3c:	2a1703e0 	mov	w0, w23
 c40:	97ffffaa 	bl	ae8 <printint>
        written += putc(fd, va_arg(ap, uint));
 c44:	0b0002b5 	add	w21, w21, w0
 c48:	14000048 	b	d68 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 c4c:	1100229a 	add	w26, w20, #0x8
 c50:	7100035f 	cmp	w26, #0x0
 c54:	5400008d 	b.le	c64 <vprintf+0xcc>
 c58:	91002e76 	add	x22, x19, #0xb
 c5c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c60:	17fffff4 	b	c30 <vprintf+0x98>
 c64:	aa1303f6 	mov	x22, x19
 c68:	8b34c313 	add	x19, x24, w20, sxtw
 c6c:	17fffff1 	b	c30 <vprintf+0x98>
      } else if(c == 'l') {
 c70:	7101b01f 	cmp	w0, #0x6c
 c74:	54000201 	b.ne	cb4 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 c78:	37f800d4 	tbnz	w20, #31, c90 <vprintf+0xf8>
 c7c:	91003e76 	add	x22, x19, #0xf
 c80:	2a1403fa 	mov	w26, w20
 c84:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c88:	52800003 	mov	w3, #0x0                   	// #0
 c8c:	17ffffea 	b	c34 <vprintf+0x9c>
 c90:	1100229a 	add	w26, w20, #0x8
 c94:	7100035f 	cmp	w26, #0x0
 c98:	5400008d 	b.le	ca8 <vprintf+0x110>
 c9c:	91003e76 	add	x22, x19, #0xf
 ca0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ca4:	17fffff9 	b	c88 <vprintf+0xf0>
 ca8:	aa1303f6 	mov	x22, x19
 cac:	8b34c313 	add	x19, x24, w20, sxtw
 cb0:	17fffff6 	b	c88 <vprintf+0xf0>
      } else if(c == 'x') {
 cb4:	7101e01f 	cmp	w0, #0x78
 cb8:	54000221 	b.ne	cfc <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 cbc:	37f800f4 	tbnz	w20, #31, cd8 <vprintf+0x140>
 cc0:	91002e76 	add	x22, x19, #0xb
 cc4:	2a1403fa 	mov	w26, w20
 cc8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ccc:	52800003 	mov	w3, #0x0                   	// #0
 cd0:	52800202 	mov	w2, #0x10                  	// #16
 cd4:	17ffffd9 	b	c38 <vprintf+0xa0>
 cd8:	1100229a 	add	w26, w20, #0x8
 cdc:	7100035f 	cmp	w26, #0x0
 ce0:	5400008d 	b.le	cf0 <vprintf+0x158>
 ce4:	91002e76 	add	x22, x19, #0xb
 ce8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cec:	17fffff8 	b	ccc <vprintf+0x134>
 cf0:	aa1303f6 	mov	x22, x19
 cf4:	8b34c313 	add	x19, x24, w20, sxtw
 cf8:	17fffff5 	b	ccc <vprintf+0x134>
      } else if(c == 'p') {
 cfc:	7101c01f 	cmp	w0, #0x70
 d00:	54000521 	b.ne	da4 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 d04:	37f803f4 	tbnz	w20, #31, d80 <vprintf+0x1e8>
 d08:	91003e76 	add	x22, x19, #0xf
 d0c:	2a1403fa 	mov	w26, w20
 d10:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d14:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 d18:	52800601 	mov	w1, #0x30                  	// #48
 d1c:	2a1703e0 	mov	w0, w23
 d20:	97ffff68 	bl	ac0 <putc>
 d24:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d28:	b000001c 	adrp	x28, 1000 <printf+0x130>
 d2c:	91023b9c 	add	x28, x28, #0x8e
  written += putc(fd, 'x');
 d30:	2a1703e0 	mov	w0, w23
 d34:	52800f01 	mov	w1, #0x78                  	// #120
 d38:	97ffff62 	bl	ac0 <putc>
 d3c:	0b000273 	add	w19, w19, w0
 d40:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d44:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 d48:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d4c:	38606b81 	ldrb	w1, [x28, x0]
 d50:	2a1703e0 	mov	w0, w23
 d54:	97ffff5b 	bl	ac0 <putc>
 d58:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 d5c:	71000694 	subs	w20, w20, #0x1
 d60:	54ffff21 	b.ne	d44 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 d64:	0b1302b5 	add	w21, w21, w19
 d68:	2a1a03f4 	mov	w20, w26
 d6c:	aa1603f3 	mov	x19, x22
      state = 0;
 d70:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 d74:	91000739 	add	x25, x25, #0x1
  state = 0;
 d78:	2a1603e1 	mov	w1, w22
 d7c:	17ffff94 	b	bcc <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 d80:	1100229a 	add	w26, w20, #0x8
 d84:	7100035f 	cmp	w26, #0x0
 d88:	5400008d 	b.le	d98 <vprintf+0x200>
 d8c:	91003e76 	add	x22, x19, #0xf
 d90:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d94:	17ffffe0 	b	d14 <vprintf+0x17c>
 d98:	aa1303f6 	mov	x22, x19
 d9c:	8b34c313 	add	x19, x24, w20, sxtw
 da0:	17ffffdd 	b	d14 <vprintf+0x17c>
      } else if(c == 's'){
 da4:	7101cc1f 	cmp	w0, #0x73
 da8:	54000381 	b.ne	e18 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 dac:	37f80214 	tbnz	w20, #31, dec <vprintf+0x254>
 db0:	91003e61 	add	x1, x19, #0xf
 db4:	aa1303e0 	mov	x0, x19
 db8:	927df033 	and	x19, x1, #0xfffffffffffffff8
 dbc:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 dc0:	b0000000 	adrp	x0, 1000 <printf+0x130>
 dc4:	91021c00 	add	x0, x0, #0x87
 dc8:	f10002df 	cmp	x22, #0x0
 dcc:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 dd0:	394002c1 	ldrb	w1, [x22]
 dd4:	34fffce1 	cbz	w1, d70 <vprintf+0x1d8>
          written += putc(fd, *s);
 dd8:	2a1703e0 	mov	w0, w23
          s++;
 ddc:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 de0:	97ffff38 	bl	ac0 <putc>
 de4:	0b0002b5 	add	w21, w21, w0
          s++;
 de8:	17fffffa 	b	dd0 <vprintf+0x238>
        s = va_arg(ap, char*);
 dec:	11002281 	add	w1, w20, #0x8
 df0:	7100003f 	cmp	w1, #0x0
 df4:	540000cd 	b.le	e0c <vprintf+0x274>
 df8:	91003e62 	add	x2, x19, #0xf
 dfc:	aa1303e0 	mov	x0, x19
 e00:	2a0103f4 	mov	w20, w1
 e04:	927df053 	and	x19, x2, #0xfffffffffffffff8
 e08:	17ffffed 	b	dbc <vprintf+0x224>
 e0c:	8b34c300 	add	x0, x24, w20, sxtw
 e10:	2a0103f4 	mov	w20, w1
 e14:	17ffffea 	b	dbc <vprintf+0x224>
      } else if(c == 'c'){
 e18:	71018c1f 	cmp	w0, #0x63
 e1c:	54000241 	b.ne	e64 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 e20:	37f80114 	tbnz	w20, #31, e40 <vprintf+0x2a8>
 e24:	91002e76 	add	x22, x19, #0xb
 e28:	2a1403fa 	mov	w26, w20
 e2c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 e30:	39400261 	ldrb	w1, [x19]
 e34:	2a1703e0 	mov	w0, w23
 e38:	97ffff22 	bl	ac0 <putc>
 e3c:	17ffff82 	b	c44 <vprintf+0xac>
 e40:	1100229a 	add	w26, w20, #0x8
 e44:	7100035f 	cmp	w26, #0x0
 e48:	5400008d 	b.le	e58 <vprintf+0x2c0>
 e4c:	91002e76 	add	x22, x19, #0xb
 e50:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 e54:	17fffff7 	b	e30 <vprintf+0x298>
 e58:	aa1303f6 	mov	x22, x19
 e5c:	8b34c313 	add	x19, x24, w20, sxtw
 e60:	17fffff4 	b	e30 <vprintf+0x298>
      } else if(c == '%'){
 e64:	7100941f 	cmp	w0, #0x25
 e68:	54ffece0 	b.eq	c04 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 e6c:	2a1703e0 	mov	w0, w23
 e70:	528004a1 	mov	w1, #0x25                  	// #37
 e74:	97ffff13 	bl	ac0 <putc>
 e78:	0b0002b5 	add	w21, w21, w0
 e7c:	17ffff62 	b	c04 <vprintf+0x6c>

0000000000000e80 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 e80:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 e84:	910003fd 	mov	x29, sp
 e88:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 e8c:	910203e2 	add	x2, sp, #0x80
 e90:	a9030be2 	stp	x2, x2, [sp, #48]
 e94:	910143e2 	add	x2, sp, #0x50
 e98:	f90023e2 	str	x2, [sp, #64]
 e9c:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 ea0:	b9004be2 	str	w2, [sp, #72]
 ea4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 ea8:	a9430fe2 	ldp	x2, x3, [sp, #48]
 eac:	a9010fe2 	stp	x2, x3, [sp, #16]
 eb0:	a9440fe2 	ldp	x2, x3, [sp, #64]
 eb4:	a9020fe2 	stp	x2, x3, [sp, #32]
 eb8:	910043e2 	add	x2, sp, #0x10
{
 ebc:	a90617e4 	stp	x4, x5, [sp, #96]
 ec0:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 ec4:	97ffff35 	bl	b98 <vprintf>
  va_end(ap);
  return result;
}
 ec8:	a8c87bfd 	ldp	x29, x30, [sp], #128
 ecc:	d65f03c0 	ret

0000000000000ed0 <printf>:

int
printf(const char *fmt, ...)
{
 ed0:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 ed4:	910003fd 	mov	x29, sp
 ed8:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 edc:	910243e1 	add	x1, sp, #0x90
 ee0:	a90307e1 	stp	x1, x1, [sp, #48]
 ee4:	910143e1 	add	x1, sp, #0x50
 ee8:	f90023e1 	str	x1, [sp, #64]
 eec:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 ef0:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 ef4:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 ef8:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 efc:	52800020 	mov	w0, #0x1                   	// #1
{
 f00:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 f04:	a9430fe2 	ldp	x2, x3, [sp, #48]
 f08:	a9010fe2 	stp	x2, x3, [sp, #16]
 f0c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 f10:	a9020fe2 	stp	x2, x3, [sp, #32]
 f14:	910043e2 	add	x2, sp, #0x10
{
 f18:	a9079be5 	stp	x5, x6, [sp, #120]
 f1c:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 f20:	97ffff1e 	bl	b98 <vprintf>
  va_end(ap);
  return result;
}
 f24:	a8c97bfd 	ldp	x29, x30, [sp], #144
 f28:	d65f03c0 	ret
