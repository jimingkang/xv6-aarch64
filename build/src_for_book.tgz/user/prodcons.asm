
user/_prodcons:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  return value;
}

int
main(void)
{
   0:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
static inline int mutex_init(mutex_t *m) { return (*m = sync_create(SYNC_MUTEX, 1)) < 0 ? -1 : 0; }
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
static inline int mutex_destroy(mutex_t *m) { return sync_destroy(*m); }

static inline int sem_init(semaphore_t *s, int value) { return (*s = sync_create(SYNC_SEM, value)) < 0 ? -1 : 0; }
   4:	52800081 	mov	w1, #0x4                   	// #4
   8:	52800040 	mov	w0, #0x2                   	// #2
   c:	910003fd 	mov	x29, sp
  10:	a90153f3 	stp	x19, x20, [sp, #16]
  14:	a9025bf5 	stp	x21, x22, [sp, #32]
  18:	a90363f7 	stp	x23, x24, [sp, #48]
  1c:	a9046bf9 	stp	x25, x26, [sp, #64]
  20:	a90573fb 	stp	x27, x28, [sp, #80]
  24:	940000df 	bl	3a0 <sync_create>
  28:	36f800c0 	tbz	w0, #31, 40 <main+0x40>
  struct shared_queue q;
  int i, pid;

  if(queue_init(&q) < 0){
    printf("prodcons: initialization failed\n");
  2c:	90000000 	adrp	x0, 0 <main>
  30:	91296000 	add	x0, x0, #0xa58
    exit(1);
  }

  pid = fork();
  if(pid < 0){
    printf("prodcons: fork failed\n");
  34:	94000272 	bl	9fc <printf>
    exit(1);
  38:	52800020 	mov	w0, #0x1                   	// #1
  3c:	94000094 	bl	28c <exit>
  40:	2a0003f4 	mov	w20, w0
  44:	52800001 	mov	w1, #0x0                   	// #0
  48:	52800040 	mov	w0, #0x2                   	// #2
  4c:	940000d5 	bl	3a0 <sync_create>
  50:	2a0003f5 	mov	w21, w0
  54:	37fffec0 	tbnz	w0, #31, 2c <main+0x2c>
static inline int mutex_init(mutex_t *m) { return (*m = sync_create(SYNC_MUTEX, 1)) < 0 ? -1 : 0; }
  58:	52800021 	mov	w1, #0x1                   	// #1
  5c:	2a0103e0 	mov	w0, w1
  60:	940000d0 	bl	3a0 <sync_create>
  64:	2a0003f3 	mov	w19, w0
  68:	37fffe20 	tbnz	w0, #31, 2c <main+0x2c>
static inline int event_notify(event_t *e) { return sync_signal(*e, 1); }
static inline int event_signal(event_t *e) { return sync_signal(*e, 1); }
static inline int event_reset(event_t *e) { return sync_reset(*e); }
static inline int event_destroy(event_t *e) { return sync_destroy(*e); }

static inline int katomic_init(katomic_t *a, int value) { return (*a = sync_create(SYNC_ATOMIC, value)) < 0 ? -1 : 0; }
  6c:	52800001 	mov	w1, #0x0                   	// #0
  70:	52800080 	mov	w0, #0x4                   	// #4
  74:	940000cb 	bl	3a0 <sync_create>
  78:	2a0003f6 	mov	w22, w0
  7c:	37fffd80 	tbnz	w0, #31, 2c <main+0x2c>
  80:	52800001 	mov	w1, #0x0                   	// #0
  84:	52800080 	mov	w0, #0x4                   	// #4
  88:	940000c6 	bl	3a0 <sync_create>
  8c:	2a0003f7 	mov	w23, w0
  90:	37fffce0 	tbnz	w0, #31, 2c <main+0x2c>
  94:	9101e3f9 	add	x25, sp, #0x78
  98:	d2800018 	mov	x24, #0x0                   	// #0
  9c:	52800001 	mov	w1, #0x0                   	// #0
  a0:	52800080 	mov	w0, #0x4                   	// #4
  a4:	940000bf 	bl	3a0 <sync_create>
  a8:	8b180b21 	add	x1, x25, x24, lsl #2
  ac:	b9001420 	str	w0, [x1, #20]
  b0:	37fffbe0 	tbnz	w0, #31, 2c <main+0x2c>
  for(i = 0; i < NBUF; i++)
  b4:	91000718 	add	x24, x24, #0x1
  b8:	f100131f 	cmp	x24, #0x4
  bc:	54ffff01 	b.ne	9c <main+0x9c>  // b.any
  pid = fork();
  c0:	94000070 	bl	280 <fork>
  if(pid < 0){
  c4:	36f80080 	tbz	w0, #31, d4 <main+0xd4>
    printf("prodcons: fork failed\n");
  c8:	90000000 	adrp	x0, 0 <main>
  cc:	9129e400 	add	x0, x0, #0xa79
  d0:	17ffffd9 	b	34 <main+0x34>
  }
  if(pid == 0){
  d4:	9101f3fa 	add	x26, sp, #0x7c
  d8:	35000560 	cbnz	w0, 184 <main+0x184>
    for(i = 1; i <= NITEM; i++){
      printf("producer: %d\n", i);
  dc:	90000019 	adrp	x25, 0 <main>
  e0:	912a4339 	add	x25, x25, #0xa90
    for(i = 1; i <= NITEM; i++){
  e4:	52800038 	mov	w24, #0x1                   	// #1
      printf("producer: %d\n", i);
  e8:	2a1803e1 	mov	w1, w24
  ec:	aa1903e0 	mov	x0, x25
  f0:	94000243 	bl	9fc <printf>
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
  f4:	2a1403e0 	mov	w0, w20
  f8:	940000ad 	bl	3ac <sync_wait>
  fc:	2a1303e0 	mov	w0, w19
 100:	940000ab 	bl	3ac <sync_wait>
static inline int katomic_load(katomic_t *a) { return sync_atomic(*a, ATOMIC_LOAD, 0, 0); }
 104:	52800003 	mov	w3, #0x0                   	// #0
 108:	52800002 	mov	w2, #0x0                   	// #0
 10c:	52800021 	mov	w1, #0x1                   	// #1
 110:	2a1603e0 	mov	w0, w22
 114:	940000af 	bl	3d0 <sync_atomic>
 118:	2a0003f7 	mov	w23, w0
static inline int katomic_store(katomic_t *a, int value) { return sync_atomic(*a, ATOMIC_STORE, value, 0); }
 11c:	8b20cb40 	add	x0, x26, w0, sxtw #2
 120:	2a1803e2 	mov	w2, w24
 124:	52800003 	mov	w3, #0x0                   	// #0
 128:	52800041 	mov	w1, #0x2                   	// #2
    for(i = 1; i <= NITEM; i++){
 12c:	11000718 	add	w24, w24, #0x1
 130:	b9401000 	ldr	w0, [x0, #16]
 134:	940000a7 	bl	3d0 <sync_atomic>
  katomic_store(&q->put, (pos + 1) % NBUF);
 138:	110006e1 	add	w1, w23, #0x1
 13c:	52800003 	mov	w3, #0x0                   	// #0
 140:	6b0103e2 	negs	w2, w1
 144:	12000421 	and	w1, w1, #0x3
 148:	12000442 	and	w2, w2, #0x3
 14c:	2a1603e0 	mov	w0, w22
 150:	5a824422 	csneg	w2, w1, w2, mi	// mi = first
 154:	52800041 	mov	w1, #0x2                   	// #2
 158:	9400009e 	bl	3d0 <sync_atomic>
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
 15c:	52800021 	mov	w1, #0x1                   	// #1
 160:	2a1303e0 	mov	w0, w19
 164:	94000095 	bl	3b8 <sync_signal>
 168:	2a1503e0 	mov	w0, w21
 16c:	52800021 	mov	w1, #0x1                   	// #1
 170:	94000092 	bl	3b8 <sync_signal>
    for(i = 1; i <= NITEM; i++){
 174:	71002f1f 	cmp	w24, #0xb
 178:	54fffb81 	b.ne	e8 <main+0xe8>  // b.any
  for(i = 0; i < NITEM; i++)
    printf("consumer: %d\n", consume(&q));
  wait(0);
  queue_destroy(&q);
  printf("prodcons: ok\n");
  exit(0);
 17c:	52800000 	mov	w0, #0x0                   	// #0
 180:	17ffffaf 	b	3c <main+0x3c>
    printf("consumer: %d\n", consume(&q));
 184:	90000018 	adrp	x24, 0 <main>
 188:	912a7b18 	add	x24, x24, #0xa9e
  if(pid == 0){
 18c:	5280015c 	mov	w28, #0xa                   	// #10
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
 190:	2a1503e0 	mov	w0, w21
 194:	94000086 	bl	3ac <sync_wait>
 198:	2a1303e0 	mov	w0, w19
 19c:	94000084 	bl	3ac <sync_wait>
static inline int katomic_load(katomic_t *a) { return sync_atomic(*a, ATOMIC_LOAD, 0, 0); }
 1a0:	52800003 	mov	w3, #0x0                   	// #0
 1a4:	52800002 	mov	w2, #0x0                   	// #0
 1a8:	52800021 	mov	w1, #0x1                   	// #1
 1ac:	2a1703e0 	mov	w0, w23
 1b0:	94000088 	bl	3d0 <sync_atomic>
 1b4:	2a0003fb 	mov	w27, w0
 1b8:	8b20cb40 	add	x0, x26, w0, sxtw #2
 1bc:	52800003 	mov	w3, #0x0                   	// #0
 1c0:	52800002 	mov	w2, #0x0                   	// #0
 1c4:	52800021 	mov	w1, #0x1                   	// #1
 1c8:	b9401000 	ldr	w0, [x0, #16]
 1cc:	94000081 	bl	3d0 <sync_atomic>
 1d0:	b9006fe0 	str	w0, [sp, #108]
  katomic_store(&q->get, (pos + 1) % NBUF);
 1d4:	11000761 	add	w1, w27, #0x1
static inline int katomic_store(katomic_t *a, int value) { return sync_atomic(*a, ATOMIC_STORE, value, 0); }
 1d8:	52800003 	mov	w3, #0x0                   	// #0
 1dc:	6b0103e2 	negs	w2, w1
 1e0:	12000421 	and	w1, w1, #0x3
 1e4:	12000442 	and	w2, w2, #0x3
 1e8:	2a1703e0 	mov	w0, w23
 1ec:	5a824422 	csneg	w2, w1, w2, mi	// mi = first
 1f0:	52800041 	mov	w1, #0x2                   	// #2
 1f4:	94000077 	bl	3d0 <sync_atomic>
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
 1f8:	52800021 	mov	w1, #0x1                   	// #1
 1fc:	2a1303e0 	mov	w0, w19
 200:	9400006e 	bl	3b8 <sync_signal>
 204:	52800021 	mov	w1, #0x1                   	// #1
 208:	2a1403e0 	mov	w0, w20
 20c:	9400006b 	bl	3b8 <sync_signal>
    printf("consumer: %d\n", consume(&q));
 210:	b9406fe1 	ldr	w1, [sp, #108]
 214:	aa1803e0 	mov	x0, x24
 218:	940001f9 	bl	9fc <printf>
  for(i = 0; i < NITEM; i++)
 21c:	7100079c 	subs	w28, w28, #0x1
 220:	54fffb81 	b.ne	190 <main+0x190>  // b.any
  wait(0);
 224:	d2800000 	mov	x0, #0x0                   	// #0
 228:	9400001c 	bl	298 <wait>
static inline int mutex_destroy(mutex_t *m) { return sync_destroy(*m); }
 22c:	2a1403e0 	mov	w0, w20
 230:	9400006b 	bl	3dc <sync_destroy>
 234:	2a1503e0 	mov	w0, w21
 238:	94000069 	bl	3dc <sync_destroy>
 23c:	2a1303e0 	mov	w0, w19
 240:	d2800013 	mov	x19, #0x0                   	// #0
 244:	94000066 	bl	3dc <sync_destroy>
 248:	2a1603e0 	mov	w0, w22
 24c:	94000064 	bl	3dc <sync_destroy>
 250:	2a1703e0 	mov	w0, w23
 254:	94000062 	bl	3dc <sync_destroy>
 258:	8b130b20 	add	x0, x25, x19, lsl #2
  for(i = 0; i < NBUF; i++)
 25c:	91000673 	add	x19, x19, #0x1
 260:	b9401400 	ldr	w0, [x0, #20]
 264:	9400005e 	bl	3dc <sync_destroy>
 268:	f100127f 	cmp	x19, #0x4
 26c:	54ffff61 	b.ne	258 <main+0x258>  // b.any
  printf("prodcons: ok\n");
 270:	90000000 	adrp	x0, 0 <main>
 274:	912ab000 	add	x0, x0, #0xaac
 278:	940001e1 	bl	9fc <printf>
 27c:	17ffffc0 	b	17c <main+0x17c>

0000000000000280 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 280:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 284:	d4000001 	svc	#0x0
 ret
 288:	d65f03c0 	ret

000000000000028c <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 28c:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 290:	d4000001 	svc	#0x0
 ret
 294:	d65f03c0 	ret

0000000000000298 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 298:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 29c:	d4000001 	svc	#0x0
 ret
 2a0:	d65f03c0 	ret

00000000000002a4 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 2a4:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 2a8:	d4000001 	svc	#0x0
 ret
 2ac:	d65f03c0 	ret

00000000000002b0 <read>:
.global read
read:
 mov x7, #SYS_read
 2b0:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 2b4:	d4000001 	svc	#0x0
 ret
 2b8:	d65f03c0 	ret

00000000000002bc <write>:
.global write
write:
 mov x7, #SYS_write
 2bc:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 2c0:	d4000001 	svc	#0x0
 ret
 2c4:	d65f03c0 	ret

00000000000002c8 <close>:
.global close
close:
 mov x7, #SYS_close
 2c8:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 2cc:	d4000001 	svc	#0x0
 ret
 2d0:	d65f03c0 	ret

00000000000002d4 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 2d4:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 2d8:	d4000001 	svc	#0x0
 ret
 2dc:	d65f03c0 	ret

00000000000002e0 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 2e0:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 2e4:	d4000001 	svc	#0x0
 ret
 2e8:	d65f03c0 	ret

00000000000002ec <open>:
.global open
open:
 mov x7, #SYS_open
 2ec:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 2f0:	d4000001 	svc	#0x0
 ret
 2f4:	d65f03c0 	ret

00000000000002f8 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 2f8:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 2fc:	d4000001 	svc	#0x0
 ret
 300:	d65f03c0 	ret

0000000000000304 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 304:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 308:	d4000001 	svc	#0x0
 ret
 30c:	d65f03c0 	ret

0000000000000310 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 310:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 314:	d4000001 	svc	#0x0
 ret
 318:	d65f03c0 	ret

000000000000031c <link>:
.global link
link:
 mov x7, #SYS_link
 31c:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 320:	d4000001 	svc	#0x0
 ret
 324:	d65f03c0 	ret

0000000000000328 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 328:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 32c:	d4000001 	svc	#0x0
 ret
 330:	d65f03c0 	ret

0000000000000334 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 334:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 338:	d4000001 	svc	#0x0
 ret
 33c:	d65f03c0 	ret

0000000000000340 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 340:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 344:	d4000001 	svc	#0x0
 ret
 348:	d65f03c0 	ret

000000000000034c <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 34c:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 350:	d4000001 	svc	#0x0
 ret
 354:	d65f03c0 	ret

0000000000000358 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 358:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 35c:	d4000001 	svc	#0x0
 ret
 360:	d65f03c0 	ret

0000000000000364 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 364:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 368:	d4000001 	svc	#0x0
 ret
 36c:	d65f03c0 	ret

0000000000000370 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 370:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 374:	d4000001 	svc	#0x0
 ret
 378:	d65f03c0 	ret

000000000000037c <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 37c:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 380:	d4000001 	svc	#0x0
 ret
 384:	d65f03c0 	ret

0000000000000388 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 388:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 38c:	d4000001 	svc	#0x0
 ret
 390:	d65f03c0 	ret

0000000000000394 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 394:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 398:	d4000001 	svc	#0x0
 ret
 39c:	d65f03c0 	ret

00000000000003a0 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 3a0:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 3a4:	d4000001 	svc	#0x0
 ret
 3a8:	d65f03c0 	ret

00000000000003ac <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 3ac:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 3b0:	d4000001 	svc	#0x0
 ret
 3b4:	d65f03c0 	ret

00000000000003b8 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 3b8:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 3bc:	d4000001 	svc	#0x0
 ret
 3c0:	d65f03c0 	ret

00000000000003c4 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 3c4:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 3c8:	d4000001 	svc	#0x0
 ret
 3cc:	d65f03c0 	ret

00000000000003d0 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 3d0:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 3d4:	d4000001 	svc	#0x0
 ret
 3d8:	d65f03c0 	ret

00000000000003dc <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 3dc:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 3e0:	d4000001 	svc	#0x0
 ret
 3e4:	d65f03c0 	ret

00000000000003e8 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 3e8:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 3ec:	d4000001 	svc	#0x0
 ret
 3f0:	d65f03c0 	ret

00000000000003f4 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 3f4:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 3f8:	d4000001 	svc	#0x0
 ret
 3fc:	d65f03c0 	ret

0000000000000400 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 400:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 404:	d4000001 	svc	#0x0
 ret
 408:	d65f03c0 	ret

000000000000040c <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 40c:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 410:	d4000001 	svc	#0x0
 ret
 414:	d65f03c0 	ret

0000000000000418 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 418:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 41c:	d4000001 	svc	#0x0
 ret
 420:	d65f03c0 	ret

0000000000000424 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 424:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 428:	d4000001 	svc	#0x0
 ret
 42c:	d65f03c0 	ret

0000000000000430 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 430:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 434:	d4000001 	svc	#0x0
 ret
 438:	d65f03c0 	ret

000000000000043c <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 43c:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 440:	d4000001 	svc	#0x0
 ret
 444:	d65f03c0 	ret

0000000000000448 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 448:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 44c:	d4000001 	svc	#0x0
 ret
 450:	d65f03c0 	ret

0000000000000454 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 454:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 458:	d4000001 	svc	#0x0
 ret
 45c:	d65f03c0 	ret

0000000000000460 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 460:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 464:	d4000001 	svc	#0x0
 ret
 468:	d65f03c0 	ret

000000000000046c <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 46c:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 470:	d4000001 	svc	#0x0
 ret
 474:	d65f03c0 	ret

0000000000000478 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 478:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 47c:	d4000001 	svc	#0x0
 ret
 480:	d65f03c0 	ret

0000000000000484 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 484:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 488:	d4000001 	svc	#0x0
 ret
 48c:	d65f03c0 	ret

0000000000000490 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 490:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 494:	d4000001 	svc	#0x0
 ret
 498:	d65f03c0 	ret

000000000000049c <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 49c:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 4a0:	d4000001 	svc	#0x0
 ret
 4a4:	d65f03c0 	ret

00000000000004a8 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 4a8:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 4ac:	d4000001 	svc	#0x0
 ret
 4b0:	d65f03c0 	ret

00000000000004b4 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 4b4:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 4b8:	d4000001 	svc	#0x0
 ret
 4bc:	d65f03c0 	ret

00000000000004c0 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 4c0:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 4c4:	d4000001 	svc	#0x0
 ret
 4c8:	d65f03c0 	ret

00000000000004cc <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 4cc:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 4d0:	d4000001 	svc	#0x0
 ret
 4d4:	d65f03c0 	ret

00000000000004d8 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 4d8:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 4dc:	d4000001 	svc	#0x0
 ret
 4e0:	d65f03c0 	ret

00000000000004e4 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 4e4:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 4e8:	d4000001 	svc	#0x0
 ret
 4ec:	d65f03c0 	ret

00000000000004f0 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 4f0:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 4f4:	d4000001 	svc	#0x0
 ret
 4f8:	d65f03c0 	ret

00000000000004fc <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 4fc:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 500:	d4000001 	svc	#0x0
 ret
 504:	d65f03c0 	ret

0000000000000508 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 508:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 50c:	d4000001 	svc	#0x0
 ret
 510:	d65f03c0 	ret

0000000000000514 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 514:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 518:	d4000001 	svc	#0x0
 ret
 51c:	d65f03c0 	ret

0000000000000520 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 520:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 524:	d4000001 	svc	#0x0
 ret
 528:	d65f03c0 	ret

000000000000052c <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 52c:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 530:	d4000001 	svc	#0x0
 ret
 534:	d65f03c0 	ret

0000000000000538 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 538:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 53c:	d4000001 	svc	#0x0
 ret
 540:	d65f03c0 	ret

0000000000000544 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 544:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 548:	d4000001 	svc	#0x0
 ret
 54c:	d65f03c0 	ret

0000000000000550 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 550:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 554:	d4000001 	svc	#0x0
 ret
 558:	d65f03c0 	ret

000000000000055c <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 55c:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 560:	d4000001 	svc	#0x0
 ret
 564:	d65f03c0 	ret

0000000000000568 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 568:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 56c:	d4000001 	svc	#0x0
 ret
 570:	d65f03c0 	ret

0000000000000574 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 574:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 578:	d4000001 	svc	#0x0
 ret
 57c:	d65f03c0 	ret

0000000000000580 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 580:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 584:	d4000001 	svc	#0x0
 ret
 588:	d65f03c0 	ret

000000000000058c <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 58c:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 590:	d4000001 	svc	#0x0
 ret
 594:	d65f03c0 	ret

0000000000000598 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 598:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 59c:	d4000001 	svc	#0x0
 ret
 5a0:	d65f03c0 	ret

00000000000005a4 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 5a4:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 5a8:	d4000001 	svc	#0x0
 ret
 5ac:	d65f03c0 	ret

00000000000005b0 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 5b0:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 5b4:	d4000001 	svc	#0x0
 ret
 5b8:	d65f03c0 	ret

00000000000005bc <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 5bc:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 5c0:	d4000001 	svc	#0x0
 ret
 5c4:	d65f03c0 	ret

00000000000005c8 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 5c8:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 5cc:	d4000001 	svc	#0x0
 ret
 5d0:	d65f03c0 	ret

00000000000005d4 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 5d4:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 5d8:	d4000001 	svc	#0x0
 ret
 5dc:	d65f03c0 	ret

00000000000005e0 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 5e0:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 5e4:	d4000001 	svc	#0x0
 ret
 5e8:	d65f03c0 	ret

00000000000005ec <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 5ec:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 5f0:	52800022 	mov	w2, #0x1                   	// #1
{
 5f4:	910003fd 	mov	x29, sp
 5f8:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 5fc:	91007fe1 	add	x1, sp, #0x1f
 600:	97ffff2f 	bl	2bc <write>
 604:	7100041f 	cmp	w0, #0x1
}
 608:	1a9f17e0 	cset	w0, eq	// eq = none
 60c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 610:	d65f03c0 	ret

0000000000000614 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 614:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 618:	910003fd 	mov	x29, sp
 61c:	a90153f3 	stp	x19, x20, [sp, #16]
 620:	a9025bf5 	stp	x21, x22, [sp, #32]
 624:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 628:	6a417c7f 	tst	w3, w1, lsr #31
 62c:	54000300 	b.eq	68c <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 630:	4b0103e1 	neg	w1, w1
    neg = 1;
 634:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 638:	90000003 	adrp	x3, 0 <main>
 63c:	912b0463 	add	x3, x3, #0xac1
 640:	9100c3f5 	add	x21, sp, #0x30
 644:	d2800000 	mov	x0, #0x0                   	// #0
 648:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 64c:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 650:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 654:	2a0403e1 	mov	w1, w4
 658:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 65c:	38666866 	ldrb	w6, [x3, x6]
 660:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 664:	91000400 	add	x0, x0, #0x1
 668:	54ffff09 	b.ls	648 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 66c:	11000493 	add	w19, w4, #0x1
  if(neg)
 670:	34000085 	cbz	w5, 680 <printint+0x6c>
    buf[i++] = '-';
 674:	528005a0 	mov	w0, #0x2d                  	// #45
 678:	38334aa0 	strb	w0, [x21, w19, uxtw]
 67c:	11000893 	add	w19, w4, #0x2
 680:	51000673 	sub	w19, w19, #0x1
 684:	52800014 	mov	w20, #0x0                   	// #0
 688:	14000008 	b	6a8 <printint+0x94>
  neg = 0;
 68c:	52800005 	mov	w5, #0x0                   	// #0
 690:	17ffffea 	b	638 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 694:	38736aa1 	ldrb	w1, [x21, x19]
 698:	2a1603e0 	mov	w0, w22
 69c:	d1000673 	sub	x19, x19, #0x1
 6a0:	97ffffd3 	bl	5ec <putc>
 6a4:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 6a8:	3100067f 	cmn	w19, #0x1
 6ac:	54ffff41 	b.ne	694 <printint+0x80>  // b.any
  return written;
}
 6b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
 6b4:	2a1403e0 	mov	w0, w20
 6b8:	a94153f3 	ldp	x19, x20, [sp, #16]
 6bc:	a8c47bfd 	ldp	x29, x30, [sp], #64
 6c0:	d65f03c0 	ret

00000000000006c4 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 6c4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 6c8:	910003fd 	mov	x29, sp
 6cc:	a90153f3 	stp	x19, x20, [sp, #16]
 6d0:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 6d4:	52800015 	mov	w21, #0x0                   	// #0
{
 6d8:	a90363f7 	stp	x23, x24, [sp, #48]
 6dc:	2a0003f7 	mov	w23, w0
 6e0:	a9046bf9 	stp	x25, x26, [sp, #64]
 6e4:	aa0103f9 	mov	x25, x1

  state = 0;
 6e8:	52800001 	mov	w1, #0x0                   	// #0
{
 6ec:	a90573fb 	stp	x27, x28, [sp, #80]
 6f0:	a9406053 	ldp	x19, x24, [x2]
 6f4:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 6f8:	39400320 	ldrb	w0, [x25]
 6fc:	35000120 	cbnz	w0, 720 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 700:	2a1503e0 	mov	w0, w21
 704:	a94153f3 	ldp	x19, x20, [sp, #16]
 708:	a9425bf5 	ldp	x21, x22, [sp, #32]
 70c:	a94363f7 	ldp	x23, x24, [sp, #48]
 710:	a9446bf9 	ldp	x25, x26, [sp, #64]
 714:	a94573fb 	ldp	x27, x28, [sp, #80]
 718:	a8c67bfd 	ldp	x29, x30, [sp], #96
 71c:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 720:	2a0003f6 	mov	w22, w0
    if(state == 0){
 724:	35000101 	cbnz	w1, 744 <vprintf+0x80>
      if(c == '%'){
 728:	7100941f 	cmp	w0, #0x25
 72c:	54000ba0 	b.eq	8a0 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 730:	2a1603e1 	mov	w1, w22
 734:	2a1703e0 	mov	w0, w23
 738:	97ffffad 	bl	5ec <putc>
 73c:	0b0002b5 	add	w21, w21, w0
 740:	14000057 	b	89c <vprintf+0x1d8>
      if(c == 'd'){
 744:	7101901f 	cmp	w0, #0x64
 748:	540002a1 	b.ne	79c <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 74c:	37f80174 	tbnz	w20, #31, 778 <vprintf+0xb4>
 750:	91002e76 	add	x22, x19, #0xb
 754:	2a1403fa 	mov	w26, w20
 758:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 75c:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 760:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 764:	b9400261 	ldr	w1, [x19]
 768:	2a1703e0 	mov	w0, w23
 76c:	97ffffaa 	bl	614 <printint>
        written += putc(fd, va_arg(ap, uint));
 770:	0b0002b5 	add	w21, w21, w0
 774:	14000048 	b	894 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 778:	1100229a 	add	w26, w20, #0x8
 77c:	7100035f 	cmp	w26, #0x0
 780:	5400008d 	b.le	790 <vprintf+0xcc>
 784:	91002e76 	add	x22, x19, #0xb
 788:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 78c:	17fffff4 	b	75c <vprintf+0x98>
 790:	aa1303f6 	mov	x22, x19
 794:	8b34c313 	add	x19, x24, w20, sxtw
 798:	17fffff1 	b	75c <vprintf+0x98>
      } else if(c == 'l') {
 79c:	7101b01f 	cmp	w0, #0x6c
 7a0:	54000201 	b.ne	7e0 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 7a4:	37f800d4 	tbnz	w20, #31, 7bc <vprintf+0xf8>
 7a8:	91003e76 	add	x22, x19, #0xf
 7ac:	2a1403fa 	mov	w26, w20
 7b0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 7b4:	52800003 	mov	w3, #0x0                   	// #0
 7b8:	17ffffea 	b	760 <vprintf+0x9c>
 7bc:	1100229a 	add	w26, w20, #0x8
 7c0:	7100035f 	cmp	w26, #0x0
 7c4:	5400008d 	b.le	7d4 <vprintf+0x110>
 7c8:	91003e76 	add	x22, x19, #0xf
 7cc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 7d0:	17fffff9 	b	7b4 <vprintf+0xf0>
 7d4:	aa1303f6 	mov	x22, x19
 7d8:	8b34c313 	add	x19, x24, w20, sxtw
 7dc:	17fffff6 	b	7b4 <vprintf+0xf0>
      } else if(c == 'x') {
 7e0:	7101e01f 	cmp	w0, #0x78
 7e4:	54000221 	b.ne	828 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 7e8:	37f800f4 	tbnz	w20, #31, 804 <vprintf+0x140>
 7ec:	91002e76 	add	x22, x19, #0xb
 7f0:	2a1403fa 	mov	w26, w20
 7f4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 7f8:	52800003 	mov	w3, #0x0                   	// #0
 7fc:	52800202 	mov	w2, #0x10                  	// #16
 800:	17ffffd9 	b	764 <vprintf+0xa0>
 804:	1100229a 	add	w26, w20, #0x8
 808:	7100035f 	cmp	w26, #0x0
 80c:	5400008d 	b.le	81c <vprintf+0x158>
 810:	91002e76 	add	x22, x19, #0xb
 814:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 818:	17fffff8 	b	7f8 <vprintf+0x134>
 81c:	aa1303f6 	mov	x22, x19
 820:	8b34c313 	add	x19, x24, w20, sxtw
 824:	17fffff5 	b	7f8 <vprintf+0x134>
      } else if(c == 'p') {
 828:	7101c01f 	cmp	w0, #0x70
 82c:	54000521 	b.ne	8d0 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 830:	37f803f4 	tbnz	w20, #31, 8ac <vprintf+0x1e8>
 834:	91003e76 	add	x22, x19, #0xf
 838:	2a1403fa 	mov	w26, w20
 83c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 840:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 844:	52800601 	mov	w1, #0x30                  	// #48
 848:	2a1703e0 	mov	w0, w23
 84c:	97ffff68 	bl	5ec <putc>
 850:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 854:	9000001c 	adrp	x28, 0 <main>
 858:	912b079c 	add	x28, x28, #0xac1
  written += putc(fd, 'x');
 85c:	2a1703e0 	mov	w0, w23
 860:	52800f01 	mov	w1, #0x78                  	// #120
 864:	97ffff62 	bl	5ec <putc>
 868:	0b000273 	add	w19, w19, w0
 86c:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 870:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 874:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 878:	38606b81 	ldrb	w1, [x28, x0]
 87c:	2a1703e0 	mov	w0, w23
 880:	97ffff5b 	bl	5ec <putc>
 884:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 888:	71000694 	subs	w20, w20, #0x1
 88c:	54ffff21 	b.ne	870 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 890:	0b1302b5 	add	w21, w21, w19
 894:	2a1a03f4 	mov	w20, w26
 898:	aa1603f3 	mov	x19, x22
      state = 0;
 89c:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 8a0:	91000739 	add	x25, x25, #0x1
  state = 0;
 8a4:	2a1603e1 	mov	w1, w22
 8a8:	17ffff94 	b	6f8 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 8ac:	1100229a 	add	w26, w20, #0x8
 8b0:	7100035f 	cmp	w26, #0x0
 8b4:	5400008d 	b.le	8c4 <vprintf+0x200>
 8b8:	91003e76 	add	x22, x19, #0xf
 8bc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8c0:	17ffffe0 	b	840 <vprintf+0x17c>
 8c4:	aa1303f6 	mov	x22, x19
 8c8:	8b34c313 	add	x19, x24, w20, sxtw
 8cc:	17ffffdd 	b	840 <vprintf+0x17c>
      } else if(c == 's'){
 8d0:	7101cc1f 	cmp	w0, #0x73
 8d4:	54000381 	b.ne	944 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 8d8:	37f80214 	tbnz	w20, #31, 918 <vprintf+0x254>
 8dc:	91003e61 	add	x1, x19, #0xf
 8e0:	aa1303e0 	mov	x0, x19
 8e4:	927df033 	and	x19, x1, #0xfffffffffffffff8
 8e8:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 8ec:	90000000 	adrp	x0, 0 <main>
 8f0:	912ae800 	add	x0, x0, #0xaba
 8f4:	f10002df 	cmp	x22, #0x0
 8f8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 8fc:	394002c1 	ldrb	w1, [x22]
 900:	34fffce1 	cbz	w1, 89c <vprintf+0x1d8>
          written += putc(fd, *s);
 904:	2a1703e0 	mov	w0, w23
          s++;
 908:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 90c:	97ffff38 	bl	5ec <putc>
 910:	0b0002b5 	add	w21, w21, w0
          s++;
 914:	17fffffa 	b	8fc <vprintf+0x238>
        s = va_arg(ap, char*);
 918:	11002281 	add	w1, w20, #0x8
 91c:	7100003f 	cmp	w1, #0x0
 920:	540000cd 	b.le	938 <vprintf+0x274>
 924:	91003e62 	add	x2, x19, #0xf
 928:	aa1303e0 	mov	x0, x19
 92c:	2a0103f4 	mov	w20, w1
 930:	927df053 	and	x19, x2, #0xfffffffffffffff8
 934:	17ffffed 	b	8e8 <vprintf+0x224>
 938:	8b34c300 	add	x0, x24, w20, sxtw
 93c:	2a0103f4 	mov	w20, w1
 940:	17ffffea 	b	8e8 <vprintf+0x224>
      } else if(c == 'c'){
 944:	71018c1f 	cmp	w0, #0x63
 948:	54000241 	b.ne	990 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 94c:	37f80114 	tbnz	w20, #31, 96c <vprintf+0x2a8>
 950:	91002e76 	add	x22, x19, #0xb
 954:	2a1403fa 	mov	w26, w20
 958:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 95c:	39400261 	ldrb	w1, [x19]
 960:	2a1703e0 	mov	w0, w23
 964:	97ffff22 	bl	5ec <putc>
 968:	17ffff82 	b	770 <vprintf+0xac>
 96c:	1100229a 	add	w26, w20, #0x8
 970:	7100035f 	cmp	w26, #0x0
 974:	5400008d 	b.le	984 <vprintf+0x2c0>
 978:	91002e76 	add	x22, x19, #0xb
 97c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 980:	17fffff7 	b	95c <vprintf+0x298>
 984:	aa1303f6 	mov	x22, x19
 988:	8b34c313 	add	x19, x24, w20, sxtw
 98c:	17fffff4 	b	95c <vprintf+0x298>
      } else if(c == '%'){
 990:	7100941f 	cmp	w0, #0x25
 994:	54ffece0 	b.eq	730 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 998:	2a1703e0 	mov	w0, w23
 99c:	528004a1 	mov	w1, #0x25                  	// #37
 9a0:	97ffff13 	bl	5ec <putc>
 9a4:	0b0002b5 	add	w21, w21, w0
 9a8:	17ffff62 	b	730 <vprintf+0x6c>

00000000000009ac <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 9ac:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 9b0:	910003fd 	mov	x29, sp
 9b4:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 9b8:	910203e2 	add	x2, sp, #0x80
 9bc:	a9030be2 	stp	x2, x2, [sp, #48]
 9c0:	910143e2 	add	x2, sp, #0x50
 9c4:	f90023e2 	str	x2, [sp, #64]
 9c8:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 9cc:	b9004be2 	str	w2, [sp, #72]
 9d0:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 9d4:	a9430fe2 	ldp	x2, x3, [sp, #48]
 9d8:	a9010fe2 	stp	x2, x3, [sp, #16]
 9dc:	a9440fe2 	ldp	x2, x3, [sp, #64]
 9e0:	a9020fe2 	stp	x2, x3, [sp, #32]
 9e4:	910043e2 	add	x2, sp, #0x10
{
 9e8:	a90617e4 	stp	x4, x5, [sp, #96]
 9ec:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 9f0:	97ffff35 	bl	6c4 <vprintf>
  va_end(ap);
  return result;
}
 9f4:	a8c87bfd 	ldp	x29, x30, [sp], #128
 9f8:	d65f03c0 	ret

00000000000009fc <printf>:

int
printf(const char *fmt, ...)
{
 9fc:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 a00:	910003fd 	mov	x29, sp
 a04:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 a08:	910243e1 	add	x1, sp, #0x90
 a0c:	a90307e1 	stp	x1, x1, [sp, #48]
 a10:	910143e1 	add	x1, sp, #0x50
 a14:	f90023e1 	str	x1, [sp, #64]
 a18:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 a1c:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 a20:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 a24:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 a28:	52800020 	mov	w0, #0x1                   	// #1
{
 a2c:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 a30:	a9430fe2 	ldp	x2, x3, [sp, #48]
 a34:	a9010fe2 	stp	x2, x3, [sp, #16]
 a38:	a9440fe2 	ldp	x2, x3, [sp, #64]
 a3c:	a9020fe2 	stp	x2, x3, [sp, #32]
 a40:	910043e2 	add	x2, sp, #0x10
{
 a44:	a9079be5 	stp	x5, x6, [sp, #120]
 a48:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 a4c:	97ffff1e 	bl	6c4 <vprintf>
  va_end(ap);
  return result;
}
 a50:	a8c97bfd 	ldp	x29, x30, [sp], #144
 a54:	d65f03c0 	ret
