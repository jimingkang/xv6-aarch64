
user/initcode.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <start>:
#include "syscall.h"

// exec(init, argv)
.global start
start:
        ldr x0, =init
   0:	580001c0 	ldr	x0, 38 <argv+0x10>
        ldr x1, =argv
   4:	580001e1 	ldr	x1, 40 <argv+0x18>
        mov x7, #SYS_exec
   8:	d28000e7 	mov	x7, #0x7                   	// #7
        svc #0
   c:	d4000001 	svc	#0x0

0000000000000010 <exit>:

// for(;;) exit();
exit:
        mov x7, #SYS_exit
  10:	d2800047 	mov	x7, #0x2                   	// #2
        svc #0
  14:	d4000001 	svc	#0x0
        b exit
  18:	17fffffe 	b	10 <exit>

000000000000001c <init>:
  1c:	696e692f 	.word	0x696e692f
  20:	0074      	.short	0x0074
  22:	0000      	.short	0x0000
  24:	d503201f 	nop

0000000000000028 <argv>:
	...
