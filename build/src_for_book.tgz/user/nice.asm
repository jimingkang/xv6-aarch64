
user/_nice:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
#include "user/user.h"
#include "user/schedutil.h"

int
main(int argc, char *argv[])
{
   0:	a9b47bfd 	stp	x29, x30, [sp, #-192]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
   c:	a9025bf5 	stp	x21, x22, [sp, #32]
  10:	2a0003f6 	mov	w22, w0
  14:	aa0103f5 	mov	x21, x1
  18:	a90363f7 	stp	x23, x24, [sp, #48]
  1c:	f90023f9 	str	x25, [sp, #64]
  int n = 10, i = 1;
  struct sched_info si;

  if(argc >= 3 && strcmp(argv[1], "-n") == 0){
  20:	7100081f 	cmp	w0, #0x2
  24:	5400084d 	b.le	12c <main+0x12c>
  28:	f94006a0 	ldr	x0, [x21, #8]
  2c:	90000001 	adrp	x1, 0 <main>
  30:	91350821 	add	x1, x1, #0xd42
  34:	940000ad 	bl	2e8 <strcmp>
  38:	2a0003f3 	mov	w19, w0
  3c:	35000a20 	cbnz	w0, 180 <main+0x180>
    if(!parse_num(argv[2], &n))
  40:	f9400aa0 	ldr	x0, [x21, #16]
static __attribute__((unused)) int
parse_num(const char *s, int *out)
{
  int neg = 0, v = 0, any = 0;

  if(*s == '-'){
  44:	39400001 	ldrb	w1, [x0]
  48:	7100b43f 	cmp	w1, #0x2d
  4c:	54000281 	b.ne	9c <main+0x9c>  // b.any
    neg = 1;
    s++;
  50:	91000400 	add	x0, x0, #0x1
    neg = 1;
  54:	52800023 	mov	w3, #0x1                   	// #1
  }
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
  58:	39400001 	ldrb	w1, [x0]
  5c:	7100c03f 	cmp	w1, #0x30
  60:	54000601 	b.ne	120 <main+0x120>  // b.any
  64:	39400401 	ldrb	w1, [x0, #1]
  68:	121a7821 	and	w1, w1, #0xffffffdf
  6c:	12001c21 	and	w1, w1, #0xff
  70:	7101603f 	cmp	w1, #0x58
  74:	54000561 	b.ne	120 <main+0x120>  // b.any
    for(s += 2; *s; s++, any = 1){
  78:	91000800 	add	x0, x0, #0x2
  int neg = 0, v = 0, any = 0;
  7c:	52800002 	mov	w2, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
  80:	39400001 	ldrb	w1, [x0]
  84:	35000101 	cbnz	w1, a4 <main+0xa4>
      if(*s < '0' || *s > '9')
        return 0;
      v = v * 10 + (*s - '0');
    }
  }
  if(!any)
  88:	34000e02 	cbz	w2, 248 <main+0x248>
    return 0;
  *out = neg ? -v : v;
  8c:	34000043 	cbz	w3, 94 <main+0x94>
  90:	4b1303f3 	neg	w19, w19
      goto usage;
    i = 3;
  94:	52800074 	mov	w20, #0x3                   	// #3
  98:	14000027 	b	134 <main+0x134>
  int neg = 0, v = 0, any = 0;
  9c:	52800003 	mov	w3, #0x0                   	// #0
  a0:	17ffffee 	b	58 <main+0x58>
      if(*s >= '0' && *s <= '9') d = *s - '0';
  a4:	5100c022 	sub	w2, w1, #0x30
  a8:	12001c44 	and	w4, w2, #0xff
  ac:	7100249f 	cmp	w4, #0x9
  b0:	540000c8 	b.hi	c8 <main+0xc8>  // b.pmore
  b4:	2a0203e1 	mov	w1, w2
      v = v * 16 + d;
  b8:	0b131033 	add	w19, w1, w19, lsl #4
    for(s += 2; *s; s++, any = 1){
  bc:	91000400 	add	x0, x0, #0x1
  c0:	52800022 	mov	w2, #0x1                   	// #1
  c4:	17ffffef 	b	80 <main+0x80>
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
  c8:	51018422 	sub	w2, w1, #0x61
  cc:	12001c42 	and	w2, w2, #0xff
  d0:	7100145f 	cmp	w2, #0x5
  d4:	54000068 	b.hi	e0 <main+0xe0>  // b.pmore
  d8:	51015c21 	sub	w1, w1, #0x57
  dc:	17fffff7 	b	b8 <main+0xb8>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
  e0:	51010422 	sub	w2, w1, #0x41
  e4:	12001c42 	and	w2, w2, #0xff
  e8:	7100145f 	cmp	w2, #0x5
  ec:	54000ae8 	b.hi	248 <main+0x248>  // b.pmore
  f0:	5100dc21 	sub	w1, w1, #0x37
  f4:	17fffff1 	b	b8 <main+0xb8>
      if(*s < '0' || *s > '9')
  f8:	5100c021 	sub	w1, w1, #0x30
  fc:	12001c22 	and	w2, w1, #0xff
 100:	7100245f 	cmp	w2, #0x9
 104:	54000a28 	b.hi	248 <main+0x248>  // b.pmore
      v = v * 10 + (*s - '0');
 108:	1b040673 	madd	w19, w19, w4, w1
    for(; *s; s++, any = 1){
 10c:	91000400 	add	x0, x0, #0x1
 110:	52800022 	mov	w2, #0x1                   	// #1
 114:	39400001 	ldrb	w1, [x0]
 118:	35ffff01 	cbnz	w1, f8 <main+0xf8>
 11c:	17ffffdb 	b	88 <main+0x88>
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 120:	52800002 	mov	w2, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 124:	52800144 	mov	w4, #0xa                   	// #10
 128:	17fffffb 	b	114 <main+0x114>
  int n = 10, i = 1;
 12c:	52800153 	mov	w19, #0xa                   	// #10
 130:	52800034 	mov	w20, #0x1                   	// #1
  }
  if(i >= argc)
 134:	6b16029f 	cmp	w20, w22
 138:	5400088a 	b.ge	248 <main+0x248>  // b.tcont
    goto usage;
  if(sched_getinfo(0, &si) < 0 || setnice(0, si.nice + n) < 0){
 13c:	910163e1 	add	x1, sp, #0x58
 140:	52800000 	mov	w0, #0x0                   	// #0
 144:	940001b9 	bl	828 <sched_getinfo>
 148:	37f800c0 	tbnz	w0, #31, 160 <main+0x160>
 14c:	b94067e1 	ldr	w1, [sp, #100]
 150:	52800000 	mov	w0, #0x0                   	// #0
 154:	0b010261 	add	w1, w19, w1
 158:	940001b7 	bl	834 <setnice>
 15c:	36f80180 	tbz	w0, #31, 18c <main+0x18c>
    fprintf(2, "nice: invalid nice value %d\n", si.nice + n);
 160:	b94067e2 	ldr	w2, [sp, #100]
 164:	90000001 	adrp	x1, 0 <main>
 168:	91351421 	add	x1, x1, #0xd45
 16c:	52800040 	mov	w0, #0x2                   	// #2
 170:	0b020262 	add	w2, w19, w2
 174:	940002c7 	bl	c90 <fprintf>
    exit(1);
  }
  exec_cmd(&argv[i]);
  fprintf(2, "nice: exec %s failed\n", argv[i]);
  exit(1);
 178:	52800020 	mov	w0, #0x1                   	// #1
 17c:	940000fd 	bl	570 <exit>
  int n = 10, i = 1;
 180:	52800153 	mov	w19, #0xa                   	// #10
 184:	52800034 	mov	w20, #0x1                   	// #1
 188:	17ffffed 	b	13c <main+0x13c>
  exec_cmd(&argv[i]);
 18c:	d37d0694 	ubfiz	x20, x20, #3, #2
 190:	8b1402b8 	add	x24, x21, x20
// exec() argv[0] the way sh does: as given if it has a '/', else /bin, then /.
static __attribute__((unused)) void
exec_cmd(char **argv)
{
  char path[64];
  char *name = argv[0];
 194:	f8746ab6 	ldr	x22, [x21, x20]
  int n;

  for(char *c = name; *c; c++)
 198:	aa1603e0 	mov	x0, x22
 19c:	39400001 	ldrb	w1, [x0]
 1a0:	350002e1 	cbnz	w1, 1fc <main+0x1fc>
 1a4:	90000002 	adrp	x2, 0 <main>
 1a8:	9134f042 	add	x2, x2, #0xd3c
 1ac:	910203f3 	add	x19, sp, #0x80
 1b0:	52800017 	mov	w23, #0x0                   	// #0
    if(*c == '/'){
      exec(name, argv);
      return;
    }
  for(int pass = 0; pass < 2; pass++){
    const char *prefix = pass == 0 ? "/bin/" : "/";
 1b4:	90000019 	adrp	x25, 0 <main>
    n = 0;
    for(const char *c = prefix; *c; c++)
 1b8:	d2800000 	mov	x0, #0x0                   	// #0
 1bc:	38606841 	ldrb	w1, [x2, x0]
 1c0:	35000381 	cbnz	w1, 230 <main+0x230>
 1c4:	2a0003e2 	mov	w2, w0
      path[n++] = *c;
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 1c8:	cb2042c0 	sub	x0, x22, w0, uxtw
 1cc:	38626801 	ldrb	w1, [x0, x2]
 1d0:	34000061 	cbz	w1, 1dc <main+0x1dc>
 1d4:	7100f85f 	cmp	w2, #0x3e
 1d8:	5400032d 	b.le	23c <main+0x23c>
      path[n++] = *c;
    path[n] = 0;
    exec(path, argv);
 1dc:	aa1803e1 	mov	x1, x24
 1e0:	aa1303e0 	mov	x0, x19
    path[n] = 0;
 1e4:	38224a7f 	strb	wzr, [x19, w2, uxtw]
    exec(path, argv);
 1e8:	940000f7 	bl	5c4 <exec>
    const char *prefix = pass == 0 ? "/bin/" : "/";
 1ec:	91350322 	add	x2, x25, #0xd40
  for(int pass = 0; pass < 2; pass++){
 1f0:	35000117 	cbnz	w23, 210 <main+0x210>
 1f4:	52800037 	mov	w23, #0x1                   	// #1
 1f8:	17fffff0 	b	1b8 <main+0x1b8>
    if(*c == '/'){
 1fc:	7100bc3f 	cmp	w1, #0x2f
 200:	54000141 	b.ne	228 <main+0x228>  // b.any
      exec(name, argv);
 204:	aa1803e1 	mov	x1, x24
 208:	aa1603e0 	mov	x0, x22
 20c:	940000ee 	bl	5c4 <exec>
  fprintf(2, "nice: exec %s failed\n", argv[i]);
 210:	f8746aa2 	ldr	x2, [x21, x20]
 214:	90000001 	adrp	x1, 0 <main>
 218:	91358821 	add	x1, x1, #0xd62
 21c:	52800040 	mov	w0, #0x2                   	// #2
 220:	9400029c 	bl	c90 <fprintf>
 224:	17ffffd5 	b	178 <main+0x178>
  for(char *c = name; *c; c++)
 228:	91000400 	add	x0, x0, #0x1
 22c:	17ffffdc 	b	19c <main+0x19c>
      path[n++] = *c;
 230:	38206a61 	strb	w1, [x19, x0]
    for(const char *c = prefix; *c; c++)
 234:	91000400 	add	x0, x0, #0x1
 238:	17ffffe1 	b	1bc <main+0x1bc>
      path[n++] = *c;
 23c:	38226a61 	strb	w1, [x19, x2]
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 240:	91000442 	add	x2, x2, #0x1
 244:	17ffffe2 	b	1cc <main+0x1cc>
usage:
  fprintf(2, "usage: nice [-n N] CMD [ARG...]\n");
 248:	90000001 	adrp	x1, 0 <main>
 24c:	9135e021 	add	x1, x1, #0xd78
 250:	52800040 	mov	w0, #0x2                   	// #2
 254:	9400028f 	bl	c90 <fprintf>
  exit(1);
 258:	17ffffc8 	b	178 <main+0x178>

000000000000025c <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 25c:	d2800002 	mov	x2, #0x0                   	// #0
 260:	38626823 	ldrb	w3, [x1, x2]
 264:	38226803 	strb	w3, [x0, x2]
 268:	91000442 	add	x2, x2, #0x1
 26c:	35ffffa3 	cbnz	w3, 260 <strcpy+0x4>
    ;
  return os;
}
 270:	d65f03c0 	ret

0000000000000274 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 274:	d2800003 	mov	x3, #0x0                   	// #0
 278:	4b030044 	sub	w4, w2, w3
 27c:	7100009f 	cmp	w4, #0x0
 280:	5400006d 	b.le	28c <strncpy+0x18>
 284:	38636825 	ldrb	w5, [x1, x3]
 288:	350000e5 	cbnz	w5, 2a4 <strncpy+0x30>
 28c:	8b030003 	add	x3, x0, x3
 290:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 294:	4b010082 	sub	w2, w4, w1
 298:	7100005f 	cmp	w2, #0x0
 29c:	540000ac 	b.gt	2b0 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 2a0:	d65f03c0 	ret
    *s++ = *t++;
 2a4:	38236805 	strb	w5, [x0, x3]
    n--;
 2a8:	91000463 	add	x3, x3, #0x1
 2ac:	17fffff3 	b	278 <strncpy+0x4>
    *s++ = 0;
 2b0:	3821687f 	strb	wzr, [x3, x1]
 2b4:	91000421 	add	x1, x1, #0x1
 2b8:	17fffff7 	b	294 <strncpy+0x20>

00000000000002bc <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 2bc:	aa0003e2 	mov	x2, x0
 2c0:	39400043 	ldrb	w3, [x2]
 2c4:	aa0203e4 	mov	x4, x2
    s++;
 2c8:	91000442 	add	x2, x2, #0x1
  while(*s)
 2cc:	35ffffa3 	cbnz	w3, 2c0 <strcat+0x4>
 2d0:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 2d4:	38626823 	ldrb	w3, [x1, x2]
 2d8:	38226883 	strb	w3, [x4, x2]
 2dc:	91000442 	add	x2, x2, #0x1
 2e0:	35ffffa3 	cbnz	w3, 2d4 <strcat+0x18>
    ;
  return os;
}
 2e4:	d65f03c0 	ret

00000000000002e8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 2e8:	d2800002 	mov	x2, #0x0                   	// #0
 2ec:	38626803 	ldrb	w3, [x0, x2]
 2f0:	38626824 	ldrb	w4, [x1, x2]
 2f4:	34000083 	cbz	w3, 304 <strcmp+0x1c>
 2f8:	91000442 	add	x2, x2, #0x1
 2fc:	6b04007f 	cmp	w3, w4
 300:	54ffff60 	b.eq	2ec <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 304:	4b040060 	sub	w0, w3, w4
 308:	d65f03c0 	ret

000000000000030c <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 30c:	340001c2 	cbz	w2, 344 <strncmp+0x38>
 310:	39400003 	ldrb	w3, [x0]
 314:	34000083 	cbz	w3, 324 <strncmp+0x18>
 318:	39400024 	ldrb	w4, [x1]
 31c:	6b03009f 	cmp	w4, w3
 320:	540000a0 	b.eq	334 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 324:	39400000 	ldrb	w0, [x0]
 328:	39400021 	ldrb	w1, [x1]
 32c:	4b010000 	sub	w0, w0, w1
}
 330:	d65f03c0 	ret
    n--, p++, q++;
 334:	51000442 	sub	w2, w2, #0x1
 338:	91000400 	add	x0, x0, #0x1
 33c:	91000421 	add	x1, x1, #0x1
 340:	17fffff3 	b	30c <strncmp>
    return 0;
 344:	52800000 	mov	w0, #0x0                   	// #0
 348:	17fffffa 	b	330 <strncmp+0x24>

000000000000034c <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 34c:	d1000402 	sub	x2, x0, #0x1
 350:	d2800001 	mov	x1, #0x0                   	// #0
 354:	aa0103e0 	mov	x0, x1
 358:	91000421 	add	x1, x1, #0x1
 35c:	38616843 	ldrb	w3, [x2, x1]
 360:	35ffffa3 	cbnz	w3, 354 <strlen+0x8>
    ;
  return n;
}
 364:	d65f03c0 	ret

0000000000000368 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 368:	d1000403 	sub	x3, x0, #0x1
 36c:	d2800002 	mov	x2, #0x0                   	// #0
 370:	2a0203e0 	mov	w0, w2
 374:	6b02003f 	cmp	w1, w2
 378:	54000089 	b.ls	388 <strnlen+0x20>  // b.plast
 37c:	91000442 	add	x2, x2, #0x1
 380:	38626864 	ldrb	w4, [x3, x2]
 384:	35ffff64 	cbnz	w4, 370 <strnlen+0x8>
    n++;
  return n;
}
 388:	d65f03c0 	ret

000000000000038c <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 38c:	d2800003 	mov	x3, #0x0                   	// #0
 390:	6b03005f 	cmp	w2, w3
 394:	54000048 	b.hi	39c <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 398:	d65f03c0 	ret
    cdst[i] = c;
 39c:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 3a0:	91000463 	add	x3, x3, #0x1
 3a4:	17fffffb 	b	390 <memset+0x4>

00000000000003a8 <strchr>:

char*
strchr(const char *s, char c)
{
 3a8:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 3ac:	39400002 	ldrb	w2, [x0]
 3b0:	35000062 	cbnz	w2, 3bc <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 3b4:	d2800000 	mov	x0, #0x0                   	// #0
}
 3b8:	d65f03c0 	ret
    if(*s == c)
 3bc:	6b01005f 	cmp	w2, w1
 3c0:	54ffffc0 	b.eq	3b8 <strchr+0x10>  // b.none
  for(; *s; s++)
 3c4:	91000400 	add	x0, x0, #0x1
 3c8:	17fffff9 	b	3ac <strchr+0x4>

00000000000003cc <gets>:

char*
gets(char *buf, int max)
{
 3cc:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 3d0:	910003fd 	mov	x29, sp
 3d4:	a90153f3 	stp	x19, x20, [sp, #16]
 3d8:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 3dc:	d2800014 	mov	x20, #0x0                   	// #0
{
 3e0:	f9001bf7 	str	x23, [sp, #48]
 3e4:	2a0103f7 	mov	w23, w1
 3e8:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 3ec:	11000695 	add	w21, w20, #0x1
 3f0:	2a1403f6 	mov	w22, w20
 3f4:	6b1702bf 	cmp	w21, w23
 3f8:	540000ea 	b.ge	414 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 3fc:	91013fe1 	add	x1, sp, #0x4f
 400:	52800022 	mov	w2, #0x1                   	// #1
 404:	52800000 	mov	w0, #0x0                   	// #0
 408:	94000063 	bl	594 <read>
    if(cc < 1)
 40c:	7100001f 	cmp	w0, #0x0
 410:	5400012c 	b.gt	434 <gets+0x68>
  for(i=0; i+1 < max; ){
 414:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 418:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 41c:	aa1303e0 	mov	x0, x19
 420:	f9401bf7 	ldr	x23, [sp, #48]
 424:	a94153f3 	ldp	x19, x20, [sp, #16]
 428:	a9425bf5 	ldp	x21, x22, [sp, #32]
 42c:	a8c57bfd 	ldp	x29, x30, [sp], #80
 430:	d65f03c0 	ret
    buf[i++] = c;
 434:	39413fe0 	ldrb	w0, [sp, #79]
 438:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 43c:	91000694 	add	x20, x20, #0x1
 440:	7100281f 	cmp	w0, #0xa
 444:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 448:	54fffd21 	b.ne	3ec <gets+0x20>  // b.any
 44c:	17fffff3 	b	418 <gets+0x4c>

0000000000000450 <stat>:

int
stat(const char *n, struct stat *st)
{
 450:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 454:	910003fd 	mov	x29, sp
 458:	a90153f3 	stp	x19, x20, [sp, #16]
 45c:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 460:	52800001 	mov	w1, #0x0                   	// #0
 464:	9400005b 	bl	5d0 <open>
  if(fd < 0)
 468:	37f80160 	tbnz	w0, #31, 494 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 46c:	aa1303e1 	mov	x1, x19
 470:	2a0003f4 	mov	w20, w0
 474:	94000060 	bl	5f4 <fstat>
 478:	2a0003f3 	mov	w19, w0
  close(fd);
 47c:	2a1403e0 	mov	w0, w20
 480:	9400004b 	bl	5ac <close>
  return r;
}
 484:	2a1303e0 	mov	w0, w19
 488:	a94153f3 	ldp	x19, x20, [sp, #16]
 48c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 490:	d65f03c0 	ret
    return -1;
 494:	12800013 	mov	w19, #0xffffffff            	// #-1
 498:	17fffffb 	b	484 <stat+0x34>

000000000000049c <atoi>:

int
atoi(const char *s)
{
 49c:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 4a0:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 4a4:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 4a8:	39400043 	ldrb	w3, [x2]
 4ac:	5100c061 	sub	w1, w3, #0x30
 4b0:	12001c21 	and	w1, w1, #0xff
 4b4:	7100243f 	cmp	w1, #0x9
 4b8:	54000049 	b.ls	4c0 <atoi+0x24>  // b.plast
  return n;
}
 4bc:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 4c0:	1b040c01 	madd	w1, w0, w4, w3
 4c4:	91000442 	add	x2, x2, #0x1
 4c8:	5100c020 	sub	w0, w1, #0x30
 4cc:	17fffff7 	b	4a8 <atoi+0xc>

00000000000004d0 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 4d0:	eb01001f 	cmp	x0, x1
 4d4:	54000263 	b.cc	520 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 4d8:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 4dc:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 4e0:	d2800003 	mov	x3, #0x0                   	// #0
 4e4:	d1000463 	sub	x3, x3, #0x1
 4e8:	11000464 	add	w4, w3, #0x1
 4ec:	0b020084 	add	w4, w4, w2
 4f0:	7100009f 	cmp	w4, #0x0
 4f4:	5400014d 	b.le	51c <memmove+0x4c>
      *--dst = *--src;
 4f8:	38636824 	ldrb	w4, [x1, x3]
 4fc:	382368a4 	strb	w4, [x5, x3]
 500:	17fffff9 	b	4e4 <memmove+0x14>
      *dst++ = *src++;
 504:	38636824 	ldrb	w4, [x1, x3]
 508:	38236804 	strb	w4, [x0, x3]
 50c:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 510:	4b030044 	sub	w4, w2, w3
 514:	7100009f 	cmp	w4, #0x0
 518:	54ffff6c 	b.gt	504 <memmove+0x34>
  }
  return vdst;
}
 51c:	d65f03c0 	ret
 520:	d2800003 	mov	x3, #0x0                   	// #0
 524:	17fffffb 	b	510 <memmove+0x40>

0000000000000528 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 528:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 52c:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 530:	d2800004 	mov	x4, #0x0                   	// #0
 534:	eb02009f 	cmp	x4, x2
 538:	54000061 	b.ne	544 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 53c:	52800000 	mov	w0, #0x0                   	// #0
 540:	14000007 	b	55c <memcmp+0x34>
    if (*p1 != *p2) {
 544:	38646803 	ldrb	w3, [x0, x4]
 548:	91000484 	add	x4, x4, #0x1
 54c:	38646825 	ldrb	w5, [x1, x4]
 550:	6b05007f 	cmp	w3, w5
 554:	54ffff00 	b.eq	534 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 558:	4b050060 	sub	w0, w3, w5
}
 55c:	d65f03c0 	ret

0000000000000560 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 560:	17ffffdc 	b	4d0 <memmove>

0000000000000564 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 564:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 568:	d4000001 	svc	#0x0
 ret
 56c:	d65f03c0 	ret

0000000000000570 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 570:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 574:	d4000001 	svc	#0x0
 ret
 578:	d65f03c0 	ret

000000000000057c <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 57c:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 580:	d4000001 	svc	#0x0
 ret
 584:	d65f03c0 	ret

0000000000000588 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 588:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 58c:	d4000001 	svc	#0x0
 ret
 590:	d65f03c0 	ret

0000000000000594 <read>:
.global read
read:
 mov x7, #SYS_read
 594:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 598:	d4000001 	svc	#0x0
 ret
 59c:	d65f03c0 	ret

00000000000005a0 <write>:
.global write
write:
 mov x7, #SYS_write
 5a0:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 5a4:	d4000001 	svc	#0x0
 ret
 5a8:	d65f03c0 	ret

00000000000005ac <close>:
.global close
close:
 mov x7, #SYS_close
 5ac:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 5b0:	d4000001 	svc	#0x0
 ret
 5b4:	d65f03c0 	ret

00000000000005b8 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 5b8:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 5bc:	d4000001 	svc	#0x0
 ret
 5c0:	d65f03c0 	ret

00000000000005c4 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 5c4:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 5c8:	d4000001 	svc	#0x0
 ret
 5cc:	d65f03c0 	ret

00000000000005d0 <open>:
.global open
open:
 mov x7, #SYS_open
 5d0:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 5d4:	d4000001 	svc	#0x0
 ret
 5d8:	d65f03c0 	ret

00000000000005dc <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 5dc:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 5e0:	d4000001 	svc	#0x0
 ret
 5e4:	d65f03c0 	ret

00000000000005e8 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 5e8:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 5ec:	d4000001 	svc	#0x0
 ret
 5f0:	d65f03c0 	ret

00000000000005f4 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 5f4:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 5f8:	d4000001 	svc	#0x0
 ret
 5fc:	d65f03c0 	ret

0000000000000600 <link>:
.global link
link:
 mov x7, #SYS_link
 600:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 604:	d4000001 	svc	#0x0
 ret
 608:	d65f03c0 	ret

000000000000060c <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 60c:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 610:	d4000001 	svc	#0x0
 ret
 614:	d65f03c0 	ret

0000000000000618 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 618:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 61c:	d4000001 	svc	#0x0
 ret
 620:	d65f03c0 	ret

0000000000000624 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 624:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 628:	d4000001 	svc	#0x0
 ret
 62c:	d65f03c0 	ret

0000000000000630 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 630:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 634:	d4000001 	svc	#0x0
 ret
 638:	d65f03c0 	ret

000000000000063c <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 63c:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 640:	d4000001 	svc	#0x0
 ret
 644:	d65f03c0 	ret

0000000000000648 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 648:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 64c:	d4000001 	svc	#0x0
 ret
 650:	d65f03c0 	ret

0000000000000654 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 654:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 658:	d4000001 	svc	#0x0
 ret
 65c:	d65f03c0 	ret

0000000000000660 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 660:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 664:	d4000001 	svc	#0x0
 ret
 668:	d65f03c0 	ret

000000000000066c <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 66c:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 670:	d4000001 	svc	#0x0
 ret
 674:	d65f03c0 	ret

0000000000000678 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 678:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 67c:	d4000001 	svc	#0x0
 ret
 680:	d65f03c0 	ret

0000000000000684 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 684:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 688:	d4000001 	svc	#0x0
 ret
 68c:	d65f03c0 	ret

0000000000000690 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 690:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 694:	d4000001 	svc	#0x0
 ret
 698:	d65f03c0 	ret

000000000000069c <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 69c:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 6a0:	d4000001 	svc	#0x0
 ret
 6a4:	d65f03c0 	ret

00000000000006a8 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 6a8:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 6ac:	d4000001 	svc	#0x0
 ret
 6b0:	d65f03c0 	ret

00000000000006b4 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 6b4:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 6b8:	d4000001 	svc	#0x0
 ret
 6bc:	d65f03c0 	ret

00000000000006c0 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 6c0:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 6c4:	d4000001 	svc	#0x0
 ret
 6c8:	d65f03c0 	ret

00000000000006cc <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 6cc:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 6d0:	d4000001 	svc	#0x0
 ret
 6d4:	d65f03c0 	ret

00000000000006d8 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 6d8:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 6dc:	d4000001 	svc	#0x0
 ret
 6e0:	d65f03c0 	ret

00000000000006e4 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 6e4:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 6e8:	d4000001 	svc	#0x0
 ret
 6ec:	d65f03c0 	ret

00000000000006f0 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 6f0:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 6f4:	d4000001 	svc	#0x0
 ret
 6f8:	d65f03c0 	ret

00000000000006fc <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 6fc:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 700:	d4000001 	svc	#0x0
 ret
 704:	d65f03c0 	ret

0000000000000708 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 708:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 70c:	d4000001 	svc	#0x0
 ret
 710:	d65f03c0 	ret

0000000000000714 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 714:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 718:	d4000001 	svc	#0x0
 ret
 71c:	d65f03c0 	ret

0000000000000720 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 720:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 724:	d4000001 	svc	#0x0
 ret
 728:	d65f03c0 	ret

000000000000072c <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 72c:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 730:	d4000001 	svc	#0x0
 ret
 734:	d65f03c0 	ret

0000000000000738 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 738:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 73c:	d4000001 	svc	#0x0
 ret
 740:	d65f03c0 	ret

0000000000000744 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 744:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 748:	d4000001 	svc	#0x0
 ret
 74c:	d65f03c0 	ret

0000000000000750 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 750:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 754:	d4000001 	svc	#0x0
 ret
 758:	d65f03c0 	ret

000000000000075c <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 75c:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 760:	d4000001 	svc	#0x0
 ret
 764:	d65f03c0 	ret

0000000000000768 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 768:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 76c:	d4000001 	svc	#0x0
 ret
 770:	d65f03c0 	ret

0000000000000774 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 774:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 778:	d4000001 	svc	#0x0
 ret
 77c:	d65f03c0 	ret

0000000000000780 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 780:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 784:	d4000001 	svc	#0x0
 ret
 788:	d65f03c0 	ret

000000000000078c <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 78c:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 790:	d4000001 	svc	#0x0
 ret
 794:	d65f03c0 	ret

0000000000000798 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 798:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 79c:	d4000001 	svc	#0x0
 ret
 7a0:	d65f03c0 	ret

00000000000007a4 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 7a4:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 7a8:	d4000001 	svc	#0x0
 ret
 7ac:	d65f03c0 	ret

00000000000007b0 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 7b0:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 7b4:	d4000001 	svc	#0x0
 ret
 7b8:	d65f03c0 	ret

00000000000007bc <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 7bc:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 7c0:	d4000001 	svc	#0x0
 ret
 7c4:	d65f03c0 	ret

00000000000007c8 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 7c8:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 7cc:	d4000001 	svc	#0x0
 ret
 7d0:	d65f03c0 	ret

00000000000007d4 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 7d4:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 7d8:	d4000001 	svc	#0x0
 ret
 7dc:	d65f03c0 	ret

00000000000007e0 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 7e0:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 7e4:	d4000001 	svc	#0x0
 ret
 7e8:	d65f03c0 	ret

00000000000007ec <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 7ec:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 7f0:	d4000001 	svc	#0x0
 ret
 7f4:	d65f03c0 	ret

00000000000007f8 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 7f8:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 7fc:	d4000001 	svc	#0x0
 ret
 800:	d65f03c0 	ret

0000000000000804 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 804:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 808:	d4000001 	svc	#0x0
 ret
 80c:	d65f03c0 	ret

0000000000000810 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 810:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 814:	d4000001 	svc	#0x0
 ret
 818:	d65f03c0 	ret

000000000000081c <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 81c:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 820:	d4000001 	svc	#0x0
 ret
 824:	d65f03c0 	ret

0000000000000828 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 828:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 82c:	d4000001 	svc	#0x0
 ret
 830:	d65f03c0 	ret

0000000000000834 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 834:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 838:	d4000001 	svc	#0x0
 ret
 83c:	d65f03c0 	ret

0000000000000840 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 840:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 844:	d4000001 	svc	#0x0
 ret
 848:	d65f03c0 	ret

000000000000084c <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 84c:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 850:	d4000001 	svc	#0x0
 ret
 854:	d65f03c0 	ret

0000000000000858 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 858:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 85c:	d4000001 	svc	#0x0
 ret
 860:	d65f03c0 	ret

0000000000000864 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 864:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 868:	d4000001 	svc	#0x0
 ret
 86c:	d65f03c0 	ret

0000000000000870 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 870:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 874:	d4000001 	svc	#0x0
 ret
 878:	d65f03c0 	ret

000000000000087c <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 87c:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 880:	d4000001 	svc	#0x0
 ret
 884:	d65f03c0 	ret

0000000000000888 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 888:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 88c:	d4000001 	svc	#0x0
 ret
 890:	d65f03c0 	ret

0000000000000894 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 894:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 898:	d4000001 	svc	#0x0
 ret
 89c:	d65f03c0 	ret

00000000000008a0 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 8a0:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 8a4:	d4000001 	svc	#0x0
 ret
 8a8:	d65f03c0 	ret

00000000000008ac <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 8ac:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 8b0:	d4000001 	svc	#0x0
 ret
 8b4:	d65f03c0 	ret

00000000000008b8 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 8b8:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 8bc:	d4000001 	svc	#0x0
 ret
 8c0:	d65f03c0 	ret

00000000000008c4 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 8c4:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 8c8:	d4000001 	svc	#0x0
 ret
 8cc:	d65f03c0 	ret

00000000000008d0 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 8d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 8d4:	52800022 	mov	w2, #0x1                   	// #1
{
 8d8:	910003fd 	mov	x29, sp
 8dc:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 8e0:	91007fe1 	add	x1, sp, #0x1f
 8e4:	97ffff2f 	bl	5a0 <write>
 8e8:	7100041f 	cmp	w0, #0x1
}
 8ec:	1a9f17e0 	cset	w0, eq	// eq = none
 8f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
 8f4:	d65f03c0 	ret

00000000000008f8 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 8f8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 8fc:	910003fd 	mov	x29, sp
 900:	a90153f3 	stp	x19, x20, [sp, #16]
 904:	a9025bf5 	stp	x21, x22, [sp, #32]
 908:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 90c:	6a417c7f 	tst	w3, w1, lsr #31
 910:	54000300 	b.eq	970 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 914:	4b0103e1 	neg	w1, w1
    neg = 1;
 918:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 91c:	90000003 	adrp	x3, 0 <main>
 920:	91368063 	add	x3, x3, #0xda0
 924:	9100c3f5 	add	x21, sp, #0x30
 928:	d2800000 	mov	x0, #0x0                   	// #0
 92c:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 930:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 934:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 938:	2a0403e1 	mov	w1, w4
 93c:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 940:	38666866 	ldrb	w6, [x3, x6]
 944:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 948:	91000400 	add	x0, x0, #0x1
 94c:	54ffff09 	b.ls	92c <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 950:	11000493 	add	w19, w4, #0x1
  if(neg)
 954:	34000085 	cbz	w5, 964 <printint+0x6c>
    buf[i++] = '-';
 958:	528005a0 	mov	w0, #0x2d                  	// #45
 95c:	38334aa0 	strb	w0, [x21, w19, uxtw]
 960:	11000893 	add	w19, w4, #0x2
 964:	51000673 	sub	w19, w19, #0x1
 968:	52800014 	mov	w20, #0x0                   	// #0
 96c:	14000008 	b	98c <printint+0x94>
  neg = 0;
 970:	52800005 	mov	w5, #0x0                   	// #0
 974:	17ffffea 	b	91c <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 978:	38736aa1 	ldrb	w1, [x21, x19]
 97c:	2a1603e0 	mov	w0, w22
 980:	d1000673 	sub	x19, x19, #0x1
 984:	97ffffd3 	bl	8d0 <putc>
 988:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 98c:	3100067f 	cmn	w19, #0x1
 990:	54ffff41 	b.ne	978 <printint+0x80>  // b.any
  return written;
}
 994:	a9425bf5 	ldp	x21, x22, [sp, #32]
 998:	2a1403e0 	mov	w0, w20
 99c:	a94153f3 	ldp	x19, x20, [sp, #16]
 9a0:	a8c47bfd 	ldp	x29, x30, [sp], #64
 9a4:	d65f03c0 	ret

00000000000009a8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 9a8:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 9ac:	910003fd 	mov	x29, sp
 9b0:	a90153f3 	stp	x19, x20, [sp, #16]
 9b4:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 9b8:	52800015 	mov	w21, #0x0                   	// #0
{
 9bc:	a90363f7 	stp	x23, x24, [sp, #48]
 9c0:	2a0003f7 	mov	w23, w0
 9c4:	a9046bf9 	stp	x25, x26, [sp, #64]
 9c8:	aa0103f9 	mov	x25, x1

  state = 0;
 9cc:	52800001 	mov	w1, #0x0                   	// #0
{
 9d0:	a90573fb 	stp	x27, x28, [sp, #80]
 9d4:	a9406053 	ldp	x19, x24, [x2]
 9d8:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 9dc:	39400320 	ldrb	w0, [x25]
 9e0:	35000120 	cbnz	w0, a04 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 9e4:	2a1503e0 	mov	w0, w21
 9e8:	a94153f3 	ldp	x19, x20, [sp, #16]
 9ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
 9f0:	a94363f7 	ldp	x23, x24, [sp, #48]
 9f4:	a9446bf9 	ldp	x25, x26, [sp, #64]
 9f8:	a94573fb 	ldp	x27, x28, [sp, #80]
 9fc:	a8c67bfd 	ldp	x29, x30, [sp], #96
 a00:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 a04:	2a0003f6 	mov	w22, w0
    if(state == 0){
 a08:	35000101 	cbnz	w1, a28 <vprintf+0x80>
      if(c == '%'){
 a0c:	7100941f 	cmp	w0, #0x25
 a10:	54000ba0 	b.eq	b84 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 a14:	2a1603e1 	mov	w1, w22
 a18:	2a1703e0 	mov	w0, w23
 a1c:	97ffffad 	bl	8d0 <putc>
 a20:	0b0002b5 	add	w21, w21, w0
 a24:	14000057 	b	b80 <vprintf+0x1d8>
      if(c == 'd'){
 a28:	7101901f 	cmp	w0, #0x64
 a2c:	540002a1 	b.ne	a80 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 a30:	37f80174 	tbnz	w20, #31, a5c <vprintf+0xb4>
 a34:	91002e76 	add	x22, x19, #0xb
 a38:	2a1403fa 	mov	w26, w20
 a3c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a40:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 a44:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 a48:	b9400261 	ldr	w1, [x19]
 a4c:	2a1703e0 	mov	w0, w23
 a50:	97ffffaa 	bl	8f8 <printint>
        written += putc(fd, va_arg(ap, uint));
 a54:	0b0002b5 	add	w21, w21, w0
 a58:	14000048 	b	b78 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 a5c:	1100229a 	add	w26, w20, #0x8
 a60:	7100035f 	cmp	w26, #0x0
 a64:	5400008d 	b.le	a74 <vprintf+0xcc>
 a68:	91002e76 	add	x22, x19, #0xb
 a6c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a70:	17fffff4 	b	a40 <vprintf+0x98>
 a74:	aa1303f6 	mov	x22, x19
 a78:	8b34c313 	add	x19, x24, w20, sxtw
 a7c:	17fffff1 	b	a40 <vprintf+0x98>
      } else if(c == 'l') {
 a80:	7101b01f 	cmp	w0, #0x6c
 a84:	54000201 	b.ne	ac4 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 a88:	37f800d4 	tbnz	w20, #31, aa0 <vprintf+0xf8>
 a8c:	91003e76 	add	x22, x19, #0xf
 a90:	2a1403fa 	mov	w26, w20
 a94:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a98:	52800003 	mov	w3, #0x0                   	// #0
 a9c:	17ffffea 	b	a44 <vprintf+0x9c>
 aa0:	1100229a 	add	w26, w20, #0x8
 aa4:	7100035f 	cmp	w26, #0x0
 aa8:	5400008d 	b.le	ab8 <vprintf+0x110>
 aac:	91003e76 	add	x22, x19, #0xf
 ab0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ab4:	17fffff9 	b	a98 <vprintf+0xf0>
 ab8:	aa1303f6 	mov	x22, x19
 abc:	8b34c313 	add	x19, x24, w20, sxtw
 ac0:	17fffff6 	b	a98 <vprintf+0xf0>
      } else if(c == 'x') {
 ac4:	7101e01f 	cmp	w0, #0x78
 ac8:	54000221 	b.ne	b0c <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 acc:	37f800f4 	tbnz	w20, #31, ae8 <vprintf+0x140>
 ad0:	91002e76 	add	x22, x19, #0xb
 ad4:	2a1403fa 	mov	w26, w20
 ad8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 adc:	52800003 	mov	w3, #0x0                   	// #0
 ae0:	52800202 	mov	w2, #0x10                  	// #16
 ae4:	17ffffd9 	b	a48 <vprintf+0xa0>
 ae8:	1100229a 	add	w26, w20, #0x8
 aec:	7100035f 	cmp	w26, #0x0
 af0:	5400008d 	b.le	b00 <vprintf+0x158>
 af4:	91002e76 	add	x22, x19, #0xb
 af8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 afc:	17fffff8 	b	adc <vprintf+0x134>
 b00:	aa1303f6 	mov	x22, x19
 b04:	8b34c313 	add	x19, x24, w20, sxtw
 b08:	17fffff5 	b	adc <vprintf+0x134>
      } else if(c == 'p') {
 b0c:	7101c01f 	cmp	w0, #0x70
 b10:	54000521 	b.ne	bb4 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 b14:	37f803f4 	tbnz	w20, #31, b90 <vprintf+0x1e8>
 b18:	91003e76 	add	x22, x19, #0xf
 b1c:	2a1403fa 	mov	w26, w20
 b20:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b24:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 b28:	52800601 	mov	w1, #0x30                  	// #48
 b2c:	2a1703e0 	mov	w0, w23
 b30:	97ffff68 	bl	8d0 <putc>
 b34:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b38:	9000001c 	adrp	x28, 0 <main>
 b3c:	9136839c 	add	x28, x28, #0xda0
  written += putc(fd, 'x');
 b40:	2a1703e0 	mov	w0, w23
 b44:	52800f01 	mov	w1, #0x78                  	// #120
 b48:	97ffff62 	bl	8d0 <putc>
 b4c:	0b000273 	add	w19, w19, w0
 b50:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b54:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 b58:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b5c:	38606b81 	ldrb	w1, [x28, x0]
 b60:	2a1703e0 	mov	w0, w23
 b64:	97ffff5b 	bl	8d0 <putc>
 b68:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 b6c:	71000694 	subs	w20, w20, #0x1
 b70:	54ffff21 	b.ne	b54 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 b74:	0b1302b5 	add	w21, w21, w19
 b78:	2a1a03f4 	mov	w20, w26
 b7c:	aa1603f3 	mov	x19, x22
      state = 0;
 b80:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 b84:	91000739 	add	x25, x25, #0x1
  state = 0;
 b88:	2a1603e1 	mov	w1, w22
 b8c:	17ffff94 	b	9dc <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 b90:	1100229a 	add	w26, w20, #0x8
 b94:	7100035f 	cmp	w26, #0x0
 b98:	5400008d 	b.le	ba8 <vprintf+0x200>
 b9c:	91003e76 	add	x22, x19, #0xf
 ba0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ba4:	17ffffe0 	b	b24 <vprintf+0x17c>
 ba8:	aa1303f6 	mov	x22, x19
 bac:	8b34c313 	add	x19, x24, w20, sxtw
 bb0:	17ffffdd 	b	b24 <vprintf+0x17c>
      } else if(c == 's'){
 bb4:	7101cc1f 	cmp	w0, #0x73
 bb8:	54000381 	b.ne	c28 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 bbc:	37f80214 	tbnz	w20, #31, bfc <vprintf+0x254>
 bc0:	91003e61 	add	x1, x19, #0xf
 bc4:	aa1303e0 	mov	x0, x19
 bc8:	927df033 	and	x19, x1, #0xfffffffffffffff8
 bcc:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 bd0:	90000000 	adrp	x0, 0 <main>
 bd4:	91366400 	add	x0, x0, #0xd99
 bd8:	f10002df 	cmp	x22, #0x0
 bdc:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 be0:	394002c1 	ldrb	w1, [x22]
 be4:	34fffce1 	cbz	w1, b80 <vprintf+0x1d8>
          written += putc(fd, *s);
 be8:	2a1703e0 	mov	w0, w23
          s++;
 bec:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 bf0:	97ffff38 	bl	8d0 <putc>
 bf4:	0b0002b5 	add	w21, w21, w0
          s++;
 bf8:	17fffffa 	b	be0 <vprintf+0x238>
        s = va_arg(ap, char*);
 bfc:	11002281 	add	w1, w20, #0x8
 c00:	7100003f 	cmp	w1, #0x0
 c04:	540000cd 	b.le	c1c <vprintf+0x274>
 c08:	91003e62 	add	x2, x19, #0xf
 c0c:	aa1303e0 	mov	x0, x19
 c10:	2a0103f4 	mov	w20, w1
 c14:	927df053 	and	x19, x2, #0xfffffffffffffff8
 c18:	17ffffed 	b	bcc <vprintf+0x224>
 c1c:	8b34c300 	add	x0, x24, w20, sxtw
 c20:	2a0103f4 	mov	w20, w1
 c24:	17ffffea 	b	bcc <vprintf+0x224>
      } else if(c == 'c'){
 c28:	71018c1f 	cmp	w0, #0x63
 c2c:	54000241 	b.ne	c74 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 c30:	37f80114 	tbnz	w20, #31, c50 <vprintf+0x2a8>
 c34:	91002e76 	add	x22, x19, #0xb
 c38:	2a1403fa 	mov	w26, w20
 c3c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c40:	39400261 	ldrb	w1, [x19]
 c44:	2a1703e0 	mov	w0, w23
 c48:	97ffff22 	bl	8d0 <putc>
 c4c:	17ffff82 	b	a54 <vprintf+0xac>
 c50:	1100229a 	add	w26, w20, #0x8
 c54:	7100035f 	cmp	w26, #0x0
 c58:	5400008d 	b.le	c68 <vprintf+0x2c0>
 c5c:	91002e76 	add	x22, x19, #0xb
 c60:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c64:	17fffff7 	b	c40 <vprintf+0x298>
 c68:	aa1303f6 	mov	x22, x19
 c6c:	8b34c313 	add	x19, x24, w20, sxtw
 c70:	17fffff4 	b	c40 <vprintf+0x298>
      } else if(c == '%'){
 c74:	7100941f 	cmp	w0, #0x25
 c78:	54ffece0 	b.eq	a14 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 c7c:	2a1703e0 	mov	w0, w23
 c80:	528004a1 	mov	w1, #0x25                  	// #37
 c84:	97ffff13 	bl	8d0 <putc>
 c88:	0b0002b5 	add	w21, w21, w0
 c8c:	17ffff62 	b	a14 <vprintf+0x6c>

0000000000000c90 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 c90:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 c94:	910003fd 	mov	x29, sp
 c98:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 c9c:	910203e2 	add	x2, sp, #0x80
 ca0:	a9030be2 	stp	x2, x2, [sp, #48]
 ca4:	910143e2 	add	x2, sp, #0x50
 ca8:	f90023e2 	str	x2, [sp, #64]
 cac:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 cb0:	b9004be2 	str	w2, [sp, #72]
 cb4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 cb8:	a9430fe2 	ldp	x2, x3, [sp, #48]
 cbc:	a9010fe2 	stp	x2, x3, [sp, #16]
 cc0:	a9440fe2 	ldp	x2, x3, [sp, #64]
 cc4:	a9020fe2 	stp	x2, x3, [sp, #32]
 cc8:	910043e2 	add	x2, sp, #0x10
{
 ccc:	a90617e4 	stp	x4, x5, [sp, #96]
 cd0:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 cd4:	97ffff35 	bl	9a8 <vprintf>
  va_end(ap);
  return result;
}
 cd8:	a8c87bfd 	ldp	x29, x30, [sp], #128
 cdc:	d65f03c0 	ret

0000000000000ce0 <printf>:

int
printf(const char *fmt, ...)
{
 ce0:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 ce4:	910003fd 	mov	x29, sp
 ce8:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 cec:	910243e1 	add	x1, sp, #0x90
 cf0:	a90307e1 	stp	x1, x1, [sp, #48]
 cf4:	910143e1 	add	x1, sp, #0x50
 cf8:	f90023e1 	str	x1, [sp, #64]
 cfc:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 d00:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 d04:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 d08:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 d0c:	52800020 	mov	w0, #0x1                   	// #1
{
 d10:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 d14:	a9430fe2 	ldp	x2, x3, [sp, #48]
 d18:	a9010fe2 	stp	x2, x3, [sp, #16]
 d1c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 d20:	a9020fe2 	stp	x2, x3, [sp, #32]
 d24:	910043e2 	add	x2, sp, #0x10
{
 d28:	a9079be5 	stp	x5, x6, [sp, #120]
 d2c:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 d30:	97ffff1e 	bl	9a8 <vprintf>
  va_end(ap);
  return result;
}
 d34:	a8c97bfd 	ldp	x29, x30, [sp], #144
 d38:	d65f03c0 	ret
