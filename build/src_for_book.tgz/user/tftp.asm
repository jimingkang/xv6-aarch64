
user/_tftp:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  return -1;
}

int
main(int argc, char **argv)
{
       0:	a9af7bfd 	stp	x29, x30, [sp, #-272]!
       4:	910003fd 	mov	x29, sp
       8:	a90153f3 	stp	x19, x20, [sp, #16]
       c:	a9025bf5 	stp	x21, x22, [sp, #32]
      10:	a90363f7 	stp	x23, x24, [sp, #48]
      14:	a9046bf9 	stp	x25, x26, [sp, #64]
      18:	a90573fb 	stp	x27, x28, [sp, #80]
  uint32 server;
  const char *server_name = TFTP_DEFAULT_SERVER;
  const char *remote_name = TFTP_DEFAULT_FILE;

  if(argc > 3){
      1c:	71000c1f 	cmp	w0, #0x3
      20:	540000cd 	b.le	38 <main+0x38>
    server_name = argv[1];
  if(argc == 3)
    remote_name = argv[2];
  if(parse_ipv4(server_name, &server) < 0){
    printf("tftp: invalid server IPv4 address: %s\n", server_name);
    printf("usage: tftp [server-ip [remote-filename]]\n");
      24:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
      28:	91083c00 	add	x0, x0, #0x20f
      2c:	94000452 	bl	1174 <printf>
    exit(1);
      30:	52800020 	mov	w0, #0x1                   	// #1
      34:	94000274 	bl	a04 <exit>
  if(argc >= 2)
      38:	7100041f 	cmp	w0, #0x1
      3c:	5400092d 	b.le	160 <main+0x160>
      40:	aa0103e2 	mov	x2, x1
    server_name = argv[1];
      44:	f9400421 	ldr	x1, [x1, #8]
  if(argc == 3)
      48:	71000c1f 	cmp	w0, #0x3
      4c:	540008e1 	b.ne	168 <main+0x168>  // b.any
    remote_name = argv[2];
      50:	f9400854 	ldr	x20, [x2, #16]
  const char *p = text;
      54:	aa0103e0 	mov	x0, x1
  int octets = 0;
      58:	52800004 	mov	w4, #0x0                   	// #0
  uint32 result = 0;
      5c:	52800015 	mov	w21, #0x0                   	// #0
  while(*p){
      60:	39400002 	ldrb	w2, [x0]
      64:	350009a2 	cbnz	w2, 198 <main+0x198>
  if(octets != 4)
      68:	7100109f 	cmp	w4, #0x4
      6c:	540008e1 	b.ne	188 <main+0x188>  // b.any
  memset(final_path, 0, TFTP_PATH_SIZE);
      70:	b0000013 	adrp	x19, 1000 <vprintf+0x1c4>
      74:	91150673 	add	x19, x19, #0x541
      78:	52801002 	mov	w2, #0x80                  	// #128
      7c:	52800001 	mov	w1, #0x0                   	// #0
      80:	91081260 	add	x0, x19, #0x204
  uint16 server_port = 0, expected_block = 1, last_ack = 0;
      84:	79011fff 	strh	wzr, [sp, #142]
  memset(final_path, 0, TFTP_PATH_SIZE);
      88:	940001e6 	bl	820 <memset>
  const char mode[] = "octet";
      8c:	910243f7 	add	x23, sp, #0x90
  memmove(final_path, "/boot/", sizeof("/boot/"));
      90:	528000e2 	mov	w2, #0x7                   	// #7
      94:	91081260 	add	x0, x19, #0x204
      98:	b0000001 	adrp	x1, 1000 <vprintf+0x1c4>
      9c:	91098421 	add	x1, x1, #0x261
      a0:	94000231 	bl	964 <memmove>
  const char mode[] = "octet";
      a4:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
      a8:	91148c00 	add	x0, x0, #0x523
      ac:	b9400001 	ldr	w1, [x0]
      b0:	79400800 	ldrh	w0, [x0, #4]
      b4:	b90093e1 	str	w1, [sp, #144]
      b8:	79000ae0 	strh	w0, [x23, #4]
  int name_len = strlen(filename);
      bc:	aa1403e0 	mov	x0, x20
      c0:	940001c8 	bl	7e0 <strlen>
  int length = 2 + name_len + 1 + mode_len;
      c4:	11002416 	add	w22, w0, #0x9
  if(name_len == 0 || length > capacity)
      c8:	710402df 	cmp	w22, #0x100
  int name_len = strlen(filename);
      cc:	2a0003f8 	mov	w24, w0
  if(name_len == 0 || length > capacity)
      d0:	7a40d804 	ccmp	w0, #0x0, #0x4, le
      d4:	540008a0 	b.eq	1e8 <main+0x1e8>  // b.none
  p[0] = value >> 8;
      d8:	52802000 	mov	w0, #0x100                 	// #256
  memmove(packet + 2, filename, name_len);
      dc:	2a1803e2 	mov	w2, w24
      e0:	aa1403e1 	mov	x1, x20
  p[0] = value >> 8;
      e4:	79050a60 	strh	w0, [x19, #644]
  memmove(packet + 2, filename, name_len);
      e8:	910a1a60 	add	x0, x19, #0x286
      ec:	9400021e 	bl	964 <memmove>
  packet[2 + name_len] = 0;
      f0:	11000b01 	add	w1, w24, #0x2
  p[0] = value >> 8;
      f4:	910a1279 	add	x25, x19, #0x284
  memmove(packet + 3 + name_len, mode, mode_len);
      f8:	11000f18 	add	w24, w24, #0x3
      fc:	528000c2 	mov	w2, #0x6                   	// #6
  packet[2 + name_len] = 0;
     100:	3821cb3f 	strb	wzr, [x25, w1, sxtw]
  memmove(packet + 3 + name_len, mode, mode_len);
     104:	8b38c320 	add	x0, x25, w24, sxtw
     108:	aa1703e1 	mov	x1, x23
     10c:	94000216 	bl	964 <memmove>
  name_len = strlen(remote_name);
     110:	aa1403e0 	mov	x0, x20
     114:	940001b3 	bl	7e0 <strlen>
  if(rrq_len < 0 || name_len == 0 ||
     118:	710002df 	cmp	w22, #0x0
  name_len = strlen(remote_name);
     11c:	2a0003f8 	mov	w24, w0
  if(rrq_len < 0 || name_len == 0 ||
     120:	7a40a804 	ccmp	w0, #0x0, #0x4, ge	// ge = tcont
     124:	54000120 	b.eq	148 <main+0x148>  // b.none
     name_len + sizeof("/boot/") > TFTP_PATH_SIZE ||
     128:	93407c00 	sxtw	x0, w0
     12c:	91001c00 	add	x0, x0, #0x7
  if(rrq_len < 0 || name_len == 0 ||
     130:	f102001f 	cmp	x0, #0x80
     134:	540000a8 	b.hi	148 <main+0x148>  // b.pmore
     strchr(remote_name, '/') != 0){
     138:	aa1403e0 	mov	x0, x20
     13c:	528005e1 	mov	w1, #0x2f                  	// #47
     140:	940001bf 	bl	83c <strchr>
     name_len + sizeof("/boot/") > TFTP_PATH_SIZE ||
     144:	b4000560 	cbz	x0, 1f0 <main+0x1f0>
    printf("tftp: invalid remote basename or filename is too long\n");
     148:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     14c:	9109a000 	add	x0, x0, #0x268
     150:	94000409 	bl	1174 <printf>
    return -1;
     154:	12800000 	mov	w0, #0xffffffff            	// #-1
  }
  exit(download(server, remote_name) < 0 ? 1 : 0);
     158:	4b0003e0 	neg	w0, w0
     15c:	17ffffb6 	b	34 <main+0x34>
  const char *server_name = TFTP_DEFAULT_SERVER;
     160:	b0000001 	adrp	x1, 1000 <vprintf+0x1c4>
     164:	91080421 	add	x1, x1, #0x201
  const char *remote_name = TFTP_DEFAULT_FILE;
     168:	b0000014 	adrp	x20, 1000 <vprintf+0x1c4>
     16c:	9107b294 	add	x20, x20, #0x1ec
     170:	17ffffb9 	b	54 <main+0x54>
      value = value * 10 + *p++ - '0';
     174:	1b071442 	madd	w2, w2, w7, w5
      if(value > 255)
     178:	91000463 	add	x3, x3, #0x1
      value = value * 10 + *p++ - '0';
     17c:	5100c042 	sub	w2, w2, #0x30
      if(value > 255)
     180:	7103fc5f 	cmp	w2, #0xff
     184:	5400010d 	b.le	1a4 <main+0x1a4>
    printf("tftp: invalid server IPv4 address: %s\n", server_name);
     188:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     18c:	9108e800 	add	x0, x0, #0x23a
     190:	940003f9 	bl	1174 <printf>
     194:	17ffffa4 	b	24 <main+0x24>
  while(*p){
     198:	d2800003 	mov	x3, #0x0                   	// #0
    int value = 0, digits = 0;
     19c:	52800002 	mov	w2, #0x0                   	// #0
      value = value * 10 + *p++ - '0';
     1a0:	52800147 	mov	w7, #0xa                   	// #10
    while(*p >= '0' && *p <= '9'){
     1a4:	38636805 	ldrb	w5, [x0, x3]
     1a8:	5100c0a6 	sub	w6, w5, #0x30
     1ac:	12001cc6 	and	w6, w6, #0xff
     1b0:	710024df 	cmp	w6, #0x9
     1b4:	54fffe09 	b.ls	174 <main+0x174>  // b.plast
    if(digits == 0)
     1b8:	34fffe83 	cbz	w3, 188 <main+0x188>
    octets++;
     1bc:	11000484 	add	w4, w4, #0x1
     1c0:	8b030000 	add	x0, x0, x3
    if(octets < 4){
     1c4:	71000c9f 	cmp	w4, #0x3
     1c8:	540000cc 	b.gt	1e0 <main+0x1e0>
      if(*p++ != '.')
     1cc:	7100b8bf 	cmp	w5, #0x2e
     1d0:	54fffdc1 	b.ne	188 <main+0x188>  // b.any
     1d4:	91000400 	add	x0, x0, #0x1
    result = (result << 8) | value;
     1d8:	2a152055 	orr	w21, w2, w21, lsl #8
     1dc:	17ffffa1 	b	60 <main+0x60>
    } else if(*p != 0){
     1e0:	34ffffc5 	cbz	w5, 1d8 <main+0x1d8>
     1e4:	17ffffe9 	b	188 <main+0x188>
    return -1;
     1e8:	12800016 	mov	w22, #0xffffffff            	// #-1
     1ec:	17ffffc9 	b	110 <main+0x110>
  memmove(final_path + sizeof("/boot/") - 1, remote_name, name_len + 1);
     1f0:	11000702 	add	w2, w24, #0x1
     1f4:	aa1403e1 	mov	x1, x20
     1f8:	91082a60 	add	x0, x19, #0x20a
     1fc:	940001da 	bl	964 <memmove>
  fd = open(final_path, O_WRONLY | O_CREATE | O_TRUNC);
     200:	91081260 	add	x0, x19, #0x204
     204:	5280c021 	mov	w1, #0x601                 	// #1537
     208:	94000217 	bl	a64 <open>
     20c:	2a0003f8 	mov	w24, w0
  if(fd < 0){
     210:	36f800c0 	tbz	w0, #31, 228 <main+0x228>
    printf("tftp: cannot create %s (check that /boot is mounted rw)\n",
     214:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     218:	910a7c00 	add	x0, x0, #0x29f
  printf("tftp: incomplete download remains at %s\n", final_path);
     21c:	91081261 	add	x1, x19, #0x204
     220:	940003d5 	bl	1174 <printf>
  return -1;
     224:	17ffffcc 	b	154 <main+0x154>
  if(udp_bind(LOCAL_PORT) < 0){
     228:	52980000 	mov	w0, #0xc000                	// #49152
     22c:	9400024d 	bl	b60 <udp_bind>
     230:	36f80100 	tbz	w0, #31, 250 <main+0x250>
    printf("tftp: cannot bind local UDP port %d\n", LOCAL_PORT);
     234:	52980001 	mov	w1, #0xc000                	// #49152
     238:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     23c:	910b6000 	add	x0, x0, #0x2d8
     240:	940003cd 	bl	1174 <printf>
    close(fd);
     244:	2a1803e0 	mov	w0, w24
     248:	940001fe 	bl	a40 <close>
    return -1;
     24c:	17ffffc2 	b	154 <main+0x154>
  start_ticks = uptime();
     250:	94000226 	bl	ae8 <uptime>
    printf("tftp: timeout waiting for server response (%d/%d)\n",
     254:	b000001b 	adrp	x27, 1000 <vprintf+0x1c4>
     258:	910c8f7b 	add	x27, x27, #0x323
  printf("tftp: requesting %s from %d.%d.%d.%d\n", remote_name,
     25c:	12001ea5 	and	w5, w21, #0xff
     260:	d3483ea4 	ubfx	x4, x21, #8, #8
     264:	d3505ea3 	ubfx	x3, x21, #16, #8
     268:	53187ea2 	lsr	w2, w21, #24
     26c:	aa1403e1 	mov	x1, x20
    if(udp_send(server, LOCAL_PORT, TFTP_PORT, rrq, rrq_len) != rrq_len)
     270:	910a127c 	add	x28, x19, #0x284
  for(int retry = 0; retry < TFTP_RETRIES; retry++){
     274:	5280001a 	mov	w26, #0x0                   	// #0
  start_ticks = uptime();
     278:	b9006fe0 	str	w0, [sp, #108]
  printf("tftp: requesting %s from %d.%d.%d.%d\n", remote_name,
     27c:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     280:	910bf400 	add	x0, x0, #0x2fd
     284:	940003bc 	bl	1174 <printf>
    if(udp_send(server, LOCAL_PORT, TFTP_PORT, rrq, rrq_len) != rrq_len)
     288:	2a1603e4 	mov	w4, w22
     28c:	aa1c03e3 	mov	x3, x28
     290:	2a1503e0 	mov	w0, w21
     294:	528008a2 	mov	w2, #0x45                  	// #69
     298:	52980001 	mov	w1, #0xc000                	// #49152
     29c:	94000237 	bl	b78 <udp_send>
     2a0:	6b0002df 	cmp	w22, w0
     2a4:	540001c1 	b.ne	2dc <main+0x2dc>  // b.any
    int n = wait_packet(server, server_port, port, packet, TFTP_PACKET_SIZE);
     2a8:	91023be1 	add	x1, sp, #0x8e
     2ac:	2a1503e0 	mov	w0, w21
     2b0:	940000ee 	bl	668 <wait_packet.constprop.0>
    if(n < 0)
     2b4:	3100041f 	cmn	w0, #0x1
     2b8:	54000120 	b.eq	2dc <main+0x2dc>  // b.none
    if(n > 0){
     2bc:	35000160 	cbnz	w0, 2e8 <main+0x2e8>
    printf("tftp: timeout waiting for server response (%d/%d)\n",
     2c0:	1100075a 	add	w26, w26, #0x1
     2c4:	aa1b03e0 	mov	x0, x27
     2c8:	2a1a03e1 	mov	w1, w26
     2cc:	528000a2 	mov	w2, #0x5                   	// #5
     2d0:	940003a9 	bl	1174 <printf>
  for(int retry = 0; retry < TFTP_RETRIES; retry++){
     2d4:	7100175f 	cmp	w26, #0x5
     2d8:	54fffd81 	b.ne	288 <main+0x288>  // b.any
    printf("tftp: no response from server\n");
     2dc:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     2e0:	91141000 	add	x0, x0, #0x504
     2e4:	1400000f 	b	320 <main+0x320>
      if(data_len > 0 && write(fd, packet + 4, data_len) != data_len){
     2e8:	91001261 	add	x1, x19, #0x4
    if(n > 0){
     2ec:	5280001a 	mov	w26, #0x0                   	// #0
     2f0:	52800016 	mov	w22, #0x0                   	// #0
     2f4:	52800019 	mov	w25, #0x0                   	// #0
     2f8:	5280003b 	mov	w27, #0x1                   	// #1
     2fc:	b9006bff 	str	wzr, [sp, #104]
      if(data_len > 0 && write(fd, packet + 4, data_len) != data_len){
     300:	f9003be1 	str	x1, [sp, #112]
      printf("tftp: retrying block %d (%d/%d)\n",
     304:	b0000001 	adrp	x1, 1000 <vprintf+0x1c4>
     308:	91110821 	add	x1, x1, #0x442
     30c:	f9003fe1 	str	x1, [sp, #120]
    if(packet_len < 2){
     310:	7100041f 	cmp	w0, #0x1
     314:	540000a1 	b.ne	328 <main+0x328>  // b.any
      printf("tftp: malformed packet\n");
     318:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     31c:	910d5800 	add	x0, x0, #0x356
    printf("tftp: no response from server\n");
     320:	94000395 	bl	1174 <printf>
    goto failed;
     324:	1400001f 	b	3a0 <main+0x3a0>
    opcode = get16(packet);
     328:	79400261 	ldrh	w1, [x19]
    if(opcode == 5){
     32c:	7114003f 	cmp	w1, #0x500
     330:	540004c1 	b.ne	3c8 <main+0x3c8>  // b.any
      int code = packet_len >= 4 ? get16(packet + 2) : -1;
     334:	71000c1f 	cmp	w0, #0x3
     338:	5400020d 	b.le	378 <main+0x378>
     33c:	79400661 	ldrh	w1, [x19, #2]
        while(length < packet_len - 4 && length < sizeof(message) - 1 &&
     340:	51001000 	sub	w0, w0, #0x4
     344:	d2800002 	mov	x2, #0x0                   	// #0
      int code = packet_len >= 4 ? get16(packet + 2) : -1;
     348:	5ac00421 	rev16	w1, w1
     34c:	12003c21 	and	w1, w1, #0xffff
      if(packet_len < 4){
     350:	2a0203e3 	mov	w3, w2
        while(length < packet_len - 4 && length < sizeof(message) - 1 &&
     354:	6b02001f 	cmp	w0, w2
     358:	540000cd 	b.le	370 <main+0x370>
     35c:	f101fc5f 	cmp	x2, #0x7f
     360:	54000080 	b.eq	370 <main+0x370>  // b.none
              packet[length + 4] != 0){
     364:	8b020264 	add	x4, x19, x2
     368:	39401084 	ldrb	w4, [x4, #4]
        while(length < packet_len - 4 && length < sizeof(message) - 1 &&
     36c:	35000284 	cbnz	w4, 3bc <main+0x3bc>
        message[length] = 0;
     370:	38234aff 	strb	wzr, [x23, w3, uxtw]
     374:	14000007 	b	390 <main+0x390>
        memmove(message, "malformed error", sizeof("malformed error"));
     378:	aa1703e0 	mov	x0, x23
     37c:	b0000001 	adrp	x1, 1000 <vprintf+0x1c4>
     380:	910db821 	add	x1, x1, #0x36e
     384:	52800202 	mov	w2, #0x10                  	// #16
     388:	94000177 	bl	964 <memmove>
      int code = packet_len >= 4 ? get16(packet + 2) : -1;
     38c:	12800001 	mov	w1, #0xffffffff            	// #-1
      printf("tftp: server error %d: %s\n", code, message);
     390:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     394:	910df800 	add	x0, x0, #0x37e
     398:	aa1703e2 	mov	x2, x23
     39c:	94000376 	bl	1174 <printf>
  close(fd);
     3a0:	2a1803e0 	mov	w0, w24
     3a4:	940001a7 	bl	a40 <close>
  udp_unbind(LOCAL_PORT);
     3a8:	52980000 	mov	w0, #0xc000                	// #49152
     3ac:	940001f0 	bl	b6c <udp_unbind>
  printf("tftp: incomplete download remains at %s\n", final_path);
     3b0:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     3b4:	91136c00 	add	x0, x0, #0x4db
     3b8:	17ffff99 	b	21c <main+0x21c>
          message[length] = packet[length + 4];
     3bc:	38226ae4 	strb	w4, [x23, x2]
          length++;
     3c0:	91000442 	add	x2, x2, #0x1
     3c4:	17ffffe3 	b	350 <main+0x350>
    if(opcode != 3 || packet_len < 4 ||
     3c8:	710c003f 	cmp	w1, #0x300
     3cc:	540000a1 	b.ne	3e0 <main+0x3e0>  // b.any
     3d0:	71000c1f 	cmp	w0, #0x3
     3d4:	5400006d 	b.le	3e0 <main+0x3e0>
     3d8:	7108101f 	cmp	w0, #0x204
     3dc:	5400008d 	b.le	3ec <main+0x3ec>
      printf("tftp: unexpected opcode or packet size\n");
     3e0:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     3e4:	910e6400 	add	x0, x0, #0x399
     3e8:	17ffffce 	b	320 <main+0x320>
    uint16 block = get16(packet + 2);
     3ec:	79400661 	ldrh	w1, [x19, #2]
     3f0:	5ac00421 	rev16	w1, w1
     3f4:	12003c3c 	and	w28, w1, #0xffff
    if(block == expected_block){
     3f8:	6b21237f 	cmp	w27, w1, uxth
     3fc:	540005e1 	b.ne	4b8 <main+0x4b8>  // b.any
      if(data_len > 0 && write(fd, packet + 4, data_len) != data_len){
     400:	71001019 	subs	w25, w0, #0x4
     404:	54000140 	b.eq	42c <main+0x42c>  // b.none
     408:	f9403be1 	ldr	x1, [sp, #112]
     40c:	2a1903e2 	mov	w2, w25
     410:	2a1803e0 	mov	w0, w24
     414:	94000188 	bl	a34 <write>
     418:	6b00033f 	cmp	w25, w0
     41c:	54000080 	b.eq	42c <main+0x42c>  // b.none
        printf("tftp: failed writing downloaded data\n");
     420:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     424:	910f0400 	add	x0, x0, #0x3c1
     428:	17ffffbe 	b	320 <main+0x320>
      if(total - last_progress >= TFTP_PROGRESS_BYTES){
     42c:	b9406be0 	ldr	w0, [sp, #104]
      total += data_len;
     430:	0b1902d6 	add	w22, w22, w25
      if(total - last_progress >= TFTP_PROGRESS_BYTES){
     434:	5287ffe1 	mov	w1, #0x3fff                	// #16383
     438:	4b0002c0 	sub	w0, w22, w0
     43c:	6b01001f 	cmp	w0, w1
     440:	540000ad 	b.le	454 <main+0x454>
        print_progress(total, start_ticks);
     444:	b9406fe1 	ldr	w1, [sp, #108]
     448:	2a1603e0 	mov	w0, w22
     44c:	9400005f 	bl	5c8 <print_progress>
        last_progress = total;
     450:	b9006bf6 	str	w22, [sp, #104]
      if(send_ack(server, server_port, block) < 0){
     454:	79411fe1 	ldrh	w1, [sp, #142]
     458:	2a1c03e2 	mov	w2, w28
     45c:	2a1503e0 	mov	w0, w21
     460:	94000073 	bl	62c <send_ack>
     464:	3100041f 	cmn	w0, #0x1
     468:	540000c1 	b.ne	480 <main+0x480>  // b.any
        printf("tftp: failed sending ACK for block %d\n", block);
     46c:	2a1c03e1 	mov	w1, w28
     470:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     474:	910f9c00 	add	x0, x0, #0x3e7
     478:	9400033f 	bl	1174 <printf>
        goto failed;
     47c:	17ffffc9 	b	3a0 <main+0x3a0>
      if(data_len < TFTP_BLOCK_SIZE)
     480:	7108033f 	cmp	w25, #0x200
     484:	54000461 	b.ne	510 <main+0x510>  // b.any
      expected_block++;
     488:	1100077b 	add	w27, w27, #0x1
      last_ack = block;
     48c:	2a1c03f9 	mov	w25, w28
      expected_block++;
     490:	12003f7b 	and	w27, w27, #0xffff
      retries = 0;
     494:	5280001a 	mov	w26, #0x0                   	// #0
      packet_len = wait_packet(server, &server_port, LOCAL_PORT,
     498:	91023be1 	add	x1, sp, #0x8e
     49c:	2a1503e0 	mov	w0, w21
     4a0:	94000072 	bl	668 <wait_packet.constprop.0>
      if(packet_len < 0){
     4a4:	3100041f 	cmn	w0, #0x1
     4a8:	540001a1 	b.ne	4dc <main+0x4dc>  // b.any
        printf("tftp: UDP receive failed\n");
     4ac:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     4b0:	91103800 	add	x0, x0, #0x40e
     4b4:	17ffff9b 	b	320 <main+0x320>
    } else if(block == last_ack){
     4b8:	6b1c033f 	cmp	w25, w28
     4bc:	54fffee1 	b.ne	498 <main+0x498>  // b.any
      if(send_ack(server, server_port, last_ack) < 0)
     4c0:	79411fe1 	ldrh	w1, [sp, #142]
     4c4:	2a1903e2 	mov	w2, w25
     4c8:	2a1503e0 	mov	w0, w21
     4cc:	94000058 	bl	62c <send_ack>
     4d0:	3100041f 	cmn	w0, #0x1
     4d4:	54fffe21 	b.ne	498 <main+0x498>  // b.any
     4d8:	17ffffb2 	b	3a0 <main+0x3a0>
      if(packet_len > 0)
     4dc:	35fff1a0 	cbnz	w0, 310 <main+0x310>
      if(++retries > TFTP_RETRIES){
     4e0:	1100075a 	add	w26, w26, #0x1
     4e4:	7100175f 	cmp	w26, #0x5
     4e8:	5400008d 	b.le	4f8 <main+0x4f8>
        printf("tftp: transfer timed out\n");
     4ec:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     4f0:	9110a000 	add	x0, x0, #0x428
     4f4:	17ffff8b 	b	320 <main+0x320>
      printf("tftp: retrying block %d (%d/%d)\n",
     4f8:	f9403fe0 	ldr	x0, [sp, #120]
     4fc:	2a1a03e2 	mov	w2, w26
     500:	2a1903e1 	mov	w1, w25
     504:	528000a3 	mov	w3, #0x5                   	// #5
     508:	9400031b 	bl	1174 <printf>
      if(send_ack(server, server_port, last_ack) < 0)
     50c:	17ffffed 	b	4c0 <main+0x4c0>
  if(close(fd) < 0){
     510:	2a1803e0 	mov	w0, w24
     514:	9400014b 	bl	a40 <close>
     518:	36f800e0 	tbz	w0, #31, 534 <main+0x534>
    printf("tftp: close failed\n");
     51c:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     520:	91118c00 	add	x0, x0, #0x463
     524:	94000314 	bl	1174 <printf>
    udp_unbind(LOCAL_PORT);
     528:	52980000 	mov	w0, #0xc000                	// #49152
     52c:	94000190 	bl	b6c <udp_unbind>
    return -1;
     530:	17ffff09 	b	154 <main+0x154>
  if(udp_unbind(LOCAL_PORT) < 0){
     534:	52980000 	mov	w0, #0xc000                	// #49152
     538:	9400018d 	bl	b6c <udp_unbind>
     53c:	36f80080 	tbz	w0, #31, 54c <main+0x54c>
    printf("tftp: failed to release UDP port\n");
     540:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     544:	9111dc00 	add	x0, x0, #0x477
     548:	17ffff02 	b	150 <main+0x150>
  if(total != last_progress)
     54c:	b9406be0 	ldr	w0, [sp, #104]
     550:	6b0002df 	cmp	w22, w0
     554:	54000080 	b.eq	564 <main+0x564>  // b.none
    print_progress(total, start_ticks);
     558:	b9406fe1 	ldr	w1, [sp, #108]
     55c:	2a1603e0 	mov	w0, w22
     560:	9400001a 	bl	5c8 <print_progress>
  int elapsed = uptime() - start_ticks;
     564:	94000161 	bl	ae8 <uptime>
     568:	b9406fe1 	ldr	w1, [sp, #108]
     56c:	4b010001 	sub	w1, w0, w1
  int rate_tenths = elapsed > 0 ? (total / 1024 * 100) / elapsed : 0;
     570:	7100003f 	cmp	w1, #0x0
     574:	5400026d 	b.le	5c0 <main+0x5c0>
     578:	52808006 	mov	w6, #0x400                 	// #1024
     57c:	52800c80 	mov	w0, #0x64                  	// #100
     580:	1ac60ec6 	sdiv	w6, w22, w6
     584:	1b007cc6 	mul	w6, w6, w0
     588:	1ac10cc6 	sdiv	w6, w6, w1
  printf("\ntftp: downloaded %s (%d bytes in %d.%d s, avg %d.%d KB/s) to %s\n",
     58c:	52800144 	mov	w4, #0xa                   	// #10
     590:	91081267 	add	x7, x19, #0x204
     594:	2a1603e2 	mov	w2, w22
     598:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     59c:	91126400 	add	x0, x0, #0x499
     5a0:	1ac40cc5 	sdiv	w5, w6, w4
     5a4:	1ac40c23 	sdiv	w3, w1, w4
     5a8:	1b0498a6 	msub	w6, w5, w4, w6
     5ac:	1b048464 	msub	w4, w3, w4, w1
     5b0:	aa1403e1 	mov	x1, x20
     5b4:	940002f0 	bl	1174 <printf>
  return 0;
     5b8:	52800000 	mov	w0, #0x0                   	// #0
     5bc:	17fffee7 	b	158 <main+0x158>
  int rate_tenths = elapsed > 0 ? (total / 1024 * 100) / elapsed : 0;
     5c0:	52800006 	mov	w6, #0x0                   	// #0
     5c4:	17fffff2 	b	58c <main+0x58c>

00000000000005c8 <print_progress>:
{
     5c8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     5cc:	910003fd 	mov	x29, sp
     5d0:	a90153f3 	stp	x19, x20, [sp, #16]
     5d4:	2a0103f4 	mov	w20, w1
     5d8:	2a0003f3 	mov	w19, w0
  int elapsed = uptime() - start_ticks;
     5dc:	94000143 	bl	ae8 <uptime>
     5e0:	4b140000 	sub	w0, w0, w20
  int rate_tenths = elapsed > 0 ? (total / 1024 * 100) / elapsed : 0;
     5e4:	7100001f 	cmp	w0, #0x0
     5e8:	540001ed 	b.le	624 <print_progress+0x5c>
     5ec:	52808001 	mov	w1, #0x400                 	// #1024
     5f0:	52800c82 	mov	w2, #0x64                  	// #100
     5f4:	1ac10e61 	sdiv	w1, w19, w1
     5f8:	1b027c21 	mul	w1, w1, w2
     5fc:	1ac00c21 	sdiv	w1, w1, w0
  printf("\rtftp: %d bytes, %d.%d KB/s", total,
     600:	52800143 	mov	w3, #0xa                   	// #10
     604:	b0000000 	adrp	x0, 1000 <vprintf+0x1c4>
     608:	91074000 	add	x0, x0, #0x1d0
     60c:	1ac30c22 	sdiv	w2, w1, w3
     610:	1b038443 	msub	w3, w2, w3, w1
     614:	2a1303e1 	mov	w1, w19
}
     618:	a94153f3 	ldp	x19, x20, [sp, #16]
     61c:	a8c27bfd 	ldp	x29, x30, [sp], #32
  printf("\rtftp: %d bytes, %d.%d KB/s", total,
     620:	140002d5 	b	1174 <printf>
  int rate_tenths = elapsed > 0 ? (total / 1024 * 100) / elapsed : 0;
     624:	52800001 	mov	w1, #0x0                   	// #0
     628:	17fffff6 	b	600 <print_progress+0x38>

000000000000062c <send_ack>:
{
     62c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  p[0] = value >> 8;
     630:	5ac00442 	rev16	w2, w2
     634:	52808003 	mov	w3, #0x400                 	// #1024
{
     638:	910003fd 	mov	x29, sp
  return udp_send(server, LOCAL_PORT, server_port, packet, sizeof(packet)) == 4
     63c:	52800084 	mov	w4, #0x4                   	// #4
  p[0] = value >> 8;
     640:	790033e3 	strh	w3, [sp, #24]
  return udp_send(server, LOCAL_PORT, server_port, packet, sizeof(packet)) == 4
     644:	910063e3 	add	x3, sp, #0x18
  p[0] = value >> 8;
     648:	790037e2 	strh	w2, [sp, #26]
  return udp_send(server, LOCAL_PORT, server_port, packet, sizeof(packet)) == 4
     64c:	12003c22 	and	w2, w1, #0xffff
     650:	52980001 	mov	w1, #0xc000                	// #49152
     654:	94000149 	bl	b78 <udp_send>
           ? 0 : -1;
     658:	7100101f 	cmp	w0, #0x4
}
     65c:	5a9f03e0 	csetm	w0, ne	// ne = any
     660:	a8c27bfd 	ldp	x29, x30, [sp], #32
     664:	d65f03c0 	ret

0000000000000668 <wait_packet.constprop.0>:
wait_packet(uint32 server, uint16 *server_port, int port,
     668:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     66c:	910003fd 	mov	x29, sp
     670:	a90153f3 	stp	x19, x20, [sp, #16]
    int n = udp_recv_timeout(port, &source, &source_port, packet, capacity,
     674:	b0000014 	adrp	x20, 1000 <vprintf+0x1c4>
     678:	91150694 	add	x20, x20, #0x541
wait_packet(uint32 server, uint16 *server_port, int port,
     67c:	aa0103f3 	mov	x19, x1
     680:	f90013f5 	str	x21, [sp, #32]
     684:	2a0003f5 	mov	w21, w0
    int n = udp_recv_timeout(port, &source, &source_port, packet, capacity,
     688:	aa1403e3 	mov	x3, x20
     68c:	9100ebe2 	add	x2, sp, #0x3a
     690:	9100f3e1 	add	x1, sp, #0x3c
     694:	52800145 	mov	w5, #0xa                   	// #10
     698:	52804084 	mov	w4, #0x204                 	// #516
     69c:	52980000 	mov	w0, #0xc000                	// #49152
     6a0:	9400013f 	bl	b9c <udp_recv_timeout>
    if(n < 0)
     6a4:	37f801c0 	tbnz	w0, #31, 6dc <wait_packet.constprop.0+0x74>
    if(n == 0)
     6a8:	34000120 	cbz	w0, 6cc <wait_packet.constprop.0+0x64>
      if(source != server)
     6ac:	b9403fe1 	ldr	w1, [sp, #60]
     6b0:	6b15003f 	cmp	w1, w21
     6b4:	54fffea1 	b.ne	688 <wait_packet.constprop.0+0x20>  // b.any
      if(*server_port != 0 && source_port != *server_port)
     6b8:	79400261 	ldrh	w1, [x19]
     6bc:	34000141 	cbz	w1, 6e4 <wait_packet.constprop.0+0x7c>
     6c0:	794077e2 	ldrh	w2, [sp, #58]
     6c4:	6b01005f 	cmp	w2, w1
     6c8:	54fffe01 	b.ne	688 <wait_packet.constprop.0+0x20>  // b.any
}
     6cc:	f94013f5 	ldr	x21, [sp, #32]
     6d0:	a94153f3 	ldp	x19, x20, [sp, #16]
     6d4:	a8c47bfd 	ldp	x29, x30, [sp], #64
     6d8:	d65f03c0 	ret
      return -1;
     6dc:	12800000 	mov	w0, #0xffffffff            	// #-1
     6e0:	17fffffb 	b	6cc <wait_packet.constprop.0+0x64>
        *server_port = source_port;
     6e4:	794077e1 	ldrh	w1, [sp, #58]
     6e8:	79000261 	strh	w1, [x19]
     6ec:	17fffff8 	b	6cc <wait_packet.constprop.0+0x64>

00000000000006f0 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     6f0:	d2800002 	mov	x2, #0x0                   	// #0
     6f4:	38626823 	ldrb	w3, [x1, x2]
     6f8:	38226803 	strb	w3, [x0, x2]
     6fc:	91000442 	add	x2, x2, #0x1
     700:	35ffffa3 	cbnz	w3, 6f4 <strcpy+0x4>
    ;
  return os;
}
     704:	d65f03c0 	ret

0000000000000708 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
     708:	d2800003 	mov	x3, #0x0                   	// #0
     70c:	4b030044 	sub	w4, w2, w3
     710:	7100009f 	cmp	w4, #0x0
     714:	5400006d 	b.le	720 <strncpy+0x18>
     718:	38636825 	ldrb	w5, [x1, x3]
     71c:	350000e5 	cbnz	w5, 738 <strncpy+0x30>
     720:	8b030003 	add	x3, x0, x3
     724:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
     728:	4b010082 	sub	w2, w4, w1
     72c:	7100005f 	cmp	w2, #0x0
     730:	540000ac 	b.gt	744 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
     734:	d65f03c0 	ret
    *s++ = *t++;
     738:	38236805 	strb	w5, [x0, x3]
    n--;
     73c:	91000463 	add	x3, x3, #0x1
     740:	17fffff3 	b	70c <strncpy+0x4>
    *s++ = 0;
     744:	3821687f 	strb	wzr, [x3, x1]
     748:	91000421 	add	x1, x1, #0x1
     74c:	17fffff7 	b	728 <strncpy+0x20>

0000000000000750 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
     750:	aa0003e2 	mov	x2, x0
     754:	39400043 	ldrb	w3, [x2]
     758:	aa0203e4 	mov	x4, x2
    s++;
     75c:	91000442 	add	x2, x2, #0x1
  while(*s)
     760:	35ffffa3 	cbnz	w3, 754 <strcat+0x4>
     764:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
     768:	38626823 	ldrb	w3, [x1, x2]
     76c:	38226883 	strb	w3, [x4, x2]
     770:	91000442 	add	x2, x2, #0x1
     774:	35ffffa3 	cbnz	w3, 768 <strcat+0x18>
    ;
  return os;
}
     778:	d65f03c0 	ret

000000000000077c <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
     77c:	d2800002 	mov	x2, #0x0                   	// #0
     780:	38626803 	ldrb	w3, [x0, x2]
     784:	38626824 	ldrb	w4, [x1, x2]
     788:	34000083 	cbz	w3, 798 <strcmp+0x1c>
     78c:	91000442 	add	x2, x2, #0x1
     790:	6b04007f 	cmp	w3, w4
     794:	54ffff60 	b.eq	780 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
     798:	4b040060 	sub	w0, w3, w4
     79c:	d65f03c0 	ret

00000000000007a0 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
     7a0:	340001c2 	cbz	w2, 7d8 <strncmp+0x38>
     7a4:	39400003 	ldrb	w3, [x0]
     7a8:	34000083 	cbz	w3, 7b8 <strncmp+0x18>
     7ac:	39400024 	ldrb	w4, [x1]
     7b0:	6b03009f 	cmp	w4, w3
     7b4:	540000a0 	b.eq	7c8 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
     7b8:	39400000 	ldrb	w0, [x0]
     7bc:	39400021 	ldrb	w1, [x1]
     7c0:	4b010000 	sub	w0, w0, w1
}
     7c4:	d65f03c0 	ret
    n--, p++, q++;
     7c8:	51000442 	sub	w2, w2, #0x1
     7cc:	91000400 	add	x0, x0, #0x1
     7d0:	91000421 	add	x1, x1, #0x1
     7d4:	17fffff3 	b	7a0 <strncmp>
    return 0;
     7d8:	52800000 	mov	w0, #0x0                   	// #0
     7dc:	17fffffa 	b	7c4 <strncmp+0x24>

00000000000007e0 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
     7e0:	d1000402 	sub	x2, x0, #0x1
     7e4:	d2800001 	mov	x1, #0x0                   	// #0
     7e8:	aa0103e0 	mov	x0, x1
     7ec:	91000421 	add	x1, x1, #0x1
     7f0:	38616843 	ldrb	w3, [x2, x1]
     7f4:	35ffffa3 	cbnz	w3, 7e8 <strlen+0x8>
    ;
  return n;
}
     7f8:	d65f03c0 	ret

00000000000007fc <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
     7fc:	d1000403 	sub	x3, x0, #0x1
     800:	d2800002 	mov	x2, #0x0                   	// #0
     804:	2a0203e0 	mov	w0, w2
     808:	6b02003f 	cmp	w1, w2
     80c:	54000089 	b.ls	81c <strnlen+0x20>  // b.plast
     810:	91000442 	add	x2, x2, #0x1
     814:	38626864 	ldrb	w4, [x3, x2]
     818:	35ffff64 	cbnz	w4, 804 <strnlen+0x8>
    n++;
  return n;
}
     81c:	d65f03c0 	ret

0000000000000820 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     820:	d2800003 	mov	x3, #0x0                   	// #0
     824:	6b03005f 	cmp	w2, w3
     828:	54000048 	b.hi	830 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
     82c:	d65f03c0 	ret
    cdst[i] = c;
     830:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
     834:	91000463 	add	x3, x3, #0x1
     838:	17fffffb 	b	824 <memset+0x4>

000000000000083c <strchr>:

char*
strchr(const char *s, char c)
{
     83c:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
     840:	39400002 	ldrb	w2, [x0]
     844:	35000062 	cbnz	w2, 850 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
     848:	d2800000 	mov	x0, #0x0                   	// #0
}
     84c:	d65f03c0 	ret
    if(*s == c)
     850:	6b01005f 	cmp	w2, w1
     854:	54ffffc0 	b.eq	84c <strchr+0x10>  // b.none
  for(; *s; s++)
     858:	91000400 	add	x0, x0, #0x1
     85c:	17fffff9 	b	840 <strchr+0x4>

0000000000000860 <gets>:

char*
gets(char *buf, int max)
{
     860:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     864:	910003fd 	mov	x29, sp
     868:	a90153f3 	stp	x19, x20, [sp, #16]
     86c:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     870:	d2800014 	mov	x20, #0x0                   	// #0
{
     874:	f9001bf7 	str	x23, [sp, #48]
     878:	2a0103f7 	mov	w23, w1
     87c:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
     880:	11000695 	add	w21, w20, #0x1
     884:	2a1403f6 	mov	w22, w20
     888:	6b1702bf 	cmp	w21, w23
     88c:	540000ea 	b.ge	8a8 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
     890:	91013fe1 	add	x1, sp, #0x4f
     894:	52800022 	mov	w2, #0x1                   	// #1
     898:	52800000 	mov	w0, #0x0                   	// #0
     89c:	94000063 	bl	a28 <read>
    if(cc < 1)
     8a0:	7100001f 	cmp	w0, #0x0
     8a4:	5400012c 	b.gt	8c8 <gets+0x68>
  for(i=0; i+1 < max; ){
     8a8:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
     8ac:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
     8b0:	aa1303e0 	mov	x0, x19
     8b4:	f9401bf7 	ldr	x23, [sp, #48]
     8b8:	a94153f3 	ldp	x19, x20, [sp, #16]
     8bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
     8c0:	a8c57bfd 	ldp	x29, x30, [sp], #80
     8c4:	d65f03c0 	ret
    buf[i++] = c;
     8c8:	39413fe0 	ldrb	w0, [sp, #79]
     8cc:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
     8d0:	91000694 	add	x20, x20, #0x1
     8d4:	7100281f 	cmp	w0, #0xa
     8d8:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
     8dc:	54fffd21 	b.ne	880 <gets+0x20>  // b.any
     8e0:	17fffff3 	b	8ac <gets+0x4c>

00000000000008e4 <stat>:

int
stat(const char *n, struct stat *st)
{
     8e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     8e8:	910003fd 	mov	x29, sp
     8ec:	a90153f3 	stp	x19, x20, [sp, #16]
     8f0:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     8f4:	52800001 	mov	w1, #0x0                   	// #0
     8f8:	9400005b 	bl	a64 <open>
  if(fd < 0)
     8fc:	37f80160 	tbnz	w0, #31, 928 <stat+0x44>
    return -1;
  r = fstat(fd, st);
     900:	aa1303e1 	mov	x1, x19
     904:	2a0003f4 	mov	w20, w0
     908:	94000060 	bl	a88 <fstat>
     90c:	2a0003f3 	mov	w19, w0
  close(fd);
     910:	2a1403e0 	mov	w0, w20
     914:	9400004b 	bl	a40 <close>
  return r;
}
     918:	2a1303e0 	mov	w0, w19
     91c:	a94153f3 	ldp	x19, x20, [sp, #16]
     920:	a8c27bfd 	ldp	x29, x30, [sp], #32
     924:	d65f03c0 	ret
    return -1;
     928:	12800013 	mov	w19, #0xffffffff            	// #-1
     92c:	17fffffb 	b	918 <stat+0x34>

0000000000000930 <atoi>:

int
atoi(const char *s)
{
     930:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
     934:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
     938:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
     93c:	39400043 	ldrb	w3, [x2]
     940:	5100c061 	sub	w1, w3, #0x30
     944:	12001c21 	and	w1, w1, #0xff
     948:	7100243f 	cmp	w1, #0x9
     94c:	54000049 	b.ls	954 <atoi+0x24>  // b.plast
  return n;
}
     950:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
     954:	1b040c01 	madd	w1, w0, w4, w3
     958:	91000442 	add	x2, x2, #0x1
     95c:	5100c020 	sub	w0, w1, #0x30
     960:	17fffff7 	b	93c <atoi+0xc>

0000000000000964 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     964:	eb01001f 	cmp	x0, x1
     968:	54000263 	b.cc	9b4 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
     96c:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
     970:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
     974:	d2800003 	mov	x3, #0x0                   	// #0
     978:	d1000463 	sub	x3, x3, #0x1
     97c:	11000464 	add	w4, w3, #0x1
     980:	0b020084 	add	w4, w4, w2
     984:	7100009f 	cmp	w4, #0x0
     988:	5400014d 	b.le	9b0 <memmove+0x4c>
      *--dst = *--src;
     98c:	38636824 	ldrb	w4, [x1, x3]
     990:	382368a4 	strb	w4, [x5, x3]
     994:	17fffff9 	b	978 <memmove+0x14>
      *dst++ = *src++;
     998:	38636824 	ldrb	w4, [x1, x3]
     99c:	38236804 	strb	w4, [x0, x3]
     9a0:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
     9a4:	4b030044 	sub	w4, w2, w3
     9a8:	7100009f 	cmp	w4, #0x0
     9ac:	54ffff6c 	b.gt	998 <memmove+0x34>
  }
  return vdst;
}
     9b0:	d65f03c0 	ret
     9b4:	d2800003 	mov	x3, #0x0                   	// #0
     9b8:	17fffffb 	b	9a4 <memmove+0x40>

00000000000009bc <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     9bc:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
     9c0:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
     9c4:	d2800004 	mov	x4, #0x0                   	// #0
     9c8:	eb02009f 	cmp	x4, x2
     9cc:	54000061 	b.ne	9d8 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
     9d0:	52800000 	mov	w0, #0x0                   	// #0
     9d4:	14000007 	b	9f0 <memcmp+0x34>
    if (*p1 != *p2) {
     9d8:	38646803 	ldrb	w3, [x0, x4]
     9dc:	91000484 	add	x4, x4, #0x1
     9e0:	38646825 	ldrb	w5, [x1, x4]
     9e4:	6b05007f 	cmp	w3, w5
     9e8:	54ffff00 	b.eq	9c8 <memcmp+0xc>  // b.none
      return *p1 - *p2;
     9ec:	4b050060 	sub	w0, w3, w5
}
     9f0:	d65f03c0 	ret

00000000000009f4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
     9f4:	17ffffdc 	b	964 <memmove>

00000000000009f8 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
     9f8:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
     9fc:	d4000001 	svc	#0x0
 ret
     a00:	d65f03c0 	ret

0000000000000a04 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
     a04:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
     a08:	d4000001 	svc	#0x0
 ret
     a0c:	d65f03c0 	ret

0000000000000a10 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
     a10:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
     a14:	d4000001 	svc	#0x0
 ret
     a18:	d65f03c0 	ret

0000000000000a1c <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
     a1c:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
     a20:	d4000001 	svc	#0x0
 ret
     a24:	d65f03c0 	ret

0000000000000a28 <read>:
.global read
read:
 mov x7, #SYS_read
     a28:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
     a2c:	d4000001 	svc	#0x0
 ret
     a30:	d65f03c0 	ret

0000000000000a34 <write>:
.global write
write:
 mov x7, #SYS_write
     a34:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
     a38:	d4000001 	svc	#0x0
 ret
     a3c:	d65f03c0 	ret

0000000000000a40 <close>:
.global close
close:
 mov x7, #SYS_close
     a40:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
     a44:	d4000001 	svc	#0x0
 ret
     a48:	d65f03c0 	ret

0000000000000a4c <kill>:
.global kill
kill:
 mov x7, #SYS_kill
     a4c:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
     a50:	d4000001 	svc	#0x0
 ret
     a54:	d65f03c0 	ret

0000000000000a58 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
     a58:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
     a5c:	d4000001 	svc	#0x0
 ret
     a60:	d65f03c0 	ret

0000000000000a64 <open>:
.global open
open:
 mov x7, #SYS_open
     a64:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
     a68:	d4000001 	svc	#0x0
 ret
     a6c:	d65f03c0 	ret

0000000000000a70 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
     a70:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
     a74:	d4000001 	svc	#0x0
 ret
     a78:	d65f03c0 	ret

0000000000000a7c <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
     a7c:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
     a80:	d4000001 	svc	#0x0
 ret
     a84:	d65f03c0 	ret

0000000000000a88 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
     a88:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
     a8c:	d4000001 	svc	#0x0
 ret
     a90:	d65f03c0 	ret

0000000000000a94 <link>:
.global link
link:
 mov x7, #SYS_link
     a94:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
     a98:	d4000001 	svc	#0x0
 ret
     a9c:	d65f03c0 	ret

0000000000000aa0 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
     aa0:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
     aa4:	d4000001 	svc	#0x0
 ret
     aa8:	d65f03c0 	ret

0000000000000aac <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
     aac:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
     ab0:	d4000001 	svc	#0x0
 ret
     ab4:	d65f03c0 	ret

0000000000000ab8 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
     ab8:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
     abc:	d4000001 	svc	#0x0
 ret
     ac0:	d65f03c0 	ret

0000000000000ac4 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
     ac4:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
     ac8:	d4000001 	svc	#0x0
 ret
     acc:	d65f03c0 	ret

0000000000000ad0 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
     ad0:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
     ad4:	d4000001 	svc	#0x0
 ret
     ad8:	d65f03c0 	ret

0000000000000adc <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
     adc:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
     ae0:	d4000001 	svc	#0x0
 ret
     ae4:	d65f03c0 	ret

0000000000000ae8 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
     ae8:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
     aec:	d4000001 	svc	#0x0
 ret
     af0:	d65f03c0 	ret

0000000000000af4 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
     af4:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
     af8:	d4000001 	svc	#0x0
 ret
     afc:	d65f03c0 	ret

0000000000000b00 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
     b00:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
     b04:	d4000001 	svc	#0x0
 ret
     b08:	d65f03c0 	ret

0000000000000b0c <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
     b0c:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
     b10:	d4000001 	svc	#0x0
 ret
     b14:	d65f03c0 	ret

0000000000000b18 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
     b18:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
     b1c:	d4000001 	svc	#0x0
 ret
     b20:	d65f03c0 	ret

0000000000000b24 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
     b24:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
     b28:	d4000001 	svc	#0x0
 ret
     b2c:	d65f03c0 	ret

0000000000000b30 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
     b30:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
     b34:	d4000001 	svc	#0x0
 ret
     b38:	d65f03c0 	ret

0000000000000b3c <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
     b3c:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
     b40:	d4000001 	svc	#0x0
 ret
     b44:	d65f03c0 	ret

0000000000000b48 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
     b48:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
     b4c:	d4000001 	svc	#0x0
 ret
     b50:	d65f03c0 	ret

0000000000000b54 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
     b54:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
     b58:	d4000001 	svc	#0x0
 ret
     b5c:	d65f03c0 	ret

0000000000000b60 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
     b60:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
     b64:	d4000001 	svc	#0x0
 ret
     b68:	d65f03c0 	ret

0000000000000b6c <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
     b6c:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
     b70:	d4000001 	svc	#0x0
 ret
     b74:	d65f03c0 	ret

0000000000000b78 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
     b78:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
     b7c:	d4000001 	svc	#0x0
 ret
     b80:	d65f03c0 	ret

0000000000000b84 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
     b84:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
     b88:	d4000001 	svc	#0x0
 ret
     b8c:	d65f03c0 	ret

0000000000000b90 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
     b90:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
     b94:	d4000001 	svc	#0x0
 ret
     b98:	d65f03c0 	ret

0000000000000b9c <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
     b9c:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
     ba0:	d4000001 	svc	#0x0
 ret
     ba4:	d65f03c0 	ret

0000000000000ba8 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
     ba8:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
     bac:	d4000001 	svc	#0x0
 ret
     bb0:	d65f03c0 	ret

0000000000000bb4 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
     bb4:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
     bb8:	d4000001 	svc	#0x0
 ret
     bbc:	d65f03c0 	ret

0000000000000bc0 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
     bc0:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
     bc4:	d4000001 	svc	#0x0
 ret
     bc8:	d65f03c0 	ret

0000000000000bcc <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
     bcc:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
     bd0:	d4000001 	svc	#0x0
 ret
     bd4:	d65f03c0 	ret

0000000000000bd8 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
     bd8:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
     bdc:	d4000001 	svc	#0x0
 ret
     be0:	d65f03c0 	ret

0000000000000be4 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
     be4:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
     be8:	d4000001 	svc	#0x0
 ret
     bec:	d65f03c0 	ret

0000000000000bf0 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
     bf0:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
     bf4:	d4000001 	svc	#0x0
 ret
     bf8:	d65f03c0 	ret

0000000000000bfc <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
     bfc:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
     c00:	d4000001 	svc	#0x0
 ret
     c04:	d65f03c0 	ret

0000000000000c08 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
     c08:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
     c0c:	d4000001 	svc	#0x0
 ret
     c10:	d65f03c0 	ret

0000000000000c14 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
     c14:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
     c18:	d4000001 	svc	#0x0
 ret
     c1c:	d65f03c0 	ret

0000000000000c20 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
     c20:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
     c24:	d4000001 	svc	#0x0
 ret
     c28:	d65f03c0 	ret

0000000000000c2c <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
     c2c:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
     c30:	d4000001 	svc	#0x0
 ret
     c34:	d65f03c0 	ret

0000000000000c38 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
     c38:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
     c3c:	d4000001 	svc	#0x0
 ret
     c40:	d65f03c0 	ret

0000000000000c44 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
     c44:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
     c48:	d4000001 	svc	#0x0
 ret
     c4c:	d65f03c0 	ret

0000000000000c50 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
     c50:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
     c54:	d4000001 	svc	#0x0
 ret
     c58:	d65f03c0 	ret

0000000000000c5c <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
     c5c:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
     c60:	d4000001 	svc	#0x0
 ret
     c64:	d65f03c0 	ret

0000000000000c68 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
     c68:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
     c6c:	d4000001 	svc	#0x0
 ret
     c70:	d65f03c0 	ret

0000000000000c74 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
     c74:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
     c78:	d4000001 	svc	#0x0
 ret
     c7c:	d65f03c0 	ret

0000000000000c80 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
     c80:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
     c84:	d4000001 	svc	#0x0
 ret
     c88:	d65f03c0 	ret

0000000000000c8c <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
     c8c:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
     c90:	d4000001 	svc	#0x0
 ret
     c94:	d65f03c0 	ret

0000000000000c98 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
     c98:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
     c9c:	d4000001 	svc	#0x0
 ret
     ca0:	d65f03c0 	ret

0000000000000ca4 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
     ca4:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
     ca8:	d4000001 	svc	#0x0
 ret
     cac:	d65f03c0 	ret

0000000000000cb0 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
     cb0:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
     cb4:	d4000001 	svc	#0x0
 ret
     cb8:	d65f03c0 	ret

0000000000000cbc <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
     cbc:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
     cc0:	d4000001 	svc	#0x0
 ret
     cc4:	d65f03c0 	ret

0000000000000cc8 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
     cc8:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
     ccc:	d4000001 	svc	#0x0
 ret
     cd0:	d65f03c0 	ret

0000000000000cd4 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
     cd4:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
     cd8:	d4000001 	svc	#0x0
 ret
     cdc:	d65f03c0 	ret

0000000000000ce0 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
     ce0:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
     ce4:	d4000001 	svc	#0x0
 ret
     ce8:	d65f03c0 	ret

0000000000000cec <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
     cec:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
     cf0:	d4000001 	svc	#0x0
 ret
     cf4:	d65f03c0 	ret

0000000000000cf8 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
     cf8:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
     cfc:	d4000001 	svc	#0x0
 ret
     d00:	d65f03c0 	ret

0000000000000d04 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
     d04:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
     d08:	d4000001 	svc	#0x0
 ret
     d0c:	d65f03c0 	ret

0000000000000d10 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
     d10:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
     d14:	d4000001 	svc	#0x0
 ret
     d18:	d65f03c0 	ret

0000000000000d1c <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
     d1c:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
     d20:	d4000001 	svc	#0x0
 ret
     d24:	d65f03c0 	ret

0000000000000d28 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
     d28:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
     d2c:	d4000001 	svc	#0x0
 ret
     d30:	d65f03c0 	ret

0000000000000d34 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
     d34:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
     d38:	d4000001 	svc	#0x0
 ret
     d3c:	d65f03c0 	ret

0000000000000d40 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
     d40:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
     d44:	d4000001 	svc	#0x0
 ret
     d48:	d65f03c0 	ret

0000000000000d4c <listen>:
.global listen
listen:
 mov x7, #SYS_listen
     d4c:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
     d50:	d4000001 	svc	#0x0
 ret
     d54:	d65f03c0 	ret

0000000000000d58 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
     d58:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
     d5c:	d4000001 	svc	#0x0
 ret
     d60:	d65f03c0 	ret

0000000000000d64 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
     d64:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
     d68:	52800022 	mov	w2, #0x1                   	// #1
{
     d6c:	910003fd 	mov	x29, sp
     d70:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
     d74:	91007fe1 	add	x1, sp, #0x1f
     d78:	97ffff2f 	bl	a34 <write>
     d7c:	7100041f 	cmp	w0, #0x1
}
     d80:	1a9f17e0 	cset	w0, eq	// eq = none
     d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
     d88:	d65f03c0 	ret

0000000000000d8c <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
     d8c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     d90:	910003fd 	mov	x29, sp
     d94:	a90153f3 	stp	x19, x20, [sp, #16]
     d98:	a9025bf5 	stp	x21, x22, [sp, #32]
     d9c:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     da0:	6a417c7f 	tst	w3, w1, lsr #31
     da4:	54000300 	b.eq	e04 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
     da8:	4b0103e1 	neg	w1, w1
    neg = 1;
     dac:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
     db0:	b0000003 	adrp	x3, 1000 <vprintf+0x1c4>
     db4:	9114c063 	add	x3, x3, #0x530
     db8:	9100c3f5 	add	x21, sp, #0x30
     dbc:	d2800000 	mov	x0, #0x0                   	// #0
     dc0:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
     dc4:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
     dc8:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
     dcc:	2a0403e1 	mov	w1, w4
     dd0:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
     dd4:	38666866 	ldrb	w6, [x3, x6]
     dd8:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
     ddc:	91000400 	add	x0, x0, #0x1
     de0:	54ffff09 	b.ls	dc0 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
     de4:	11000493 	add	w19, w4, #0x1
  if(neg)
     de8:	34000085 	cbz	w5, df8 <printint+0x6c>
    buf[i++] = '-';
     dec:	528005a0 	mov	w0, #0x2d                  	// #45
     df0:	38334aa0 	strb	w0, [x21, w19, uxtw]
     df4:	11000893 	add	w19, w4, #0x2
     df8:	51000673 	sub	w19, w19, #0x1
     dfc:	52800014 	mov	w20, #0x0                   	// #0
     e00:	14000008 	b	e20 <printint+0x94>
  neg = 0;
     e04:	52800005 	mov	w5, #0x0                   	// #0
     e08:	17ffffea 	b	db0 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
     e0c:	38736aa1 	ldrb	w1, [x21, x19]
     e10:	2a1603e0 	mov	w0, w22
     e14:	d1000673 	sub	x19, x19, #0x1
     e18:	97ffffd3 	bl	d64 <putc>
     e1c:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
     e20:	3100067f 	cmn	w19, #0x1
     e24:	54ffff41 	b.ne	e0c <printint+0x80>  // b.any
  return written;
}
     e28:	a9425bf5 	ldp	x21, x22, [sp, #32]
     e2c:	2a1403e0 	mov	w0, w20
     e30:	a94153f3 	ldp	x19, x20, [sp, #16]
     e34:	a8c47bfd 	ldp	x29, x30, [sp], #64
     e38:	d65f03c0 	ret

0000000000000e3c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
     e3c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
     e40:	910003fd 	mov	x29, sp
     e44:	a90153f3 	stp	x19, x20, [sp, #16]
     e48:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
     e4c:	52800015 	mov	w21, #0x0                   	// #0
{
     e50:	a90363f7 	stp	x23, x24, [sp, #48]
     e54:	2a0003f7 	mov	w23, w0
     e58:	a9046bf9 	stp	x25, x26, [sp, #64]
     e5c:	aa0103f9 	mov	x25, x1

  state = 0;
     e60:	52800001 	mov	w1, #0x0                   	// #0
{
     e64:	a90573fb 	stp	x27, x28, [sp, #80]
     e68:	a9406053 	ldp	x19, x24, [x2]
     e6c:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
     e70:	39400320 	ldrb	w0, [x25]
     e74:	35000120 	cbnz	w0, e98 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
     e78:	2a1503e0 	mov	w0, w21
     e7c:	a94153f3 	ldp	x19, x20, [sp, #16]
     e80:	a9425bf5 	ldp	x21, x22, [sp, #32]
     e84:	a94363f7 	ldp	x23, x24, [sp, #48]
     e88:	a9446bf9 	ldp	x25, x26, [sp, #64]
     e8c:	a94573fb 	ldp	x27, x28, [sp, #80]
     e90:	a8c67bfd 	ldp	x29, x30, [sp], #96
     e94:	d65f03c0 	ret
    c = fmt[i] & 0xff;
     e98:	2a0003f6 	mov	w22, w0
    if(state == 0){
     e9c:	35000101 	cbnz	w1, ebc <vprintf+0x80>
      if(c == '%'){
     ea0:	7100941f 	cmp	w0, #0x25
     ea4:	54000ba0 	b.eq	1018 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
     ea8:	2a1603e1 	mov	w1, w22
     eac:	2a1703e0 	mov	w0, w23
     eb0:	97ffffad 	bl	d64 <putc>
     eb4:	0b0002b5 	add	w21, w21, w0
     eb8:	14000057 	b	1014 <vprintf+0x1d8>
      if(c == 'd'){
     ebc:	7101901f 	cmp	w0, #0x64
     ec0:	540002a1 	b.ne	f14 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
     ec4:	37f80174 	tbnz	w20, #31, ef0 <vprintf+0xb4>
     ec8:	91002e76 	add	x22, x19, #0xb
     ecc:	2a1403fa 	mov	w26, w20
     ed0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     ed4:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
     ed8:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
     edc:	b9400261 	ldr	w1, [x19]
     ee0:	2a1703e0 	mov	w0, w23
     ee4:	97ffffaa 	bl	d8c <printint>
        written += putc(fd, va_arg(ap, uint));
     ee8:	0b0002b5 	add	w21, w21, w0
     eec:	14000048 	b	100c <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
     ef0:	1100229a 	add	w26, w20, #0x8
     ef4:	7100035f 	cmp	w26, #0x0
     ef8:	5400008d 	b.le	f08 <vprintf+0xcc>
     efc:	91002e76 	add	x22, x19, #0xb
     f00:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     f04:	17fffff4 	b	ed4 <vprintf+0x98>
     f08:	aa1303f6 	mov	x22, x19
     f0c:	8b34c313 	add	x19, x24, w20, sxtw
     f10:	17fffff1 	b	ed4 <vprintf+0x98>
      } else if(c == 'l') {
     f14:	7101b01f 	cmp	w0, #0x6c
     f18:	54000201 	b.ne	f58 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
     f1c:	37f800d4 	tbnz	w20, #31, f34 <vprintf+0xf8>
     f20:	91003e76 	add	x22, x19, #0xf
     f24:	2a1403fa 	mov	w26, w20
     f28:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     f2c:	52800003 	mov	w3, #0x0                   	// #0
     f30:	17ffffea 	b	ed8 <vprintf+0x9c>
     f34:	1100229a 	add	w26, w20, #0x8
     f38:	7100035f 	cmp	w26, #0x0
     f3c:	5400008d 	b.le	f4c <vprintf+0x110>
     f40:	91003e76 	add	x22, x19, #0xf
     f44:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     f48:	17fffff9 	b	f2c <vprintf+0xf0>
     f4c:	aa1303f6 	mov	x22, x19
     f50:	8b34c313 	add	x19, x24, w20, sxtw
     f54:	17fffff6 	b	f2c <vprintf+0xf0>
      } else if(c == 'x') {
     f58:	7101e01f 	cmp	w0, #0x78
     f5c:	54000221 	b.ne	fa0 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
     f60:	37f800f4 	tbnz	w20, #31, f7c <vprintf+0x140>
     f64:	91002e76 	add	x22, x19, #0xb
     f68:	2a1403fa 	mov	w26, w20
     f6c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     f70:	52800003 	mov	w3, #0x0                   	// #0
     f74:	52800202 	mov	w2, #0x10                  	// #16
     f78:	17ffffd9 	b	edc <vprintf+0xa0>
     f7c:	1100229a 	add	w26, w20, #0x8
     f80:	7100035f 	cmp	w26, #0x0
     f84:	5400008d 	b.le	f94 <vprintf+0x158>
     f88:	91002e76 	add	x22, x19, #0xb
     f8c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     f90:	17fffff8 	b	f70 <vprintf+0x134>
     f94:	aa1303f6 	mov	x22, x19
     f98:	8b34c313 	add	x19, x24, w20, sxtw
     f9c:	17fffff5 	b	f70 <vprintf+0x134>
      } else if(c == 'p') {
     fa0:	7101c01f 	cmp	w0, #0x70
     fa4:	54000521 	b.ne	1048 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
     fa8:	37f803f4 	tbnz	w20, #31, 1024 <vprintf+0x1e8>
     fac:	91003e76 	add	x22, x19, #0xf
     fb0:	2a1403fa 	mov	w26, w20
     fb4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     fb8:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
     fbc:	52800601 	mov	w1, #0x30                  	// #48
     fc0:	2a1703e0 	mov	w0, w23
     fc4:	97ffff68 	bl	d64 <putc>
     fc8:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     fcc:	b000001c 	adrp	x28, 1000 <vprintf+0x1c4>
     fd0:	9114c39c 	add	x28, x28, #0x530
  written += putc(fd, 'x');
     fd4:	2a1703e0 	mov	w0, w23
     fd8:	52800f01 	mov	w1, #0x78                  	// #120
     fdc:	97ffff62 	bl	d64 <putc>
     fe0:	0b000273 	add	w19, w19, w0
     fe4:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     fe8:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     fec:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     ff0:	38606b81 	ldrb	w1, [x28, x0]
     ff4:	2a1703e0 	mov	w0, w23
     ff8:	97ffff5b 	bl	d64 <putc>
     ffc:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    1000:	71000694 	subs	w20, w20, #0x1
    1004:	54ffff21 	b.ne	fe8 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    1008:	0b1302b5 	add	w21, w21, w19
    100c:	2a1a03f4 	mov	w20, w26
    1010:	aa1603f3 	mov	x19, x22
      state = 0;
    1014:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
    1018:	91000739 	add	x25, x25, #0x1
  state = 0;
    101c:	2a1603e1 	mov	w1, w22
    1020:	17ffff94 	b	e70 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
    1024:	1100229a 	add	w26, w20, #0x8
    1028:	7100035f 	cmp	w26, #0x0
    102c:	5400008d 	b.le	103c <vprintf+0x200>
    1030:	91003e76 	add	x22, x19, #0xf
    1034:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1038:	17ffffe0 	b	fb8 <vprintf+0x17c>
    103c:	aa1303f6 	mov	x22, x19
    1040:	8b34c313 	add	x19, x24, w20, sxtw
    1044:	17ffffdd 	b	fb8 <vprintf+0x17c>
      } else if(c == 's'){
    1048:	7101cc1f 	cmp	w0, #0x73
    104c:	54000381 	b.ne	10bc <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
    1050:	37f80214 	tbnz	w20, #31, 1090 <vprintf+0x254>
    1054:	91003e61 	add	x1, x19, #0xf
    1058:	aa1303e0 	mov	x0, x19
    105c:	927df033 	and	x19, x1, #0xfffffffffffffff8
    1060:	f9400016 	ldr	x22, [x0]
          s = "(null)";
    1064:	90000000 	adrp	x0, 1000 <vprintf+0x1c4>
    1068:	9114a400 	add	x0, x0, #0x529
    106c:	f10002df 	cmp	x22, #0x0
    1070:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
    1074:	394002c1 	ldrb	w1, [x22]
    1078:	34fffce1 	cbz	w1, 1014 <vprintf+0x1d8>
          written += putc(fd, *s);
    107c:	2a1703e0 	mov	w0, w23
          s++;
    1080:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
    1084:	97ffff38 	bl	d64 <putc>
    1088:	0b0002b5 	add	w21, w21, w0
          s++;
    108c:	17fffffa 	b	1074 <vprintf+0x238>
        s = va_arg(ap, char*);
    1090:	11002281 	add	w1, w20, #0x8
    1094:	7100003f 	cmp	w1, #0x0
    1098:	540000cd 	b.le	10b0 <vprintf+0x274>
    109c:	91003e62 	add	x2, x19, #0xf
    10a0:	aa1303e0 	mov	x0, x19
    10a4:	2a0103f4 	mov	w20, w1
    10a8:	927df053 	and	x19, x2, #0xfffffffffffffff8
    10ac:	17ffffed 	b	1060 <vprintf+0x224>
    10b0:	8b34c300 	add	x0, x24, w20, sxtw
    10b4:	2a0103f4 	mov	w20, w1
    10b8:	17ffffea 	b	1060 <vprintf+0x224>
      } else if(c == 'c'){
    10bc:	71018c1f 	cmp	w0, #0x63
    10c0:	54000241 	b.ne	1108 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
    10c4:	37f80114 	tbnz	w20, #31, 10e4 <vprintf+0x2a8>
    10c8:	91002e76 	add	x22, x19, #0xb
    10cc:	2a1403fa 	mov	w26, w20
    10d0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    10d4:	39400261 	ldrb	w1, [x19]
    10d8:	2a1703e0 	mov	w0, w23
    10dc:	97ffff22 	bl	d64 <putc>
    10e0:	17ffff82 	b	ee8 <vprintf+0xac>
    10e4:	1100229a 	add	w26, w20, #0x8
    10e8:	7100035f 	cmp	w26, #0x0
    10ec:	5400008d 	b.le	10fc <vprintf+0x2c0>
    10f0:	91002e76 	add	x22, x19, #0xb
    10f4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    10f8:	17fffff7 	b	10d4 <vprintf+0x298>
    10fc:	aa1303f6 	mov	x22, x19
    1100:	8b34c313 	add	x19, x24, w20, sxtw
    1104:	17fffff4 	b	10d4 <vprintf+0x298>
      } else if(c == '%'){
    1108:	7100941f 	cmp	w0, #0x25
    110c:	54ffece0 	b.eq	ea8 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
    1110:	2a1703e0 	mov	w0, w23
    1114:	528004a1 	mov	w1, #0x25                  	// #37
    1118:	97ffff13 	bl	d64 <putc>
    111c:	0b0002b5 	add	w21, w21, w0
    1120:	17ffff62 	b	ea8 <vprintf+0x6c>

0000000000001124 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
    1124:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    1128:	910003fd 	mov	x29, sp
    112c:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
    1130:	910203e2 	add	x2, sp, #0x80
    1134:	a9030be2 	stp	x2, x2, [sp, #48]
    1138:	910143e2 	add	x2, sp, #0x50
    113c:	f90023e2 	str	x2, [sp, #64]
    1140:	128005e2 	mov	w2, #0xffffffd0            	// #-48
    1144:	b9004be2 	str	w2, [sp, #72]
    1148:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
    114c:	a9430fe2 	ldp	x2, x3, [sp, #48]
    1150:	a9010fe2 	stp	x2, x3, [sp, #16]
    1154:	a9440fe2 	ldp	x2, x3, [sp, #64]
    1158:	a9020fe2 	stp	x2, x3, [sp, #32]
    115c:	910043e2 	add	x2, sp, #0x10
{
    1160:	a90617e4 	stp	x4, x5, [sp, #96]
    1164:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
    1168:	97ffff35 	bl	e3c <vprintf>
  va_end(ap);
  return result;
}
    116c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    1170:	d65f03c0 	ret

0000000000001174 <printf>:

int
printf(const char *fmt, ...)
{
    1174:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    1178:	910003fd 	mov	x29, sp
    117c:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
    1180:	910243e1 	add	x1, sp, #0x90
    1184:	a90307e1 	stp	x1, x1, [sp, #48]
    1188:	910143e1 	add	x1, sp, #0x50
    118c:	f90023e1 	str	x1, [sp, #64]
    1190:	128006e1 	mov	w1, #0xffffffc8            	// #-56
    1194:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
    1198:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
    119c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
    11a0:	52800020 	mov	w0, #0x1                   	// #1
{
    11a4:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
    11a8:	a9430fe2 	ldp	x2, x3, [sp, #48]
    11ac:	a9010fe2 	stp	x2, x3, [sp, #16]
    11b0:	a9440fe2 	ldp	x2, x3, [sp, #64]
    11b4:	a9020fe2 	stp	x2, x3, [sp, #32]
    11b8:	910043e2 	add	x2, sp, #0x10
{
    11bc:	a9079be5 	stp	x5, x6, [sp, #120]
    11c0:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
    11c4:	97ffff1e 	bl	e3c <vprintf>
  va_end(ap);
  return result;
}
    11c8:	a8c97bfd 	ldp	x29, x30, [sp], #144
    11cc:	d65f03c0 	ret
