
user/_kill:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char **argv)
{
   0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
  int i;

  if(argc < 2){
   c:	7100041f 	cmp	w0, #0x1
  10:	540000ec 	b.gt	2c <main+0x2c>
    fprintf(2, "usage: kill pid...\n");
  14:	90000001 	adrp	x1, 0 <main>
  18:	912cf021 	add	x1, x1, #0xb3c
  1c:	52800040 	mov	w0, #0x2                   	// #2
  20:	9400029c 	bl	a90 <fprintf>
    exit(1);
  24:	52800020 	mov	w0, #0x1                   	// #1
  }
  for(i=1; i<argc; i++)
    kill(atoi(argv[i]));
  exit(0);
  28:	940000d2 	bl	370 <exit>
  2c:	2a0003f4 	mov	w20, w0
  if(argc < 2){
  30:	d2800033 	mov	x19, #0x1                   	// #1
    kill(atoi(argv[i]));
  34:	f8737820 	ldr	x0, [x1, x19, lsl #3]
  for(i=1; i<argc; i++)
  38:	91000673 	add	x19, x19, #0x1
    kill(atoi(argv[i]));
  3c:	f90017e1 	str	x1, [sp, #40]
  40:	94000097 	bl	29c <atoi>
  44:	940000dd 	bl	3b8 <kill>
  for(i=1; i<argc; i++)
  48:	f94017e1 	ldr	x1, [sp, #40]
  4c:	6b13029f 	cmp	w20, w19
  50:	54ffff2c 	b.gt	34 <main+0x34>
  exit(0);
  54:	52800000 	mov	w0, #0x0                   	// #0
  58:	17fffff4 	b	28 <main+0x28>

000000000000005c <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  5c:	d2800002 	mov	x2, #0x0                   	// #0
  60:	38626823 	ldrb	w3, [x1, x2]
  64:	38226803 	strb	w3, [x0, x2]
  68:	91000442 	add	x2, x2, #0x1
  6c:	35ffffa3 	cbnz	w3, 60 <strcpy+0x4>
    ;
  return os;
}
  70:	d65f03c0 	ret

0000000000000074 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
  74:	d2800003 	mov	x3, #0x0                   	// #0
  78:	4b030044 	sub	w4, w2, w3
  7c:	7100009f 	cmp	w4, #0x0
  80:	5400006d 	b.le	8c <strncpy+0x18>
  84:	38636825 	ldrb	w5, [x1, x3]
  88:	350000e5 	cbnz	w5, a4 <strncpy+0x30>
  8c:	8b030003 	add	x3, x0, x3
  90:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
  94:	4b010082 	sub	w2, w4, w1
  98:	7100005f 	cmp	w2, #0x0
  9c:	540000ac 	b.gt	b0 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
  a0:	d65f03c0 	ret
    *s++ = *t++;
  a4:	38236805 	strb	w5, [x0, x3]
    n--;
  a8:	91000463 	add	x3, x3, #0x1
  ac:	17fffff3 	b	78 <strncpy+0x4>
    *s++ = 0;
  b0:	3821687f 	strb	wzr, [x3, x1]
  b4:	91000421 	add	x1, x1, #0x1
  b8:	17fffff7 	b	94 <strncpy+0x20>

00000000000000bc <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
  bc:	aa0003e2 	mov	x2, x0
  c0:	39400043 	ldrb	w3, [x2]
  c4:	aa0203e4 	mov	x4, x2
    s++;
  c8:	91000442 	add	x2, x2, #0x1
  while(*s)
  cc:	35ffffa3 	cbnz	w3, c0 <strcat+0x4>
  d0:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
  d4:	38626823 	ldrb	w3, [x1, x2]
  d8:	38226883 	strb	w3, [x4, x2]
  dc:	91000442 	add	x2, x2, #0x1
  e0:	35ffffa3 	cbnz	w3, d4 <strcat+0x18>
    ;
  return os;
}
  e4:	d65f03c0 	ret

00000000000000e8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
  e8:	d2800002 	mov	x2, #0x0                   	// #0
  ec:	38626803 	ldrb	w3, [x0, x2]
  f0:	38626824 	ldrb	w4, [x1, x2]
  f4:	34000083 	cbz	w3, 104 <strcmp+0x1c>
  f8:	91000442 	add	x2, x2, #0x1
  fc:	6b04007f 	cmp	w3, w4
 100:	54ffff60 	b.eq	ec <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 104:	4b040060 	sub	w0, w3, w4
 108:	d65f03c0 	ret

000000000000010c <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 10c:	340001c2 	cbz	w2, 144 <strncmp+0x38>
 110:	39400003 	ldrb	w3, [x0]
 114:	34000083 	cbz	w3, 124 <strncmp+0x18>
 118:	39400024 	ldrb	w4, [x1]
 11c:	6b03009f 	cmp	w4, w3
 120:	540000a0 	b.eq	134 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 124:	39400000 	ldrb	w0, [x0]
 128:	39400021 	ldrb	w1, [x1]
 12c:	4b010000 	sub	w0, w0, w1
}
 130:	d65f03c0 	ret
    n--, p++, q++;
 134:	51000442 	sub	w2, w2, #0x1
 138:	91000400 	add	x0, x0, #0x1
 13c:	91000421 	add	x1, x1, #0x1
 140:	17fffff3 	b	10c <strncmp>
    return 0;
 144:	52800000 	mov	w0, #0x0                   	// #0
 148:	17fffffa 	b	130 <strncmp+0x24>

000000000000014c <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 14c:	d1000402 	sub	x2, x0, #0x1
 150:	d2800001 	mov	x1, #0x0                   	// #0
 154:	aa0103e0 	mov	x0, x1
 158:	91000421 	add	x1, x1, #0x1
 15c:	38616843 	ldrb	w3, [x2, x1]
 160:	35ffffa3 	cbnz	w3, 154 <strlen+0x8>
    ;
  return n;
}
 164:	d65f03c0 	ret

0000000000000168 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 168:	d1000403 	sub	x3, x0, #0x1
 16c:	d2800002 	mov	x2, #0x0                   	// #0
 170:	2a0203e0 	mov	w0, w2
 174:	6b02003f 	cmp	w1, w2
 178:	54000089 	b.ls	188 <strnlen+0x20>  // b.plast
 17c:	91000442 	add	x2, x2, #0x1
 180:	38626864 	ldrb	w4, [x3, x2]
 184:	35ffff64 	cbnz	w4, 170 <strnlen+0x8>
    n++;
  return n;
}
 188:	d65f03c0 	ret

000000000000018c <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 18c:	d2800003 	mov	x3, #0x0                   	// #0
 190:	6b03005f 	cmp	w2, w3
 194:	54000048 	b.hi	19c <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 198:	d65f03c0 	ret
    cdst[i] = c;
 19c:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 1a0:	91000463 	add	x3, x3, #0x1
 1a4:	17fffffb 	b	190 <memset+0x4>

00000000000001a8 <strchr>:

char*
strchr(const char *s, char c)
{
 1a8:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 1ac:	39400002 	ldrb	w2, [x0]
 1b0:	35000062 	cbnz	w2, 1bc <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 1b4:	d2800000 	mov	x0, #0x0                   	// #0
}
 1b8:	d65f03c0 	ret
    if(*s == c)
 1bc:	6b01005f 	cmp	w2, w1
 1c0:	54ffffc0 	b.eq	1b8 <strchr+0x10>  // b.none
  for(; *s; s++)
 1c4:	91000400 	add	x0, x0, #0x1
 1c8:	17fffff9 	b	1ac <strchr+0x4>

00000000000001cc <gets>:

char*
gets(char *buf, int max)
{
 1cc:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 1d0:	910003fd 	mov	x29, sp
 1d4:	a90153f3 	stp	x19, x20, [sp, #16]
 1d8:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1dc:	d2800014 	mov	x20, #0x0                   	// #0
{
 1e0:	f9001bf7 	str	x23, [sp, #48]
 1e4:	2a0103f7 	mov	w23, w1
 1e8:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 1ec:	11000695 	add	w21, w20, #0x1
 1f0:	2a1403f6 	mov	w22, w20
 1f4:	6b1702bf 	cmp	w21, w23
 1f8:	540000ea 	b.ge	214 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 1fc:	91013fe1 	add	x1, sp, #0x4f
 200:	52800022 	mov	w2, #0x1                   	// #1
 204:	52800000 	mov	w0, #0x0                   	// #0
 208:	94000063 	bl	394 <read>
    if(cc < 1)
 20c:	7100001f 	cmp	w0, #0x0
 210:	5400012c 	b.gt	234 <gets+0x68>
  for(i=0; i+1 < max; ){
 214:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 218:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 21c:	aa1303e0 	mov	x0, x19
 220:	f9401bf7 	ldr	x23, [sp, #48]
 224:	a94153f3 	ldp	x19, x20, [sp, #16]
 228:	a9425bf5 	ldp	x21, x22, [sp, #32]
 22c:	a8c57bfd 	ldp	x29, x30, [sp], #80
 230:	d65f03c0 	ret
    buf[i++] = c;
 234:	39413fe0 	ldrb	w0, [sp, #79]
 238:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 23c:	91000694 	add	x20, x20, #0x1
 240:	7100281f 	cmp	w0, #0xa
 244:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 248:	54fffd21 	b.ne	1ec <gets+0x20>  // b.any
 24c:	17fffff3 	b	218 <gets+0x4c>

0000000000000250 <stat>:

int
stat(const char *n, struct stat *st)
{
 250:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 254:	910003fd 	mov	x29, sp
 258:	a90153f3 	stp	x19, x20, [sp, #16]
 25c:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 260:	52800001 	mov	w1, #0x0                   	// #0
 264:	9400005b 	bl	3d0 <open>
  if(fd < 0)
 268:	37f80160 	tbnz	w0, #31, 294 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 26c:	aa1303e1 	mov	x1, x19
 270:	2a0003f4 	mov	w20, w0
 274:	94000060 	bl	3f4 <fstat>
 278:	2a0003f3 	mov	w19, w0
  close(fd);
 27c:	2a1403e0 	mov	w0, w20
 280:	9400004b 	bl	3ac <close>
  return r;
}
 284:	2a1303e0 	mov	w0, w19
 288:	a94153f3 	ldp	x19, x20, [sp, #16]
 28c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 290:	d65f03c0 	ret
    return -1;
 294:	12800013 	mov	w19, #0xffffffff            	// #-1
 298:	17fffffb 	b	284 <stat+0x34>

000000000000029c <atoi>:

int
atoi(const char *s)
{
 29c:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 2a0:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 2a4:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 2a8:	39400043 	ldrb	w3, [x2]
 2ac:	5100c061 	sub	w1, w3, #0x30
 2b0:	12001c21 	and	w1, w1, #0xff
 2b4:	7100243f 	cmp	w1, #0x9
 2b8:	54000049 	b.ls	2c0 <atoi+0x24>  // b.plast
  return n;
}
 2bc:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 2c0:	1b040c01 	madd	w1, w0, w4, w3
 2c4:	91000442 	add	x2, x2, #0x1
 2c8:	5100c020 	sub	w0, w1, #0x30
 2cc:	17fffff7 	b	2a8 <atoi+0xc>

00000000000002d0 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2d0:	eb01001f 	cmp	x0, x1
 2d4:	54000263 	b.cc	320 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 2d8:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 2dc:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 2e0:	d2800003 	mov	x3, #0x0                   	// #0
 2e4:	d1000463 	sub	x3, x3, #0x1
 2e8:	11000464 	add	w4, w3, #0x1
 2ec:	0b020084 	add	w4, w4, w2
 2f0:	7100009f 	cmp	w4, #0x0
 2f4:	5400014d 	b.le	31c <memmove+0x4c>
      *--dst = *--src;
 2f8:	38636824 	ldrb	w4, [x1, x3]
 2fc:	382368a4 	strb	w4, [x5, x3]
 300:	17fffff9 	b	2e4 <memmove+0x14>
      *dst++ = *src++;
 304:	38636824 	ldrb	w4, [x1, x3]
 308:	38236804 	strb	w4, [x0, x3]
 30c:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 310:	4b030044 	sub	w4, w2, w3
 314:	7100009f 	cmp	w4, #0x0
 318:	54ffff6c 	b.gt	304 <memmove+0x34>
  }
  return vdst;
}
 31c:	d65f03c0 	ret
 320:	d2800003 	mov	x3, #0x0                   	// #0
 324:	17fffffb 	b	310 <memmove+0x40>

0000000000000328 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 328:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 32c:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 330:	d2800004 	mov	x4, #0x0                   	// #0
 334:	eb02009f 	cmp	x4, x2
 338:	54000061 	b.ne	344 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 33c:	52800000 	mov	w0, #0x0                   	// #0
 340:	14000007 	b	35c <memcmp+0x34>
    if (*p1 != *p2) {
 344:	38646803 	ldrb	w3, [x0, x4]
 348:	91000484 	add	x4, x4, #0x1
 34c:	38646825 	ldrb	w5, [x1, x4]
 350:	6b05007f 	cmp	w3, w5
 354:	54ffff00 	b.eq	334 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 358:	4b050060 	sub	w0, w3, w5
}
 35c:	d65f03c0 	ret

0000000000000360 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 360:	17ffffdc 	b	2d0 <memmove>

0000000000000364 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 364:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 368:	d4000001 	svc	#0x0
 ret
 36c:	d65f03c0 	ret

0000000000000370 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 370:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 374:	d4000001 	svc	#0x0
 ret
 378:	d65f03c0 	ret

000000000000037c <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 37c:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 380:	d4000001 	svc	#0x0
 ret
 384:	d65f03c0 	ret

0000000000000388 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 388:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 38c:	d4000001 	svc	#0x0
 ret
 390:	d65f03c0 	ret

0000000000000394 <read>:
.global read
read:
 mov x7, #SYS_read
 394:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 398:	d4000001 	svc	#0x0
 ret
 39c:	d65f03c0 	ret

00000000000003a0 <write>:
.global write
write:
 mov x7, #SYS_write
 3a0:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 3a4:	d4000001 	svc	#0x0
 ret
 3a8:	d65f03c0 	ret

00000000000003ac <close>:
.global close
close:
 mov x7, #SYS_close
 3ac:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 3b0:	d4000001 	svc	#0x0
 ret
 3b4:	d65f03c0 	ret

00000000000003b8 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 3b8:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 3bc:	d4000001 	svc	#0x0
 ret
 3c0:	d65f03c0 	ret

00000000000003c4 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 3c4:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 3c8:	d4000001 	svc	#0x0
 ret
 3cc:	d65f03c0 	ret

00000000000003d0 <open>:
.global open
open:
 mov x7, #SYS_open
 3d0:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 3d4:	d4000001 	svc	#0x0
 ret
 3d8:	d65f03c0 	ret

00000000000003dc <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 3dc:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 3e0:	d4000001 	svc	#0x0
 ret
 3e4:	d65f03c0 	ret

00000000000003e8 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 3e8:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 3ec:	d4000001 	svc	#0x0
 ret
 3f0:	d65f03c0 	ret

00000000000003f4 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 3f4:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 3f8:	d4000001 	svc	#0x0
 ret
 3fc:	d65f03c0 	ret

0000000000000400 <link>:
.global link
link:
 mov x7, #SYS_link
 400:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 404:	d4000001 	svc	#0x0
 ret
 408:	d65f03c0 	ret

000000000000040c <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 40c:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 410:	d4000001 	svc	#0x0
 ret
 414:	d65f03c0 	ret

0000000000000418 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 418:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 41c:	d4000001 	svc	#0x0
 ret
 420:	d65f03c0 	ret

0000000000000424 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 424:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 428:	d4000001 	svc	#0x0
 ret
 42c:	d65f03c0 	ret

0000000000000430 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 430:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 434:	d4000001 	svc	#0x0
 ret
 438:	d65f03c0 	ret

000000000000043c <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 43c:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 440:	d4000001 	svc	#0x0
 ret
 444:	d65f03c0 	ret

0000000000000448 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 448:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 44c:	d4000001 	svc	#0x0
 ret
 450:	d65f03c0 	ret

0000000000000454 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 454:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 458:	d4000001 	svc	#0x0
 ret
 45c:	d65f03c0 	ret

0000000000000460 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 460:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 464:	d4000001 	svc	#0x0
 ret
 468:	d65f03c0 	ret

000000000000046c <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 46c:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 470:	d4000001 	svc	#0x0
 ret
 474:	d65f03c0 	ret

0000000000000478 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 478:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 47c:	d4000001 	svc	#0x0
 ret
 480:	d65f03c0 	ret

0000000000000484 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 484:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 488:	d4000001 	svc	#0x0
 ret
 48c:	d65f03c0 	ret

0000000000000490 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 490:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 494:	d4000001 	svc	#0x0
 ret
 498:	d65f03c0 	ret

000000000000049c <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 49c:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 4a0:	d4000001 	svc	#0x0
 ret
 4a4:	d65f03c0 	ret

00000000000004a8 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 4a8:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 4ac:	d4000001 	svc	#0x0
 ret
 4b0:	d65f03c0 	ret

00000000000004b4 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 4b4:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 4b8:	d4000001 	svc	#0x0
 ret
 4bc:	d65f03c0 	ret

00000000000004c0 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 4c0:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 4c4:	d4000001 	svc	#0x0
 ret
 4c8:	d65f03c0 	ret

00000000000004cc <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 4cc:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 4d0:	d4000001 	svc	#0x0
 ret
 4d4:	d65f03c0 	ret

00000000000004d8 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 4d8:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 4dc:	d4000001 	svc	#0x0
 ret
 4e0:	d65f03c0 	ret

00000000000004e4 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 4e4:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 4e8:	d4000001 	svc	#0x0
 ret
 4ec:	d65f03c0 	ret

00000000000004f0 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 4f0:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 4f4:	d4000001 	svc	#0x0
 ret
 4f8:	d65f03c0 	ret

00000000000004fc <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 4fc:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 500:	d4000001 	svc	#0x0
 ret
 504:	d65f03c0 	ret

0000000000000508 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 508:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 50c:	d4000001 	svc	#0x0
 ret
 510:	d65f03c0 	ret

0000000000000514 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 514:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 518:	d4000001 	svc	#0x0
 ret
 51c:	d65f03c0 	ret

0000000000000520 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 520:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 524:	d4000001 	svc	#0x0
 ret
 528:	d65f03c0 	ret

000000000000052c <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 52c:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 530:	d4000001 	svc	#0x0
 ret
 534:	d65f03c0 	ret

0000000000000538 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 538:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 53c:	d4000001 	svc	#0x0
 ret
 540:	d65f03c0 	ret

0000000000000544 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 544:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 548:	d4000001 	svc	#0x0
 ret
 54c:	d65f03c0 	ret

0000000000000550 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 550:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 554:	d4000001 	svc	#0x0
 ret
 558:	d65f03c0 	ret

000000000000055c <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 55c:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 560:	d4000001 	svc	#0x0
 ret
 564:	d65f03c0 	ret

0000000000000568 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 568:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 56c:	d4000001 	svc	#0x0
 ret
 570:	d65f03c0 	ret

0000000000000574 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 574:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 578:	d4000001 	svc	#0x0
 ret
 57c:	d65f03c0 	ret

0000000000000580 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 580:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 584:	d4000001 	svc	#0x0
 ret
 588:	d65f03c0 	ret

000000000000058c <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 58c:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 590:	d4000001 	svc	#0x0
 ret
 594:	d65f03c0 	ret

0000000000000598 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 598:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 59c:	d4000001 	svc	#0x0
 ret
 5a0:	d65f03c0 	ret

00000000000005a4 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 5a4:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 5a8:	d4000001 	svc	#0x0
 ret
 5ac:	d65f03c0 	ret

00000000000005b0 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 5b0:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 5b4:	d4000001 	svc	#0x0
 ret
 5b8:	d65f03c0 	ret

00000000000005bc <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 5bc:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 5c0:	d4000001 	svc	#0x0
 ret
 5c4:	d65f03c0 	ret

00000000000005c8 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 5c8:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 5cc:	d4000001 	svc	#0x0
 ret
 5d0:	d65f03c0 	ret

00000000000005d4 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 5d4:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 5d8:	d4000001 	svc	#0x0
 ret
 5dc:	d65f03c0 	ret

00000000000005e0 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 5e0:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 5e4:	d4000001 	svc	#0x0
 ret
 5e8:	d65f03c0 	ret

00000000000005ec <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 5ec:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 5f0:	d4000001 	svc	#0x0
 ret
 5f4:	d65f03c0 	ret

00000000000005f8 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 5f8:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 5fc:	d4000001 	svc	#0x0
 ret
 600:	d65f03c0 	ret

0000000000000604 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 604:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 608:	d4000001 	svc	#0x0
 ret
 60c:	d65f03c0 	ret

0000000000000610 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 610:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 614:	d4000001 	svc	#0x0
 ret
 618:	d65f03c0 	ret

000000000000061c <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 61c:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 620:	d4000001 	svc	#0x0
 ret
 624:	d65f03c0 	ret

0000000000000628 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 628:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 62c:	d4000001 	svc	#0x0
 ret
 630:	d65f03c0 	ret

0000000000000634 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 634:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 638:	d4000001 	svc	#0x0
 ret
 63c:	d65f03c0 	ret

0000000000000640 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 640:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 644:	d4000001 	svc	#0x0
 ret
 648:	d65f03c0 	ret

000000000000064c <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 64c:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 650:	d4000001 	svc	#0x0
 ret
 654:	d65f03c0 	ret

0000000000000658 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 658:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 65c:	d4000001 	svc	#0x0
 ret
 660:	d65f03c0 	ret

0000000000000664 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 664:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 668:	d4000001 	svc	#0x0
 ret
 66c:	d65f03c0 	ret

0000000000000670 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 670:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 674:	d4000001 	svc	#0x0
 ret
 678:	d65f03c0 	ret

000000000000067c <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 67c:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 680:	d4000001 	svc	#0x0
 ret
 684:	d65f03c0 	ret

0000000000000688 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 688:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 68c:	d4000001 	svc	#0x0
 ret
 690:	d65f03c0 	ret

0000000000000694 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 694:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 698:	d4000001 	svc	#0x0
 ret
 69c:	d65f03c0 	ret

00000000000006a0 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 6a0:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 6a4:	d4000001 	svc	#0x0
 ret
 6a8:	d65f03c0 	ret

00000000000006ac <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 6ac:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 6b0:	d4000001 	svc	#0x0
 ret
 6b4:	d65f03c0 	ret

00000000000006b8 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 6b8:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 6bc:	d4000001 	svc	#0x0
 ret
 6c0:	d65f03c0 	ret

00000000000006c4 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 6c4:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 6c8:	d4000001 	svc	#0x0
 ret
 6cc:	d65f03c0 	ret

00000000000006d0 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 6d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 6d4:	52800022 	mov	w2, #0x1                   	// #1
{
 6d8:	910003fd 	mov	x29, sp
 6dc:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 6e0:	91007fe1 	add	x1, sp, #0x1f
 6e4:	97ffff2f 	bl	3a0 <write>
 6e8:	7100041f 	cmp	w0, #0x1
}
 6ec:	1a9f17e0 	cset	w0, eq	// eq = none
 6f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
 6f4:	d65f03c0 	ret

00000000000006f8 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 6f8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 6fc:	910003fd 	mov	x29, sp
 700:	a90153f3 	stp	x19, x20, [sp, #16]
 704:	a9025bf5 	stp	x21, x22, [sp, #32]
 708:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 70c:	6a417c7f 	tst	w3, w1, lsr #31
 710:	54000300 	b.eq	770 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 714:	4b0103e1 	neg	w1, w1
    neg = 1;
 718:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 71c:	90000003 	adrp	x3, 0 <main>
 720:	912d5c63 	add	x3, x3, #0xb57
 724:	9100c3f5 	add	x21, sp, #0x30
 728:	d2800000 	mov	x0, #0x0                   	// #0
 72c:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 730:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 734:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 738:	2a0403e1 	mov	w1, w4
 73c:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 740:	38666866 	ldrb	w6, [x3, x6]
 744:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 748:	91000400 	add	x0, x0, #0x1
 74c:	54ffff09 	b.ls	72c <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 750:	11000493 	add	w19, w4, #0x1
  if(neg)
 754:	34000085 	cbz	w5, 764 <printint+0x6c>
    buf[i++] = '-';
 758:	528005a0 	mov	w0, #0x2d                  	// #45
 75c:	38334aa0 	strb	w0, [x21, w19, uxtw]
 760:	11000893 	add	w19, w4, #0x2
 764:	51000673 	sub	w19, w19, #0x1
 768:	52800014 	mov	w20, #0x0                   	// #0
 76c:	14000008 	b	78c <printint+0x94>
  neg = 0;
 770:	52800005 	mov	w5, #0x0                   	// #0
 774:	17ffffea 	b	71c <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 778:	38736aa1 	ldrb	w1, [x21, x19]
 77c:	2a1603e0 	mov	w0, w22
 780:	d1000673 	sub	x19, x19, #0x1
 784:	97ffffd3 	bl	6d0 <putc>
 788:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 78c:	3100067f 	cmn	w19, #0x1
 790:	54ffff41 	b.ne	778 <printint+0x80>  // b.any
  return written;
}
 794:	a9425bf5 	ldp	x21, x22, [sp, #32]
 798:	2a1403e0 	mov	w0, w20
 79c:	a94153f3 	ldp	x19, x20, [sp, #16]
 7a0:	a8c47bfd 	ldp	x29, x30, [sp], #64
 7a4:	d65f03c0 	ret

00000000000007a8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 7a8:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 7ac:	910003fd 	mov	x29, sp
 7b0:	a90153f3 	stp	x19, x20, [sp, #16]
 7b4:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 7b8:	52800015 	mov	w21, #0x0                   	// #0
{
 7bc:	a90363f7 	stp	x23, x24, [sp, #48]
 7c0:	2a0003f7 	mov	w23, w0
 7c4:	a9046bf9 	stp	x25, x26, [sp, #64]
 7c8:	aa0103f9 	mov	x25, x1

  state = 0;
 7cc:	52800001 	mov	w1, #0x0                   	// #0
{
 7d0:	a90573fb 	stp	x27, x28, [sp, #80]
 7d4:	a9406053 	ldp	x19, x24, [x2]
 7d8:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 7dc:	39400320 	ldrb	w0, [x25]
 7e0:	35000120 	cbnz	w0, 804 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 7e4:	2a1503e0 	mov	w0, w21
 7e8:	a94153f3 	ldp	x19, x20, [sp, #16]
 7ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
 7f0:	a94363f7 	ldp	x23, x24, [sp, #48]
 7f4:	a9446bf9 	ldp	x25, x26, [sp, #64]
 7f8:	a94573fb 	ldp	x27, x28, [sp, #80]
 7fc:	a8c67bfd 	ldp	x29, x30, [sp], #96
 800:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 804:	2a0003f6 	mov	w22, w0
    if(state == 0){
 808:	35000101 	cbnz	w1, 828 <vprintf+0x80>
      if(c == '%'){
 80c:	7100941f 	cmp	w0, #0x25
 810:	54000ba0 	b.eq	984 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 814:	2a1603e1 	mov	w1, w22
 818:	2a1703e0 	mov	w0, w23
 81c:	97ffffad 	bl	6d0 <putc>
 820:	0b0002b5 	add	w21, w21, w0
 824:	14000057 	b	980 <vprintf+0x1d8>
      if(c == 'd'){
 828:	7101901f 	cmp	w0, #0x64
 82c:	540002a1 	b.ne	880 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 830:	37f80174 	tbnz	w20, #31, 85c <vprintf+0xb4>
 834:	91002e76 	add	x22, x19, #0xb
 838:	2a1403fa 	mov	w26, w20
 83c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 840:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 844:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 848:	b9400261 	ldr	w1, [x19]
 84c:	2a1703e0 	mov	w0, w23
 850:	97ffffaa 	bl	6f8 <printint>
        written += putc(fd, va_arg(ap, uint));
 854:	0b0002b5 	add	w21, w21, w0
 858:	14000048 	b	978 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 85c:	1100229a 	add	w26, w20, #0x8
 860:	7100035f 	cmp	w26, #0x0
 864:	5400008d 	b.le	874 <vprintf+0xcc>
 868:	91002e76 	add	x22, x19, #0xb
 86c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 870:	17fffff4 	b	840 <vprintf+0x98>
 874:	aa1303f6 	mov	x22, x19
 878:	8b34c313 	add	x19, x24, w20, sxtw
 87c:	17fffff1 	b	840 <vprintf+0x98>
      } else if(c == 'l') {
 880:	7101b01f 	cmp	w0, #0x6c
 884:	54000201 	b.ne	8c4 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 888:	37f800d4 	tbnz	w20, #31, 8a0 <vprintf+0xf8>
 88c:	91003e76 	add	x22, x19, #0xf
 890:	2a1403fa 	mov	w26, w20
 894:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 898:	52800003 	mov	w3, #0x0                   	// #0
 89c:	17ffffea 	b	844 <vprintf+0x9c>
 8a0:	1100229a 	add	w26, w20, #0x8
 8a4:	7100035f 	cmp	w26, #0x0
 8a8:	5400008d 	b.le	8b8 <vprintf+0x110>
 8ac:	91003e76 	add	x22, x19, #0xf
 8b0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8b4:	17fffff9 	b	898 <vprintf+0xf0>
 8b8:	aa1303f6 	mov	x22, x19
 8bc:	8b34c313 	add	x19, x24, w20, sxtw
 8c0:	17fffff6 	b	898 <vprintf+0xf0>
      } else if(c == 'x') {
 8c4:	7101e01f 	cmp	w0, #0x78
 8c8:	54000221 	b.ne	90c <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 8cc:	37f800f4 	tbnz	w20, #31, 8e8 <vprintf+0x140>
 8d0:	91002e76 	add	x22, x19, #0xb
 8d4:	2a1403fa 	mov	w26, w20
 8d8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8dc:	52800003 	mov	w3, #0x0                   	// #0
 8e0:	52800202 	mov	w2, #0x10                  	// #16
 8e4:	17ffffd9 	b	848 <vprintf+0xa0>
 8e8:	1100229a 	add	w26, w20, #0x8
 8ec:	7100035f 	cmp	w26, #0x0
 8f0:	5400008d 	b.le	900 <vprintf+0x158>
 8f4:	91002e76 	add	x22, x19, #0xb
 8f8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8fc:	17fffff8 	b	8dc <vprintf+0x134>
 900:	aa1303f6 	mov	x22, x19
 904:	8b34c313 	add	x19, x24, w20, sxtw
 908:	17fffff5 	b	8dc <vprintf+0x134>
      } else if(c == 'p') {
 90c:	7101c01f 	cmp	w0, #0x70
 910:	54000521 	b.ne	9b4 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 914:	37f803f4 	tbnz	w20, #31, 990 <vprintf+0x1e8>
 918:	91003e76 	add	x22, x19, #0xf
 91c:	2a1403fa 	mov	w26, w20
 920:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 924:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 928:	52800601 	mov	w1, #0x30                  	// #48
 92c:	2a1703e0 	mov	w0, w23
 930:	97ffff68 	bl	6d0 <putc>
 934:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 938:	9000001c 	adrp	x28, 0 <main>
 93c:	912d5f9c 	add	x28, x28, #0xb57
  written += putc(fd, 'x');
 940:	2a1703e0 	mov	w0, w23
 944:	52800f01 	mov	w1, #0x78                  	// #120
 948:	97ffff62 	bl	6d0 <putc>
 94c:	0b000273 	add	w19, w19, w0
 950:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 954:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 958:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 95c:	38606b81 	ldrb	w1, [x28, x0]
 960:	2a1703e0 	mov	w0, w23
 964:	97ffff5b 	bl	6d0 <putc>
 968:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 96c:	71000694 	subs	w20, w20, #0x1
 970:	54ffff21 	b.ne	954 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 974:	0b1302b5 	add	w21, w21, w19
 978:	2a1a03f4 	mov	w20, w26
 97c:	aa1603f3 	mov	x19, x22
      state = 0;
 980:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 984:	91000739 	add	x25, x25, #0x1
  state = 0;
 988:	2a1603e1 	mov	w1, w22
 98c:	17ffff94 	b	7dc <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 990:	1100229a 	add	w26, w20, #0x8
 994:	7100035f 	cmp	w26, #0x0
 998:	5400008d 	b.le	9a8 <vprintf+0x200>
 99c:	91003e76 	add	x22, x19, #0xf
 9a0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9a4:	17ffffe0 	b	924 <vprintf+0x17c>
 9a8:	aa1303f6 	mov	x22, x19
 9ac:	8b34c313 	add	x19, x24, w20, sxtw
 9b0:	17ffffdd 	b	924 <vprintf+0x17c>
      } else if(c == 's'){
 9b4:	7101cc1f 	cmp	w0, #0x73
 9b8:	54000381 	b.ne	a28 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 9bc:	37f80214 	tbnz	w20, #31, 9fc <vprintf+0x254>
 9c0:	91003e61 	add	x1, x19, #0xf
 9c4:	aa1303e0 	mov	x0, x19
 9c8:	927df033 	and	x19, x1, #0xfffffffffffffff8
 9cc:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 9d0:	90000000 	adrp	x0, 0 <main>
 9d4:	912d4000 	add	x0, x0, #0xb50
 9d8:	f10002df 	cmp	x22, #0x0
 9dc:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 9e0:	394002c1 	ldrb	w1, [x22]
 9e4:	34fffce1 	cbz	w1, 980 <vprintf+0x1d8>
          written += putc(fd, *s);
 9e8:	2a1703e0 	mov	w0, w23
          s++;
 9ec:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 9f0:	97ffff38 	bl	6d0 <putc>
 9f4:	0b0002b5 	add	w21, w21, w0
          s++;
 9f8:	17fffffa 	b	9e0 <vprintf+0x238>
        s = va_arg(ap, char*);
 9fc:	11002281 	add	w1, w20, #0x8
 a00:	7100003f 	cmp	w1, #0x0
 a04:	540000cd 	b.le	a1c <vprintf+0x274>
 a08:	91003e62 	add	x2, x19, #0xf
 a0c:	aa1303e0 	mov	x0, x19
 a10:	2a0103f4 	mov	w20, w1
 a14:	927df053 	and	x19, x2, #0xfffffffffffffff8
 a18:	17ffffed 	b	9cc <vprintf+0x224>
 a1c:	8b34c300 	add	x0, x24, w20, sxtw
 a20:	2a0103f4 	mov	w20, w1
 a24:	17ffffea 	b	9cc <vprintf+0x224>
      } else if(c == 'c'){
 a28:	71018c1f 	cmp	w0, #0x63
 a2c:	54000241 	b.ne	a74 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 a30:	37f80114 	tbnz	w20, #31, a50 <vprintf+0x2a8>
 a34:	91002e76 	add	x22, x19, #0xb
 a38:	2a1403fa 	mov	w26, w20
 a3c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a40:	39400261 	ldrb	w1, [x19]
 a44:	2a1703e0 	mov	w0, w23
 a48:	97ffff22 	bl	6d0 <putc>
 a4c:	17ffff82 	b	854 <vprintf+0xac>
 a50:	1100229a 	add	w26, w20, #0x8
 a54:	7100035f 	cmp	w26, #0x0
 a58:	5400008d 	b.le	a68 <vprintf+0x2c0>
 a5c:	91002e76 	add	x22, x19, #0xb
 a60:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a64:	17fffff7 	b	a40 <vprintf+0x298>
 a68:	aa1303f6 	mov	x22, x19
 a6c:	8b34c313 	add	x19, x24, w20, sxtw
 a70:	17fffff4 	b	a40 <vprintf+0x298>
      } else if(c == '%'){
 a74:	7100941f 	cmp	w0, #0x25
 a78:	54ffece0 	b.eq	814 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 a7c:	2a1703e0 	mov	w0, w23
 a80:	528004a1 	mov	w1, #0x25                  	// #37
 a84:	97ffff13 	bl	6d0 <putc>
 a88:	0b0002b5 	add	w21, w21, w0
 a8c:	17ffff62 	b	814 <vprintf+0x6c>

0000000000000a90 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 a90:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 a94:	910003fd 	mov	x29, sp
 a98:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 a9c:	910203e2 	add	x2, sp, #0x80
 aa0:	a9030be2 	stp	x2, x2, [sp, #48]
 aa4:	910143e2 	add	x2, sp, #0x50
 aa8:	f90023e2 	str	x2, [sp, #64]
 aac:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 ab0:	b9004be2 	str	w2, [sp, #72]
 ab4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 ab8:	a9430fe2 	ldp	x2, x3, [sp, #48]
 abc:	a9010fe2 	stp	x2, x3, [sp, #16]
 ac0:	a9440fe2 	ldp	x2, x3, [sp, #64]
 ac4:	a9020fe2 	stp	x2, x3, [sp, #32]
 ac8:	910043e2 	add	x2, sp, #0x10
{
 acc:	a90617e4 	stp	x4, x5, [sp, #96]
 ad0:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 ad4:	97ffff35 	bl	7a8 <vprintf>
  va_end(ap);
  return result;
}
 ad8:	a8c87bfd 	ldp	x29, x30, [sp], #128
 adc:	d65f03c0 	ret

0000000000000ae0 <printf>:

int
printf(const char *fmt, ...)
{
 ae0:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 ae4:	910003fd 	mov	x29, sp
 ae8:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 aec:	910243e1 	add	x1, sp, #0x90
 af0:	a90307e1 	stp	x1, x1, [sp, #48]
 af4:	910143e1 	add	x1, sp, #0x50
 af8:	f90023e1 	str	x1, [sp, #64]
 afc:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 b00:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 b04:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 b08:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 b0c:	52800020 	mov	w0, #0x1                   	// #1
{
 b10:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 b14:	a9430fe2 	ldp	x2, x3, [sp, #48]
 b18:	a9010fe2 	stp	x2, x3, [sp, #16]
 b1c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 b20:	a9020fe2 	stp	x2, x3, [sp, #32]
 b24:	910043e2 	add	x2, sp, #0x10
{
 b28:	a9079be5 	stp	x5, x6, [sp, #120]
 b2c:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 b30:	97ffff1e 	bl	7a8 <vprintf>
  va_end(ap);
  return result;
}
 b34:	a8c97bfd 	ldp	x29, x30, [sp], #144
 b38:	d65f03c0 	ret
