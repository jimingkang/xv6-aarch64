
user/_ptytest:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:

// Kernel PTY smoke test. It verifies both independent byte streams without
// depending on SSH framing or cryptography.
int
main(void)
{
   0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
   4:	910003fd 	mov	x29, sp
  int fd[2];
  char buf[32];
  int n;

  if(pty_open(fd) < 0){
   8:	9100a3e0 	add	x0, sp, #0x28
{
   c:	a90153f3 	stp	x19, x20, [sp, #16]
  if(pty_open(fd) < 0){
  10:	940001d1 	bl	754 <pty_open>
  14:	36f800c0 	tbz	w0, #31, 2c <main+0x2c>
    printf("ptytest: pty_open failed\n");
  18:	90000000 	adrp	x0, 0 <main>
  1c:	91326000 	add	x0, x0, #0xc98
    exit(1);
  }
  if(write(fd[0], "input-to-slave\n", 15) != 15 ||
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
     memcmp(buf, "input-to-slave\n", 15) != 0){
    printf("ptytest: master-to-slave failed\n");
  20:	94000307 	bl	c3c <printf>
    exit(1);
  24:	52800020 	mov	w0, #0x1                   	// #1
  28:	94000129 	bl	4cc <exit>
  if(write(fd[0], "input-to-slave\n", 15) != 15 ||
  2c:	b9402be0 	ldr	w0, [sp, #40]
  30:	90000013 	adrp	x19, 0 <main>
  34:	528001e2 	mov	w2, #0xf                   	// #15
  38:	9132ca61 	add	x1, x19, #0xcb2
  3c:	94000130 	bl	4fc <write>
  40:	71003c1f 	cmp	w0, #0xf
  44:	54000080 	b.eq	54 <main+0x54>  // b.none
    printf("ptytest: master-to-slave failed\n");
  48:	90000000 	adrp	x0, 0 <main>
  4c:	91330800 	add	x0, x0, #0xcc2
  50:	17fffff4 	b	20 <main+0x20>
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
  54:	b9402fe0 	ldr	w0, [sp, #44]
  58:	9100c3e1 	add	x1, sp, #0x30
  5c:	52800402 	mov	w2, #0x20                  	// #32
  60:	94000124 	bl	4f0 <read>
  if(write(fd[0], "input-to-slave\n", 15) != 15 ||
  64:	71003c1f 	cmp	w0, #0xf
  68:	54ffff01 	b.ne	48 <main+0x48>  // b.any
     memcmp(buf, "input-to-slave\n", 15) != 0){
  6c:	2a0003e2 	mov	w2, w0
  70:	9132ca61 	add	x1, x19, #0xcb2
  74:	9100c3e0 	add	x0, sp, #0x30
  78:	94000103 	bl	484 <memcmp>
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
  7c:	35fffe60 	cbnz	w0, 48 <main+0x48>
  }
  if((n = read(fd[0], buf, sizeof(buf))) != 16 ||
  80:	b9402be0 	ldr	w0, [sp, #40]
  84:	9100c3e1 	add	x1, sp, #0x30
  88:	52800402 	mov	w2, #0x20                  	// #32
  8c:	94000119 	bl	4f0 <read>
  90:	7100401f 	cmp	w0, #0x10
  94:	54000080 	b.eq	a4 <main+0xa4>  // b.none
     memcmp(buf, "input-to-slave\r\n", 16) != 0){
    printf("ptytest: input echo failed\n");
  98:	90000000 	adrp	x0, 0 <main>
  9c:	91338c00 	add	x0, x0, #0xce3
  a0:	17ffffe0 	b	20 <main+0x20>
     memcmp(buf, "input-to-slave\r\n", 16) != 0){
  a4:	2a0003e2 	mov	w2, w0
  a8:	90000014 	adrp	x20, 0 <main>
  ac:	9100c3e0 	add	x0, sp, #0x30
  b0:	9133fe81 	add	x1, x20, #0xcff
  b4:	940000f4 	bl	484 <memcmp>
  if((n = read(fd[0], buf, sizeof(buf))) != 16 ||
  b8:	35ffff00 	cbnz	w0, 98 <main+0x98>
    exit(1);
  }
  if(write(fd[0], "\033[A\n", 4) != 4 ||
  bc:	b9402be0 	ldr	w0, [sp, #40]
  c0:	90000001 	adrp	x1, 0 <main>
  c4:	91344021 	add	x1, x1, #0xd10
  c8:	52800082 	mov	w2, #0x4                   	// #4
  cc:	9400010c 	bl	4fc <write>
  d0:	7100101f 	cmp	w0, #0x4
  d4:	54000080 	b.eq	e4 <main+0xe4>  // b.none
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
     memcmp(buf, "input-to-slave\n", 15) != 0 ||
     (n = read(fd[0], buf, sizeof(buf))) != 16 ||
     memcmp(buf, "input-to-slave\r\n", 16) != 0){
    printf("ptytest: history recall failed\n");
  d8:	90000000 	adrp	x0, 0 <main>
  dc:	91345400 	add	x0, x0, #0xd15
  e0:	17ffffd0 	b	20 <main+0x20>
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
  e4:	b9402fe0 	ldr	w0, [sp, #44]
  e8:	9100c3e1 	add	x1, sp, #0x30
  ec:	52800402 	mov	w2, #0x20                  	// #32
  f0:	94000100 	bl	4f0 <read>
  if(write(fd[0], "\033[A\n", 4) != 4 ||
  f4:	71003c1f 	cmp	w0, #0xf
  f8:	54ffff01 	b.ne	d8 <main+0xd8>  // b.any
     memcmp(buf, "input-to-slave\n", 15) != 0 ||
  fc:	2a0003e2 	mov	w2, w0
 100:	9132ca61 	add	x1, x19, #0xcb2
 104:	9100c3e0 	add	x0, sp, #0x30
 108:	940000df 	bl	484 <memcmp>
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
 10c:	35fffe60 	cbnz	w0, d8 <main+0xd8>
     (n = read(fd[0], buf, sizeof(buf))) != 16 ||
 110:	b9402be0 	ldr	w0, [sp, #40]
 114:	9100c3e1 	add	x1, sp, #0x30
 118:	52800402 	mov	w2, #0x20                  	// #32
 11c:	940000f5 	bl	4f0 <read>
     memcmp(buf, "input-to-slave\n", 15) != 0 ||
 120:	7100401f 	cmp	w0, #0x10
 124:	54fffda1 	b.ne	d8 <main+0xd8>  // b.any
     memcmp(buf, "input-to-slave\r\n", 16) != 0){
 128:	9133fe81 	add	x1, x20, #0xcff
 12c:	9100c3e0 	add	x0, sp, #0x30
 130:	52800202 	mov	w2, #0x10                  	// #16
 134:	940000d4 	bl	484 <memcmp>
     (n = read(fd[0], buf, sizeof(buf))) != 16 ||
 138:	35fffd00 	cbnz	w0, d8 <main+0xd8>
    exit(1);
  }
  if(write(fd[1], "output-to-master\n", 17) != 17 ||
 13c:	b9402fe0 	ldr	w0, [sp, #44]
 140:	90000001 	adrp	x1, 0 <main>
 144:	9134d421 	add	x1, x1, #0xd35
 148:	52800222 	mov	w2, #0x11                  	// #17
 14c:	940000ec 	bl	4fc <write>
 150:	7100441f 	cmp	w0, #0x11
 154:	54000080 	b.eq	164 <main+0x164>  // b.none
     (n = read(fd[0], buf, sizeof(buf))) != 18 ||
     memcmp(buf, "output-to-master\r\n", 18) != 0){
    printf("ptytest: slave-to-master failed\n");
 158:	90000000 	adrp	x0, 0 <main>
 15c:	91351c00 	add	x0, x0, #0xd47
 160:	17ffffb0 	b	20 <main+0x20>
     (n = read(fd[0], buf, sizeof(buf))) != 18 ||
 164:	b9402be0 	ldr	w0, [sp, #40]
 168:	9100c3e1 	add	x1, sp, #0x30
 16c:	52800402 	mov	w2, #0x20                  	// #32
 170:	940000e0 	bl	4f0 <read>
  if(write(fd[1], "output-to-master\n", 17) != 17 ||
 174:	7100481f 	cmp	w0, #0x12
 178:	54ffff01 	b.ne	158 <main+0x158>  // b.any
     memcmp(buf, "output-to-master\r\n", 18) != 0){
 17c:	2a0003e2 	mov	w2, w0
 180:	90000001 	adrp	x1, 0 <main>
 184:	9135a021 	add	x1, x1, #0xd68
 188:	9100c3e0 	add	x0, sp, #0x30
 18c:	940000be 	bl	484 <memcmp>
     (n = read(fd[0], buf, sizeof(buf))) != 18 ||
 190:	35fffe40 	cbnz	w0, 158 <main+0x158>
    exit(1);
  }
  close(fd[0]);
 194:	b9402be0 	ldr	w0, [sp, #40]
 198:	940000dc 	bl	508 <close>
  close(fd[1]);
 19c:	b9402fe0 	ldr	w0, [sp, #44]
 1a0:	940000da 	bl	508 <close>
  printf("ptytest: ok\n");
 1a4:	90000000 	adrp	x0, 0 <main>
 1a8:	9135ec00 	add	x0, x0, #0xd7b
 1ac:	940002a4 	bl	c3c <printf>
  exit(0);
 1b0:	52800000 	mov	w0, #0x0                   	// #0
 1b4:	17ffff9d 	b	28 <main+0x28>

00000000000001b8 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1b8:	d2800002 	mov	x2, #0x0                   	// #0
 1bc:	38626823 	ldrb	w3, [x1, x2]
 1c0:	38226803 	strb	w3, [x0, x2]
 1c4:	91000442 	add	x2, x2, #0x1
 1c8:	35ffffa3 	cbnz	w3, 1bc <strcpy+0x4>
    ;
  return os;
}
 1cc:	d65f03c0 	ret

00000000000001d0 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 1d0:	d2800003 	mov	x3, #0x0                   	// #0
 1d4:	4b030044 	sub	w4, w2, w3
 1d8:	7100009f 	cmp	w4, #0x0
 1dc:	5400006d 	b.le	1e8 <strncpy+0x18>
 1e0:	38636825 	ldrb	w5, [x1, x3]
 1e4:	350000e5 	cbnz	w5, 200 <strncpy+0x30>
 1e8:	8b030003 	add	x3, x0, x3
 1ec:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 1f0:	4b010082 	sub	w2, w4, w1
 1f4:	7100005f 	cmp	w2, #0x0
 1f8:	540000ac 	b.gt	20c <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 1fc:	d65f03c0 	ret
    *s++ = *t++;
 200:	38236805 	strb	w5, [x0, x3]
    n--;
 204:	91000463 	add	x3, x3, #0x1
 208:	17fffff3 	b	1d4 <strncpy+0x4>
    *s++ = 0;
 20c:	3821687f 	strb	wzr, [x3, x1]
 210:	91000421 	add	x1, x1, #0x1
 214:	17fffff7 	b	1f0 <strncpy+0x20>

0000000000000218 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 218:	aa0003e2 	mov	x2, x0
 21c:	39400043 	ldrb	w3, [x2]
 220:	aa0203e4 	mov	x4, x2
    s++;
 224:	91000442 	add	x2, x2, #0x1
  while(*s)
 228:	35ffffa3 	cbnz	w3, 21c <strcat+0x4>
 22c:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 230:	38626823 	ldrb	w3, [x1, x2]
 234:	38226883 	strb	w3, [x4, x2]
 238:	91000442 	add	x2, x2, #0x1
 23c:	35ffffa3 	cbnz	w3, 230 <strcat+0x18>
    ;
  return os;
}
 240:	d65f03c0 	ret

0000000000000244 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 244:	d2800002 	mov	x2, #0x0                   	// #0
 248:	38626803 	ldrb	w3, [x0, x2]
 24c:	38626824 	ldrb	w4, [x1, x2]
 250:	34000083 	cbz	w3, 260 <strcmp+0x1c>
 254:	91000442 	add	x2, x2, #0x1
 258:	6b04007f 	cmp	w3, w4
 25c:	54ffff60 	b.eq	248 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 260:	4b040060 	sub	w0, w3, w4
 264:	d65f03c0 	ret

0000000000000268 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 268:	340001c2 	cbz	w2, 2a0 <strncmp+0x38>
 26c:	39400003 	ldrb	w3, [x0]
 270:	34000083 	cbz	w3, 280 <strncmp+0x18>
 274:	39400024 	ldrb	w4, [x1]
 278:	6b03009f 	cmp	w4, w3
 27c:	540000a0 	b.eq	290 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 280:	39400000 	ldrb	w0, [x0]
 284:	39400021 	ldrb	w1, [x1]
 288:	4b010000 	sub	w0, w0, w1
}
 28c:	d65f03c0 	ret
    n--, p++, q++;
 290:	51000442 	sub	w2, w2, #0x1
 294:	91000400 	add	x0, x0, #0x1
 298:	91000421 	add	x1, x1, #0x1
 29c:	17fffff3 	b	268 <strncmp>
    return 0;
 2a0:	52800000 	mov	w0, #0x0                   	// #0
 2a4:	17fffffa 	b	28c <strncmp+0x24>

00000000000002a8 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 2a8:	d1000402 	sub	x2, x0, #0x1
 2ac:	d2800001 	mov	x1, #0x0                   	// #0
 2b0:	aa0103e0 	mov	x0, x1
 2b4:	91000421 	add	x1, x1, #0x1
 2b8:	38616843 	ldrb	w3, [x2, x1]
 2bc:	35ffffa3 	cbnz	w3, 2b0 <strlen+0x8>
    ;
  return n;
}
 2c0:	d65f03c0 	ret

00000000000002c4 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 2c4:	d1000403 	sub	x3, x0, #0x1
 2c8:	d2800002 	mov	x2, #0x0                   	// #0
 2cc:	2a0203e0 	mov	w0, w2
 2d0:	6b02003f 	cmp	w1, w2
 2d4:	54000089 	b.ls	2e4 <strnlen+0x20>  // b.plast
 2d8:	91000442 	add	x2, x2, #0x1
 2dc:	38626864 	ldrb	w4, [x3, x2]
 2e0:	35ffff64 	cbnz	w4, 2cc <strnlen+0x8>
    n++;
  return n;
}
 2e4:	d65f03c0 	ret

00000000000002e8 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2e8:	d2800003 	mov	x3, #0x0                   	// #0
 2ec:	6b03005f 	cmp	w2, w3
 2f0:	54000048 	b.hi	2f8 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 2f4:	d65f03c0 	ret
    cdst[i] = c;
 2f8:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 2fc:	91000463 	add	x3, x3, #0x1
 300:	17fffffb 	b	2ec <memset+0x4>

0000000000000304 <strchr>:

char*
strchr(const char *s, char c)
{
 304:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 308:	39400002 	ldrb	w2, [x0]
 30c:	35000062 	cbnz	w2, 318 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 310:	d2800000 	mov	x0, #0x0                   	// #0
}
 314:	d65f03c0 	ret
    if(*s == c)
 318:	6b01005f 	cmp	w2, w1
 31c:	54ffffc0 	b.eq	314 <strchr+0x10>  // b.none
  for(; *s; s++)
 320:	91000400 	add	x0, x0, #0x1
 324:	17fffff9 	b	308 <strchr+0x4>

0000000000000328 <gets>:

char*
gets(char *buf, int max)
{
 328:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 32c:	910003fd 	mov	x29, sp
 330:	a90153f3 	stp	x19, x20, [sp, #16]
 334:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 338:	d2800014 	mov	x20, #0x0                   	// #0
{
 33c:	f9001bf7 	str	x23, [sp, #48]
 340:	2a0103f7 	mov	w23, w1
 344:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 348:	11000695 	add	w21, w20, #0x1
 34c:	2a1403f6 	mov	w22, w20
 350:	6b1702bf 	cmp	w21, w23
 354:	540000ea 	b.ge	370 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 358:	91013fe1 	add	x1, sp, #0x4f
 35c:	52800022 	mov	w2, #0x1                   	// #1
 360:	52800000 	mov	w0, #0x0                   	// #0
 364:	94000063 	bl	4f0 <read>
    if(cc < 1)
 368:	7100001f 	cmp	w0, #0x0
 36c:	5400012c 	b.gt	390 <gets+0x68>
  for(i=0; i+1 < max; ){
 370:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 374:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 378:	aa1303e0 	mov	x0, x19
 37c:	f9401bf7 	ldr	x23, [sp, #48]
 380:	a94153f3 	ldp	x19, x20, [sp, #16]
 384:	a9425bf5 	ldp	x21, x22, [sp, #32]
 388:	a8c57bfd 	ldp	x29, x30, [sp], #80
 38c:	d65f03c0 	ret
    buf[i++] = c;
 390:	39413fe0 	ldrb	w0, [sp, #79]
 394:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 398:	91000694 	add	x20, x20, #0x1
 39c:	7100281f 	cmp	w0, #0xa
 3a0:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 3a4:	54fffd21 	b.ne	348 <gets+0x20>  // b.any
 3a8:	17fffff3 	b	374 <gets+0x4c>

00000000000003ac <stat>:

int
stat(const char *n, struct stat *st)
{
 3ac:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 3b0:	910003fd 	mov	x29, sp
 3b4:	a90153f3 	stp	x19, x20, [sp, #16]
 3b8:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3bc:	52800001 	mov	w1, #0x0                   	// #0
 3c0:	9400005b 	bl	52c <open>
  if(fd < 0)
 3c4:	37f80160 	tbnz	w0, #31, 3f0 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 3c8:	aa1303e1 	mov	x1, x19
 3cc:	2a0003f4 	mov	w20, w0
 3d0:	94000060 	bl	550 <fstat>
 3d4:	2a0003f3 	mov	w19, w0
  close(fd);
 3d8:	2a1403e0 	mov	w0, w20
 3dc:	9400004b 	bl	508 <close>
  return r;
}
 3e0:	2a1303e0 	mov	w0, w19
 3e4:	a94153f3 	ldp	x19, x20, [sp, #16]
 3e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
 3ec:	d65f03c0 	ret
    return -1;
 3f0:	12800013 	mov	w19, #0xffffffff            	// #-1
 3f4:	17fffffb 	b	3e0 <stat+0x34>

00000000000003f8 <atoi>:

int
atoi(const char *s)
{
 3f8:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 3fc:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 400:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 404:	39400043 	ldrb	w3, [x2]
 408:	5100c061 	sub	w1, w3, #0x30
 40c:	12001c21 	and	w1, w1, #0xff
 410:	7100243f 	cmp	w1, #0x9
 414:	54000049 	b.ls	41c <atoi+0x24>  // b.plast
  return n;
}
 418:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 41c:	1b040c01 	madd	w1, w0, w4, w3
 420:	91000442 	add	x2, x2, #0x1
 424:	5100c020 	sub	w0, w1, #0x30
 428:	17fffff7 	b	404 <atoi+0xc>

000000000000042c <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 42c:	eb01001f 	cmp	x0, x1
 430:	54000263 	b.cc	47c <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 434:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 438:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 43c:	d2800003 	mov	x3, #0x0                   	// #0
 440:	d1000463 	sub	x3, x3, #0x1
 444:	11000464 	add	w4, w3, #0x1
 448:	0b020084 	add	w4, w4, w2
 44c:	7100009f 	cmp	w4, #0x0
 450:	5400014d 	b.le	478 <memmove+0x4c>
      *--dst = *--src;
 454:	38636824 	ldrb	w4, [x1, x3]
 458:	382368a4 	strb	w4, [x5, x3]
 45c:	17fffff9 	b	440 <memmove+0x14>
      *dst++ = *src++;
 460:	38636824 	ldrb	w4, [x1, x3]
 464:	38236804 	strb	w4, [x0, x3]
 468:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 46c:	4b030044 	sub	w4, w2, w3
 470:	7100009f 	cmp	w4, #0x0
 474:	54ffff6c 	b.gt	460 <memmove+0x34>
  }
  return vdst;
}
 478:	d65f03c0 	ret
 47c:	d2800003 	mov	x3, #0x0                   	// #0
 480:	17fffffb 	b	46c <memmove+0x40>

0000000000000484 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 484:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 488:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 48c:	d2800004 	mov	x4, #0x0                   	// #0
 490:	eb02009f 	cmp	x4, x2
 494:	54000061 	b.ne	4a0 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 498:	52800000 	mov	w0, #0x0                   	// #0
 49c:	14000007 	b	4b8 <memcmp+0x34>
    if (*p1 != *p2) {
 4a0:	38646803 	ldrb	w3, [x0, x4]
 4a4:	91000484 	add	x4, x4, #0x1
 4a8:	38646825 	ldrb	w5, [x1, x4]
 4ac:	6b05007f 	cmp	w3, w5
 4b0:	54ffff00 	b.eq	490 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 4b4:	4b050060 	sub	w0, w3, w5
}
 4b8:	d65f03c0 	ret

00000000000004bc <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 4bc:	17ffffdc 	b	42c <memmove>

00000000000004c0 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 4c0:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 4c4:	d4000001 	svc	#0x0
 ret
 4c8:	d65f03c0 	ret

00000000000004cc <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 4cc:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 4d0:	d4000001 	svc	#0x0
 ret
 4d4:	d65f03c0 	ret

00000000000004d8 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 4d8:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 4dc:	d4000001 	svc	#0x0
 ret
 4e0:	d65f03c0 	ret

00000000000004e4 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 4e4:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 4e8:	d4000001 	svc	#0x0
 ret
 4ec:	d65f03c0 	ret

00000000000004f0 <read>:
.global read
read:
 mov x7, #SYS_read
 4f0:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 4f4:	d4000001 	svc	#0x0
 ret
 4f8:	d65f03c0 	ret

00000000000004fc <write>:
.global write
write:
 mov x7, #SYS_write
 4fc:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 500:	d4000001 	svc	#0x0
 ret
 504:	d65f03c0 	ret

0000000000000508 <close>:
.global close
close:
 mov x7, #SYS_close
 508:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 50c:	d4000001 	svc	#0x0
 ret
 510:	d65f03c0 	ret

0000000000000514 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 514:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 518:	d4000001 	svc	#0x0
 ret
 51c:	d65f03c0 	ret

0000000000000520 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 520:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 524:	d4000001 	svc	#0x0
 ret
 528:	d65f03c0 	ret

000000000000052c <open>:
.global open
open:
 mov x7, #SYS_open
 52c:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 530:	d4000001 	svc	#0x0
 ret
 534:	d65f03c0 	ret

0000000000000538 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 538:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 53c:	d4000001 	svc	#0x0
 ret
 540:	d65f03c0 	ret

0000000000000544 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 544:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 548:	d4000001 	svc	#0x0
 ret
 54c:	d65f03c0 	ret

0000000000000550 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 550:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 554:	d4000001 	svc	#0x0
 ret
 558:	d65f03c0 	ret

000000000000055c <link>:
.global link
link:
 mov x7, #SYS_link
 55c:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 560:	d4000001 	svc	#0x0
 ret
 564:	d65f03c0 	ret

0000000000000568 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 568:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 56c:	d4000001 	svc	#0x0
 ret
 570:	d65f03c0 	ret

0000000000000574 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 574:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 578:	d4000001 	svc	#0x0
 ret
 57c:	d65f03c0 	ret

0000000000000580 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 580:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 584:	d4000001 	svc	#0x0
 ret
 588:	d65f03c0 	ret

000000000000058c <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 58c:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 590:	d4000001 	svc	#0x0
 ret
 594:	d65f03c0 	ret

0000000000000598 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 598:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 59c:	d4000001 	svc	#0x0
 ret
 5a0:	d65f03c0 	ret

00000000000005a4 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 5a4:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 5a8:	d4000001 	svc	#0x0
 ret
 5ac:	d65f03c0 	ret

00000000000005b0 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 5b0:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 5b4:	d4000001 	svc	#0x0
 ret
 5b8:	d65f03c0 	ret

00000000000005bc <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 5bc:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 5c0:	d4000001 	svc	#0x0
 ret
 5c4:	d65f03c0 	ret

00000000000005c8 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 5c8:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 5cc:	d4000001 	svc	#0x0
 ret
 5d0:	d65f03c0 	ret

00000000000005d4 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 5d4:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 5d8:	d4000001 	svc	#0x0
 ret
 5dc:	d65f03c0 	ret

00000000000005e0 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 5e0:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 5e4:	d4000001 	svc	#0x0
 ret
 5e8:	d65f03c0 	ret

00000000000005ec <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 5ec:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 5f0:	d4000001 	svc	#0x0
 ret
 5f4:	d65f03c0 	ret

00000000000005f8 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 5f8:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 5fc:	d4000001 	svc	#0x0
 ret
 600:	d65f03c0 	ret

0000000000000604 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 604:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 608:	d4000001 	svc	#0x0
 ret
 60c:	d65f03c0 	ret

0000000000000610 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 610:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 614:	d4000001 	svc	#0x0
 ret
 618:	d65f03c0 	ret

000000000000061c <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 61c:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 620:	d4000001 	svc	#0x0
 ret
 624:	d65f03c0 	ret

0000000000000628 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 628:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 62c:	d4000001 	svc	#0x0
 ret
 630:	d65f03c0 	ret

0000000000000634 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 634:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 638:	d4000001 	svc	#0x0
 ret
 63c:	d65f03c0 	ret

0000000000000640 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 640:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 644:	d4000001 	svc	#0x0
 ret
 648:	d65f03c0 	ret

000000000000064c <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 64c:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 650:	d4000001 	svc	#0x0
 ret
 654:	d65f03c0 	ret

0000000000000658 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 658:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 65c:	d4000001 	svc	#0x0
 ret
 660:	d65f03c0 	ret

0000000000000664 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 664:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 668:	d4000001 	svc	#0x0
 ret
 66c:	d65f03c0 	ret

0000000000000670 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 670:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 674:	d4000001 	svc	#0x0
 ret
 678:	d65f03c0 	ret

000000000000067c <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 67c:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 680:	d4000001 	svc	#0x0
 ret
 684:	d65f03c0 	ret

0000000000000688 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 688:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 68c:	d4000001 	svc	#0x0
 ret
 690:	d65f03c0 	ret

0000000000000694 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 694:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 698:	d4000001 	svc	#0x0
 ret
 69c:	d65f03c0 	ret

00000000000006a0 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 6a0:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 6a4:	d4000001 	svc	#0x0
 ret
 6a8:	d65f03c0 	ret

00000000000006ac <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 6ac:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 6b0:	d4000001 	svc	#0x0
 ret
 6b4:	d65f03c0 	ret

00000000000006b8 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 6b8:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 6bc:	d4000001 	svc	#0x0
 ret
 6c0:	d65f03c0 	ret

00000000000006c4 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 6c4:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 6c8:	d4000001 	svc	#0x0
 ret
 6cc:	d65f03c0 	ret

00000000000006d0 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 6d0:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 6d4:	d4000001 	svc	#0x0
 ret
 6d8:	d65f03c0 	ret

00000000000006dc <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 6dc:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 6e0:	d4000001 	svc	#0x0
 ret
 6e4:	d65f03c0 	ret

00000000000006e8 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 6e8:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 6ec:	d4000001 	svc	#0x0
 ret
 6f0:	d65f03c0 	ret

00000000000006f4 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 6f4:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 6f8:	d4000001 	svc	#0x0
 ret
 6fc:	d65f03c0 	ret

0000000000000700 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 700:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 704:	d4000001 	svc	#0x0
 ret
 708:	d65f03c0 	ret

000000000000070c <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 70c:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 710:	d4000001 	svc	#0x0
 ret
 714:	d65f03c0 	ret

0000000000000718 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 718:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 71c:	d4000001 	svc	#0x0
 ret
 720:	d65f03c0 	ret

0000000000000724 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 724:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 728:	d4000001 	svc	#0x0
 ret
 72c:	d65f03c0 	ret

0000000000000730 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 730:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 734:	d4000001 	svc	#0x0
 ret
 738:	d65f03c0 	ret

000000000000073c <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 73c:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 740:	d4000001 	svc	#0x0
 ret
 744:	d65f03c0 	ret

0000000000000748 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 748:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 74c:	d4000001 	svc	#0x0
 ret
 750:	d65f03c0 	ret

0000000000000754 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 754:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 758:	d4000001 	svc	#0x0
 ret
 75c:	d65f03c0 	ret

0000000000000760 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 760:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 764:	d4000001 	svc	#0x0
 ret
 768:	d65f03c0 	ret

000000000000076c <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 76c:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 770:	d4000001 	svc	#0x0
 ret
 774:	d65f03c0 	ret

0000000000000778 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 778:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 77c:	d4000001 	svc	#0x0
 ret
 780:	d65f03c0 	ret

0000000000000784 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 784:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 788:	d4000001 	svc	#0x0
 ret
 78c:	d65f03c0 	ret

0000000000000790 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 790:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 794:	d4000001 	svc	#0x0
 ret
 798:	d65f03c0 	ret

000000000000079c <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 79c:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 7a0:	d4000001 	svc	#0x0
 ret
 7a4:	d65f03c0 	ret

00000000000007a8 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 7a8:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 7ac:	d4000001 	svc	#0x0
 ret
 7b0:	d65f03c0 	ret

00000000000007b4 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 7b4:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 7b8:	d4000001 	svc	#0x0
 ret
 7bc:	d65f03c0 	ret

00000000000007c0 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 7c0:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 7c4:	d4000001 	svc	#0x0
 ret
 7c8:	d65f03c0 	ret

00000000000007cc <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 7cc:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 7d0:	d4000001 	svc	#0x0
 ret
 7d4:	d65f03c0 	ret

00000000000007d8 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 7d8:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 7dc:	d4000001 	svc	#0x0
 ret
 7e0:	d65f03c0 	ret

00000000000007e4 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 7e4:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 7e8:	d4000001 	svc	#0x0
 ret
 7ec:	d65f03c0 	ret

00000000000007f0 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 7f0:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 7f4:	d4000001 	svc	#0x0
 ret
 7f8:	d65f03c0 	ret

00000000000007fc <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 7fc:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 800:	d4000001 	svc	#0x0
 ret
 804:	d65f03c0 	ret

0000000000000808 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 808:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 80c:	d4000001 	svc	#0x0
 ret
 810:	d65f03c0 	ret

0000000000000814 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 814:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 818:	d4000001 	svc	#0x0
 ret
 81c:	d65f03c0 	ret

0000000000000820 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 820:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 824:	d4000001 	svc	#0x0
 ret
 828:	d65f03c0 	ret

000000000000082c <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 82c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 830:	52800022 	mov	w2, #0x1                   	// #1
{
 834:	910003fd 	mov	x29, sp
 838:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 83c:	91007fe1 	add	x1, sp, #0x1f
 840:	97ffff2f 	bl	4fc <write>
 844:	7100041f 	cmp	w0, #0x1
}
 848:	1a9f17e0 	cset	w0, eq	// eq = none
 84c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 850:	d65f03c0 	ret

0000000000000854 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 854:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 858:	910003fd 	mov	x29, sp
 85c:	a90153f3 	stp	x19, x20, [sp, #16]
 860:	a9025bf5 	stp	x21, x22, [sp, #32]
 864:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 868:	6a417c7f 	tst	w3, w1, lsr #31
 86c:	54000300 	b.eq	8cc <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 870:	4b0103e1 	neg	w1, w1
    neg = 1;
 874:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 878:	90000003 	adrp	x3, 0 <main>
 87c:	91363c63 	add	x3, x3, #0xd8f
 880:	9100c3f5 	add	x21, sp, #0x30
 884:	d2800000 	mov	x0, #0x0                   	// #0
 888:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 88c:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 890:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 894:	2a0403e1 	mov	w1, w4
 898:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 89c:	38666866 	ldrb	w6, [x3, x6]
 8a0:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 8a4:	91000400 	add	x0, x0, #0x1
 8a8:	54ffff09 	b.ls	888 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 8ac:	11000493 	add	w19, w4, #0x1
  if(neg)
 8b0:	34000085 	cbz	w5, 8c0 <printint+0x6c>
    buf[i++] = '-';
 8b4:	528005a0 	mov	w0, #0x2d                  	// #45
 8b8:	38334aa0 	strb	w0, [x21, w19, uxtw]
 8bc:	11000893 	add	w19, w4, #0x2
 8c0:	51000673 	sub	w19, w19, #0x1
 8c4:	52800014 	mov	w20, #0x0                   	// #0
 8c8:	14000008 	b	8e8 <printint+0x94>
  neg = 0;
 8cc:	52800005 	mov	w5, #0x0                   	// #0
 8d0:	17ffffea 	b	878 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 8d4:	38736aa1 	ldrb	w1, [x21, x19]
 8d8:	2a1603e0 	mov	w0, w22
 8dc:	d1000673 	sub	x19, x19, #0x1
 8e0:	97ffffd3 	bl	82c <putc>
 8e4:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 8e8:	3100067f 	cmn	w19, #0x1
 8ec:	54ffff41 	b.ne	8d4 <printint+0x80>  // b.any
  return written;
}
 8f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
 8f4:	2a1403e0 	mov	w0, w20
 8f8:	a94153f3 	ldp	x19, x20, [sp, #16]
 8fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
 900:	d65f03c0 	ret

0000000000000904 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 904:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 908:	910003fd 	mov	x29, sp
 90c:	a90153f3 	stp	x19, x20, [sp, #16]
 910:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 914:	52800015 	mov	w21, #0x0                   	// #0
{
 918:	a90363f7 	stp	x23, x24, [sp, #48]
 91c:	2a0003f7 	mov	w23, w0
 920:	a9046bf9 	stp	x25, x26, [sp, #64]
 924:	aa0103f9 	mov	x25, x1

  state = 0;
 928:	52800001 	mov	w1, #0x0                   	// #0
{
 92c:	a90573fb 	stp	x27, x28, [sp, #80]
 930:	a9406053 	ldp	x19, x24, [x2]
 934:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 938:	39400320 	ldrb	w0, [x25]
 93c:	35000120 	cbnz	w0, 960 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 940:	2a1503e0 	mov	w0, w21
 944:	a94153f3 	ldp	x19, x20, [sp, #16]
 948:	a9425bf5 	ldp	x21, x22, [sp, #32]
 94c:	a94363f7 	ldp	x23, x24, [sp, #48]
 950:	a9446bf9 	ldp	x25, x26, [sp, #64]
 954:	a94573fb 	ldp	x27, x28, [sp, #80]
 958:	a8c67bfd 	ldp	x29, x30, [sp], #96
 95c:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 960:	2a0003f6 	mov	w22, w0
    if(state == 0){
 964:	35000101 	cbnz	w1, 984 <vprintf+0x80>
      if(c == '%'){
 968:	7100941f 	cmp	w0, #0x25
 96c:	54000ba0 	b.eq	ae0 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 970:	2a1603e1 	mov	w1, w22
 974:	2a1703e0 	mov	w0, w23
 978:	97ffffad 	bl	82c <putc>
 97c:	0b0002b5 	add	w21, w21, w0
 980:	14000057 	b	adc <vprintf+0x1d8>
      if(c == 'd'){
 984:	7101901f 	cmp	w0, #0x64
 988:	540002a1 	b.ne	9dc <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 98c:	37f80174 	tbnz	w20, #31, 9b8 <vprintf+0xb4>
 990:	91002e76 	add	x22, x19, #0xb
 994:	2a1403fa 	mov	w26, w20
 998:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 99c:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 9a0:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 9a4:	b9400261 	ldr	w1, [x19]
 9a8:	2a1703e0 	mov	w0, w23
 9ac:	97ffffaa 	bl	854 <printint>
        written += putc(fd, va_arg(ap, uint));
 9b0:	0b0002b5 	add	w21, w21, w0
 9b4:	14000048 	b	ad4 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 9b8:	1100229a 	add	w26, w20, #0x8
 9bc:	7100035f 	cmp	w26, #0x0
 9c0:	5400008d 	b.le	9d0 <vprintf+0xcc>
 9c4:	91002e76 	add	x22, x19, #0xb
 9c8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9cc:	17fffff4 	b	99c <vprintf+0x98>
 9d0:	aa1303f6 	mov	x22, x19
 9d4:	8b34c313 	add	x19, x24, w20, sxtw
 9d8:	17fffff1 	b	99c <vprintf+0x98>
      } else if(c == 'l') {
 9dc:	7101b01f 	cmp	w0, #0x6c
 9e0:	54000201 	b.ne	a20 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 9e4:	37f800d4 	tbnz	w20, #31, 9fc <vprintf+0xf8>
 9e8:	91003e76 	add	x22, x19, #0xf
 9ec:	2a1403fa 	mov	w26, w20
 9f0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9f4:	52800003 	mov	w3, #0x0                   	// #0
 9f8:	17ffffea 	b	9a0 <vprintf+0x9c>
 9fc:	1100229a 	add	w26, w20, #0x8
 a00:	7100035f 	cmp	w26, #0x0
 a04:	5400008d 	b.le	a14 <vprintf+0x110>
 a08:	91003e76 	add	x22, x19, #0xf
 a0c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a10:	17fffff9 	b	9f4 <vprintf+0xf0>
 a14:	aa1303f6 	mov	x22, x19
 a18:	8b34c313 	add	x19, x24, w20, sxtw
 a1c:	17fffff6 	b	9f4 <vprintf+0xf0>
      } else if(c == 'x') {
 a20:	7101e01f 	cmp	w0, #0x78
 a24:	54000221 	b.ne	a68 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 a28:	37f800f4 	tbnz	w20, #31, a44 <vprintf+0x140>
 a2c:	91002e76 	add	x22, x19, #0xb
 a30:	2a1403fa 	mov	w26, w20
 a34:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a38:	52800003 	mov	w3, #0x0                   	// #0
 a3c:	52800202 	mov	w2, #0x10                  	// #16
 a40:	17ffffd9 	b	9a4 <vprintf+0xa0>
 a44:	1100229a 	add	w26, w20, #0x8
 a48:	7100035f 	cmp	w26, #0x0
 a4c:	5400008d 	b.le	a5c <vprintf+0x158>
 a50:	91002e76 	add	x22, x19, #0xb
 a54:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a58:	17fffff8 	b	a38 <vprintf+0x134>
 a5c:	aa1303f6 	mov	x22, x19
 a60:	8b34c313 	add	x19, x24, w20, sxtw
 a64:	17fffff5 	b	a38 <vprintf+0x134>
      } else if(c == 'p') {
 a68:	7101c01f 	cmp	w0, #0x70
 a6c:	54000521 	b.ne	b10 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 a70:	37f803f4 	tbnz	w20, #31, aec <vprintf+0x1e8>
 a74:	91003e76 	add	x22, x19, #0xf
 a78:	2a1403fa 	mov	w26, w20
 a7c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a80:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 a84:	52800601 	mov	w1, #0x30                  	// #48
 a88:	2a1703e0 	mov	w0, w23
 a8c:	97ffff68 	bl	82c <putc>
 a90:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a94:	9000001c 	adrp	x28, 0 <main>
 a98:	91363f9c 	add	x28, x28, #0xd8f
  written += putc(fd, 'x');
 a9c:	2a1703e0 	mov	w0, w23
 aa0:	52800f01 	mov	w1, #0x78                  	// #120
 aa4:	97ffff62 	bl	82c <putc>
 aa8:	0b000273 	add	w19, w19, w0
 aac:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 ab0:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 ab4:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 ab8:	38606b81 	ldrb	w1, [x28, x0]
 abc:	2a1703e0 	mov	w0, w23
 ac0:	97ffff5b 	bl	82c <putc>
 ac4:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 ac8:	71000694 	subs	w20, w20, #0x1
 acc:	54ffff21 	b.ne	ab0 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 ad0:	0b1302b5 	add	w21, w21, w19
 ad4:	2a1a03f4 	mov	w20, w26
 ad8:	aa1603f3 	mov	x19, x22
      state = 0;
 adc:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 ae0:	91000739 	add	x25, x25, #0x1
  state = 0;
 ae4:	2a1603e1 	mov	w1, w22
 ae8:	17ffff94 	b	938 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 aec:	1100229a 	add	w26, w20, #0x8
 af0:	7100035f 	cmp	w26, #0x0
 af4:	5400008d 	b.le	b04 <vprintf+0x200>
 af8:	91003e76 	add	x22, x19, #0xf
 afc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b00:	17ffffe0 	b	a80 <vprintf+0x17c>
 b04:	aa1303f6 	mov	x22, x19
 b08:	8b34c313 	add	x19, x24, w20, sxtw
 b0c:	17ffffdd 	b	a80 <vprintf+0x17c>
      } else if(c == 's'){
 b10:	7101cc1f 	cmp	w0, #0x73
 b14:	54000381 	b.ne	b84 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 b18:	37f80214 	tbnz	w20, #31, b58 <vprintf+0x254>
 b1c:	91003e61 	add	x1, x19, #0xf
 b20:	aa1303e0 	mov	x0, x19
 b24:	927df033 	and	x19, x1, #0xfffffffffffffff8
 b28:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 b2c:	90000000 	adrp	x0, 0 <main>
 b30:	91362000 	add	x0, x0, #0xd88
 b34:	f10002df 	cmp	x22, #0x0
 b38:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 b3c:	394002c1 	ldrb	w1, [x22]
 b40:	34fffce1 	cbz	w1, adc <vprintf+0x1d8>
          written += putc(fd, *s);
 b44:	2a1703e0 	mov	w0, w23
          s++;
 b48:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 b4c:	97ffff38 	bl	82c <putc>
 b50:	0b0002b5 	add	w21, w21, w0
          s++;
 b54:	17fffffa 	b	b3c <vprintf+0x238>
        s = va_arg(ap, char*);
 b58:	11002281 	add	w1, w20, #0x8
 b5c:	7100003f 	cmp	w1, #0x0
 b60:	540000cd 	b.le	b78 <vprintf+0x274>
 b64:	91003e62 	add	x2, x19, #0xf
 b68:	aa1303e0 	mov	x0, x19
 b6c:	2a0103f4 	mov	w20, w1
 b70:	927df053 	and	x19, x2, #0xfffffffffffffff8
 b74:	17ffffed 	b	b28 <vprintf+0x224>
 b78:	8b34c300 	add	x0, x24, w20, sxtw
 b7c:	2a0103f4 	mov	w20, w1
 b80:	17ffffea 	b	b28 <vprintf+0x224>
      } else if(c == 'c'){
 b84:	71018c1f 	cmp	w0, #0x63
 b88:	54000241 	b.ne	bd0 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 b8c:	37f80114 	tbnz	w20, #31, bac <vprintf+0x2a8>
 b90:	91002e76 	add	x22, x19, #0xb
 b94:	2a1403fa 	mov	w26, w20
 b98:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b9c:	39400261 	ldrb	w1, [x19]
 ba0:	2a1703e0 	mov	w0, w23
 ba4:	97ffff22 	bl	82c <putc>
 ba8:	17ffff82 	b	9b0 <vprintf+0xac>
 bac:	1100229a 	add	w26, w20, #0x8
 bb0:	7100035f 	cmp	w26, #0x0
 bb4:	5400008d 	b.le	bc4 <vprintf+0x2c0>
 bb8:	91002e76 	add	x22, x19, #0xb
 bbc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 bc0:	17fffff7 	b	b9c <vprintf+0x298>
 bc4:	aa1303f6 	mov	x22, x19
 bc8:	8b34c313 	add	x19, x24, w20, sxtw
 bcc:	17fffff4 	b	b9c <vprintf+0x298>
      } else if(c == '%'){
 bd0:	7100941f 	cmp	w0, #0x25
 bd4:	54ffece0 	b.eq	970 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 bd8:	2a1703e0 	mov	w0, w23
 bdc:	528004a1 	mov	w1, #0x25                  	// #37
 be0:	97ffff13 	bl	82c <putc>
 be4:	0b0002b5 	add	w21, w21, w0
 be8:	17ffff62 	b	970 <vprintf+0x6c>

0000000000000bec <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 bec:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 bf0:	910003fd 	mov	x29, sp
 bf4:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 bf8:	910203e2 	add	x2, sp, #0x80
 bfc:	a9030be2 	stp	x2, x2, [sp, #48]
 c00:	910143e2 	add	x2, sp, #0x50
 c04:	f90023e2 	str	x2, [sp, #64]
 c08:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 c0c:	b9004be2 	str	w2, [sp, #72]
 c10:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 c14:	a9430fe2 	ldp	x2, x3, [sp, #48]
 c18:	a9010fe2 	stp	x2, x3, [sp, #16]
 c1c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 c20:	a9020fe2 	stp	x2, x3, [sp, #32]
 c24:	910043e2 	add	x2, sp, #0x10
{
 c28:	a90617e4 	stp	x4, x5, [sp, #96]
 c2c:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 c30:	97ffff35 	bl	904 <vprintf>
  va_end(ap);
  return result;
}
 c34:	a8c87bfd 	ldp	x29, x30, [sp], #128
 c38:	d65f03c0 	ret

0000000000000c3c <printf>:

int
printf(const char *fmt, ...)
{
 c3c:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 c40:	910003fd 	mov	x29, sp
 c44:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 c48:	910243e1 	add	x1, sp, #0x90
 c4c:	a90307e1 	stp	x1, x1, [sp, #48]
 c50:	910143e1 	add	x1, sp, #0x50
 c54:	f90023e1 	str	x1, [sp, #64]
 c58:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 c5c:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 c60:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 c64:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 c68:	52800020 	mov	w0, #0x1                   	// #1
{
 c6c:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 c70:	a9430fe2 	ldp	x2, x3, [sp, #48]
 c74:	a9010fe2 	stp	x2, x3, [sp, #16]
 c78:	a9440fe2 	ldp	x2, x3, [sp, #64]
 c7c:	a9020fe2 	stp	x2, x3, [sp, #32]
 c80:	910043e2 	add	x2, sp, #0x10
{
 c84:	a9079be5 	stp	x5, x6, [sp, #120]
 c88:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 c8c:	97ffff1e 	bl	904 <vprintf>
  va_end(ap);
  return result;
}
 c90:	a8c97bfd 	ldp	x29, x30, [sp], #144
 c94:	d65f03c0 	ret
