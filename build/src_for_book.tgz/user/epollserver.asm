
user/_epollserver:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  }
}

int
main(void)
{
   0:	d11643ff 	sub	sp, sp, #0x590
  struct epoll_event ev, events[MAX_EVENTS];
  int server_fd = socket_listen(PORT, 10);
   4:	52800141 	mov	w1, #0xa                   	// #10
   8:	5283f200 	mov	w0, #0x1f90                	// #8080
{
   c:	a9007bfd 	stp	x29, x30, [sp]
  10:	910003fd 	mov	x29, sp
  14:	a90153f3 	stp	x19, x20, [sp, #16]
  18:	a9025bf5 	stp	x21, x22, [sp, #32]
  1c:	a90363f7 	stp	x23, x24, [sp, #48]
  20:	a9046bf9 	stp	x25, x26, [sp, #64]
  24:	a90573fb 	stp	x27, x28, [sp, #80]
  int server_fd = socket_listen(PORT, 10);
  28:	94000247 	bl	944 <socket_listen>
  if(server_fd < 0 || set_nonblocking(server_fd) < 0){
  2c:	37f80080 	tbnz	w0, #31, 3c <main+0x3c>
  30:	2a0003f5 	mov	w21, w0
  34:	940000dd 	bl	3a8 <set_nonblocking>
  38:	36f800e0 	tbz	w0, #31, 54 <main+0x54>
    printf("epollserver: cannot listen on %d\n", PORT);
  3c:	90000000 	adrp	x0, 0 <main>
  40:	913b4000 	add	x0, x0, #0xed0
  44:	5283f201 	mov	w1, #0x1f90                	// #8080
  48:	9400038b 	bl	e74 <printf>
  }

  int epoll_fd = epoll_create();
  if(epoll_fd < 0){
    close(server_fd);
    exit(1);
  4c:	52800020 	mov	w0, #0x1                   	// #1
  50:	940001ad 	bl	704 <exit>
  int epoll_fd = epoll_create();
  54:	94000242 	bl	95c <epoll_create>
  58:	2a0003f9 	mov	w25, w0
  if(epoll_fd < 0){
  5c:	36f80080 	tbz	w0, #31, 6c <main+0x6c>
    close(server_fd);
  60:	2a1503e0 	mov	w0, w21
  64:	940001b7 	bl	740 <close>
  68:	17fffff9 	b	4c <main+0x4c>
  }
  ev.events = EPOLLIN;
  6c:	52800033 	mov	w19, #0x1                   	// #1
  ev.data.fd = server_fd;
  if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, server_fd, &ev) < 0){
  70:	910203e3 	add	x3, sp, #0x80
  74:	2a1503e2 	mov	w2, w21
  78:	2a1303e1 	mov	w1, w19
  ev.events = EPOLLIN;
  7c:	b90083f3 	str	w19, [sp, #128]
  ev.data.fd = server_fd;
  80:	b9008bf5 	str	w21, [sp, #136]
  if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, server_fd, &ev) < 0){
  84:	94000239 	bl	968 <epoll_ctl>
  88:	36f800a0 	tbz	w0, #31, 9c <main+0x9c>
    printf("epollserver: epoll_ctl listener failed\n");
  8c:	90000000 	adrp	x0, 0 <main>
  90:	913bc800 	add	x0, x0, #0xef2
  94:	94000378 	bl	e74 <printf>
    exit(1);
  98:	17ffffed 	b	4c <main+0x4c>
    if(clients[i].fd == 0){
  9c:	90000013 	adrp	x19, 0 <main>
  a0:	913e4273 	add	x19, x19, #0xf90
  }
  printf("Epoll server started on port %d...\n", PORT);
  a4:	90000000 	adrp	x0, 0 <main>
  a8:	913c6800 	add	x0, x0, #0xf1a
  ac:	5283f201 	mov	w1, #0x1f90                	// #8080
  b0:	94000371 	bl	e74 <printf>

  for(;;){
    int nfds = epoll_wait(epoll_fd, events, MAX_EVENTS, -1);
  b4:	910243e1 	add	x1, sp, #0x90
  b8:	2a1903e0 	mov	w0, w25
  bc:	12800003 	mov	w3, #0xffffffff            	// #-1
  c0:	52800202 	mov	w2, #0x10                  	// #16
  c4:	9400022c 	bl	974 <epoll_wait>
  c8:	b9007be0 	str	w0, [sp, #120]
    if(nfds < 0)
  cc:	37f81400 	tbnz	w0, #31, 34c <main+0x34c>
  d0:	910243f6 	add	x22, sp, #0x90
      break;
    for(int i = 0; i < nfds; i++){
  d4:	5280001b 	mov	w27, #0x0                   	// #0
  d8:	b9407be0 	ldr	w0, [sp, #120]
  dc:	6b00037f 	cmp	w27, w0
  e0:	54fffea0 	b.eq	b4 <main+0xb4>  // b.none
      int fd = events[i].data.fd;
  e4:	b9400ada 	ldr	w26, [x22, #8]
      if(fd == server_fd){
  e8:	6b1a02bf 	cmp	w21, w26
  ec:	54000181 	b.ne	11c <main+0x11c>  // b.any
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
            close(client_fd);
            client->fd = 0;
            continue;
          }
          printf("New client connected fd=%d.\n", client_fd);
  f0:	90000014 	adrp	x20, 0 <main>
  f4:	913cfa94 	add	x20, x20, #0xf3e
          int client_fd = socket_accept(server_fd);
  f8:	2a1a03e0 	mov	w0, w26
  fc:	94000215 	bl	950 <socket_accept>
 100:	2a0003f8 	mov	w24, w0
          if(client_fd < 0)
 104:	37f80780 	tbnz	w0, #31, 1f4 <main+0x1f4>
          if(set_nonblocking(client_fd) < 0){
 108:	940000a8 	bl	3a8 <set_nonblocking>
 10c:	36f802e0 	tbz	w0, #31, 168 <main+0x168>
            close(client_fd);
 110:	2a1803e0 	mov	w0, w24
 114:	9400018b 	bl	740 <close>
            continue;
 118:	17fffff8 	b	f8 <main+0xf8>
      if(fd == server_fd){
 11c:	d2800014 	mov	x20, #0x0                   	// #0
    if(clients[i].fd == fd)
 120:	52820200 	mov	w0, #0x1010                	// #4112
 124:	9ba07e9c 	umull	x28, w20, w0
 128:	8b130380 	add	x0, x28, x19
 12c:	f90037e0 	str	x0, [sp, #104]
 130:	b87c6a60 	ldr	w0, [x19, x28]
 134:	6b00035f 	cmp	w26, w0
 138:	54000581 	b.ne	1e8 <main+0x1e8>  // b.any
        }
      } else {
        struct client *client = find_client(fd);
        if(client == 0)
          continue;
        if(events[i].events & EPOLLERR){
 13c:	b94002c0 	ldr	w0, [x22]
 140:	121d0018 	and	w24, w0, #0x8
 144:	361805e0 	tbz	w0, #3, 200 <main+0x200>
          close_client(epoll_fd, client);
          printf("Client fd=%d disconnected.\n", fd);
          continue;
        }
        if(update_client_events(epoll_fd, client) < 0){
          close_client(epoll_fd, client);
 148:	f94037e1 	ldr	x1, [sp, #104]
 14c:	2a1903e0 	mov	w0, w25
 150:	94000088 	bl	370 <close_client>
          printf("Client fd=%d disconnected.\n", fd);
 154:	2a1a03e1 	mov	w1, w26
 158:	90000000 	adrp	x0, 0 <main>
 15c:	913d6c00 	add	x0, x0, #0xf5b
 160:	94000345 	bl	e74 <printf>
 164:	14000024 	b	1f4 <main+0x1f4>
          if(set_nonblocking(client_fd) < 0){
 168:	d2800003 	mov	x3, #0x0                   	// #0
    if(clients[i].fd == 0){
 16c:	52820200 	mov	w0, #0x1010                	// #4112
 170:	9ba07c60 	umull	x0, w3, w0
 174:	b8606a60 	ldr	w0, [x19, x0]
 178:	35000280 	cbnz	w0, 1c8 <main+0x1c8>
      clients[i].fd = fd;
 17c:	2a0303e3 	mov	w3, w3
 180:	d2820200 	mov	x0, #0x1010                	// #4112
      clients[i].events = EPOLLIN;
 184:	d2800021 	mov	x1, #0x1                   	// #1
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
 188:	2a1803e2 	mov	w2, w24
          ev.events = EPOLLIN;
 18c:	b90083e1 	str	w1, [sp, #128]
      clients[i].fd = fd;
 190:	9b007c77 	mul	x23, x3, x0
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
 194:	910203e3 	add	x3, sp, #0x80
      clients[i].fd = fd;
 198:	8b170260 	add	x0, x19, x23
 19c:	b8376a78 	str	w24, [x19, x23]
      clients[i].events = EPOLLIN;
 1a0:	f8004001 	stur	x1, [x0, #4]
      clients[i].read_closed = 0;
 1a4:	b9000c1f 	str	wzr, [x0, #12]
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
 1a8:	2a1903e0 	mov	w0, w25
          ev.data.fd = client_fd;
 1ac:	b9008bf8 	str	w24, [sp, #136]
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
 1b0:	940001ee 	bl	968 <epoll_ctl>
 1b4:	36f80120 	tbz	w0, #31, 1d8 <main+0x1d8>
            close(client_fd);
 1b8:	2a1803e0 	mov	w0, w24
 1bc:	94000161 	bl	740 <close>
            client->fd = 0;
 1c0:	b8376a7f 	str	wzr, [x19, x23]
            continue;
 1c4:	17ffffcd 	b	f8 <main+0xf8>
  for(int i = 0; i < MAX_EVENTS - 1; i++){
 1c8:	91000463 	add	x3, x3, #0x1
 1cc:	f1003c7f 	cmp	x3, #0xf
 1d0:	54fffce1 	b.ne	16c <main+0x16c>  // b.any
 1d4:	17ffffcf 	b	110 <main+0x110>
          printf("New client connected fd=%d.\n", client_fd);
 1d8:	2a1803e1 	mov	w1, w24
 1dc:	aa1403e0 	mov	x0, x20
 1e0:	94000325 	bl	e74 <printf>
 1e4:	17ffffc5 	b	f8 <main+0xf8>
  for(int i = 0; i < MAX_EVENTS - 1; i++)
 1e8:	91000694 	add	x20, x20, #0x1
 1ec:	f1003e9f 	cmp	x20, #0xf
 1f0:	54fff981 	b.ne	120 <main+0x120>  // b.any
    for(int i = 0; i < nfds; i++){
 1f4:	1100077b 	add	w27, w27, #0x1
 1f8:	910042d6 	add	x22, x22, #0x10
 1fc:	17ffffb7 	b	d8 <main+0xd8>
        if(events[i].events & EPOLLIN){
 200:	2a1403f4 	mov	w20, w20
 204:	36000120 	tbz	w0, #0, 228 <main+0x228>
  while(client->output_len < OUTPUT_SIZE){
 208:	d2820203 	mov	x3, #0x1010                	// #4112
    memmove(client->output + client->output_len, buf, n);
 20c:	91004260 	add	x0, x19, #0x10
 210:	8b1c0000 	add	x0, x0, x28
 214:	f9003be0 	str	x0, [sp, #112]
  while(client->output_len < OUTPUT_SIZE){
 218:	9b034e97 	madd	x23, x20, x3, x19
 21c:	b9400ae2 	ldr	w2, [x23, #8]
 220:	713ffc5f 	cmp	w2, #0xfff
 224:	5400046d 	b.le	2b0 <main+0x2b0>
        if(events[i].events & EPOLLOUT)
 228:	b94002c0 	ldr	w0, [x22]
 22c:	36100120 	tbz	w0, #2, 250 <main+0x250>
  while(client->output_len > 0){
 230:	d2820203 	mov	x3, #0x1010                	// #4112
    int n = write(client->fd, client->output, client->output_len);
 234:	90000000 	adrp	x0, 0 <main>
 238:	913e8000 	add	x0, x0, #0xfa0
 23c:	8b1c0017 	add	x23, x0, x28
  while(client->output_len > 0){
 240:	9b034e9c 	madd	x28, x20, x3, x19
 244:	b9400b82 	ldr	w2, [x28, #8]
 248:	7100005f 	cmp	w2, #0x0
 24c:	540005ec 	b.gt	308 <main+0x308>
        if(client->read_closed && client->output_len == 0){
 250:	d2820200 	mov	x0, #0x1010                	// #4112
 254:	9b004e80 	madd	x0, x20, x0, x19
 258:	29410400 	ldp	w0, w1, [x0, #8]
 25c:	34000721 	cbz	w1, 340 <main+0x340>
 260:	34fff740 	cbz	w0, 148 <main+0x148>
    events |= EPOLLOUT;
 264:	7100001f 	cmp	w0, #0x0
  if(events == client->events)
 268:	d2820200 	mov	x0, #0x1010                	// #4112
    events |= EPOLLOUT;
 26c:	321e0301 	orr	w1, w24, #0x4
  if(events == client->events)
 270:	9b007e80 	mul	x0, x20, x0
    events |= EPOLLOUT;
 274:	1a98c038 	csel	w24, w1, w24, gt
  if(events == client->events)
 278:	8b000274 	add	x20, x19, x0
 27c:	b9400681 	ldr	w1, [x20, #4]
 280:	6b18003f 	cmp	w1, w24
 284:	54fffb80 	b.eq	1f4 <main+0x1f4>  // b.none
  ev.data.fd = client->fd;
 288:	b8606a62 	ldr	w2, [x19, x0]
  if(epoll_ctl(epoll_fd, EPOLL_CTL_MOD, client->fd, &ev) < 0)
 28c:	910643e3 	add	x3, sp, #0x190
 290:	2a1903e0 	mov	w0, w25
 294:	52800061 	mov	w1, #0x3                   	// #3
  ev.events = events;
 298:	b90193f8 	str	w24, [sp, #400]
  ev.data.fd = client->fd;
 29c:	b9019be2 	str	w2, [sp, #408]
  if(epoll_ctl(epoll_fd, EPOLL_CTL_MOD, client->fd, &ev) < 0)
 2a0:	940001b2 	bl	968 <epoll_ctl>
 2a4:	37fff520 	tbnz	w0, #31, 148 <main+0x148>
  client->events = events;
 2a8:	b9000698 	str	w24, [x20, #4]
  return 0;
 2ac:	17ffffd2 	b	1f4 <main+0x1f4>
    int space = OUTPUT_SIZE - client->output_len;
 2b0:	52820000 	mov	w0, #0x1000                	// #4096
 2b4:	4b020002 	sub	w2, w0, w2
    int size = space < READ_SIZE ? space : READ_SIZE;
 2b8:	7110005f 	cmp	w2, #0x400
    int n = read(client->fd, buf, size);
 2bc:	52808000 	mov	w0, #0x400                 	// #1024
 2c0:	1a80d042 	csel	w2, w2, w0, le
 2c4:	b94002e0 	ldr	w0, [x23]
 2c8:	910643e1 	add	x1, sp, #0x190
 2cc:	94000117 	bl	728 <read>
 2d0:	2a0003e2 	mov	w2, w0
    if(n == 0)
 2d4:	34000480 	cbz	w0, 364 <main+0x364>
    if(n < 0)
 2d8:	37fffa80 	tbnz	w0, #31, 228 <main+0x228>
    memmove(client->output + client->output_len, buf, n);
 2dc:	f9403be3 	ldr	x3, [sp, #112]
 2e0:	910643e1 	add	x1, sp, #0x190
 2e4:	b9800ae0 	ldrsw	x0, [x23, #8]
 2e8:	b9007fe2 	str	w2, [sp, #124]
 2ec:	8b000060 	add	x0, x3, x0
 2f0:	940000dd 	bl	664 <memmove>
    client->output_len += n;
 2f4:	b9400ae0 	ldr	w0, [x23, #8]
 2f8:	b9407fe2 	ldr	w2, [sp, #124]
 2fc:	0b020000 	add	w0, w0, w2
 300:	b9000ae0 	str	w0, [x23, #8]
 304:	17ffffc6 	b	21c <main+0x21c>
    int n = write(client->fd, client->output, client->output_len);
 308:	b9400380 	ldr	w0, [x28]
 30c:	aa1703e1 	mov	x1, x23
 310:	94000109 	bl	734 <write>
    if(n <= 0)
 314:	7100001f 	cmp	w0, #0x0
 318:	54fff9cd 	b.le	250 <main+0x250>
    client->output_len -= n;
 31c:	b9400b82 	ldr	w2, [x28, #8]
 320:	4b000042 	sub	w2, w2, w0
 324:	b9000b82 	str	w2, [x28, #8]
    if(client->output_len > 0)
 328:	7100005f 	cmp	w2, #0x0
 32c:	54fff8cd 	b.le	244 <main+0x244>
      memmove(client->output, client->output + n, client->output_len);
 330:	8b2042e1 	add	x1, x23, w0, uxtw
 334:	aa1703e0 	mov	x0, x23
 338:	940000cb 	bl	664 <memmove>
 33c:	17ffffc2 	b	244 <main+0x244>
  if(!client->read_closed && client->output_len < OUTPUT_SIZE)
 340:	713ffc1f 	cmp	w0, #0xfff
 344:	1a9fc7f8 	cset	w24, le
 348:	17ffffc7 	b	264 <main+0x264>
        }
      }
    }
  }
  close(epoll_fd);
 34c:	2a1903e0 	mov	w0, w25
 350:	940000fc 	bl	740 <close>
  close(server_fd);
 354:	2a1503e0 	mov	w0, w21
 358:	940000fa 	bl	740 <close>
  exit(0);
 35c:	52800000 	mov	w0, #0x0                   	// #0
 360:	17ffff3c 	b	50 <main+0x50>
            client->read_closed = 1;
 364:	52800020 	mov	w0, #0x1                   	// #1
 368:	b9000ee0 	str	w0, [x23, #12]
 36c:	17ffffaf 	b	228 <main+0x228>

0000000000000370 <close_client>:
{
 370:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  epoll_ctl(epoll_fd, EPOLL_CTL_DEL, client->fd, 0);
 374:	d2800003 	mov	x3, #0x0                   	// #0
{
 378:	910003fd 	mov	x29, sp
 37c:	f9000bf3 	str	x19, [sp, #16]
 380:	aa0103f3 	mov	x19, x1
  epoll_ctl(epoll_fd, EPOLL_CTL_DEL, client->fd, 0);
 384:	52800041 	mov	w1, #0x2                   	// #2
 388:	b9400262 	ldr	w2, [x19]
 38c:	94000177 	bl	968 <epoll_ctl>
  close(client->fd);
 390:	b9400260 	ldr	w0, [x19]
 394:	940000eb 	bl	740 <close>
  client->fd = 0;
 398:	a9007e7f 	stp	xzr, xzr, [x19]
}
 39c:	f9400bf3 	ldr	x19, [sp, #16]
 3a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
 3a4:	d65f03c0 	ret

00000000000003a8 <set_nonblocking>:
{
 3a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  int flags = fcntl(fd, F_GETFL, 0);
 3ac:	52800002 	mov	w2, #0x0                   	// #0
 3b0:	52800061 	mov	w1, #0x3                   	// #3
{
 3b4:	910003fd 	mov	x29, sp
 3b8:	f9000bf3 	str	x19, [sp, #16]
 3bc:	2a0003f3 	mov	w19, w0
  int flags = fcntl(fd, F_GETFL, 0);
 3c0:	94000170 	bl	980 <fcntl>
  if(flags < 0)
 3c4:	37f800e0 	tbnz	w0, #31, 3e0 <set_nonblocking+0x38>
  return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
 3c8:	32150002 	orr	w2, w0, #0x800
 3cc:	2a1303e0 	mov	w0, w19
}
 3d0:	f9400bf3 	ldr	x19, [sp, #16]
  return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
 3d4:	52800081 	mov	w1, #0x4                   	// #4
}
 3d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
  return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
 3dc:	14000169 	b	980 <fcntl>
}
 3e0:	f9400bf3 	ldr	x19, [sp, #16]
 3e4:	12800000 	mov	w0, #0xffffffff            	// #-1
 3e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
 3ec:	d65f03c0 	ret

00000000000003f0 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 3f0:	d2800002 	mov	x2, #0x0                   	// #0
 3f4:	38626823 	ldrb	w3, [x1, x2]
 3f8:	38226803 	strb	w3, [x0, x2]
 3fc:	91000442 	add	x2, x2, #0x1
 400:	35ffffa3 	cbnz	w3, 3f4 <strcpy+0x4>
    ;
  return os;
}
 404:	d65f03c0 	ret

0000000000000408 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 408:	d2800003 	mov	x3, #0x0                   	// #0
 40c:	4b030044 	sub	w4, w2, w3
 410:	7100009f 	cmp	w4, #0x0
 414:	5400006d 	b.le	420 <strncpy+0x18>
 418:	38636825 	ldrb	w5, [x1, x3]
 41c:	350000e5 	cbnz	w5, 438 <strncpy+0x30>
 420:	8b030003 	add	x3, x0, x3
 424:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 428:	4b010082 	sub	w2, w4, w1
 42c:	7100005f 	cmp	w2, #0x0
 430:	540000ac 	b.gt	444 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 434:	d65f03c0 	ret
    *s++ = *t++;
 438:	38236805 	strb	w5, [x0, x3]
    n--;
 43c:	91000463 	add	x3, x3, #0x1
 440:	17fffff3 	b	40c <strncpy+0x4>
    *s++ = 0;
 444:	3821687f 	strb	wzr, [x3, x1]
 448:	91000421 	add	x1, x1, #0x1
 44c:	17fffff7 	b	428 <strncpy+0x20>

0000000000000450 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 450:	aa0003e2 	mov	x2, x0
 454:	39400043 	ldrb	w3, [x2]
 458:	aa0203e4 	mov	x4, x2
    s++;
 45c:	91000442 	add	x2, x2, #0x1
  while(*s)
 460:	35ffffa3 	cbnz	w3, 454 <strcat+0x4>
 464:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 468:	38626823 	ldrb	w3, [x1, x2]
 46c:	38226883 	strb	w3, [x4, x2]
 470:	91000442 	add	x2, x2, #0x1
 474:	35ffffa3 	cbnz	w3, 468 <strcat+0x18>
    ;
  return os;
}
 478:	d65f03c0 	ret

000000000000047c <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 47c:	d2800002 	mov	x2, #0x0                   	// #0
 480:	38626803 	ldrb	w3, [x0, x2]
 484:	38626824 	ldrb	w4, [x1, x2]
 488:	34000083 	cbz	w3, 498 <strcmp+0x1c>
 48c:	91000442 	add	x2, x2, #0x1
 490:	6b04007f 	cmp	w3, w4
 494:	54ffff60 	b.eq	480 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 498:	4b040060 	sub	w0, w3, w4
 49c:	d65f03c0 	ret

00000000000004a0 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 4a0:	340001c2 	cbz	w2, 4d8 <strncmp+0x38>
 4a4:	39400003 	ldrb	w3, [x0]
 4a8:	34000083 	cbz	w3, 4b8 <strncmp+0x18>
 4ac:	39400024 	ldrb	w4, [x1]
 4b0:	6b03009f 	cmp	w4, w3
 4b4:	540000a0 	b.eq	4c8 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 4b8:	39400000 	ldrb	w0, [x0]
 4bc:	39400021 	ldrb	w1, [x1]
 4c0:	4b010000 	sub	w0, w0, w1
}
 4c4:	d65f03c0 	ret
    n--, p++, q++;
 4c8:	51000442 	sub	w2, w2, #0x1
 4cc:	91000400 	add	x0, x0, #0x1
 4d0:	91000421 	add	x1, x1, #0x1
 4d4:	17fffff3 	b	4a0 <strncmp>
    return 0;
 4d8:	52800000 	mov	w0, #0x0                   	// #0
 4dc:	17fffffa 	b	4c4 <strncmp+0x24>

00000000000004e0 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 4e0:	d1000402 	sub	x2, x0, #0x1
 4e4:	d2800001 	mov	x1, #0x0                   	// #0
 4e8:	aa0103e0 	mov	x0, x1
 4ec:	91000421 	add	x1, x1, #0x1
 4f0:	38616843 	ldrb	w3, [x2, x1]
 4f4:	35ffffa3 	cbnz	w3, 4e8 <strlen+0x8>
    ;
  return n;
}
 4f8:	d65f03c0 	ret

00000000000004fc <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 4fc:	d1000403 	sub	x3, x0, #0x1
 500:	d2800002 	mov	x2, #0x0                   	// #0
 504:	2a0203e0 	mov	w0, w2
 508:	6b02003f 	cmp	w1, w2
 50c:	54000089 	b.ls	51c <strnlen+0x20>  // b.plast
 510:	91000442 	add	x2, x2, #0x1
 514:	38626864 	ldrb	w4, [x3, x2]
 518:	35ffff64 	cbnz	w4, 504 <strnlen+0x8>
    n++;
  return n;
}
 51c:	d65f03c0 	ret

0000000000000520 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 520:	d2800003 	mov	x3, #0x0                   	// #0
 524:	6b03005f 	cmp	w2, w3
 528:	54000048 	b.hi	530 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 52c:	d65f03c0 	ret
    cdst[i] = c;
 530:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 534:	91000463 	add	x3, x3, #0x1
 538:	17fffffb 	b	524 <memset+0x4>

000000000000053c <strchr>:

char*
strchr(const char *s, char c)
{
 53c:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 540:	39400002 	ldrb	w2, [x0]
 544:	35000062 	cbnz	w2, 550 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 548:	d2800000 	mov	x0, #0x0                   	// #0
}
 54c:	d65f03c0 	ret
    if(*s == c)
 550:	6b01005f 	cmp	w2, w1
 554:	54ffffc0 	b.eq	54c <strchr+0x10>  // b.none
  for(; *s; s++)
 558:	91000400 	add	x0, x0, #0x1
 55c:	17fffff9 	b	540 <strchr+0x4>

0000000000000560 <gets>:

char*
gets(char *buf, int max)
{
 560:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 564:	910003fd 	mov	x29, sp
 568:	a90153f3 	stp	x19, x20, [sp, #16]
 56c:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 570:	d2800014 	mov	x20, #0x0                   	// #0
{
 574:	f9001bf7 	str	x23, [sp, #48]
 578:	2a0103f7 	mov	w23, w1
 57c:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 580:	11000695 	add	w21, w20, #0x1
 584:	2a1403f6 	mov	w22, w20
 588:	6b1702bf 	cmp	w21, w23
 58c:	540000ea 	b.ge	5a8 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 590:	91013fe1 	add	x1, sp, #0x4f
 594:	52800022 	mov	w2, #0x1                   	// #1
 598:	52800000 	mov	w0, #0x0                   	// #0
 59c:	94000063 	bl	728 <read>
    if(cc < 1)
 5a0:	7100001f 	cmp	w0, #0x0
 5a4:	5400012c 	b.gt	5c8 <gets+0x68>
  for(i=0; i+1 < max; ){
 5a8:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 5ac:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 5b0:	aa1303e0 	mov	x0, x19
 5b4:	f9401bf7 	ldr	x23, [sp, #48]
 5b8:	a94153f3 	ldp	x19, x20, [sp, #16]
 5bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
 5c0:	a8c57bfd 	ldp	x29, x30, [sp], #80
 5c4:	d65f03c0 	ret
    buf[i++] = c;
 5c8:	39413fe0 	ldrb	w0, [sp, #79]
 5cc:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 5d0:	91000694 	add	x20, x20, #0x1
 5d4:	7100281f 	cmp	w0, #0xa
 5d8:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 5dc:	54fffd21 	b.ne	580 <gets+0x20>  // b.any
 5e0:	17fffff3 	b	5ac <gets+0x4c>

00000000000005e4 <stat>:

int
stat(const char *n, struct stat *st)
{
 5e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 5e8:	910003fd 	mov	x29, sp
 5ec:	a90153f3 	stp	x19, x20, [sp, #16]
 5f0:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 5f4:	52800001 	mov	w1, #0x0                   	// #0
 5f8:	9400005b 	bl	764 <open>
  if(fd < 0)
 5fc:	37f80160 	tbnz	w0, #31, 628 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 600:	aa1303e1 	mov	x1, x19
 604:	2a0003f4 	mov	w20, w0
 608:	94000060 	bl	788 <fstat>
 60c:	2a0003f3 	mov	w19, w0
  close(fd);
 610:	2a1403e0 	mov	w0, w20
 614:	9400004b 	bl	740 <close>
  return r;
}
 618:	2a1303e0 	mov	w0, w19
 61c:	a94153f3 	ldp	x19, x20, [sp, #16]
 620:	a8c27bfd 	ldp	x29, x30, [sp], #32
 624:	d65f03c0 	ret
    return -1;
 628:	12800013 	mov	w19, #0xffffffff            	// #-1
 62c:	17fffffb 	b	618 <stat+0x34>

0000000000000630 <atoi>:

int
atoi(const char *s)
{
 630:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 634:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 638:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 63c:	39400043 	ldrb	w3, [x2]
 640:	5100c061 	sub	w1, w3, #0x30
 644:	12001c21 	and	w1, w1, #0xff
 648:	7100243f 	cmp	w1, #0x9
 64c:	54000049 	b.ls	654 <atoi+0x24>  // b.plast
  return n;
}
 650:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 654:	1b040c01 	madd	w1, w0, w4, w3
 658:	91000442 	add	x2, x2, #0x1
 65c:	5100c020 	sub	w0, w1, #0x30
 660:	17fffff7 	b	63c <atoi+0xc>

0000000000000664 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 664:	eb01001f 	cmp	x0, x1
 668:	54000263 	b.cc	6b4 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 66c:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 670:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 674:	d2800003 	mov	x3, #0x0                   	// #0
 678:	d1000463 	sub	x3, x3, #0x1
 67c:	11000464 	add	w4, w3, #0x1
 680:	0b020084 	add	w4, w4, w2
 684:	7100009f 	cmp	w4, #0x0
 688:	5400014d 	b.le	6b0 <memmove+0x4c>
      *--dst = *--src;
 68c:	38636824 	ldrb	w4, [x1, x3]
 690:	382368a4 	strb	w4, [x5, x3]
 694:	17fffff9 	b	678 <memmove+0x14>
      *dst++ = *src++;
 698:	38636824 	ldrb	w4, [x1, x3]
 69c:	38236804 	strb	w4, [x0, x3]
 6a0:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 6a4:	4b030044 	sub	w4, w2, w3
 6a8:	7100009f 	cmp	w4, #0x0
 6ac:	54ffff6c 	b.gt	698 <memmove+0x34>
  }
  return vdst;
}
 6b0:	d65f03c0 	ret
 6b4:	d2800003 	mov	x3, #0x0                   	// #0
 6b8:	17fffffb 	b	6a4 <memmove+0x40>

00000000000006bc <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 6bc:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 6c0:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 6c4:	d2800004 	mov	x4, #0x0                   	// #0
 6c8:	eb02009f 	cmp	x4, x2
 6cc:	54000061 	b.ne	6d8 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 6d0:	52800000 	mov	w0, #0x0                   	// #0
 6d4:	14000007 	b	6f0 <memcmp+0x34>
    if (*p1 != *p2) {
 6d8:	38646803 	ldrb	w3, [x0, x4]
 6dc:	91000484 	add	x4, x4, #0x1
 6e0:	38646825 	ldrb	w5, [x1, x4]
 6e4:	6b05007f 	cmp	w3, w5
 6e8:	54ffff00 	b.eq	6c8 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 6ec:	4b050060 	sub	w0, w3, w5
}
 6f0:	d65f03c0 	ret

00000000000006f4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 6f4:	17ffffdc 	b	664 <memmove>

00000000000006f8 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 6f8:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 6fc:	d4000001 	svc	#0x0
 ret
 700:	d65f03c0 	ret

0000000000000704 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 704:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 708:	d4000001 	svc	#0x0
 ret
 70c:	d65f03c0 	ret

0000000000000710 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 710:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 714:	d4000001 	svc	#0x0
 ret
 718:	d65f03c0 	ret

000000000000071c <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 71c:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 720:	d4000001 	svc	#0x0
 ret
 724:	d65f03c0 	ret

0000000000000728 <read>:
.global read
read:
 mov x7, #SYS_read
 728:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 72c:	d4000001 	svc	#0x0
 ret
 730:	d65f03c0 	ret

0000000000000734 <write>:
.global write
write:
 mov x7, #SYS_write
 734:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 738:	d4000001 	svc	#0x0
 ret
 73c:	d65f03c0 	ret

0000000000000740 <close>:
.global close
close:
 mov x7, #SYS_close
 740:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 744:	d4000001 	svc	#0x0
 ret
 748:	d65f03c0 	ret

000000000000074c <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 74c:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 750:	d4000001 	svc	#0x0
 ret
 754:	d65f03c0 	ret

0000000000000758 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 758:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 75c:	d4000001 	svc	#0x0
 ret
 760:	d65f03c0 	ret

0000000000000764 <open>:
.global open
open:
 mov x7, #SYS_open
 764:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 768:	d4000001 	svc	#0x0
 ret
 76c:	d65f03c0 	ret

0000000000000770 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 770:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 774:	d4000001 	svc	#0x0
 ret
 778:	d65f03c0 	ret

000000000000077c <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 77c:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 780:	d4000001 	svc	#0x0
 ret
 784:	d65f03c0 	ret

0000000000000788 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 788:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 78c:	d4000001 	svc	#0x0
 ret
 790:	d65f03c0 	ret

0000000000000794 <link>:
.global link
link:
 mov x7, #SYS_link
 794:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 798:	d4000001 	svc	#0x0
 ret
 79c:	d65f03c0 	ret

00000000000007a0 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 7a0:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 7a4:	d4000001 	svc	#0x0
 ret
 7a8:	d65f03c0 	ret

00000000000007ac <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 7ac:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 7b0:	d4000001 	svc	#0x0
 ret
 7b4:	d65f03c0 	ret

00000000000007b8 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 7b8:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 7bc:	d4000001 	svc	#0x0
 ret
 7c0:	d65f03c0 	ret

00000000000007c4 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 7c4:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 7c8:	d4000001 	svc	#0x0
 ret
 7cc:	d65f03c0 	ret

00000000000007d0 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 7d0:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 7d4:	d4000001 	svc	#0x0
 ret
 7d8:	d65f03c0 	ret

00000000000007dc <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 7dc:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 7e0:	d4000001 	svc	#0x0
 ret
 7e4:	d65f03c0 	ret

00000000000007e8 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 7e8:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 7ec:	d4000001 	svc	#0x0
 ret
 7f0:	d65f03c0 	ret

00000000000007f4 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 7f4:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 7f8:	d4000001 	svc	#0x0
 ret
 7fc:	d65f03c0 	ret

0000000000000800 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 800:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 804:	d4000001 	svc	#0x0
 ret
 808:	d65f03c0 	ret

000000000000080c <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 80c:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 810:	d4000001 	svc	#0x0
 ret
 814:	d65f03c0 	ret

0000000000000818 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 818:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 81c:	d4000001 	svc	#0x0
 ret
 820:	d65f03c0 	ret

0000000000000824 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 824:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 828:	d4000001 	svc	#0x0
 ret
 82c:	d65f03c0 	ret

0000000000000830 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 830:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 834:	d4000001 	svc	#0x0
 ret
 838:	d65f03c0 	ret

000000000000083c <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 83c:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 840:	d4000001 	svc	#0x0
 ret
 844:	d65f03c0 	ret

0000000000000848 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 848:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 84c:	d4000001 	svc	#0x0
 ret
 850:	d65f03c0 	ret

0000000000000854 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 854:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 858:	d4000001 	svc	#0x0
 ret
 85c:	d65f03c0 	ret

0000000000000860 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 860:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 864:	d4000001 	svc	#0x0
 ret
 868:	d65f03c0 	ret

000000000000086c <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 86c:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 870:	d4000001 	svc	#0x0
 ret
 874:	d65f03c0 	ret

0000000000000878 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 878:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 87c:	d4000001 	svc	#0x0
 ret
 880:	d65f03c0 	ret

0000000000000884 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 884:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 888:	d4000001 	svc	#0x0
 ret
 88c:	d65f03c0 	ret

0000000000000890 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 890:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 894:	d4000001 	svc	#0x0
 ret
 898:	d65f03c0 	ret

000000000000089c <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 89c:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 8a0:	d4000001 	svc	#0x0
 ret
 8a4:	d65f03c0 	ret

00000000000008a8 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 8a8:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 8ac:	d4000001 	svc	#0x0
 ret
 8b0:	d65f03c0 	ret

00000000000008b4 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 8b4:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 8b8:	d4000001 	svc	#0x0
 ret
 8bc:	d65f03c0 	ret

00000000000008c0 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 8c0:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 8c4:	d4000001 	svc	#0x0
 ret
 8c8:	d65f03c0 	ret

00000000000008cc <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 8cc:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 8d0:	d4000001 	svc	#0x0
 ret
 8d4:	d65f03c0 	ret

00000000000008d8 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 8d8:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 8dc:	d4000001 	svc	#0x0
 ret
 8e0:	d65f03c0 	ret

00000000000008e4 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 8e4:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 8e8:	d4000001 	svc	#0x0
 ret
 8ec:	d65f03c0 	ret

00000000000008f0 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 8f0:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 8f4:	d4000001 	svc	#0x0
 ret
 8f8:	d65f03c0 	ret

00000000000008fc <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 8fc:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 900:	d4000001 	svc	#0x0
 ret
 904:	d65f03c0 	ret

0000000000000908 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 908:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 90c:	d4000001 	svc	#0x0
 ret
 910:	d65f03c0 	ret

0000000000000914 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 914:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 918:	d4000001 	svc	#0x0
 ret
 91c:	d65f03c0 	ret

0000000000000920 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 920:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 924:	d4000001 	svc	#0x0
 ret
 928:	d65f03c0 	ret

000000000000092c <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 92c:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 930:	d4000001 	svc	#0x0
 ret
 934:	d65f03c0 	ret

0000000000000938 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 938:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 93c:	d4000001 	svc	#0x0
 ret
 940:	d65f03c0 	ret

0000000000000944 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 944:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 948:	d4000001 	svc	#0x0
 ret
 94c:	d65f03c0 	ret

0000000000000950 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 950:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 954:	d4000001 	svc	#0x0
 ret
 958:	d65f03c0 	ret

000000000000095c <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 95c:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 960:	d4000001 	svc	#0x0
 ret
 964:	d65f03c0 	ret

0000000000000968 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 968:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 96c:	d4000001 	svc	#0x0
 ret
 970:	d65f03c0 	ret

0000000000000974 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 974:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 978:	d4000001 	svc	#0x0
 ret
 97c:	d65f03c0 	ret

0000000000000980 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 980:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 984:	d4000001 	svc	#0x0
 ret
 988:	d65f03c0 	ret

000000000000098c <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 98c:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 990:	d4000001 	svc	#0x0
 ret
 994:	d65f03c0 	ret

0000000000000998 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 998:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 99c:	d4000001 	svc	#0x0
 ret
 9a0:	d65f03c0 	ret

00000000000009a4 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 9a4:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 9a8:	d4000001 	svc	#0x0
 ret
 9ac:	d65f03c0 	ret

00000000000009b0 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 9b0:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 9b4:	d4000001 	svc	#0x0
 ret
 9b8:	d65f03c0 	ret

00000000000009bc <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 9bc:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 9c0:	d4000001 	svc	#0x0
 ret
 9c4:	d65f03c0 	ret

00000000000009c8 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 9c8:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 9cc:	d4000001 	svc	#0x0
 ret
 9d0:	d65f03c0 	ret

00000000000009d4 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 9d4:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 9d8:	d4000001 	svc	#0x0
 ret
 9dc:	d65f03c0 	ret

00000000000009e0 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 9e0:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 9e4:	d4000001 	svc	#0x0
 ret
 9e8:	d65f03c0 	ret

00000000000009ec <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 9ec:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 9f0:	d4000001 	svc	#0x0
 ret
 9f4:	d65f03c0 	ret

00000000000009f8 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 9f8:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 9fc:	d4000001 	svc	#0x0
 ret
 a00:	d65f03c0 	ret

0000000000000a04 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 a04:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 a08:	d4000001 	svc	#0x0
 ret
 a0c:	d65f03c0 	ret

0000000000000a10 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 a10:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 a14:	d4000001 	svc	#0x0
 ret
 a18:	d65f03c0 	ret

0000000000000a1c <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 a1c:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 a20:	d4000001 	svc	#0x0
 ret
 a24:	d65f03c0 	ret

0000000000000a28 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 a28:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 a2c:	d4000001 	svc	#0x0
 ret
 a30:	d65f03c0 	ret

0000000000000a34 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 a34:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 a38:	d4000001 	svc	#0x0
 ret
 a3c:	d65f03c0 	ret

0000000000000a40 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 a40:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 a44:	d4000001 	svc	#0x0
 ret
 a48:	d65f03c0 	ret

0000000000000a4c <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 a4c:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 a50:	d4000001 	svc	#0x0
 ret
 a54:	d65f03c0 	ret

0000000000000a58 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 a58:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 a5c:	d4000001 	svc	#0x0
 ret
 a60:	d65f03c0 	ret

0000000000000a64 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 a64:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 a68:	52800022 	mov	w2, #0x1                   	// #1
{
 a6c:	910003fd 	mov	x29, sp
 a70:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 a74:	91007fe1 	add	x1, sp, #0x1f
 a78:	97ffff2f 	bl	734 <write>
 a7c:	7100041f 	cmp	w0, #0x1
}
 a80:	1a9f17e0 	cset	w0, eq	// eq = none
 a84:	a8c27bfd 	ldp	x29, x30, [sp], #32
 a88:	d65f03c0 	ret

0000000000000a8c <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 a8c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 a90:	910003fd 	mov	x29, sp
 a94:	a90153f3 	stp	x19, x20, [sp, #16]
 a98:	a9025bf5 	stp	x21, x22, [sp, #32]
 a9c:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 aa0:	6a417c7f 	tst	w3, w1, lsr #31
 aa4:	54000300 	b.eq	b04 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 aa8:	4b0103e1 	neg	w1, w1
    neg = 1;
 aac:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 ab0:	90000003 	adrp	x3, 0 <main>
 ab4:	913df863 	add	x3, x3, #0xf7e
 ab8:	9100c3f5 	add	x21, sp, #0x30
 abc:	d2800000 	mov	x0, #0x0                   	// #0
 ac0:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 ac4:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 ac8:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 acc:	2a0403e1 	mov	w1, w4
 ad0:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 ad4:	38666866 	ldrb	w6, [x3, x6]
 ad8:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 adc:	91000400 	add	x0, x0, #0x1
 ae0:	54ffff09 	b.ls	ac0 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 ae4:	11000493 	add	w19, w4, #0x1
  if(neg)
 ae8:	34000085 	cbz	w5, af8 <printint+0x6c>
    buf[i++] = '-';
 aec:	528005a0 	mov	w0, #0x2d                  	// #45
 af0:	38334aa0 	strb	w0, [x21, w19, uxtw]
 af4:	11000893 	add	w19, w4, #0x2
 af8:	51000673 	sub	w19, w19, #0x1
 afc:	52800014 	mov	w20, #0x0                   	// #0
 b00:	14000008 	b	b20 <printint+0x94>
  neg = 0;
 b04:	52800005 	mov	w5, #0x0                   	// #0
 b08:	17ffffea 	b	ab0 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 b0c:	38736aa1 	ldrb	w1, [x21, x19]
 b10:	2a1603e0 	mov	w0, w22
 b14:	d1000673 	sub	x19, x19, #0x1
 b18:	97ffffd3 	bl	a64 <putc>
 b1c:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 b20:	3100067f 	cmn	w19, #0x1
 b24:	54ffff41 	b.ne	b0c <printint+0x80>  // b.any
  return written;
}
 b28:	a9425bf5 	ldp	x21, x22, [sp, #32]
 b2c:	2a1403e0 	mov	w0, w20
 b30:	a94153f3 	ldp	x19, x20, [sp, #16]
 b34:	a8c47bfd 	ldp	x29, x30, [sp], #64
 b38:	d65f03c0 	ret

0000000000000b3c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 b3c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 b40:	910003fd 	mov	x29, sp
 b44:	a90153f3 	stp	x19, x20, [sp, #16]
 b48:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 b4c:	52800015 	mov	w21, #0x0                   	// #0
{
 b50:	a90363f7 	stp	x23, x24, [sp, #48]
 b54:	2a0003f7 	mov	w23, w0
 b58:	a9046bf9 	stp	x25, x26, [sp, #64]
 b5c:	aa0103f9 	mov	x25, x1

  state = 0;
 b60:	52800001 	mov	w1, #0x0                   	// #0
{
 b64:	a90573fb 	stp	x27, x28, [sp, #80]
 b68:	a9406053 	ldp	x19, x24, [x2]
 b6c:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 b70:	39400320 	ldrb	w0, [x25]
 b74:	35000120 	cbnz	w0, b98 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 b78:	2a1503e0 	mov	w0, w21
 b7c:	a94153f3 	ldp	x19, x20, [sp, #16]
 b80:	a9425bf5 	ldp	x21, x22, [sp, #32]
 b84:	a94363f7 	ldp	x23, x24, [sp, #48]
 b88:	a9446bf9 	ldp	x25, x26, [sp, #64]
 b8c:	a94573fb 	ldp	x27, x28, [sp, #80]
 b90:	a8c67bfd 	ldp	x29, x30, [sp], #96
 b94:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 b98:	2a0003f6 	mov	w22, w0
    if(state == 0){
 b9c:	35000101 	cbnz	w1, bbc <vprintf+0x80>
      if(c == '%'){
 ba0:	7100941f 	cmp	w0, #0x25
 ba4:	54000ba0 	b.eq	d18 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 ba8:	2a1603e1 	mov	w1, w22
 bac:	2a1703e0 	mov	w0, w23
 bb0:	97ffffad 	bl	a64 <putc>
 bb4:	0b0002b5 	add	w21, w21, w0
 bb8:	14000057 	b	d14 <vprintf+0x1d8>
      if(c == 'd'){
 bbc:	7101901f 	cmp	w0, #0x64
 bc0:	540002a1 	b.ne	c14 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 bc4:	37f80174 	tbnz	w20, #31, bf0 <vprintf+0xb4>
 bc8:	91002e76 	add	x22, x19, #0xb
 bcc:	2a1403fa 	mov	w26, w20
 bd0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 bd4:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 bd8:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 bdc:	b9400261 	ldr	w1, [x19]
 be0:	2a1703e0 	mov	w0, w23
 be4:	97ffffaa 	bl	a8c <printint>
        written += putc(fd, va_arg(ap, uint));
 be8:	0b0002b5 	add	w21, w21, w0
 bec:	14000048 	b	d0c <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 bf0:	1100229a 	add	w26, w20, #0x8
 bf4:	7100035f 	cmp	w26, #0x0
 bf8:	5400008d 	b.le	c08 <vprintf+0xcc>
 bfc:	91002e76 	add	x22, x19, #0xb
 c00:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c04:	17fffff4 	b	bd4 <vprintf+0x98>
 c08:	aa1303f6 	mov	x22, x19
 c0c:	8b34c313 	add	x19, x24, w20, sxtw
 c10:	17fffff1 	b	bd4 <vprintf+0x98>
      } else if(c == 'l') {
 c14:	7101b01f 	cmp	w0, #0x6c
 c18:	54000201 	b.ne	c58 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 c1c:	37f800d4 	tbnz	w20, #31, c34 <vprintf+0xf8>
 c20:	91003e76 	add	x22, x19, #0xf
 c24:	2a1403fa 	mov	w26, w20
 c28:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c2c:	52800003 	mov	w3, #0x0                   	// #0
 c30:	17ffffea 	b	bd8 <vprintf+0x9c>
 c34:	1100229a 	add	w26, w20, #0x8
 c38:	7100035f 	cmp	w26, #0x0
 c3c:	5400008d 	b.le	c4c <vprintf+0x110>
 c40:	91003e76 	add	x22, x19, #0xf
 c44:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c48:	17fffff9 	b	c2c <vprintf+0xf0>
 c4c:	aa1303f6 	mov	x22, x19
 c50:	8b34c313 	add	x19, x24, w20, sxtw
 c54:	17fffff6 	b	c2c <vprintf+0xf0>
      } else if(c == 'x') {
 c58:	7101e01f 	cmp	w0, #0x78
 c5c:	54000221 	b.ne	ca0 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 c60:	37f800f4 	tbnz	w20, #31, c7c <vprintf+0x140>
 c64:	91002e76 	add	x22, x19, #0xb
 c68:	2a1403fa 	mov	w26, w20
 c6c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c70:	52800003 	mov	w3, #0x0                   	// #0
 c74:	52800202 	mov	w2, #0x10                  	// #16
 c78:	17ffffd9 	b	bdc <vprintf+0xa0>
 c7c:	1100229a 	add	w26, w20, #0x8
 c80:	7100035f 	cmp	w26, #0x0
 c84:	5400008d 	b.le	c94 <vprintf+0x158>
 c88:	91002e76 	add	x22, x19, #0xb
 c8c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c90:	17fffff8 	b	c70 <vprintf+0x134>
 c94:	aa1303f6 	mov	x22, x19
 c98:	8b34c313 	add	x19, x24, w20, sxtw
 c9c:	17fffff5 	b	c70 <vprintf+0x134>
      } else if(c == 'p') {
 ca0:	7101c01f 	cmp	w0, #0x70
 ca4:	54000521 	b.ne	d48 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 ca8:	37f803f4 	tbnz	w20, #31, d24 <vprintf+0x1e8>
 cac:	91003e76 	add	x22, x19, #0xf
 cb0:	2a1403fa 	mov	w26, w20
 cb4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cb8:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 cbc:	52800601 	mov	w1, #0x30                  	// #48
 cc0:	2a1703e0 	mov	w0, w23
 cc4:	97ffff68 	bl	a64 <putc>
 cc8:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 ccc:	9000001c 	adrp	x28, 0 <main>
 cd0:	913dfb9c 	add	x28, x28, #0xf7e
  written += putc(fd, 'x');
 cd4:	2a1703e0 	mov	w0, w23
 cd8:	52800f01 	mov	w1, #0x78                  	// #120
 cdc:	97ffff62 	bl	a64 <putc>
 ce0:	0b000273 	add	w19, w19, w0
 ce4:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 ce8:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 cec:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 cf0:	38606b81 	ldrb	w1, [x28, x0]
 cf4:	2a1703e0 	mov	w0, w23
 cf8:	97ffff5b 	bl	a64 <putc>
 cfc:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 d00:	71000694 	subs	w20, w20, #0x1
 d04:	54ffff21 	b.ne	ce8 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 d08:	0b1302b5 	add	w21, w21, w19
 d0c:	2a1a03f4 	mov	w20, w26
 d10:	aa1603f3 	mov	x19, x22
      state = 0;
 d14:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 d18:	91000739 	add	x25, x25, #0x1
  state = 0;
 d1c:	2a1603e1 	mov	w1, w22
 d20:	17ffff94 	b	b70 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 d24:	1100229a 	add	w26, w20, #0x8
 d28:	7100035f 	cmp	w26, #0x0
 d2c:	5400008d 	b.le	d3c <vprintf+0x200>
 d30:	91003e76 	add	x22, x19, #0xf
 d34:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d38:	17ffffe0 	b	cb8 <vprintf+0x17c>
 d3c:	aa1303f6 	mov	x22, x19
 d40:	8b34c313 	add	x19, x24, w20, sxtw
 d44:	17ffffdd 	b	cb8 <vprintf+0x17c>
      } else if(c == 's'){
 d48:	7101cc1f 	cmp	w0, #0x73
 d4c:	54000381 	b.ne	dbc <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 d50:	37f80214 	tbnz	w20, #31, d90 <vprintf+0x254>
 d54:	91003e61 	add	x1, x19, #0xf
 d58:	aa1303e0 	mov	x0, x19
 d5c:	927df033 	and	x19, x1, #0xfffffffffffffff8
 d60:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 d64:	90000000 	adrp	x0, 0 <main>
 d68:	913ddc00 	add	x0, x0, #0xf77
 d6c:	f10002df 	cmp	x22, #0x0
 d70:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 d74:	394002c1 	ldrb	w1, [x22]
 d78:	34fffce1 	cbz	w1, d14 <vprintf+0x1d8>
          written += putc(fd, *s);
 d7c:	2a1703e0 	mov	w0, w23
          s++;
 d80:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 d84:	97ffff38 	bl	a64 <putc>
 d88:	0b0002b5 	add	w21, w21, w0
          s++;
 d8c:	17fffffa 	b	d74 <vprintf+0x238>
        s = va_arg(ap, char*);
 d90:	11002281 	add	w1, w20, #0x8
 d94:	7100003f 	cmp	w1, #0x0
 d98:	540000cd 	b.le	db0 <vprintf+0x274>
 d9c:	91003e62 	add	x2, x19, #0xf
 da0:	aa1303e0 	mov	x0, x19
 da4:	2a0103f4 	mov	w20, w1
 da8:	927df053 	and	x19, x2, #0xfffffffffffffff8
 dac:	17ffffed 	b	d60 <vprintf+0x224>
 db0:	8b34c300 	add	x0, x24, w20, sxtw
 db4:	2a0103f4 	mov	w20, w1
 db8:	17ffffea 	b	d60 <vprintf+0x224>
      } else if(c == 'c'){
 dbc:	71018c1f 	cmp	w0, #0x63
 dc0:	54000241 	b.ne	e08 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 dc4:	37f80114 	tbnz	w20, #31, de4 <vprintf+0x2a8>
 dc8:	91002e76 	add	x22, x19, #0xb
 dcc:	2a1403fa 	mov	w26, w20
 dd0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 dd4:	39400261 	ldrb	w1, [x19]
 dd8:	2a1703e0 	mov	w0, w23
 ddc:	97ffff22 	bl	a64 <putc>
 de0:	17ffff82 	b	be8 <vprintf+0xac>
 de4:	1100229a 	add	w26, w20, #0x8
 de8:	7100035f 	cmp	w26, #0x0
 dec:	5400008d 	b.le	dfc <vprintf+0x2c0>
 df0:	91002e76 	add	x22, x19, #0xb
 df4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 df8:	17fffff7 	b	dd4 <vprintf+0x298>
 dfc:	aa1303f6 	mov	x22, x19
 e00:	8b34c313 	add	x19, x24, w20, sxtw
 e04:	17fffff4 	b	dd4 <vprintf+0x298>
      } else if(c == '%'){
 e08:	7100941f 	cmp	w0, #0x25
 e0c:	54ffece0 	b.eq	ba8 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 e10:	2a1703e0 	mov	w0, w23
 e14:	528004a1 	mov	w1, #0x25                  	// #37
 e18:	97ffff13 	bl	a64 <putc>
 e1c:	0b0002b5 	add	w21, w21, w0
 e20:	17ffff62 	b	ba8 <vprintf+0x6c>

0000000000000e24 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 e24:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 e28:	910003fd 	mov	x29, sp
 e2c:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 e30:	910203e2 	add	x2, sp, #0x80
 e34:	a9030be2 	stp	x2, x2, [sp, #48]
 e38:	910143e2 	add	x2, sp, #0x50
 e3c:	f90023e2 	str	x2, [sp, #64]
 e40:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 e44:	b9004be2 	str	w2, [sp, #72]
 e48:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 e4c:	a9430fe2 	ldp	x2, x3, [sp, #48]
 e50:	a9010fe2 	stp	x2, x3, [sp, #16]
 e54:	a9440fe2 	ldp	x2, x3, [sp, #64]
 e58:	a9020fe2 	stp	x2, x3, [sp, #32]
 e5c:	910043e2 	add	x2, sp, #0x10
{
 e60:	a90617e4 	stp	x4, x5, [sp, #96]
 e64:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 e68:	97ffff35 	bl	b3c <vprintf>
  va_end(ap);
  return result;
}
 e6c:	a8c87bfd 	ldp	x29, x30, [sp], #128
 e70:	d65f03c0 	ret

0000000000000e74 <printf>:

int
printf(const char *fmt, ...)
{
 e74:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 e78:	910003fd 	mov	x29, sp
 e7c:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 e80:	910243e1 	add	x1, sp, #0x90
 e84:	a90307e1 	stp	x1, x1, [sp, #48]
 e88:	910143e1 	add	x1, sp, #0x50
 e8c:	f90023e1 	str	x1, [sp, #64]
 e90:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 e94:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 e98:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 e9c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 ea0:	52800020 	mov	w0, #0x1                   	// #1
{
 ea4:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 ea8:	a9430fe2 	ldp	x2, x3, [sp, #48]
 eac:	a9010fe2 	stp	x2, x3, [sp, #16]
 eb0:	a9440fe2 	ldp	x2, x3, [sp, #64]
 eb4:	a9020fe2 	stp	x2, x3, [sp, #32]
 eb8:	910043e2 	add	x2, sp, #0x10
{
 ebc:	a9079be5 	stp	x5, x6, [sp, #120]
 ec0:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 ec4:	97ffff1e 	bl	b3c <vprintf>
  va_end(ap);
  return result;
}
 ec8:	a8c97bfd 	ldp	x29, x30, [sp], #144
 ecc:	d65f03c0 	ret
