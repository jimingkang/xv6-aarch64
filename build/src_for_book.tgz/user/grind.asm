
user/_grind:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  exit(0);
}

int
main()
{
       0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
       4:	910003fd 	mov	x29, sp
  while(1){
    int pid = fork();
       8:	940002d1 	bl	b4c <fork>
    if(pid == 0){
       c:	35000040 	cbnz	w0, 14 <main+0x14>
      iter();
      10:	940001de 	bl	788 <iter>
      14:	7100001f 	cmp	w0, #0x0
      exit(0);
    }
    if(pid > 0){
      18:	5400006d 	b.le	24 <main+0x24>
      wait(0);
      1c:	d2800000 	mov	x0, #0x0                   	// #0
      20:	940002d1 	bl	b64 <wait>
    }
    sleep_ticks(20);
      24:	52800280 	mov	w0, #0x14                  	// #20
      28:	94000302 	bl	c30 <sleep_ticks>
  while(1){
      2c:	17fffff7 	b	8 <main+0x8>

0000000000000030 <do_rand>:
{
      30:	aa0003e3 	mov	x3, x0
    x = (*ctx % 0x7ffffffe) + 1;
      34:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
      38:	f9400061 	ldr	x1, [x3]
      3c:	9ac00822 	udiv	x2, x1, x0
      40:	9b008442 	msub	x2, x2, x0, x1
    lo = x % 127773;
      44:	d29e63a1 	mov	x1, #0xf31d                	// #62237
      48:	f2a00021 	movk	x1, #0x1, lsl #16
    x = (*ctx % 0x7ffffffe) + 1;
      4c:	91000442 	add	x2, x2, #0x1
    lo = x % 127773;
      50:	9ac10840 	udiv	x0, x2, x1
      54:	9b018801 	msub	x1, x0, x1, x2
    x = 16807 * lo - 2836 * hi;
      58:	12816262 	mov	w2, #0xfffff4ec            	// #-2836
      5c:	9b227c00 	smull	x0, w0, w2
      60:	528834e2 	mov	w2, #0x41a7                	// #16807
      64:	9b220021 	smaddl	x1, w1, w2, x0
        x += 0x7fffffff;
      68:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    if (x < 0)
      6c:	f100003f 	cmp	x1, #0x0
        x += 0x7fffffff;
      70:	8b000020 	add	x0, x1, x0
      74:	9a80a021 	csel	x1, x1, x0, ge	// ge = tcont
    x--;
      78:	d1000420 	sub	x0, x1, #0x1
    *ctx = x;
      7c:	f9000060 	str	x0, [x3]
}
      80:	d65f03c0 	ret

0000000000000084 <rand>:
    return (do_rand(&rand_next));
      84:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
      88:	91172000 	add	x0, x0, #0x5c8
      8c:	17ffffe9 	b	30 <do_rand>

0000000000000090 <go>:
{
      90:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
      94:	910003fd 	mov	x29, sp
      98:	a90153f3 	stp	x19, x20, [sp, #16]
      9c:	2a0003f3 	mov	w19, w0
  mkdir("grindir");
      a0:	b0000014 	adrp	x20, 1000 <vprintf+0x70>
      a4:	910ca294 	add	x20, x20, #0x328
  char *break0 = sbrk(0);
      a8:	52800000 	mov	w0, #0x0                   	// #0
{
      ac:	a9025bf5 	stp	x21, x22, [sp, #32]
      b0:	a90363f7 	stp	x23, x24, [sp, #48]
      b4:	a9046bf9 	stp	x25, x26, [sp, #64]
      b8:	a90573fb 	stp	x27, x28, [sp, #80]
  char *break0 = sbrk(0);
      bc:	940002da 	bl	c24 <sbrk>
      c0:	aa0003fc 	mov	x28, x0
  mkdir("grindir");
      c4:	aa1403e0 	mov	x0, x20
      c8:	940002cb 	bl	bf4 <mkdir>
  if(chdir("grindir") != 0){
      cc:	aa1403e0 	mov	x0, x20
      d0:	940002cc 	bl	c00 <chdir>
      d4:	340000c0 	cbz	w0, ec <go+0x5c>
    printf("grind: chdir grindir failed\n");
      d8:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
      dc:	910cc000 	add	x0, x0, #0x330
        printf("grind: fork failed\n");
      e0:	9400047a 	bl	12c8 <printf>
        exit(1);
      e4:	52800020 	mov	w0, #0x1                   	// #1
      e8:	14000080 	b	2e8 <go+0x258>
  chdir("/");
      ec:	b0000017 	adrp	x23, 1000 <vprintf+0x70>
      f0:	910d36f7 	add	x23, x23, #0x34d
      f4:	aa1703e0 	mov	x0, x23
      f8:	940002c2 	bl	c00 <chdir>
      fc:	7100027f 	cmp	w19, #0x0
     100:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     104:	910d3c21 	add	x1, x1, #0x34f
     108:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     10c:	910d4400 	add	x0, x0, #0x351
     110:	b0000018 	adrp	x24, 1000 <vprintf+0x70>
     114:	9115a318 	add	x24, x24, #0x568
     118:	9a801020 	csel	x0, x1, x0, ne	// ne = any
  uint64 iters = 0;
     11c:	d2800016 	mov	x22, #0x0                   	// #0
  int fd = -1;
     120:	12800013 	mov	w19, #0xffffffff            	// #-1
    iters++;
     124:	d2803e9b 	mov	x27, #0x1f4                 	// #500
     128:	f90033e0 	str	x0, [sp, #96]
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     12c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     130:	91154c00 	add	x0, x0, #0x553
     134:	f90037e0 	str	x0, [sp, #104]
    iters++;
     138:	910006d6 	add	x22, x22, #0x1
     13c:	9adb0ac0 	udiv	x0, x22, x27
     140:	9b1bd800 	msub	x0, x0, x27, x22
    if((iters % 500) == 0)
     144:	b50000a0 	cbnz	x0, 158 <go+0xc8>
      write(1, which_child?"B":"A", 1);
     148:	f94033e1 	ldr	x1, [sp, #96]
     14c:	52800022 	mov	w2, #0x1                   	// #1
     150:	2a0203e0 	mov	w0, w2
     154:	9400028d 	bl	b88 <write>
    int what = rand() % 23;
     158:	97ffffcb 	bl	84 <rand>
     15c:	528002e2 	mov	w2, #0x17                  	// #23
     160:	1ac20c01 	sdiv	w1, w0, w2
     164:	1b028020 	msub	w0, w1, w2, w0
     168:	51000400 	sub	w0, w0, #0x1
     16c:	7100541f 	cmp	w0, #0x15
     170:	54fffe48 	b.hi	138 <go+0xa8>  // b.pmore
     174:	78605b00 	ldrh	w0, [x24, w0, uxtw #1]
     178:	10000061 	adr	x1, 184 <go+0xf4>
     17c:	8b20a820 	add	x0, x1, w0, sxth #2
     180:	d61f0000 	br	x0
      close(open("grindir/../a", O_CREATE|O_RDWR));
     184:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     188:	910ec000 	add	x0, x0, #0x3b0
      close(open("grindir/../grindir/../b", O_CREATE|O_RDWR));
     18c:	52804041 	mov	w1, #0x202                 	// #514
     190:	9400028a 	bl	bb8 <open>
     194:	94000280 	bl	b94 <close>
     198:	17ffffe8 	b	138 <go+0xa8>
     19c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     1a0:	910d4c00 	add	x0, x0, #0x353
     1a4:	17fffffa 	b	18c <go+0xfc>
      unlink("grindir/../a");
     1a8:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     1ac:	910ec000 	add	x0, x0, #0x3b0
      unlink("c");
     1b0:	94000288 	bl	bd0 <unlink>
     1b4:	17ffffe1 	b	138 <go+0xa8>
      if(chdir("grindir") != 0){
     1b8:	aa1403e0 	mov	x0, x20
     1bc:	94000291 	bl	c00 <chdir>
     1c0:	35fff8c0 	cbnz	w0, d8 <go+0x48>
      unlink("../b");
     1c4:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     1c8:	910de000 	add	x0, x0, #0x378
     1cc:	94000281 	bl	bd0 <unlink>
      chdir("/");
     1d0:	aa1703e0 	mov	x0, x23
     1d4:	9400028b 	bl	c00 <chdir>
     1d8:	17ffffd8 	b	138 <go+0xa8>
      close(fd);
     1dc:	2a1303e0 	mov	w0, w19
     1e0:	9400026d 	bl	b94 <close>
      fd = open("/grindir/../a", O_CREATE|O_RDWR);
     1e4:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     1e8:	910ebc00 	add	x0, x0, #0x3af
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
     1ec:	52804041 	mov	w1, #0x202                 	// #514
     1f0:	94000272 	bl	bb8 <open>
     1f4:	2a0003f3 	mov	w19, w0
     1f8:	17ffffd0 	b	138 <go+0xa8>
      close(fd);
     1fc:	2a1303e0 	mov	w0, w19
     200:	94000265 	bl	b94 <close>
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
     204:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     208:	910dac00 	add	x0, x0, #0x36b
     20c:	17fffff8 	b	1ec <go+0x15c>
      write(fd, buf, sizeof(buf));
     210:	2a1303e0 	mov	w0, w19
     214:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     218:	91174021 	add	x1, x1, #0x5d0
     21c:	52807ce2 	mov	w2, #0x3e7                 	// #999
     220:	9400025a 	bl	b88 <write>
     224:	17ffffc5 	b	138 <go+0xa8>
      read(fd, buf, sizeof(buf));
     228:	2a1303e0 	mov	w0, w19
     22c:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     230:	91174021 	add	x1, x1, #0x5d0
     234:	52807ce2 	mov	w2, #0x3e7                 	// #999
     238:	94000251 	bl	b7c <read>
     23c:	17ffffbf 	b	138 <go+0xa8>
      mkdir("grindir/../a");
     240:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     244:	910ec000 	add	x0, x0, #0x3b0
     248:	9400026b 	bl	bf4 <mkdir>
      close(open("a/../a/./a", O_CREATE|O_RDWR));
     24c:	52804041 	mov	w1, #0x202                 	// #514
     250:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     254:	910df400 	add	x0, x0, #0x37d
     258:	94000258 	bl	bb8 <open>
     25c:	9400024e 	bl	b94 <close>
      unlink("a/a");
     260:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     264:	910e2000 	add	x0, x0, #0x388
     268:	17ffffd2 	b	1b0 <go+0x120>
      mkdir("/../b");
     26c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     270:	910ddc00 	add	x0, x0, #0x377
     274:	94000260 	bl	bf4 <mkdir>
      close(open("grindir/../b/b", O_CREATE|O_RDWR));
     278:	52804041 	mov	w1, #0x202                 	// #514
     27c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     280:	910e3000 	add	x0, x0, #0x38c
     284:	9400024d 	bl	bb8 <open>
     288:	94000243 	bl	b94 <close>
      unlink("b/b");
     28c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     290:	910e5c00 	add	x0, x0, #0x397
     294:	17ffffc7 	b	1b0 <go+0x120>
      unlink("b");
     298:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     29c:	910dec00 	add	x0, x0, #0x37b
     2a0:	9400024c 	bl	bd0 <unlink>
      link("../grindir/./../a", "../b");
     2a4:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     2a8:	910de021 	add	x1, x1, #0x378
     2ac:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     2b0:	910e6c00 	add	x0, x0, #0x39b
      link(".././b", "/grindir/../a");
     2b4:	9400024d 	bl	be8 <link>
     2b8:	17ffffa0 	b	138 <go+0xa8>
      unlink("../grindir/../a");
     2bc:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     2c0:	910eb400 	add	x0, x0, #0x3ad
     2c4:	94000243 	bl	bd0 <unlink>
      link(".././b", "/grindir/../a");
     2c8:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     2cc:	910ebc21 	add	x1, x1, #0x3af
     2d0:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     2d4:	910ef400 	add	x0, x0, #0x3bd
     2d8:	17fffff7 	b	2b4 <go+0x224>
      int pid = fork();
     2dc:	9400021c 	bl	b4c <fork>
      if(pid == 0){
     2e0:	35000060 	cbnz	w0, 2ec <go+0x25c>
        exit(0);
     2e4:	52800000 	mov	w0, #0x0                   	// #0
     2e8:	9400021c 	bl	b58 <exit>
      } else if(pid < 0){
     2ec:	36f804e0 	tbz	w0, #31, 388 <go+0x2f8>
        printf("grind: fork failed\n");
     2f0:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     2f4:	910f1000 	add	x0, x0, #0x3c4
     2f8:	17ffff7a 	b	e0 <go+0x50>
      int pid = fork();
     2fc:	94000214 	bl	b4c <fork>
      if(pid == 0){
     300:	35ffff60 	cbnz	w0, 2ec <go+0x25c>
        fork();
     304:	94000212 	bl	b4c <fork>
        fork();
     308:	94000211 	bl	b4c <fork>
        exit(0);
     30c:	17fffff6 	b	2e4 <go+0x254>
      sbrk(6011);
     310:	5282ef60 	mov	w0, #0x177b                	// #6011
        sbrk(-(sbrk(0) - break0));
     314:	94000244 	bl	c24 <sbrk>
     318:	17ffff88 	b	138 <go+0xa8>
      if(sbrk(0) > break0)
     31c:	52800000 	mov	w0, #0x0                   	// #0
     320:	94000241 	bl	c24 <sbrk>
     324:	eb1c001f 	cmp	x0, x28
     328:	54fff089 	b.ls	138 <go+0xa8>  // b.plast
        sbrk(-(sbrk(0) - break0));
     32c:	52800000 	mov	w0, #0x0                   	// #0
     330:	9400023d 	bl	c24 <sbrk>
     334:	4b000380 	sub	w0, w28, w0
     338:	17fffff7 	b	314 <go+0x284>
      int pid = fork();
     33c:	94000204 	bl	b4c <fork>
     340:	2a0003f5 	mov	w21, w0
      if(pid == 0){
     344:	350000e0 	cbnz	w0, 360 <go+0x2d0>
        close(open("a", O_CREATE|O_RDWR));
     348:	52804041 	mov	w1, #0x202                 	// #514
     34c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     350:	910eac00 	add	x0, x0, #0x3ab
     354:	94000219 	bl	bb8 <open>
     358:	9400020f 	bl	b94 <close>
        exit(0);
     35c:	17ffffe2 	b	2e4 <go+0x254>
      } else if(pid < 0){
     360:	37fffc80 	tbnz	w0, #31, 2f0 <go+0x260>
      if(chdir("../grindir/..") != 0){
     364:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     368:	910f6000 	add	x0, x0, #0x3d8
     36c:	94000225 	bl	c00 <chdir>
     370:	34000080 	cbz	w0, 380 <go+0x2f0>
        printf("grind: chdir failed\n");
     374:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     378:	910f9800 	add	x0, x0, #0x3e6
     37c:	17ffff59 	b	e0 <go+0x50>
      kill(pid);
     380:	2a1503e0 	mov	w0, w21
     384:	94000207 	bl	ba0 <kill>
      wait(0);
     388:	d2800000 	mov	x0, #0x0                   	// #0
     38c:	940001f6 	bl	b64 <wait>
     390:	17ffff6a 	b	138 <go+0xa8>
      int pid = fork();
     394:	940001ee 	bl	b4c <fork>
      if(pid == 0){
     398:	35fffaa0 	cbnz	w0, 2ec <go+0x25c>
        kill(getpid());
     39c:	9400021f 	bl	c18 <getpid>
     3a0:	94000200 	bl	ba0 <kill>
        exit(0);
     3a4:	17ffffd0 	b	2e4 <go+0x254>
      if(pipe(fds) < 0){
     3a8:	910223e0 	add	x0, sp, #0x88
     3ac:	940001f1 	bl	b70 <pipe>
     3b0:	36f80080 	tbz	w0, #31, 3c0 <go+0x330>
        printf("grind: pipe failed\n");
     3b4:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     3b8:	910fec00 	add	x0, x0, #0x3fb
     3bc:	17ffff49 	b	e0 <go+0x50>
      int pid = fork();
     3c0:	940001e3 	bl	b4c <fork>
      if(pid == 0){
     3c4:	350002e0 	cbnz	w0, 420 <go+0x390>
        fork();
     3c8:	940001e1 	bl	b4c <fork>
        fork();
     3cc:	940001e0 	bl	b4c <fork>
        if(write(fds[1], "x", 1) != 1)
     3d0:	b9408fe0 	ldr	w0, [sp, #140]
     3d4:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     3d8:	91103c21 	add	x1, x1, #0x40f
     3dc:	52800022 	mov	w2, #0x1                   	// #1
     3e0:	940001ea 	bl	b88 <write>
     3e4:	7100041f 	cmp	w0, #0x1
     3e8:	54000080 	b.eq	3f8 <go+0x368>  // b.none
          printf("grind: pipe write failed\n");
     3ec:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     3f0:	91104400 	add	x0, x0, #0x411
     3f4:	940003b5 	bl	12c8 <printf>
        if(read(fds[0], &c, 1) != 1)
     3f8:	b9408be0 	ldr	w0, [sp, #136]
     3fc:	910203e1 	add	x1, sp, #0x80
     400:	52800022 	mov	w2, #0x1                   	// #1
     404:	940001de 	bl	b7c <read>
     408:	7100041f 	cmp	w0, #0x1
     40c:	54fff6c0 	b.eq	2e4 <go+0x254>  // b.none
          printf("grind: pipe read failed\n");
     410:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     414:	9110ac00 	add	x0, x0, #0x42b
     418:	940003ac 	bl	12c8 <printf>
     41c:	17ffffb2 	b	2e4 <go+0x254>
      } else if(pid < 0){
     420:	37fff680 	tbnz	w0, #31, 2f0 <go+0x260>
      close(fds[0]);
     424:	b9408be0 	ldr	w0, [sp, #136]
     428:	940001db 	bl	b94 <close>
      close(fds[1]);
     42c:	b9408fe0 	ldr	w0, [sp, #140]
     430:	940001d9 	bl	b94 <close>
      wait(0);
     434:	17ffffd5 	b	388 <go+0x2f8>
      int pid = fork();
     438:	940001c5 	bl	b4c <fork>
      if(pid == 0){
     43c:	35fff580 	cbnz	w0, 2ec <go+0x25c>
        unlink("a");
     440:	b0000013 	adrp	x19, 1000 <vprintf+0x70>
     444:	910eae60 	add	x0, x19, #0x3ab
     448:	940001e2 	bl	bd0 <unlink>
        mkdir("a");
     44c:	910eae60 	add	x0, x19, #0x3ab
     450:	940001e9 	bl	bf4 <mkdir>
        chdir("a");
     454:	910eae60 	add	x0, x19, #0x3ab
     458:	940001ea 	bl	c00 <chdir>
        unlink("../a");
     45c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     460:	910ea000 	add	x0, x0, #0x3a8
     464:	940001db 	bl	bd0 <unlink>
        fd = open("x", O_CREATE|O_RDWR);
     468:	b0000013 	adrp	x19, 1000 <vprintf+0x70>
     46c:	52804041 	mov	w1, #0x202                 	// #514
     470:	91103e60 	add	x0, x19, #0x40f
     474:	940001d1 	bl	bb8 <open>
        unlink("x");
     478:	91103e60 	add	x0, x19, #0x40f
     47c:	940001d5 	bl	bd0 <unlink>
        exit(0);
     480:	17ffff99 	b	2e4 <go+0x254>
      unlink("c");
     484:	b0000015 	adrp	x21, 1000 <vprintf+0x70>
     488:	911112a0 	add	x0, x21, #0x444
     48c:	940001d1 	bl	bd0 <unlink>
      int fd1 = open("c", O_CREATE|O_RDWR);
     490:	911112a0 	add	x0, x21, #0x444
     494:	52804041 	mov	w1, #0x202                 	// #514
     498:	940001c8 	bl	bb8 <open>
     49c:	2a0003f9 	mov	w25, w0
      if(fd1 < 0){
     4a0:	36f80080 	tbz	w0, #31, 4b0 <go+0x420>
        printf("grind: create c failed\n");
     4a4:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     4a8:	91111800 	add	x0, x0, #0x446
     4ac:	17ffff0d 	b	e0 <go+0x50>
      if(write(fd1, "x", 1) != 1){
     4b0:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     4b4:	91103c21 	add	x1, x1, #0x40f
     4b8:	52800022 	mov	w2, #0x1                   	// #1
     4bc:	940001b3 	bl	b88 <write>
     4c0:	7100041f 	cmp	w0, #0x1
     4c4:	54000080 	b.eq	4d4 <go+0x444>  // b.none
        printf("grind: write c failed\n");
     4c8:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     4cc:	91117800 	add	x0, x0, #0x45e
     4d0:	17ffff04 	b	e0 <go+0x50>
      if(fstat(fd1, &st) != 0){
     4d4:	910223e1 	add	x1, sp, #0x88
     4d8:	2a1903e0 	mov	w0, w25
     4dc:	940001c0 	bl	bdc <fstat>
     4e0:	34000080 	cbz	w0, 4f0 <go+0x460>
        printf("grind: fstat failed\n");
     4e4:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     4e8:	9111d400 	add	x0, x0, #0x475
     4ec:	17fffefd 	b	e0 <go+0x50>
      if(st.size != 1){
     4f0:	f9404fe2 	ldr	x2, [sp, #152]
     4f4:	f100045f 	cmp	x2, #0x1
     4f8:	540000c0 	b.eq	510 <go+0x480>  // b.none
        printf("grind: fstat reports wrong size %d\n", (int)st.size);
     4fc:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     500:	91122800 	add	x0, x0, #0x48a
     504:	2a0203e1 	mov	w1, w2
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
     508:	94000370 	bl	12c8 <printf>
        exit(1);
     50c:	17fffef6 	b	e4 <go+0x54>
      if(st.ino > 200){
     510:	b9408fe1 	ldr	w1, [sp, #140]
     514:	7103203f 	cmp	w1, #0xc8
     518:	540000a9 	b.ls	52c <go+0x49c>  // b.plast
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
     51c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     520:	9112b800 	add	x0, x0, #0x4ae
     524:	f90033e2 	str	x2, [sp, #96]
     528:	17fffff8 	b	508 <go+0x478>
      close(fd1);
     52c:	2a1903e0 	mov	w0, w25
     530:	94000199 	bl	b94 <close>
      unlink("c");
     534:	911112a0 	add	x0, x21, #0x444
     538:	17ffff1e 	b	1b0 <go+0x120>
      if(pipe(aa) < 0){
     53c:	9101e3e0 	add	x0, sp, #0x78
     540:	9400018c 	bl	b70 <pipe>
     544:	36f800c0 	tbz	w0, #31, 55c <go+0x4cc>
        fprintf(2, "grind: pipe failed\n");
     548:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     54c:	910fec21 	add	x1, x1, #0x3fb
          fprintf(2, "grind: dup failed\n");
     550:	52800040 	mov	w0, #0x2                   	// #2
     554:	94000349 	bl	1278 <fprintf>
          exit(1);
     558:	17fffee3 	b	e4 <go+0x54>
      if(pipe(bb) < 0){
     55c:	910203e0 	add	x0, sp, #0x80
     560:	94000184 	bl	b70 <pipe>
     564:	37ffff20 	tbnz	w0, #31, 548 <go+0x4b8>
      int pid1 = fork();
     568:	94000179 	bl	b4c <fork>
      if(pid1 == 0){
     56c:	35000440 	cbnz	w0, 5f4 <go+0x564>
        close(bb[0]);
     570:	b94083e0 	ldr	w0, [sp, #128]
     574:	94000188 	bl	b94 <close>
        close(bb[1]);
     578:	b94087e0 	ldr	w0, [sp, #132]
     57c:	94000186 	bl	b94 <close>
        close(aa[0]);
     580:	b9407be0 	ldr	w0, [sp, #120]
     584:	94000184 	bl	b94 <close>
        close(1);
     588:	52800020 	mov	w0, #0x1                   	// #1
     58c:	94000182 	bl	b94 <close>
        if(dup(aa[1]) != 1){
     590:	b9407fe0 	ldr	w0, [sp, #124]
     594:	9400019e 	bl	c0c <dup>
     598:	7100041f 	cmp	w0, #0x1
     59c:	54000080 	b.eq	5ac <go+0x51c>  // b.none
          fprintf(2, "grind: dup failed\n");
     5a0:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     5a4:	91135821 	add	x1, x1, #0x4d6
     5a8:	17ffffea 	b	550 <go+0x4c0>
        close(aa[1]);
     5ac:	b9407fe0 	ldr	w0, [sp, #124]
     5b0:	94000179 	bl	b94 <close>
        char *args[3] = { "echo", "hi", 0 };
     5b4:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     5b8:	91166000 	add	x0, x0, #0x598
        exec("/bin/echo", args);
     5bc:	910223e1 	add	x1, sp, #0x88
        char *args[3] = { "echo", "hi", 0 };
     5c0:	a9400c02 	ldp	x2, x3, [x0]
     5c4:	a9088fe2 	stp	x2, x3, [sp, #136]
     5c8:	f9400800 	ldr	x0, [x0, #16]
     5cc:	f9004fe0 	str	x0, [sp, #152]
        exec("/bin/echo", args);
     5d0:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     5d4:	9113a400 	add	x0, x0, #0x4e9
     5d8:	94000175 	bl	bac <exec>
        fprintf(2, "grind: echo: not found\n");
     5dc:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     5e0:	9113cc21 	add	x1, x1, #0x4f3
     5e4:	52800040 	mov	w0, #0x2                   	// #2
     5e8:	94000324 	bl	1278 <fprintf>
        exit(2);
     5ec:	52800040 	mov	w0, #0x2                   	// #2
     5f0:	17ffff3e 	b	2e8 <go+0x258>
      } else if(pid1 < 0){
     5f4:	36f800e0 	tbz	w0, #31, 610 <go+0x580>
        fprintf(2, "grind: fork failed\n");
     5f8:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     5fc:	910f1021 	add	x1, x1, #0x3c4
     600:	52800040 	mov	w0, #0x2                   	// #2
     604:	9400031d 	bl	1278 <fprintf>
        exit(3);
     608:	52800060 	mov	w0, #0x3                   	// #3
     60c:	17ffff37 	b	2e8 <go+0x258>
      int pid2 = fork();
     610:	9400014f 	bl	b4c <fork>
      if(pid2 == 0){
     614:	350005a0 	cbnz	w0, 6c8 <go+0x638>
        close(aa[1]);
     618:	b9407fe0 	ldr	w0, [sp, #124]
     61c:	b0000013 	adrp	x19, 1000 <vprintf+0x70>
     620:	91135a73 	add	x19, x19, #0x4d6
     624:	9400015c 	bl	b94 <close>
        close(bb[0]);
     628:	b94083e0 	ldr	w0, [sp, #128]
     62c:	9400015a 	bl	b94 <close>
        close(0);
     630:	52800000 	mov	w0, #0x0                   	// #0
     634:	94000158 	bl	b94 <close>
        if(dup(aa[0]) != 0){
     638:	b9407be0 	ldr	w0, [sp, #120]
     63c:	94000174 	bl	c0c <dup>
     640:	340000c0 	cbz	w0, 658 <go+0x5c8>
          fprintf(2, "grind: dup failed\n");
     644:	aa1303e1 	mov	x1, x19
     648:	52800040 	mov	w0, #0x2                   	// #2
     64c:	9400030b 	bl	1278 <fprintf>
          exit(4);
     650:	52800080 	mov	w0, #0x4                   	// #4
     654:	17ffff25 	b	2e8 <go+0x258>
        close(aa[0]);
     658:	b9407be0 	ldr	w0, [sp, #120]
     65c:	9400014e 	bl	b94 <close>
        close(1);
     660:	52800020 	mov	w0, #0x1                   	// #1
     664:	9400014c 	bl	b94 <close>
        if(dup(bb[1]) != 1){
     668:	b94087e0 	ldr	w0, [sp, #132]
     66c:	94000168 	bl	c0c <dup>
     670:	7100041f 	cmp	w0, #0x1
     674:	540000c0 	b.eq	68c <go+0x5fc>  // b.none
          fprintf(2, "grind: dup failed\n");
     678:	aa1303e1 	mov	x1, x19
     67c:	52800040 	mov	w0, #0x2                   	// #2
     680:	940002fe 	bl	1278 <fprintf>
          exit(5);
     684:	528000a0 	mov	w0, #0x5                   	// #5
     688:	17ffff18 	b	2e8 <go+0x258>
        close(bb[1]);
     68c:	b94087e0 	ldr	w0, [sp, #132]
     690:	94000141 	bl	b94 <close>
        char *args[2] = { "cat", 0 };
     694:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     698:	91144000 	add	x0, x0, #0x510
        exec("/bin/cat", args);
     69c:	910223e1 	add	x1, sp, #0x88
        char *args[2] = { "cat", 0 };
     6a0:	a908ffe0 	stp	x0, xzr, [sp, #136]
        exec("/bin/cat", args);
     6a4:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     6a8:	91142c00 	add	x0, x0, #0x50b
     6ac:	94000140 	bl	bac <exec>
        fprintf(2, "grind: cat: not found\n");
     6b0:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     6b4:	91145021 	add	x1, x1, #0x514
     6b8:	52800040 	mov	w0, #0x2                   	// #2
     6bc:	940002ef 	bl	1278 <fprintf>
        exit(6);
     6c0:	528000c0 	mov	w0, #0x6                   	// #6
     6c4:	17ffff09 	b	2e8 <go+0x258>
      } else if(pid2 < 0){
     6c8:	36f800e0 	tbz	w0, #31, 6e4 <go+0x654>
        fprintf(2, "grind: fork failed\n");
     6cc:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     6d0:	910f1021 	add	x1, x1, #0x3c4
     6d4:	52800040 	mov	w0, #0x2                   	// #2
     6d8:	940002e8 	bl	1278 <fprintf>
        exit(7);
     6dc:	528000e0 	mov	w0, #0x7                   	// #7
     6e0:	17ffff02 	b	2e8 <go+0x258>
      close(aa[0]);
     6e4:	b9407be0 	ldr	w0, [sp, #120]
     6e8:	9400012b 	bl	b94 <close>
      close(aa[1]);
     6ec:	b9407fe0 	ldr	w0, [sp, #124]
     6f0:	94000129 	bl	b94 <close>
      close(bb[1]);
     6f4:	b94087e0 	ldr	w0, [sp, #132]
     6f8:	94000127 	bl	b94 <close>
      char buf[4] = { 0, 0, 0, 0 };
     6fc:	b90073ff 	str	wzr, [sp, #112]
      read(bb[0], buf+0, 1);
     700:	b94083e0 	ldr	w0, [sp, #128]
     704:	9101c3e1 	add	x1, sp, #0x70
     708:	52800022 	mov	w2, #0x1                   	// #1
     70c:	9400011c 	bl	b7c <read>
      read(bb[0], buf+1, 1);
     710:	b94083e0 	ldr	w0, [sp, #128]
     714:	9101c7e1 	add	x1, sp, #0x71
     718:	52800022 	mov	w2, #0x1                   	// #1
     71c:	94000118 	bl	b7c <read>
      read(bb[0], buf+2, 1);
     720:	b94083e0 	ldr	w0, [sp, #128]
     724:	9101cbe1 	add	x1, sp, #0x72
     728:	52800022 	mov	w2, #0x1                   	// #1
     72c:	94000114 	bl	b7c <read>
      close(bb[0]);
     730:	b94083e0 	ldr	w0, [sp, #128]
     734:	94000118 	bl	b94 <close>
      wait(&st1);
     738:	9101d3e0 	add	x0, sp, #0x74
     73c:	9400010a 	bl	b64 <wait>
      wait(&st2);
     740:	910223e0 	add	x0, sp, #0x88
     744:	94000108 	bl	b64 <wait>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     748:	b94077e0 	ldr	w0, [sp, #116]
     74c:	b9408be1 	ldr	w1, [sp, #136]
     750:	2a010000 	orr	w0, w0, w1
     754:	34000100 	cbz	w0, 774 <go+0x6e4>
        printf("grind: exec pipeline failed %d %d \"%s\"\n", st1, st2, buf);
     758:	b94077e1 	ldr	w1, [sp, #116]
     75c:	9101c3e3 	add	x3, sp, #0x70
     760:	b9408be2 	ldr	w2, [sp, #136]
     764:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     768:	9114ac00 	add	x0, x0, #0x52b
     76c:	940002d7 	bl	12c8 <printf>
     770:	17fffe5d 	b	e4 <go+0x54>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     774:	f94037e1 	ldr	x1, [sp, #104]
     778:	9101c3e0 	add	x0, sp, #0x70
     77c:	94000055 	bl	8d0 <strcmp>
     780:	34ffcdc0 	cbz	w0, 138 <go+0xa8>
     784:	17fffff5 	b	758 <go+0x6c8>

0000000000000788 <iter>:
{
     788:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  unlink("a");
     78c:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     790:	910eac00 	add	x0, x0, #0x3ab
{
     794:	910003fd 	mov	x29, sp
     798:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("a");
     79c:	9400010d 	bl	bd0 <unlink>
  unlink("b");
     7a0:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     7a4:	910dec00 	add	x0, x0, #0x37b
     7a8:	9400010a 	bl	bd0 <unlink>
  int pid1 = fork();
     7ac:	940000e8 	bl	b4c <fork>
  if(pid1 < 0){
     7b0:	36f800c0 	tbz	w0, #31, 7c8 <iter+0x40>
    printf("grind: fork failed\n");
     7b4:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     7b8:	910f1000 	add	x0, x0, #0x3c4
     7bc:	940002c3 	bl	12c8 <printf>
    exit(1);
     7c0:	52800020 	mov	w0, #0x1                   	// #1
  exit(0);
     7c4:	940000e5 	bl	b58 <exit>
     7c8:	2a0003f4 	mov	w20, w0
  if(pid1 == 0){
     7cc:	350000a0 	cbnz	w0, 7e0 <iter+0x58>
    rand_next = 31;
     7d0:	b0000001 	adrp	x1, 1000 <vprintf+0x70>
     7d4:	d28003e2 	mov	x2, #0x1f                  	// #31
     7d8:	f902e422 	str	x2, [x1, #1480]
    go(1);
     7dc:	97fffe2d 	bl	90 <go>
  int pid2 = fork();
     7e0:	940000db 	bl	b4c <fork>
     7e4:	2a0003f3 	mov	w19, w0
  if(pid2 < 0){
     7e8:	37fffe60 	tbnz	w0, #31, 7b4 <iter+0x2c>
  if(pid2 == 0){
     7ec:	350000c0 	cbnz	w0, 804 <iter+0x7c>
    rand_next = 7177;
     7f0:	b0000000 	adrp	x0, 1000 <vprintf+0x70>
     7f4:	d2838121 	mov	x1, #0x1c09                	// #7177
     7f8:	f902e401 	str	x1, [x0, #1480]
    go(1);
     7fc:	52800020 	mov	w0, #0x1                   	// #1
     800:	17fffff7 	b	7dc <iter+0x54>
  int st1 = -1;
     804:	12800000 	mov	w0, #0xffffffff            	// #-1
     808:	b9002be0 	str	w0, [sp, #40]
  wait(&st1);
     80c:	9100a3e0 	add	x0, sp, #0x28
     810:	940000d5 	bl	b64 <wait>
  if(st1 != 0){
     814:	b9402be0 	ldr	w0, [sp, #40]
     818:	340000a0 	cbz	w0, 82c <iter+0xa4>
    kill(pid1);
     81c:	2a1403e0 	mov	w0, w20
     820:	940000e0 	bl	ba0 <kill>
    kill(pid2);
     824:	2a1303e0 	mov	w0, w19
     828:	940000de 	bl	ba0 <kill>
  int st2 = -1;
     82c:	12800000 	mov	w0, #0xffffffff            	// #-1
     830:	b9002fe0 	str	w0, [sp, #44]
  wait(&st2);
     834:	9100b3e0 	add	x0, sp, #0x2c
     838:	940000cb 	bl	b64 <wait>
  exit(0);
     83c:	52800000 	mov	w0, #0x0                   	// #0
     840:	17ffffe1 	b	7c4 <iter+0x3c>

0000000000000844 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     844:	d2800002 	mov	x2, #0x0                   	// #0
     848:	38626823 	ldrb	w3, [x1, x2]
     84c:	38226803 	strb	w3, [x0, x2]
     850:	91000442 	add	x2, x2, #0x1
     854:	35ffffa3 	cbnz	w3, 848 <strcpy+0x4>
    ;
  return os;
}
     858:	d65f03c0 	ret

000000000000085c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
     85c:	d2800003 	mov	x3, #0x0                   	// #0
     860:	4b030044 	sub	w4, w2, w3
     864:	7100009f 	cmp	w4, #0x0
     868:	5400006d 	b.le	874 <strncpy+0x18>
     86c:	38636825 	ldrb	w5, [x1, x3]
     870:	350000e5 	cbnz	w5, 88c <strncpy+0x30>
     874:	8b030003 	add	x3, x0, x3
     878:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
     87c:	4b010082 	sub	w2, w4, w1
     880:	7100005f 	cmp	w2, #0x0
     884:	540000ac 	b.gt	898 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
     888:	d65f03c0 	ret
    *s++ = *t++;
     88c:	38236805 	strb	w5, [x0, x3]
    n--;
     890:	91000463 	add	x3, x3, #0x1
     894:	17fffff3 	b	860 <strncpy+0x4>
    *s++ = 0;
     898:	3821687f 	strb	wzr, [x3, x1]
     89c:	91000421 	add	x1, x1, #0x1
     8a0:	17fffff7 	b	87c <strncpy+0x20>

00000000000008a4 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
     8a4:	aa0003e2 	mov	x2, x0
     8a8:	39400043 	ldrb	w3, [x2]
     8ac:	aa0203e4 	mov	x4, x2
    s++;
     8b0:	91000442 	add	x2, x2, #0x1
  while(*s)
     8b4:	35ffffa3 	cbnz	w3, 8a8 <strcat+0x4>
     8b8:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
     8bc:	38626823 	ldrb	w3, [x1, x2]
     8c0:	38226883 	strb	w3, [x4, x2]
     8c4:	91000442 	add	x2, x2, #0x1
     8c8:	35ffffa3 	cbnz	w3, 8bc <strcat+0x18>
    ;
  return os;
}
     8cc:	d65f03c0 	ret

00000000000008d0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
     8d0:	d2800002 	mov	x2, #0x0                   	// #0
     8d4:	38626803 	ldrb	w3, [x0, x2]
     8d8:	38626824 	ldrb	w4, [x1, x2]
     8dc:	34000083 	cbz	w3, 8ec <strcmp+0x1c>
     8e0:	91000442 	add	x2, x2, #0x1
     8e4:	6b04007f 	cmp	w3, w4
     8e8:	54ffff60 	b.eq	8d4 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
     8ec:	4b040060 	sub	w0, w3, w4
     8f0:	d65f03c0 	ret

00000000000008f4 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
     8f4:	340001c2 	cbz	w2, 92c <strncmp+0x38>
     8f8:	39400003 	ldrb	w3, [x0]
     8fc:	34000083 	cbz	w3, 90c <strncmp+0x18>
     900:	39400024 	ldrb	w4, [x1]
     904:	6b03009f 	cmp	w4, w3
     908:	540000a0 	b.eq	91c <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
     90c:	39400000 	ldrb	w0, [x0]
     910:	39400021 	ldrb	w1, [x1]
     914:	4b010000 	sub	w0, w0, w1
}
     918:	d65f03c0 	ret
    n--, p++, q++;
     91c:	51000442 	sub	w2, w2, #0x1
     920:	91000400 	add	x0, x0, #0x1
     924:	91000421 	add	x1, x1, #0x1
     928:	17fffff3 	b	8f4 <strncmp>
    return 0;
     92c:	52800000 	mov	w0, #0x0                   	// #0
     930:	17fffffa 	b	918 <strncmp+0x24>

0000000000000934 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
     934:	d1000402 	sub	x2, x0, #0x1
     938:	d2800001 	mov	x1, #0x0                   	// #0
     93c:	aa0103e0 	mov	x0, x1
     940:	91000421 	add	x1, x1, #0x1
     944:	38616843 	ldrb	w3, [x2, x1]
     948:	35ffffa3 	cbnz	w3, 93c <strlen+0x8>
    ;
  return n;
}
     94c:	d65f03c0 	ret

0000000000000950 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
     950:	d1000403 	sub	x3, x0, #0x1
     954:	d2800002 	mov	x2, #0x0                   	// #0
     958:	2a0203e0 	mov	w0, w2
     95c:	6b02003f 	cmp	w1, w2
     960:	54000089 	b.ls	970 <strnlen+0x20>  // b.plast
     964:	91000442 	add	x2, x2, #0x1
     968:	38626864 	ldrb	w4, [x3, x2]
     96c:	35ffff64 	cbnz	w4, 958 <strnlen+0x8>
    n++;
  return n;
}
     970:	d65f03c0 	ret

0000000000000974 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     974:	d2800003 	mov	x3, #0x0                   	// #0
     978:	6b03005f 	cmp	w2, w3
     97c:	54000048 	b.hi	984 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
     980:	d65f03c0 	ret
    cdst[i] = c;
     984:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
     988:	91000463 	add	x3, x3, #0x1
     98c:	17fffffb 	b	978 <memset+0x4>

0000000000000990 <strchr>:

char*
strchr(const char *s, char c)
{
     990:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
     994:	39400002 	ldrb	w2, [x0]
     998:	35000062 	cbnz	w2, 9a4 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
     99c:	d2800000 	mov	x0, #0x0                   	// #0
}
     9a0:	d65f03c0 	ret
    if(*s == c)
     9a4:	6b01005f 	cmp	w2, w1
     9a8:	54ffffc0 	b.eq	9a0 <strchr+0x10>  // b.none
  for(; *s; s++)
     9ac:	91000400 	add	x0, x0, #0x1
     9b0:	17fffff9 	b	994 <strchr+0x4>

00000000000009b4 <gets>:

char*
gets(char *buf, int max)
{
     9b4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     9b8:	910003fd 	mov	x29, sp
     9bc:	a90153f3 	stp	x19, x20, [sp, #16]
     9c0:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     9c4:	d2800014 	mov	x20, #0x0                   	// #0
{
     9c8:	f9001bf7 	str	x23, [sp, #48]
     9cc:	2a0103f7 	mov	w23, w1
     9d0:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
     9d4:	11000695 	add	w21, w20, #0x1
     9d8:	2a1403f6 	mov	w22, w20
     9dc:	6b1702bf 	cmp	w21, w23
     9e0:	540000ea 	b.ge	9fc <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
     9e4:	91013fe1 	add	x1, sp, #0x4f
     9e8:	52800022 	mov	w2, #0x1                   	// #1
     9ec:	52800000 	mov	w0, #0x0                   	// #0
     9f0:	94000063 	bl	b7c <read>
    if(cc < 1)
     9f4:	7100001f 	cmp	w0, #0x0
     9f8:	5400012c 	b.gt	a1c <gets+0x68>
  for(i=0; i+1 < max; ){
     9fc:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
     a00:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
     a04:	aa1303e0 	mov	x0, x19
     a08:	f9401bf7 	ldr	x23, [sp, #48]
     a0c:	a94153f3 	ldp	x19, x20, [sp, #16]
     a10:	a9425bf5 	ldp	x21, x22, [sp, #32]
     a14:	a8c57bfd 	ldp	x29, x30, [sp], #80
     a18:	d65f03c0 	ret
    buf[i++] = c;
     a1c:	39413fe0 	ldrb	w0, [sp, #79]
     a20:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
     a24:	91000694 	add	x20, x20, #0x1
     a28:	7100281f 	cmp	w0, #0xa
     a2c:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
     a30:	54fffd21 	b.ne	9d4 <gets+0x20>  // b.any
     a34:	17fffff3 	b	a00 <gets+0x4c>

0000000000000a38 <stat>:

int
stat(const char *n, struct stat *st)
{
     a38:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     a3c:	910003fd 	mov	x29, sp
     a40:	a90153f3 	stp	x19, x20, [sp, #16]
     a44:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     a48:	52800001 	mov	w1, #0x0                   	// #0
     a4c:	9400005b 	bl	bb8 <open>
  if(fd < 0)
     a50:	37f80160 	tbnz	w0, #31, a7c <stat+0x44>
    return -1;
  r = fstat(fd, st);
     a54:	aa1303e1 	mov	x1, x19
     a58:	2a0003f4 	mov	w20, w0
     a5c:	94000060 	bl	bdc <fstat>
     a60:	2a0003f3 	mov	w19, w0
  close(fd);
     a64:	2a1403e0 	mov	w0, w20
     a68:	9400004b 	bl	b94 <close>
  return r;
}
     a6c:	2a1303e0 	mov	w0, w19
     a70:	a94153f3 	ldp	x19, x20, [sp, #16]
     a74:	a8c27bfd 	ldp	x29, x30, [sp], #32
     a78:	d65f03c0 	ret
    return -1;
     a7c:	12800013 	mov	w19, #0xffffffff            	// #-1
     a80:	17fffffb 	b	a6c <stat+0x34>

0000000000000a84 <atoi>:

int
atoi(const char *s)
{
     a84:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
     a88:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
     a8c:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
     a90:	39400043 	ldrb	w3, [x2]
     a94:	5100c061 	sub	w1, w3, #0x30
     a98:	12001c21 	and	w1, w1, #0xff
     a9c:	7100243f 	cmp	w1, #0x9
     aa0:	54000049 	b.ls	aa8 <atoi+0x24>  // b.plast
  return n;
}
     aa4:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
     aa8:	1b040c01 	madd	w1, w0, w4, w3
     aac:	91000442 	add	x2, x2, #0x1
     ab0:	5100c020 	sub	w0, w1, #0x30
     ab4:	17fffff7 	b	a90 <atoi+0xc>

0000000000000ab8 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     ab8:	eb01001f 	cmp	x0, x1
     abc:	54000263 	b.cc	b08 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
     ac0:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
     ac4:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
     ac8:	d2800003 	mov	x3, #0x0                   	// #0
     acc:	d1000463 	sub	x3, x3, #0x1
     ad0:	11000464 	add	w4, w3, #0x1
     ad4:	0b020084 	add	w4, w4, w2
     ad8:	7100009f 	cmp	w4, #0x0
     adc:	5400014d 	b.le	b04 <memmove+0x4c>
      *--dst = *--src;
     ae0:	38636824 	ldrb	w4, [x1, x3]
     ae4:	382368a4 	strb	w4, [x5, x3]
     ae8:	17fffff9 	b	acc <memmove+0x14>
      *dst++ = *src++;
     aec:	38636824 	ldrb	w4, [x1, x3]
     af0:	38236804 	strb	w4, [x0, x3]
     af4:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
     af8:	4b030044 	sub	w4, w2, w3
     afc:	7100009f 	cmp	w4, #0x0
     b00:	54ffff6c 	b.gt	aec <memmove+0x34>
  }
  return vdst;
}
     b04:	d65f03c0 	ret
     b08:	d2800003 	mov	x3, #0x0                   	// #0
     b0c:	17fffffb 	b	af8 <memmove+0x40>

0000000000000b10 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     b10:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
     b14:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
     b18:	d2800004 	mov	x4, #0x0                   	// #0
     b1c:	eb02009f 	cmp	x4, x2
     b20:	54000061 	b.ne	b2c <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
     b24:	52800000 	mov	w0, #0x0                   	// #0
     b28:	14000007 	b	b44 <memcmp+0x34>
    if (*p1 != *p2) {
     b2c:	38646803 	ldrb	w3, [x0, x4]
     b30:	91000484 	add	x4, x4, #0x1
     b34:	38646825 	ldrb	w5, [x1, x4]
     b38:	6b05007f 	cmp	w3, w5
     b3c:	54ffff00 	b.eq	b1c <memcmp+0xc>  // b.none
      return *p1 - *p2;
     b40:	4b050060 	sub	w0, w3, w5
}
     b44:	d65f03c0 	ret

0000000000000b48 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
     b48:	17ffffdc 	b	ab8 <memmove>

0000000000000b4c <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
     b4c:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
     b50:	d4000001 	svc	#0x0
 ret
     b54:	d65f03c0 	ret

0000000000000b58 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
     b58:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
     b5c:	d4000001 	svc	#0x0
 ret
     b60:	d65f03c0 	ret

0000000000000b64 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
     b64:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
     b68:	d4000001 	svc	#0x0
 ret
     b6c:	d65f03c0 	ret

0000000000000b70 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
     b70:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
     b74:	d4000001 	svc	#0x0
 ret
     b78:	d65f03c0 	ret

0000000000000b7c <read>:
.global read
read:
 mov x7, #SYS_read
     b7c:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
     b80:	d4000001 	svc	#0x0
 ret
     b84:	d65f03c0 	ret

0000000000000b88 <write>:
.global write
write:
 mov x7, #SYS_write
     b88:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
     b8c:	d4000001 	svc	#0x0
 ret
     b90:	d65f03c0 	ret

0000000000000b94 <close>:
.global close
close:
 mov x7, #SYS_close
     b94:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
     b98:	d4000001 	svc	#0x0
 ret
     b9c:	d65f03c0 	ret

0000000000000ba0 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
     ba0:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
     ba4:	d4000001 	svc	#0x0
 ret
     ba8:	d65f03c0 	ret

0000000000000bac <exec>:
.global exec
exec:
 mov x7, #SYS_exec
     bac:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
     bb0:	d4000001 	svc	#0x0
 ret
     bb4:	d65f03c0 	ret

0000000000000bb8 <open>:
.global open
open:
 mov x7, #SYS_open
     bb8:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
     bbc:	d4000001 	svc	#0x0
 ret
     bc0:	d65f03c0 	ret

0000000000000bc4 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
     bc4:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
     bc8:	d4000001 	svc	#0x0
 ret
     bcc:	d65f03c0 	ret

0000000000000bd0 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
     bd0:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
     bd4:	d4000001 	svc	#0x0
 ret
     bd8:	d65f03c0 	ret

0000000000000bdc <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
     bdc:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
     be0:	d4000001 	svc	#0x0
 ret
     be4:	d65f03c0 	ret

0000000000000be8 <link>:
.global link
link:
 mov x7, #SYS_link
     be8:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
     bec:	d4000001 	svc	#0x0
 ret
     bf0:	d65f03c0 	ret

0000000000000bf4 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
     bf4:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
     bf8:	d4000001 	svc	#0x0
 ret
     bfc:	d65f03c0 	ret

0000000000000c00 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
     c00:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
     c04:	d4000001 	svc	#0x0
 ret
     c08:	d65f03c0 	ret

0000000000000c0c <dup>:
.global dup
dup:
 mov x7, #SYS_dup
     c0c:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
     c10:	d4000001 	svc	#0x0
 ret
     c14:	d65f03c0 	ret

0000000000000c18 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
     c18:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
     c1c:	d4000001 	svc	#0x0
 ret
     c20:	d65f03c0 	ret

0000000000000c24 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
     c24:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
     c28:	d4000001 	svc	#0x0
 ret
     c2c:	d65f03c0 	ret

0000000000000c30 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
     c30:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
     c34:	d4000001 	svc	#0x0
 ret
     c38:	d65f03c0 	ret

0000000000000c3c <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
     c3c:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
     c40:	d4000001 	svc	#0x0
 ret
     c44:	d65f03c0 	ret

0000000000000c48 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
     c48:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
     c4c:	d4000001 	svc	#0x0
 ret
     c50:	d65f03c0 	ret

0000000000000c54 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
     c54:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
     c58:	d4000001 	svc	#0x0
 ret
     c5c:	d65f03c0 	ret

0000000000000c60 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
     c60:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
     c64:	d4000001 	svc	#0x0
 ret
     c68:	d65f03c0 	ret

0000000000000c6c <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
     c6c:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
     c70:	d4000001 	svc	#0x0
 ret
     c74:	d65f03c0 	ret

0000000000000c78 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
     c78:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
     c7c:	d4000001 	svc	#0x0
 ret
     c80:	d65f03c0 	ret

0000000000000c84 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
     c84:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
     c88:	d4000001 	svc	#0x0
 ret
     c8c:	d65f03c0 	ret

0000000000000c90 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
     c90:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
     c94:	d4000001 	svc	#0x0
 ret
     c98:	d65f03c0 	ret

0000000000000c9c <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
     c9c:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
     ca0:	d4000001 	svc	#0x0
 ret
     ca4:	d65f03c0 	ret

0000000000000ca8 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
     ca8:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
     cac:	d4000001 	svc	#0x0
 ret
     cb0:	d65f03c0 	ret

0000000000000cb4 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
     cb4:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
     cb8:	d4000001 	svc	#0x0
 ret
     cbc:	d65f03c0 	ret

0000000000000cc0 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
     cc0:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
     cc4:	d4000001 	svc	#0x0
 ret
     cc8:	d65f03c0 	ret

0000000000000ccc <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
     ccc:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
     cd0:	d4000001 	svc	#0x0
 ret
     cd4:	d65f03c0 	ret

0000000000000cd8 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
     cd8:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
     cdc:	d4000001 	svc	#0x0
 ret
     ce0:	d65f03c0 	ret

0000000000000ce4 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
     ce4:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
     ce8:	d4000001 	svc	#0x0
 ret
     cec:	d65f03c0 	ret

0000000000000cf0 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
     cf0:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
     cf4:	d4000001 	svc	#0x0
 ret
     cf8:	d65f03c0 	ret

0000000000000cfc <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
     cfc:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
     d00:	d4000001 	svc	#0x0
 ret
     d04:	d65f03c0 	ret

0000000000000d08 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
     d08:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
     d0c:	d4000001 	svc	#0x0
 ret
     d10:	d65f03c0 	ret

0000000000000d14 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
     d14:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
     d18:	d4000001 	svc	#0x0
 ret
     d1c:	d65f03c0 	ret

0000000000000d20 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
     d20:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
     d24:	d4000001 	svc	#0x0
 ret
     d28:	d65f03c0 	ret

0000000000000d2c <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
     d2c:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
     d30:	d4000001 	svc	#0x0
 ret
     d34:	d65f03c0 	ret

0000000000000d38 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
     d38:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
     d3c:	d4000001 	svc	#0x0
 ret
     d40:	d65f03c0 	ret

0000000000000d44 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
     d44:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
     d48:	d4000001 	svc	#0x0
 ret
     d4c:	d65f03c0 	ret

0000000000000d50 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
     d50:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
     d54:	d4000001 	svc	#0x0
 ret
     d58:	d65f03c0 	ret

0000000000000d5c <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
     d5c:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
     d60:	d4000001 	svc	#0x0
 ret
     d64:	d65f03c0 	ret

0000000000000d68 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
     d68:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
     d6c:	d4000001 	svc	#0x0
 ret
     d70:	d65f03c0 	ret

0000000000000d74 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
     d74:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
     d78:	d4000001 	svc	#0x0
 ret
     d7c:	d65f03c0 	ret

0000000000000d80 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
     d80:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
     d84:	d4000001 	svc	#0x0
 ret
     d88:	d65f03c0 	ret

0000000000000d8c <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
     d8c:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
     d90:	d4000001 	svc	#0x0
 ret
     d94:	d65f03c0 	ret

0000000000000d98 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
     d98:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
     d9c:	d4000001 	svc	#0x0
 ret
     da0:	d65f03c0 	ret

0000000000000da4 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
     da4:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
     da8:	d4000001 	svc	#0x0
 ret
     dac:	d65f03c0 	ret

0000000000000db0 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
     db0:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
     db4:	d4000001 	svc	#0x0
 ret
     db8:	d65f03c0 	ret

0000000000000dbc <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
     dbc:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
     dc0:	d4000001 	svc	#0x0
 ret
     dc4:	d65f03c0 	ret

0000000000000dc8 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
     dc8:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
     dcc:	d4000001 	svc	#0x0
 ret
     dd0:	d65f03c0 	ret

0000000000000dd4 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
     dd4:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
     dd8:	d4000001 	svc	#0x0
 ret
     ddc:	d65f03c0 	ret

0000000000000de0 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
     de0:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
     de4:	d4000001 	svc	#0x0
 ret
     de8:	d65f03c0 	ret

0000000000000dec <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
     dec:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
     df0:	d4000001 	svc	#0x0
 ret
     df4:	d65f03c0 	ret

0000000000000df8 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
     df8:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
     dfc:	d4000001 	svc	#0x0
 ret
     e00:	d65f03c0 	ret

0000000000000e04 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
     e04:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
     e08:	d4000001 	svc	#0x0
 ret
     e0c:	d65f03c0 	ret

0000000000000e10 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
     e10:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
     e14:	d4000001 	svc	#0x0
 ret
     e18:	d65f03c0 	ret

0000000000000e1c <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
     e1c:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
     e20:	d4000001 	svc	#0x0
 ret
     e24:	d65f03c0 	ret

0000000000000e28 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
     e28:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
     e2c:	d4000001 	svc	#0x0
 ret
     e30:	d65f03c0 	ret

0000000000000e34 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
     e34:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
     e38:	d4000001 	svc	#0x0
 ret
     e3c:	d65f03c0 	ret

0000000000000e40 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
     e40:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
     e44:	d4000001 	svc	#0x0
 ret
     e48:	d65f03c0 	ret

0000000000000e4c <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
     e4c:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
     e50:	d4000001 	svc	#0x0
 ret
     e54:	d65f03c0 	ret

0000000000000e58 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
     e58:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
     e5c:	d4000001 	svc	#0x0
 ret
     e60:	d65f03c0 	ret

0000000000000e64 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
     e64:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
     e68:	d4000001 	svc	#0x0
 ret
     e6c:	d65f03c0 	ret

0000000000000e70 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
     e70:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
     e74:	d4000001 	svc	#0x0
 ret
     e78:	d65f03c0 	ret

0000000000000e7c <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
     e7c:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
     e80:	d4000001 	svc	#0x0
 ret
     e84:	d65f03c0 	ret

0000000000000e88 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
     e88:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
     e8c:	d4000001 	svc	#0x0
 ret
     e90:	d65f03c0 	ret

0000000000000e94 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
     e94:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
     e98:	d4000001 	svc	#0x0
 ret
     e9c:	d65f03c0 	ret

0000000000000ea0 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
     ea0:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
     ea4:	d4000001 	svc	#0x0
 ret
     ea8:	d65f03c0 	ret

0000000000000eac <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
     eac:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
     eb0:	d4000001 	svc	#0x0
 ret
     eb4:	d65f03c0 	ret

0000000000000eb8 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
     eb8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
     ebc:	52800022 	mov	w2, #0x1                   	// #1
{
     ec0:	910003fd 	mov	x29, sp
     ec4:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
     ec8:	91007fe1 	add	x1, sp, #0x1f
     ecc:	97ffff2f 	bl	b88 <write>
     ed0:	7100041f 	cmp	w0, #0x1
}
     ed4:	1a9f17e0 	cset	w0, eq	// eq = none
     ed8:	a8c27bfd 	ldp	x29, x30, [sp], #32
     edc:	d65f03c0 	ret

0000000000000ee0 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
     ee0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     ee4:	910003fd 	mov	x29, sp
     ee8:	a90153f3 	stp	x19, x20, [sp, #16]
     eec:	a9025bf5 	stp	x21, x22, [sp, #32]
     ef0:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     ef4:	6a417c7f 	tst	w3, w1, lsr #31
     ef8:	54000300 	b.eq	f58 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
     efc:	4b0103e1 	neg	w1, w1
    neg = 1;
     f00:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
     f04:	b0000003 	adrp	x3, 1000 <vprintf+0x70>
     f08:	9116c063 	add	x3, x3, #0x5b0
     f0c:	9100c3f5 	add	x21, sp, #0x30
     f10:	d2800000 	mov	x0, #0x0                   	// #0
     f14:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
     f18:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
     f1c:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
     f20:	2a0403e1 	mov	w1, w4
     f24:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
     f28:	38666866 	ldrb	w6, [x3, x6]
     f2c:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
     f30:	91000400 	add	x0, x0, #0x1
     f34:	54ffff09 	b.ls	f14 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
     f38:	11000493 	add	w19, w4, #0x1
  if(neg)
     f3c:	34000085 	cbz	w5, f4c <printint+0x6c>
    buf[i++] = '-';
     f40:	528005a0 	mov	w0, #0x2d                  	// #45
     f44:	38334aa0 	strb	w0, [x21, w19, uxtw]
     f48:	11000893 	add	w19, w4, #0x2
     f4c:	51000673 	sub	w19, w19, #0x1
     f50:	52800014 	mov	w20, #0x0                   	// #0
     f54:	14000008 	b	f74 <printint+0x94>
  neg = 0;
     f58:	52800005 	mov	w5, #0x0                   	// #0
     f5c:	17ffffea 	b	f04 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
     f60:	38736aa1 	ldrb	w1, [x21, x19]
     f64:	2a1603e0 	mov	w0, w22
     f68:	d1000673 	sub	x19, x19, #0x1
     f6c:	97ffffd3 	bl	eb8 <putc>
     f70:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
     f74:	3100067f 	cmn	w19, #0x1
     f78:	54ffff41 	b.ne	f60 <printint+0x80>  // b.any
  return written;
}
     f7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
     f80:	2a1403e0 	mov	w0, w20
     f84:	a94153f3 	ldp	x19, x20, [sp, #16]
     f88:	a8c47bfd 	ldp	x29, x30, [sp], #64
     f8c:	d65f03c0 	ret

0000000000000f90 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
     f90:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
     f94:	910003fd 	mov	x29, sp
     f98:	a90153f3 	stp	x19, x20, [sp, #16]
     f9c:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
     fa0:	52800015 	mov	w21, #0x0                   	// #0
{
     fa4:	a90363f7 	stp	x23, x24, [sp, #48]
     fa8:	2a0003f7 	mov	w23, w0
     fac:	a9046bf9 	stp	x25, x26, [sp, #64]
     fb0:	aa0103f9 	mov	x25, x1

  state = 0;
     fb4:	52800001 	mov	w1, #0x0                   	// #0
{
     fb8:	a90573fb 	stp	x27, x28, [sp, #80]
     fbc:	a9406053 	ldp	x19, x24, [x2]
     fc0:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
     fc4:	39400320 	ldrb	w0, [x25]
     fc8:	35000120 	cbnz	w0, fec <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
     fcc:	2a1503e0 	mov	w0, w21
     fd0:	a94153f3 	ldp	x19, x20, [sp, #16]
     fd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
     fd8:	a94363f7 	ldp	x23, x24, [sp, #48]
     fdc:	a9446bf9 	ldp	x25, x26, [sp, #64]
     fe0:	a94573fb 	ldp	x27, x28, [sp, #80]
     fe4:	a8c67bfd 	ldp	x29, x30, [sp], #96
     fe8:	d65f03c0 	ret
    c = fmt[i] & 0xff;
     fec:	2a0003f6 	mov	w22, w0
    if(state == 0){
     ff0:	35000101 	cbnz	w1, 1010 <vprintf+0x80>
      if(c == '%'){
     ff4:	7100941f 	cmp	w0, #0x25
     ff8:	54000ba0 	b.eq	116c <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
     ffc:	2a1603e1 	mov	w1, w22
    1000:	2a1703e0 	mov	w0, w23
    1004:	97ffffad 	bl	eb8 <putc>
    1008:	0b0002b5 	add	w21, w21, w0
    100c:	14000057 	b	1168 <vprintf+0x1d8>
      if(c == 'd'){
    1010:	7101901f 	cmp	w0, #0x64
    1014:	540002a1 	b.ne	1068 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
    1018:	37f80174 	tbnz	w20, #31, 1044 <vprintf+0xb4>
    101c:	91002e76 	add	x22, x19, #0xb
    1020:	2a1403fa 	mov	w26, w20
    1024:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1028:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    102c:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
    1030:	b9400261 	ldr	w1, [x19]
    1034:	2a1703e0 	mov	w0, w23
    1038:	97ffffaa 	bl	ee0 <printint>
        written += putc(fd, va_arg(ap, uint));
    103c:	0b0002b5 	add	w21, w21, w0
    1040:	14000048 	b	1160 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
    1044:	1100229a 	add	w26, w20, #0x8
    1048:	7100035f 	cmp	w26, #0x0
    104c:	5400008d 	b.le	105c <vprintf+0xcc>
    1050:	91002e76 	add	x22, x19, #0xb
    1054:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1058:	17fffff4 	b	1028 <vprintf+0x98>
    105c:	aa1303f6 	mov	x22, x19
    1060:	8b34c313 	add	x19, x24, w20, sxtw
    1064:	17fffff1 	b	1028 <vprintf+0x98>
      } else if(c == 'l') {
    1068:	7101b01f 	cmp	w0, #0x6c
    106c:	54000201 	b.ne	10ac <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    1070:	37f800d4 	tbnz	w20, #31, 1088 <vprintf+0xf8>
    1074:	91003e76 	add	x22, x19, #0xf
    1078:	2a1403fa 	mov	w26, w20
    107c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1080:	52800003 	mov	w3, #0x0                   	// #0
    1084:	17ffffea 	b	102c <vprintf+0x9c>
    1088:	1100229a 	add	w26, w20, #0x8
    108c:	7100035f 	cmp	w26, #0x0
    1090:	5400008d 	b.le	10a0 <vprintf+0x110>
    1094:	91003e76 	add	x22, x19, #0xf
    1098:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    109c:	17fffff9 	b	1080 <vprintf+0xf0>
    10a0:	aa1303f6 	mov	x22, x19
    10a4:	8b34c313 	add	x19, x24, w20, sxtw
    10a8:	17fffff6 	b	1080 <vprintf+0xf0>
      } else if(c == 'x') {
    10ac:	7101e01f 	cmp	w0, #0x78
    10b0:	54000221 	b.ne	10f4 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
    10b4:	37f800f4 	tbnz	w20, #31, 10d0 <vprintf+0x140>
    10b8:	91002e76 	add	x22, x19, #0xb
    10bc:	2a1403fa 	mov	w26, w20
    10c0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    10c4:	52800003 	mov	w3, #0x0                   	// #0
    10c8:	52800202 	mov	w2, #0x10                  	// #16
    10cc:	17ffffd9 	b	1030 <vprintf+0xa0>
    10d0:	1100229a 	add	w26, w20, #0x8
    10d4:	7100035f 	cmp	w26, #0x0
    10d8:	5400008d 	b.le	10e8 <vprintf+0x158>
    10dc:	91002e76 	add	x22, x19, #0xb
    10e0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    10e4:	17fffff8 	b	10c4 <vprintf+0x134>
    10e8:	aa1303f6 	mov	x22, x19
    10ec:	8b34c313 	add	x19, x24, w20, sxtw
    10f0:	17fffff5 	b	10c4 <vprintf+0x134>
      } else if(c == 'p') {
    10f4:	7101c01f 	cmp	w0, #0x70
    10f8:	54000521 	b.ne	119c <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    10fc:	37f803f4 	tbnz	w20, #31, 1178 <vprintf+0x1e8>
    1100:	91003e76 	add	x22, x19, #0xf
    1104:	2a1403fa 	mov	w26, w20
    1108:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    110c:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
    1110:	52800601 	mov	w1, #0x30                  	// #48
    1114:	2a1703e0 	mov	w0, w23
    1118:	97ffff68 	bl	eb8 <putc>
    111c:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    1120:	9000001c 	adrp	x28, 1000 <vprintf+0x70>
    1124:	9116c39c 	add	x28, x28, #0x5b0
  written += putc(fd, 'x');
    1128:	2a1703e0 	mov	w0, w23
    112c:	52800f01 	mov	w1, #0x78                  	// #120
    1130:	97ffff62 	bl	eb8 <putc>
    1134:	0b000273 	add	w19, w19, w0
    1138:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    113c:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    1140:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    1144:	38606b81 	ldrb	w1, [x28, x0]
    1148:	2a1703e0 	mov	w0, w23
    114c:	97ffff5b 	bl	eb8 <putc>
    1150:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    1154:	71000694 	subs	w20, w20, #0x1
    1158:	54ffff21 	b.ne	113c <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    115c:	0b1302b5 	add	w21, w21, w19
    1160:	2a1a03f4 	mov	w20, w26
    1164:	aa1603f3 	mov	x19, x22
      state = 0;
    1168:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
    116c:	91000739 	add	x25, x25, #0x1
  state = 0;
    1170:	2a1603e1 	mov	w1, w22
    1174:	17ffff94 	b	fc4 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
    1178:	1100229a 	add	w26, w20, #0x8
    117c:	7100035f 	cmp	w26, #0x0
    1180:	5400008d 	b.le	1190 <vprintf+0x200>
    1184:	91003e76 	add	x22, x19, #0xf
    1188:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    118c:	17ffffe0 	b	110c <vprintf+0x17c>
    1190:	aa1303f6 	mov	x22, x19
    1194:	8b34c313 	add	x19, x24, w20, sxtw
    1198:	17ffffdd 	b	110c <vprintf+0x17c>
      } else if(c == 's'){
    119c:	7101cc1f 	cmp	w0, #0x73
    11a0:	54000381 	b.ne	1210 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
    11a4:	37f80214 	tbnz	w20, #31, 11e4 <vprintf+0x254>
    11a8:	91003e61 	add	x1, x19, #0xf
    11ac:	aa1303e0 	mov	x0, x19
    11b0:	927df033 	and	x19, x1, #0xfffffffffffffff8
    11b4:	f9400016 	ldr	x22, [x0]
          s = "(null)";
    11b8:	90000000 	adrp	x0, 1000 <vprintf+0x70>
    11bc:	91156800 	add	x0, x0, #0x55a
    11c0:	f10002df 	cmp	x22, #0x0
    11c4:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
    11c8:	394002c1 	ldrb	w1, [x22]
    11cc:	34fffce1 	cbz	w1, 1168 <vprintf+0x1d8>
          written += putc(fd, *s);
    11d0:	2a1703e0 	mov	w0, w23
          s++;
    11d4:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
    11d8:	97ffff38 	bl	eb8 <putc>
    11dc:	0b0002b5 	add	w21, w21, w0
          s++;
    11e0:	17fffffa 	b	11c8 <vprintf+0x238>
        s = va_arg(ap, char*);
    11e4:	11002281 	add	w1, w20, #0x8
    11e8:	7100003f 	cmp	w1, #0x0
    11ec:	540000cd 	b.le	1204 <vprintf+0x274>
    11f0:	91003e62 	add	x2, x19, #0xf
    11f4:	aa1303e0 	mov	x0, x19
    11f8:	2a0103f4 	mov	w20, w1
    11fc:	927df053 	and	x19, x2, #0xfffffffffffffff8
    1200:	17ffffed 	b	11b4 <vprintf+0x224>
    1204:	8b34c300 	add	x0, x24, w20, sxtw
    1208:	2a0103f4 	mov	w20, w1
    120c:	17ffffea 	b	11b4 <vprintf+0x224>
      } else if(c == 'c'){
    1210:	71018c1f 	cmp	w0, #0x63
    1214:	54000241 	b.ne	125c <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
    1218:	37f80114 	tbnz	w20, #31, 1238 <vprintf+0x2a8>
    121c:	91002e76 	add	x22, x19, #0xb
    1220:	2a1403fa 	mov	w26, w20
    1224:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1228:	39400261 	ldrb	w1, [x19]
    122c:	2a1703e0 	mov	w0, w23
    1230:	97ffff22 	bl	eb8 <putc>
    1234:	17ffff82 	b	103c <vprintf+0xac>
    1238:	1100229a 	add	w26, w20, #0x8
    123c:	7100035f 	cmp	w26, #0x0
    1240:	5400008d 	b.le	1250 <vprintf+0x2c0>
    1244:	91002e76 	add	x22, x19, #0xb
    1248:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    124c:	17fffff7 	b	1228 <vprintf+0x298>
    1250:	aa1303f6 	mov	x22, x19
    1254:	8b34c313 	add	x19, x24, w20, sxtw
    1258:	17fffff4 	b	1228 <vprintf+0x298>
      } else if(c == '%'){
    125c:	7100941f 	cmp	w0, #0x25
    1260:	54ffece0 	b.eq	ffc <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
    1264:	2a1703e0 	mov	w0, w23
    1268:	528004a1 	mov	w1, #0x25                  	// #37
    126c:	97ffff13 	bl	eb8 <putc>
    1270:	0b0002b5 	add	w21, w21, w0
    1274:	17ffff62 	b	ffc <vprintf+0x6c>

0000000000001278 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
    1278:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    127c:	910003fd 	mov	x29, sp
    1280:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
    1284:	910203e2 	add	x2, sp, #0x80
    1288:	a9030be2 	stp	x2, x2, [sp, #48]
    128c:	910143e2 	add	x2, sp, #0x50
    1290:	f90023e2 	str	x2, [sp, #64]
    1294:	128005e2 	mov	w2, #0xffffffd0            	// #-48
    1298:	b9004be2 	str	w2, [sp, #72]
    129c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
    12a0:	a9430fe2 	ldp	x2, x3, [sp, #48]
    12a4:	a9010fe2 	stp	x2, x3, [sp, #16]
    12a8:	a9440fe2 	ldp	x2, x3, [sp, #64]
    12ac:	a9020fe2 	stp	x2, x3, [sp, #32]
    12b0:	910043e2 	add	x2, sp, #0x10
{
    12b4:	a90617e4 	stp	x4, x5, [sp, #96]
    12b8:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
    12bc:	97ffff35 	bl	f90 <vprintf>
  va_end(ap);
  return result;
}
    12c0:	a8c87bfd 	ldp	x29, x30, [sp], #128
    12c4:	d65f03c0 	ret

00000000000012c8 <printf>:

int
printf(const char *fmt, ...)
{
    12c8:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    12cc:	910003fd 	mov	x29, sp
    12d0:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
    12d4:	910243e1 	add	x1, sp, #0x90
    12d8:	a90307e1 	stp	x1, x1, [sp, #48]
    12dc:	910143e1 	add	x1, sp, #0x50
    12e0:	f90023e1 	str	x1, [sp, #64]
    12e4:	128006e1 	mov	w1, #0xffffffc8            	// #-56
    12e8:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
    12ec:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
    12f0:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
    12f4:	52800020 	mov	w0, #0x1                   	// #1
{
    12f8:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
    12fc:	a9430fe2 	ldp	x2, x3, [sp, #48]
    1300:	a9010fe2 	stp	x2, x3, [sp, #16]
    1304:	a9440fe2 	ldp	x2, x3, [sp, #64]
    1308:	a9020fe2 	stp	x2, x3, [sp, #32]
    130c:	910043e2 	add	x2, sp, #0x10
{
    1310:	a9079be5 	stp	x5, x6, [sp, #120]
    1314:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
    1318:	97ffff1e 	bl	f90 <vprintf>
  va_end(ap);
  return result;
}
    131c:	a8c97bfd 	ldp	x29, x30, [sp], #144
    1320:	d65f03c0 	ret
