
user/_sh:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  return 0;
}

int
main(int argc, char **argv)
{
       0:	a9a57bfd 	stp	x29, x30, [sp, #-432]!
       4:	910003fd 	mov	x29, sp
       8:	a90153f3 	stp	x19, x20, [sp, #16]
       c:	a9025bf5 	stp	x21, x22, [sp, #32]
      10:	a90363f7 	stp	x23, x24, [sp, #48]
  static char cwd[100] = "/";
  int fd;

  // login passes the already-selected home so the logical pwd state matches
  // the cwd inherited across exec (xv6 does not yet provide getcwd()).
  if(argc > 1 && argv[1][0] == '/'){
      14:	7100041f 	cmp	w0, #0x1
      18:	5400018d 	b.le	48 <main+0x48>
      1c:	f9400421 	ldr	x1, [x1, #8]
      20:	39400020 	ldrb	w0, [x1]
      24:	7100bc1f 	cmp	w0, #0x2f
      28:	54000101 	b.ne	48 <main+0x48>  // b.any
    strncpy(cwd, argv[1], sizeof(cwd) - 1);
      2c:	b0000013 	adrp	x19, 1000 <nulterminate+0x7c>
      30:	913bd673 	add	x19, x19, #0xef5
      34:	91023a73 	add	x19, x19, #0x8e
      38:	52800c62 	mov	w2, #0x63                  	// #99
      3c:	aa1303e0 	mov	x0, x19
      40:	9400041e 	bl	10b8 <strncpy>
    cwd[sizeof(cwd) - 1] = 0;
      44:	39018e7f 	strb	wzr, [x19, #99]
  }

  // Ensure that three file descriptors are open.
  while((fd = open("/dev/tty", O_RDWR)) >= 0){
      48:	b0000013 	adrp	x19, 1000 <nulterminate+0x7c>
      4c:	9138de73 	add	x19, x19, #0xe37
      50:	aa1303e0 	mov	x0, x19
      54:	52800041 	mov	w1, #0x2                   	// #2
      58:	940004ef 	bl	1414 <open>
      5c:	36f80140 	tbz	w0, #31, 84 <main+0x84>
    }
  }
  // A process without an attached controlling TTY can still use the system
  // console to fill a missing standard descriptor.
  if(fd < 0){
    while((fd = open("/dev/console", O_RDWR)) >= 0){
      60:	b0000013 	adrp	x19, 1000 <nulterminate+0x7c>
      64:	91390273 	add	x19, x19, #0xe40
      68:	aa1303e0 	mov	x0, x19
      6c:	52800041 	mov	w1, #0x2                   	// #2
      70:	940004e9 	bl	1414 <open>
      74:	37f800e0 	tbnz	w0, #31, 90 <main+0x90>
      if(fd >= 3){
      78:	7100081f 	cmp	w0, #0x2
      7c:	54ffff6d 	b.le	68 <main+0x68>
      80:	14000003 	b	8c <main+0x8c>
    if(fd >= 3){
      84:	7100081f 	cmp	w0, #0x2
      88:	54fffe4d 	b.le	50 <main+0x50>
        close(fd);
      8c:	940004d9 	bl	13f0 <close>
  int fd = open("/etc/rc", O_RDONLY);
      90:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
      94:	91393400 	add	x0, x0, #0xe4d
      98:	52800001 	mov	w1, #0x0                   	// #0
      9c:	940004de 	bl	1414 <open>
      a0:	2a0003f4 	mov	w20, w0
  if(fd < 0)
      a4:	37f80500 	tbnz	w0, #31, 144 <main+0x144>
  n = read(fd, buf, sizeof(buf) - 1);
      a8:	9102c3f5 	add	x21, sp, #0xb0
      ac:	52801fe2 	mov	w2, #0xff                  	// #255
      b0:	aa1503e1 	mov	x1, x21
      b4:	940004c9 	bl	13d8 <read>
      b8:	2a0003f3 	mov	w19, w0
  close(fd);
      bc:	2a1403e0 	mov	w0, w20
      c0:	940004cc 	bl	13f0 <close>
  if(n <= 0)
      c4:	7100027f 	cmp	w19, #0x0
      c8:	540003ed 	b.le	144 <main+0x144>
    if(strncmp(buf + start, "export PATH=", 12) == 0)
      cc:	b0000017 	adrp	x23, 1000 <nulterminate+0x7c>
      d0:	913956f7 	add	x23, x23, #0xe55
  strncpy(shell_path, value, sizeof(shell_path) - 1);
      d4:	b0000016 	adrp	x22, 1000 <nulterminate+0x7c>
      d8:	913bd6d6 	add	x22, x22, #0xef5
  buf[n] = 0;
      dc:	d2800034 	mov	x20, #0x1                   	// #1
  int n, start = 0;
      e0:	52800000 	mov	w0, #0x0                   	// #0
  buf[n] = 0;
      e4:	38334abf 	strb	wzr, [x21, w19, uxtw]
    if(buf[i] != '\n' && buf[i] != 0)
      e8:	8b1402a1 	add	x1, x21, x20
      ec:	385ff022 	ldurb	w2, [x1, #-1]
      f0:	7100005f 	cmp	w2, #0x0
      f4:	7a4a1844 	ccmp	w2, #0xa, #0x4, ne	// ne = any
      f8:	540001e1 	b.ne	134 <main+0x134>  // b.any
    buf[i] = 0;
      fc:	381ff03f 	sturb	wzr, [x1, #-1]
    if(strncmp(buf + start, "export PATH=", 12) == 0)
     100:	2a0003f8 	mov	w24, w0
     104:	aa1703e1 	mov	x1, x23
     108:	8b2042a0 	add	x0, x21, w0, uxtw
     10c:	52800182 	mov	w2, #0xc                   	// #12
     110:	94000410 	bl	1150 <strncmp>
     114:	350000e0 	cbnz	w0, 130 <main+0x130>
      setpath(buf + start + 12);
     118:	91003301 	add	x1, x24, #0xc
  strncpy(shell_path, value, sizeof(shell_path) - 1);
     11c:	aa1603e0 	mov	x0, x22
     120:	8b0102a1 	add	x1, x21, x1
     124:	52800fe2 	mov	w2, #0x7f                  	// #127
     128:	940003e4 	bl	10b8 <strncpy>
  shell_path[sizeof(shell_path) - 1] = 0;
     12c:	3901fedf 	strb	wzr, [x22, #127]
    start = i + 1;
     130:	2a1403e0 	mov	w0, w20
  for(int i = 0; i <= n; i++){
     134:	91000694 	add	x20, x20, #0x1
     138:	51000681 	sub	w1, w20, #0x1
     13c:	6b01027f 	cmp	w19, w1
     140:	54fffd4a 	b.ge	e8 <main+0xe8>  // b.tcont
  loadrc();

  // Read and run input commands.
  for(;;){
    tty_set_foreground(0);
    if(getcmd(buf, sizeof(buf)) < 0)
     144:	b0000013 	adrp	x19, 1000 <nulterminate+0x7c>
     148:	913fa273 	add	x19, x19, #0xfe8
      break;
    if(strncmp(buf, "export PATH=", 12) == 0){
     14c:	b0000015 	adrp	x21, 1000 <nulterminate+0x7c>
     150:	913956b5 	add	x21, x21, #0xe55
      break;
    if((buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' ') ||
       strcmp(buf, "cd\n") == 0){
      // Chdir must be called by the parent, not the child.
      buf[strlen(buf)-1] = 0;  // chop \n
      char *path = buf[2] == 0 ? "/" : buf+3;
     154:	91000e76 	add	x22, x19, #0x3
    tty_set_foreground(0);
     158:	52800000 	mov	w0, #0x0                   	// #0
     15c:	9400050b 	bl	1588 <tty_set_foreground>
    if(getcmd(buf, sizeof(buf)) < 0)
     160:	aa1303e0 	mov	x0, x19
     164:	52800c81 	mov	w1, #0x64                  	// #100
     168:	940000df 	bl	4e4 <getcmd>
     16c:	3100041f 	cmn	w0, #0x1
     170:	54001b60 	b.eq	4dc <main+0x4dc>  // b.none
    if(strncmp(buf, "export PATH=", 12) == 0){
     174:	aa1503e1 	mov	x1, x21
     178:	aa1303e0 	mov	x0, x19
     17c:	52800182 	mov	w2, #0xc                   	// #12
     180:	940003f4 	bl	1150 <strncmp>
     184:	35000240 	cbnz	w0, 1cc <main+0x1cc>
      int n = strlen(buf);
     188:	aa1303e0 	mov	x0, x19
     18c:	94000401 	bl	1190 <strlen>
      if(n > 0 && buf[n - 1] == '\n')
     190:	7100001f 	cmp	w0, #0x0
     194:	540000cd 	b.le	1ac <main+0x1ac>
     198:	51000400 	sub	w0, w0, #0x1
     19c:	38606a61 	ldrb	w1, [x19, x0]
     1a0:	7100283f 	cmp	w1, #0xa
     1a4:	54000041 	b.ne	1ac <main+0x1ac>  // b.any
        buf[n - 1] = 0;
     1a8:	38206a7f 	strb	wzr, [x19, x0]
  strncpy(shell_path, value, sizeof(shell_path) - 1);
     1ac:	b0000014 	adrp	x20, 1000 <nulterminate+0x7c>
     1b0:	913bd694 	add	x20, x20, #0xef5
     1b4:	91003261 	add	x1, x19, #0xc
     1b8:	aa1403e0 	mov	x0, x20
     1bc:	52800fe2 	mov	w2, #0x7f                  	// #127
     1c0:	940003be 	bl	10b8 <strncpy>
  shell_path[sizeof(shell_path) - 1] = 0;
     1c4:	3901fe9f 	strb	wzr, [x20, #127]
      continue;
     1c8:	17ffffe4 	b	158 <main+0x158>
    if(strcmp(buf, "pwd\n") == 0){
     1cc:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     1d0:	91398821 	add	x1, x1, #0xe62
     1d4:	aa1303e0 	mov	x0, x19
     1d8:	940003d5 	bl	112c <strcmp>
     1dc:	35000100 	cbnz	w0, 1fc <main+0x1fc>
      printf("%s\n", cwd);
     1e0:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     1e4:	913bd421 	add	x1, x1, #0xef5
     1e8:	91023821 	add	x1, x1, #0x8e
     1ec:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     1f0:	9138c400 	add	x0, x0, #0xe31
     1f4:	9400064c 	bl	1b24 <printf>
      continue;
     1f8:	17ffffd8 	b	158 <main+0x158>
    if(strcmp(buf, "exit\n") == 0 || strcmp(buf, "logout\n") == 0)
     1fc:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     200:	91399c21 	add	x1, x1, #0xe67
     204:	aa1303e0 	mov	x0, x19
     208:	940003c9 	bl	112c <strcmp>
     20c:	34001680 	cbz	w0, 4dc <main+0x4dc>
     210:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     214:	9139b421 	add	x1, x1, #0xe6d
     218:	aa1303e0 	mov	x0, x19
     21c:	940003c4 	bl	112c <strcmp>
     220:	340015e0 	cbz	w0, 4dc <main+0x4dc>
    if((buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' ') ||
     224:	39400260 	ldrb	w0, [x19]
     228:	71018c1f 	cmp	w0, #0x63
     22c:	540000e1 	b.ne	248 <main+0x248>  // b.any
     230:	39400660 	ldrb	w0, [x19, #1]
     234:	7101901f 	cmp	w0, #0x64
     238:	54000081 	b.ne	248 <main+0x248>  // b.any
     23c:	39400a60 	ldrb	w0, [x19, #2]
     240:	7100801f 	cmp	w0, #0x20
     244:	540000c0 	b.eq	25c <main+0x25c>  // b.none
       strcmp(buf, "cd\n") == 0){
     248:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     24c:	9139d421 	add	x1, x1, #0xe75
     250:	aa1303e0 	mov	x0, x19
     254:	940003b6 	bl	112c <strcmp>
    if((buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' ') ||
     258:	350010a0 	cbnz	w0, 46c <main+0x46c>
      buf[strlen(buf)-1] = 0;  // chop \n
     25c:	aa1303e0 	mov	x0, x19
     260:	940003cc 	bl	1190 <strlen>
     264:	51000400 	sub	w0, w0, #0x1
      char *path = buf[2] == 0 ? "/" : buf+3;
     268:	b0000014 	adrp	x20, 1000 <nulterminate+0x7c>
     26c:	9138d694 	add	x20, x20, #0xe35
      buf[strlen(buf)-1] = 0;  // chop \n
     270:	38206a7f 	strb	wzr, [x19, x0]
      char *path = buf[2] == 0 ? "/" : buf+3;
     274:	39400a60 	ldrb	w0, [x19, #2]
     278:	7100001f 	cmp	w0, #0x0
     27c:	9a9412d4 	csel	x20, x22, x20, ne	// ne = any
      if(chdir(path) < 0)
     280:	aa1403e0 	mov	x0, x20
     284:	94000476 	bl	145c <chdir>
     288:	36f800e0 	tbz	w0, #31, 2a4 <main+0x2a4>
        fprintf(2, "cannot cd %s\n", path);
     28c:	aa1403e2 	mov	x2, x20
     290:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     294:	9139e421 	add	x1, x1, #0xe79
     298:	52800040 	mov	w0, #0x2                   	// #2
     29c:	9400060e 	bl	1ad4 <fprintf>
     2a0:	17ffffae 	b	158 <main+0x158>
  if(path[0] != '/'){
     2a4:	39400280 	ldrb	w0, [x20]
     2a8:	910123e3 	add	x3, sp, #0x48
     2ac:	7100bc1f 	cmp	w0, #0x2f
     2b0:	540002c1 	b.ne	308 <main+0x308>  // b.any
  int i = 0, n = 0;
     2b4:	52800000 	mov	w0, #0x0                   	// #0
  for(i = 0; path[i] && n < (int)sizeof(input)-1; i++)
     2b8:	2a0003e1 	mov	w1, w0
     2bc:	cb204294 	sub	x20, x20, w0, uxtw
     2c0:	38616a82 	ldrb	w2, [x20, x1]
     2c4:	2a0103e0 	mov	w0, w1
     2c8:	350004e2 	cbnz	w2, 364 <main+0x364>
      output[n++] = input[start+j];
     2cc:	9102c3e6 	add	x6, sp, #0xb0
  input[n] = 0;
     2d0:	3820487f 	strb	wzr, [x3, w0, uxtw]
  output[0] = '/';
     2d4:	528005e0 	mov	w0, #0x2f                  	// #47
  i = 0;
     2d8:	d2800004 	mov	x4, #0x0                   	// #0
  output[0] = '/';
     2dc:	3902c3e0 	strb	w0, [sp, #176]
  n = 1;
     2e0:	52800020 	mov	w0, #0x1                   	// #1
  while(input[i]){
     2e4:	3864c861 	ldrb	w1, [x3, w4, sxtw]
     2e8:	35000481 	cbnz	w1, 378 <main+0x378>
  output[n] = 0;
     2ec:	9102c3e1 	add	x1, sp, #0xb0
     2f0:	3820c83f 	strb	wzr, [x1, w0, sxtw]
  strcpy(cwd, output);
     2f4:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     2f8:	913bd400 	add	x0, x0, #0xef5
     2fc:	91023800 	add	x0, x0, #0x8e
     300:	94000368 	bl	10a0 <strcpy>
     304:	17ffff95 	b	158 <main+0x158>
    while(cwd[i] && n < (int)sizeof(input)-1)
     308:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     30c:	913bd421 	add	x1, x1, #0xef5
     310:	91023821 	add	x1, x1, #0x8e
     314:	d2800000 	mov	x0, #0x0                   	// #0
     318:	14000005 	b	32c <main+0x32c>
     31c:	f1018c1f 	cmp	x0, #0x63
     320:	540000e0 	b.eq	33c <main+0x33c>  // b.none
      input[n++] = cwd[i++];
     324:	38206862 	strb	w2, [x3, x0]
     328:	91000400 	add	x0, x0, #0x1
    while(cwd[i] && n < (int)sizeof(input)-1)
     32c:	38616802 	ldrb	w2, [x0, x1]
     330:	35ffff62 	cbnz	w2, 31c <main+0x31c>
    if(n > 1 && input[n-1] != '/' && n < (int)sizeof(input)-1)
     334:	7100041f 	cmp	w0, #0x1
     338:	54fffc0d 	b.le	2b8 <main+0x2b8>
     33c:	51000401 	sub	w1, w0, #0x1
     340:	38616861 	ldrb	w1, [x3, x1]
     344:	7100bc3f 	cmp	w1, #0x2f
     348:	54fffb80 	b.eq	2b8 <main+0x2b8>  // b.none
     34c:	71018c1f 	cmp	w0, #0x63
     350:	54fffb40 	b.eq	2b8 <main+0x2b8>  // b.none
      input[n++] = '/';
     354:	528005e1 	mov	w1, #0x2f                  	// #47
     358:	38204861 	strb	w1, [x3, w0, uxtw]
     35c:	11000400 	add	w0, w0, #0x1
     360:	17ffffd6 	b	2b8 <main+0x2b8>
  for(i = 0; path[i] && n < (int)sizeof(input)-1; i++)
     364:	71018c3f 	cmp	w1, #0x63
     368:	54fffb20 	b.eq	2cc <main+0x2cc>  // b.none
    input[n++] = path[i];
     36c:	38216862 	strb	w2, [x3, x1]
  for(i = 0; path[i] && n < (int)sizeof(input)-1; i++)
     370:	91000421 	add	x1, x1, #0x1
     374:	17ffffd3 	b	2c0 <main+0x2c0>
    while(input[i] == '/')
     378:	aa0403e1 	mov	x1, x4
     37c:	91000484 	add	x4, x4, #0x1
     380:	38616865 	ldrb	w5, [x3, x1]
     384:	7100bcbf 	cmp	w5, #0x2f
     388:	54ffff80 	b.eq	378 <main+0x378>  // b.none
     38c:	93407c24 	sxtw	x4, w1
    while(input[i] && input[i] != '/')
     390:	38646867 	ldrb	w7, [x3, x4]
     394:	aa0403e2 	mov	x2, x4
     398:	91000484 	add	x4, x4, #0x1
     39c:	7100bcff 	cmp	w7, #0x2f
     3a0:	7a4018e4 	ccmp	w7, #0x0, #0x4, ne	// ne = any
     3a4:	54ffff61 	b.ne	390 <main+0x390>  // b.any
     3a8:	93407c44 	sxtw	x4, w2
    if(len == 0 || (len == 1 && input[start] == '.'))
     3ac:	6b010042 	subs	w2, w2, w1
     3b0:	54fff9a0 	b.eq	2e4 <main+0x2e4>  // b.none
     3b4:	7100045f 	cmp	w2, #0x1
     3b8:	54000321 	b.ne	41c <main+0x41c>  // b.any
     3bc:	7100b8bf 	cmp	w5, #0x2e
     3c0:	54fff920 	b.eq	2e4 <main+0x2e4>  // b.none
    if(n > 1 && output[n-1] != '/' && n < (int)sizeof(output)-1)
     3c4:	7100041f 	cmp	w0, #0x1
     3c8:	5400014d 	b.le	3f0 <main+0x3f0>
     3cc:	51000405 	sub	w5, w0, #0x1
     3d0:	386568c5 	ldrb	w5, [x6, x5]
     3d4:	7100bcbf 	cmp	w5, #0x2f
     3d8:	540000c0 	b.eq	3f0 <main+0x3f0>  // b.none
     3dc:	7101881f 	cmp	w0, #0x62
     3e0:	5400008c 	b.gt	3f0 <main+0x3f0>
      output[n++] = '/';
     3e4:	528005e5 	mov	w5, #0x2f                  	// #47
     3e8:	382048c5 	strb	w5, [x6, w0, uxtw]
     3ec:	11000400 	add	w0, w0, #0x1
    for(int j = 0; j < len && n < (int)sizeof(output)-1; j++)
     3f0:	93407c00 	sxtw	x0, w0
      output[n++] = input[start+j];
     3f4:	8b21c061 	add	x1, x3, w1, sxtw
    for(int j = 0; j < len && n < (int)sizeof(output)-1; j++)
     3f8:	d2800005 	mov	x5, #0x0                   	// #0
     3fc:	7101881f 	cmp	w0, #0x62
     400:	7a45d044 	ccmp	w2, w5, #0x4, le
     404:	54fff70d 	b.le	2e4 <main+0x2e4>
      output[n++] = input[start+j];
     408:	38656827 	ldrb	w7, [x1, x5]
     40c:	910004a5 	add	x5, x5, #0x1
     410:	38266807 	strb	w7, [x0, x6]
    for(int j = 0; j < len && n < (int)sizeof(output)-1; j++)
     414:	91000400 	add	x0, x0, #0x1
     418:	17fffff9 	b	3fc <main+0x3fc>
    if(len == 2 && input[start] == '.' && input[start+1] == '.'){
     41c:	7100085f 	cmp	w2, #0x2
     420:	54fffd21 	b.ne	3c4 <main+0x3c4>  // b.any
     424:	7100b8bf 	cmp	w5, #0x2e
     428:	54fffce1 	b.ne	3c4 <main+0x3c4>  // b.any
     42c:	11000425 	add	w5, w1, #0x1
     430:	3865c865 	ldrb	w5, [x3, w5, sxtw]
     434:	7100b8bf 	cmp	w5, #0x2e
     438:	54fffc61 	b.ne	3c4 <main+0x3c4>  // b.any
      if(n > 1){
     43c:	7100041f 	cmp	w0, #0x1
     440:	54fff52d 	b.le	2e4 <main+0x2e4>
        while(n > 1 && output[n-1] != '/')
     444:	51000801 	sub	w1, w0, #0x2
     448:	9102c3e5 	add	x5, sp, #0xb0
     44c:	11000420 	add	w0, w1, #0x1
     450:	34fff4a1 	cbz	w1, 2e4 <main+0x2e4>
     454:	d1000421 	sub	x1, x1, #0x1
     458:	8b050022 	add	x2, x1, x5
     45c:	39400442 	ldrb	w2, [x2, #1]
     460:	7100bc5f 	cmp	w2, #0x2f
     464:	54ffff41 	b.ne	44c <main+0x44c>  // b.any
     468:	17ffff9f 	b	2e4 <main+0x2e4>
      else
        setcwd(cwd, path);
      continue;
    }
    int pid = fork1();
     46c:	9400003d 	bl	560 <fork1>
    if(pid == 0){
     470:	35000160 	cbnz	w0, 49c <main+0x49c>
      if(tty_set_foreground(getpid()) < 0)
     474:	94000400 	bl	1474 <getpid>
     478:	94000444 	bl	1588 <tty_set_foreground>
     47c:	36f800a0 	tbz	w0, #31, 490 <main+0x490>
        fprintf(2, "sh: cannot set foreground process group\n");
     480:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     484:	913a1c21 	add	x1, x1, #0xe87
     488:	52800040 	mov	w0, #0x2                   	// #2
     48c:	94000592 	bl	1ad4 <fprintf>
      runcmd(parsecmd(buf));
     490:	aa1303e0 	mov	x0, x19
     494:	940002e3 	bl	1020 <parsecmd>
     498:	9400003c 	bl	588 <runcmd>
    }
    if(tty_set_foreground(pid) < 0)
     49c:	9400043b 	bl	1588 <tty_set_foreground>
     4a0:	36f800a0 	tbz	w0, #31, 4b4 <main+0x4b4>
      fprintf(2, "sh: cannot set foreground process group\n");
     4a4:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     4a8:	913a1c21 	add	x1, x1, #0xe87
     4ac:	52800040 	mov	w0, #0x2                   	// #2
     4b0:	94000589 	bl	1ad4 <fprintf>
    wait(0);
     4b4:	d2800000 	mov	x0, #0x0                   	// #0
     4b8:	940003c2 	bl	13c0 <wait>
    if(tty_set_foreground(getpid()) < 0)
     4bc:	940003ee 	bl	1474 <getpid>
     4c0:	94000432 	bl	1588 <tty_set_foreground>
     4c4:	36ffe4a0 	tbz	w0, #31, 158 <main+0x158>
      fprintf(2, "sh: cannot restore foreground process group\n");
     4c8:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     4cc:	913ac021 	add	x1, x1, #0xeb0
     4d0:	52800040 	mov	w0, #0x2                   	// #2
     4d4:	94000580 	bl	1ad4 <fprintf>
     4d8:	17ffff20 	b	158 <main+0x158>
  }
  exit(0);
     4dc:	52800000 	mov	w0, #0x0                   	// #0
     4e0:	940003b5 	bl	13b4 <exit>

00000000000004e4 <getcmd>:
{
     4e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     4e8:	910003fd 	mov	x29, sp
     4ec:	a90153f3 	stp	x19, x20, [sp, #16]
     4f0:	aa0003f3 	mov	x19, x0
     4f4:	2a0103f4 	mov	w20, w1
  fprintf(2, "$ ");
     4f8:	52800040 	mov	w0, #0x2                   	// #2
     4fc:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     500:	91365021 	add	x1, x1, #0xd94
     504:	94000574 	bl	1ad4 <fprintf>
  memset(buf, 0, nbuf);
     508:	2a1403e2 	mov	w2, w20
     50c:	aa1303e0 	mov	x0, x19
     510:	52800001 	mov	w1, #0x0                   	// #0
     514:	9400032f 	bl	11d0 <memset>
  gets(buf, nbuf);
     518:	2a1403e1 	mov	w1, w20
     51c:	aa1303e0 	mov	x0, x19
     520:	9400033c 	bl	1210 <gets>
  if(buf[0] == 0) // EOF
     524:	39400260 	ldrb	w0, [x19]
}
     528:	a94153f3 	ldp	x19, x20, [sp, #16]
  if(buf[0] == 0) // EOF
     52c:	7100001f 	cmp	w0, #0x0
}
     530:	5a9f13e0 	csetm	w0, eq	// eq = none
     534:	a8c27bfd 	ldp	x29, x30, [sp], #32
     538:	d65f03c0 	ret

000000000000053c <panic>:
}

void
panic(char *s)
{
     53c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "%s\n", s);
     540:	aa0003e2 	mov	x2, x0
     544:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     548:	9138c421 	add	x1, x1, #0xe31
{
     54c:	910003fd 	mov	x29, sp
  fprintf(2, "%s\n", s);
     550:	52800040 	mov	w0, #0x2                   	// #2
     554:	94000560 	bl	1ad4 <fprintf>
  exit(1);
     558:	52800020 	mov	w0, #0x1                   	// #1
     55c:	94000396 	bl	13b4 <exit>

0000000000000560 <fork1>:
}

int
fork1(void)
{
     560:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
     564:	910003fd 	mov	x29, sp
  int pid;

  pid = fork();
     568:	94000390 	bl	13a8 <fork>
  if(pid == -1)
     56c:	3100041f 	cmn	w0, #0x1
     570:	54000081 	b.ne	580 <fork1+0x20>  // b.any
    panic("fork");
     574:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     578:	91365c00 	add	x0, x0, #0xd97
     57c:	97fffff0 	bl	53c <panic>
  return pid;
}
     580:	a8c17bfd 	ldp	x29, x30, [sp], #16
     584:	d65f03c0 	ret

0000000000000588 <runcmd>:
{
     588:	a9b17bfd 	stp	x29, x30, [sp, #-240]!
     58c:	910003fd 	mov	x29, sp
     590:	a90153f3 	stp	x19, x20, [sp, #16]
     594:	a9025bf5 	stp	x21, x22, [sp, #32]
     598:	a90363f7 	stp	x23, x24, [sp, #48]
     59c:	f90023f9 	str	x25, [sp, #64]
  if(cmd == 0)
     5a0:	b5000060 	cbnz	x0, 5ac <runcmd+0x24>
      exit(1);
     5a4:	52800020 	mov	w0, #0x1                   	// #1
     5a8:	94000383 	bl	13b4 <exit>
  switch(cmd->type){
     5ac:	b9400014 	ldr	w20, [x0]
     5b0:	aa0003f3 	mov	x19, x0
     5b4:	71000e9f 	cmp	w20, #0x3
     5b8:	54000e40 	b.eq	780 <runcmd+0x1f8>  // b.none
     5bc:	5400010c 	b.gt	5dc <runcmd+0x54>
     5c0:	7100069f 	cmp	w20, #0x1
     5c4:	540001a0 	b.eq	5f8 <runcmd+0x70>  // b.none
     5c8:	71000a9f 	cmp	w20, #0x2
     5cc:	54000b20 	b.eq	730 <runcmd+0x1a8>  // b.none
    panic("runcmd");
     5d0:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     5d4:	91367000 	add	x0, x0, #0xd9c
      panic("pipe");
     5d8:	97ffffd9 	bl	53c <panic>
  switch(cmd->type){
     5dc:	7100129f 	cmp	w20, #0x4
     5e0:	54000c00 	b.eq	760 <runcmd+0x1d8>  // b.none
     5e4:	7100169f 	cmp	w20, #0x5
     5e8:	54ffff41 	b.ne	5d0 <runcmd+0x48>  // b.any
    if(fork1() == 0)
     5ec:	97ffffdd 	bl	560 <fork1>
     5f0:	35000200 	cbnz	w0, 630 <runcmd+0xa8>
     5f4:	1400005d 	b	768 <runcmd+0x1e0>
    if(ecmd->argv[0] == 0)
     5f8:	f9400416 	ldr	x22, [x0, #8]
     5fc:	b4fffd56 	cbz	x22, 5a4 <runcmd+0x1c>
  if(strchr(command, '/')){
     600:	aa1603e0 	mov	x0, x22
     604:	528005e1 	mov	w1, #0x2f                  	// #47
     608:	940002f9 	bl	11ec <strchr>
     60c:	b40007c0 	cbz	x0, 704 <runcmd+0x17c>
    exec(command, argv);
     610:	91002261 	add	x1, x19, #0x8
     614:	aa1603e0 	mov	x0, x22
  exec(path, argv);
     618:	9400037c 	bl	1408 <exec>
    fprintf(2, "exec %s failed\n", ecmd->argv[0]);
     61c:	f9400662 	ldr	x2, [x19, #8]
     620:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     624:	91368c21 	add	x1, x1, #0xda3
     628:	52800040 	mov	w0, #0x2                   	// #2
     62c:	9400052a 	bl	1ad4 <fprintf>
  exit(0);
     630:	52800000 	mov	w0, #0x0                   	// #0
     634:	17ffffdd 	b	5a8 <runcmd+0x20>
      path[n++] = *p++;
     638:	38216a83 	strb	w3, [x20, x1]
     63c:	91000421 	add	x1, x1, #0x1
    while(*p && *p != ':' && n < (int)sizeof(path) - 2)
     640:	38616843 	ldrb	w3, [x2, x1]
     644:	8b010057 	add	x23, x2, x1
     648:	2a0103e0 	mov	w0, w1
     64c:	7100e87f 	cmp	w3, #0x3a
     650:	7a401864 	ccmp	w3, #0x0, #0x4, ne	// ne = any
     654:	540003e0 	b.eq	6d0 <runcmd+0x148>  // b.none
     658:	f102783f 	cmp	x1, #0x9e
     65c:	54fffee1 	b.ne	638 <runcmd+0xb0>  // b.any
    if(path[n - 1] != '/')
     660:	51000401 	sub	w1, w0, #0x1
     664:	38616a81 	ldrb	w1, [x20, x1]
     668:	7100bc3f 	cmp	w1, #0x2f
     66c:	540003c1 	b.ne	6e4 <runcmd+0x15c>  // b.any
    for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     670:	2a0003e1 	mov	w1, w0
     674:	cb2042c0 	sub	x0, x22, w0, uxtw
     678:	38616803 	ldrb	w3, [x0, x1]
     67c:	2a0103e2 	mov	w2, w1
     680:	35000383 	cbnz	w3, 6f0 <runcmd+0x168>
    path[n] = 0;
     684:	38224a9f 	strb	wzr, [x20, w2, uxtw]
    exec(path, argv);
     688:	91002261 	add	x1, x19, #0x8
     68c:	aa1403e0 	mov	x0, x20
     690:	9400035e 	bl	1408 <exec>
     694:	aa1703e2 	mov	x2, x23
  while(*p){
     698:	39400040 	ldrb	w0, [x2]
     69c:	35000160 	cbnz	w0, 6c8 <runcmd+0x140>
  path[0] = '/';
     6a0:	528005e0 	mov	w0, #0x2f                  	// #47
     6a4:	390143e0 	strb	w0, [sp, #80]
  for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     6a8:	d2800000 	mov	x0, #0x0                   	// #0
     6ac:	38606ac1 	ldrb	w1, [x22, x0]
     6b0:	35000361 	cbnz	w1, 71c <runcmd+0x194>
     6b4:	11000400 	add	w0, w0, #0x1
  exec(path, argv);
     6b8:	91002261 	add	x1, x19, #0x8
  path[n] = 0;
     6bc:	38204a9f 	strb	wzr, [x20, w0, uxtw]
  exec(path, argv);
     6c0:	aa1403e0 	mov	x0, x20
     6c4:	17ffffd5 	b	618 <runcmd+0x90>
  while(*p){
     6c8:	d2800001 	mov	x1, #0x0                   	// #0
     6cc:	17ffffdd 	b	640 <runcmd+0xb8>
      p++;
     6d0:	7100e87f 	cmp	w3, #0x3a
     6d4:	9a9716f7 	cinc	x23, x23, eq	// eq = none
    if(n == 0)
     6d8:	35fffc41 	cbnz	w1, 660 <runcmd+0xd8>
      path[n++] = '.';
     6dc:	52800020 	mov	w0, #0x1                   	// #1
     6e0:	390143f9 	strb	w25, [sp, #80]
      path[n++] = '/';
     6e4:	38204a98 	strb	w24, [x20, w0, uxtw]
     6e8:	11000400 	add	w0, w0, #0x1
     6ec:	17ffffe1 	b	670 <runcmd+0xe8>
    for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     6f0:	71027c3f 	cmp	w1, #0x9f
     6f4:	54fffc80 	b.eq	684 <runcmd+0xfc>  // b.none
      path[n++] = command[i];
     6f8:	38216a83 	strb	w3, [x20, x1]
    for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     6fc:	91000421 	add	x1, x1, #0x1
     700:	17ffffde 	b	678 <runcmd+0xf0>
  char *p = shell_path;
     704:	b0000002 	adrp	x2, 1000 <nulterminate+0x7c>
     708:	913bd442 	add	x2, x2, #0xef5
     70c:	910143f4 	add	x20, sp, #0x50
      path[n++] = '/';
     710:	528005f8 	mov	w24, #0x2f                  	// #47
      path[n++] = '.';
     714:	528005d9 	mov	w25, #0x2e                  	// #46
     718:	17ffffe0 	b	698 <runcmd+0x110>
  for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     71c:	91000400 	add	x0, x0, #0x1
     720:	f1027c1f 	cmp	x0, #0x9f
     724:	54fffca0 	b.eq	6b8 <runcmd+0x130>  // b.none
    path[n++] = command[i];
     728:	38206a81 	strb	w1, [x20, x0]
  for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     72c:	17ffffe0 	b	6ac <runcmd+0x124>
    close(rcmd->fd);
     730:	b9402400 	ldr	w0, [x0, #36]
     734:	9400032f 	bl	13f0 <close>
    if(open(rcmd->file, rcmd->mode) < 0){
     738:	f9400a60 	ldr	x0, [x19, #16]
     73c:	b9402261 	ldr	w1, [x19, #32]
     740:	94000335 	bl	1414 <open>
     744:	36f80120 	tbz	w0, #31, 768 <runcmd+0x1e0>
      fprintf(2, "open %s failed\n", rcmd->file);
     748:	f9400a62 	ldr	x2, [x19, #16]
     74c:	2a1403e0 	mov	w0, w20
     750:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     754:	9136cc21 	add	x1, x1, #0xdb3
     758:	940004df 	bl	1ad4 <fprintf>
     75c:	17ffff92 	b	5a4 <runcmd+0x1c>
    if(fork1() == 0)
     760:	97ffff80 	bl	560 <fork1>
     764:	35000060 	cbnz	w0, 770 <runcmd+0x1e8>
      runcmd(bcmd->cmd);
     768:	f9400660 	ldr	x0, [x19, #8]
     76c:	14000004 	b	77c <runcmd+0x1f4>
    wait(0);
     770:	d2800000 	mov	x0, #0x0                   	// #0
     774:	94000313 	bl	13c0 <wait>
      runcmd(pcmd->right);
     778:	f9400a60 	ldr	x0, [x19, #16]
      runcmd(bcmd->cmd);
     77c:	97ffff83 	bl	588 <runcmd>
    if(pipe(p) < 0)
     780:	910143e0 	add	x0, sp, #0x50
     784:	94000312 	bl	13cc <pipe>
     788:	36f80080 	tbz	w0, #31, 798 <runcmd+0x210>
      panic("pipe");
     78c:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     790:	91370c00 	add	x0, x0, #0xdc3
     794:	17ffff91 	b	5d8 <runcmd+0x50>
    if(fork1() == 0){
     798:	97ffff72 	bl	560 <fork1>
     79c:	35000140 	cbnz	w0, 7c4 <runcmd+0x23c>
      close(1);
     7a0:	52800020 	mov	w0, #0x1                   	// #1
     7a4:	94000313 	bl	13f0 <close>
      dup(p[1]);
     7a8:	b94057e0 	ldr	w0, [sp, #84]
     7ac:	9400032f 	bl	1468 <dup>
      close(p[0]);
     7b0:	b94053e0 	ldr	w0, [sp, #80]
     7b4:	9400030f 	bl	13f0 <close>
      close(p[1]);
     7b8:	b94057e0 	ldr	w0, [sp, #84]
     7bc:	9400030d 	bl	13f0 <close>
      runcmd(pcmd->left);
     7c0:	17ffffea 	b	768 <runcmd+0x1e0>
    if(fork1() == 0){
     7c4:	97ffff67 	bl	560 <fork1>
     7c8:	35000120 	cbnz	w0, 7ec <runcmd+0x264>
      close(0);
     7cc:	94000309 	bl	13f0 <close>
      dup(p[0]);
     7d0:	b94053e0 	ldr	w0, [sp, #80]
     7d4:	94000325 	bl	1468 <dup>
      close(p[0]);
     7d8:	b94053e0 	ldr	w0, [sp, #80]
     7dc:	94000305 	bl	13f0 <close>
      close(p[1]);
     7e0:	b94057e0 	ldr	w0, [sp, #84]
     7e4:	94000303 	bl	13f0 <close>
     7e8:	17ffffe4 	b	778 <runcmd+0x1f0>
    close(p[0]);
     7ec:	b94053e0 	ldr	w0, [sp, #80]
     7f0:	94000300 	bl	13f0 <close>
    close(p[1]);
     7f4:	b94057e0 	ldr	w0, [sp, #84]
     7f8:	940002fe 	bl	13f0 <close>
    wait(0);
     7fc:	d2800000 	mov	x0, #0x0                   	// #0
     800:	940002f0 	bl	13c0 <wait>
    wait(0);
     804:	d2800000 	mov	x0, #0x0                   	// #0
     808:	940002ee 	bl	13c0 <wait>
    break;
     80c:	17ffff89 	b	630 <runcmd+0xa8>

0000000000000810 <execcmd>:
//PAGEBREAK!
// Constructors

struct cmd*
execcmd(void)
{
     810:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  struct execcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     814:	52801500 	mov	w0, #0xa8                  	// #168
{
     818:	910003fd 	mov	x29, sp
     81c:	f9000bf3 	str	x19, [sp, #16]
  cmd = malloc(sizeof(*cmd));
     820:	9400051d 	bl	1c94 <malloc>
     824:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
     828:	52801502 	mov	w2, #0xa8                  	// #168
     82c:	52800001 	mov	w1, #0x0                   	// #0
     830:	94000268 	bl	11d0 <memset>
  cmd->type = EXEC;
     834:	52800020 	mov	w0, #0x1                   	// #1
     838:	b9000260 	str	w0, [x19]
  return (struct cmd*)cmd;
}
     83c:	aa1303e0 	mov	x0, x19
     840:	f9400bf3 	ldr	x19, [sp, #16]
     844:	a8c27bfd 	ldp	x29, x30, [sp], #32
     848:	d65f03c0 	ret

000000000000084c <redircmd>:

struct cmd*
redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
     84c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     850:	910003fd 	mov	x29, sp
     854:	a90153f3 	stp	x19, x20, [sp, #16]
     858:	2a0303f4 	mov	w20, w3
     85c:	a9025bf5 	stp	x21, x22, [sp, #32]
     860:	2a0403f5 	mov	w21, w4
     864:	aa0203f6 	mov	x22, x2
     868:	a90363f7 	stp	x23, x24, [sp, #48]
     86c:	aa0103f8 	mov	x24, x1
     870:	aa0003f7 	mov	x23, x0
  struct redircmd *cmd;

  cmd = malloc(sizeof(*cmd));
     874:	52800500 	mov	w0, #0x28                  	// #40
     878:	94000507 	bl	1c94 <malloc>
     87c:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
     880:	52800502 	mov	w2, #0x28                  	// #40
     884:	52800001 	mov	w1, #0x0                   	// #0
     888:	94000252 	bl	11d0 <memset>
  cmd->type = REDIR;
     88c:	52800040 	mov	w0, #0x2                   	// #2
     890:	b9000260 	str	w0, [x19]
  cmd->file = file;
  cmd->efile = efile;
  cmd->mode = mode;
  cmd->fd = fd;
  return (struct cmd*)cmd;
}
     894:	aa1303e0 	mov	x0, x19
  cmd->cmd = subcmd;
     898:	a900e277 	stp	x23, x24, [x19, #8]
  cmd->efile = efile;
     89c:	f9000e76 	str	x22, [x19, #24]
  cmd->mode = mode;
     8a0:	29045674 	stp	w20, w21, [x19, #32]
}
     8a4:	a94153f3 	ldp	x19, x20, [sp, #16]
     8a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
     8ac:	a94363f7 	ldp	x23, x24, [sp, #48]
     8b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
     8b4:	d65f03c0 	ret

00000000000008b8 <pipecmd>:

struct cmd*
pipecmd(struct cmd *left, struct cmd *right)
{
     8b8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     8bc:	910003fd 	mov	x29, sp
     8c0:	a90153f3 	stp	x19, x20, [sp, #16]
     8c4:	aa0003f4 	mov	x20, x0
  struct pipecmd *cmd;

  cmd = malloc(sizeof(*cmd));
     8c8:	52800300 	mov	w0, #0x18                  	// #24
{
     8cc:	f90013f5 	str	x21, [sp, #32]
     8d0:	aa0103f5 	mov	x21, x1
  cmd = malloc(sizeof(*cmd));
     8d4:	940004f0 	bl	1c94 <malloc>
     8d8:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
     8dc:	52800302 	mov	w2, #0x18                  	// #24
     8e0:	52800001 	mov	w1, #0x0                   	// #0
     8e4:	9400023b 	bl	11d0 <memset>
  cmd->type = PIPE;
  cmd->left = left;
     8e8:	a900d674 	stp	x20, x21, [x19, #8]
  cmd->type = PIPE;
     8ec:	52800060 	mov	w0, #0x3                   	// #3
  cmd->right = right;
  return (struct cmd*)cmd;
}
     8f0:	f94013f5 	ldr	x21, [sp, #32]
  cmd->type = PIPE;
     8f4:	b9000260 	str	w0, [x19]
}
     8f8:	aa1303e0 	mov	x0, x19
     8fc:	a94153f3 	ldp	x19, x20, [sp, #16]
     900:	a8c37bfd 	ldp	x29, x30, [sp], #48
     904:	d65f03c0 	ret

0000000000000908 <listcmd>:

struct cmd*
listcmd(struct cmd *left, struct cmd *right)
{
     908:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     90c:	910003fd 	mov	x29, sp
     910:	a90153f3 	stp	x19, x20, [sp, #16]
     914:	aa0003f4 	mov	x20, x0
  struct listcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     918:	52800300 	mov	w0, #0x18                  	// #24
{
     91c:	f90013f5 	str	x21, [sp, #32]
     920:	aa0103f5 	mov	x21, x1
  cmd = malloc(sizeof(*cmd));
     924:	940004dc 	bl	1c94 <malloc>
     928:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
     92c:	52800302 	mov	w2, #0x18                  	// #24
     930:	52800001 	mov	w1, #0x0                   	// #0
     934:	94000227 	bl	11d0 <memset>
  cmd->type = LIST;
  cmd->left = left;
     938:	a900d674 	stp	x20, x21, [x19, #8]
  cmd->type = LIST;
     93c:	52800080 	mov	w0, #0x4                   	// #4
  cmd->right = right;
  return (struct cmd*)cmd;
}
     940:	f94013f5 	ldr	x21, [sp, #32]
  cmd->type = LIST;
     944:	b9000260 	str	w0, [x19]
}
     948:	aa1303e0 	mov	x0, x19
     94c:	a94153f3 	ldp	x19, x20, [sp, #16]
     950:	a8c37bfd 	ldp	x29, x30, [sp], #48
     954:	d65f03c0 	ret

0000000000000958 <backcmd>:

struct cmd*
backcmd(struct cmd *subcmd)
{
     958:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     95c:	910003fd 	mov	x29, sp
     960:	a90153f3 	stp	x19, x20, [sp, #16]
     964:	aa0003f4 	mov	x20, x0
  struct backcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     968:	52800200 	mov	w0, #0x10                  	// #16
     96c:	940004ca 	bl	1c94 <malloc>
     970:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
     974:	52800202 	mov	w2, #0x10                  	// #16
     978:	52800001 	mov	w1, #0x0                   	// #0
     97c:	94000215 	bl	11d0 <memset>
  cmd->type = BACK;
     980:	528000a0 	mov	w0, #0x5                   	// #5
     984:	b9000260 	str	w0, [x19]
  cmd->cmd = subcmd;
     988:	f9000674 	str	x20, [x19, #8]
  return (struct cmd*)cmd;
}
     98c:	aa1303e0 	mov	x0, x19
     990:	a94153f3 	ldp	x19, x20, [sp, #16]
     994:	a8c27bfd 	ldp	x29, x30, [sp], #32
     998:	d65f03c0 	ret

000000000000099c <gettoken>:
char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>&;()";

int
gettoken(char **ps, char *es, char **q, char **eq)
{
     99c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     9a0:	910003fd 	mov	x29, sp
     9a4:	a90153f3 	stp	x19, x20, [sp, #16]
  char *s;
  int ret;

  s = *ps;
  while(s < es && strchr(whitespace, *s))
     9a8:	b0000014 	adrp	x20, 1000 <nulterminate+0x7c>
     9ac:	913bd694 	add	x20, x20, #0xef5
{
     9b0:	a9025bf5 	stp	x21, x22, [sp, #32]
  while(s < es && strchr(whitespace, *s))
     9b4:	91020294 	add	x20, x20, #0x80
{
     9b8:	aa0003f6 	mov	x22, x0
     9bc:	a90363f7 	stp	x23, x24, [sp, #48]
     9c0:	aa0303f5 	mov	x21, x3
     9c4:	aa0103f7 	mov	x23, x1
  s = *ps;
     9c8:	f9400013 	ldr	x19, [x0]
{
     9cc:	aa0203f8 	mov	x24, x2
  while(s < es && strchr(whitespace, *s))
     9d0:	eb17027f 	cmp	x19, x23
     9d4:	540001a3 	b.cc	a08 <gettoken+0x6c>  // b.lo, b.ul, b.last
    s++;
  if(q)
     9d8:	b5000258 	cbnz	x24, a20 <gettoken+0x84>
    *q = s;
  ret = *s;
     9dc:	39400261 	ldrb	w1, [x19]
  switch(*s){
     9e0:	7100f03f 	cmp	w1, #0x3c
     9e4:	540003a8 	b.hi	a58 <gettoken+0xbc>  // b.pmore
     9e8:	7100943f 	cmp	w1, #0x25
     9ec:	540001e8 	b.hi	a28 <gettoken+0x8c>  // b.pmore
     9f0:	340006a1 	cbz	w1, ac4 <gettoken+0x128>
      s++;
    }
    break;
  default:
    ret = 'a';
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     9f4:	b0000001 	adrp	x1, 1000 <nulterminate+0x7c>
     9f8:	913bd421 	add	x1, x1, #0xef5
     9fc:	91020038 	add	x24, x1, #0x80
     a00:	91021834 	add	x20, x1, #0x86
     a04:	1400002c 	b	ab4 <gettoken+0x118>
  while(s < es && strchr(whitespace, *s))
     a08:	39400261 	ldrb	w1, [x19]
     a0c:	aa1403e0 	mov	x0, x20
     a10:	940001f7 	bl	11ec <strchr>
     a14:	b4fffe20 	cbz	x0, 9d8 <gettoken+0x3c>
    s++;
     a18:	91000673 	add	x19, x19, #0x1
     a1c:	17ffffed 	b	9d0 <gettoken+0x34>
    *q = s;
     a20:	f9000313 	str	x19, [x24]
     a24:	17ffffee 	b	9dc <gettoken+0x40>
  switch(*s){
     a28:	d2c06800 	mov	x0, #0x34000000000         	// #3573412790272
     a2c:	f2e30000 	movk	x0, #0x1800, lsl #48
     a30:	9ac12400 	lsr	x0, x0, x1
     a34:	3607fe00 	tbz	w0, #0, 9f4 <gettoken+0x58>
  ret = *s;
     a38:	2a0103f4 	mov	w20, w1
    s++;
     a3c:	91000673 	add	x19, x19, #0x1
      s++;
    break;
  }
  if(eq)
     a40:	b4000055 	cbz	x21, a48 <gettoken+0xac>
    *eq = s;
     a44:	f90002b3 	str	x19, [x21]

  while(s < es && strchr(whitespace, *s))
     a48:	b0000015 	adrp	x21, 1000 <nulterminate+0x7c>
     a4c:	913bd6b5 	add	x21, x21, #0xef5
     a50:	910202b5 	add	x21, x21, #0x80
     a54:	1400001f 	b	ad0 <gettoken+0x134>
  switch(*s){
     a58:	7100f83f 	cmp	w1, #0x3e
     a5c:	54000080 	b.eq	a6c <gettoken+0xd0>  // b.none
     a60:	7101f03f 	cmp	w1, #0x7c
     a64:	54fffc81 	b.ne	9f4 <gettoken+0x58>  // b.any
     a68:	17fffff4 	b	a38 <gettoken+0x9c>
    if(*s == '>'){
     a6c:	39400660 	ldrb	w0, [x19, #1]
     a70:	7100f81f 	cmp	w0, #0x3e
     a74:	54000080 	b.eq	a84 <gettoken+0xe8>  // b.none
    s++;
     a78:	91000673 	add	x19, x19, #0x1
  ret = *s;
     a7c:	2a0103f4 	mov	w20, w1
     a80:	17fffff0 	b	a40 <gettoken+0xa4>
      s++;
     a84:	91000a73 	add	x19, x19, #0x2
      ret = '+';
     a88:	52800574 	mov	w20, #0x2b                  	// #43
     a8c:	17ffffed 	b	a40 <gettoken+0xa4>
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     a90:	39400261 	ldrb	w1, [x19]
     a94:	aa1803e0 	mov	x0, x24
     a98:	940001d5 	bl	11ec <strchr>
     a9c:	b5000100 	cbnz	x0, abc <gettoken+0x120>
     aa0:	39400261 	ldrb	w1, [x19]
     aa4:	aa1403e0 	mov	x0, x20
     aa8:	940001d1 	bl	11ec <strchr>
     aac:	b5000080 	cbnz	x0, abc <gettoken+0x120>
      s++;
     ab0:	91000673 	add	x19, x19, #0x1
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     ab4:	eb17027f 	cmp	x19, x23
     ab8:	54fffec3 	b.cc	a90 <gettoken+0xf4>  // b.lo, b.ul, b.last
    ret = 'a';
     abc:	52800c34 	mov	w20, #0x61                  	// #97
     ac0:	17ffffe0 	b	a40 <gettoken+0xa4>
  switch(*s){
     ac4:	52800014 	mov	w20, #0x0                   	// #0
     ac8:	17ffffde 	b	a40 <gettoken+0xa4>
    s++;
     acc:	91000673 	add	x19, x19, #0x1
  while(s < es && strchr(whitespace, *s))
     ad0:	eb17027f 	cmp	x19, x23
     ad4:	540000a2 	b.cs	ae8 <gettoken+0x14c>  // b.hs, b.nlast
     ad8:	39400261 	ldrb	w1, [x19]
     adc:	aa1503e0 	mov	x0, x21
     ae0:	940001c3 	bl	11ec <strchr>
     ae4:	b5ffff40 	cbnz	x0, acc <gettoken+0x130>
  *ps = s;
     ae8:	f90002d3 	str	x19, [x22]
  return ret;
}
     aec:	2a1403e0 	mov	w0, w20
     af0:	a94153f3 	ldp	x19, x20, [sp, #16]
     af4:	a9425bf5 	ldp	x21, x22, [sp, #32]
     af8:	a94363f7 	ldp	x23, x24, [sp, #48]
     afc:	a8c47bfd 	ldp	x29, x30, [sp], #64
     b00:	d65f03c0 	ret

0000000000000b04 <peek>:

int
peek(char **ps, char *es, char *toks)
{
     b04:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     b08:	910003fd 	mov	x29, sp
     b0c:	a90153f3 	stp	x19, x20, [sp, #16]
  char *s;

  s = *ps;
  while(s < es && strchr(whitespace, *s))
     b10:	b0000014 	adrp	x20, 1000 <nulterminate+0x7c>
     b14:	913bd694 	add	x20, x20, #0xef5
{
     b18:	a9025bf5 	stp	x21, x22, [sp, #32]
  while(s < es && strchr(whitespace, *s))
     b1c:	91020294 	add	x20, x20, #0x80
{
     b20:	aa0003f5 	mov	x21, x0
  s = *ps;
     b24:	f9400013 	ldr	x19, [x0]
{
     b28:	aa0203f6 	mov	x22, x2
     b2c:	f9001bf7 	str	x23, [sp, #48]
     b30:	aa0103f7 	mov	x23, x1
  while(s < es && strchr(whitespace, *s))
     b34:	eb17027f 	cmp	x19, x23
     b38:	54000143 	b.cc	b60 <peek+0x5c>  // b.lo, b.ul, b.last
    s++;
  *ps = s;
     b3c:	f90002b3 	str	x19, [x21]
  return *s && strchr(toks, *s);
     b40:	39400261 	ldrb	w1, [x19]
     b44:	350001a1 	cbnz	w1, b78 <peek+0x74>
     b48:	52800000 	mov	w0, #0x0                   	// #0
}
     b4c:	f9401bf7 	ldr	x23, [sp, #48]
     b50:	a94153f3 	ldp	x19, x20, [sp, #16]
     b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
     b58:	a8c47bfd 	ldp	x29, x30, [sp], #64
     b5c:	d65f03c0 	ret
  while(s < es && strchr(whitespace, *s))
     b60:	39400261 	ldrb	w1, [x19]
     b64:	aa1403e0 	mov	x0, x20
     b68:	940001a1 	bl	11ec <strchr>
     b6c:	b4fffe80 	cbz	x0, b3c <peek+0x38>
    s++;
     b70:	91000673 	add	x19, x19, #0x1
     b74:	17fffff0 	b	b34 <peek+0x30>
  return *s && strchr(toks, *s);
     b78:	aa1603e0 	mov	x0, x22
     b7c:	9400019c 	bl	11ec <strchr>
     b80:	f100001f 	cmp	x0, #0x0
     b84:	1a9f07e0 	cset	w0, ne	// ne = any
     b88:	17fffff1 	b	b4c <peek+0x48>

0000000000000b8c <parseredirs>:
  return cmd;
}

struct cmd*
parseredirs(struct cmd *cmd, char **ps, char *es)
{
     b8c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     b90:	910003fd 	mov	x29, sp
     b94:	a90153f3 	stp	x19, x20, [sp, #16]
     b98:	aa0103f4 	mov	x20, x1
  int tok;
  char *q, *eq;

  while(peek(ps, es, "<>")){
     b9c:	aa0003f3 	mov	x19, x0
{
     ba0:	a9025bf5 	stp	x21, x22, [sp, #32]
  while(peek(ps, es, "<>")){
     ba4:	b0000016 	adrp	x22, 1000 <nulterminate+0x7c>
     ba8:	913796d6 	add	x22, x22, #0xde5
{
     bac:	aa0203f5 	mov	x21, x2
     bb0:	f9001bf7 	str	x23, [sp, #48]
  while(peek(ps, es, "<>")){
     bb4:	aa1603e2 	mov	x2, x22
     bb8:	aa1503e1 	mov	x1, x21
     bbc:	aa1403e0 	mov	x0, x20
     bc0:	97ffffd1 	bl	b04 <peek>
     bc4:	350000e0 	cbnz	w0, be0 <parseredirs+0x54>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
      break;
    }
  }
  return cmd;
}
     bc8:	f9401bf7 	ldr	x23, [sp, #48]
     bcc:	aa1303e0 	mov	x0, x19
     bd0:	a94153f3 	ldp	x19, x20, [sp, #16]
     bd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
     bd8:	a8c57bfd 	ldp	x29, x30, [sp], #80
     bdc:	d65f03c0 	ret
    tok = gettoken(ps, es, 0, 0);
     be0:	aa1503e1 	mov	x1, x21
     be4:	d2800003 	mov	x3, #0x0                   	// #0
     be8:	d2800002 	mov	x2, #0x0                   	// #0
     bec:	aa1403e0 	mov	x0, x20
     bf0:	97ffff6b 	bl	99c <gettoken>
     bf4:	2a0003f7 	mov	w23, w0
    if(gettoken(ps, es, &q, &eq) != 'a')
     bf8:	910123e3 	add	x3, sp, #0x48
     bfc:	910103e2 	add	x2, sp, #0x40
     c00:	aa1503e1 	mov	x1, x21
     c04:	aa1403e0 	mov	x0, x20
     c08:	97ffff65 	bl	99c <gettoken>
     c0c:	7101841f 	cmp	w0, #0x61
     c10:	54000080 	b.eq	c20 <parseredirs+0x94>  // b.none
      panic("missing file for redirection");
     c14:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     c18:	91372000 	add	x0, x0, #0xdc8
     c1c:	97fffe48 	bl	53c <panic>
    switch(tok){
     c20:	7100f2ff 	cmp	w23, #0x3c
     c24:	54000100 	b.eq	c44 <parseredirs+0xb8>  // b.none
     c28:	7100faff 	cmp	w23, #0x3e
     c2c:	540001a0 	b.eq	c60 <parseredirs+0xd4>  // b.none
     c30:	7100aeff 	cmp	w23, #0x2b
     c34:	54fffc01 	b.ne	bb4 <parseredirs+0x28>  // b.any
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
     c38:	52800024 	mov	w4, #0x1                   	// #1
     c3c:	52804023 	mov	w3, #0x201                 	// #513
     c40:	14000003 	b	c4c <parseredirs+0xc0>
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
     c44:	52800004 	mov	w4, #0x0                   	// #0
     c48:	52800003 	mov	w3, #0x0                   	// #0
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
     c4c:	a9440be1 	ldp	x1, x2, [sp, #64]
     c50:	aa1303e0 	mov	x0, x19
     c54:	97fffefe 	bl	84c <redircmd>
     c58:	aa0003f3 	mov	x19, x0
      break;
     c5c:	17ffffd6 	b	bb4 <parseredirs+0x28>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE|O_TRUNC, 1);
     c60:	52800024 	mov	w4, #0x1                   	// #1
     c64:	5280c023 	mov	w3, #0x601                 	// #1537
     c68:	17fffff9 	b	c4c <parseredirs+0xc0>

0000000000000c6c <parseexec>:
  return cmd;
}

struct cmd*
parseexec(char **ps, char *es)
{
     c6c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;

  if(peek(ps, es, "("))
     c70:	b0000002 	adrp	x2, 1000 <nulterminate+0x7c>
     c74:	9137a042 	add	x2, x2, #0xde8
{
     c78:	910003fd 	mov	x29, sp
     c7c:	a90153f3 	stp	x19, x20, [sp, #16]
     c80:	a9025bf5 	stp	x21, x22, [sp, #32]
     c84:	aa0003f6 	mov	x22, x0
     c88:	a90363f7 	stp	x23, x24, [sp, #48]
     c8c:	aa0103f7 	mov	x23, x1
     c90:	f90023f9 	str	x25, [sp, #64]
  if(peek(ps, es, "("))
     c94:	97ffff9c 	bl	b04 <peek>
     c98:	34000120 	cbz	w0, cbc <parseexec+0x50>
    ret = parseredirs(ret, ps, es);
  }
  cmd->argv[argc] = 0;
  cmd->eargv[argc] = 0;
  return ret;
}
     c9c:	f94023f9 	ldr	x25, [sp, #64]
    return parseblock(ps, es);
     ca0:	aa1703e1 	mov	x1, x23
}
     ca4:	a94153f3 	ldp	x19, x20, [sp, #16]
    return parseblock(ps, es);
     ca8:	aa1603e0 	mov	x0, x22
}
     cac:	a94363f7 	ldp	x23, x24, [sp, #48]
     cb0:	a9425bf5 	ldp	x21, x22, [sp, #32]
     cb4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    return parseblock(ps, es);
     cb8:	14000088 	b	ed8 <parseblock>
     cbc:	2a0003f4 	mov	w20, w0
  ret = execcmd();
     cc0:	97fffed4 	bl	810 <execcmd>
     cc4:	aa0003f5 	mov	x21, x0
  ret = parseredirs(ret, ps, es);
     cc8:	aa1703e2 	mov	x2, x23
     ccc:	aa1603e1 	mov	x1, x22
  while(!peek(ps, es, "|)&;")){
     cd0:	b0000019 	adrp	x25, 1000 <nulterminate+0x7c>
     cd4:	9137ff39 	add	x25, x25, #0xdff
  ret = parseredirs(ret, ps, es);
     cd8:	97ffffad 	bl	b8c <parseredirs>
     cdc:	910022b8 	add	x24, x21, #0x8
     ce0:	aa0003f3 	mov	x19, x0
  while(!peek(ps, es, "|)&;")){
     ce4:	aa1903e2 	mov	x2, x25
     ce8:	aa1703e1 	mov	x1, x23
     cec:	aa1603e0 	mov	x0, x22
     cf0:	97ffff85 	bl	b04 <peek>
     cf4:	34000160 	cbz	w0, d20 <parseexec+0xb4>
  cmd->argv[argc] = 0;
     cf8:	8b344ea0 	add	x0, x21, w20, uxtw #3
}
     cfc:	f94023f9 	ldr	x25, [sp, #64]
  cmd->argv[argc] = 0;
     d00:	f900041f 	str	xzr, [x0, #8]
  cmd->eargv[argc] = 0;
     d04:	f9002c1f 	str	xzr, [x0, #88]
}
     d08:	aa1303e0 	mov	x0, x19
     d0c:	a94153f3 	ldp	x19, x20, [sp, #16]
     d10:	a9425bf5 	ldp	x21, x22, [sp, #32]
     d14:	a94363f7 	ldp	x23, x24, [sp, #48]
     d18:	a8c67bfd 	ldp	x29, x30, [sp], #96
     d1c:	d65f03c0 	ret
    if((tok=gettoken(ps, es, &q, &eq)) == 0)
     d20:	910163e3 	add	x3, sp, #0x58
     d24:	910143e2 	add	x2, sp, #0x50
     d28:	aa1703e1 	mov	x1, x23
     d2c:	aa1603e0 	mov	x0, x22
     d30:	97ffff1b 	bl	99c <gettoken>
     d34:	34fffe20 	cbz	w0, cf8 <parseexec+0x8c>
    if(tok != 'a')
     d38:	7101841f 	cmp	w0, #0x61
     d3c:	54000080 	b.eq	d4c <parseexec+0xe0>  // b.none
      panic("syntax");
     d40:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     d44:	9137a800 	add	x0, x0, #0xdea
      panic("too many args");
     d48:	97fffdfd 	bl	53c <panic>
    cmd->argv[argc] = q;
     d4c:	f9402be0 	ldr	x0, [sp, #80]
     d50:	f9000300 	str	x0, [x24]
    cmd->eargv[argc] = eq;
     d54:	f9402fe0 	ldr	x0, [sp, #88]
    argc++;
     d58:	11000694 	add	w20, w20, #0x1
    cmd->eargv[argc] = eq;
     d5c:	f9002b00 	str	x0, [x24, #80]
    if(argc >= MAXARGS)
     d60:	71002a9f 	cmp	w20, #0xa
     d64:	54000081 	b.ne	d74 <parseexec+0x108>  // b.any
      panic("too many args");
     d68:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     d6c:	9137c400 	add	x0, x0, #0xdf1
     d70:	17fffff6 	b	d48 <parseexec+0xdc>
    ret = parseredirs(ret, ps, es);
     d74:	aa1303e0 	mov	x0, x19
     d78:	aa1703e2 	mov	x2, x23
     d7c:	aa1603e1 	mov	x1, x22
    if(argc >= MAXARGS)
     d80:	91002318 	add	x24, x24, #0x8
    ret = parseredirs(ret, ps, es);
     d84:	97ffff82 	bl	b8c <parseredirs>
     d88:	aa0003f3 	mov	x19, x0
     d8c:	17ffffd6 	b	ce4 <parseexec+0x78>

0000000000000d90 <parsepipe>:
{
     d90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     d94:	910003fd 	mov	x29, sp
     d98:	a90153f3 	stp	x19, x20, [sp, #16]
     d9c:	aa0003f3 	mov	x19, x0
     da0:	aa0103f4 	mov	x20, x1
     da4:	f90013f5 	str	x21, [sp, #32]
  cmd = parseexec(ps, es);
     da8:	97ffffb1 	bl	c6c <parseexec>
  if(peek(ps, es, "|")){
     dac:	b0000002 	adrp	x2, 1000 <nulterminate+0x7c>
     db0:	91381042 	add	x2, x2, #0xe04
  cmd = parseexec(ps, es);
     db4:	aa0003f5 	mov	x21, x0
  if(peek(ps, es, "|")){
     db8:	aa1403e1 	mov	x1, x20
     dbc:	aa1303e0 	mov	x0, x19
     dc0:	97ffff51 	bl	b04 <peek>
     dc4:	340001e0 	cbz	w0, e00 <parsepipe+0x70>
    gettoken(ps, es, 0, 0);
     dc8:	d2800003 	mov	x3, #0x0                   	// #0
     dcc:	d2800002 	mov	x2, #0x0                   	// #0
     dd0:	aa1403e1 	mov	x1, x20
     dd4:	aa1303e0 	mov	x0, x19
     dd8:	97fffef1 	bl	99c <gettoken>
    cmd = pipecmd(cmd, parsepipe(ps, es));
     ddc:	aa1403e1 	mov	x1, x20
     de0:	aa1303e0 	mov	x0, x19
     de4:	97ffffeb 	bl	d90 <parsepipe>
     de8:	aa0003e1 	mov	x1, x0
}
     dec:	a94153f3 	ldp	x19, x20, [sp, #16]
    cmd = pipecmd(cmd, parsepipe(ps, es));
     df0:	aa1503e0 	mov	x0, x21
}
     df4:	f94013f5 	ldr	x21, [sp, #32]
     df8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    cmd = pipecmd(cmd, parsepipe(ps, es));
     dfc:	17fffeaf 	b	8b8 <pipecmd>
}
     e00:	aa1503e0 	mov	x0, x21
     e04:	f94013f5 	ldr	x21, [sp, #32]
     e08:	a94153f3 	ldp	x19, x20, [sp, #16]
     e0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
     e10:	d65f03c0 	ret

0000000000000e14 <parseline>:
{
     e14:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     e18:	910003fd 	mov	x29, sp
     e1c:	a90153f3 	stp	x19, x20, [sp, #16]
     e20:	aa0003f4 	mov	x20, x0
     e24:	a9025bf5 	stp	x21, x22, [sp, #32]
     e28:	aa0103f5 	mov	x21, x1
  while(peek(ps, es, "&")){
     e2c:	b0000016 	adrp	x22, 1000 <nulterminate+0x7c>
     e30:	91381ad6 	add	x22, x22, #0xe06
  cmd = parsepipe(ps, es);
     e34:	97ffffd7 	bl	d90 <parsepipe>
     e38:	aa0003f3 	mov	x19, x0
  while(peek(ps, es, "&")){
     e3c:	aa1603e2 	mov	x2, x22
     e40:	aa1503e1 	mov	x1, x21
     e44:	aa1403e0 	mov	x0, x20
     e48:	97ffff2f 	bl	b04 <peek>
     e4c:	350002a0 	cbnz	w0, ea0 <parseline+0x8c>
  if(peek(ps, es, ";")){
     e50:	b0000002 	adrp	x2, 1000 <nulterminate+0x7c>
     e54:	91380842 	add	x2, x2, #0xe02
     e58:	aa1503e1 	mov	x1, x21
     e5c:	aa1403e0 	mov	x0, x20
     e60:	97ffff29 	bl	b04 <peek>
     e64:	34000300 	cbz	w0, ec4 <parseline+0xb0>
    gettoken(ps, es, 0, 0);
     e68:	d2800003 	mov	x3, #0x0                   	// #0
     e6c:	d2800002 	mov	x2, #0x0                   	// #0
     e70:	aa1503e1 	mov	x1, x21
     e74:	aa1403e0 	mov	x0, x20
     e78:	97fffec9 	bl	99c <gettoken>
    cmd = listcmd(cmd, parseline(ps, es));
     e7c:	aa1503e1 	mov	x1, x21
     e80:	aa1403e0 	mov	x0, x20
     e84:	97ffffe4 	bl	e14 <parseline>
     e88:	aa0003e1 	mov	x1, x0
}
     e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    cmd = listcmd(cmd, parseline(ps, es));
     e90:	aa1303e0 	mov	x0, x19
}
     e94:	a94153f3 	ldp	x19, x20, [sp, #16]
     e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    cmd = listcmd(cmd, parseline(ps, es));
     e9c:	17fffe9b 	b	908 <listcmd>
    gettoken(ps, es, 0, 0);
     ea0:	aa1503e1 	mov	x1, x21
     ea4:	d2800003 	mov	x3, #0x0                   	// #0
     ea8:	d2800002 	mov	x2, #0x0                   	// #0
     eac:	aa1403e0 	mov	x0, x20
     eb0:	97fffebb 	bl	99c <gettoken>
    cmd = backcmd(cmd);
     eb4:	aa1303e0 	mov	x0, x19
     eb8:	97fffea8 	bl	958 <backcmd>
     ebc:	aa0003f3 	mov	x19, x0
     ec0:	17ffffdf 	b	e3c <parseline+0x28>
}
     ec4:	aa1303e0 	mov	x0, x19
     ec8:	a94153f3 	ldp	x19, x20, [sp, #16]
     ecc:	a9425bf5 	ldp	x21, x22, [sp, #32]
     ed0:	a8c37bfd 	ldp	x29, x30, [sp], #48
     ed4:	d65f03c0 	ret

0000000000000ed8 <parseblock>:
{
     ed8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  if(!peek(ps, es, "("))
     edc:	b0000002 	adrp	x2, 1000 <nulterminate+0x7c>
     ee0:	9137a042 	add	x2, x2, #0xde8
{
     ee4:	910003fd 	mov	x29, sp
     ee8:	a90153f3 	stp	x19, x20, [sp, #16]
     eec:	aa0003f3 	mov	x19, x0
     ef0:	aa0103f4 	mov	x20, x1
     ef4:	f90013f5 	str	x21, [sp, #32]
  if(!peek(ps, es, "("))
     ef8:	97ffff03 	bl	b04 <peek>
     efc:	35000080 	cbnz	w0, f0c <parseblock+0x34>
    panic("parseblock");
     f00:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     f04:	91382000 	add	x0, x0, #0xe08
    panic("syntax - missing )");
     f08:	97fffd8d 	bl	53c <panic>
  gettoken(ps, es, 0, 0);
     f0c:	d2800002 	mov	x2, #0x0                   	// #0
     f10:	d2800003 	mov	x3, #0x0                   	// #0
     f14:	aa1403e1 	mov	x1, x20
     f18:	aa1303e0 	mov	x0, x19
     f1c:	97fffea0 	bl	99c <gettoken>
  cmd = parseline(ps, es);
     f20:	aa1403e1 	mov	x1, x20
     f24:	aa1303e0 	mov	x0, x19
     f28:	97ffffbb 	bl	e14 <parseline>
     f2c:	aa0003f5 	mov	x21, x0
  if(!peek(ps, es, ")"))
     f30:	b0000002 	adrp	x2, 1000 <nulterminate+0x7c>
     f34:	91389042 	add	x2, x2, #0xe24
     f38:	aa1403e1 	mov	x1, x20
     f3c:	aa1303e0 	mov	x0, x19
     f40:	97fffef1 	bl	b04 <peek>
     f44:	35000080 	cbnz	w0, f54 <parseblock+0x7c>
    panic("syntax - missing )");
     f48:	b0000000 	adrp	x0, 1000 <nulterminate+0x7c>
     f4c:	91384c00 	add	x0, x0, #0xe13
     f50:	17ffffee 	b	f08 <parseblock+0x30>
  gettoken(ps, es, 0, 0);
     f54:	aa1403e1 	mov	x1, x20
     f58:	aa1303e0 	mov	x0, x19
     f5c:	d2800003 	mov	x3, #0x0                   	// #0
     f60:	d2800002 	mov	x2, #0x0                   	// #0
     f64:	97fffe8e 	bl	99c <gettoken>
  cmd = parseredirs(cmd, ps, es);
     f68:	aa1403e2 	mov	x2, x20
     f6c:	aa1303e1 	mov	x1, x19
     f70:	aa1503e0 	mov	x0, x21
}
     f74:	f94013f5 	ldr	x21, [sp, #32]
     f78:	a94153f3 	ldp	x19, x20, [sp, #16]
     f7c:	a8c37bfd 	ldp	x29, x30, [sp], #48
  cmd = parseredirs(cmd, ps, es);
     f80:	17ffff03 	b	b8c <parseredirs>

0000000000000f84 <nulterminate>:

// NUL-terminate all the counted strings.
struct cmd*
nulterminate(struct cmd *cmd)
{
     f84:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     f88:	910003fd 	mov	x29, sp
     f8c:	f9000bf3 	str	x19, [sp, #16]
     f90:	aa0003f3 	mov	x19, x0
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
     f94:	b4000120 	cbz	x0, fb8 <nulterminate+0x34>
    return 0;

  switch(cmd->type){
     f98:	b9400000 	ldr	w0, [x0]
     f9c:	71000c1f 	cmp	w0, #0x3
     fa0:	54000360 	b.eq	100c <nulterminate+0x88>  // b.none
     fa4:	5400012c 	b.gt	fc8 <nulterminate+0x44>
     fa8:	7100041f 	cmp	w0, #0x1
     fac:	540001a0 	b.eq	fe0 <nulterminate+0x5c>  // b.none
     fb0:	7100081f 	cmp	w0, #0x2
     fb4:	54000220 	b.eq	ff8 <nulterminate+0x74>  // b.none
    bcmd = (struct backcmd*)cmd;
    nulterminate(bcmd->cmd);
    break;
  }
  return cmd;
}
     fb8:	aa1303e0 	mov	x0, x19
     fbc:	f9400bf3 	ldr	x19, [sp, #16]
     fc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
     fc4:	d65f03c0 	ret
  switch(cmd->type){
     fc8:	7100101f 	cmp	w0, #0x4
     fcc:	54000200 	b.eq	100c <nulterminate+0x88>  // b.none
     fd0:	7100141f 	cmp	w0, #0x5
     fd4:	54ffff21 	b.ne	fb8 <nulterminate+0x34>  // b.any
    nulterminate(bcmd->cmd);
     fd8:	f9400660 	ldr	x0, [x19, #8]
     fdc:	1400000f 	b	1018 <nulterminate+0x94>
     fe0:	91002260 	add	x0, x19, #0x8
    for(i=0; ecmd->argv[i]; i++)
     fe4:	f8408401 	ldr	x1, [x0], #8
     fe8:	b4fffe81 	cbz	x1, fb8 <nulterminate+0x34>
      *ecmd->eargv[i] = 0;
     fec:	f9402401 	ldr	x1, [x0, #72]
     ff0:	3900003f 	strb	wzr, [x1]
    for(i=0; ecmd->argv[i]; i++)
     ff4:	17fffffc 	b	fe4 <nulterminate+0x60>
    nulterminate(rcmd->cmd);
     ff8:	f9400660 	ldr	x0, [x19, #8]
     ffc:	97ffffe2 	bl	f84 <nulterminate>
    *rcmd->efile = 0;
    1000:	f9400e60 	ldr	x0, [x19, #24]
    1004:	3900001f 	strb	wzr, [x0]
    break;
    1008:	17ffffec 	b	fb8 <nulterminate+0x34>
    nulterminate(lcmd->left);
    100c:	f9400660 	ldr	x0, [x19, #8]
    1010:	97ffffdd 	bl	f84 <nulterminate>
    nulterminate(lcmd->right);
    1014:	f9400a60 	ldr	x0, [x19, #16]
    nulterminate(bcmd->cmd);
    1018:	97ffffdb 	bl	f84 <nulterminate>
    break;
    101c:	17ffffe7 	b	fb8 <nulterminate+0x34>

0000000000001020 <parsecmd>:
{
    1020:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1024:	910003fd 	mov	x29, sp
    1028:	a90153f3 	stp	x19, x20, [sp, #16]
  es = s + strlen(s);
    102c:	aa0003f3 	mov	x19, x0
{
    1030:	f90017e0 	str	x0, [sp, #40]
  es = s + strlen(s);
    1034:	94000057 	bl	1190 <strlen>
    1038:	8b204273 	add	x19, x19, w0, uxtw
  cmd = parseline(&s, es);
    103c:	9100a3e0 	add	x0, sp, #0x28
    1040:	aa1303e1 	mov	x1, x19
    1044:	97ffff74 	bl	e14 <parseline>
  peek(&s, es, "");
    1048:	aa1303e1 	mov	x1, x19
  cmd = parseline(&s, es);
    104c:	aa0003f4 	mov	x20, x0
  peek(&s, es, "");
    1050:	90000002 	adrp	x2, 1000 <nulterminate+0x7c>
    1054:	9139e042 	add	x2, x2, #0xe78
    1058:	9100a3e0 	add	x0, sp, #0x28
    105c:	97fffeaa 	bl	b04 <peek>
  if(s != es){
    1060:	f94017e2 	ldr	x2, [sp, #40]
    1064:	eb13005f 	cmp	x2, x19
    1068:	54000100 	b.eq	1088 <parsecmd+0x68>  // b.none
    fprintf(2, "leftovers: %s\n", s);
    106c:	90000001 	adrp	x1, 1000 <nulterminate+0x7c>
    1070:	91389821 	add	x1, x1, #0xe26
    1074:	52800040 	mov	w0, #0x2                   	// #2
    1078:	94000297 	bl	1ad4 <fprintf>
    panic("syntax");
    107c:	90000000 	adrp	x0, 1000 <nulterminate+0x7c>
    1080:	9137a800 	add	x0, x0, #0xdea
    1084:	97fffd2e 	bl	53c <panic>
  nulterminate(cmd);
    1088:	aa1403e0 	mov	x0, x20
    108c:	97ffffbe 	bl	f84 <nulterminate>
}
    1090:	aa1403e0 	mov	x0, x20
    1094:	a94153f3 	ldp	x19, x20, [sp, #16]
    1098:	a8c37bfd 	ldp	x29, x30, [sp], #48
    109c:	d65f03c0 	ret

00000000000010a0 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
    10a0:	d2800002 	mov	x2, #0x0                   	// #0
    10a4:	38626823 	ldrb	w3, [x1, x2]
    10a8:	38226803 	strb	w3, [x0, x2]
    10ac:	91000442 	add	x2, x2, #0x1
    10b0:	35ffffa3 	cbnz	w3, 10a4 <strcpy+0x4>
    ;
  return os;
}
    10b4:	d65f03c0 	ret

00000000000010b8 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
    10b8:	d2800003 	mov	x3, #0x0                   	// #0
    10bc:	4b030044 	sub	w4, w2, w3
    10c0:	7100009f 	cmp	w4, #0x0
    10c4:	5400006d 	b.le	10d0 <strncpy+0x18>
    10c8:	38636825 	ldrb	w5, [x1, x3]
    10cc:	350000e5 	cbnz	w5, 10e8 <strncpy+0x30>
    10d0:	8b030003 	add	x3, x0, x3
    10d4:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
    10d8:	4b010082 	sub	w2, w4, w1
    10dc:	7100005f 	cmp	w2, #0x0
    10e0:	540000ac 	b.gt	10f4 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
    10e4:	d65f03c0 	ret
    *s++ = *t++;
    10e8:	38236805 	strb	w5, [x0, x3]
    n--;
    10ec:	91000463 	add	x3, x3, #0x1
    10f0:	17fffff3 	b	10bc <strncpy+0x4>
    *s++ = 0;
    10f4:	3821687f 	strb	wzr, [x3, x1]
    10f8:	91000421 	add	x1, x1, #0x1
    10fc:	17fffff7 	b	10d8 <strncpy+0x20>

0000000000001100 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
    1100:	aa0003e2 	mov	x2, x0
    1104:	39400043 	ldrb	w3, [x2]
    1108:	aa0203e4 	mov	x4, x2
    s++;
    110c:	91000442 	add	x2, x2, #0x1
  while(*s)
    1110:	35ffffa3 	cbnz	w3, 1104 <strcat+0x4>
    1114:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
    1118:	38626823 	ldrb	w3, [x1, x2]
    111c:	38226883 	strb	w3, [x4, x2]
    1120:	91000442 	add	x2, x2, #0x1
    1124:	35ffffa3 	cbnz	w3, 1118 <strcat+0x18>
    ;
  return os;
}
    1128:	d65f03c0 	ret

000000000000112c <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
    112c:	d2800002 	mov	x2, #0x0                   	// #0
    1130:	38626803 	ldrb	w3, [x0, x2]
    1134:	38626824 	ldrb	w4, [x1, x2]
    1138:	34000083 	cbz	w3, 1148 <strcmp+0x1c>
    113c:	91000442 	add	x2, x2, #0x1
    1140:	6b04007f 	cmp	w3, w4
    1144:	54ffff60 	b.eq	1130 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
    1148:	4b040060 	sub	w0, w3, w4
    114c:	d65f03c0 	ret

0000000000001150 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
    1150:	340001c2 	cbz	w2, 1188 <strncmp+0x38>
    1154:	39400003 	ldrb	w3, [x0]
    1158:	34000083 	cbz	w3, 1168 <strncmp+0x18>
    115c:	39400024 	ldrb	w4, [x1]
    1160:	6b03009f 	cmp	w4, w3
    1164:	540000a0 	b.eq	1178 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
    1168:	39400000 	ldrb	w0, [x0]
    116c:	39400021 	ldrb	w1, [x1]
    1170:	4b010000 	sub	w0, w0, w1
}
    1174:	d65f03c0 	ret
    n--, p++, q++;
    1178:	51000442 	sub	w2, w2, #0x1
    117c:	91000400 	add	x0, x0, #0x1
    1180:	91000421 	add	x1, x1, #0x1
    1184:	17fffff3 	b	1150 <strncmp>
    return 0;
    1188:	52800000 	mov	w0, #0x0                   	// #0
    118c:	17fffffa 	b	1174 <strncmp+0x24>

0000000000001190 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
    1190:	d1000402 	sub	x2, x0, #0x1
    1194:	d2800001 	mov	x1, #0x0                   	// #0
    1198:	aa0103e0 	mov	x0, x1
    119c:	91000421 	add	x1, x1, #0x1
    11a0:	38616843 	ldrb	w3, [x2, x1]
    11a4:	35ffffa3 	cbnz	w3, 1198 <strlen+0x8>
    ;
  return n;
}
    11a8:	d65f03c0 	ret

00000000000011ac <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
    11ac:	d1000403 	sub	x3, x0, #0x1
    11b0:	d2800002 	mov	x2, #0x0                   	// #0
    11b4:	2a0203e0 	mov	w0, w2
    11b8:	6b02003f 	cmp	w1, w2
    11bc:	54000089 	b.ls	11cc <strnlen+0x20>  // b.plast
    11c0:	91000442 	add	x2, x2, #0x1
    11c4:	38626864 	ldrb	w4, [x3, x2]
    11c8:	35ffff64 	cbnz	w4, 11b4 <strnlen+0x8>
    n++;
  return n;
}
    11cc:	d65f03c0 	ret

00000000000011d0 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    11d0:	d2800003 	mov	x3, #0x0                   	// #0
    11d4:	6b03005f 	cmp	w2, w3
    11d8:	54000048 	b.hi	11e0 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
    11dc:	d65f03c0 	ret
    cdst[i] = c;
    11e0:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
    11e4:	91000463 	add	x3, x3, #0x1
    11e8:	17fffffb 	b	11d4 <memset+0x4>

00000000000011ec <strchr>:

char*
strchr(const char *s, char c)
{
    11ec:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
    11f0:	39400002 	ldrb	w2, [x0]
    11f4:	35000062 	cbnz	w2, 1200 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
    11f8:	d2800000 	mov	x0, #0x0                   	// #0
}
    11fc:	d65f03c0 	ret
    if(*s == c)
    1200:	6b01005f 	cmp	w2, w1
    1204:	54ffffc0 	b.eq	11fc <strchr+0x10>  // b.none
  for(; *s; s++)
    1208:	91000400 	add	x0, x0, #0x1
    120c:	17fffff9 	b	11f0 <strchr+0x4>

0000000000001210 <gets>:

char*
gets(char *buf, int max)
{
    1210:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    1214:	910003fd 	mov	x29, sp
    1218:	a90153f3 	stp	x19, x20, [sp, #16]
    121c:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    1220:	d2800014 	mov	x20, #0x0                   	// #0
{
    1224:	f9001bf7 	str	x23, [sp, #48]
    1228:	2a0103f7 	mov	w23, w1
    122c:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
    1230:	11000695 	add	w21, w20, #0x1
    1234:	2a1403f6 	mov	w22, w20
    1238:	6b1702bf 	cmp	w21, w23
    123c:	540000ea 	b.ge	1258 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
    1240:	91013fe1 	add	x1, sp, #0x4f
    1244:	52800022 	mov	w2, #0x1                   	// #1
    1248:	52800000 	mov	w0, #0x0                   	// #0
    124c:	94000063 	bl	13d8 <read>
    if(cc < 1)
    1250:	7100001f 	cmp	w0, #0x0
    1254:	5400012c 	b.gt	1278 <gets+0x68>
  for(i=0; i+1 < max; ){
    1258:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
    125c:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
    1260:	aa1303e0 	mov	x0, x19
    1264:	f9401bf7 	ldr	x23, [sp, #48]
    1268:	a94153f3 	ldp	x19, x20, [sp, #16]
    126c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1270:	a8c57bfd 	ldp	x29, x30, [sp], #80
    1274:	d65f03c0 	ret
    buf[i++] = c;
    1278:	39413fe0 	ldrb	w0, [sp, #79]
    127c:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
    1280:	91000694 	add	x20, x20, #0x1
    1284:	7100281f 	cmp	w0, #0xa
    1288:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
    128c:	54fffd21 	b.ne	1230 <gets+0x20>  // b.any
    1290:	17fffff3 	b	125c <gets+0x4c>

0000000000001294 <stat>:

int
stat(const char *n, struct stat *st)
{
    1294:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1298:	910003fd 	mov	x29, sp
    129c:	a90153f3 	stp	x19, x20, [sp, #16]
    12a0:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    12a4:	52800001 	mov	w1, #0x0                   	// #0
    12a8:	9400005b 	bl	1414 <open>
  if(fd < 0)
    12ac:	37f80160 	tbnz	w0, #31, 12d8 <stat+0x44>
    return -1;
  r = fstat(fd, st);
    12b0:	aa1303e1 	mov	x1, x19
    12b4:	2a0003f4 	mov	w20, w0
    12b8:	94000060 	bl	1438 <fstat>
    12bc:	2a0003f3 	mov	w19, w0
  close(fd);
    12c0:	2a1403e0 	mov	w0, w20
    12c4:	9400004b 	bl	13f0 <close>
  return r;
}
    12c8:	2a1303e0 	mov	w0, w19
    12cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    12d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    12d4:	d65f03c0 	ret
    return -1;
    12d8:	12800013 	mov	w19, #0xffffffff            	// #-1
    12dc:	17fffffb 	b	12c8 <stat+0x34>

00000000000012e0 <atoi>:

int
atoi(const char *s)
{
    12e0:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
    12e4:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
    12e8:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
    12ec:	39400043 	ldrb	w3, [x2]
    12f0:	5100c061 	sub	w1, w3, #0x30
    12f4:	12001c21 	and	w1, w1, #0xff
    12f8:	7100243f 	cmp	w1, #0x9
    12fc:	54000049 	b.ls	1304 <atoi+0x24>  // b.plast
  return n;
}
    1300:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
    1304:	1b040c01 	madd	w1, w0, w4, w3
    1308:	91000442 	add	x2, x2, #0x1
    130c:	5100c020 	sub	w0, w1, #0x30
    1310:	17fffff7 	b	12ec <atoi+0xc>

0000000000001314 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    1314:	eb01001f 	cmp	x0, x1
    1318:	54000263 	b.cc	1364 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
    131c:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
    1320:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
    1324:	d2800003 	mov	x3, #0x0                   	// #0
    1328:	d1000463 	sub	x3, x3, #0x1
    132c:	11000464 	add	w4, w3, #0x1
    1330:	0b020084 	add	w4, w4, w2
    1334:	7100009f 	cmp	w4, #0x0
    1338:	5400014d 	b.le	1360 <memmove+0x4c>
      *--dst = *--src;
    133c:	38636824 	ldrb	w4, [x1, x3]
    1340:	382368a4 	strb	w4, [x5, x3]
    1344:	17fffff9 	b	1328 <memmove+0x14>
      *dst++ = *src++;
    1348:	38636824 	ldrb	w4, [x1, x3]
    134c:	38236804 	strb	w4, [x0, x3]
    1350:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
    1354:	4b030044 	sub	w4, w2, w3
    1358:	7100009f 	cmp	w4, #0x0
    135c:	54ffff6c 	b.gt	1348 <memmove+0x34>
  }
  return vdst;
}
    1360:	d65f03c0 	ret
    1364:	d2800003 	mov	x3, #0x0                   	// #0
    1368:	17fffffb 	b	1354 <memmove+0x40>

000000000000136c <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    136c:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
    1370:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
    1374:	d2800004 	mov	x4, #0x0                   	// #0
    1378:	eb02009f 	cmp	x4, x2
    137c:	54000061 	b.ne	1388 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
    1380:	52800000 	mov	w0, #0x0                   	// #0
    1384:	14000007 	b	13a0 <memcmp+0x34>
    if (*p1 != *p2) {
    1388:	38646803 	ldrb	w3, [x0, x4]
    138c:	91000484 	add	x4, x4, #0x1
    1390:	38646825 	ldrb	w5, [x1, x4]
    1394:	6b05007f 	cmp	w3, w5
    1398:	54ffff00 	b.eq	1378 <memcmp+0xc>  // b.none
      return *p1 - *p2;
    139c:	4b050060 	sub	w0, w3, w5
}
    13a0:	d65f03c0 	ret

00000000000013a4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
    13a4:	17ffffdc 	b	1314 <memmove>

00000000000013a8 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
    13a8:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
    13ac:	d4000001 	svc	#0x0
 ret
    13b0:	d65f03c0 	ret

00000000000013b4 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
    13b4:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
    13b8:	d4000001 	svc	#0x0
 ret
    13bc:	d65f03c0 	ret

00000000000013c0 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
    13c0:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
    13c4:	d4000001 	svc	#0x0
 ret
    13c8:	d65f03c0 	ret

00000000000013cc <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
    13cc:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
    13d0:	d4000001 	svc	#0x0
 ret
    13d4:	d65f03c0 	ret

00000000000013d8 <read>:
.global read
read:
 mov x7, #SYS_read
    13d8:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
    13dc:	d4000001 	svc	#0x0
 ret
    13e0:	d65f03c0 	ret

00000000000013e4 <write>:
.global write
write:
 mov x7, #SYS_write
    13e4:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
    13e8:	d4000001 	svc	#0x0
 ret
    13ec:	d65f03c0 	ret

00000000000013f0 <close>:
.global close
close:
 mov x7, #SYS_close
    13f0:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
    13f4:	d4000001 	svc	#0x0
 ret
    13f8:	d65f03c0 	ret

00000000000013fc <kill>:
.global kill
kill:
 mov x7, #SYS_kill
    13fc:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
    1400:	d4000001 	svc	#0x0
 ret
    1404:	d65f03c0 	ret

0000000000001408 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
    1408:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
    140c:	d4000001 	svc	#0x0
 ret
    1410:	d65f03c0 	ret

0000000000001414 <open>:
.global open
open:
 mov x7, #SYS_open
    1414:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
    1418:	d4000001 	svc	#0x0
 ret
    141c:	d65f03c0 	ret

0000000000001420 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
    1420:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
    1424:	d4000001 	svc	#0x0
 ret
    1428:	d65f03c0 	ret

000000000000142c <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
    142c:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
    1430:	d4000001 	svc	#0x0
 ret
    1434:	d65f03c0 	ret

0000000000001438 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
    1438:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
    143c:	d4000001 	svc	#0x0
 ret
    1440:	d65f03c0 	ret

0000000000001444 <link>:
.global link
link:
 mov x7, #SYS_link
    1444:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
    1448:	d4000001 	svc	#0x0
 ret
    144c:	d65f03c0 	ret

0000000000001450 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
    1450:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
    1454:	d4000001 	svc	#0x0
 ret
    1458:	d65f03c0 	ret

000000000000145c <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
    145c:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
    1460:	d4000001 	svc	#0x0
 ret
    1464:	d65f03c0 	ret

0000000000001468 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
    1468:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
    146c:	d4000001 	svc	#0x0
 ret
    1470:	d65f03c0 	ret

0000000000001474 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
    1474:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
    1478:	d4000001 	svc	#0x0
 ret
    147c:	d65f03c0 	ret

0000000000001480 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
    1480:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
    1484:	d4000001 	svc	#0x0
 ret
    1488:	d65f03c0 	ret

000000000000148c <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
    148c:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
    1490:	d4000001 	svc	#0x0
 ret
    1494:	d65f03c0 	ret

0000000000001498 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
    1498:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
    149c:	d4000001 	svc	#0x0
 ret
    14a0:	d65f03c0 	ret

00000000000014a4 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
    14a4:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
    14a8:	d4000001 	svc	#0x0
 ret
    14ac:	d65f03c0 	ret

00000000000014b0 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
    14b0:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
    14b4:	d4000001 	svc	#0x0
 ret
    14b8:	d65f03c0 	ret

00000000000014bc <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
    14bc:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
    14c0:	d4000001 	svc	#0x0
 ret
    14c4:	d65f03c0 	ret

00000000000014c8 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
    14c8:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
    14cc:	d4000001 	svc	#0x0
 ret
    14d0:	d65f03c0 	ret

00000000000014d4 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
    14d4:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
    14d8:	d4000001 	svc	#0x0
 ret
    14dc:	d65f03c0 	ret

00000000000014e0 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
    14e0:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
    14e4:	d4000001 	svc	#0x0
 ret
    14e8:	d65f03c0 	ret

00000000000014ec <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
    14ec:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
    14f0:	d4000001 	svc	#0x0
 ret
    14f4:	d65f03c0 	ret

00000000000014f8 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
    14f8:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
    14fc:	d4000001 	svc	#0x0
 ret
    1500:	d65f03c0 	ret

0000000000001504 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
    1504:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
    1508:	d4000001 	svc	#0x0
 ret
    150c:	d65f03c0 	ret

0000000000001510 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
    1510:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
    1514:	d4000001 	svc	#0x0
 ret
    1518:	d65f03c0 	ret

000000000000151c <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
    151c:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
    1520:	d4000001 	svc	#0x0
 ret
    1524:	d65f03c0 	ret

0000000000001528 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
    1528:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
    152c:	d4000001 	svc	#0x0
 ret
    1530:	d65f03c0 	ret

0000000000001534 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
    1534:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
    1538:	d4000001 	svc	#0x0
 ret
    153c:	d65f03c0 	ret

0000000000001540 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
    1540:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
    1544:	d4000001 	svc	#0x0
 ret
    1548:	d65f03c0 	ret

000000000000154c <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
    154c:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
    1550:	d4000001 	svc	#0x0
 ret
    1554:	d65f03c0 	ret

0000000000001558 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
    1558:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
    155c:	d4000001 	svc	#0x0
 ret
    1560:	d65f03c0 	ret

0000000000001564 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
    1564:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
    1568:	d4000001 	svc	#0x0
 ret
    156c:	d65f03c0 	ret

0000000000001570 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
    1570:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
    1574:	d4000001 	svc	#0x0
 ret
    1578:	d65f03c0 	ret

000000000000157c <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
    157c:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
    1580:	d4000001 	svc	#0x0
 ret
    1584:	d65f03c0 	ret

0000000000001588 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
    1588:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
    158c:	d4000001 	svc	#0x0
 ret
    1590:	d65f03c0 	ret

0000000000001594 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
    1594:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
    1598:	d4000001 	svc	#0x0
 ret
    159c:	d65f03c0 	ret

00000000000015a0 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
    15a0:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
    15a4:	d4000001 	svc	#0x0
 ret
    15a8:	d65f03c0 	ret

00000000000015ac <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
    15ac:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
    15b0:	d4000001 	svc	#0x0
 ret
    15b4:	d65f03c0 	ret

00000000000015b8 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
    15b8:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
    15bc:	d4000001 	svc	#0x0
 ret
    15c0:	d65f03c0 	ret

00000000000015c4 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
    15c4:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
    15c8:	d4000001 	svc	#0x0
 ret
    15cc:	d65f03c0 	ret

00000000000015d0 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
    15d0:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
    15d4:	d4000001 	svc	#0x0
 ret
    15d8:	d65f03c0 	ret

00000000000015dc <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
    15dc:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
    15e0:	d4000001 	svc	#0x0
 ret
    15e4:	d65f03c0 	ret

00000000000015e8 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
    15e8:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
    15ec:	d4000001 	svc	#0x0
 ret
    15f0:	d65f03c0 	ret

00000000000015f4 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
    15f4:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
    15f8:	d4000001 	svc	#0x0
 ret
    15fc:	d65f03c0 	ret

0000000000001600 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
    1600:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
    1604:	d4000001 	svc	#0x0
 ret
    1608:	d65f03c0 	ret

000000000000160c <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
    160c:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
    1610:	d4000001 	svc	#0x0
 ret
    1614:	d65f03c0 	ret

0000000000001618 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
    1618:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
    161c:	d4000001 	svc	#0x0
 ret
    1620:	d65f03c0 	ret

0000000000001624 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
    1624:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
    1628:	d4000001 	svc	#0x0
 ret
    162c:	d65f03c0 	ret

0000000000001630 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
    1630:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
    1634:	d4000001 	svc	#0x0
 ret
    1638:	d65f03c0 	ret

000000000000163c <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
    163c:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
    1640:	d4000001 	svc	#0x0
 ret
    1644:	d65f03c0 	ret

0000000000001648 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
    1648:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
    164c:	d4000001 	svc	#0x0
 ret
    1650:	d65f03c0 	ret

0000000000001654 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
    1654:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
    1658:	d4000001 	svc	#0x0
 ret
    165c:	d65f03c0 	ret

0000000000001660 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
    1660:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
    1664:	d4000001 	svc	#0x0
 ret
    1668:	d65f03c0 	ret

000000000000166c <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
    166c:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
    1670:	d4000001 	svc	#0x0
 ret
    1674:	d65f03c0 	ret

0000000000001678 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
    1678:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
    167c:	d4000001 	svc	#0x0
 ret
    1680:	d65f03c0 	ret

0000000000001684 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
    1684:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
    1688:	d4000001 	svc	#0x0
 ret
    168c:	d65f03c0 	ret

0000000000001690 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
    1690:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
    1694:	d4000001 	svc	#0x0
 ret
    1698:	d65f03c0 	ret

000000000000169c <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
    169c:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
    16a0:	d4000001 	svc	#0x0
 ret
    16a4:	d65f03c0 	ret

00000000000016a8 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
    16a8:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
    16ac:	d4000001 	svc	#0x0
 ret
    16b0:	d65f03c0 	ret

00000000000016b4 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
    16b4:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
    16b8:	d4000001 	svc	#0x0
 ret
    16bc:	d65f03c0 	ret

00000000000016c0 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
    16c0:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
    16c4:	d4000001 	svc	#0x0
 ret
    16c8:	d65f03c0 	ret

00000000000016cc <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
    16cc:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
    16d0:	d4000001 	svc	#0x0
 ret
    16d4:	d65f03c0 	ret

00000000000016d8 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
    16d8:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
    16dc:	d4000001 	svc	#0x0
 ret
    16e0:	d65f03c0 	ret

00000000000016e4 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
    16e4:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
    16e8:	d4000001 	svc	#0x0
 ret
    16ec:	d65f03c0 	ret

00000000000016f0 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
    16f0:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
    16f4:	d4000001 	svc	#0x0
 ret
    16f8:	d65f03c0 	ret

00000000000016fc <listen>:
.global listen
listen:
 mov x7, #SYS_listen
    16fc:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
    1700:	d4000001 	svc	#0x0
 ret
    1704:	d65f03c0 	ret

0000000000001708 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
    1708:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
    170c:	d4000001 	svc	#0x0
 ret
    1710:	d65f03c0 	ret

0000000000001714 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
    1714:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
    1718:	52800022 	mov	w2, #0x1                   	// #1
{
    171c:	910003fd 	mov	x29, sp
    1720:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
    1724:	91007fe1 	add	x1, sp, #0x1f
    1728:	97ffff2f 	bl	13e4 <write>
    172c:	7100041f 	cmp	w0, #0x1
}
    1730:	1a9f17e0 	cset	w0, eq	// eq = none
    1734:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1738:	d65f03c0 	ret

000000000000173c <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
    173c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1740:	910003fd 	mov	x29, sp
    1744:	a90153f3 	stp	x19, x20, [sp, #16]
    1748:	a9025bf5 	stp	x21, x22, [sp, #32]
    174c:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    1750:	6a417c7f 	tst	w3, w1, lsr #31
    1754:	54000300 	b.eq	17b4 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
    1758:	4b0103e1 	neg	w1, w1
    neg = 1;
    175c:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
    1760:	90000003 	adrp	x3, 1000 <nulterminate+0x7c>
    1764:	913b9063 	add	x3, x3, #0xee4
    1768:	9100c3f5 	add	x21, sp, #0x30
    176c:	d2800000 	mov	x0, #0x0                   	// #0
    1770:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
    1774:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
    1778:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
    177c:	2a0403e1 	mov	w1, w4
    1780:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
    1784:	38666866 	ldrb	w6, [x3, x6]
    1788:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
    178c:	91000400 	add	x0, x0, #0x1
    1790:	54ffff09 	b.ls	1770 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
    1794:	11000493 	add	w19, w4, #0x1
  if(neg)
    1798:	34000085 	cbz	w5, 17a8 <printint+0x6c>
    buf[i++] = '-';
    179c:	528005a0 	mov	w0, #0x2d                  	// #45
    17a0:	38334aa0 	strb	w0, [x21, w19, uxtw]
    17a4:	11000893 	add	w19, w4, #0x2
    17a8:	51000673 	sub	w19, w19, #0x1
    17ac:	52800014 	mov	w20, #0x0                   	// #0
    17b0:	14000008 	b	17d0 <printint+0x94>
  neg = 0;
    17b4:	52800005 	mov	w5, #0x0                   	// #0
    17b8:	17ffffea 	b	1760 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
    17bc:	38736aa1 	ldrb	w1, [x21, x19]
    17c0:	2a1603e0 	mov	w0, w22
    17c4:	d1000673 	sub	x19, x19, #0x1
    17c8:	97ffffd3 	bl	1714 <putc>
    17cc:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
    17d0:	3100067f 	cmn	w19, #0x1
    17d4:	54ffff41 	b.ne	17bc <printint+0x80>  // b.any
  return written;
}
    17d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    17dc:	2a1403e0 	mov	w0, w20
    17e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    17e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    17e8:	d65f03c0 	ret

00000000000017ec <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
    17ec:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    17f0:	910003fd 	mov	x29, sp
    17f4:	a90153f3 	stp	x19, x20, [sp, #16]
    17f8:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
    17fc:	52800015 	mov	w21, #0x0                   	// #0
{
    1800:	a90363f7 	stp	x23, x24, [sp, #48]
    1804:	2a0003f7 	mov	w23, w0
    1808:	a9046bf9 	stp	x25, x26, [sp, #64]
    180c:	aa0103f9 	mov	x25, x1

  state = 0;
    1810:	52800001 	mov	w1, #0x0                   	// #0
{
    1814:	a90573fb 	stp	x27, x28, [sp, #80]
    1818:	a9406053 	ldp	x19, x24, [x2]
    181c:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
    1820:	39400320 	ldrb	w0, [x25]
    1824:	35000120 	cbnz	w0, 1848 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
    1828:	2a1503e0 	mov	w0, w21
    182c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1830:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1834:	a94363f7 	ldp	x23, x24, [sp, #48]
    1838:	a9446bf9 	ldp	x25, x26, [sp, #64]
    183c:	a94573fb 	ldp	x27, x28, [sp, #80]
    1840:	a8c67bfd 	ldp	x29, x30, [sp], #96
    1844:	d65f03c0 	ret
    c = fmt[i] & 0xff;
    1848:	2a0003f6 	mov	w22, w0
    if(state == 0){
    184c:	35000101 	cbnz	w1, 186c <vprintf+0x80>
      if(c == '%'){
    1850:	7100941f 	cmp	w0, #0x25
    1854:	54000ba0 	b.eq	19c8 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
    1858:	2a1603e1 	mov	w1, w22
    185c:	2a1703e0 	mov	w0, w23
    1860:	97ffffad 	bl	1714 <putc>
    1864:	0b0002b5 	add	w21, w21, w0
    1868:	14000057 	b	19c4 <vprintf+0x1d8>
      if(c == 'd'){
    186c:	7101901f 	cmp	w0, #0x64
    1870:	540002a1 	b.ne	18c4 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
    1874:	37f80174 	tbnz	w20, #31, 18a0 <vprintf+0xb4>
    1878:	91002e76 	add	x22, x19, #0xb
    187c:	2a1403fa 	mov	w26, w20
    1880:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1884:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    1888:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
    188c:	b9400261 	ldr	w1, [x19]
    1890:	2a1703e0 	mov	w0, w23
    1894:	97ffffaa 	bl	173c <printint>
        written += putc(fd, va_arg(ap, uint));
    1898:	0b0002b5 	add	w21, w21, w0
    189c:	14000048 	b	19bc <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
    18a0:	1100229a 	add	w26, w20, #0x8
    18a4:	7100035f 	cmp	w26, #0x0
    18a8:	5400008d 	b.le	18b8 <vprintf+0xcc>
    18ac:	91002e76 	add	x22, x19, #0xb
    18b0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    18b4:	17fffff4 	b	1884 <vprintf+0x98>
    18b8:	aa1303f6 	mov	x22, x19
    18bc:	8b34c313 	add	x19, x24, w20, sxtw
    18c0:	17fffff1 	b	1884 <vprintf+0x98>
      } else if(c == 'l') {
    18c4:	7101b01f 	cmp	w0, #0x6c
    18c8:	54000201 	b.ne	1908 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    18cc:	37f800d4 	tbnz	w20, #31, 18e4 <vprintf+0xf8>
    18d0:	91003e76 	add	x22, x19, #0xf
    18d4:	2a1403fa 	mov	w26, w20
    18d8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    18dc:	52800003 	mov	w3, #0x0                   	// #0
    18e0:	17ffffea 	b	1888 <vprintf+0x9c>
    18e4:	1100229a 	add	w26, w20, #0x8
    18e8:	7100035f 	cmp	w26, #0x0
    18ec:	5400008d 	b.le	18fc <vprintf+0x110>
    18f0:	91003e76 	add	x22, x19, #0xf
    18f4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    18f8:	17fffff9 	b	18dc <vprintf+0xf0>
    18fc:	aa1303f6 	mov	x22, x19
    1900:	8b34c313 	add	x19, x24, w20, sxtw
    1904:	17fffff6 	b	18dc <vprintf+0xf0>
      } else if(c == 'x') {
    1908:	7101e01f 	cmp	w0, #0x78
    190c:	54000221 	b.ne	1950 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
    1910:	37f800f4 	tbnz	w20, #31, 192c <vprintf+0x140>
    1914:	91002e76 	add	x22, x19, #0xb
    1918:	2a1403fa 	mov	w26, w20
    191c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1920:	52800003 	mov	w3, #0x0                   	// #0
    1924:	52800202 	mov	w2, #0x10                  	// #16
    1928:	17ffffd9 	b	188c <vprintf+0xa0>
    192c:	1100229a 	add	w26, w20, #0x8
    1930:	7100035f 	cmp	w26, #0x0
    1934:	5400008d 	b.le	1944 <vprintf+0x158>
    1938:	91002e76 	add	x22, x19, #0xb
    193c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1940:	17fffff8 	b	1920 <vprintf+0x134>
    1944:	aa1303f6 	mov	x22, x19
    1948:	8b34c313 	add	x19, x24, w20, sxtw
    194c:	17fffff5 	b	1920 <vprintf+0x134>
      } else if(c == 'p') {
    1950:	7101c01f 	cmp	w0, #0x70
    1954:	54000521 	b.ne	19f8 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    1958:	37f803f4 	tbnz	w20, #31, 19d4 <vprintf+0x1e8>
    195c:	91003e76 	add	x22, x19, #0xf
    1960:	2a1403fa 	mov	w26, w20
    1964:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1968:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
    196c:	52800601 	mov	w1, #0x30                  	// #48
    1970:	2a1703e0 	mov	w0, w23
    1974:	97ffff68 	bl	1714 <putc>
    1978:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    197c:	9000001c 	adrp	x28, 1000 <nulterminate+0x7c>
    1980:	913b939c 	add	x28, x28, #0xee4
  written += putc(fd, 'x');
    1984:	2a1703e0 	mov	w0, w23
    1988:	52800f01 	mov	w1, #0x78                  	// #120
    198c:	97ffff62 	bl	1714 <putc>
    1990:	0b000273 	add	w19, w19, w0
    1994:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    1998:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    199c:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    19a0:	38606b81 	ldrb	w1, [x28, x0]
    19a4:	2a1703e0 	mov	w0, w23
    19a8:	97ffff5b 	bl	1714 <putc>
    19ac:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    19b0:	71000694 	subs	w20, w20, #0x1
    19b4:	54ffff21 	b.ne	1998 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    19b8:	0b1302b5 	add	w21, w21, w19
    19bc:	2a1a03f4 	mov	w20, w26
    19c0:	aa1603f3 	mov	x19, x22
      state = 0;
    19c4:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
    19c8:	91000739 	add	x25, x25, #0x1
  state = 0;
    19cc:	2a1603e1 	mov	w1, w22
    19d0:	17ffff94 	b	1820 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
    19d4:	1100229a 	add	w26, w20, #0x8
    19d8:	7100035f 	cmp	w26, #0x0
    19dc:	5400008d 	b.le	19ec <vprintf+0x200>
    19e0:	91003e76 	add	x22, x19, #0xf
    19e4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    19e8:	17ffffe0 	b	1968 <vprintf+0x17c>
    19ec:	aa1303f6 	mov	x22, x19
    19f0:	8b34c313 	add	x19, x24, w20, sxtw
    19f4:	17ffffdd 	b	1968 <vprintf+0x17c>
      } else if(c == 's'){
    19f8:	7101cc1f 	cmp	w0, #0x73
    19fc:	54000381 	b.ne	1a6c <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
    1a00:	37f80214 	tbnz	w20, #31, 1a40 <vprintf+0x254>
    1a04:	91003e61 	add	x1, x19, #0xf
    1a08:	aa1303e0 	mov	x0, x19
    1a0c:	927df033 	and	x19, x1, #0xfffffffffffffff8
    1a10:	f9400016 	ldr	x22, [x0]
          s = "(null)";
    1a14:	90000000 	adrp	x0, 1000 <nulterminate+0x7c>
    1a18:	913b7400 	add	x0, x0, #0xedd
    1a1c:	f10002df 	cmp	x22, #0x0
    1a20:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
    1a24:	394002c1 	ldrb	w1, [x22]
    1a28:	34fffce1 	cbz	w1, 19c4 <vprintf+0x1d8>
          written += putc(fd, *s);
    1a2c:	2a1703e0 	mov	w0, w23
          s++;
    1a30:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
    1a34:	97ffff38 	bl	1714 <putc>
    1a38:	0b0002b5 	add	w21, w21, w0
          s++;
    1a3c:	17fffffa 	b	1a24 <vprintf+0x238>
        s = va_arg(ap, char*);
    1a40:	11002281 	add	w1, w20, #0x8
    1a44:	7100003f 	cmp	w1, #0x0
    1a48:	540000cd 	b.le	1a60 <vprintf+0x274>
    1a4c:	91003e62 	add	x2, x19, #0xf
    1a50:	aa1303e0 	mov	x0, x19
    1a54:	2a0103f4 	mov	w20, w1
    1a58:	927df053 	and	x19, x2, #0xfffffffffffffff8
    1a5c:	17ffffed 	b	1a10 <vprintf+0x224>
    1a60:	8b34c300 	add	x0, x24, w20, sxtw
    1a64:	2a0103f4 	mov	w20, w1
    1a68:	17ffffea 	b	1a10 <vprintf+0x224>
      } else if(c == 'c'){
    1a6c:	71018c1f 	cmp	w0, #0x63
    1a70:	54000241 	b.ne	1ab8 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
    1a74:	37f80114 	tbnz	w20, #31, 1a94 <vprintf+0x2a8>
    1a78:	91002e76 	add	x22, x19, #0xb
    1a7c:	2a1403fa 	mov	w26, w20
    1a80:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1a84:	39400261 	ldrb	w1, [x19]
    1a88:	2a1703e0 	mov	w0, w23
    1a8c:	97ffff22 	bl	1714 <putc>
    1a90:	17ffff82 	b	1898 <vprintf+0xac>
    1a94:	1100229a 	add	w26, w20, #0x8
    1a98:	7100035f 	cmp	w26, #0x0
    1a9c:	5400008d 	b.le	1aac <vprintf+0x2c0>
    1aa0:	91002e76 	add	x22, x19, #0xb
    1aa4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1aa8:	17fffff7 	b	1a84 <vprintf+0x298>
    1aac:	aa1303f6 	mov	x22, x19
    1ab0:	8b34c313 	add	x19, x24, w20, sxtw
    1ab4:	17fffff4 	b	1a84 <vprintf+0x298>
      } else if(c == '%'){
    1ab8:	7100941f 	cmp	w0, #0x25
    1abc:	54ffece0 	b.eq	1858 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
    1ac0:	2a1703e0 	mov	w0, w23
    1ac4:	528004a1 	mov	w1, #0x25                  	// #37
    1ac8:	97ffff13 	bl	1714 <putc>
    1acc:	0b0002b5 	add	w21, w21, w0
    1ad0:	17ffff62 	b	1858 <vprintf+0x6c>

0000000000001ad4 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
    1ad4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    1ad8:	910003fd 	mov	x29, sp
    1adc:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
    1ae0:	910203e2 	add	x2, sp, #0x80
    1ae4:	a9030be2 	stp	x2, x2, [sp, #48]
    1ae8:	910143e2 	add	x2, sp, #0x50
    1aec:	f90023e2 	str	x2, [sp, #64]
    1af0:	128005e2 	mov	w2, #0xffffffd0            	// #-48
    1af4:	b9004be2 	str	w2, [sp, #72]
    1af8:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
    1afc:	a9430fe2 	ldp	x2, x3, [sp, #48]
    1b00:	a9010fe2 	stp	x2, x3, [sp, #16]
    1b04:	a9440fe2 	ldp	x2, x3, [sp, #64]
    1b08:	a9020fe2 	stp	x2, x3, [sp, #32]
    1b0c:	910043e2 	add	x2, sp, #0x10
{
    1b10:	a90617e4 	stp	x4, x5, [sp, #96]
    1b14:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
    1b18:	97ffff35 	bl	17ec <vprintf>
  va_end(ap);
  return result;
}
    1b1c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    1b20:	d65f03c0 	ret

0000000000001b24 <printf>:

int
printf(const char *fmt, ...)
{
    1b24:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    1b28:	910003fd 	mov	x29, sp
    1b2c:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
    1b30:	910243e1 	add	x1, sp, #0x90
    1b34:	a90307e1 	stp	x1, x1, [sp, #48]
    1b38:	910143e1 	add	x1, sp, #0x50
    1b3c:	f90023e1 	str	x1, [sp, #64]
    1b40:	128006e1 	mov	w1, #0xffffffc8            	// #-56
    1b44:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
    1b48:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
    1b4c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
    1b50:	52800020 	mov	w0, #0x1                   	// #1
{
    1b54:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
    1b58:	a9430fe2 	ldp	x2, x3, [sp, #48]
    1b5c:	a9010fe2 	stp	x2, x3, [sp, #16]
    1b60:	a9440fe2 	ldp	x2, x3, [sp, #64]
    1b64:	a9020fe2 	stp	x2, x3, [sp, #32]
    1b68:	910043e2 	add	x2, sp, #0x10
{
    1b6c:	a9079be5 	stp	x5, x6, [sp, #120]
    1b70:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
    1b74:	97ffff1e 	bl	17ec <vprintf>
  va_end(ap);
  return result;
}
    1b78:	a8c97bfd 	ldp	x29, x30, [sp], #144
    1b7c:	d65f03c0 	ret

0000000000001b80 <free_locked>:
free_locked(void *ap)
{
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1b80:	b0000005 	adrp	x5, 2000 <buf.0+0x18>
    1b84:	f94028a2 	ldr	x2, [x5, #80]
  bp = (Header*)ap - 1;
    1b88:	d1004003 	sub	x3, x0, #0x10
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1b8c:	f9400041 	ldr	x1, [x2]
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1b90:	eb03005f 	cmp	x2, x3
    1b94:	54000342 	b.cs	1bfc <free_locked+0x7c>  // b.hs, b.nlast
    1b98:	eb01007f 	cmp	x3, x1
    1b9c:	540002a2 	b.cs	1bf0 <free_locked+0x70>  // b.hs, b.nlast
      break;
  if(bp + bp->s.size == p->s.ptr){
    1ba0:	b85f8006 	ldur	w6, [x0, #-8]
    1ba4:	8b265064 	add	x4, x3, w6, uxtw #4
    1ba8:	eb04003f 	cmp	x1, x4
    1bac:	540000a1 	b.ne	1bc0 <free_locked+0x40>  // b.any
    bp->s.size += p->s.ptr->s.size;
    1bb0:	b9400824 	ldr	w4, [x1, #8]
    bp->s.ptr = p->s.ptr->s.ptr;
    1bb4:	f9400021 	ldr	x1, [x1]
    bp->s.size += p->s.ptr->s.size;
    1bb8:	0b060084 	add	w4, w4, w6
    1bbc:	b81f8004 	stur	w4, [x0, #-8]
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    1bc0:	b9400844 	ldr	w4, [x2, #8]
    1bc4:	f81f0001 	stur	x1, [x0, #-16]
    1bc8:	8b245046 	add	x6, x2, w4, uxtw #4
    1bcc:	eb06007f 	cmp	x3, x6
    1bd0:	540000a1 	b.ne	1be4 <free_locked+0x64>  // b.any
    p->s.size += bp->s.size;
    1bd4:	b85f8000 	ldur	w0, [x0, #-8]
    p->s.ptr = bp->s.ptr;
    1bd8:	aa0103e3 	mov	x3, x1
    p->s.size += bp->s.size;
    1bdc:	0b040000 	add	w0, w0, w4
    1be0:	b9000840 	str	w0, [x2, #8]
  } else
    p->s.ptr = bp;
  freep = p;
    1be4:	f90028a2 	str	x2, [x5, #80]
    1be8:	f9000043 	str	x3, [x2]
}
    1bec:	d65f03c0 	ret
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1bf0:	eb01005f 	cmp	x2, x1
    1bf4:	540000c3 	b.cc	1c0c <free_locked+0x8c>  // b.lo, b.ul, b.last
    1bf8:	17ffffea 	b	1ba0 <free_locked+0x20>
    1bfc:	eb01005f 	cmp	x2, x1
    1c00:	54000063 	b.cc	1c0c <free_locked+0x8c>  // b.lo, b.ul, b.last
    1c04:	eb01007f 	cmp	x3, x1
    1c08:	54fffcc3 	b.cc	1ba0 <free_locked+0x20>  // b.lo, b.ul, b.last
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1c0c:	aa0103e2 	mov	x2, x1
    1c10:	17ffffdf 	b	1b8c <free_locked+0xc>

0000000000001c14 <heap_acquire>:
{
    1c14:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1c18:	910003fd 	mov	x29, sp
    1c1c:	a90153f3 	stp	x19, x20, [sp, #16]
    asm volatile("ldaxr %w0, [%1]"
    1c20:	b0000013 	adrp	x19, 2000 <buf.0+0x18>
    1c24:	91014273 	add	x19, x19, #0x50
    1c28:	91002273 	add	x19, x19, #0x8
      asm volatile("stxr %w0, %w1, [%2]"
    1c2c:	52800034 	mov	w20, #0x1                   	// #1
    asm volatile("ldaxr %w0, [%1]"
    1c30:	885ffe60 	ldaxr	w0, [x19]
    if(old == 0){
    1c34:	350000c0 	cbnz	w0, 1c4c <heap_acquire+0x38>
      asm volatile("stxr %w0, %w1, [%2]"
    1c38:	88007e74 	stxr	w0, w20, [x19]
      if(failed == 0)
    1c3c:	350000a0 	cbnz	w0, 1c50 <heap_acquire+0x3c>
}
    1c40:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c44:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1c48:	d65f03c0 	ret
      asm volatile("clrex" ::: "memory");
    1c4c:	d5033f5f 	clrex
    sched_yield();
    1c50:	97fffe90 	bl	1690 <sched_yield>
  for(;;){
    1c54:	17fffff7 	b	1c30 <heap_acquire+0x1c>

0000000000001c58 <free>:

void
free(void *ap)
{
  if(ap == 0)
    1c58:	b40001c0 	cbz	x0, 1c90 <free+0x38>
{
    1c5c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1c60:	910003fd 	mov	x29, sp
    1c64:	f9000fe0 	str	x0, [sp, #24]
    return;
  heap_acquire();
    1c68:	97ffffeb 	bl	1c14 <heap_acquire>
  free_locked(ap);
    1c6c:	f9400fe0 	ldr	x0, [sp, #24]
    1c70:	97ffffc4 	bl	1b80 <free_locked>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    1c74:	b0000000 	adrp	x0, 2000 <buf.0+0x18>
    1c78:	91014000 	add	x0, x0, #0x50
    1c7c:	52800001 	mov	w1, #0x0                   	// #0
    1c80:	91002000 	add	x0, x0, #0x8
    1c84:	889ffc01 	stlr	w1, [x0]
  heap_release();
}
    1c88:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1c8c:	d65f03c0 	ret
    1c90:	d65f03c0 	ret

0000000000001c94 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1c94:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1c98:	910003fd 	mov	x29, sp
    1c9c:	a90153f3 	stp	x19, x20, [sp, #16]
  Header *p, *prevp;
  uint nunits;

  heap_acquire();
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1ca0:	2a0003f3 	mov	w19, w0
    1ca4:	91003e73 	add	x19, x19, #0xf
{
    1ca8:	a9025bf5 	stp	x21, x22, [sp, #32]
  if((prevp = freep) == 0){
    1cac:	b0000016 	adrp	x22, 2000 <buf.0+0x18>
    1cb0:	910142d4 	add	x20, x22, #0x50
{
    1cb4:	f9001bf7 	str	x23, [sp, #48]
  heap_acquire();
    1cb8:	97ffffd7 	bl	1c14 <heap_acquire>
  if((prevp = freep) == 0){
    1cbc:	f9402ac1 	ldr	x1, [x22, #80]
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1cc0:	d344fe73 	lsr	x19, x19, #4
    1cc4:	11000673 	add	w19, w19, #0x1
  if((prevp = freep) == 0){
    1cc8:	b50000a1 	cbnz	x1, 1cdc <malloc+0x48>
    base.s.ptr = freep = prevp = &base;
    1ccc:	91004281 	add	x1, x20, #0x10
    1cd0:	f9002ac1 	str	x1, [x22, #80]
    1cd4:	f9000a81 	str	x1, [x20, #16]
    base.s.size = 0;
    1cd8:	b9001a9f 	str	wzr, [x20, #24]
  if(nu < 4096)
    1cdc:	7140067f 	cmp	w19, #0x1, lsl #12
    1ce0:	52820015 	mov	w21, #0x1000                	// #4096
    1ce4:	1a952275 	csel	w21, w19, w21, cs	// cs = hs, nlast
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1ce8:	f9400020 	ldr	x0, [x1]
  p = sbrk(nu * sizeof(Header));
    1cec:	531c6eb7 	lsl	w23, w21, #4
    if(p->s.size >= nunits){
    1cf0:	b9400802 	ldr	w2, [x0, #8]
    1cf4:	6b13005f 	cmp	w2, w19
    1cf8:	54000263 	b.cc	1d44 <malloc+0xb0>  // b.lo, b.ul, b.last
      if(p->s.size == nunits)
    1cfc:	540001a1 	b.ne	1d30 <malloc+0x9c>  // b.any
        prevp->s.ptr = p->s.ptr;
    1d00:	f9400002 	ldr	x2, [x0]
    1d04:	f9000022 	str	x2, [x1]
      else {
        p->s.size -= nunits;
        p += p->s.size;
        p->s.size = nunits;
      }
      freep = prevp;
    1d08:	f9002ac1 	str	x1, [x22, #80]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    1d0c:	91002294 	add	x20, x20, #0x8
    1d10:	52800001 	mov	w1, #0x0                   	// #0
    1d14:	889ffe81 	stlr	w1, [x20]
      heap_release();
      return (void*)(p + 1);
    1d18:	91004000 	add	x0, x0, #0x10
      if((p = morecore(nunits)) == 0){
        heap_release();
        return 0;
      }
  }
}
    1d1c:	f9401bf7 	ldr	x23, [sp, #48]
    1d20:	a94153f3 	ldp	x19, x20, [sp, #16]
    1d24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1d28:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1d2c:	d65f03c0 	ret
        p->s.size -= nunits;
    1d30:	4b130042 	sub	w2, w2, w19
    1d34:	b9000802 	str	w2, [x0, #8]
        p += p->s.size;
    1d38:	8b225000 	add	x0, x0, w2, uxtw #4
        p->s.size = nunits;
    1d3c:	b9000813 	str	w19, [x0, #8]
    1d40:	17fffff2 	b	1d08 <malloc+0x74>
    if(p == freep)
    1d44:	f9400281 	ldr	x1, [x20]
    1d48:	eb00003f 	cmp	x1, x0
    1d4c:	540001e1 	b.ne	1d88 <malloc+0xf4>  // b.any
  p = sbrk(nu * sizeof(Header));
    1d50:	2a1703e0 	mov	w0, w23
    1d54:	97fffdcb 	bl	1480 <sbrk>
  if(p == (char*)-1)
    1d58:	b100041f 	cmn	x0, #0x1
    1d5c:	540000c1 	b.ne	1d74 <malloc+0xe0>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    1d60:	91002294 	add	x20, x20, #0x8
    1d64:	52800000 	mov	w0, #0x0                   	// #0
    1d68:	889ffe80 	stlr	w0, [x20]
        return 0;
    1d6c:	d2800000 	mov	x0, #0x0                   	// #0
    1d70:	17ffffeb 	b	1d1c <malloc+0x88>
  hp->s.size = nu;
    1d74:	b9000815 	str	w21, [x0, #8]
  free_locked((void*)(hp + 1));
    1d78:	91004000 	add	x0, x0, #0x10
    1d7c:	97ffff81 	bl	1b80 <free_locked>
  return freep;
    1d80:	f9400280 	ldr	x0, [x20]
      if((p = morecore(nunits)) == 0){
    1d84:	b4fffee0 	cbz	x0, 1d60 <malloc+0xcc>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1d88:	aa0003e1 	mov	x1, x0
    1d8c:	f9400000 	ldr	x0, [x0]
    if(p->s.size >= nunits){
    1d90:	17ffffd8 	b	1cf0 <malloc+0x5c>
