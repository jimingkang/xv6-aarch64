
user/_ping:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
         (ip >> 8) & 255, ip & 255);
}

int
main(int argc, char **argv)
{
   0:	d10dc3ff 	sub	sp, sp, #0x370
   4:	a9007bfd 	stp	x29, x30, [sp]
   8:	910003fd 	mov	x29, sp
   c:	a90153f3 	stp	x19, x20, [sp, #16]
  10:	a9025bf5 	stp	x21, x22, [sp, #32]
  14:	a90363f7 	stp	x23, x24, [sp, #48]
  18:	a9046bf9 	stp	x25, x26, [sp, #64]
  1c:	f9002bfb 	str	x27, [sp, #80]
  uchar tx[32], rx[64];
  uint32 dst, src;
  uint16 rseq;
  int id, seq, n, before, after;

  if(argc != 2){
  20:	7100081f 	cmp	w0, #0x2
  24:	540000c0 	b.eq	3c <main+0x3c>  // b.none
    fprintf(2, "usage: ping host\n");
  28:	90000001 	adrp	x1, 0 <main>
  2c:	913e1021 	add	x1, x1, #0xf84
    for(n = 0; n < (int)sizeof(tx); n++)
      tx[n] = n + seq;
    before = uptime();
    if(icmp_send(dst, id, seq, tx, sizeof(tx)) < 0 ||
       (n = icmp_recv(id, &src, &rseq, rx, sizeof(rx))) < 0){
      fprintf(2, "ping: send/receive failed\n");
  30:	52800040 	mov	w0, #0x2                   	// #2
  34:	940003a6 	bl	ecc <fprintf>
      exit(1);
  38:	14000064 	b	1c8 <main+0x1c8>
  if(parse_ip(argv[1], &dst) < 0 && resolve(argv[1], &dst) < 0){
  3c:	f9400436 	ldr	x22, [x1, #8]
  40:	aa0103f5 	mov	x21, x1
  int part = 0, dots = 0, digit = 0;
  44:	52800004 	mov	w4, #0x0                   	// #0
  48:	52800002 	mov	w2, #0x0                   	// #0
  if(parse_ip(argv[1], &dst) < 0 && resolve(argv[1], &dst) < 0){
  4c:	aa1603e3 	mov	x3, x22
  int part = 0, dots = 0, digit = 0;
  50:	52800000 	mov	w0, #0x0                   	// #0
  uint32 v = 0;
  54:	52800013 	mov	w19, #0x0                   	// #0
      part = part * 10 + *s - '0';
  58:	52800146 	mov	w6, #0xa                   	// #10
    if(*s >= '0' && *s <= '9'){
  5c:	39400061 	ldrb	w1, [x3]
  60:	5100c025 	sub	w5, w1, #0x30
  64:	12001ca5 	and	w5, w5, #0xff
  68:	710024bf 	cmp	w5, #0x9
  6c:	54000108 	b.hi	8c <main+0x8c>  // b.pmore
      part = part * 10 + *s - '0';
  70:	1b060400 	madd	w0, w0, w6, w1
  74:	5100c000 	sub	w0, w0, #0x30
      if(part > 255)
  78:	7103fc1f 	cmp	w0, #0xff
  7c:	5400020c 	b.gt	bc <main+0xbc>
      digit = 1;
  80:	52800024 	mov	w4, #0x1                   	// #1
  for(;; s++){
  84:	91000463 	add	x3, x3, #0x1
    if(*s >= '0' && *s <= '9'){
  88:	17fffff5 	b	5c <main+0x5c>
    } else if(*s == '.' || *s == 0){
  8c:	7100b83f 	cmp	w1, #0x2e
  90:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
  94:	54000141 	b.ne	bc <main+0xbc>  // b.any
      if(!digit)
  98:	34000124 	cbz	w4, bc <main+0xbc>
      v = (v << 8) | part;
  9c:	2a132013 	orr	w19, w0, w19, lsl #8
      if(*s == 0)
  a0:	340000a1 	cbz	w1, b4 <main+0xb4>
      dots++;
  a4:	11000442 	add	w2, w2, #0x1
      part = digit = 0;
  a8:	52800004 	mov	w4, #0x0                   	// #0
  ac:	52800000 	mov	w0, #0x0                   	// #0
  b0:	17fffff5 	b	84 <main+0x84>
  if(dots != 3)
  b4:	71000c5f 	cmp	w2, #0x3
  b8:	540012e0 	b.eq	314 <main+0x314>  // b.none
  memset(query, 0, sizeof(query));
  bc:	9101c3f3 	add	x19, sp, #0x70
  c0:	52802002 	mov	w2, #0x100                 	// #256
  c4:	aa1303e0 	mov	x0, x19
  c8:	52800001 	mov	w1, #0x0                   	// #0
  cc:	9400013f 	bl	5c8 <memset>
  int q = 12, start, n, off, answers, rdlen;
  d0:	52800194 	mov	w20, #0xc                   	// #12
  query[0] = 0x51;
  d4:	528e2a20 	mov	w0, #0x7151                	// #29009
  d8:	7900e3e0 	strh	w0, [sp, #112]
  query[2] = 0x01;
  dc:	52800020 	mov	w0, #0x1                   	// #1
  e0:	3901cbe0 	strb	w0, [sp, #114]
  query[5] = 0x01;
  e4:	3901d7e0 	strb	w0, [sp, #117]
  while(*p){
  e8:	394002c0 	ldrb	w0, [x22]
    start = q++;
  ec:	11000682 	add	w2, w20, #0x1
  f0:	93407e84 	sxtw	x4, w20
  f4:	93407c41 	sxtw	x1, w2
  while(*p){
  f8:	34000300 	cbz	w0, 158 <main+0x158>
  fc:	52800000 	mov	w0, #0x0                   	// #0
 100:	1400000c 	b	130 <main+0x130>
      if(q >= (int)sizeof(query) - 5 || query[start] == 63)
 104:	7103e85f 	cmp	w2, #0xfa
 108:	5400056c 	b.gt	1b4 <main+0x1b4>
 10c:	7100fc1f 	cmp	w0, #0x3f
 110:	54000520 	b.eq	1b4 <main+0x1b4>  // b.none
      query[q++] = *p++;
 114:	38216a63 	strb	w3, [x19, x1]
 118:	910006d6 	add	x22, x22, #0x1
 11c:	11000442 	add	w2, w2, #0x1
      query[start]++;
 120:	91000421 	add	x1, x1, #0x1
 124:	38646a60 	ldrb	w0, [x19, x4]
 128:	11000400 	add	w0, w0, #0x1
 12c:	12001c00 	and	w0, w0, #0xff
    query[start] = 0;
 130:	38246a60 	strb	w0, [x19, x4]
    while(*p && *p != '.'){
 134:	394002c3 	ldrb	w3, [x22]
 138:	7100b87f 	cmp	w3, #0x2e
 13c:	7a401864 	ccmp	w3, #0x0, #0x4, ne	// ne = any
 140:	54fffe21 	b.ne	104 <main+0x104>  // b.any
      p++;
 144:	7100b87f 	cmp	w3, #0x2e
 148:	9a9616d6 	cinc	x22, x22, eq	// eq = none
    if(query[start] == 0)
 14c:	34000340 	cbz	w0, 1b4 <main+0x1b4>
 150:	2a0203f4 	mov	w20, w2
 154:	17ffffe5 	b	e8 <main+0xe8>
  query[q++] = 0;
 158:	11000a80 	add	w0, w20, #0x2
  query[q++] = 0;
 15c:	38246a7f 	strb	wzr, [x19, x4]
  query[q++] = 0;
 160:	38216a7f 	strb	wzr, [x19, x1]
  query[q++] = 1; // A
 164:	52800021 	mov	w1, #0x1                   	// #1
 168:	3820ca61 	strb	w1, [x19, w0, sxtw]
 16c:	11000e80 	add	w0, w20, #0x3
  query[q++] = 0;
 170:	3820ca7f 	strb	wzr, [x19, w0, sxtw]
 174:	11001280 	add	w0, w20, #0x4
  query[q++] = 1; // IN
 178:	3820ca61 	strb	w1, [x19, w0, sxtw]
  if(udp_bind(DNS_PORT) < 0)
 17c:	5299e120 	mov	w0, #0xcf09                	// #53001
 180:	940001e2 	bl	908 <udp_bind>
 184:	37f80180 	tbnz	w0, #31, 1b4 <main+0x1b4>
  if(udp_send(QEMU_DNS, DNS_PORT, 53, query, q) < 0){
 188:	52804076 	mov	w22, #0x203                 	// #515
 18c:	72a14016 	movk	w22, #0xa00, lsl #16
 190:	11001684 	add	w4, w20, #0x5
 194:	aa1303e3 	mov	x3, x19
 198:	2a1603e0 	mov	w0, w22
 19c:	528006a2 	mov	w2, #0x35                  	// #53
 1a0:	5299e121 	mov	w1, #0xcf09                	// #53001
 1a4:	940001df 	bl	920 <udp_send>
 1a8:	36f80140 	tbz	w0, #31, 1d0 <main+0x1d0>
    udp_unbind(DNS_PORT);
 1ac:	5299e120 	mov	w0, #0xcf09                	// #53001
 1b0:	940001d9 	bl	914 <udp_unbind>
    fprintf(2, "ping: cannot resolve %s\n", argv[1]);
 1b4:	f94006a2 	ldr	x2, [x21, #8]
 1b8:	90000001 	adrp	x1, 0 <main>
 1bc:	913e5821 	add	x1, x1, #0xf96
 1c0:	52800040 	mov	w0, #0x2                   	// #2
 1c4:	94000342 	bl	ecc <fprintf>
    exit(1);
 1c8:	52800020 	mov	w0, #0x1                   	// #1
 1cc:	94000178 	bl	7ac <exit>
  sleep_ticks(5);
 1d0:	528000a0 	mov	w0, #0x5                   	// #5
 1d4:	940001ac 	bl	884 <sleep_ticks>
  if(udp_send(QEMU_DNS, DNS_PORT, 53, query, q) < 0){
 1d8:	11001684 	add	w4, w20, #0x5
 1dc:	aa1303e3 	mov	x3, x19
 1e0:	2a1603e0 	mov	w0, w22
 1e4:	528006a2 	mov	w2, #0x35                  	// #53
 1e8:	5299e121 	mov	w1, #0xcf09                	// #53001
 1ec:	940001cd 	bl	920 <udp_send>
 1f0:	37fffde0 	tbnz	w0, #31, 1ac <main+0x1ac>
  n = udp_recv(DNS_PORT, &src, &sport, reply, sizeof(reply));
 1f4:	9105c3f3 	add	x19, sp, #0x170
 1f8:	9101abe2 	add	x2, sp, #0x6a
 1fc:	aa1303e3 	mov	x3, x19
 200:	9101b3e1 	add	x1, sp, #0x6c
 204:	52804004 	mov	w4, #0x200                 	// #512
 208:	5299e120 	mov	w0, #0xcf09                	// #53001
 20c:	940001c8 	bl	92c <udp_recv>
 210:	2a0003f4 	mov	w20, w0
  udp_unbind(DNS_PORT);
 214:	5299e120 	mov	w0, #0xcf09                	// #53001
 218:	940001bf 	bl	914 <udp_unbind>
  if(n < 12 || src != QEMU_DNS || sport != 53 ||
 21c:	71002e9f 	cmp	w20, #0xb
 220:	54fffcad 	b.le	1b4 <main+0x1b4>
 224:	b9406fe0 	ldr	w0, [sp, #108]
 228:	6b16001f 	cmp	w0, w22
 22c:	54fffc41 	b.ne	1b4 <main+0x1b4>  // b.any
 230:	7940d7e0 	ldrh	w0, [sp, #106]
 234:	7100d41f 	cmp	w0, #0x35
 238:	54fffbe1 	b.ne	1b4 <main+0x1b4>  // b.any
 23c:	3945c3e0 	ldrb	w0, [sp, #368]
 240:	7101441f 	cmp	w0, #0x51
 244:	54fffb81 	b.ne	1b4 <main+0x1b4>  // b.any
     reply[0] != 0x51 || reply[1] != 0x71 || (reply[3] & 15) != 0)
 248:	3945c7e0 	ldrb	w0, [sp, #369]
 24c:	7101c41f 	cmp	w0, #0x71
 250:	54fffb21 	b.ne	1b4 <main+0x1b4>  // b.any
 254:	3945cfe0 	ldrb	w0, [sp, #371]
 258:	f2400c1f 	tst	x0, #0xf
 25c:	54fffac1 	b.ne	1b4 <main+0x1b4>  // b.any
  off = skip_name(reply, n, 12);
 260:	2a1403e1 	mov	w1, w20
 264:	aa1303e0 	mov	x0, x19
 268:	52800182 	mov	w2, #0xc                   	// #12
 26c:	9400006e 	bl	424 <skip_name>
  if(off < 0 || off + 4 > n)
 270:	37fffa20 	tbnz	w0, #31, 1b4 <main+0x1b4>
 274:	11000c01 	add	w1, w0, #0x3
 278:	6b01029f 	cmp	w20, w1
 27c:	54fff9cd 	b.le	1b4 <main+0x1b4>
 280:	7942efe6 	ldrh	w6, [sp, #374]
  off += 4;
 284:	11001002 	add	w2, w0, #0x4
 288:	5ac004c6 	rev16	w6, w6
 28c:	12003cc6 	and	w6, w6, #0xffff
  while(answers-- > 0){
 290:	34fff926 	cbz	w6, 1b4 <main+0x1b4>
    off = skip_name(reply, n, off);
 294:	2a1403e1 	mov	w1, w20
 298:	aa1303e0 	mov	x0, x19
 29c:	94000062 	bl	424 <skip_name>
    if(off < 0 || off + 10 > n)
 2a0:	37fff8a0 	tbnz	w0, #31, 1b4 <main+0x1b4>
 2a4:	11002401 	add	w1, w0, #0x9
 2a8:	6b01029f 	cmp	w20, w1
 2ac:	54fff84d 	b.le	1b4 <main+0x1b4>
    rdlen = ((int)reply[off + 8] << 8) | reply[off + 9];
 2b0:	11002002 	add	w2, w0, #0x8
 2b4:	38614a61 	ldrb	w1, [x19, w1, uxtw]
 2b8:	38626a64 	ldrb	w4, [x19, x2]
 2bc:	2a042024 	orr	w4, w1, w4, lsl #8
    if(off + 10 + rdlen > n)
 2c0:	11002801 	add	w1, w0, #0xa
 2c4:	0b010082 	add	w2, w4, w1
 2c8:	6b02029f 	cmp	w20, w2
 2cc:	54fff74b 	b.lt	1b4 <main+0x1b4>  // b.tstop
    if(reply[off] == 0 && reply[off + 1] == 1 &&
 2d0:	38604a62 	ldrb	w2, [x19, w0, uxtw]
 2d4:	35000782 	cbnz	w2, 3c4 <main+0x3c4>
 2d8:	11000402 	add	w2, w0, #0x1
 2dc:	38626a62 	ldrb	w2, [x19, x2]
 2e0:	7100045f 	cmp	w2, #0x1
 2e4:	54000701 	b.ne	3c4 <main+0x3c4>  // b.any
       reply[off + 2] == 0 && reply[off + 3] == 1 && rdlen == 4){
 2e8:	11000802 	add	w2, w0, #0x2
    if(reply[off] == 0 && reply[off + 1] == 1 &&
 2ec:	38626a62 	ldrb	w2, [x19, x2]
 2f0:	350006a2 	cbnz	w2, 3c4 <main+0x3c4>
       reply[off + 2] == 0 && reply[off + 3] == 1 && rdlen == 4){
 2f4:	11000c02 	add	w2, w0, #0x3
 2f8:	38626a62 	ldrb	w2, [x19, x2]
 2fc:	7100045f 	cmp	w2, #0x1
 300:	54000621 	b.ne	3c4 <main+0x3c4>  // b.any
 304:	7100109f 	cmp	w4, #0x4
 308:	540005e1 	b.ne	3c4 <main+0x3c4>  // b.any
      *ip = ((uint32)a[0] << 24) | ((uint32)a[1] << 16) |
 30c:	b8614a73 	ldr	w19, [x19, w1, uxtw]
 310:	5ac00a73 	rev	w19, w19
  printf("PING %s (", argv[1]);
 314:	f94006a1 	ldr	x1, [x21, #8]
 318:	90000000 	adrp	x0, 0 <main>
 31c:	913ebc00 	add	x0, x0, #0xfaf
    }
    after = uptime();
    printf("%d bytes from ", n);
 320:	90000017 	adrp	x23, 0 <main>
 324:	913f9af7 	add	x23, x23, #0xfe6
    print_ip(src);
    printf(": icmp_seq=%d time=%d ms\n", rseq, (after - before) * 100);
 328:	90000018 	adrp	x24, 0 <main>
 32c:	913fd718 	add	x24, x24, #0xff5
  printf("PING %s (", argv[1]);
 330:	940002fb 	bl	f1c <printf>
  print_ip(dst);
 334:	2a1303e0 	mov	w0, w19
 338:	94000050 	bl	478 <print_ip>
  printf("): %d data bytes\n", (int)sizeof(tx));
 33c:	52800401 	mov	w1, #0x20                  	// #32
 340:	90000000 	adrp	x0, 0 <main>
 344:	913ee400 	add	x0, x0, #0xfb9
 348:	940002f5 	bl	f1c <printf>
  id = getpid() & 0xffff;
 34c:	94000148 	bl	86c <getpid>
      tx[n] = n + seq;
 350:	9101c3f9 	add	x25, sp, #0x70
  id = getpid() & 0xffff;
 354:	12003c16 	and	w22, w0, #0xffff
  for(seq = 1; seq <= 4; seq++){
 358:	52800035 	mov	w21, #0x1                   	// #1
    if(query[start] == 0)
 35c:	d2800014 	mov	x20, #0x0                   	// #0
      tx[n] = n + seq;
 360:	0b1402a0 	add	w0, w21, w20
 364:	38396a80 	strb	w0, [x20, x25]
    for(n = 0; n < (int)sizeof(tx); n++)
 368:	91000694 	add	x20, x20, #0x1
 36c:	f100829f 	cmp	x20, #0x20
 370:	54ffff81 	b.ne	360 <main+0x360>  // b.any
    before = uptime();
 374:	94000147 	bl	890 <uptime>
 378:	2a0003fb 	mov	w27, w0
    if(icmp_send(dst, id, seq, tx, sizeof(tx)) < 0 ||
 37c:	2a1403e4 	mov	w4, w20
 380:	aa1903e3 	mov	x3, x25
 384:	2a1503e2 	mov	w2, w21
 388:	2a1603e1 	mov	w1, w22
 38c:	2a1303e0 	mov	w0, w19
 390:	94000170 	bl	950 <icmp_send>
 394:	37f80120 	tbnz	w0, #31, 3b8 <main+0x3b8>
       (n = icmp_recv(id, &src, &rseq, rx, sizeof(rx))) < 0){
 398:	9105c3e3 	add	x3, sp, #0x170
 39c:	9101abe2 	add	x2, sp, #0x6a
 3a0:	9101b3e1 	add	x1, sp, #0x6c
 3a4:	2a1603e0 	mov	w0, w22
 3a8:	52800804 	mov	w4, #0x40                  	// #64
 3ac:	9400016c 	bl	95c <icmp_recv>
 3b0:	2a0003fa 	mov	w26, w0
    if(icmp_send(dst, id, seq, tx, sizeof(tx)) < 0 ||
 3b4:	36f80100 	tbz	w0, #31, 3d4 <main+0x3d4>
      fprintf(2, "ping: send/receive failed\n");
 3b8:	90000001 	adrp	x1, 0 <main>
 3bc:	913f2c21 	add	x1, x1, #0xfcb
 3c0:	17ffff1c 	b	30 <main+0x30>
    off += 10 + rdlen;
 3c4:	11002882 	add	w2, w4, #0xa
  while(answers-- > 0){
 3c8:	510004c6 	sub	w6, w6, #0x1
    off += 10 + rdlen;
 3cc:	0b000042 	add	w2, w2, w0
 3d0:	17ffffb0 	b	290 <main+0x290>
    after = uptime();
 3d4:	9400012f 	bl	890 <uptime>
    printf(": icmp_seq=%d time=%d ms\n", rseq, (after - before) * 100);
 3d8:	4b1b0014 	sub	w20, w0, w27
    printf("%d bytes from ", n);
 3dc:	2a1a03e1 	mov	w1, w26
 3e0:	aa1703e0 	mov	x0, x23
 3e4:	940002ce 	bl	f1c <printf>
    print_ip(src);
 3e8:	b9406fe0 	ldr	w0, [sp, #108]
 3ec:	94000023 	bl	478 <print_ip>
    printf(": icmp_seq=%d time=%d ms\n", rseq, (after - before) * 100);
 3f0:	52800c82 	mov	w2, #0x64                  	// #100
 3f4:	7940d7e1 	ldrh	w1, [sp, #106]
 3f8:	aa1803e0 	mov	x0, x24
 3fc:	1b027e82 	mul	w2, w20, w2
 400:	940002c7 	bl	f1c <printf>
    if(seq != 4)
 404:	710012bf 	cmp	w21, #0x4
 408:	54000061 	b.ne	414 <main+0x414>  // b.any
      sleep_ticks(10);
  }
  exit(0);
 40c:	52800000 	mov	w0, #0x0                   	// #0
 410:	17ffff6f 	b	1cc <main+0x1cc>
      sleep_ticks(10);
 414:	52800140 	mov	w0, #0xa                   	// #10
  for(seq = 1; seq <= 4; seq++){
 418:	110006b5 	add	w21, w21, #0x1
      sleep_ticks(10);
 41c:	9400011a 	bl	884 <sleep_ticks>
  for(seq = 1; seq <= 4; seq++){
 420:	17ffffcf 	b	35c <main+0x35c>

0000000000000424 <skip_name>:
{
 424:	aa0003e4 	mov	x4, x0
  while(off < len){
 428:	6b01005f 	cmp	w2, w1
 42c:	5400010a 	b.ge	44c <skip_name+0x28>  // b.tcont
    int n = msg[off++];
 430:	3862c883 	ldrb	w3, [x4, w2, sxtw]
 434:	11000440 	add	w0, w2, #0x1
    if((n & 0xc0) == 0xc0)
 438:	121a0465 	and	w5, w3, #0xc0
 43c:	710300bf 	cmp	w5, #0xc0
 440:	540000e1 	b.ne	45c <skip_name+0x38>  // b.any
      return off < len ? off + 1 : -1;
 444:	6b00003f 	cmp	w1, w0
 448:	5400006c 	b.gt	454 <skip_name+0x30>
 44c:	12800000 	mov	w0, #0xffffffff            	// #-1
}
 450:	d65f03c0 	ret
      return off < len ? off + 1 : -1;
 454:	11000840 	add	w0, w2, #0x2
 458:	17fffffe 	b	450 <skip_name+0x2c>
    if(n == 0)
 45c:	34ffffa3 	cbz	w3, 450 <skip_name+0x2c>
    if(n > 63 || off + n > len)
 460:	7100fc7f 	cmp	w3, #0x3f
 464:	54ffff4c 	b.gt	44c <skip_name+0x28>
 468:	0b030002 	add	w2, w0, w3
 46c:	6b01005f 	cmp	w2, w1
 470:	54fffdcd 	b.le	428 <skip_name+0x4>
 474:	17fffff6 	b	44c <skip_name+0x28>

0000000000000478 <print_ip>:
{
 478:	2a0003e1 	mov	w1, w0
  printf("%d.%d.%d.%d", (ip >> 24) & 255, (ip >> 16) & 255,
 47c:	90000000 	adrp	x0, 0 <main>
 480:	913de000 	add	x0, x0, #0xf78
 484:	12001c24 	and	w4, w1, #0xff
 488:	d3483c23 	ubfx	x3, x1, #8, #8
 48c:	d3505c22 	ubfx	x2, x1, #16, #8
 490:	53187c21 	lsr	w1, w1, #24
 494:	140002a2 	b	f1c <printf>

0000000000000498 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 498:	d2800002 	mov	x2, #0x0                   	// #0
 49c:	38626823 	ldrb	w3, [x1, x2]
 4a0:	38226803 	strb	w3, [x0, x2]
 4a4:	91000442 	add	x2, x2, #0x1
 4a8:	35ffffa3 	cbnz	w3, 49c <strcpy+0x4>
    ;
  return os;
}
 4ac:	d65f03c0 	ret

00000000000004b0 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 4b0:	d2800003 	mov	x3, #0x0                   	// #0
 4b4:	4b030044 	sub	w4, w2, w3
 4b8:	7100009f 	cmp	w4, #0x0
 4bc:	5400006d 	b.le	4c8 <strncpy+0x18>
 4c0:	38636825 	ldrb	w5, [x1, x3]
 4c4:	350000e5 	cbnz	w5, 4e0 <strncpy+0x30>
 4c8:	8b030003 	add	x3, x0, x3
 4cc:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 4d0:	4b010082 	sub	w2, w4, w1
 4d4:	7100005f 	cmp	w2, #0x0
 4d8:	540000ac 	b.gt	4ec <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 4dc:	d65f03c0 	ret
    *s++ = *t++;
 4e0:	38236805 	strb	w5, [x0, x3]
    n--;
 4e4:	91000463 	add	x3, x3, #0x1
 4e8:	17fffff3 	b	4b4 <strncpy+0x4>
    *s++ = 0;
 4ec:	3821687f 	strb	wzr, [x3, x1]
 4f0:	91000421 	add	x1, x1, #0x1
 4f4:	17fffff7 	b	4d0 <strncpy+0x20>

00000000000004f8 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 4f8:	aa0003e2 	mov	x2, x0
 4fc:	39400043 	ldrb	w3, [x2]
 500:	aa0203e4 	mov	x4, x2
    s++;
 504:	91000442 	add	x2, x2, #0x1
  while(*s)
 508:	35ffffa3 	cbnz	w3, 4fc <strcat+0x4>
 50c:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 510:	38626823 	ldrb	w3, [x1, x2]
 514:	38226883 	strb	w3, [x4, x2]
 518:	91000442 	add	x2, x2, #0x1
 51c:	35ffffa3 	cbnz	w3, 510 <strcat+0x18>
    ;
  return os;
}
 520:	d65f03c0 	ret

0000000000000524 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 524:	d2800002 	mov	x2, #0x0                   	// #0
 528:	38626803 	ldrb	w3, [x0, x2]
 52c:	38626824 	ldrb	w4, [x1, x2]
 530:	34000083 	cbz	w3, 540 <strcmp+0x1c>
 534:	91000442 	add	x2, x2, #0x1
 538:	6b04007f 	cmp	w3, w4
 53c:	54ffff60 	b.eq	528 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 540:	4b040060 	sub	w0, w3, w4
 544:	d65f03c0 	ret

0000000000000548 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 548:	340001c2 	cbz	w2, 580 <strncmp+0x38>
 54c:	39400003 	ldrb	w3, [x0]
 550:	34000083 	cbz	w3, 560 <strncmp+0x18>
 554:	39400024 	ldrb	w4, [x1]
 558:	6b03009f 	cmp	w4, w3
 55c:	540000a0 	b.eq	570 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 560:	39400000 	ldrb	w0, [x0]
 564:	39400021 	ldrb	w1, [x1]
 568:	4b010000 	sub	w0, w0, w1
}
 56c:	d65f03c0 	ret
    n--, p++, q++;
 570:	51000442 	sub	w2, w2, #0x1
 574:	91000400 	add	x0, x0, #0x1
 578:	91000421 	add	x1, x1, #0x1
 57c:	17fffff3 	b	548 <strncmp>
    return 0;
 580:	52800000 	mov	w0, #0x0                   	// #0
 584:	17fffffa 	b	56c <strncmp+0x24>

0000000000000588 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 588:	d1000402 	sub	x2, x0, #0x1
 58c:	d2800001 	mov	x1, #0x0                   	// #0
 590:	aa0103e0 	mov	x0, x1
 594:	91000421 	add	x1, x1, #0x1
 598:	38616843 	ldrb	w3, [x2, x1]
 59c:	35ffffa3 	cbnz	w3, 590 <strlen+0x8>
    ;
  return n;
}
 5a0:	d65f03c0 	ret

00000000000005a4 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 5a4:	d1000403 	sub	x3, x0, #0x1
 5a8:	d2800002 	mov	x2, #0x0                   	// #0
 5ac:	2a0203e0 	mov	w0, w2
 5b0:	6b02003f 	cmp	w1, w2
 5b4:	54000089 	b.ls	5c4 <strnlen+0x20>  // b.plast
 5b8:	91000442 	add	x2, x2, #0x1
 5bc:	38626864 	ldrb	w4, [x3, x2]
 5c0:	35ffff64 	cbnz	w4, 5ac <strnlen+0x8>
    n++;
  return n;
}
 5c4:	d65f03c0 	ret

00000000000005c8 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 5c8:	d2800003 	mov	x3, #0x0                   	// #0
 5cc:	6b03005f 	cmp	w2, w3
 5d0:	54000048 	b.hi	5d8 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 5d4:	d65f03c0 	ret
    cdst[i] = c;
 5d8:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 5dc:	91000463 	add	x3, x3, #0x1
 5e0:	17fffffb 	b	5cc <memset+0x4>

00000000000005e4 <strchr>:

char*
strchr(const char *s, char c)
{
 5e4:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 5e8:	39400002 	ldrb	w2, [x0]
 5ec:	35000062 	cbnz	w2, 5f8 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 5f0:	d2800000 	mov	x0, #0x0                   	// #0
}
 5f4:	d65f03c0 	ret
    if(*s == c)
 5f8:	6b01005f 	cmp	w2, w1
 5fc:	54ffffc0 	b.eq	5f4 <strchr+0x10>  // b.none
  for(; *s; s++)
 600:	91000400 	add	x0, x0, #0x1
 604:	17fffff9 	b	5e8 <strchr+0x4>

0000000000000608 <gets>:

char*
gets(char *buf, int max)
{
 608:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 60c:	910003fd 	mov	x29, sp
 610:	a90153f3 	stp	x19, x20, [sp, #16]
 614:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 618:	d2800014 	mov	x20, #0x0                   	// #0
{
 61c:	f9001bf7 	str	x23, [sp, #48]
 620:	2a0103f7 	mov	w23, w1
 624:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 628:	11000695 	add	w21, w20, #0x1
 62c:	2a1403f6 	mov	w22, w20
 630:	6b1702bf 	cmp	w21, w23
 634:	540000ea 	b.ge	650 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 638:	91013fe1 	add	x1, sp, #0x4f
 63c:	52800022 	mov	w2, #0x1                   	// #1
 640:	52800000 	mov	w0, #0x0                   	// #0
 644:	94000063 	bl	7d0 <read>
    if(cc < 1)
 648:	7100001f 	cmp	w0, #0x0
 64c:	5400012c 	b.gt	670 <gets+0x68>
  for(i=0; i+1 < max; ){
 650:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 654:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 658:	aa1303e0 	mov	x0, x19
 65c:	f9401bf7 	ldr	x23, [sp, #48]
 660:	a94153f3 	ldp	x19, x20, [sp, #16]
 664:	a9425bf5 	ldp	x21, x22, [sp, #32]
 668:	a8c57bfd 	ldp	x29, x30, [sp], #80
 66c:	d65f03c0 	ret
    buf[i++] = c;
 670:	39413fe0 	ldrb	w0, [sp, #79]
 674:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 678:	91000694 	add	x20, x20, #0x1
 67c:	7100281f 	cmp	w0, #0xa
 680:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 684:	54fffd21 	b.ne	628 <gets+0x20>  // b.any
 688:	17fffff3 	b	654 <gets+0x4c>

000000000000068c <stat>:

int
stat(const char *n, struct stat *st)
{
 68c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 690:	910003fd 	mov	x29, sp
 694:	a90153f3 	stp	x19, x20, [sp, #16]
 698:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 69c:	52800001 	mov	w1, #0x0                   	// #0
 6a0:	9400005b 	bl	80c <open>
  if(fd < 0)
 6a4:	37f80160 	tbnz	w0, #31, 6d0 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 6a8:	aa1303e1 	mov	x1, x19
 6ac:	2a0003f4 	mov	w20, w0
 6b0:	94000060 	bl	830 <fstat>
 6b4:	2a0003f3 	mov	w19, w0
  close(fd);
 6b8:	2a1403e0 	mov	w0, w20
 6bc:	9400004b 	bl	7e8 <close>
  return r;
}
 6c0:	2a1303e0 	mov	w0, w19
 6c4:	a94153f3 	ldp	x19, x20, [sp, #16]
 6c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
 6cc:	d65f03c0 	ret
    return -1;
 6d0:	12800013 	mov	w19, #0xffffffff            	// #-1
 6d4:	17fffffb 	b	6c0 <stat+0x34>

00000000000006d8 <atoi>:

int
atoi(const char *s)
{
 6d8:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 6dc:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 6e0:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 6e4:	39400043 	ldrb	w3, [x2]
 6e8:	5100c061 	sub	w1, w3, #0x30
 6ec:	12001c21 	and	w1, w1, #0xff
 6f0:	7100243f 	cmp	w1, #0x9
 6f4:	54000049 	b.ls	6fc <atoi+0x24>  // b.plast
  return n;
}
 6f8:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 6fc:	1b040c01 	madd	w1, w0, w4, w3
 700:	91000442 	add	x2, x2, #0x1
 704:	5100c020 	sub	w0, w1, #0x30
 708:	17fffff7 	b	6e4 <atoi+0xc>

000000000000070c <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 70c:	eb01001f 	cmp	x0, x1
 710:	54000263 	b.cc	75c <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 714:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 718:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 71c:	d2800003 	mov	x3, #0x0                   	// #0
 720:	d1000463 	sub	x3, x3, #0x1
 724:	11000464 	add	w4, w3, #0x1
 728:	0b020084 	add	w4, w4, w2
 72c:	7100009f 	cmp	w4, #0x0
 730:	5400014d 	b.le	758 <memmove+0x4c>
      *--dst = *--src;
 734:	38636824 	ldrb	w4, [x1, x3]
 738:	382368a4 	strb	w4, [x5, x3]
 73c:	17fffff9 	b	720 <memmove+0x14>
      *dst++ = *src++;
 740:	38636824 	ldrb	w4, [x1, x3]
 744:	38236804 	strb	w4, [x0, x3]
 748:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 74c:	4b030044 	sub	w4, w2, w3
 750:	7100009f 	cmp	w4, #0x0
 754:	54ffff6c 	b.gt	740 <memmove+0x34>
  }
  return vdst;
}
 758:	d65f03c0 	ret
 75c:	d2800003 	mov	x3, #0x0                   	// #0
 760:	17fffffb 	b	74c <memmove+0x40>

0000000000000764 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 764:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 768:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 76c:	d2800004 	mov	x4, #0x0                   	// #0
 770:	eb02009f 	cmp	x4, x2
 774:	54000061 	b.ne	780 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 778:	52800000 	mov	w0, #0x0                   	// #0
 77c:	14000007 	b	798 <memcmp+0x34>
    if (*p1 != *p2) {
 780:	38646803 	ldrb	w3, [x0, x4]
 784:	91000484 	add	x4, x4, #0x1
 788:	38646825 	ldrb	w5, [x1, x4]
 78c:	6b05007f 	cmp	w3, w5
 790:	54ffff00 	b.eq	770 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 794:	4b050060 	sub	w0, w3, w5
}
 798:	d65f03c0 	ret

000000000000079c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 79c:	17ffffdc 	b	70c <memmove>

00000000000007a0 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 7a0:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 7a4:	d4000001 	svc	#0x0
 ret
 7a8:	d65f03c0 	ret

00000000000007ac <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 7ac:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 7b0:	d4000001 	svc	#0x0
 ret
 7b4:	d65f03c0 	ret

00000000000007b8 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 7b8:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 7bc:	d4000001 	svc	#0x0
 ret
 7c0:	d65f03c0 	ret

00000000000007c4 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 7c4:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 7c8:	d4000001 	svc	#0x0
 ret
 7cc:	d65f03c0 	ret

00000000000007d0 <read>:
.global read
read:
 mov x7, #SYS_read
 7d0:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 7d4:	d4000001 	svc	#0x0
 ret
 7d8:	d65f03c0 	ret

00000000000007dc <write>:
.global write
write:
 mov x7, #SYS_write
 7dc:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 7e0:	d4000001 	svc	#0x0
 ret
 7e4:	d65f03c0 	ret

00000000000007e8 <close>:
.global close
close:
 mov x7, #SYS_close
 7e8:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 7ec:	d4000001 	svc	#0x0
 ret
 7f0:	d65f03c0 	ret

00000000000007f4 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 7f4:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 7f8:	d4000001 	svc	#0x0
 ret
 7fc:	d65f03c0 	ret

0000000000000800 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 800:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 804:	d4000001 	svc	#0x0
 ret
 808:	d65f03c0 	ret

000000000000080c <open>:
.global open
open:
 mov x7, #SYS_open
 80c:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 810:	d4000001 	svc	#0x0
 ret
 814:	d65f03c0 	ret

0000000000000818 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 818:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 81c:	d4000001 	svc	#0x0
 ret
 820:	d65f03c0 	ret

0000000000000824 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 824:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 828:	d4000001 	svc	#0x0
 ret
 82c:	d65f03c0 	ret

0000000000000830 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 830:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 834:	d4000001 	svc	#0x0
 ret
 838:	d65f03c0 	ret

000000000000083c <link>:
.global link
link:
 mov x7, #SYS_link
 83c:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 840:	d4000001 	svc	#0x0
 ret
 844:	d65f03c0 	ret

0000000000000848 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 848:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 84c:	d4000001 	svc	#0x0
 ret
 850:	d65f03c0 	ret

0000000000000854 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 854:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 858:	d4000001 	svc	#0x0
 ret
 85c:	d65f03c0 	ret

0000000000000860 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 860:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 864:	d4000001 	svc	#0x0
 ret
 868:	d65f03c0 	ret

000000000000086c <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 86c:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 870:	d4000001 	svc	#0x0
 ret
 874:	d65f03c0 	ret

0000000000000878 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 878:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 87c:	d4000001 	svc	#0x0
 ret
 880:	d65f03c0 	ret

0000000000000884 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 884:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 888:	d4000001 	svc	#0x0
 ret
 88c:	d65f03c0 	ret

0000000000000890 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 890:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 894:	d4000001 	svc	#0x0
 ret
 898:	d65f03c0 	ret

000000000000089c <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 89c:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 8a0:	d4000001 	svc	#0x0
 ret
 8a4:	d65f03c0 	ret

00000000000008a8 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 8a8:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 8ac:	d4000001 	svc	#0x0
 ret
 8b0:	d65f03c0 	ret

00000000000008b4 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 8b4:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 8b8:	d4000001 	svc	#0x0
 ret
 8bc:	d65f03c0 	ret

00000000000008c0 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 8c0:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 8c4:	d4000001 	svc	#0x0
 ret
 8c8:	d65f03c0 	ret

00000000000008cc <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 8cc:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 8d0:	d4000001 	svc	#0x0
 ret
 8d4:	d65f03c0 	ret

00000000000008d8 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 8d8:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 8dc:	d4000001 	svc	#0x0
 ret
 8e0:	d65f03c0 	ret

00000000000008e4 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 8e4:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 8e8:	d4000001 	svc	#0x0
 ret
 8ec:	d65f03c0 	ret

00000000000008f0 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 8f0:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 8f4:	d4000001 	svc	#0x0
 ret
 8f8:	d65f03c0 	ret

00000000000008fc <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 8fc:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 900:	d4000001 	svc	#0x0
 ret
 904:	d65f03c0 	ret

0000000000000908 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 908:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 90c:	d4000001 	svc	#0x0
 ret
 910:	d65f03c0 	ret

0000000000000914 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 914:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 918:	d4000001 	svc	#0x0
 ret
 91c:	d65f03c0 	ret

0000000000000920 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 920:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 924:	d4000001 	svc	#0x0
 ret
 928:	d65f03c0 	ret

000000000000092c <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 92c:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 930:	d4000001 	svc	#0x0
 ret
 934:	d65f03c0 	ret

0000000000000938 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 938:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 93c:	d4000001 	svc	#0x0
 ret
 940:	d65f03c0 	ret

0000000000000944 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 944:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 948:	d4000001 	svc	#0x0
 ret
 94c:	d65f03c0 	ret

0000000000000950 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 950:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 954:	d4000001 	svc	#0x0
 ret
 958:	d65f03c0 	ret

000000000000095c <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 95c:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 960:	d4000001 	svc	#0x0
 ret
 964:	d65f03c0 	ret

0000000000000968 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 968:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 96c:	d4000001 	svc	#0x0
 ret
 970:	d65f03c0 	ret

0000000000000974 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 974:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 978:	d4000001 	svc	#0x0
 ret
 97c:	d65f03c0 	ret

0000000000000980 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 980:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 984:	d4000001 	svc	#0x0
 ret
 988:	d65f03c0 	ret

000000000000098c <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 98c:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 990:	d4000001 	svc	#0x0
 ret
 994:	d65f03c0 	ret

0000000000000998 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 998:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 99c:	d4000001 	svc	#0x0
 ret
 9a0:	d65f03c0 	ret

00000000000009a4 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 9a4:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 9a8:	d4000001 	svc	#0x0
 ret
 9ac:	d65f03c0 	ret

00000000000009b0 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 9b0:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 9b4:	d4000001 	svc	#0x0
 ret
 9b8:	d65f03c0 	ret

00000000000009bc <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 9bc:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 9c0:	d4000001 	svc	#0x0
 ret
 9c4:	d65f03c0 	ret

00000000000009c8 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 9c8:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 9cc:	d4000001 	svc	#0x0
 ret
 9d0:	d65f03c0 	ret

00000000000009d4 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 9d4:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 9d8:	d4000001 	svc	#0x0
 ret
 9dc:	d65f03c0 	ret

00000000000009e0 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 9e0:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 9e4:	d4000001 	svc	#0x0
 ret
 9e8:	d65f03c0 	ret

00000000000009ec <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 9ec:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 9f0:	d4000001 	svc	#0x0
 ret
 9f4:	d65f03c0 	ret

00000000000009f8 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 9f8:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 9fc:	d4000001 	svc	#0x0
 ret
 a00:	d65f03c0 	ret

0000000000000a04 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 a04:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 a08:	d4000001 	svc	#0x0
 ret
 a0c:	d65f03c0 	ret

0000000000000a10 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 a10:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 a14:	d4000001 	svc	#0x0
 ret
 a18:	d65f03c0 	ret

0000000000000a1c <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 a1c:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 a20:	d4000001 	svc	#0x0
 ret
 a24:	d65f03c0 	ret

0000000000000a28 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 a28:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 a2c:	d4000001 	svc	#0x0
 ret
 a30:	d65f03c0 	ret

0000000000000a34 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 a34:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 a38:	d4000001 	svc	#0x0
 ret
 a3c:	d65f03c0 	ret

0000000000000a40 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 a40:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 a44:	d4000001 	svc	#0x0
 ret
 a48:	d65f03c0 	ret

0000000000000a4c <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 a4c:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 a50:	d4000001 	svc	#0x0
 ret
 a54:	d65f03c0 	ret

0000000000000a58 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 a58:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 a5c:	d4000001 	svc	#0x0
 ret
 a60:	d65f03c0 	ret

0000000000000a64 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 a64:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 a68:	d4000001 	svc	#0x0
 ret
 a6c:	d65f03c0 	ret

0000000000000a70 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 a70:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 a74:	d4000001 	svc	#0x0
 ret
 a78:	d65f03c0 	ret

0000000000000a7c <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 a7c:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 a80:	d4000001 	svc	#0x0
 ret
 a84:	d65f03c0 	ret

0000000000000a88 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 a88:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 a8c:	d4000001 	svc	#0x0
 ret
 a90:	d65f03c0 	ret

0000000000000a94 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 a94:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 a98:	d4000001 	svc	#0x0
 ret
 a9c:	d65f03c0 	ret

0000000000000aa0 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 aa0:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 aa4:	d4000001 	svc	#0x0
 ret
 aa8:	d65f03c0 	ret

0000000000000aac <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 aac:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 ab0:	d4000001 	svc	#0x0
 ret
 ab4:	d65f03c0 	ret

0000000000000ab8 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 ab8:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 abc:	d4000001 	svc	#0x0
 ret
 ac0:	d65f03c0 	ret

0000000000000ac4 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 ac4:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 ac8:	d4000001 	svc	#0x0
 ret
 acc:	d65f03c0 	ret

0000000000000ad0 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 ad0:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 ad4:	d4000001 	svc	#0x0
 ret
 ad8:	d65f03c0 	ret

0000000000000adc <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 adc:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 ae0:	d4000001 	svc	#0x0
 ret
 ae4:	d65f03c0 	ret

0000000000000ae8 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 ae8:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 aec:	d4000001 	svc	#0x0
 ret
 af0:	d65f03c0 	ret

0000000000000af4 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 af4:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 af8:	d4000001 	svc	#0x0
 ret
 afc:	d65f03c0 	ret

0000000000000b00 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 b00:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 b04:	d4000001 	svc	#0x0
 ret
 b08:	d65f03c0 	ret

0000000000000b0c <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 b0c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 b10:	52800022 	mov	w2, #0x1                   	// #1
{
 b14:	910003fd 	mov	x29, sp
 b18:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 b1c:	91007fe1 	add	x1, sp, #0x1f
 b20:	97ffff2f 	bl	7dc <write>
 b24:	7100041f 	cmp	w0, #0x1
}
 b28:	1a9f17e0 	cset	w0, eq	// eq = none
 b2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 b30:	d65f03c0 	ret

0000000000000b34 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 b34:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 b38:	910003fd 	mov	x29, sp
 b3c:	a90153f3 	stp	x19, x20, [sp, #16]
 b40:	a9025bf5 	stp	x21, x22, [sp, #32]
 b44:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 b48:	6a417c7f 	tst	w3, w1, lsr #31
 b4c:	54000300 	b.eq	bac <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 b50:	4b0103e1 	neg	w1, w1
    neg = 1;
 b54:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 b58:	b0000003 	adrp	x3, 1000 <printf+0xe4>
 b5c:	91005863 	add	x3, x3, #0x16
 b60:	9100c3f5 	add	x21, sp, #0x30
 b64:	d2800000 	mov	x0, #0x0                   	// #0
 b68:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 b6c:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 b70:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 b74:	2a0403e1 	mov	w1, w4
 b78:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 b7c:	38666866 	ldrb	w6, [x3, x6]
 b80:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 b84:	91000400 	add	x0, x0, #0x1
 b88:	54ffff09 	b.ls	b68 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 b8c:	11000493 	add	w19, w4, #0x1
  if(neg)
 b90:	34000085 	cbz	w5, ba0 <printint+0x6c>
    buf[i++] = '-';
 b94:	528005a0 	mov	w0, #0x2d                  	// #45
 b98:	38334aa0 	strb	w0, [x21, w19, uxtw]
 b9c:	11000893 	add	w19, w4, #0x2
 ba0:	51000673 	sub	w19, w19, #0x1
 ba4:	52800014 	mov	w20, #0x0                   	// #0
 ba8:	14000008 	b	bc8 <printint+0x94>
  neg = 0;
 bac:	52800005 	mov	w5, #0x0                   	// #0
 bb0:	17ffffea 	b	b58 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 bb4:	38736aa1 	ldrb	w1, [x21, x19]
 bb8:	2a1603e0 	mov	w0, w22
 bbc:	d1000673 	sub	x19, x19, #0x1
 bc0:	97ffffd3 	bl	b0c <putc>
 bc4:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 bc8:	3100067f 	cmn	w19, #0x1
 bcc:	54ffff41 	b.ne	bb4 <printint+0x80>  // b.any
  return written;
}
 bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
 bd4:	2a1403e0 	mov	w0, w20
 bd8:	a94153f3 	ldp	x19, x20, [sp, #16]
 bdc:	a8c47bfd 	ldp	x29, x30, [sp], #64
 be0:	d65f03c0 	ret

0000000000000be4 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 be4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 be8:	910003fd 	mov	x29, sp
 bec:	a90153f3 	stp	x19, x20, [sp, #16]
 bf0:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 bf4:	52800015 	mov	w21, #0x0                   	// #0
{
 bf8:	a90363f7 	stp	x23, x24, [sp, #48]
 bfc:	2a0003f7 	mov	w23, w0
 c00:	a9046bf9 	stp	x25, x26, [sp, #64]
 c04:	aa0103f9 	mov	x25, x1

  state = 0;
 c08:	52800001 	mov	w1, #0x0                   	// #0
{
 c0c:	a90573fb 	stp	x27, x28, [sp, #80]
 c10:	a9406053 	ldp	x19, x24, [x2]
 c14:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 c18:	39400320 	ldrb	w0, [x25]
 c1c:	35000120 	cbnz	w0, c40 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 c20:	2a1503e0 	mov	w0, w21
 c24:	a94153f3 	ldp	x19, x20, [sp, #16]
 c28:	a9425bf5 	ldp	x21, x22, [sp, #32]
 c2c:	a94363f7 	ldp	x23, x24, [sp, #48]
 c30:	a9446bf9 	ldp	x25, x26, [sp, #64]
 c34:	a94573fb 	ldp	x27, x28, [sp, #80]
 c38:	a8c67bfd 	ldp	x29, x30, [sp], #96
 c3c:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 c40:	2a0003f6 	mov	w22, w0
    if(state == 0){
 c44:	35000101 	cbnz	w1, c64 <vprintf+0x80>
      if(c == '%'){
 c48:	7100941f 	cmp	w0, #0x25
 c4c:	54000ba0 	b.eq	dc0 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 c50:	2a1603e1 	mov	w1, w22
 c54:	2a1703e0 	mov	w0, w23
 c58:	97ffffad 	bl	b0c <putc>
 c5c:	0b0002b5 	add	w21, w21, w0
 c60:	14000057 	b	dbc <vprintf+0x1d8>
      if(c == 'd'){
 c64:	7101901f 	cmp	w0, #0x64
 c68:	540002a1 	b.ne	cbc <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 c6c:	37f80174 	tbnz	w20, #31, c98 <vprintf+0xb4>
 c70:	91002e76 	add	x22, x19, #0xb
 c74:	2a1403fa 	mov	w26, w20
 c78:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c7c:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 c80:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 c84:	b9400261 	ldr	w1, [x19]
 c88:	2a1703e0 	mov	w0, w23
 c8c:	97ffffaa 	bl	b34 <printint>
        written += putc(fd, va_arg(ap, uint));
 c90:	0b0002b5 	add	w21, w21, w0
 c94:	14000048 	b	db4 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 c98:	1100229a 	add	w26, w20, #0x8
 c9c:	7100035f 	cmp	w26, #0x0
 ca0:	5400008d 	b.le	cb0 <vprintf+0xcc>
 ca4:	91002e76 	add	x22, x19, #0xb
 ca8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cac:	17fffff4 	b	c7c <vprintf+0x98>
 cb0:	aa1303f6 	mov	x22, x19
 cb4:	8b34c313 	add	x19, x24, w20, sxtw
 cb8:	17fffff1 	b	c7c <vprintf+0x98>
      } else if(c == 'l') {
 cbc:	7101b01f 	cmp	w0, #0x6c
 cc0:	54000201 	b.ne	d00 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 cc4:	37f800d4 	tbnz	w20, #31, cdc <vprintf+0xf8>
 cc8:	91003e76 	add	x22, x19, #0xf
 ccc:	2a1403fa 	mov	w26, w20
 cd0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cd4:	52800003 	mov	w3, #0x0                   	// #0
 cd8:	17ffffea 	b	c80 <vprintf+0x9c>
 cdc:	1100229a 	add	w26, w20, #0x8
 ce0:	7100035f 	cmp	w26, #0x0
 ce4:	5400008d 	b.le	cf4 <vprintf+0x110>
 ce8:	91003e76 	add	x22, x19, #0xf
 cec:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cf0:	17fffff9 	b	cd4 <vprintf+0xf0>
 cf4:	aa1303f6 	mov	x22, x19
 cf8:	8b34c313 	add	x19, x24, w20, sxtw
 cfc:	17fffff6 	b	cd4 <vprintf+0xf0>
      } else if(c == 'x') {
 d00:	7101e01f 	cmp	w0, #0x78
 d04:	54000221 	b.ne	d48 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 d08:	37f800f4 	tbnz	w20, #31, d24 <vprintf+0x140>
 d0c:	91002e76 	add	x22, x19, #0xb
 d10:	2a1403fa 	mov	w26, w20
 d14:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d18:	52800003 	mov	w3, #0x0                   	// #0
 d1c:	52800202 	mov	w2, #0x10                  	// #16
 d20:	17ffffd9 	b	c84 <vprintf+0xa0>
 d24:	1100229a 	add	w26, w20, #0x8
 d28:	7100035f 	cmp	w26, #0x0
 d2c:	5400008d 	b.le	d3c <vprintf+0x158>
 d30:	91002e76 	add	x22, x19, #0xb
 d34:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d38:	17fffff8 	b	d18 <vprintf+0x134>
 d3c:	aa1303f6 	mov	x22, x19
 d40:	8b34c313 	add	x19, x24, w20, sxtw
 d44:	17fffff5 	b	d18 <vprintf+0x134>
      } else if(c == 'p') {
 d48:	7101c01f 	cmp	w0, #0x70
 d4c:	54000521 	b.ne	df0 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 d50:	37f803f4 	tbnz	w20, #31, dcc <vprintf+0x1e8>
 d54:	91003e76 	add	x22, x19, #0xf
 d58:	2a1403fa 	mov	w26, w20
 d5c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d60:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 d64:	52800601 	mov	w1, #0x30                  	// #48
 d68:	2a1703e0 	mov	w0, w23
 d6c:	97ffff68 	bl	b0c <putc>
 d70:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d74:	b000001c 	adrp	x28, 1000 <printf+0xe4>
 d78:	91005b9c 	add	x28, x28, #0x16
  written += putc(fd, 'x');
 d7c:	2a1703e0 	mov	w0, w23
 d80:	52800f01 	mov	w1, #0x78                  	// #120
 d84:	97ffff62 	bl	b0c <putc>
 d88:	0b000273 	add	w19, w19, w0
 d8c:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d90:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 d94:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d98:	38606b81 	ldrb	w1, [x28, x0]
 d9c:	2a1703e0 	mov	w0, w23
 da0:	97ffff5b 	bl	b0c <putc>
 da4:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 da8:	71000694 	subs	w20, w20, #0x1
 dac:	54ffff21 	b.ne	d90 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 db0:	0b1302b5 	add	w21, w21, w19
 db4:	2a1a03f4 	mov	w20, w26
 db8:	aa1603f3 	mov	x19, x22
      state = 0;
 dbc:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 dc0:	91000739 	add	x25, x25, #0x1
  state = 0;
 dc4:	2a1603e1 	mov	w1, w22
 dc8:	17ffff94 	b	c18 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 dcc:	1100229a 	add	w26, w20, #0x8
 dd0:	7100035f 	cmp	w26, #0x0
 dd4:	5400008d 	b.le	de4 <vprintf+0x200>
 dd8:	91003e76 	add	x22, x19, #0xf
 ddc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 de0:	17ffffe0 	b	d60 <vprintf+0x17c>
 de4:	aa1303f6 	mov	x22, x19
 de8:	8b34c313 	add	x19, x24, w20, sxtw
 dec:	17ffffdd 	b	d60 <vprintf+0x17c>
      } else if(c == 's'){
 df0:	7101cc1f 	cmp	w0, #0x73
 df4:	54000381 	b.ne	e64 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 df8:	37f80214 	tbnz	w20, #31, e38 <vprintf+0x254>
 dfc:	91003e61 	add	x1, x19, #0xf
 e00:	aa1303e0 	mov	x0, x19
 e04:	927df033 	and	x19, x1, #0xfffffffffffffff8
 e08:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 e0c:	b0000000 	adrp	x0, 1000 <printf+0xe4>
 e10:	91003c00 	add	x0, x0, #0xf
 e14:	f10002df 	cmp	x22, #0x0
 e18:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 e1c:	394002c1 	ldrb	w1, [x22]
 e20:	34fffce1 	cbz	w1, dbc <vprintf+0x1d8>
          written += putc(fd, *s);
 e24:	2a1703e0 	mov	w0, w23
          s++;
 e28:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 e2c:	97ffff38 	bl	b0c <putc>
 e30:	0b0002b5 	add	w21, w21, w0
          s++;
 e34:	17fffffa 	b	e1c <vprintf+0x238>
        s = va_arg(ap, char*);
 e38:	11002281 	add	w1, w20, #0x8
 e3c:	7100003f 	cmp	w1, #0x0
 e40:	540000cd 	b.le	e58 <vprintf+0x274>
 e44:	91003e62 	add	x2, x19, #0xf
 e48:	aa1303e0 	mov	x0, x19
 e4c:	2a0103f4 	mov	w20, w1
 e50:	927df053 	and	x19, x2, #0xfffffffffffffff8
 e54:	17ffffed 	b	e08 <vprintf+0x224>
 e58:	8b34c300 	add	x0, x24, w20, sxtw
 e5c:	2a0103f4 	mov	w20, w1
 e60:	17ffffea 	b	e08 <vprintf+0x224>
      } else if(c == 'c'){
 e64:	71018c1f 	cmp	w0, #0x63
 e68:	54000241 	b.ne	eb0 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 e6c:	37f80114 	tbnz	w20, #31, e8c <vprintf+0x2a8>
 e70:	91002e76 	add	x22, x19, #0xb
 e74:	2a1403fa 	mov	w26, w20
 e78:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 e7c:	39400261 	ldrb	w1, [x19]
 e80:	2a1703e0 	mov	w0, w23
 e84:	97ffff22 	bl	b0c <putc>
 e88:	17ffff82 	b	c90 <vprintf+0xac>
 e8c:	1100229a 	add	w26, w20, #0x8
 e90:	7100035f 	cmp	w26, #0x0
 e94:	5400008d 	b.le	ea4 <vprintf+0x2c0>
 e98:	91002e76 	add	x22, x19, #0xb
 e9c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ea0:	17fffff7 	b	e7c <vprintf+0x298>
 ea4:	aa1303f6 	mov	x22, x19
 ea8:	8b34c313 	add	x19, x24, w20, sxtw
 eac:	17fffff4 	b	e7c <vprintf+0x298>
      } else if(c == '%'){
 eb0:	7100941f 	cmp	w0, #0x25
 eb4:	54ffece0 	b.eq	c50 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 eb8:	2a1703e0 	mov	w0, w23
 ebc:	528004a1 	mov	w1, #0x25                  	// #37
 ec0:	97ffff13 	bl	b0c <putc>
 ec4:	0b0002b5 	add	w21, w21, w0
 ec8:	17ffff62 	b	c50 <vprintf+0x6c>

0000000000000ecc <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 ecc:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 ed0:	910003fd 	mov	x29, sp
 ed4:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 ed8:	910203e2 	add	x2, sp, #0x80
 edc:	a9030be2 	stp	x2, x2, [sp, #48]
 ee0:	910143e2 	add	x2, sp, #0x50
 ee4:	f90023e2 	str	x2, [sp, #64]
 ee8:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 eec:	b9004be2 	str	w2, [sp, #72]
 ef0:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 ef4:	a9430fe2 	ldp	x2, x3, [sp, #48]
 ef8:	a9010fe2 	stp	x2, x3, [sp, #16]
 efc:	a9440fe2 	ldp	x2, x3, [sp, #64]
 f00:	a9020fe2 	stp	x2, x3, [sp, #32]
 f04:	910043e2 	add	x2, sp, #0x10
{
 f08:	a90617e4 	stp	x4, x5, [sp, #96]
 f0c:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 f10:	97ffff35 	bl	be4 <vprintf>
  va_end(ap);
  return result;
}
 f14:	a8c87bfd 	ldp	x29, x30, [sp], #128
 f18:	d65f03c0 	ret

0000000000000f1c <printf>:

int
printf(const char *fmt, ...)
{
 f1c:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 f20:	910003fd 	mov	x29, sp
 f24:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 f28:	910243e1 	add	x1, sp, #0x90
 f2c:	a90307e1 	stp	x1, x1, [sp, #48]
 f30:	910143e1 	add	x1, sp, #0x50
 f34:	f90023e1 	str	x1, [sp, #64]
 f38:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 f3c:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 f40:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 f44:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 f48:	52800020 	mov	w0, #0x1                   	// #1
{
 f4c:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 f50:	a9430fe2 	ldp	x2, x3, [sp, #48]
 f54:	a9010fe2 	stp	x2, x3, [sp, #16]
 f58:	a9440fe2 	ldp	x2, x3, [sp, #64]
 f5c:	a9020fe2 	stp	x2, x3, [sp, #32]
 f60:	910043e2 	add	x2, sp, #0x10
{
 f64:	a9079be5 	stp	x5, x6, [sp, #120]
 f68:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 f6c:	97ffff1e 	bl	be4 <vprintf>
  va_end(ap);
  return result;
}
 f70:	a8c97bfd 	ldp	x29, x30, [sp], #144
 f74:	d65f03c0 	ret
