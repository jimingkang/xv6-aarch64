
user/_rtlat:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
         (us / 10) % 10, us % 10);
}

int
main(int argc, char *argv[])
{
       0:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
       4:	910003fd 	mov	x29, sp
       8:	a9046bf9 	stp	x25, x26, [sp, #64]
       c:	2a0003f9 	mov	w25, w0
  int policy = SCHED_FIFO, prio = 80, cpu = 3, hogs = 3, samples = 30;
      10:	52800a00 	mov	w0, #0x50                  	// #80
{
      14:	aa0103fa 	mov	x26, x1
      18:	a90153f3 	stp	x19, x20, [sp, #16]
  int fds[2], hog_pid[8], reader;

  for(int i = 1; i < argc; i++){
      1c:	d2800033 	mov	x19, #0x1                   	// #1
  int policy = SCHED_FIFO, prio = 80, cpu = 3, hogs = 3, samples = 30;
      20:	2a1303f4 	mov	w20, w19
{
      24:	a90363f7 	stp	x23, x24, [sp, #48]
    if(i + 1 >= argc)
      usage();
    char *opt = argv[i], *val = argv[++i];
    if(strcmp(opt, "-p") == 0){
      28:	b0000017 	adrp	x23, 1000 <printf+0x4>
      2c:	91035af7 	add	x23, x23, #0xd6
      if(strcmp(val, "fifo") == 0) policy = SCHED_FIFO;
      else if(strcmp(val, "rr") == 0) policy = SCHED_RR;
      else if(strcmp(val, "other") == 0) policy = SCHED_OTHER;
      else usage();
    } else if(strcmp(opt, "-P") == 0){
      30:	b0000018 	adrp	x24, 1000 <printf+0x4>
      34:	91039f18 	add	x24, x24, #0xe7
{
      38:	a90573fb 	stp	x27, x28, [sp, #80]
    char *opt = argv[i], *val = argv[++i];
      3c:	9100203b 	add	x27, x1, #0x8
  int policy = SCHED_FIFO, prio = 80, cpu = 3, hogs = 3, samples = 30;
      40:	b90063e0 	str	w0, [sp, #96]
      44:	52800060 	mov	w0, #0x3                   	// #3
{
      48:	a9025bf5 	stp	x21, x22, [sp, #32]
  int policy = SCHED_FIFO, prio = 80, cpu = 3, hogs = 3, samples = 30;
      4c:	290c83e0 	stp	w0, w0, [sp, #100]
      50:	528003c0 	mov	w0, #0x1e                  	// #30
      54:	b9006fe0 	str	w0, [sp, #108]
  for(int i = 1; i < argc; i++){
      58:	6b13033f 	cmp	w25, w19
      5c:	5400032c 	b.gt	c0 <main+0xc0>
      if(!parse_num(val, &samples) || samples < 1) usage();
    } else {
      usage();
    }
  }
  if(policy == SCHED_OTHER)
      60:	35000cf4 	cbnz	w20, 1fc <main+0x1fc>
static __attribute__((unused)) const char *
policy_name(int policy)
{
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
  if(policy == SCHED_RR) return "SCHED_RR";
  return "SCHED_OTHER";
      64:	b0000013 	adrp	x19, 1000 <printf+0x4>
      68:	91030673 	add	x19, x19, #0xc1
    prio = 0;
      6c:	b90063ff 	str	wzr, [sp, #96]

  printf("rtlat: reader %s prio %d on CPU%d, %d busy loop(s) on CPU%d, "
      70:	294c5bfa 	ldp	w26, w22, [sp, #96]
      74:	aa1303e1 	mov	x1, x19
      78:	294d57f9 	ldp	w25, w21, [sp, #104]
      7c:	2a1603e5 	mov	w5, w22
      80:	2a1603e3 	mov	w3, w22
      84:	2a1a03e2 	mov	w2, w26
      88:	2a1503e6 	mov	w6, w21
      8c:	2a1903e4 	mov	w4, w25
      90:	b0000000 	adrp	x0, 1000 <printf+0x4>
      94:	9103cc00 	add	x0, x0, #0xf3
      98:	940003d9 	bl	ffc <printf>
         "%d samples\n", policy_name(policy), prio, cpu, hogs, cpu, samples);

  if(pipe(fds) < 0){
      9c:	9101c3e0 	add	x0, sp, #0x70
      a0:	94000201 	bl	8a4 <pipe>
      a4:	36f80e40 	tbz	w0, #31, 26c <main+0x26c>
    fprintf(2, "rtlat: pipe failed\n");
      a8:	b0000001 	adrp	x1, 1000 <printf+0x4>
      ac:	9104f021 	add	x1, x1, #0x13c
      b0:	52800040 	mov	w0, #0x2                   	// #2
      b4:	940003be 	bl	fac <fprintf>
    exit(1);
      b8:	52800020 	mov	w0, #0x1                   	// #1
      bc:	940001f4 	bl	88c <exit>
    if(i + 1 >= argc)
      c0:	11000660 	add	w0, w19, #0x1
      c4:	6b00033f 	cmp	w25, w0
      c8:	5400004c 	b.gt	d0 <main+0xd0>
      usage();
      cc:	94000123 	bl	558 <usage>
    char *opt = argv[i], *val = argv[++i];
      d0:	f8737b56 	ldr	x22, [x26, x19, lsl #3]
    if(strcmp(opt, "-p") == 0){
      d4:	aa1703e1 	mov	x1, x23
    char *opt = argv[i], *val = argv[++i];
      d8:	f8737b75 	ldr	x21, [x27, x19, lsl #3]
    if(strcmp(opt, "-p") == 0){
      dc:	aa1603e0 	mov	x0, x22
      e0:	94000149 	bl	604 <strcmp>
      e4:	35000260 	cbnz	w0, 130 <main+0x130>
      if(strcmp(val, "fifo") == 0) policy = SCHED_FIFO;
      e8:	b0000001 	adrp	x1, 1000 <printf+0x4>
      ec:	91036421 	add	x1, x1, #0xd9
      f0:	aa1503e0 	mov	x0, x21
      f4:	94000144 	bl	604 <strcmp>
      f8:	340007a0 	cbz	w0, 1ec <main+0x1ec>
      else if(strcmp(val, "rr") == 0) policy = SCHED_RR;
      fc:	b0000001 	adrp	x1, 1000 <printf+0x4>
     100:	91037821 	add	x1, x1, #0xde
     104:	aa1503e0 	mov	x0, x21
     108:	9400013f 	bl	604 <strcmp>
     10c:	34000740 	cbz	w0, 1f4 <main+0x1f4>
      else if(strcmp(val, "other") == 0) policy = SCHED_OTHER;
     110:	aa1503e0 	mov	x0, x21
     114:	b0000001 	adrp	x1, 1000 <printf+0x4>
     118:	91038421 	add	x1, x1, #0xe1
     11c:	9400013a 	bl	604 <strcmp>
     120:	2a0003f4 	mov	w20, w0
     124:	35fffd40 	cbnz	w0, cc <main+0xcc>
  for(int i = 1; i < argc; i++){
     128:	91000a73 	add	x19, x19, #0x2
     12c:	17ffffcb 	b	58 <main+0x58>
    } else if(strcmp(opt, "-P") == 0){
     130:	aa1803e1 	mov	x1, x24
     134:	aa1603e0 	mov	x0, x22
     138:	94000133 	bl	604 <strcmp>
     13c:	350000c0 	cbnz	w0, 154 <main+0x154>
      if(!parse_num(val, &prio)) usage();
     140:	910183e1 	add	x1, sp, #0x60
     144:	aa1503e0 	mov	x0, x21
     148:	940000b8 	bl	428 <parse_num>
     14c:	35fffee0 	cbnz	w0, 128 <main+0x128>
     150:	17ffffdf 	b	cc <main+0xcc>
    } else if(strcmp(opt, "-c") == 0){
     154:	b0000001 	adrp	x1, 1000 <printf+0x4>
     158:	9103a821 	add	x1, x1, #0xea
     15c:	aa1603e0 	mov	x0, x22
     160:	94000129 	bl	604 <strcmp>
     164:	35000120 	cbnz	w0, 188 <main+0x188>
      if(!parse_num(val, &cpu) || cpu < 0 || cpu >= NCPU) usage();
     168:	910193e1 	add	x1, sp, #0x64
     16c:	aa1503e0 	mov	x0, x21
     170:	940000ae 	bl	428 <parse_num>
     174:	34fffac0 	cbz	w0, cc <main+0xcc>
     178:	b94067e0 	ldr	w0, [sp, #100]
     17c:	71000c1f 	cmp	w0, #0x3
      if(!parse_num(val, &hogs) || hogs < 0 || hogs > 8) usage();
     180:	54fffd49 	b.ls	128 <main+0x128>  // b.plast
     184:	17ffffd2 	b	cc <main+0xcc>
    } else if(strcmp(opt, "-l") == 0){
     188:	b0000001 	adrp	x1, 1000 <printf+0x4>
     18c:	9103b421 	add	x1, x1, #0xed
     190:	aa1603e0 	mov	x0, x22
     194:	9400011c 	bl	604 <strcmp>
     198:	35000100 	cbnz	w0, 1b8 <main+0x1b8>
      if(!parse_num(val, &hogs) || hogs < 0 || hogs > 8) usage();
     19c:	9101a3e1 	add	x1, sp, #0x68
     1a0:	aa1503e0 	mov	x0, x21
     1a4:	940000a1 	bl	428 <parse_num>
     1a8:	34fff920 	cbz	w0, cc <main+0xcc>
     1ac:	b9406be0 	ldr	w0, [sp, #104]
     1b0:	7100201f 	cmp	w0, #0x8
     1b4:	17fffff3 	b	180 <main+0x180>
    } else if(strcmp(opt, "-n") == 0){
     1b8:	b0000001 	adrp	x1, 1000 <printf+0x4>
     1bc:	9103c021 	add	x1, x1, #0xf0
     1c0:	aa1603e0 	mov	x0, x22
     1c4:	94000110 	bl	604 <strcmp>
     1c8:	35fff820 	cbnz	w0, cc <main+0xcc>
      if(!parse_num(val, &samples) || samples < 1) usage();
     1cc:	9101b3e1 	add	x1, sp, #0x6c
     1d0:	aa1503e0 	mov	x0, x21
     1d4:	94000095 	bl	428 <parse_num>
     1d8:	34fff7a0 	cbz	w0, cc <main+0xcc>
     1dc:	b9406fe0 	ldr	w0, [sp, #108]
     1e0:	7100001f 	cmp	w0, #0x0
     1e4:	54fffa2c 	b.gt	128 <main+0x128>
     1e8:	17ffffb9 	b	cc <main+0xcc>
      if(strcmp(val, "fifo") == 0) policy = SCHED_FIFO;
     1ec:	52800034 	mov	w20, #0x1                   	// #1
     1f0:	17ffffce 	b	128 <main+0x128>
      else if(strcmp(val, "rr") == 0) policy = SCHED_RR;
     1f4:	52800054 	mov	w20, #0x2                   	// #2
     1f8:	17ffffcc 	b	128 <main+0x128>
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
     1fc:	7100069f 	cmp	w20, #0x1
     200:	b0000000 	adrp	x0, 1000 <printf+0x4>
     204:	9102d800 	add	x0, x0, #0xb6
     208:	b0000013 	adrp	x19, 1000 <printf+0x4>
     20c:	91033673 	add	x19, x19, #0xcd
     210:	9a801273 	csel	x19, x19, x0, ne	// ne = any
     214:	17ffff97 	b	70 <main+0x70>
  }

  // CPU hogs: ordinary time-sharing tasks that never block.
  for(int h = 0; h < hogs; h++){
    if((hog_pid[h] = fork()) == 0){
     218:	9400019a 	bl	880 <fork>
     21c:	b8377b00 	str	w0, [x24, x23, lsl #2]
     220:	910006f7 	add	x23, x23, #0x1
     224:	35000280 	cbnz	w0, 274 <main+0x274>
      close(fds[0]);
     228:	b94073e0 	ldr	w0, [sp, #112]
     22c:	940001a7 	bl	8c8 <close>
      close(fds[1]);
     230:	b94077e0 	ldr	w0, [sp, #116]
     234:	940001a5 	bl	8c8 <close>
      sched_setaffinity(0, 1U << cpu);
     238:	52800021 	mov	w1, #0x1                   	// #1
     23c:	52800000 	mov	w0, #0x0                   	// #0
     240:	1ad62021 	lsl	w1, w1, w22
     244:	94000246 	bl	b5c <sched_setaffinity>
      sched_setscheduler(0, SCHED_OTHER, 0);
     248:	52800002 	mov	w2, #0x0                   	// #0
     24c:	52800001 	mov	w1, #0x0                   	// #0
     250:	52800000 	mov	w0, #0x0                   	// #0
     254:	94000239 	bl	b38 <sched_setscheduler>
      for(volatile uint64 n = 0; ; n++)
     258:	f9003fff 	str	xzr, [sp, #120]
     25c:	f9403fe0 	ldr	x0, [sp, #120]
     260:	91000400 	add	x0, x0, #0x1
     264:	f9003fe0 	str	x0, [sp, #120]
     268:	17fffffd 	b	25c <main+0x25c>
    if((hog_pid[h] = fork()) == 0){
     26c:	910203f8 	add	x24, sp, #0x80
  if(pipe(fds) < 0){
     270:	d2800017 	mov	x23, #0x0                   	// #0
  for(int h = 0; h < hogs; h++){
     274:	6b17033f 	cmp	w25, w23
     278:	54fffd0c 	b.gt	218 <main+0x218>
      sched_setaffinity(0, 1U << cpu);
     27c:	5280003b 	mov	w27, #0x1                   	// #1
        ;
    }
  }

  if((reader = fork()) == 0){
     280:	94000180 	bl	880 <fork>
      sched_setaffinity(0, 1U << cpu);
     284:	1ad62378 	lsl	w24, w27, w22
  if((reader = fork()) == 0){
     288:	2a0003f7 	mov	w23, w0
     28c:	35000880 	cbnz	w0, 39c <main+0x39c>
    uint64 ts, lat, min = ~0ULL, max = 0, sum = 0;
    int over1ms = 0, wrong_cpu = 0;

    close(fds[1]);
     290:	b94077e0 	ldr	w0, [sp, #116]
     294:	9400018d 	bl	8c8 <close>
    sched_setaffinity(0, 1U << cpu);
     298:	2a1803e1 	mov	w1, w24
     29c:	52800000 	mov	w0, #0x0                   	// #0
     2a0:	9400022f 	bl	b5c <sched_setaffinity>
    if(sched_setscheduler(0, policy, prio) < 0){
     2a4:	2a1a03e2 	mov	w2, w26
     2a8:	2a1403e1 	mov	w1, w20
     2ac:	52800000 	mov	w0, #0x0                   	// #0
     2b0:	94000222 	bl	b38 <sched_setscheduler>
     2b4:	36f80680 	tbz	w0, #31, 384 <main+0x384>
      fprintf(2, "rtlat: cannot set reader policy\n");
     2b8:	b0000001 	adrp	x1, 1000 <printf+0x4>
     2bc:	91054021 	add	x1, x1, #0x150
     2c0:	17ffff7c 	b	b0 <main+0xb0>
      exit(1);
    }
    for(int s = 0; s < samples; s++){
      if(read(fds[0], &ts, sizeof(ts)) != sizeof(ts))
     2c4:	b94073e0 	ldr	w0, [sp, #112]
     2c8:	9101e3e1 	add	x1, sp, #0x78
     2cc:	52800102 	mov	w2, #0x8                   	// #8
     2d0:	94000178 	bl	8b0 <read>
     2d4:	7100201f 	cmp	w0, #0x8
     2d8:	54000221 	b.ne	31c <main+0x31c>  // b.any
        break;
      lat = clock_us() - ts;
     2dc:	94000226 	bl	b74 <clock_us>
    for(int s = 0; s < samples; s++){
     2e0:	1100079c 	add	w28, w28, #0x1
      lat = clock_us() - ts;
     2e4:	f9403fe1 	ldr	x1, [sp, #120]
     2e8:	cb010014 	sub	x20, x0, x1
      if(getcpu() != cpu)
     2ec:	94000225 	bl	b80 <getcpu>
        wrong_cpu++;
     2f0:	6b0002df 	cmp	w22, w0
     2f4:	1a9706f7 	cinc	w23, w23, ne	// ne = any
      if(lat < min) min = lat;
     2f8:	eb14033f 	cmp	x25, x20
     2fc:	9a949339 	csel	x25, x25, x20, ls	// ls = plast
      if(lat > max) max = lat;
     300:	eb14031f 	cmp	x24, x20
     304:	9a942318 	csel	x24, x24, x20, cs	// cs = hs, nlast
      if(lat > 1000) over1ms++;
     308:	f10fa29f 	cmp	x20, #0x3e8
     30c:	1a9a975a 	cinc	w26, w26, hi	// hi = pmore
      sum += lat;
     310:	8b14037b 	add	x27, x27, x20
    for(int s = 0; s < samples; s++){
     314:	6b1c02bf 	cmp	w21, w28
     318:	54fffd6c 	b.gt	2c4 <main+0x2c4>
    }
    printf("rtlat: %s wakeup latency over %d samples\n",
     31c:	2a1503e2 	mov	w2, w21
     320:	aa1303e1 	mov	x1, x19
     324:	b0000000 	adrp	x0, 1000 <printf+0x4>
     328:	9105c400 	add	x0, x0, #0x171
     32c:	94000334 	bl	ffc <printf>
           policy_name(policy), samples);
    print_us("min", min);
     330:	aa1903e1 	mov	x1, x25
     334:	b0000000 	adrp	x0, 1000 <printf+0x4>
     338:	91066c00 	add	x0, x0, #0x19b
     33c:	94000077 	bl	518 <print_us>
    print_us("avg", sum / samples);
     340:	93407ea1 	sxtw	x1, w21
     344:	b0000000 	adrp	x0, 1000 <printf+0x4>
     348:	91067c00 	add	x0, x0, #0x19f
     34c:	9ac10b61 	udiv	x1, x27, x1
     350:	94000072 	bl	518 <print_us>
    print_us("max", max);
     354:	aa1803e1 	mov	x1, x24
     358:	b0000000 	adrp	x0, 1000 <printf+0x4>
     35c:	91068c00 	add	x0, x0, #0x1a3
     360:	9400006e 	bl	518 <print_us>
    printf("  samples > 1 ms: %d, ran on a CPU other than CPU%d: %d\n",
     364:	b0000000 	adrp	x0, 1000 <printf+0x4>
     368:	91069c00 	add	x0, x0, #0x1a7
     36c:	2a1703e3 	mov	w3, w23
     370:	2a1603e2 	mov	w2, w22
     374:	2a1a03e1 	mov	w1, w26
     378:	94000321 	bl	ffc <printf>
  wait(0);                          // reader
  for(int h = 0; h < hogs; h++){
    kill(hog_pid[h]);
    wait(0);
  }
  exit(0);
     37c:	52800000 	mov	w0, #0x0                   	// #0
     380:	17ffff4f 	b	bc <main+0xbc>
    for(int s = 0; s < samples; s++){
     384:	5280001c 	mov	w28, #0x0                   	// #0
    int over1ms = 0, wrong_cpu = 0;
     388:	5280001a 	mov	w26, #0x0                   	// #0
    uint64 ts, lat, min = ~0ULL, max = 0, sum = 0;
     38c:	d280001b 	mov	x27, #0x0                   	// #0
     390:	d2800018 	mov	x24, #0x0                   	// #0
     394:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
     398:	17ffffdf 	b	314 <main+0x314>
  close(fds[0]);
     39c:	b94073e0 	ldr	w0, [sp, #112]
  for(int s = 0; s < samples; s++){
     3a0:	52800013 	mov	w19, #0x0                   	// #0
  close(fds[0]);
     3a4:	94000149 	bl	8c8 <close>
  sched_setaffinity(0, ((1U << NCPU) - 1) & ~(1U << cpu));
     3a8:	2a3803e1 	mvn	w1, w24
     3ac:	52800000 	mov	w0, #0x0                   	// #0
     3b0:	12000c21 	and	w1, w1, #0xf
     3b4:	940001ea 	bl	b5c <sched_setaffinity>
  sleep_ticks(2);                   // let the hogs and reader settle
     3b8:	52800040 	mov	w0, #0x2                   	// #2
     3bc:	9400016a 	bl	964 <sleep_ticks>
  for(int s = 0; s < samples; s++){
     3c0:	6b1302bf 	cmp	w21, w19
     3c4:	540001ec 	b.gt	400 <main+0x400>
  close(fds[1]);
     3c8:	b94077e0 	ldr	w0, [sp, #116]
    kill(hog_pid[h]);
     3cc:	910203f4 	add	x20, sp, #0x80
  for(int h = 0; h < hogs; h++){
     3d0:	d2800013 	mov	x19, #0x0                   	// #0
  close(fds[1]);
     3d4:	9400013d 	bl	8c8 <close>
  wait(0);                          // reader
     3d8:	d2800000 	mov	x0, #0x0                   	// #0
     3dc:	9400012f 	bl	898 <wait>
  for(int h = 0; h < hogs; h++){
     3e0:	6b13033f 	cmp	w25, w19
     3e4:	54fffccd 	b.le	37c <main+0x37c>
    kill(hog_pid[h]);
     3e8:	b8737a80 	ldr	w0, [x20, x19, lsl #2]
     3ec:	91000673 	add	x19, x19, #0x1
     3f0:	94000139 	bl	8d4 <kill>
    wait(0);
     3f4:	d2800000 	mov	x0, #0x0                   	// #0
     3f8:	94000128 	bl	898 <wait>
  for(int h = 0; h < hogs; h++){
     3fc:	17fffff9 	b	3e0 <main+0x3e0>
    sleep_ticks(1);                 // one xv6 tick, 100 ms
     400:	52800020 	mov	w0, #0x1                   	// #1
     404:	94000158 	bl	964 <sleep_ticks>
    uint64 now = clock_us();
     408:	940001db 	bl	b74 <clock_us>
     40c:	f9003fe0 	str	x0, [sp, #120]
    write(fds[1], &now, sizeof(now));
     410:	b94077e0 	ldr	w0, [sp, #116]
     414:	9101e3e1 	add	x1, sp, #0x78
  for(int s = 0; s < samples; s++){
     418:	11000673 	add	w19, w19, #0x1
    write(fds[1], &now, sizeof(now));
     41c:	52800102 	mov	w2, #0x8                   	// #8
     420:	94000127 	bl	8bc <write>
  for(int s = 0; s < samples; s++){
     424:	17ffffe7 	b	3c0 <main+0x3c0>

0000000000000428 <parse_num>:
{
     428:	aa0003e2 	mov	x2, x0
  if(*s == '-'){
     42c:	39400000 	ldrb	w0, [x0]
     430:	7100b41f 	cmp	w0, #0x2d
     434:	540002c1 	b.ne	48c <parse_num+0x64>  // b.any
    s++;
     438:	91000442 	add	x2, x2, #0x1
    neg = 1;
     43c:	52800025 	mov	w5, #0x1                   	// #1
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
     440:	39400040 	ldrb	w0, [x2]
     444:	7100c01f 	cmp	w0, #0x30
     448:	540000c1 	b.ne	460 <parse_num+0x38>  // b.any
     44c:	39400440 	ldrb	w0, [x2, #1]
     450:	121a7800 	and	w0, w0, #0xffffffdf
     454:	12001c00 	and	w0, w0, #0xff
     458:	7101601f 	cmp	w0, #0x58
     45c:	540001c0 	b.eq	494 <parse_num+0x6c>  // b.none
     460:	52800000 	mov	w0, #0x0                   	// #0
     464:	52800003 	mov	w3, #0x0                   	// #0
      v = v * 10 + (*s - '0');
     468:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
     46c:	39400044 	ldrb	w4, [x2]
     470:	340001c4 	cbz	w4, 4a8 <parse_num+0x80>
      if(*s < '0' || *s > '9')
     474:	5100c084 	sub	w4, w4, #0x30
     478:	12001c80 	and	w0, w4, #0xff
     47c:	7100241f 	cmp	w0, #0x9
     480:	54000449 	b.ls	508 <parse_num+0xe0>  // b.plast
      else return 0;
     484:	52800000 	mov	w0, #0x0                   	// #0
}
     488:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
     48c:	52800005 	mov	w5, #0x0                   	// #0
     490:	17ffffec 	b	440 <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
     494:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
     498:	52800000 	mov	w0, #0x0                   	// #0
     49c:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
     4a0:	39400044 	ldrb	w4, [x2]
     4a4:	350000c4 	cbnz	w4, 4bc <parse_num+0x94>
  if(!any)
     4a8:	34ffff00 	cbz	w0, 488 <parse_num+0x60>
  *out = neg ? -v : v;
     4ac:	710000bf 	cmp	w5, #0x0
     4b0:	5a830463 	cneg	w3, w3, ne	// ne = any
     4b4:	b9000023 	str	w3, [x1]
  return 1;
     4b8:	17fffff4 	b	488 <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
     4bc:	5100c080 	sub	w0, w4, #0x30
     4c0:	12001c06 	and	w6, w0, #0xff
     4c4:	710024df 	cmp	w6, #0x9
     4c8:	540000c9 	b.ls	4e0 <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
     4cc:	51018480 	sub	w0, w4, #0x61
     4d0:	12001c00 	and	w0, w0, #0xff
     4d4:	7100141f 	cmp	w0, #0x5
     4d8:	540000c8 	b.hi	4f0 <parse_num+0xc8>  // b.pmore
     4dc:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
     4e0:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
     4e4:	91000442 	add	x2, x2, #0x1
     4e8:	52800020 	mov	w0, #0x1                   	// #1
     4ec:	17ffffed 	b	4a0 <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
     4f0:	51010480 	sub	w0, w4, #0x41
     4f4:	12001c00 	and	w0, w0, #0xff
     4f8:	7100141f 	cmp	w0, #0x5
     4fc:	54fffc48 	b.hi	484 <parse_num+0x5c>  // b.pmore
     500:	5100dc80 	sub	w0, w4, #0x37
     504:	17fffff7 	b	4e0 <parse_num+0xb8>
      v = v * 10 + (*s - '0');
     508:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
     50c:	91000442 	add	x2, x2, #0x1
     510:	52800020 	mov	w0, #0x1                   	// #1
     514:	17ffffd6 	b	46c <parse_num+0x44>

0000000000000518 <print_us>:
  printf("  %s %l.%l%l%l ms\n", label, us / 1000, (us / 100) % 10,
     518:	d2800c82 	mov	x2, #0x64                  	// #100
     51c:	d2800146 	mov	x6, #0xa                   	// #10
{
     520:	aa0003e7 	mov	x7, x0
  printf("  %s %l.%l%l%l ms\n", label, us / 1000, (us / 100) % 10,
     524:	b0000000 	adrp	x0, 1000 <printf+0x4>
     528:	91016000 	add	x0, x0, #0x58
     52c:	9ac20822 	udiv	x2, x1, x2
     530:	9ac60824 	udiv	x4, x1, x6
     534:	9ac60843 	udiv	x3, x2, x6
     538:	9ac60888 	udiv	x8, x4, x6
     53c:	9b068485 	msub	x5, x4, x6, x1
     540:	9b068863 	msub	x3, x3, x6, x2
     544:	d2807d02 	mov	x2, #0x3e8                 	// #1000
     548:	9ac20822 	udiv	x2, x1, x2
     54c:	9b069104 	msub	x4, x8, x6, x4
     550:	aa0703e1 	mov	x1, x7
     554:	140002aa 	b	ffc <printf>

0000000000000558 <usage>:
{
     558:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: rtlat [-p fifo|rr|other] [-P PRIO] [-c CPU] [-l HOGS] "
     55c:	b0000001 	adrp	x1, 1000 <printf+0x4>
     560:	9101ac21 	add	x1, x1, #0x6b
{
     564:	910003fd 	mov	x29, sp
  fprintf(2, "usage: rtlat [-p fifo|rr|other] [-P PRIO] [-c CPU] [-l HOGS] "
     568:	52800040 	mov	w0, #0x2                   	// #2
     56c:	94000290 	bl	fac <fprintf>
  exit(1);
     570:	52800020 	mov	w0, #0x1                   	// #1
     574:	940000c6 	bl	88c <exit>

0000000000000578 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     578:	d2800002 	mov	x2, #0x0                   	// #0
     57c:	38626823 	ldrb	w3, [x1, x2]
     580:	38226803 	strb	w3, [x0, x2]
     584:	91000442 	add	x2, x2, #0x1
     588:	35ffffa3 	cbnz	w3, 57c <strcpy+0x4>
    ;
  return os;
}
     58c:	d65f03c0 	ret

0000000000000590 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
     590:	d2800003 	mov	x3, #0x0                   	// #0
     594:	4b030044 	sub	w4, w2, w3
     598:	7100009f 	cmp	w4, #0x0
     59c:	5400006d 	b.le	5a8 <strncpy+0x18>
     5a0:	38636825 	ldrb	w5, [x1, x3]
     5a4:	350000e5 	cbnz	w5, 5c0 <strncpy+0x30>
     5a8:	8b030003 	add	x3, x0, x3
     5ac:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
     5b0:	4b010082 	sub	w2, w4, w1
     5b4:	7100005f 	cmp	w2, #0x0
     5b8:	540000ac 	b.gt	5cc <strncpy+0x3c>
    *s++ = 0;
  return os;
}
     5bc:	d65f03c0 	ret
    *s++ = *t++;
     5c0:	38236805 	strb	w5, [x0, x3]
    n--;
     5c4:	91000463 	add	x3, x3, #0x1
     5c8:	17fffff3 	b	594 <strncpy+0x4>
    *s++ = 0;
     5cc:	3821687f 	strb	wzr, [x3, x1]
     5d0:	91000421 	add	x1, x1, #0x1
     5d4:	17fffff7 	b	5b0 <strncpy+0x20>

00000000000005d8 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
     5d8:	aa0003e2 	mov	x2, x0
     5dc:	39400043 	ldrb	w3, [x2]
     5e0:	aa0203e4 	mov	x4, x2
    s++;
     5e4:	91000442 	add	x2, x2, #0x1
  while(*s)
     5e8:	35ffffa3 	cbnz	w3, 5dc <strcat+0x4>
     5ec:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
     5f0:	38626823 	ldrb	w3, [x1, x2]
     5f4:	38226883 	strb	w3, [x4, x2]
     5f8:	91000442 	add	x2, x2, #0x1
     5fc:	35ffffa3 	cbnz	w3, 5f0 <strcat+0x18>
    ;
  return os;
}
     600:	d65f03c0 	ret

0000000000000604 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
     604:	d2800002 	mov	x2, #0x0                   	// #0
     608:	38626803 	ldrb	w3, [x0, x2]
     60c:	38626824 	ldrb	w4, [x1, x2]
     610:	34000083 	cbz	w3, 620 <strcmp+0x1c>
     614:	91000442 	add	x2, x2, #0x1
     618:	6b04007f 	cmp	w3, w4
     61c:	54ffff60 	b.eq	608 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
     620:	4b040060 	sub	w0, w3, w4
     624:	d65f03c0 	ret

0000000000000628 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
     628:	340001c2 	cbz	w2, 660 <strncmp+0x38>
     62c:	39400003 	ldrb	w3, [x0]
     630:	34000083 	cbz	w3, 640 <strncmp+0x18>
     634:	39400024 	ldrb	w4, [x1]
     638:	6b03009f 	cmp	w4, w3
     63c:	540000a0 	b.eq	650 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
     640:	39400000 	ldrb	w0, [x0]
     644:	39400021 	ldrb	w1, [x1]
     648:	4b010000 	sub	w0, w0, w1
}
     64c:	d65f03c0 	ret
    n--, p++, q++;
     650:	51000442 	sub	w2, w2, #0x1
     654:	91000400 	add	x0, x0, #0x1
     658:	91000421 	add	x1, x1, #0x1
     65c:	17fffff3 	b	628 <strncmp>
    return 0;
     660:	52800000 	mov	w0, #0x0                   	// #0
     664:	17fffffa 	b	64c <strncmp+0x24>

0000000000000668 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
     668:	d1000402 	sub	x2, x0, #0x1
     66c:	d2800001 	mov	x1, #0x0                   	// #0
     670:	aa0103e0 	mov	x0, x1
     674:	91000421 	add	x1, x1, #0x1
     678:	38616843 	ldrb	w3, [x2, x1]
     67c:	35ffffa3 	cbnz	w3, 670 <strlen+0x8>
    ;
  return n;
}
     680:	d65f03c0 	ret

0000000000000684 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
     684:	d1000403 	sub	x3, x0, #0x1
     688:	d2800002 	mov	x2, #0x0                   	// #0
     68c:	2a0203e0 	mov	w0, w2
     690:	6b02003f 	cmp	w1, w2
     694:	54000089 	b.ls	6a4 <strnlen+0x20>  // b.plast
     698:	91000442 	add	x2, x2, #0x1
     69c:	38626864 	ldrb	w4, [x3, x2]
     6a0:	35ffff64 	cbnz	w4, 68c <strnlen+0x8>
    n++;
  return n;
}
     6a4:	d65f03c0 	ret

00000000000006a8 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     6a8:	d2800003 	mov	x3, #0x0                   	// #0
     6ac:	6b03005f 	cmp	w2, w3
     6b0:	54000048 	b.hi	6b8 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
     6b4:	d65f03c0 	ret
    cdst[i] = c;
     6b8:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
     6bc:	91000463 	add	x3, x3, #0x1
     6c0:	17fffffb 	b	6ac <memset+0x4>

00000000000006c4 <strchr>:

char*
strchr(const char *s, char c)
{
     6c4:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
     6c8:	39400002 	ldrb	w2, [x0]
     6cc:	35000062 	cbnz	w2, 6d8 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
     6d0:	d2800000 	mov	x0, #0x0                   	// #0
}
     6d4:	d65f03c0 	ret
    if(*s == c)
     6d8:	6b01005f 	cmp	w2, w1
     6dc:	54ffffc0 	b.eq	6d4 <strchr+0x10>  // b.none
  for(; *s; s++)
     6e0:	91000400 	add	x0, x0, #0x1
     6e4:	17fffff9 	b	6c8 <strchr+0x4>

00000000000006e8 <gets>:

char*
gets(char *buf, int max)
{
     6e8:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     6ec:	910003fd 	mov	x29, sp
     6f0:	a90153f3 	stp	x19, x20, [sp, #16]
     6f4:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     6f8:	d2800014 	mov	x20, #0x0                   	// #0
{
     6fc:	f9001bf7 	str	x23, [sp, #48]
     700:	2a0103f7 	mov	w23, w1
     704:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
     708:	11000695 	add	w21, w20, #0x1
     70c:	2a1403f6 	mov	w22, w20
     710:	6b1702bf 	cmp	w21, w23
     714:	540000ea 	b.ge	730 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
     718:	91013fe1 	add	x1, sp, #0x4f
     71c:	52800022 	mov	w2, #0x1                   	// #1
     720:	52800000 	mov	w0, #0x0                   	// #0
     724:	94000063 	bl	8b0 <read>
    if(cc < 1)
     728:	7100001f 	cmp	w0, #0x0
     72c:	5400012c 	b.gt	750 <gets+0x68>
  for(i=0; i+1 < max; ){
     730:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
     734:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
     738:	aa1303e0 	mov	x0, x19
     73c:	f9401bf7 	ldr	x23, [sp, #48]
     740:	a94153f3 	ldp	x19, x20, [sp, #16]
     744:	a9425bf5 	ldp	x21, x22, [sp, #32]
     748:	a8c57bfd 	ldp	x29, x30, [sp], #80
     74c:	d65f03c0 	ret
    buf[i++] = c;
     750:	39413fe0 	ldrb	w0, [sp, #79]
     754:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
     758:	91000694 	add	x20, x20, #0x1
     75c:	7100281f 	cmp	w0, #0xa
     760:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
     764:	54fffd21 	b.ne	708 <gets+0x20>  // b.any
     768:	17fffff3 	b	734 <gets+0x4c>

000000000000076c <stat>:

int
stat(const char *n, struct stat *st)
{
     76c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     770:	910003fd 	mov	x29, sp
     774:	a90153f3 	stp	x19, x20, [sp, #16]
     778:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     77c:	52800001 	mov	w1, #0x0                   	// #0
     780:	9400005b 	bl	8ec <open>
  if(fd < 0)
     784:	37f80160 	tbnz	w0, #31, 7b0 <stat+0x44>
    return -1;
  r = fstat(fd, st);
     788:	aa1303e1 	mov	x1, x19
     78c:	2a0003f4 	mov	w20, w0
     790:	94000060 	bl	910 <fstat>
     794:	2a0003f3 	mov	w19, w0
  close(fd);
     798:	2a1403e0 	mov	w0, w20
     79c:	9400004b 	bl	8c8 <close>
  return r;
}
     7a0:	2a1303e0 	mov	w0, w19
     7a4:	a94153f3 	ldp	x19, x20, [sp, #16]
     7a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
     7ac:	d65f03c0 	ret
    return -1;
     7b0:	12800013 	mov	w19, #0xffffffff            	// #-1
     7b4:	17fffffb 	b	7a0 <stat+0x34>

00000000000007b8 <atoi>:

int
atoi(const char *s)
{
     7b8:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
     7bc:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
     7c0:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
     7c4:	39400043 	ldrb	w3, [x2]
     7c8:	5100c061 	sub	w1, w3, #0x30
     7cc:	12001c21 	and	w1, w1, #0xff
     7d0:	7100243f 	cmp	w1, #0x9
     7d4:	54000049 	b.ls	7dc <atoi+0x24>  // b.plast
  return n;
}
     7d8:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
     7dc:	1b040c01 	madd	w1, w0, w4, w3
     7e0:	91000442 	add	x2, x2, #0x1
     7e4:	5100c020 	sub	w0, w1, #0x30
     7e8:	17fffff7 	b	7c4 <atoi+0xc>

00000000000007ec <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     7ec:	eb01001f 	cmp	x0, x1
     7f0:	54000263 	b.cc	83c <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
     7f4:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
     7f8:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
     7fc:	d2800003 	mov	x3, #0x0                   	// #0
     800:	d1000463 	sub	x3, x3, #0x1
     804:	11000464 	add	w4, w3, #0x1
     808:	0b020084 	add	w4, w4, w2
     80c:	7100009f 	cmp	w4, #0x0
     810:	5400014d 	b.le	838 <memmove+0x4c>
      *--dst = *--src;
     814:	38636824 	ldrb	w4, [x1, x3]
     818:	382368a4 	strb	w4, [x5, x3]
     81c:	17fffff9 	b	800 <memmove+0x14>
      *dst++ = *src++;
     820:	38636824 	ldrb	w4, [x1, x3]
     824:	38236804 	strb	w4, [x0, x3]
     828:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
     82c:	4b030044 	sub	w4, w2, w3
     830:	7100009f 	cmp	w4, #0x0
     834:	54ffff6c 	b.gt	820 <memmove+0x34>
  }
  return vdst;
}
     838:	d65f03c0 	ret
     83c:	d2800003 	mov	x3, #0x0                   	// #0
     840:	17fffffb 	b	82c <memmove+0x40>

0000000000000844 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     844:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
     848:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
     84c:	d2800004 	mov	x4, #0x0                   	// #0
     850:	eb02009f 	cmp	x4, x2
     854:	54000061 	b.ne	860 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
     858:	52800000 	mov	w0, #0x0                   	// #0
     85c:	14000007 	b	878 <memcmp+0x34>
    if (*p1 != *p2) {
     860:	38646803 	ldrb	w3, [x0, x4]
     864:	91000484 	add	x4, x4, #0x1
     868:	38646825 	ldrb	w5, [x1, x4]
     86c:	6b05007f 	cmp	w3, w5
     870:	54ffff00 	b.eq	850 <memcmp+0xc>  // b.none
      return *p1 - *p2;
     874:	4b050060 	sub	w0, w3, w5
}
     878:	d65f03c0 	ret

000000000000087c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
     87c:	17ffffdc 	b	7ec <memmove>

0000000000000880 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
     880:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
     884:	d4000001 	svc	#0x0
 ret
     888:	d65f03c0 	ret

000000000000088c <exit>:
.global exit
exit:
 mov x7, #SYS_exit
     88c:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
     890:	d4000001 	svc	#0x0
 ret
     894:	d65f03c0 	ret

0000000000000898 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
     898:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
     89c:	d4000001 	svc	#0x0
 ret
     8a0:	d65f03c0 	ret

00000000000008a4 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
     8a4:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
     8a8:	d4000001 	svc	#0x0
 ret
     8ac:	d65f03c0 	ret

00000000000008b0 <read>:
.global read
read:
 mov x7, #SYS_read
     8b0:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
     8b4:	d4000001 	svc	#0x0
 ret
     8b8:	d65f03c0 	ret

00000000000008bc <write>:
.global write
write:
 mov x7, #SYS_write
     8bc:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
     8c0:	d4000001 	svc	#0x0
 ret
     8c4:	d65f03c0 	ret

00000000000008c8 <close>:
.global close
close:
 mov x7, #SYS_close
     8c8:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
     8cc:	d4000001 	svc	#0x0
 ret
     8d0:	d65f03c0 	ret

00000000000008d4 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
     8d4:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
     8d8:	d4000001 	svc	#0x0
 ret
     8dc:	d65f03c0 	ret

00000000000008e0 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
     8e0:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
     8e4:	d4000001 	svc	#0x0
 ret
     8e8:	d65f03c0 	ret

00000000000008ec <open>:
.global open
open:
 mov x7, #SYS_open
     8ec:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
     8f0:	d4000001 	svc	#0x0
 ret
     8f4:	d65f03c0 	ret

00000000000008f8 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
     8f8:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
     8fc:	d4000001 	svc	#0x0
 ret
     900:	d65f03c0 	ret

0000000000000904 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
     904:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
     908:	d4000001 	svc	#0x0
 ret
     90c:	d65f03c0 	ret

0000000000000910 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
     910:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
     914:	d4000001 	svc	#0x0
 ret
     918:	d65f03c0 	ret

000000000000091c <link>:
.global link
link:
 mov x7, #SYS_link
     91c:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
     920:	d4000001 	svc	#0x0
 ret
     924:	d65f03c0 	ret

0000000000000928 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
     928:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
     92c:	d4000001 	svc	#0x0
 ret
     930:	d65f03c0 	ret

0000000000000934 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
     934:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
     938:	d4000001 	svc	#0x0
 ret
     93c:	d65f03c0 	ret

0000000000000940 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
     940:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
     944:	d4000001 	svc	#0x0
 ret
     948:	d65f03c0 	ret

000000000000094c <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
     94c:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
     950:	d4000001 	svc	#0x0
 ret
     954:	d65f03c0 	ret

0000000000000958 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
     958:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
     95c:	d4000001 	svc	#0x0
 ret
     960:	d65f03c0 	ret

0000000000000964 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
     964:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
     968:	d4000001 	svc	#0x0
 ret
     96c:	d65f03c0 	ret

0000000000000970 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
     970:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
     974:	d4000001 	svc	#0x0
 ret
     978:	d65f03c0 	ret

000000000000097c <ps>:
.global ps
ps:
 mov x7, #SYS_ps
     97c:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
     980:	d4000001 	svc	#0x0
 ret
     984:	d65f03c0 	ret

0000000000000988 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
     988:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
     98c:	d4000001 	svc	#0x0
 ret
     990:	d65f03c0 	ret

0000000000000994 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
     994:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
     998:	d4000001 	svc	#0x0
 ret
     99c:	d65f03c0 	ret

00000000000009a0 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
     9a0:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
     9a4:	d4000001 	svc	#0x0
 ret
     9a8:	d65f03c0 	ret

00000000000009ac <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
     9ac:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
     9b0:	d4000001 	svc	#0x0
 ret
     9b4:	d65f03c0 	ret

00000000000009b8 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
     9b8:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
     9bc:	d4000001 	svc	#0x0
 ret
     9c0:	d65f03c0 	ret

00000000000009c4 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
     9c4:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
     9c8:	d4000001 	svc	#0x0
 ret
     9cc:	d65f03c0 	ret

00000000000009d0 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
     9d0:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
     9d4:	d4000001 	svc	#0x0
 ret
     9d8:	d65f03c0 	ret

00000000000009dc <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
     9dc:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
     9e0:	d4000001 	svc	#0x0
 ret
     9e4:	d65f03c0 	ret

00000000000009e8 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
     9e8:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
     9ec:	d4000001 	svc	#0x0
 ret
     9f0:	d65f03c0 	ret

00000000000009f4 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
     9f4:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
     9f8:	d4000001 	svc	#0x0
 ret
     9fc:	d65f03c0 	ret

0000000000000a00 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
     a00:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
     a04:	d4000001 	svc	#0x0
 ret
     a08:	d65f03c0 	ret

0000000000000a0c <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
     a0c:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
     a10:	d4000001 	svc	#0x0
 ret
     a14:	d65f03c0 	ret

0000000000000a18 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
     a18:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
     a1c:	d4000001 	svc	#0x0
 ret
     a20:	d65f03c0 	ret

0000000000000a24 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
     a24:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
     a28:	d4000001 	svc	#0x0
 ret
     a2c:	d65f03c0 	ret

0000000000000a30 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
     a30:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
     a34:	d4000001 	svc	#0x0
 ret
     a38:	d65f03c0 	ret

0000000000000a3c <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
     a3c:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
     a40:	d4000001 	svc	#0x0
 ret
     a44:	d65f03c0 	ret

0000000000000a48 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
     a48:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
     a4c:	d4000001 	svc	#0x0
 ret
     a50:	d65f03c0 	ret

0000000000000a54 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
     a54:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
     a58:	d4000001 	svc	#0x0
 ret
     a5c:	d65f03c0 	ret

0000000000000a60 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
     a60:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
     a64:	d4000001 	svc	#0x0
 ret
     a68:	d65f03c0 	ret

0000000000000a6c <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
     a6c:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
     a70:	d4000001 	svc	#0x0
 ret
     a74:	d65f03c0 	ret

0000000000000a78 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
     a78:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
     a7c:	d4000001 	svc	#0x0
 ret
     a80:	d65f03c0 	ret

0000000000000a84 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
     a84:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
     a88:	d4000001 	svc	#0x0
 ret
     a8c:	d65f03c0 	ret

0000000000000a90 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
     a90:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
     a94:	d4000001 	svc	#0x0
 ret
     a98:	d65f03c0 	ret

0000000000000a9c <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
     a9c:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
     aa0:	d4000001 	svc	#0x0
 ret
     aa4:	d65f03c0 	ret

0000000000000aa8 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
     aa8:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
     aac:	d4000001 	svc	#0x0
 ret
     ab0:	d65f03c0 	ret

0000000000000ab4 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
     ab4:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
     ab8:	d4000001 	svc	#0x0
 ret
     abc:	d65f03c0 	ret

0000000000000ac0 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
     ac0:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
     ac4:	d4000001 	svc	#0x0
 ret
     ac8:	d65f03c0 	ret

0000000000000acc <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
     acc:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
     ad0:	d4000001 	svc	#0x0
 ret
     ad4:	d65f03c0 	ret

0000000000000ad8 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
     ad8:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
     adc:	d4000001 	svc	#0x0
 ret
     ae0:	d65f03c0 	ret

0000000000000ae4 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
     ae4:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
     ae8:	d4000001 	svc	#0x0
 ret
     aec:	d65f03c0 	ret

0000000000000af0 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
     af0:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
     af4:	d4000001 	svc	#0x0
 ret
     af8:	d65f03c0 	ret

0000000000000afc <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
     afc:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
     b00:	d4000001 	svc	#0x0
 ret
     b04:	d65f03c0 	ret

0000000000000b08 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
     b08:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
     b0c:	d4000001 	svc	#0x0
 ret
     b10:	d65f03c0 	ret

0000000000000b14 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
     b14:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
     b18:	d4000001 	svc	#0x0
 ret
     b1c:	d65f03c0 	ret

0000000000000b20 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
     b20:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
     b24:	d4000001 	svc	#0x0
 ret
     b28:	d65f03c0 	ret

0000000000000b2c <rename>:
.global rename
rename:
 mov x7, #SYS_rename
     b2c:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
     b30:	d4000001 	svc	#0x0
 ret
     b34:	d65f03c0 	ret

0000000000000b38 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
     b38:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
     b3c:	d4000001 	svc	#0x0
 ret
     b40:	d65f03c0 	ret

0000000000000b44 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
     b44:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
     b48:	d4000001 	svc	#0x0
 ret
     b4c:	d65f03c0 	ret

0000000000000b50 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
     b50:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
     b54:	d4000001 	svc	#0x0
 ret
     b58:	d65f03c0 	ret

0000000000000b5c <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
     b5c:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
     b60:	d4000001 	svc	#0x0
 ret
     b64:	d65f03c0 	ret

0000000000000b68 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
     b68:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
     b6c:	d4000001 	svc	#0x0
 ret
     b70:	d65f03c0 	ret

0000000000000b74 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
     b74:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
     b78:	d4000001 	svc	#0x0
 ret
     b7c:	d65f03c0 	ret

0000000000000b80 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
     b80:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
     b84:	d4000001 	svc	#0x0
 ret
     b88:	d65f03c0 	ret

0000000000000b8c <clone>:
.global clone
clone:
 mov x7, #SYS_clone
     b8c:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
     b90:	d4000001 	svc	#0x0
 ret
     b94:	d65f03c0 	ret

0000000000000b98 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
     b98:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
     b9c:	d4000001 	svc	#0x0
 ret
     ba0:	d65f03c0 	ret

0000000000000ba4 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
     ba4:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
     ba8:	d4000001 	svc	#0x0
 ret
     bac:	d65f03c0 	ret

0000000000000bb0 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
     bb0:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
     bb4:	d4000001 	svc	#0x0
 ret
     bb8:	d65f03c0 	ret

0000000000000bbc <socket>:
.global socket
socket:
 mov x7, #SYS_socket
     bbc:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
     bc0:	d4000001 	svc	#0x0
 ret
     bc4:	d65f03c0 	ret

0000000000000bc8 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
     bc8:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
     bcc:	d4000001 	svc	#0x0
 ret
     bd0:	d65f03c0 	ret

0000000000000bd4 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
     bd4:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
     bd8:	d4000001 	svc	#0x0
 ret
     bdc:	d65f03c0 	ret

0000000000000be0 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
     be0:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
     be4:	d4000001 	svc	#0x0
 ret
     be8:	d65f03c0 	ret

0000000000000bec <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
     bec:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
     bf0:	52800022 	mov	w2, #0x1                   	// #1
{
     bf4:	910003fd 	mov	x29, sp
     bf8:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
     bfc:	91007fe1 	add	x1, sp, #0x1f
     c00:	97ffff2f 	bl	8bc <write>
     c04:	7100041f 	cmp	w0, #0x1
}
     c08:	1a9f17e0 	cset	w0, eq	// eq = none
     c0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
     c10:	d65f03c0 	ret

0000000000000c14 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
     c14:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     c18:	910003fd 	mov	x29, sp
     c1c:	a90153f3 	stp	x19, x20, [sp, #16]
     c20:	a9025bf5 	stp	x21, x22, [sp, #32]
     c24:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     c28:	6a417c7f 	tst	w3, w1, lsr #31
     c2c:	54000300 	b.eq	c8c <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
     c30:	4b0103e1 	neg	w1, w1
    neg = 1;
     c34:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
     c38:	b0000003 	adrp	x3, 1000 <printf+0x4>
     c3c:	91079c63 	add	x3, x3, #0x1e7
     c40:	9100c3f5 	add	x21, sp, #0x30
     c44:	d2800000 	mov	x0, #0x0                   	// #0
     c48:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
     c4c:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
     c50:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
     c54:	2a0403e1 	mov	w1, w4
     c58:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
     c5c:	38666866 	ldrb	w6, [x3, x6]
     c60:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
     c64:	91000400 	add	x0, x0, #0x1
     c68:	54ffff09 	b.ls	c48 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
     c6c:	11000493 	add	w19, w4, #0x1
  if(neg)
     c70:	34000085 	cbz	w5, c80 <printint+0x6c>
    buf[i++] = '-';
     c74:	528005a0 	mov	w0, #0x2d                  	// #45
     c78:	38334aa0 	strb	w0, [x21, w19, uxtw]
     c7c:	11000893 	add	w19, w4, #0x2
     c80:	51000673 	sub	w19, w19, #0x1
     c84:	52800014 	mov	w20, #0x0                   	// #0
     c88:	14000008 	b	ca8 <printint+0x94>
  neg = 0;
     c8c:	52800005 	mov	w5, #0x0                   	// #0
     c90:	17ffffea 	b	c38 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
     c94:	38736aa1 	ldrb	w1, [x21, x19]
     c98:	2a1603e0 	mov	w0, w22
     c9c:	d1000673 	sub	x19, x19, #0x1
     ca0:	97ffffd3 	bl	bec <putc>
     ca4:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
     ca8:	3100067f 	cmn	w19, #0x1
     cac:	54ffff41 	b.ne	c94 <printint+0x80>  // b.any
  return written;
}
     cb0:	a9425bf5 	ldp	x21, x22, [sp, #32]
     cb4:	2a1403e0 	mov	w0, w20
     cb8:	a94153f3 	ldp	x19, x20, [sp, #16]
     cbc:	a8c47bfd 	ldp	x29, x30, [sp], #64
     cc0:	d65f03c0 	ret

0000000000000cc4 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
     cc4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
     cc8:	910003fd 	mov	x29, sp
     ccc:	a90153f3 	stp	x19, x20, [sp, #16]
     cd0:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
     cd4:	52800015 	mov	w21, #0x0                   	// #0
{
     cd8:	a90363f7 	stp	x23, x24, [sp, #48]
     cdc:	2a0003f7 	mov	w23, w0
     ce0:	a9046bf9 	stp	x25, x26, [sp, #64]
     ce4:	aa0103f9 	mov	x25, x1

  state = 0;
     ce8:	52800001 	mov	w1, #0x0                   	// #0
{
     cec:	a90573fb 	stp	x27, x28, [sp, #80]
     cf0:	a9406053 	ldp	x19, x24, [x2]
     cf4:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
     cf8:	39400320 	ldrb	w0, [x25]
     cfc:	35000120 	cbnz	w0, d20 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
     d00:	2a1503e0 	mov	w0, w21
     d04:	a94153f3 	ldp	x19, x20, [sp, #16]
     d08:	a9425bf5 	ldp	x21, x22, [sp, #32]
     d0c:	a94363f7 	ldp	x23, x24, [sp, #48]
     d10:	a9446bf9 	ldp	x25, x26, [sp, #64]
     d14:	a94573fb 	ldp	x27, x28, [sp, #80]
     d18:	a8c67bfd 	ldp	x29, x30, [sp], #96
     d1c:	d65f03c0 	ret
    c = fmt[i] & 0xff;
     d20:	2a0003f6 	mov	w22, w0
    if(state == 0){
     d24:	35000101 	cbnz	w1, d44 <vprintf+0x80>
      if(c == '%'){
     d28:	7100941f 	cmp	w0, #0x25
     d2c:	54000ba0 	b.eq	ea0 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
     d30:	2a1603e1 	mov	w1, w22
     d34:	2a1703e0 	mov	w0, w23
     d38:	97ffffad 	bl	bec <putc>
     d3c:	0b0002b5 	add	w21, w21, w0
     d40:	14000057 	b	e9c <vprintf+0x1d8>
      if(c == 'd'){
     d44:	7101901f 	cmp	w0, #0x64
     d48:	540002a1 	b.ne	d9c <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
     d4c:	37f80174 	tbnz	w20, #31, d78 <vprintf+0xb4>
     d50:	91002e76 	add	x22, x19, #0xb
     d54:	2a1403fa 	mov	w26, w20
     d58:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     d5c:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
     d60:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
     d64:	b9400261 	ldr	w1, [x19]
     d68:	2a1703e0 	mov	w0, w23
     d6c:	97ffffaa 	bl	c14 <printint>
        written += putc(fd, va_arg(ap, uint));
     d70:	0b0002b5 	add	w21, w21, w0
     d74:	14000048 	b	e94 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
     d78:	1100229a 	add	w26, w20, #0x8
     d7c:	7100035f 	cmp	w26, #0x0
     d80:	5400008d 	b.le	d90 <vprintf+0xcc>
     d84:	91002e76 	add	x22, x19, #0xb
     d88:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     d8c:	17fffff4 	b	d5c <vprintf+0x98>
     d90:	aa1303f6 	mov	x22, x19
     d94:	8b34c313 	add	x19, x24, w20, sxtw
     d98:	17fffff1 	b	d5c <vprintf+0x98>
      } else if(c == 'l') {
     d9c:	7101b01f 	cmp	w0, #0x6c
     da0:	54000201 	b.ne	de0 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
     da4:	37f800d4 	tbnz	w20, #31, dbc <vprintf+0xf8>
     da8:	91003e76 	add	x22, x19, #0xf
     dac:	2a1403fa 	mov	w26, w20
     db0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     db4:	52800003 	mov	w3, #0x0                   	// #0
     db8:	17ffffea 	b	d60 <vprintf+0x9c>
     dbc:	1100229a 	add	w26, w20, #0x8
     dc0:	7100035f 	cmp	w26, #0x0
     dc4:	5400008d 	b.le	dd4 <vprintf+0x110>
     dc8:	91003e76 	add	x22, x19, #0xf
     dcc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     dd0:	17fffff9 	b	db4 <vprintf+0xf0>
     dd4:	aa1303f6 	mov	x22, x19
     dd8:	8b34c313 	add	x19, x24, w20, sxtw
     ddc:	17fffff6 	b	db4 <vprintf+0xf0>
      } else if(c == 'x') {
     de0:	7101e01f 	cmp	w0, #0x78
     de4:	54000221 	b.ne	e28 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
     de8:	37f800f4 	tbnz	w20, #31, e04 <vprintf+0x140>
     dec:	91002e76 	add	x22, x19, #0xb
     df0:	2a1403fa 	mov	w26, w20
     df4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     df8:	52800003 	mov	w3, #0x0                   	// #0
     dfc:	52800202 	mov	w2, #0x10                  	// #16
     e00:	17ffffd9 	b	d64 <vprintf+0xa0>
     e04:	1100229a 	add	w26, w20, #0x8
     e08:	7100035f 	cmp	w26, #0x0
     e0c:	5400008d 	b.le	e1c <vprintf+0x158>
     e10:	91002e76 	add	x22, x19, #0xb
     e14:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     e18:	17fffff8 	b	df8 <vprintf+0x134>
     e1c:	aa1303f6 	mov	x22, x19
     e20:	8b34c313 	add	x19, x24, w20, sxtw
     e24:	17fffff5 	b	df8 <vprintf+0x134>
      } else if(c == 'p') {
     e28:	7101c01f 	cmp	w0, #0x70
     e2c:	54000521 	b.ne	ed0 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
     e30:	37f803f4 	tbnz	w20, #31, eac <vprintf+0x1e8>
     e34:	91003e76 	add	x22, x19, #0xf
     e38:	2a1403fa 	mov	w26, w20
     e3c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     e40:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
     e44:	52800601 	mov	w1, #0x30                  	// #48
     e48:	2a1703e0 	mov	w0, w23
     e4c:	97ffff68 	bl	bec <putc>
     e50:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     e54:	b000001c 	adrp	x28, 1000 <printf+0x4>
     e58:	91079f9c 	add	x28, x28, #0x1e7
  written += putc(fd, 'x');
     e5c:	2a1703e0 	mov	w0, w23
     e60:	52800f01 	mov	w1, #0x78                  	// #120
     e64:	97ffff62 	bl	bec <putc>
     e68:	0b000273 	add	w19, w19, w0
     e6c:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     e70:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     e74:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     e78:	38606b81 	ldrb	w1, [x28, x0]
     e7c:	2a1703e0 	mov	w0, w23
     e80:	97ffff5b 	bl	bec <putc>
     e84:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     e88:	71000694 	subs	w20, w20, #0x1
     e8c:	54ffff21 	b.ne	e70 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
     e90:	0b1302b5 	add	w21, w21, w19
     e94:	2a1a03f4 	mov	w20, w26
     e98:	aa1603f3 	mov	x19, x22
      state = 0;
     e9c:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
     ea0:	91000739 	add	x25, x25, #0x1
  state = 0;
     ea4:	2a1603e1 	mov	w1, w22
     ea8:	17ffff94 	b	cf8 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
     eac:	1100229a 	add	w26, w20, #0x8
     eb0:	7100035f 	cmp	w26, #0x0
     eb4:	5400008d 	b.le	ec4 <vprintf+0x200>
     eb8:	91003e76 	add	x22, x19, #0xf
     ebc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     ec0:	17ffffe0 	b	e40 <vprintf+0x17c>
     ec4:	aa1303f6 	mov	x22, x19
     ec8:	8b34c313 	add	x19, x24, w20, sxtw
     ecc:	17ffffdd 	b	e40 <vprintf+0x17c>
      } else if(c == 's'){
     ed0:	7101cc1f 	cmp	w0, #0x73
     ed4:	54000381 	b.ne	f44 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
     ed8:	37f80214 	tbnz	w20, #31, f18 <vprintf+0x254>
     edc:	91003e61 	add	x1, x19, #0xf
     ee0:	aa1303e0 	mov	x0, x19
     ee4:	927df033 	and	x19, x1, #0xfffffffffffffff8
     ee8:	f9400016 	ldr	x22, [x0]
          s = "(null)";
     eec:	b0000000 	adrp	x0, 1000 <printf+0x4>
     ef0:	91078000 	add	x0, x0, #0x1e0
     ef4:	f10002df 	cmp	x22, #0x0
     ef8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
     efc:	394002c1 	ldrb	w1, [x22]
     f00:	34fffce1 	cbz	w1, e9c <vprintf+0x1d8>
          written += putc(fd, *s);
     f04:	2a1703e0 	mov	w0, w23
          s++;
     f08:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
     f0c:	97ffff38 	bl	bec <putc>
     f10:	0b0002b5 	add	w21, w21, w0
          s++;
     f14:	17fffffa 	b	efc <vprintf+0x238>
        s = va_arg(ap, char*);
     f18:	11002281 	add	w1, w20, #0x8
     f1c:	7100003f 	cmp	w1, #0x0
     f20:	540000cd 	b.le	f38 <vprintf+0x274>
     f24:	91003e62 	add	x2, x19, #0xf
     f28:	aa1303e0 	mov	x0, x19
     f2c:	2a0103f4 	mov	w20, w1
     f30:	927df053 	and	x19, x2, #0xfffffffffffffff8
     f34:	17ffffed 	b	ee8 <vprintf+0x224>
     f38:	8b34c300 	add	x0, x24, w20, sxtw
     f3c:	2a0103f4 	mov	w20, w1
     f40:	17ffffea 	b	ee8 <vprintf+0x224>
      } else if(c == 'c'){
     f44:	71018c1f 	cmp	w0, #0x63
     f48:	54000241 	b.ne	f90 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
     f4c:	37f80114 	tbnz	w20, #31, f6c <vprintf+0x2a8>
     f50:	91002e76 	add	x22, x19, #0xb
     f54:	2a1403fa 	mov	w26, w20
     f58:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     f5c:	39400261 	ldrb	w1, [x19]
     f60:	2a1703e0 	mov	w0, w23
     f64:	97ffff22 	bl	bec <putc>
     f68:	17ffff82 	b	d70 <vprintf+0xac>
     f6c:	1100229a 	add	w26, w20, #0x8
     f70:	7100035f 	cmp	w26, #0x0
     f74:	5400008d 	b.le	f84 <vprintf+0x2c0>
     f78:	91002e76 	add	x22, x19, #0xb
     f7c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     f80:	17fffff7 	b	f5c <vprintf+0x298>
     f84:	aa1303f6 	mov	x22, x19
     f88:	8b34c313 	add	x19, x24, w20, sxtw
     f8c:	17fffff4 	b	f5c <vprintf+0x298>
      } else if(c == '%'){
     f90:	7100941f 	cmp	w0, #0x25
     f94:	54ffece0 	b.eq	d30 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
     f98:	2a1703e0 	mov	w0, w23
     f9c:	528004a1 	mov	w1, #0x25                  	// #37
     fa0:	97ffff13 	bl	bec <putc>
     fa4:	0b0002b5 	add	w21, w21, w0
     fa8:	17ffff62 	b	d30 <vprintf+0x6c>

0000000000000fac <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
     fac:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
     fb0:	910003fd 	mov	x29, sp
     fb4:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
     fb8:	910203e2 	add	x2, sp, #0x80
     fbc:	a9030be2 	stp	x2, x2, [sp, #48]
     fc0:	910143e2 	add	x2, sp, #0x50
     fc4:	f90023e2 	str	x2, [sp, #64]
     fc8:	128005e2 	mov	w2, #0xffffffd0            	// #-48
     fcc:	b9004be2 	str	w2, [sp, #72]
     fd0:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
     fd4:	a9430fe2 	ldp	x2, x3, [sp, #48]
     fd8:	a9010fe2 	stp	x2, x3, [sp, #16]
     fdc:	a9440fe2 	ldp	x2, x3, [sp, #64]
     fe0:	a9020fe2 	stp	x2, x3, [sp, #32]
     fe4:	910043e2 	add	x2, sp, #0x10
{
     fe8:	a90617e4 	stp	x4, x5, [sp, #96]
     fec:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
     ff0:	97ffff35 	bl	cc4 <vprintf>
  va_end(ap);
  return result;
}
     ff4:	a8c87bfd 	ldp	x29, x30, [sp], #128
     ff8:	d65f03c0 	ret

0000000000000ffc <printf>:

int
printf(const char *fmt, ...)
{
     ffc:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    1000:	910003fd 	mov	x29, sp
    1004:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
    1008:	910243e1 	add	x1, sp, #0x90
    100c:	a90307e1 	stp	x1, x1, [sp, #48]
    1010:	910143e1 	add	x1, sp, #0x50
    1014:	f90023e1 	str	x1, [sp, #64]
    1018:	128006e1 	mov	w1, #0xffffffc8            	// #-56
    101c:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
    1020:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
    1024:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
    1028:	52800020 	mov	w0, #0x1                   	// #1
{
    102c:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
    1030:	a9430fe2 	ldp	x2, x3, [sp, #48]
    1034:	a9010fe2 	stp	x2, x3, [sp, #16]
    1038:	a9440fe2 	ldp	x2, x3, [sp, #64]
    103c:	a9020fe2 	stp	x2, x3, [sp, #32]
    1040:	910043e2 	add	x2, sp, #0x10
{
    1044:	a9079be5 	stp	x5, x6, [sp, #120]
    1048:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
    104c:	97ffff1e 	bl	cc4 <vprintf>
  va_end(ap);
  return result;
}
    1050:	a8c97bfd 	ldp	x29, x30, [sp], #144
    1054:	d65f03c0 	ret
