
user/_posixtest:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  return (void *)42;
}

int
main(void)
{
       0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
  pthread_t first, second;
  void *result = 0;
  struct stat status;
  sem_t semaphore;
  char buffer[6] = {0};
  int loops = 500;
       4:	52803e80 	mov	w0, #0x1f4                 	// #500
  int fd, server;
  struct sockaddr_in address;

  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
       8:	52803482 	mov	w2, #0x1a4                 	// #420
{
       c:	910003fd 	mov	x29, sp
  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
      10:	5280c041 	mov	w1, #0x602                 	// #1538
{
      14:	a90153f3 	stp	x19, x20, [sp, #16]
  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
      18:	b0000014 	adrp	x20, 1000 <pthread_create+0x38>
{
      1c:	a9025bf5 	stp	x21, x22, [sp, #32]
  char buffer[6] = {0};
      20:	2908ffe0 	stp	w0, wzr, [sp, #68]
  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
      24:	91209280 	add	x0, x20, #0x824
  char buffer[6] = {0};
      28:	79009bff 	strh	wzr, [sp, #76]
  void *result = 0;
      2c:	f9002bff 	str	xzr, [sp, #80]
  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
      30:	94000182 	bl	638 <open>
  if(fd < 0 || write(fd, "POSIX", 5) != 5 ||
      34:	37f80400 	tbnz	w0, #31, b4 <main+0xb4>
      38:	2a0003f3 	mov	w19, w0
      3c:	b0000015 	adrp	x21, 1000 <pthread_create+0x38>
      40:	d28000a2 	mov	x2, #0x5                   	// #5
      44:	9120baa1 	add	x1, x21, #0x82e
      48:	94000170 	bl	608 <write>
      4c:	aa0003f6 	mov	x22, x0
      50:	f100141f 	cmp	x0, #0x5
      54:	54000301 	b.ne	b4 <main+0xb4>  // b.any
     lseek(fd, 0, SEEK_SET) != 0 || read(fd, buffer, 5) != 5 ||
      58:	2a1303e0 	mov	w0, w19
      5c:	52800002 	mov	w2, #0x0                   	// #0
      60:	d2800001 	mov	x1, #0x0                   	// #0
      64:	94000232 	bl	92c <lseek>
  if(fd < 0 || write(fd, "POSIX", 5) != 5 ||
      68:	b5000260 	cbnz	x0, b4 <main+0xb4>
     lseek(fd, 0, SEEK_SET) != 0 || read(fd, buffer, 5) != 5 ||
      6c:	aa1603e2 	mov	x2, x22
      70:	910123e1 	add	x1, sp, #0x48
      74:	2a1303e0 	mov	w0, w19
      78:	94000161 	bl	5fc <read>
      7c:	f100141f 	cmp	x0, #0x5
      80:	540001a1 	b.ne	b4 <main+0xb4>  // b.any
     strcmp(buffer, "POSIX") != 0 || fstat(fd, &status) < 0 ||
      84:	9120baa1 	add	x1, x21, #0x82e
      88:	910123e0 	add	x0, sp, #0x48
      8c:	940000b1 	bl	350 <strcmp>
     lseek(fd, 0, SEEK_SET) != 0 || read(fd, buffer, 5) != 5 ||
      90:	35000120 	cbnz	w0, b4 <main+0xb4>
     strcmp(buffer, "POSIX") != 0 || fstat(fd, &status) < 0 ||
      94:	9101a3e1 	add	x1, sp, #0x68
      98:	2a1303e0 	mov	w0, w19
      9c:	94000170 	bl	65c <fstat>
      a0:	37f800a0 	tbnz	w0, #31, b4 <main+0xb4>
      a4:	7940e3e0 	ldrh	w0, [sp, #112]
      a8:	12000800 	and	w0, w0, #0x7
      ac:	7100081f 	cmp	w0, #0x2
      b0:	540000c0 	b.eq	c8 <main+0xc8>  // b.none
     !S_ISREG(status.st_mode)){
    printf("posixtest: file API failed\n");
      b4:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
      b8:	9120d000 	add	x0, x0, #0x834
  close(fd);
  unlink("posix.tmp");

  if(sem_init(&semaphore, 0, 0) < 0 || sem_post(&semaphore) < 0 ||
     sem_wait(&semaphore) < 0 || sem_destroy(&semaphore) < 0){
    printf("posixtest: semaphore API failed\n");
      bc:	94000323 	bl	d48 <printf>
    exit(1);
      c0:	52800020 	mov	w0, #0x1                   	// #1
      c4:	94000145 	bl	5d8 <exit>
  close(fd);
      c8:	2a1303e0 	mov	w0, w19
      cc:	94000152 	bl	614 <close>
  unlink("posix.tmp");
      d0:	91209280 	add	x0, x20, #0x824
      d4:	9400015f 	bl	650 <unlink>
  if(sem_init(&semaphore, 0, 0) < 0 || sem_post(&semaphore) < 0 ||
      d8:	910103e0 	add	x0, sp, #0x40
      dc:	52800002 	mov	w2, #0x0                   	// #0
      e0:	52800001 	mov	w1, #0x0                   	// #0
      e4:	940004a3 	bl	1370 <sem_init>
      e8:	37f80140 	tbnz	w0, #31, 110 <main+0x110>
      ec:	910103e0 	add	x0, sp, #0x40
      f0:	940004bf 	bl	13ec <sem_post>
      f4:	37f800e0 	tbnz	w0, #31, 110 <main+0x110>
     sem_wait(&semaphore) < 0 || sem_destroy(&semaphore) < 0){
      f8:	910103e0 	add	x0, sp, #0x40
      fc:	940004b1 	bl	13c0 <sem_wait>
  if(sem_init(&semaphore, 0, 0) < 0 || sem_post(&semaphore) < 0 ||
     100:	37f80080 	tbnz	w0, #31, 110 <main+0x110>
     sem_wait(&semaphore) < 0 || sem_destroy(&semaphore) < 0){
     104:	910103e0 	add	x0, sp, #0x40
     108:	940004c5 	bl	141c <sem_destroy>
     10c:	36f80080 	tbz	w0, #31, 11c <main+0x11c>
    printf("posixtest: semaphore API failed\n");
     110:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
     114:	91214000 	add	x0, x0, #0x850
     118:	17ffffe9 	b	bc <main+0xbc>
  }

  if(pthread_create(&first, 0, worker, &loops) != 0 ||
     11c:	910113e3 	add	x3, sp, #0x44
     120:	9100e3e0 	add	x0, sp, #0x38
     124:	90000014 	adrp	x20, 0 <main>
     128:	d2800001 	mov	x1, #0x0                   	// #0
     12c:	91096282 	add	x2, x20, #0x258
     130:	b0000013 	adrp	x19, 1000 <pthread_create+0x38>
     134:	91242273 	add	x19, x19, #0x908
     138:	940003a4 	bl	fc8 <pthread_create>
     13c:	35000300 	cbnz	w0, 19c <main+0x19c>
     pthread_create(&second, 0, worker, &loops) != 0 ||
     140:	910113e3 	add	x3, sp, #0x44
     144:	91096282 	add	x2, x20, #0x258
     148:	9100f3e0 	add	x0, sp, #0x3c
     14c:	d2800001 	mov	x1, #0x0                   	// #0
     150:	9400039e 	bl	fc8 <pthread_create>
  if(pthread_create(&first, 0, worker, &loops) != 0 ||
     154:	35000240 	cbnz	w0, 19c <main+0x19c>
     pthread_join(first, &result) != 0 || result != (void *)42 ||
     158:	b9403be0 	ldr	w0, [sp, #56]
     15c:	910143e1 	add	x1, sp, #0x50
     160:	940003e9 	bl	1104 <pthread_join>
     pthread_create(&second, 0, worker, &loops) != 0 ||
     164:	350001c0 	cbnz	w0, 19c <main+0x19c>
     pthread_join(first, &result) != 0 || result != (void *)42 ||
     168:	f9402be0 	ldr	x0, [sp, #80]
     16c:	f100a81f 	cmp	x0, #0x2a
     170:	54000161 	b.ne	19c <main+0x19c>  // b.any
     pthread_join(second, &result) != 0 || result != (void *)42 ||
     174:	b9403fe0 	ldr	w0, [sp, #60]
     178:	910143e1 	add	x1, sp, #0x50
     17c:	940003e2 	bl	1104 <pthread_join>
     pthread_join(first, &result) != 0 || result != (void *)42 ||
     180:	350000e0 	cbnz	w0, 19c <main+0x19c>
     pthread_join(second, &result) != 0 || result != (void *)42 ||
     184:	f9402be0 	ldr	x0, [sp, #80]
     188:	f100a81f 	cmp	x0, #0x2a
     18c:	54000081 	b.ne	19c <main+0x19c>  // b.any
     190:	b9400660 	ldr	w0, [x19, #4]
     194:	710fa01f 	cmp	w0, #0x3e8
     198:	540000c0 	b.eq	1b0 <main+0x1b0>  // b.none
     counter != 1000){
    printf("posixtest: pthread API failed counter=%d\n", counter);
     19c:	b9400661 	ldr	w1, [x19, #4]
     1a0:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
     1a4:	9121c400 	add	x0, x0, #0x871
     1a8:	940002e8 	bl	d48 <printf>
    exit(1);
     1ac:	17ffffc5 	b	c0 <main+0xc0>
  }
  pthread_mutex_destroy(&lock);
     1b0:	aa1303e0 	mov	x0, x19
     1b4:	9400045d 	bl	1328 <pthread_mutex_destroy>

  memset(&address, 0, sizeof(address));
     1b8:	d2800202 	mov	x2, #0x10                  	// #16
     1bc:	52800001 	mov	w1, #0x0                   	// #0
     1c0:	910163e0 	add	x0, sp, #0x58
     1c4:	9400008c 	bl	3f4 <memset>
  address.sin_family = AF_INET;
     1c8:	52800040 	mov	w0, #0x2                   	// #2
     1cc:	7900b3e0 	strh	w0, [sp, #88]
  address.sin_port = htons(18080);
     1d0:	5288d400 	mov	w0, #0x46a0                	// #18080
     1d4:	940004bf 	bl	14d0 <htons>
  address.sin_addr.s_addr = INADDR_ANY;
  server = socket(AF_INET, SOCK_STREAM, 0);
     1d8:	52800002 	mov	w2, #0x0                   	// #0
     1dc:	52800021 	mov	w1, #0x1                   	// #1
  address.sin_port = htons(18080);
     1e0:	7900b7e0 	strh	w0, [sp, #90]
  server = socket(AF_INET, SOCK_STREAM, 0);
     1e4:	52800040 	mov	w0, #0x2                   	// #2
  address.sin_addr.s_addr = INADDR_ANY;
     1e8:	b9005fff 	str	wzr, [sp, #92]
  server = socket(AF_INET, SOCK_STREAM, 0);
     1ec:	940001c7 	bl	908 <socket>
     1f0:	2a0003f4 	mov	w20, w0
  if(server < 0 || bind(server, (struct sockaddr *)&address,
     1f4:	37f80120 	tbnz	w0, #31, 218 <main+0x218>
     1f8:	910163e1 	add	x1, sp, #0x58
     1fc:	52800202 	mov	w2, #0x10                  	// #16
     200:	940001c5 	bl	914 <bind>
     204:	37f800a0 	tbnz	w0, #31, 218 <main+0x218>
                        sizeof(address)) < 0 || listen(server, 4) < 0){
     208:	2a1403e0 	mov	w0, w20
     20c:	52800081 	mov	w1, #0x4                   	// #4
     210:	940001c4 	bl	920 <listen>
     214:	36f80080 	tbz	w0, #31, 224 <main+0x224>
    printf("posixtest: socket/bind/listen API failed\n");
     218:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
     21c:	91226c00 	add	x0, x0, #0x89b
     220:	17ffffa7 	b	bc <main+0xbc>
    exit(1);
  }
  close(server);
     224:	2a1403e0 	mov	w0, w20
     228:	940000fb 	bl	614 <close>
  printf("posixtest: PASS pid=%d tid=%d counter=%d\n",
     22c:	9400011b 	bl	698 <getpid>
     230:	2a0003f4 	mov	w20, w0
     234:	940001b2 	bl	8fc <gettid>
     238:	2a0003e2 	mov	w2, w0
     23c:	b9400663 	ldr	w3, [x19, #4]
     240:	2a1403e1 	mov	w1, w20
     244:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
     248:	91231400 	add	x0, x0, #0x8c5
     24c:	940002bf 	bl	d48 <printf>
         getpid(), gettid(), counter);
  exit(0);
     250:	52800000 	mov	w0, #0x0                   	// #0
     254:	17ffff9c 	b	c4 <main+0xc4>

0000000000000258 <worker>:
{
     258:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     25c:	910003fd 	mov	x29, sp
     260:	a90153f3 	stp	x19, x20, [sp, #16]
    if(pthread_mutex_lock(&lock) != 0)
     264:	b0000013 	adrp	x19, 1000 <pthread_create+0x38>
     268:	91242273 	add	x19, x19, #0x908
{
     26c:	f90013f5 	str	x21, [sp, #32]
  for(int i = 0; i < loops; i++){
     270:	52800014 	mov	w20, #0x0                   	// #0
  int loops = *(int *)argument;
     274:	b9400015 	ldr	w21, [x0]
  for(int i = 0; i < loops; i++){
     278:	6b15029f 	cmp	w20, w21
     27c:	540000cb 	b.lt	294 <worker+0x3c>  // b.tstop
  return (void *)42;
     280:	d2800540 	mov	x0, #0x2a                  	// #42
}
     284:	f94013f5 	ldr	x21, [sp, #32]
     288:	a94153f3 	ldp	x19, x20, [sp, #16]
     28c:	a8c37bfd 	ldp	x29, x30, [sp], #48
     290:	d65f03c0 	ret
    if(pthread_mutex_lock(&lock) != 0)
     294:	aa1303e0 	mov	x0, x19
     298:	940003fb 	bl	1284 <pthread_mutex_lock>
     29c:	35000100 	cbnz	w0, 2bc <worker+0x64>
    counter++;
     2a0:	b9400660 	ldr	w0, [x19, #4]
  for(int i = 0; i < loops; i++){
     2a4:	11000694 	add	w20, w20, #0x1
    counter++;
     2a8:	11000400 	add	w0, w0, #0x1
     2ac:	b9000660 	str	w0, [x19, #4]
    pthread_mutex_unlock(&lock);
     2b0:	aa1303e0 	mov	x0, x19
     2b4:	94000411 	bl	12f8 <pthread_mutex_unlock>
  for(int i = 0; i < loops; i++){
     2b8:	17fffff0 	b	278 <worker+0x20>
      return (void *)1;
     2bc:	d2800020 	mov	x0, #0x1                   	// #1
     2c0:	17fffff1 	b	284 <worker+0x2c>

00000000000002c4 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     2c4:	d2800002 	mov	x2, #0x0                   	// #0
     2c8:	38626823 	ldrb	w3, [x1, x2]
     2cc:	38226803 	strb	w3, [x0, x2]
     2d0:	91000442 	add	x2, x2, #0x1
     2d4:	35ffffa3 	cbnz	w3, 2c8 <strcpy+0x4>
    ;
  return os;
}
     2d8:	d65f03c0 	ret

00000000000002dc <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
     2dc:	d2800003 	mov	x3, #0x0                   	// #0
     2e0:	4b030044 	sub	w4, w2, w3
     2e4:	7100009f 	cmp	w4, #0x0
     2e8:	5400006d 	b.le	2f4 <strncpy+0x18>
     2ec:	38636825 	ldrb	w5, [x1, x3]
     2f0:	350000e5 	cbnz	w5, 30c <strncpy+0x30>
     2f4:	8b030003 	add	x3, x0, x3
     2f8:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
     2fc:	4b010082 	sub	w2, w4, w1
     300:	7100005f 	cmp	w2, #0x0
     304:	540000ac 	b.gt	318 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
     308:	d65f03c0 	ret
    *s++ = *t++;
     30c:	38236805 	strb	w5, [x0, x3]
    n--;
     310:	91000463 	add	x3, x3, #0x1
     314:	17fffff3 	b	2e0 <strncpy+0x4>
    *s++ = 0;
     318:	3821687f 	strb	wzr, [x3, x1]
     31c:	91000421 	add	x1, x1, #0x1
     320:	17fffff7 	b	2fc <strncpy+0x20>

0000000000000324 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
     324:	aa0003e2 	mov	x2, x0
     328:	39400043 	ldrb	w3, [x2]
     32c:	aa0203e4 	mov	x4, x2
    s++;
     330:	91000442 	add	x2, x2, #0x1
  while(*s)
     334:	35ffffa3 	cbnz	w3, 328 <strcat+0x4>
     338:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
     33c:	38626823 	ldrb	w3, [x1, x2]
     340:	38226883 	strb	w3, [x4, x2]
     344:	91000442 	add	x2, x2, #0x1
     348:	35ffffa3 	cbnz	w3, 33c <strcat+0x18>
    ;
  return os;
}
     34c:	d65f03c0 	ret

0000000000000350 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
     350:	d2800002 	mov	x2, #0x0                   	// #0
     354:	38626803 	ldrb	w3, [x0, x2]
     358:	38626824 	ldrb	w4, [x1, x2]
     35c:	34000083 	cbz	w3, 36c <strcmp+0x1c>
     360:	91000442 	add	x2, x2, #0x1
     364:	6b04007f 	cmp	w3, w4
     368:	54ffff60 	b.eq	354 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
     36c:	4b040060 	sub	w0, w3, w4
     370:	d65f03c0 	ret

0000000000000374 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
     374:	340001c2 	cbz	w2, 3ac <strncmp+0x38>
     378:	39400003 	ldrb	w3, [x0]
     37c:	34000083 	cbz	w3, 38c <strncmp+0x18>
     380:	39400024 	ldrb	w4, [x1]
     384:	6b03009f 	cmp	w4, w3
     388:	540000a0 	b.eq	39c <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
     38c:	39400000 	ldrb	w0, [x0]
     390:	39400021 	ldrb	w1, [x1]
     394:	4b010000 	sub	w0, w0, w1
}
     398:	d65f03c0 	ret
    n--, p++, q++;
     39c:	51000442 	sub	w2, w2, #0x1
     3a0:	91000400 	add	x0, x0, #0x1
     3a4:	91000421 	add	x1, x1, #0x1
     3a8:	17fffff3 	b	374 <strncmp>
    return 0;
     3ac:	52800000 	mov	w0, #0x0                   	// #0
     3b0:	17fffffa 	b	398 <strncmp+0x24>

00000000000003b4 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
     3b4:	d1000402 	sub	x2, x0, #0x1
     3b8:	d2800001 	mov	x1, #0x0                   	// #0
     3bc:	aa0103e0 	mov	x0, x1
     3c0:	91000421 	add	x1, x1, #0x1
     3c4:	38616843 	ldrb	w3, [x2, x1]
     3c8:	35ffffa3 	cbnz	w3, 3bc <strlen+0x8>
    ;
  return n;
}
     3cc:	d65f03c0 	ret

00000000000003d0 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
     3d0:	d1000403 	sub	x3, x0, #0x1
     3d4:	d2800002 	mov	x2, #0x0                   	// #0
     3d8:	2a0203e0 	mov	w0, w2
     3dc:	6b02003f 	cmp	w1, w2
     3e0:	54000089 	b.ls	3f0 <strnlen+0x20>  // b.plast
     3e4:	91000442 	add	x2, x2, #0x1
     3e8:	38626864 	ldrb	w4, [x3, x2]
     3ec:	35ffff64 	cbnz	w4, 3d8 <strnlen+0x8>
    n++;
  return n;
}
     3f0:	d65f03c0 	ret

00000000000003f4 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     3f4:	d2800003 	mov	x3, #0x0                   	// #0
     3f8:	6b03005f 	cmp	w2, w3
     3fc:	54000048 	b.hi	404 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
     400:	d65f03c0 	ret
    cdst[i] = c;
     404:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
     408:	91000463 	add	x3, x3, #0x1
     40c:	17fffffb 	b	3f8 <memset+0x4>

0000000000000410 <strchr>:

char*
strchr(const char *s, char c)
{
     410:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
     414:	39400002 	ldrb	w2, [x0]
     418:	35000062 	cbnz	w2, 424 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
     41c:	d2800000 	mov	x0, #0x0                   	// #0
}
     420:	d65f03c0 	ret
    if(*s == c)
     424:	6b01005f 	cmp	w2, w1
     428:	54ffffc0 	b.eq	420 <strchr+0x10>  // b.none
  for(; *s; s++)
     42c:	91000400 	add	x0, x0, #0x1
     430:	17fffff9 	b	414 <strchr+0x4>

0000000000000434 <gets>:

char*
gets(char *buf, int max)
{
     434:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     438:	910003fd 	mov	x29, sp
     43c:	a90153f3 	stp	x19, x20, [sp, #16]
     440:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     444:	d2800014 	mov	x20, #0x0                   	// #0
{
     448:	f9001bf7 	str	x23, [sp, #48]
     44c:	2a0103f7 	mov	w23, w1
     450:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
     454:	11000695 	add	w21, w20, #0x1
     458:	2a1403f6 	mov	w22, w20
     45c:	6b1702bf 	cmp	w21, w23
     460:	540000ea 	b.ge	47c <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
     464:	91013fe1 	add	x1, sp, #0x4f
     468:	52800022 	mov	w2, #0x1                   	// #1
     46c:	52800000 	mov	w0, #0x0                   	// #0
     470:	94000063 	bl	5fc <read>
    if(cc < 1)
     474:	7100001f 	cmp	w0, #0x0
     478:	5400012c 	b.gt	49c <gets+0x68>
  for(i=0; i+1 < max; ){
     47c:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
     480:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
     484:	aa1303e0 	mov	x0, x19
     488:	f9401bf7 	ldr	x23, [sp, #48]
     48c:	a94153f3 	ldp	x19, x20, [sp, #16]
     490:	a9425bf5 	ldp	x21, x22, [sp, #32]
     494:	a8c57bfd 	ldp	x29, x30, [sp], #80
     498:	d65f03c0 	ret
    buf[i++] = c;
     49c:	39413fe0 	ldrb	w0, [sp, #79]
     4a0:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
     4a4:	91000694 	add	x20, x20, #0x1
     4a8:	7100281f 	cmp	w0, #0xa
     4ac:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
     4b0:	54fffd21 	b.ne	454 <gets+0x20>  // b.any
     4b4:	17fffff3 	b	480 <gets+0x4c>

00000000000004b8 <stat>:

int
stat(const char *n, struct stat *st)
{
     4b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     4bc:	910003fd 	mov	x29, sp
     4c0:	a90153f3 	stp	x19, x20, [sp, #16]
     4c4:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     4c8:	52800001 	mov	w1, #0x0                   	// #0
     4cc:	9400005b 	bl	638 <open>
  if(fd < 0)
     4d0:	37f80160 	tbnz	w0, #31, 4fc <stat+0x44>
    return -1;
  r = fstat(fd, st);
     4d4:	aa1303e1 	mov	x1, x19
     4d8:	2a0003f4 	mov	w20, w0
     4dc:	94000060 	bl	65c <fstat>
     4e0:	2a0003f3 	mov	w19, w0
  close(fd);
     4e4:	2a1403e0 	mov	w0, w20
     4e8:	9400004b 	bl	614 <close>
  return r;
}
     4ec:	2a1303e0 	mov	w0, w19
     4f0:	a94153f3 	ldp	x19, x20, [sp, #16]
     4f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
     4f8:	d65f03c0 	ret
    return -1;
     4fc:	12800013 	mov	w19, #0xffffffff            	// #-1
     500:	17fffffb 	b	4ec <stat+0x34>

0000000000000504 <atoi>:

int
atoi(const char *s)
{
     504:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
     508:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
     50c:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
     510:	39400043 	ldrb	w3, [x2]
     514:	5100c061 	sub	w1, w3, #0x30
     518:	12001c21 	and	w1, w1, #0xff
     51c:	7100243f 	cmp	w1, #0x9
     520:	54000049 	b.ls	528 <atoi+0x24>  // b.plast
  return n;
}
     524:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
     528:	1b040c01 	madd	w1, w0, w4, w3
     52c:	91000442 	add	x2, x2, #0x1
     530:	5100c020 	sub	w0, w1, #0x30
     534:	17fffff7 	b	510 <atoi+0xc>

0000000000000538 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     538:	eb01001f 	cmp	x0, x1
     53c:	54000263 	b.cc	588 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
     540:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
     544:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
     548:	d2800003 	mov	x3, #0x0                   	// #0
     54c:	d1000463 	sub	x3, x3, #0x1
     550:	11000464 	add	w4, w3, #0x1
     554:	0b020084 	add	w4, w4, w2
     558:	7100009f 	cmp	w4, #0x0
     55c:	5400014d 	b.le	584 <memmove+0x4c>
      *--dst = *--src;
     560:	38636824 	ldrb	w4, [x1, x3]
     564:	382368a4 	strb	w4, [x5, x3]
     568:	17fffff9 	b	54c <memmove+0x14>
      *dst++ = *src++;
     56c:	38636824 	ldrb	w4, [x1, x3]
     570:	38236804 	strb	w4, [x0, x3]
     574:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
     578:	4b030044 	sub	w4, w2, w3
     57c:	7100009f 	cmp	w4, #0x0
     580:	54ffff6c 	b.gt	56c <memmove+0x34>
  }
  return vdst;
}
     584:	d65f03c0 	ret
     588:	d2800003 	mov	x3, #0x0                   	// #0
     58c:	17fffffb 	b	578 <memmove+0x40>

0000000000000590 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     590:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
     594:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
     598:	d2800004 	mov	x4, #0x0                   	// #0
     59c:	eb02009f 	cmp	x4, x2
     5a0:	54000061 	b.ne	5ac <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
     5a4:	52800000 	mov	w0, #0x0                   	// #0
     5a8:	14000007 	b	5c4 <memcmp+0x34>
    if (*p1 != *p2) {
     5ac:	38646803 	ldrb	w3, [x0, x4]
     5b0:	91000484 	add	x4, x4, #0x1
     5b4:	38646825 	ldrb	w5, [x1, x4]
     5b8:	6b05007f 	cmp	w3, w5
     5bc:	54ffff00 	b.eq	59c <memcmp+0xc>  // b.none
      return *p1 - *p2;
     5c0:	4b050060 	sub	w0, w3, w5
}
     5c4:	d65f03c0 	ret

00000000000005c8 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
     5c8:	17ffffdc 	b	538 <memmove>

00000000000005cc <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
     5cc:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
     5d0:	d4000001 	svc	#0x0
 ret
     5d4:	d65f03c0 	ret

00000000000005d8 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
     5d8:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
     5dc:	d4000001 	svc	#0x0
 ret
     5e0:	d65f03c0 	ret

00000000000005e4 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
     5e4:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
     5e8:	d4000001 	svc	#0x0
 ret
     5ec:	d65f03c0 	ret

00000000000005f0 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
     5f0:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
     5f4:	d4000001 	svc	#0x0
 ret
     5f8:	d65f03c0 	ret

00000000000005fc <read>:
.global read
read:
 mov x7, #SYS_read
     5fc:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
     600:	d4000001 	svc	#0x0
 ret
     604:	d65f03c0 	ret

0000000000000608 <write>:
.global write
write:
 mov x7, #SYS_write
     608:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
     60c:	d4000001 	svc	#0x0
 ret
     610:	d65f03c0 	ret

0000000000000614 <close>:
.global close
close:
 mov x7, #SYS_close
     614:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
     618:	d4000001 	svc	#0x0
 ret
     61c:	d65f03c0 	ret

0000000000000620 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
     620:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
     624:	d4000001 	svc	#0x0
 ret
     628:	d65f03c0 	ret

000000000000062c <exec>:
.global exec
exec:
 mov x7, #SYS_exec
     62c:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
     630:	d4000001 	svc	#0x0
 ret
     634:	d65f03c0 	ret

0000000000000638 <open>:
.global open
open:
 mov x7, #SYS_open
     638:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
     63c:	d4000001 	svc	#0x0
 ret
     640:	d65f03c0 	ret

0000000000000644 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
     644:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
     648:	d4000001 	svc	#0x0
 ret
     64c:	d65f03c0 	ret

0000000000000650 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
     650:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
     654:	d4000001 	svc	#0x0
 ret
     658:	d65f03c0 	ret

000000000000065c <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
     65c:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
     660:	d4000001 	svc	#0x0
 ret
     664:	d65f03c0 	ret

0000000000000668 <link>:
.global link
link:
 mov x7, #SYS_link
     668:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
     66c:	d4000001 	svc	#0x0
 ret
     670:	d65f03c0 	ret

0000000000000674 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
     674:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
     678:	d4000001 	svc	#0x0
 ret
     67c:	d65f03c0 	ret

0000000000000680 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
     680:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
     684:	d4000001 	svc	#0x0
 ret
     688:	d65f03c0 	ret

000000000000068c <dup>:
.global dup
dup:
 mov x7, #SYS_dup
     68c:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
     690:	d4000001 	svc	#0x0
 ret
     694:	d65f03c0 	ret

0000000000000698 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
     698:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
     69c:	d4000001 	svc	#0x0
 ret
     6a0:	d65f03c0 	ret

00000000000006a4 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
     6a4:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
     6a8:	d4000001 	svc	#0x0
 ret
     6ac:	d65f03c0 	ret

00000000000006b0 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
     6b0:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
     6b4:	d4000001 	svc	#0x0
 ret
     6b8:	d65f03c0 	ret

00000000000006bc <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
     6bc:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
     6c0:	d4000001 	svc	#0x0
 ret
     6c4:	d65f03c0 	ret

00000000000006c8 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
     6c8:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
     6cc:	d4000001 	svc	#0x0
 ret
     6d0:	d65f03c0 	ret

00000000000006d4 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
     6d4:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
     6d8:	d4000001 	svc	#0x0
 ret
     6dc:	d65f03c0 	ret

00000000000006e0 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
     6e0:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
     6e4:	d4000001 	svc	#0x0
 ret
     6e8:	d65f03c0 	ret

00000000000006ec <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
     6ec:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
     6f0:	d4000001 	svc	#0x0
 ret
     6f4:	d65f03c0 	ret

00000000000006f8 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
     6f8:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
     6fc:	d4000001 	svc	#0x0
 ret
     700:	d65f03c0 	ret

0000000000000704 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
     704:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
     708:	d4000001 	svc	#0x0
 ret
     70c:	d65f03c0 	ret

0000000000000710 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
     710:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
     714:	d4000001 	svc	#0x0
 ret
     718:	d65f03c0 	ret

000000000000071c <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
     71c:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
     720:	d4000001 	svc	#0x0
 ret
     724:	d65f03c0 	ret

0000000000000728 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
     728:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
     72c:	d4000001 	svc	#0x0
 ret
     730:	d65f03c0 	ret

0000000000000734 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
     734:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
     738:	d4000001 	svc	#0x0
 ret
     73c:	d65f03c0 	ret

0000000000000740 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
     740:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
     744:	d4000001 	svc	#0x0
 ret
     748:	d65f03c0 	ret

000000000000074c <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
     74c:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
     750:	d4000001 	svc	#0x0
 ret
     754:	d65f03c0 	ret

0000000000000758 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
     758:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
     75c:	d4000001 	svc	#0x0
 ret
     760:	d65f03c0 	ret

0000000000000764 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
     764:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
     768:	d4000001 	svc	#0x0
 ret
     76c:	d65f03c0 	ret

0000000000000770 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
     770:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
     774:	d4000001 	svc	#0x0
 ret
     778:	d65f03c0 	ret

000000000000077c <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
     77c:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
     780:	d4000001 	svc	#0x0
 ret
     784:	d65f03c0 	ret

0000000000000788 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
     788:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
     78c:	d4000001 	svc	#0x0
 ret
     790:	d65f03c0 	ret

0000000000000794 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
     794:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
     798:	d4000001 	svc	#0x0
 ret
     79c:	d65f03c0 	ret

00000000000007a0 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
     7a0:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
     7a4:	d4000001 	svc	#0x0
 ret
     7a8:	d65f03c0 	ret

00000000000007ac <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
     7ac:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
     7b0:	d4000001 	svc	#0x0
 ret
     7b4:	d65f03c0 	ret

00000000000007b8 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
     7b8:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
     7bc:	d4000001 	svc	#0x0
 ret
     7c0:	d65f03c0 	ret

00000000000007c4 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
     7c4:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
     7c8:	d4000001 	svc	#0x0
 ret
     7cc:	d65f03c0 	ret

00000000000007d0 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
     7d0:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
     7d4:	d4000001 	svc	#0x0
 ret
     7d8:	d65f03c0 	ret

00000000000007dc <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
     7dc:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
     7e0:	d4000001 	svc	#0x0
 ret
     7e4:	d65f03c0 	ret

00000000000007e8 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
     7e8:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
     7ec:	d4000001 	svc	#0x0
 ret
     7f0:	d65f03c0 	ret

00000000000007f4 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
     7f4:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
     7f8:	d4000001 	svc	#0x0
 ret
     7fc:	d65f03c0 	ret

0000000000000800 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
     800:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
     804:	d4000001 	svc	#0x0
 ret
     808:	d65f03c0 	ret

000000000000080c <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
     80c:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
     810:	d4000001 	svc	#0x0
 ret
     814:	d65f03c0 	ret

0000000000000818 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
     818:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
     81c:	d4000001 	svc	#0x0
 ret
     820:	d65f03c0 	ret

0000000000000824 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
     824:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
     828:	d4000001 	svc	#0x0
 ret
     82c:	d65f03c0 	ret

0000000000000830 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
     830:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
     834:	d4000001 	svc	#0x0
 ret
     838:	d65f03c0 	ret

000000000000083c <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
     83c:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
     840:	d4000001 	svc	#0x0
 ret
     844:	d65f03c0 	ret

0000000000000848 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
     848:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
     84c:	d4000001 	svc	#0x0
 ret
     850:	d65f03c0 	ret

0000000000000854 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
     854:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
     858:	d4000001 	svc	#0x0
 ret
     85c:	d65f03c0 	ret

0000000000000860 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
     860:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
     864:	d4000001 	svc	#0x0
 ret
     868:	d65f03c0 	ret

000000000000086c <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
     86c:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
     870:	d4000001 	svc	#0x0
 ret
     874:	d65f03c0 	ret

0000000000000878 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
     878:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
     87c:	d4000001 	svc	#0x0
 ret
     880:	d65f03c0 	ret

0000000000000884 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
     884:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
     888:	d4000001 	svc	#0x0
 ret
     88c:	d65f03c0 	ret

0000000000000890 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
     890:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
     894:	d4000001 	svc	#0x0
 ret
     898:	d65f03c0 	ret

000000000000089c <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
     89c:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
     8a0:	d4000001 	svc	#0x0
 ret
     8a4:	d65f03c0 	ret

00000000000008a8 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
     8a8:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
     8ac:	d4000001 	svc	#0x0
 ret
     8b0:	d65f03c0 	ret

00000000000008b4 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
     8b4:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
     8b8:	d4000001 	svc	#0x0
 ret
     8bc:	d65f03c0 	ret

00000000000008c0 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
     8c0:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
     8c4:	d4000001 	svc	#0x0
 ret
     8c8:	d65f03c0 	ret

00000000000008cc <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
     8cc:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
     8d0:	d4000001 	svc	#0x0
 ret
     8d4:	d65f03c0 	ret

00000000000008d8 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
     8d8:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
     8dc:	d4000001 	svc	#0x0
 ret
     8e0:	d65f03c0 	ret

00000000000008e4 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
     8e4:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
     8e8:	d4000001 	svc	#0x0
 ret
     8ec:	d65f03c0 	ret

00000000000008f0 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
     8f0:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
     8f4:	d4000001 	svc	#0x0
 ret
     8f8:	d65f03c0 	ret

00000000000008fc <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
     8fc:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
     900:	d4000001 	svc	#0x0
 ret
     904:	d65f03c0 	ret

0000000000000908 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
     908:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
     90c:	d4000001 	svc	#0x0
 ret
     910:	d65f03c0 	ret

0000000000000914 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
     914:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
     918:	d4000001 	svc	#0x0
 ret
     91c:	d65f03c0 	ret

0000000000000920 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
     920:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
     924:	d4000001 	svc	#0x0
 ret
     928:	d65f03c0 	ret

000000000000092c <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
     92c:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
     930:	d4000001 	svc	#0x0
 ret
     934:	d65f03c0 	ret

0000000000000938 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
     938:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
     93c:	52800022 	mov	w2, #0x1                   	// #1
{
     940:	910003fd 	mov	x29, sp
     944:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
     948:	91007fe1 	add	x1, sp, #0x1f
     94c:	97ffff2f 	bl	608 <write>
     950:	7100041f 	cmp	w0, #0x1
}
     954:	1a9f17e0 	cset	w0, eq	// eq = none
     958:	a8c27bfd 	ldp	x29, x30, [sp], #32
     95c:	d65f03c0 	ret

0000000000000960 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
     960:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     964:	910003fd 	mov	x29, sp
     968:	a90153f3 	stp	x19, x20, [sp, #16]
     96c:	a9025bf5 	stp	x21, x22, [sp, #32]
     970:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     974:	6a417c7f 	tst	w3, w1, lsr #31
     978:	54000300 	b.eq	9d8 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
     97c:	4b0103e1 	neg	w1, w1
    neg = 1;
     980:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
     984:	b0000003 	adrp	x3, 1000 <pthread_create+0x38>
     988:	9123d863 	add	x3, x3, #0x8f6
     98c:	9100c3f5 	add	x21, sp, #0x30
     990:	d2800000 	mov	x0, #0x0                   	// #0
     994:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
     998:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
     99c:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
     9a0:	2a0403e1 	mov	w1, w4
     9a4:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
     9a8:	38666866 	ldrb	w6, [x3, x6]
     9ac:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
     9b0:	91000400 	add	x0, x0, #0x1
     9b4:	54ffff09 	b.ls	994 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
     9b8:	11000493 	add	w19, w4, #0x1
  if(neg)
     9bc:	34000085 	cbz	w5, 9cc <printint+0x6c>
    buf[i++] = '-';
     9c0:	528005a0 	mov	w0, #0x2d                  	// #45
     9c4:	38334aa0 	strb	w0, [x21, w19, uxtw]
     9c8:	11000893 	add	w19, w4, #0x2
     9cc:	51000673 	sub	w19, w19, #0x1
     9d0:	52800014 	mov	w20, #0x0                   	// #0
     9d4:	14000008 	b	9f4 <printint+0x94>
  neg = 0;
     9d8:	52800005 	mov	w5, #0x0                   	// #0
     9dc:	17ffffea 	b	984 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
     9e0:	38736aa1 	ldrb	w1, [x21, x19]
     9e4:	2a1603e0 	mov	w0, w22
     9e8:	d1000673 	sub	x19, x19, #0x1
     9ec:	97ffffd3 	bl	938 <putc>
     9f0:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
     9f4:	3100067f 	cmn	w19, #0x1
     9f8:	54ffff41 	b.ne	9e0 <printint+0x80>  // b.any
  return written;
}
     9fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
     a00:	2a1403e0 	mov	w0, w20
     a04:	a94153f3 	ldp	x19, x20, [sp, #16]
     a08:	a8c47bfd 	ldp	x29, x30, [sp], #64
     a0c:	d65f03c0 	ret

0000000000000a10 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
     a10:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
     a14:	910003fd 	mov	x29, sp
     a18:	a90153f3 	stp	x19, x20, [sp, #16]
     a1c:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
     a20:	52800015 	mov	w21, #0x0                   	// #0
{
     a24:	a90363f7 	stp	x23, x24, [sp, #48]
     a28:	2a0003f7 	mov	w23, w0
     a2c:	a9046bf9 	stp	x25, x26, [sp, #64]
     a30:	aa0103f9 	mov	x25, x1

  state = 0;
     a34:	52800001 	mov	w1, #0x0                   	// #0
{
     a38:	a90573fb 	stp	x27, x28, [sp, #80]
     a3c:	a9406053 	ldp	x19, x24, [x2]
     a40:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
     a44:	39400320 	ldrb	w0, [x25]
     a48:	35000120 	cbnz	w0, a6c <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
     a4c:	2a1503e0 	mov	w0, w21
     a50:	a94153f3 	ldp	x19, x20, [sp, #16]
     a54:	a9425bf5 	ldp	x21, x22, [sp, #32]
     a58:	a94363f7 	ldp	x23, x24, [sp, #48]
     a5c:	a9446bf9 	ldp	x25, x26, [sp, #64]
     a60:	a94573fb 	ldp	x27, x28, [sp, #80]
     a64:	a8c67bfd 	ldp	x29, x30, [sp], #96
     a68:	d65f03c0 	ret
    c = fmt[i] & 0xff;
     a6c:	2a0003f6 	mov	w22, w0
    if(state == 0){
     a70:	35000101 	cbnz	w1, a90 <vprintf+0x80>
      if(c == '%'){
     a74:	7100941f 	cmp	w0, #0x25
     a78:	54000ba0 	b.eq	bec <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
     a7c:	2a1603e1 	mov	w1, w22
     a80:	2a1703e0 	mov	w0, w23
     a84:	97ffffad 	bl	938 <putc>
     a88:	0b0002b5 	add	w21, w21, w0
     a8c:	14000057 	b	be8 <vprintf+0x1d8>
      if(c == 'd'){
     a90:	7101901f 	cmp	w0, #0x64
     a94:	540002a1 	b.ne	ae8 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
     a98:	37f80174 	tbnz	w20, #31, ac4 <vprintf+0xb4>
     a9c:	91002e76 	add	x22, x19, #0xb
     aa0:	2a1403fa 	mov	w26, w20
     aa4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     aa8:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
     aac:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
     ab0:	b9400261 	ldr	w1, [x19]
     ab4:	2a1703e0 	mov	w0, w23
     ab8:	97ffffaa 	bl	960 <printint>
        written += putc(fd, va_arg(ap, uint));
     abc:	0b0002b5 	add	w21, w21, w0
     ac0:	14000048 	b	be0 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
     ac4:	1100229a 	add	w26, w20, #0x8
     ac8:	7100035f 	cmp	w26, #0x0
     acc:	5400008d 	b.le	adc <vprintf+0xcc>
     ad0:	91002e76 	add	x22, x19, #0xb
     ad4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     ad8:	17fffff4 	b	aa8 <vprintf+0x98>
     adc:	aa1303f6 	mov	x22, x19
     ae0:	8b34c313 	add	x19, x24, w20, sxtw
     ae4:	17fffff1 	b	aa8 <vprintf+0x98>
      } else if(c == 'l') {
     ae8:	7101b01f 	cmp	w0, #0x6c
     aec:	54000201 	b.ne	b2c <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
     af0:	37f800d4 	tbnz	w20, #31, b08 <vprintf+0xf8>
     af4:	91003e76 	add	x22, x19, #0xf
     af8:	2a1403fa 	mov	w26, w20
     afc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     b00:	52800003 	mov	w3, #0x0                   	// #0
     b04:	17ffffea 	b	aac <vprintf+0x9c>
     b08:	1100229a 	add	w26, w20, #0x8
     b0c:	7100035f 	cmp	w26, #0x0
     b10:	5400008d 	b.le	b20 <vprintf+0x110>
     b14:	91003e76 	add	x22, x19, #0xf
     b18:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     b1c:	17fffff9 	b	b00 <vprintf+0xf0>
     b20:	aa1303f6 	mov	x22, x19
     b24:	8b34c313 	add	x19, x24, w20, sxtw
     b28:	17fffff6 	b	b00 <vprintf+0xf0>
      } else if(c == 'x') {
     b2c:	7101e01f 	cmp	w0, #0x78
     b30:	54000221 	b.ne	b74 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
     b34:	37f800f4 	tbnz	w20, #31, b50 <vprintf+0x140>
     b38:	91002e76 	add	x22, x19, #0xb
     b3c:	2a1403fa 	mov	w26, w20
     b40:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     b44:	52800003 	mov	w3, #0x0                   	// #0
     b48:	52800202 	mov	w2, #0x10                  	// #16
     b4c:	17ffffd9 	b	ab0 <vprintf+0xa0>
     b50:	1100229a 	add	w26, w20, #0x8
     b54:	7100035f 	cmp	w26, #0x0
     b58:	5400008d 	b.le	b68 <vprintf+0x158>
     b5c:	91002e76 	add	x22, x19, #0xb
     b60:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     b64:	17fffff8 	b	b44 <vprintf+0x134>
     b68:	aa1303f6 	mov	x22, x19
     b6c:	8b34c313 	add	x19, x24, w20, sxtw
     b70:	17fffff5 	b	b44 <vprintf+0x134>
      } else if(c == 'p') {
     b74:	7101c01f 	cmp	w0, #0x70
     b78:	54000521 	b.ne	c1c <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
     b7c:	37f803f4 	tbnz	w20, #31, bf8 <vprintf+0x1e8>
     b80:	91003e76 	add	x22, x19, #0xf
     b84:	2a1403fa 	mov	w26, w20
     b88:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     b8c:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
     b90:	52800601 	mov	w1, #0x30                  	// #48
     b94:	2a1703e0 	mov	w0, w23
     b98:	97ffff68 	bl	938 <putc>
     b9c:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     ba0:	b000001c 	adrp	x28, 1000 <pthread_create+0x38>
     ba4:	9123db9c 	add	x28, x28, #0x8f6
  written += putc(fd, 'x');
     ba8:	2a1703e0 	mov	w0, w23
     bac:	52800f01 	mov	w1, #0x78                  	// #120
     bb0:	97ffff62 	bl	938 <putc>
     bb4:	0b000273 	add	w19, w19, w0
     bb8:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     bbc:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     bc0:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     bc4:	38606b81 	ldrb	w1, [x28, x0]
     bc8:	2a1703e0 	mov	w0, w23
     bcc:	97ffff5b 	bl	938 <putc>
     bd0:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     bd4:	71000694 	subs	w20, w20, #0x1
     bd8:	54ffff21 	b.ne	bbc <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
     bdc:	0b1302b5 	add	w21, w21, w19
     be0:	2a1a03f4 	mov	w20, w26
     be4:	aa1603f3 	mov	x19, x22
      state = 0;
     be8:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
     bec:	91000739 	add	x25, x25, #0x1
  state = 0;
     bf0:	2a1603e1 	mov	w1, w22
     bf4:	17ffff94 	b	a44 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
     bf8:	1100229a 	add	w26, w20, #0x8
     bfc:	7100035f 	cmp	w26, #0x0
     c00:	5400008d 	b.le	c10 <vprintf+0x200>
     c04:	91003e76 	add	x22, x19, #0xf
     c08:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     c0c:	17ffffe0 	b	b8c <vprintf+0x17c>
     c10:	aa1303f6 	mov	x22, x19
     c14:	8b34c313 	add	x19, x24, w20, sxtw
     c18:	17ffffdd 	b	b8c <vprintf+0x17c>
      } else if(c == 's'){
     c1c:	7101cc1f 	cmp	w0, #0x73
     c20:	54000381 	b.ne	c90 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
     c24:	37f80214 	tbnz	w20, #31, c64 <vprintf+0x254>
     c28:	91003e61 	add	x1, x19, #0xf
     c2c:	aa1303e0 	mov	x0, x19
     c30:	927df033 	and	x19, x1, #0xfffffffffffffff8
     c34:	f9400016 	ldr	x22, [x0]
          s = "(null)";
     c38:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
     c3c:	9123bc00 	add	x0, x0, #0x8ef
     c40:	f10002df 	cmp	x22, #0x0
     c44:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
     c48:	394002c1 	ldrb	w1, [x22]
     c4c:	34fffce1 	cbz	w1, be8 <vprintf+0x1d8>
          written += putc(fd, *s);
     c50:	2a1703e0 	mov	w0, w23
          s++;
     c54:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
     c58:	97ffff38 	bl	938 <putc>
     c5c:	0b0002b5 	add	w21, w21, w0
          s++;
     c60:	17fffffa 	b	c48 <vprintf+0x238>
        s = va_arg(ap, char*);
     c64:	11002281 	add	w1, w20, #0x8
     c68:	7100003f 	cmp	w1, #0x0
     c6c:	540000cd 	b.le	c84 <vprintf+0x274>
     c70:	91003e62 	add	x2, x19, #0xf
     c74:	aa1303e0 	mov	x0, x19
     c78:	2a0103f4 	mov	w20, w1
     c7c:	927df053 	and	x19, x2, #0xfffffffffffffff8
     c80:	17ffffed 	b	c34 <vprintf+0x224>
     c84:	8b34c300 	add	x0, x24, w20, sxtw
     c88:	2a0103f4 	mov	w20, w1
     c8c:	17ffffea 	b	c34 <vprintf+0x224>
      } else if(c == 'c'){
     c90:	71018c1f 	cmp	w0, #0x63
     c94:	54000241 	b.ne	cdc <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
     c98:	37f80114 	tbnz	w20, #31, cb8 <vprintf+0x2a8>
     c9c:	91002e76 	add	x22, x19, #0xb
     ca0:	2a1403fa 	mov	w26, w20
     ca4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     ca8:	39400261 	ldrb	w1, [x19]
     cac:	2a1703e0 	mov	w0, w23
     cb0:	97ffff22 	bl	938 <putc>
     cb4:	17ffff82 	b	abc <vprintf+0xac>
     cb8:	1100229a 	add	w26, w20, #0x8
     cbc:	7100035f 	cmp	w26, #0x0
     cc0:	5400008d 	b.le	cd0 <vprintf+0x2c0>
     cc4:	91002e76 	add	x22, x19, #0xb
     cc8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
     ccc:	17fffff7 	b	ca8 <vprintf+0x298>
     cd0:	aa1303f6 	mov	x22, x19
     cd4:	8b34c313 	add	x19, x24, w20, sxtw
     cd8:	17fffff4 	b	ca8 <vprintf+0x298>
      } else if(c == '%'){
     cdc:	7100941f 	cmp	w0, #0x25
     ce0:	54ffece0 	b.eq	a7c <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
     ce4:	2a1703e0 	mov	w0, w23
     ce8:	528004a1 	mov	w1, #0x25                  	// #37
     cec:	97ffff13 	bl	938 <putc>
     cf0:	0b0002b5 	add	w21, w21, w0
     cf4:	17ffff62 	b	a7c <vprintf+0x6c>

0000000000000cf8 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
     cf8:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
     cfc:	910003fd 	mov	x29, sp
     d00:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
     d04:	910203e2 	add	x2, sp, #0x80
     d08:	a9030be2 	stp	x2, x2, [sp, #48]
     d0c:	910143e2 	add	x2, sp, #0x50
     d10:	f90023e2 	str	x2, [sp, #64]
     d14:	128005e2 	mov	w2, #0xffffffd0            	// #-48
     d18:	b9004be2 	str	w2, [sp, #72]
     d1c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
     d20:	a9430fe2 	ldp	x2, x3, [sp, #48]
     d24:	a9010fe2 	stp	x2, x3, [sp, #16]
     d28:	a9440fe2 	ldp	x2, x3, [sp, #64]
     d2c:	a9020fe2 	stp	x2, x3, [sp, #32]
     d30:	910043e2 	add	x2, sp, #0x10
{
     d34:	a90617e4 	stp	x4, x5, [sp, #96]
     d38:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
     d3c:	97ffff35 	bl	a10 <vprintf>
  va_end(ap);
  return result;
}
     d40:	a8c87bfd 	ldp	x29, x30, [sp], #128
     d44:	d65f03c0 	ret

0000000000000d48 <printf>:

int
printf(const char *fmt, ...)
{
     d48:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
     d4c:	910003fd 	mov	x29, sp
     d50:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
     d54:	910243e1 	add	x1, sp, #0x90
     d58:	a90307e1 	stp	x1, x1, [sp, #48]
     d5c:	910143e1 	add	x1, sp, #0x50
     d60:	f90023e1 	str	x1, [sp, #64]
     d64:	128006e1 	mov	w1, #0xffffffc8            	// #-56
     d68:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
     d6c:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
     d70:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
     d74:	52800020 	mov	w0, #0x1                   	// #1
{
     d78:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
     d7c:	a9430fe2 	ldp	x2, x3, [sp, #48]
     d80:	a9010fe2 	stp	x2, x3, [sp, #16]
     d84:	a9440fe2 	ldp	x2, x3, [sp, #64]
     d88:	a9020fe2 	stp	x2, x3, [sp, #32]
     d8c:	910043e2 	add	x2, sp, #0x10
{
     d90:	a9079be5 	stp	x5, x6, [sp, #120]
     d94:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
     d98:	97ffff1e 	bl	a10 <vprintf>
  va_end(ap);
  return result;
}
     d9c:	a8c97bfd 	ldp	x29, x30, [sp], #144
     da0:	d65f03c0 	ret

0000000000000da4 <pthread_records_lock>:
static struct pthread_record *pthread_records;
static int posix_errno;

static void
pthread_records_lock(void)
{
     da4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     da8:	910003fd 	mov	x29, sp
     dac:	a90153f3 	stp	x19, x20, [sp, #16]
  for(;;){
    uint old, failed, one = 1;
    asm volatile("ldaxr %w0, [%1]"
     db0:	b0000013 	adrp	x19, 1000 <pthread_create+0x38>
     db4:	91244273 	add	x19, x19, #0x910
                 : "=&r"(old) : "r"(&pthread_lock_word) : "memory");
    if(old == 0){
      asm volatile("stxr %w0, %w1, [%2]"
     db8:	52800034 	mov	w20, #0x1                   	// #1
    asm volatile("ldaxr %w0, [%1]"
     dbc:	885ffe60 	ldaxr	w0, [x19]
    if(old == 0){
     dc0:	350000c0 	cbnz	w0, dd8 <pthread_records_lock+0x34>
      asm volatile("stxr %w0, %w1, [%2]"
     dc4:	88007e74 	stxr	w0, w20, [x19]
                   : "=&r"(failed) : "r"(one), "r"(&pthread_lock_word)
                   : "memory");
      if(failed == 0)
     dc8:	350000a0 	cbnz	w0, ddc <pthread_records_lock+0x38>
    } else {
      asm volatile("clrex" ::: "memory");
    }
    sched_yield();
  }
}
     dcc:	a94153f3 	ldp	x19, x20, [sp, #16]
     dd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
     dd4:	d65f03c0 	ret
      asm volatile("clrex" ::: "memory");
     dd8:	d5033f5f 	clrex
    sched_yield();
     ddc:	97fffeb6 	bl	8b4 <sched_yield>
  for(;;){
     de0:	17fffff7 	b	dbc <pthread_records_lock+0x18>

0000000000000de4 <pthread_boot>:
  return 0;
}

static void
pthread_boot(void *opaque)
{
     de4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     de8:	910003fd 	mov	x29, sp
     dec:	a90153f3 	stp	x19, x20, [sp, #16]
     df0:	aa0003f3 	mov	x19, x0
  struct pthread_record *record = opaque;
  while(!__atomic_load_n(&record->ready, __ATOMIC_ACQUIRE))
     df4:	91003014 	add	x20, x0, #0xc
     df8:	88dffe80 	ldar	w0, [x20]
     dfc:	340000c0 	cbz	w0, e14 <pthread_boot+0x30>
    sched_yield();
  record->result = record->start(record->argument);
     e00:	a9418261 	ldp	x1, x0, [x19, #24]
     e04:	d63f0020 	blr	x1
     e08:	f9001660 	str	x0, [x19, #40]
  texit(0);
     e0c:	52800000 	mov	w0, #0x0                   	// #0
     e10:	97fffeb5 	bl	8e4 <texit>
    sched_yield();
     e14:	97fffea8 	bl	8b4 <sched_yield>
     e18:	17fffff8 	b	df8 <pthread_boot+0x14>

0000000000000e1c <__errno_location>:
}
     e1c:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
     e20:	91244000 	add	x0, x0, #0x910
     e24:	91001000 	add	x0, x0, #0x4
     e28:	d65f03c0 	ret

0000000000000e2c <_exit>:
{
     e2c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
     e30:	910003fd 	mov	x29, sp
  exit(status);
     e34:	97fffde9 	bl	5d8 <exit>

0000000000000e38 <execv>:
  return exec((char *)path, (char **)arguments);
     e38:	17fffdfd 	b	62c <exec>

0000000000000e3c <sleep>:
{
     e3c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     e40:	910003fd 	mov	x29, sp
     e44:	a90153f3 	stp	x19, x20, [sp, #16]
     e48:	2a0003f3 	mov	w19, w0
    unsigned int chunk = seconds > 0x0fffffffU ? 0x0fffffffU : seconds;
     e4c:	12be0014 	mov	w20, #0xfffffff             	// #268435455
{
     e50:	a9025bf5 	stp	x21, x22, [sp, #32]
    if(sleep_ticks(chunk * POSIX_TICKS_PER_SECOND) < 0)
     e54:	52800156 	mov	w22, #0xa                   	// #10
  while(seconds > 0){
     e58:	350000d3 	cbnz	w19, e70 <sleep+0x34>
}
     e5c:	2a1303e0 	mov	w0, w19
     e60:	a94153f3 	ldp	x19, x20, [sp, #16]
     e64:	a9425bf5 	ldp	x21, x22, [sp, #32]
     e68:	a8c37bfd 	ldp	x29, x30, [sp], #48
     e6c:	d65f03c0 	ret
    unsigned int chunk = seconds > 0x0fffffffU ? 0x0fffffffU : seconds;
     e70:	6b14027f 	cmp	w19, w20
     e74:	1a949275 	csel	w21, w19, w20, ls	// ls = plast
    if(sleep_ticks(chunk * POSIX_TICKS_PER_SECOND) < 0)
     e78:	1b167ea0 	mul	w0, w21, w22
     e7c:	97fffe0d 	bl	6b0 <sleep_ticks>
     e80:	37fffee0 	tbnz	w0, #31, e5c <sleep+0x20>
    seconds -= chunk;
     e84:	4b150273 	sub	w19, w19, w21
     e88:	17fffff4 	b	e58 <sleep+0x1c>

0000000000000e8c <usleep>:
  unsigned int ticks = (microseconds + 99999U) / 100000U;
     e8c:	5290d3e1 	mov	w1, #0x869f                	// #34463
     e90:	72a00021 	movk	w1, #0x1, lsl #16
     e94:	0b010000 	add	w0, w0, w1
  return ticks == 0 ? 0 : sleep_ticks(ticks);
     e98:	6b01001f 	cmp	w0, w1
     e9c:	54000089 	b.ls	eac <usleep+0x20>  // b.plast
  unsigned int ticks = (microseconds + 99999U) / 100000U;
     ea0:	11000421 	add	w1, w1, #0x1
  return ticks == 0 ? 0 : sleep_ticks(ticks);
     ea4:	1ac10800 	udiv	w0, w0, w1
     ea8:	17fffe02 	b	6b0 <sleep_ticks>
}
     eac:	52800000 	mov	w0, #0x0                   	// #0
     eb0:	d65f03c0 	ret

0000000000000eb4 <clock_gettime>:
  if(value == 0 || clock_id != CLOCK_MONOTONIC){
     eb4:	f100003f 	cmp	x1, #0x0
     eb8:	7a411800 	ccmp	w0, #0x1, #0x0, ne	// ne = any
     ebc:	54000120 	b.eq	ee0 <clock_gettime+0x2c>  // b.none
    errno = clock_id == CLOCK_REALTIME ? ENOSYS : EINVAL;
     ec0:	7100001f 	cmp	w0, #0x0
     ec4:	528004c1 	mov	w1, #0x26                  	// #38
     ec8:	528002c0 	mov	w0, #0x16                  	// #22
     ecc:	1a811000 	csel	w0, w0, w1, ne	// ne = any
     ed0:	b0000001 	adrp	x1, 1000 <pthread_create+0x38>
     ed4:	b9091420 	str	w0, [x1, #2324]
    return -1;
     ed8:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     edc:	d65f03c0 	ret
{
     ee0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     ee4:	910003fd 	mov	x29, sp
     ee8:	f9000bf3 	str	x19, [sp, #16]
     eec:	aa0103f3 	mov	x19, x1
  microseconds = clock_us();
     ef0:	97fffe74 	bl	8c0 <clock_us>
  value->tv_sec = microseconds / 1000000ULL;
     ef4:	d2884802 	mov	x2, #0x4240                	// #16960
     ef8:	f2a001e2 	movk	x2, #0xf, lsl #16
     efc:	9ac20801 	udiv	x1, x0, x2
  value->tv_nsec = (microseconds % 1000000ULL) * 1000ULL;
     f00:	9b028022 	msub	x2, x1, x2, x0
     f04:	52807d00 	mov	w0, #0x3e8                 	// #1000
     f08:	9ba07c42 	umull	x2, w2, w0
  return 0;
     f0c:	52800000 	mov	w0, #0x0                   	// #0
  value->tv_sec = microseconds / 1000000ULL;
     f10:	a9000a61 	stp	x1, x2, [x19]
}
     f14:	f9400bf3 	ldr	x19, [sp, #16]
     f18:	a8c27bfd 	ldp	x29, x30, [sp], #32
     f1c:	d65f03c0 	ret

0000000000000f20 <nanosleep>:
  if(request == 0 || request->tv_sec < 0 || request->tv_nsec < 0 ||
     f20:	b40004a0 	cbz	x0, fb4 <nanosleep+0x94>
{
     f24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     f28:	910003fd 	mov	x29, sp
     f2c:	a90153f3 	stp	x19, x20, [sp, #16]
  if(request == 0 || request->tv_sec < 0 || request->tv_nsec < 0 ||
     f30:	f9400013 	ldr	x19, [x0]
{
     f34:	f90013f5 	str	x21, [sp, #32]
  if(request == 0 || request->tv_sec < 0 || request->tv_nsec < 0 ||
     f38:	b7f800d3 	tbnz	x19, #63, f50 <nanosleep+0x30>
     f3c:	f9400400 	ldr	x0, [x0, #8]
     f40:	d2993fe1 	mov	x1, #0xc9ff                	// #51711
     f44:	f2a77341 	movk	x1, #0x3b9a, lsl #16
     f48:	eb01001f 	cmp	x0, x1
     f4c:	54000129 	b.ls	f70 <nanosleep+0x50>  // b.plast
    errno = EINVAL;
     f50:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
     f54:	528002c1 	mov	w1, #0x16                  	// #22
     f58:	b9091401 	str	w1, [x0, #2324]
    return -1;
     f5c:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     f60:	f94013f5 	ldr	x21, [sp, #32]
     f64:	a94153f3 	ldp	x19, x20, [sp, #16]
     f68:	a8c37bfd 	ldp	x29, x30, [sp], #48
     f6c:	d65f03c0 	ret
                 (request->tv_nsec + 999) / 1000;
     f70:	910f9c00 	add	x0, x0, #0x3e7
     f74:	d2807d01 	mov	x1, #0x3e8                 	// #1000
    uint chunk = microseconds > 0xffffffffULL ? 0xffffffffU : microseconds;
     f78:	b2407ff4 	mov	x20, #0xffffffff            	// #4294967295
                 (request->tv_nsec + 999) / 1000;
     f7c:	9ac10800 	udiv	x0, x0, x1
  microseconds = (uint64)request->tv_sec * 1000000ULL +
     f80:	d2884801 	mov	x1, #0x4240                	// #16960
     f84:	f2a001e1 	movk	x1, #0xf, lsl #16
     f88:	9b010273 	madd	x19, x19, x1, x0
  while(microseconds > 0){
     f8c:	b5000073 	cbnz	x19, f98 <nanosleep+0x78>
  return 0;
     f90:	52800000 	mov	w0, #0x0                   	// #0
     f94:	17fffff3 	b	f60 <nanosleep+0x40>
    uint chunk = microseconds > 0xffffffffULL ? 0xffffffffU : microseconds;
     f98:	eb14027f 	cmp	x19, x20
     f9c:	9a949275 	csel	x21, x19, x20, ls	// ls = plast
    if(usleep(chunk) < 0)
     fa0:	2a1503e0 	mov	w0, w21
     fa4:	97ffffba 	bl	e8c <usleep>
     fa8:	37fffda0 	tbnz	w0, #31, f5c <nanosleep+0x3c>
    microseconds -= chunk;
     fac:	cb150273 	sub	x19, x19, x21
     fb0:	17fffff7 	b	f8c <nanosleep+0x6c>
    errno = EINVAL;
     fb4:	b0000000 	adrp	x0, 1000 <pthread_create+0x38>
     fb8:	528002c1 	mov	w1, #0x16                  	// #22
     fbc:	b9091401 	str	w1, [x0, #2324]
    return -1;
     fc0:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     fc4:	d65f03c0 	ret

0000000000000fc8 <pthread_create>:
  struct pthread_record *record;
  uint64 top;
  int tid;
  (void)attributes;

  if(thread == 0 || start == 0)
     fc8:	f100001f 	cmp	x0, #0x0
     fcc:	fa401844 	ccmp	x2, #0x0, #0x4, ne	// ne = any
     fd0:	54000960 	b.eq	10fc <pthread_create+0x134>  // b.none
{
     fd4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     fd8:	910003fd 	mov	x29, sp
     fdc:	a90153f3 	stp	x19, x20, [sp, #16]
     fe0:	aa0203f4 	mov	x20, x2
     fe4:	a9025bf5 	stp	x21, x22, [sp, #32]
     fe8:	aa0003f5 	mov	x21, x0
     fec:	aa0303f6 	mov	x22, x3
    return EINVAL;
  if((record = malloc(sizeof(*record))) == 0)
     ff0:	52800600 	mov	w0, #0x30                  	// #48
{
     ff4:	f9001bf7 	str	x23, [sp, #48]
     ff8:	1a9f17f7 	cset	w23, eq	// eq = none
  if((record = malloc(sizeof(*record))) == 0)
     ffc:	940001ca 	bl	1724 <malloc>
    1000:	aa0003f3 	mov	x19, x0
    1004:	b4000140 	cbz	x0, 102c <pthread_create+0x64>
    return ENOMEM;
  memset(record, 0, sizeof(*record));
    1008:	52800602 	mov	w2, #0x30                  	// #48
    100c:	52800001 	mov	w1, #0x0                   	// #0
    1010:	97fffcf9 	bl	3f4 <memset>
  if((record->stack = malloc(POSIX_THREAD_STACK + 16)) == 0){
    1014:	52880200 	mov	w0, #0x4010                	// #16400
    1018:	940001c3 	bl	1724 <malloc>
    101c:	f9000a60 	str	x0, [x19, #16]
    1020:	b5000120 	cbnz	x0, 1044 <pthread_create+0x7c>
    free(record);
    1024:	aa1303e0 	mov	x0, x19
    1028:	940001b0 	bl	16e8 <free>
    return ENOMEM;
    102c:	52800180 	mov	w0, #0xc                   	// #12
  }
  record->tid = tid;
  *thread = tid;
  __atomic_store_n(&record->ready, 1, __ATOMIC_RELEASE);
  return 0;
}
    1030:	f9401bf7 	ldr	x23, [sp, #48]
    1034:	a94153f3 	ldp	x19, x20, [sp, #16]
    1038:	a9425bf5 	ldp	x21, x22, [sp, #32]
    103c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1040:	d65f03c0 	ret
  record->start = start;
    1044:	a901da74 	stp	x20, x22, [x19, #24]
  record->next = pthread_records;
    1048:	90000014 	adrp	x20, 1000 <pthread_create+0x38>
    104c:	91244294 	add	x20, x20, #0x910
  pthread_records_lock();
    1050:	97ffff55 	bl	da4 <pthread_records_lock>
  record->next = pthread_records;
    1054:	f9400680 	ldr	x0, [x20, #8]
    1058:	f9000260 	str	x0, [x19]
  pthread_records = record;
    105c:	f9000693 	str	x19, [x20, #8]
  asm volatile("stlr %w0, [%1]" ::
    1060:	889ffe97 	stlr	w23, [x20]
  top = ((uint64)record->stack + POSIX_THREAD_STACK + 16) & ~15ULL;
    1064:	f9400a62 	ldr	x2, [x19, #16]
    1068:	d2880203 	mov	x3, #0x4010                	// #16400
  tid = clone(pthread_boot, record, (void *)top);
    106c:	f0ffffe0 	adrp	x0, 0 <main>
    1070:	91379000 	add	x0, x0, #0xde4
  top = ((uint64)record->stack + POSIX_THREAD_STACK + 16) & ~15ULL;
    1074:	8b030042 	add	x2, x2, x3
  tid = clone(pthread_boot, record, (void *)top);
    1078:	aa1303e1 	mov	x1, x19
    107c:	927cec42 	and	x2, x2, #0xfffffffffffffff0
    1080:	97fffe16 	bl	8d8 <clone>
  if(tid < 0){
    1084:	36f802e0 	tbz	w0, #31, 10e0 <pthread_create+0x118>
    pthread_records_lock();
    1088:	97ffff47 	bl	da4 <pthread_records_lock>
    if(pthread_records == record)
    108c:	f9400680 	ldr	x0, [x20, #8]
    1090:	eb13001f 	cmp	x0, x19
    1094:	54000181 	b.ne	10c4 <pthread_create+0xfc>  // b.any
      pthread_records = record->next;
    1098:	f9400260 	ldr	x0, [x19]
    109c:	f9000680 	str	x0, [x20, #8]
  asm volatile("stlr %w0, [%1]" ::
    10a0:	52800000 	mov	w0, #0x0                   	// #0
    10a4:	889ffe80 	stlr	w0, [x20]
    free(record->stack);
    10a8:	f9400a60 	ldr	x0, [x19, #16]
    10ac:	9400018f 	bl	16e8 <free>
    free(record);
    10b0:	aa1303e0 	mov	x0, x19
    10b4:	9400018d 	bl	16e8 <free>
    return EAGAIN;
    10b8:	52800160 	mov	w0, #0xb                   	// #11
    10bc:	17ffffdd 	b	1030 <pthread_create+0x68>
      for(p = pthread_records; p && p->next != record; p = p->next)
    10c0:	aa0103e0 	mov	x0, x1
    10c4:	b4fffee0 	cbz	x0, 10a0 <pthread_create+0xd8>
    10c8:	f9400001 	ldr	x1, [x0]
    10cc:	eb13003f 	cmp	x1, x19
    10d0:	54ffff81 	b.ne	10c0 <pthread_create+0xf8>  // b.any
        p->next = record->next;
    10d4:	f9400261 	ldr	x1, [x19]
    10d8:	f9000001 	str	x1, [x0]
    10dc:	17fffff1 	b	10a0 <pthread_create+0xd8>
  record->tid = tid;
    10e0:	b9000a60 	str	w0, [x19, #8]
  *thread = tid;
    10e4:	b90002a0 	str	w0, [x21]
  __atomic_store_n(&record->ready, 1, __ATOMIC_RELEASE);
    10e8:	52800020 	mov	w0, #0x1                   	// #1
    10ec:	91003273 	add	x19, x19, #0xc
    10f0:	889ffe60 	stlr	w0, [x19]
  return 0;
    10f4:	52800000 	mov	w0, #0x0                   	// #0
    10f8:	17ffffce 	b	1030 <pthread_create+0x68>
    return EINVAL;
    10fc:	528002c0 	mov	w0, #0x16                  	// #22
}
    1100:	d65f03c0 	ret

0000000000001104 <pthread_join>:

int
pthread_join(pthread_t thread, void **result)
{
  struct pthread_record *record, *previous = 0;
  if(thread <= 0 || thread == gettid())
    1104:	7100001f 	cmp	w0, #0x0
    1108:	5400066d 	b.le	11d4 <pthread_join+0xd0>
{
    110c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1110:	910003fd 	mov	x29, sp
    1114:	a90153f3 	stp	x19, x20, [sp, #16]
    1118:	2a0003f4 	mov	w20, w0
    111c:	f90013f5 	str	x21, [sp, #32]
    1120:	aa0103f5 	mov	x21, x1
  if(thread <= 0 || thread == gettid())
    1124:	97fffdf6 	bl	8fc <gettid>
    1128:	6b14001f 	cmp	w0, w20
    112c:	540000c1 	b.ne	1144 <pthread_join+0x40>  // b.any
    return EINVAL;
    1130:	528002c0 	mov	w0, #0x16                  	// #22
  if(result)
    *result = record->result;
  free(record->stack);
  free(record);
  return 0;
}
    1134:	f94013f5 	ldr	x21, [sp, #32]
    1138:	a94153f3 	ldp	x19, x20, [sp, #16]
    113c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1140:	d65f03c0 	ret
  if(tjoin(thread, 0) < 0)
    1144:	2a1403e0 	mov	w0, w20
    1148:	d2800001 	mov	x1, #0x0                   	// #0
    114c:	97fffde9 	bl	8f0 <tjoin>
    1150:	37f803a0 	tbnz	w0, #31, 11c4 <pthread_join+0xc0>
  pthread_records_lock();
    1154:	97ffff14 	bl	da4 <pthread_records_lock>
  for(record = pthread_records; record && record->tid != thread;
    1158:	90000002 	adrp	x2, 1000 <pthread_create+0x38>
    115c:	91244042 	add	x2, x2, #0x910
  struct pthread_record *record, *previous = 0;
    1160:	d2800001 	mov	x1, #0x0                   	// #0
  for(record = pthread_records; record && record->tid != thread;
    1164:	f9400453 	ldr	x19, [x2, #8]
    1168:	b40002b3 	cbz	x19, 11bc <pthread_join+0xb8>
    116c:	b9400a60 	ldr	w0, [x19, #8]
    1170:	6b14001f 	cmp	w0, w20
    1174:	f9400260 	ldr	x0, [x19]
    1178:	540001c1 	b.ne	11b0 <pthread_join+0xac>  // b.any
    if(previous)
    117c:	b4000281 	cbz	x1, 11cc <pthread_join+0xc8>
      previous->next = record->next;
    1180:	f9000020 	str	x0, [x1]
  asm volatile("stlr %w0, [%1]" ::
    1184:	52800000 	mov	w0, #0x0                   	// #0
    1188:	889ffc40 	stlr	w0, [x2]
  if(result)
    118c:	b4000075 	cbz	x21, 1198 <pthread_join+0x94>
    *result = record->result;
    1190:	f9401660 	ldr	x0, [x19, #40]
    1194:	f90002a0 	str	x0, [x21]
  free(record->stack);
    1198:	f9400a60 	ldr	x0, [x19, #16]
    119c:	94000153 	bl	16e8 <free>
  free(record);
    11a0:	aa1303e0 	mov	x0, x19
    11a4:	94000151 	bl	16e8 <free>
  return 0;
    11a8:	52800000 	mov	w0, #0x0                   	// #0
    11ac:	17ffffe2 	b	1134 <pthread_join+0x30>
      previous = record, record = record->next)
    11b0:	aa1303e1 	mov	x1, x19
    11b4:	aa0003f3 	mov	x19, x0
    11b8:	17ffffec 	b	1168 <pthread_join+0x64>
  asm volatile("stlr %w0, [%1]" ::
    11bc:	52800000 	mov	w0, #0x0                   	// #0
    11c0:	889ffc40 	stlr	w0, [x2]
    return ESRCH;
    11c4:	52800060 	mov	w0, #0x3                   	// #3
    11c8:	17ffffdb 	b	1134 <pthread_join+0x30>
      pthread_records = record->next;
    11cc:	f9000440 	str	x0, [x2, #8]
    11d0:	17ffffed 	b	1184 <pthread_join+0x80>
    return EINVAL;
    11d4:	528002c0 	mov	w0, #0x16                  	// #22
}
    11d8:	d65f03c0 	ret

00000000000011dc <pthread_self>:

pthread_t
pthread_self(void)
{
  return gettid();
    11dc:	17fffdc8 	b	8fc <gettid>

00000000000011e0 <pthread_equal>:
}

int
pthread_equal(pthread_t first, pthread_t second)
{
  return first == second;
    11e0:	6b01001f 	cmp	w0, w1
}
    11e4:	1a9f17e0 	cset	w0, eq	// eq = none
    11e8:	d65f03c0 	ret

00000000000011ec <pthread_exit>:

void
pthread_exit(void *result)
{
    11ec:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    11f0:	910003fd 	mov	x29, sp
    11f4:	f9000bf3 	str	x19, [sp, #16]
    11f8:	aa0003f3 	mov	x19, x0
  struct pthread_record *record;
  pthread_records_lock();
    11fc:	97fffeea 	bl	da4 <pthread_records_lock>
  record = pthread_find(gettid());
    1200:	97fffdbf 	bl	8fc <gettid>
  for(record = pthread_records; record; record = record->next)
    1204:	90000002 	adrp	x2, 1000 <pthread_create+0x38>
    1208:	91244042 	add	x2, x2, #0x910
    120c:	f9400441 	ldr	x1, [x2, #8]
    1210:	b5000081 	cbnz	x1, 1220 <pthread_exit+0x34>
  asm volatile("stlr %w0, [%1]" ::
    1214:	52800000 	mov	w0, #0x0                   	// #0
    1218:	889ffc40 	stlr	w0, [x2]
  if(record)
    record->result = result;
  pthread_records_unlock();
  texit(0);
    121c:	97fffdb2 	bl	8e4 <texit>
    if(record->tid == tid)
    1220:	b9400823 	ldr	w3, [x1, #8]
    1224:	6b03001f 	cmp	w0, w3
    1228:	54000060 	b.eq	1234 <pthread_exit+0x48>  // b.none
  for(record = pthread_records; record; record = record->next)
    122c:	f9400021 	ldr	x1, [x1]
    1230:	17fffff8 	b	1210 <pthread_exit+0x24>
    record->result = result;
    1234:	f9001433 	str	x19, [x1, #40]
    1238:	17fffff7 	b	1214 <pthread_exit+0x28>

000000000000123c <pthread_mutex_init>:
pthread_mutex_init(pthread_mutex_t *mutex,
                   const pthread_mutexattr_t *attributes)
{
  int handle;
  (void)attributes;
  if(mutex == 0 || (handle = sync_create(SYNC_MUTEX, 1)) < 0)
    123c:	b50000e0 	cbnz	x0, 1258 <pthread_mutex_init+0x1c>
    return ENOMEM;
    1240:	52800180 	mov	w0, #0xc                   	// #12
  *mutex = handle;
  return 0;
}
    1244:	d65f03c0 	ret
    return ENOMEM;
    1248:	52800180 	mov	w0, #0xc                   	// #12
}
    124c:	f9400bf3 	ldr	x19, [sp, #16]
    1250:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1254:	d65f03c0 	ret
{
    1258:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  if(mutex == 0 || (handle = sync_create(SYNC_MUTEX, 1)) < 0)
    125c:	52800021 	mov	w1, #0x1                   	// #1
{
    1260:	910003fd 	mov	x29, sp
    1264:	f9000bf3 	str	x19, [sp, #16]
    1268:	aa0003f3 	mov	x19, x0
  if(mutex == 0 || (handle = sync_create(SYNC_MUTEX, 1)) < 0)
    126c:	2a0103e0 	mov	w0, w1
    1270:	97fffd1f 	bl	6ec <sync_create>
    1274:	37fffea0 	tbnz	w0, #31, 1248 <pthread_mutex_init+0xc>
  *mutex = handle;
    1278:	b9000260 	str	w0, [x19]
  return 0;
    127c:	52800000 	mov	w0, #0x0                   	// #0
    1280:	17fffff3 	b	124c <pthread_mutex_init+0x10>

0000000000001284 <pthread_mutex_lock>:

int
pthread_mutex_lock(pthread_mutex_t *mutex)
{
  int handle, old;
  if(mutex == 0)
    1284:	b4000320 	cbz	x0, 12e8 <pthread_mutex_lock+0x64>
{
    1288:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    128c:	910003fd 	mov	x29, sp
    1290:	a90153f3 	stp	x19, x20, [sp, #16]
    1294:	aa0003f3 	mov	x19, x0
    return EINVAL;
  handle = __atomic_load_n(mutex, __ATOMIC_ACQUIRE);
    1298:	88dffc00 	ldar	w0, [x0]
  if(handle == 0){
    129c:	35000140 	cbnz	w0, 12c4 <pthread_mutex_lock+0x40>
    handle = sync_create(SYNC_MUTEX, 1);
    12a0:	52800021 	mov	w1, #0x1                   	// #1
    12a4:	2a0103e0 	mov	w0, w1
    12a8:	97fffd11 	bl	6ec <sync_create>
    if(handle < 0)
    12ac:	37f80220 	tbnz	w0, #31, 12f0 <pthread_mutex_lock+0x6c>
    asm volatile("ldaxr %w0, [%1]"
    12b0:	885ffe74 	ldaxr	w20, [x19]
    if((int)old != expected){
    12b4:	34000154 	cbz	w20, 12dc <pthread_mutex_lock+0x58>
      asm volatile("clrex" ::: "memory");
    12b8:	d5033f5f 	clrex
      return ENOMEM;
    old = posix_compare_exchange(mutex, 0, handle);
    if(old != 0){
      sync_destroy(handle);
    12bc:	97fffd1b 	bl	728 <sync_destroy>
      handle = old;
    12c0:	2a1403e0 	mov	w0, w20
    }
  }
  return sync_wait(handle) < 0 ? EINVAL : 0;
    12c4:	97fffd0d 	bl	6f8 <sync_wait>
    12c8:	528002c1 	mov	w1, #0x16                  	// #22
    12cc:	0a807c20 	and	w0, w1, w0, asr #31
}
    12d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    12d4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    12d8:	d65f03c0 	ret
    asm volatile("stxr %w0, %w1, [%2]"
    12dc:	88017e60 	stxr	w1, w0, [x19]
    if(failed == 0)
    12e0:	35fffe81 	cbnz	w1, 12b0 <pthread_mutex_lock+0x2c>
    12e4:	17fffff8 	b	12c4 <pthread_mutex_lock+0x40>
    return EINVAL;
    12e8:	528002c0 	mov	w0, #0x16                  	// #22
}
    12ec:	d65f03c0 	ret
      return ENOMEM;
    12f0:	52800180 	mov	w0, #0xc                   	// #12
    12f4:	17fffff7 	b	12d0 <pthread_mutex_lock+0x4c>

00000000000012f8 <pthread_mutex_unlock>:

int
pthread_mutex_unlock(pthread_mutex_t *mutex)
{
  if(mutex == 0 || *mutex == 0)
    12f8:	b5000060 	cbnz	x0, 1304 <pthread_mutex_unlock+0xc>
    return EINVAL;
    12fc:	528002c0 	mov	w0, #0x16                  	// #22
  return sync_signal(*mutex, 1) < 0 ? EPERM : 0;
}
    1300:	d65f03c0 	ret
  if(mutex == 0 || *mutex == 0)
    1304:	b9400000 	ldr	w0, [x0]
    1308:	34ffffa0 	cbz	w0, 12fc <pthread_mutex_unlock+0x4>
{
    130c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  return sync_signal(*mutex, 1) < 0 ? EPERM : 0;
    1310:	52800021 	mov	w1, #0x1                   	// #1
{
    1314:	910003fd 	mov	x29, sp
  return sync_signal(*mutex, 1) < 0 ? EPERM : 0;
    1318:	97fffcfb 	bl	704 <sync_signal>
    131c:	531f7c00 	lsr	w0, w0, #31
}
    1320:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1324:	d65f03c0 	ret

0000000000001328 <pthread_mutex_destroy>:

int
pthread_mutex_destroy(pthread_mutex_t *mutex)
{
  int handle;
  if(mutex == 0)
    1328:	b40001e0 	cbz	x0, 1364 <pthread_mutex_destroy+0x3c>
    asm volatile("stxr %w0, %w1, [%2]"
    132c:	52800003 	mov	w3, #0x0                   	// #0
    asm volatile("ldaxr %w0, [%1]"
    1330:	885ffc01 	ldaxr	w1, [x0]
    asm volatile("stxr %w0, %w1, [%2]"
    1334:	88027c03 	stxr	w2, w3, [x0]
    if(failed == 0)
    1338:	35ffffc2 	cbnz	w2, 1330 <pthread_mutex_destroy+0x8>
      return old;
    133c:	2a0103e0 	mov	w0, w1
    return EINVAL;
  handle = posix_exchange(mutex, 0);
  return handle == 0 || sync_destroy(handle) == 0 ? 0 : EBUSY;
    1340:	34000161 	cbz	w1, 136c <pthread_mutex_destroy+0x44>
{
    1344:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1348:	910003fd 	mov	x29, sp
  return handle == 0 || sync_destroy(handle) == 0 ? 0 : EBUSY;
    134c:	97fffcf7 	bl	728 <sync_destroy>
    1350:	7100001f 	cmp	w0, #0x0
    1354:	1a9f07e0 	cset	w0, ne	// ne = any
}
    1358:	a8c17bfd 	ldp	x29, x30, [sp], #16
  return handle == 0 || sync_destroy(handle) == 0 ? 0 : EBUSY;
    135c:	531c6c00 	lsl	w0, w0, #4
}
    1360:	d65f03c0 	ret
    return EINVAL;
    1364:	528002c0 	mov	w0, #0x16                  	// #22
    1368:	d65f03c0 	ret
}
    136c:	d65f03c0 	ret

0000000000001370 <sem_init>:

int
sem_init(sem_t *semaphore, int shared, unsigned int value)
{
  int handle;
  if(semaphore == 0 || shared != 0 ||
    1370:	f100001f 	cmp	x0, #0x0
    1374:	7a401820 	ccmp	w1, #0x0, #0x0, ne	// ne = any
    1378:	540000e0 	b.eq	1394 <sem_init+0x24>  // b.none
     (handle = sync_create(SYNC_SEM, value)) < 0)
    return -1;
    137c:	12800000 	mov	w0, #0xffffffff            	// #-1
  *semaphore = handle;
  return 0;
}
    1380:	d65f03c0 	ret
    return -1;
    1384:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    1388:	f9400bf3 	ldr	x19, [sp, #16]
    138c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1390:	d65f03c0 	ret
{
    1394:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1398:	2a0203e1 	mov	w1, w2
    139c:	910003fd 	mov	x29, sp
    13a0:	f9000bf3 	str	x19, [sp, #16]
    13a4:	aa0003f3 	mov	x19, x0
     (handle = sync_create(SYNC_SEM, value)) < 0)
    13a8:	52800040 	mov	w0, #0x2                   	// #2
    13ac:	97fffcd0 	bl	6ec <sync_create>
  if(semaphore == 0 || shared != 0 ||
    13b0:	37fffea0 	tbnz	w0, #31, 1384 <sem_init+0x14>
  *semaphore = handle;
    13b4:	b9000260 	str	w0, [x19]
  return 0;
    13b8:	52800000 	mov	w0, #0x0                   	// #0
    13bc:	17fffff3 	b	1388 <sem_init+0x18>

00000000000013c0 <sem_wait>:

int sem_wait(sem_t *semaphore)
{
  return semaphore && sync_wait(*semaphore) == 0 ? 0 : -1;
    13c0:	b4000120 	cbz	x0, 13e4 <sem_wait+0x24>
{
    13c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    13c8:	910003fd 	mov	x29, sp
  return semaphore && sync_wait(*semaphore) == 0 ? 0 : -1;
    13cc:	b9400000 	ldr	w0, [x0]
    13d0:	97fffcca 	bl	6f8 <sync_wait>
    13d4:	7100001f 	cmp	w0, #0x0
    13d8:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    13dc:	a8c17bfd 	ldp	x29, x30, [sp], #16
    13e0:	d65f03c0 	ret
  return semaphore && sync_wait(*semaphore) == 0 ? 0 : -1;
    13e4:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    13e8:	d65f03c0 	ret

00000000000013ec <sem_post>:

int sem_post(sem_t *semaphore)
{
  return semaphore && sync_signal(*semaphore, 1) == 0 ? 0 : -1;
    13ec:	b4000140 	cbz	x0, 1414 <sem_post+0x28>
{
    13f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  return semaphore && sync_signal(*semaphore, 1) == 0 ? 0 : -1;
    13f4:	52800021 	mov	w1, #0x1                   	// #1
{
    13f8:	910003fd 	mov	x29, sp
  return semaphore && sync_signal(*semaphore, 1) == 0 ? 0 : -1;
    13fc:	b9400000 	ldr	w0, [x0]
    1400:	97fffcc1 	bl	704 <sync_signal>
    1404:	7100001f 	cmp	w0, #0x0
    1408:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    140c:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1410:	d65f03c0 	ret
  return semaphore && sync_signal(*semaphore, 1) == 0 ? 0 : -1;
    1414:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    1418:	d65f03c0 	ret

000000000000141c <sem_destroy>:

int sem_destroy(sem_t *semaphore)
{
  return semaphore && sync_destroy(*semaphore) == 0 ? 0 : -1;
    141c:	b4000120 	cbz	x0, 1440 <sem_destroy+0x24>
{
    1420:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1424:	910003fd 	mov	x29, sp
  return semaphore && sync_destroy(*semaphore) == 0 ? 0 : -1;
    1428:	b9400000 	ldr	w0, [x0]
    142c:	97fffcbf 	bl	728 <sync_destroy>
    1430:	7100001f 	cmp	w0, #0x0
    1434:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    1438:	a8c17bfd 	ldp	x29, x30, [sp], #16
    143c:	d65f03c0 	ret
  return semaphore && sync_destroy(*semaphore) == 0 ? 0 : -1;
    1440:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    1444:	d65f03c0 	ret

0000000000001448 <epoll_create1>:

int
epoll_create1(int flags)
{
  if(flags != 0){
    1448:	35000040 	cbnz	w0, 1450 <epoll_create1+0x8>
    errno = EINVAL;
    return -1;
  }
  return epoll_create();
    144c:	17fffcf9 	b	830 <epoll_create>
    errno = EINVAL;
    1450:	90000000 	adrp	x0, 1000 <pthread_create+0x38>
    1454:	528002c1 	mov	w1, #0x16                  	// #22
    1458:	b9091401 	str	w1, [x0, #2324]
}
    145c:	12800000 	mov	w0, #0xffffffff            	// #-1
    1460:	d65f03c0 	ret

0000000000001464 <accept>:

int
accept(int descriptor, struct sockaddr *address, unsigned int *length)
{
    1464:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1468:	910003fd 	mov	x29, sp
    146c:	a90153f3 	stp	x19, x20, [sp, #16]
    1470:	aa0103f4 	mov	x20, x1
    1474:	aa0203f3 	mov	x19, x2
    1478:	a9025bf5 	stp	x21, x22, [sp, #32]
  int child = socket_accept(descriptor);
    147c:	97fffcea 	bl	824 <socket_accept>
  if(child >= 0 && address && length){
    1480:	7100001f 	cmp	w0, #0x0
  int child = socket_accept(descriptor);
    1484:	2a0003f5 	mov	w21, w0
  if(child >= 0 && address && length){
    1488:	fa40aa84 	ccmp	x20, #0x0, #0x4, ge	// ge = tcont
    148c:	54000180 	b.eq	14bc <accept+0x58>  // b.none
    1490:	b4000173 	cbz	x19, 14bc <accept+0x58>
    memset(address, 0, *length < sizeof(*address) ? *length : sizeof(*address));
    1494:	b9400262 	ldr	w2, [x19]
    1498:	52800216 	mov	w22, #0x10                  	// #16
    149c:	aa1403e0 	mov	x0, x20
    14a0:	52800001 	mov	w1, #0x0                   	// #0
    14a4:	6b16005f 	cmp	w2, w22
    14a8:	1a969042 	csel	w2, w2, w22, ls	// ls = plast
    14ac:	97fffbd2 	bl	3f4 <memset>
    address->sa_family = AF_INET;
    14b0:	52800040 	mov	w0, #0x2                   	// #2
    14b4:	79000280 	strh	w0, [x20]
    *length = sizeof(*address);
    14b8:	b9000276 	str	w22, [x19]
  }
  return child;
}
    14bc:	2a1503e0 	mov	w0, w21
    14c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    14c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    14c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    14cc:	d65f03c0 	ret

00000000000014d0 <htons>:

uint16
htons(uint16 value)
{
  return (value << 8) | (value >> 8);
}
    14d0:	5ac00400 	rev16	w0, w0
    14d4:	d65f03c0 	ret

00000000000014d8 <ntohs>:

uint16 ntohs(uint16 value) { return htons(value); }
    14d8:	5ac00400 	rev16	w0, w0
    14dc:	d65f03c0 	ret

00000000000014e0 <htonl>:
uint32
htonl(uint32 value)
{
  return ((value & 0xffU) << 24) | ((value & 0xff00U) << 8) |
         ((value >> 8) & 0xff00U) | ((value >> 24) & 0xffU);
}
    14e0:	5ac00800 	rev	w0, w0
    14e4:	d65f03c0 	ret

00000000000014e8 <ntohl>:

uint32 ntohl(uint32 value) { return htonl(value); }
    14e8:	17fffffe 	b	14e0 <htonl>

00000000000014ec <inet_addr>:

uint32
inet_addr(const char *text)
{
    14ec:	aa0003e1 	mov	x1, x0
  uint32 address = 0;
  for(int part = 0; part < 4; part++){
    uint value = 0;
    if(text == 0 || *text < '0' || *text > '9')
    14f0:	b4000360 	cbz	x0, 155c <inet_addr+0x70>
    14f4:	52800000 	mov	w0, #0x0                   	// #0
    14f8:	52800003 	mov	w3, #0x0                   	// #0
      return 0xffffffffU;
    while(*text >= '0' && *text <= '9'){
      value = value * 10 + (*text++ - '0');
    14fc:	52800146 	mov	w6, #0xa                   	// #10
    if(text == 0 || *text < '0' || *text > '9')
    1500:	39400022 	ldrb	w2, [x1]
    1504:	5100c042 	sub	w2, w2, #0x30
    1508:	12001c42 	and	w2, w2, #0xff
    150c:	7100245f 	cmp	w2, #0x9
    1510:	54000268 	b.hi	155c <inet_addr+0x70>  // b.pmore
    uint value = 0;
    1514:	52800002 	mov	w2, #0x0                   	// #0
    while(*text >= '0' && *text <= '9'){
    1518:	39400024 	ldrb	w4, [x1]
    151c:	5100c085 	sub	w5, w4, #0x30
    1520:	12001ca5 	and	w5, w5, #0xff
    1524:	710024bf 	cmp	w5, #0x9
    1528:	54000109 	b.ls	1548 <inet_addr+0x5c>  // b.plast
      if(value > 255)
        return 0xffffffffU;
    }
    address |= value << (part * 8);
    152c:	1ac32042 	lsl	w2, w2, w3
    1530:	2a020000 	orr	w0, w0, w2
    if(part != 3 && *text++ != '.')
    1534:	7100607f 	cmp	w3, #0x18
    1538:	54000161 	b.ne	1564 <inet_addr+0x78>  // b.any
      return 0xffffffffU;
    153c:	7100009f 	cmp	w4, #0x0
    1540:	5a9f0000 	csinv	w0, w0, wzr, eq	// eq = none
      return 0xffffffffU;
  }
  return *text == 0 ? address : 0xffffffffU;
}
    1544:	d65f03c0 	ret
      value = value * 10 + (*text++ - '0');
    1548:	1b061042 	madd	w2, w2, w6, w4
    154c:	91000421 	add	x1, x1, #0x1
    1550:	5100c042 	sub	w2, w2, #0x30
      if(value > 255)
    1554:	7103fc5f 	cmp	w2, #0xff
    1558:	54fffe09 	b.ls	1518 <inet_addr+0x2c>  // b.plast
      return 0xffffffffU;
    155c:	12800000 	mov	w0, #0xffffffff            	// #-1
    1560:	17fffff9 	b	1544 <inet_addr+0x58>
    if(part != 3 && *text++ != '.')
    1564:	7100b89f 	cmp	w4, #0x2e
    1568:	54ffffa1 	b.ne	155c <inet_addr+0x70>  // b.any
    156c:	11002063 	add	w3, w3, #0x8
    1570:	91000421 	add	x1, x1, #0x1
    if(text == 0 || *text < '0' || *text > '9')
    1574:	17ffffe3 	b	1500 <inet_addr+0x14>

0000000000001578 <putchar>:

int putchar(int character)
{
    1578:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  char c = character;
  return write(1, &c, 1) == 1 ? (unsigned char)c : -1;
    157c:	52800022 	mov	w2, #0x1                   	// #1
{
    1580:	910003fd 	mov	x29, sp
  return write(1, &c, 1) == 1 ? (unsigned char)c : -1;
    1584:	91007fe1 	add	x1, sp, #0x1f
  char c = character;
    1588:	39007fe0 	strb	w0, [sp, #31]
  return write(1, &c, 1) == 1 ? (unsigned char)c : -1;
    158c:	2a0203e0 	mov	w0, w2
    1590:	97fffc1e 	bl	608 <write>
    1594:	39407fe1 	ldrb	w1, [sp, #31]
    1598:	7100041f 	cmp	w0, #0x1
}
    159c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    15a0:	5a9f0020 	csinv	w0, w1, wzr, eq	// eq = none
    15a4:	d65f03c0 	ret

00000000000015a8 <puts>:

int puts(const char *text)
{
    15a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    15ac:	910003fd 	mov	x29, sp
    15b0:	a90153f3 	stp	x19, x20, [sp, #16]
    15b4:	aa0003f3 	mov	x19, x0
  int length = strlen(text);
    15b8:	97fffb7f 	bl	3b4 <strlen>
    15bc:	2a0003f4 	mov	w20, w0
  if(write(1, text, length) != length || write(1, "\n", 1) != 1)
    15c0:	2a0003e2 	mov	w2, w0
    15c4:	aa1303e1 	mov	x1, x19
    15c8:	52800020 	mov	w0, #0x1                   	// #1
    15cc:	97fffc0f 	bl	608 <write>
    15d0:	6b14001f 	cmp	w0, w20
    15d4:	540000a0 	b.eq	15e8 <puts+0x40>  // b.none
    return -1;
    15d8:	12800000 	mov	w0, #0xffffffff            	// #-1
  return length + 1;
}
    15dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    15e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    15e4:	d65f03c0 	ret
    15e8:	2a0003f3 	mov	w19, w0
  if(write(1, text, length) != length || write(1, "\n", 1) != 1)
    15ec:	90000001 	adrp	x1, 1000 <pthread_create+0x38>
    15f0:	9123b421 	add	x1, x1, #0x8ed
    15f4:	52800022 	mov	w2, #0x1                   	// #1
    15f8:	2a0203e0 	mov	w0, w2
    15fc:	97fffc03 	bl	608 <write>
    1600:	7100041f 	cmp	w0, #0x1
    1604:	54fffea1 	b.ne	15d8 <puts+0x30>  // b.any
  return length + 1;
    1608:	11000660 	add	w0, w19, #0x1
    160c:	17fffff4 	b	15dc <puts+0x34>

0000000000001610 <free_locked>:
free_locked(void *ap)
{
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1610:	90000005 	adrp	x5, 1000 <pthread_create+0x38>
    1614:	f94490a2 	ldr	x2, [x5, #2336]
  bp = (Header*)ap - 1;
    1618:	d1004003 	sub	x3, x0, #0x10
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    161c:	f9400041 	ldr	x1, [x2]
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1620:	eb03005f 	cmp	x2, x3
    1624:	54000342 	b.cs	168c <free_locked+0x7c>  // b.hs, b.nlast
    1628:	eb01007f 	cmp	x3, x1
    162c:	540002a2 	b.cs	1680 <free_locked+0x70>  // b.hs, b.nlast
      break;
  if(bp + bp->s.size == p->s.ptr){
    1630:	b85f8006 	ldur	w6, [x0, #-8]
    1634:	8b265064 	add	x4, x3, w6, uxtw #4
    1638:	eb04003f 	cmp	x1, x4
    163c:	540000a1 	b.ne	1650 <free_locked+0x40>  // b.any
    bp->s.size += p->s.ptr->s.size;
    1640:	b9400824 	ldr	w4, [x1, #8]
    bp->s.ptr = p->s.ptr->s.ptr;
    1644:	f9400021 	ldr	x1, [x1]
    bp->s.size += p->s.ptr->s.size;
    1648:	0b060084 	add	w4, w4, w6
    164c:	b81f8004 	stur	w4, [x0, #-8]
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    1650:	b9400844 	ldr	w4, [x2, #8]
    1654:	f81f0001 	stur	x1, [x0, #-16]
    1658:	8b245046 	add	x6, x2, w4, uxtw #4
    165c:	eb06007f 	cmp	x3, x6
    1660:	540000a1 	b.ne	1674 <free_locked+0x64>  // b.any
    p->s.size += bp->s.size;
    1664:	b85f8000 	ldur	w0, [x0, #-8]
    p->s.ptr = bp->s.ptr;
    1668:	aa0103e3 	mov	x3, x1
    p->s.size += bp->s.size;
    166c:	0b040000 	add	w0, w0, w4
    1670:	b9000840 	str	w0, [x2, #8]
  } else
    p->s.ptr = bp;
  freep = p;
    1674:	f90490a2 	str	x2, [x5, #2336]
    1678:	f9000043 	str	x3, [x2]
}
    167c:	d65f03c0 	ret
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1680:	eb01005f 	cmp	x2, x1
    1684:	540000c3 	b.cc	169c <free_locked+0x8c>  // b.lo, b.ul, b.last
    1688:	17ffffea 	b	1630 <free_locked+0x20>
    168c:	eb01005f 	cmp	x2, x1
    1690:	54000063 	b.cc	169c <free_locked+0x8c>  // b.lo, b.ul, b.last
    1694:	eb01007f 	cmp	x3, x1
    1698:	54fffcc3 	b.cc	1630 <free_locked+0x20>  // b.lo, b.ul, b.last
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    169c:	aa0103e2 	mov	x2, x1
    16a0:	17ffffdf 	b	161c <free_locked+0xc>

00000000000016a4 <heap_acquire>:
{
    16a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    16a8:	910003fd 	mov	x29, sp
    16ac:	a90153f3 	stp	x19, x20, [sp, #16]
    asm volatile("ldaxr %w0, [%1]"
    16b0:	90000013 	adrp	x19, 1000 <pthread_create+0x38>
    16b4:	91248273 	add	x19, x19, #0x920
    16b8:	91002273 	add	x19, x19, #0x8
      asm volatile("stxr %w0, %w1, [%2]"
    16bc:	52800034 	mov	w20, #0x1                   	// #1
    asm volatile("ldaxr %w0, [%1]"
    16c0:	885ffe60 	ldaxr	w0, [x19]
    if(old == 0){
    16c4:	350000c0 	cbnz	w0, 16dc <heap_acquire+0x38>
      asm volatile("stxr %w0, %w1, [%2]"
    16c8:	88007e74 	stxr	w0, w20, [x19]
      if(failed == 0)
    16cc:	350000a0 	cbnz	w0, 16e0 <heap_acquire+0x3c>
}
    16d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    16d4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    16d8:	d65f03c0 	ret
      asm volatile("clrex" ::: "memory");
    16dc:	d5033f5f 	clrex
    sched_yield();
    16e0:	97fffc75 	bl	8b4 <sched_yield>
  for(;;){
    16e4:	17fffff7 	b	16c0 <heap_acquire+0x1c>

00000000000016e8 <free>:

void
free(void *ap)
{
  if(ap == 0)
    16e8:	b40001c0 	cbz	x0, 1720 <free+0x38>
{
    16ec:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    16f0:	910003fd 	mov	x29, sp
    16f4:	f9000fe0 	str	x0, [sp, #24]
    return;
  heap_acquire();
    16f8:	97ffffeb 	bl	16a4 <heap_acquire>
  free_locked(ap);
    16fc:	f9400fe0 	ldr	x0, [sp, #24]
    1700:	97ffffc4 	bl	1610 <free_locked>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    1704:	90000000 	adrp	x0, 1000 <pthread_create+0x38>
    1708:	91248000 	add	x0, x0, #0x920
    170c:	52800001 	mov	w1, #0x0                   	// #0
    1710:	91002000 	add	x0, x0, #0x8
    1714:	889ffc01 	stlr	w1, [x0]
  heap_release();
}
    1718:	a8c27bfd 	ldp	x29, x30, [sp], #32
    171c:	d65f03c0 	ret
    1720:	d65f03c0 	ret

0000000000001724 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1724:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1728:	910003fd 	mov	x29, sp
    172c:	a90153f3 	stp	x19, x20, [sp, #16]
  Header *p, *prevp;
  uint nunits;

  heap_acquire();
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1730:	2a0003f3 	mov	w19, w0
    1734:	91003e73 	add	x19, x19, #0xf
{
    1738:	a9025bf5 	stp	x21, x22, [sp, #32]
  if((prevp = freep) == 0){
    173c:	90000016 	adrp	x22, 1000 <pthread_create+0x38>
    1740:	912482d4 	add	x20, x22, #0x920
{
    1744:	f9001bf7 	str	x23, [sp, #48]
  heap_acquire();
    1748:	97ffffd7 	bl	16a4 <heap_acquire>
  if((prevp = freep) == 0){
    174c:	f94492c1 	ldr	x1, [x22, #2336]
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1750:	d344fe73 	lsr	x19, x19, #4
    1754:	11000673 	add	w19, w19, #0x1
  if((prevp = freep) == 0){
    1758:	b50000a1 	cbnz	x1, 176c <malloc+0x48>
    base.s.ptr = freep = prevp = &base;
    175c:	91004281 	add	x1, x20, #0x10
    1760:	f90492c1 	str	x1, [x22, #2336]
    1764:	f9000a81 	str	x1, [x20, #16]
    base.s.size = 0;
    1768:	b9001a9f 	str	wzr, [x20, #24]
  if(nu < 4096)
    176c:	7140067f 	cmp	w19, #0x1, lsl #12
    1770:	52820015 	mov	w21, #0x1000                	// #4096
    1774:	1a952275 	csel	w21, w19, w21, cs	// cs = hs, nlast
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1778:	f9400020 	ldr	x0, [x1]
  p = sbrk(nu * sizeof(Header));
    177c:	531c6eb7 	lsl	w23, w21, #4
    if(p->s.size >= nunits){
    1780:	b9400802 	ldr	w2, [x0, #8]
    1784:	6b13005f 	cmp	w2, w19
    1788:	54000263 	b.cc	17d4 <malloc+0xb0>  // b.lo, b.ul, b.last
      if(p->s.size == nunits)
    178c:	540001a1 	b.ne	17c0 <malloc+0x9c>  // b.any
        prevp->s.ptr = p->s.ptr;
    1790:	f9400002 	ldr	x2, [x0]
    1794:	f9000022 	str	x2, [x1]
      else {
        p->s.size -= nunits;
        p += p->s.size;
        p->s.size = nunits;
      }
      freep = prevp;
    1798:	f90492c1 	str	x1, [x22, #2336]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    179c:	91002294 	add	x20, x20, #0x8
    17a0:	52800001 	mov	w1, #0x0                   	// #0
    17a4:	889ffe81 	stlr	w1, [x20]
      heap_release();
      return (void*)(p + 1);
    17a8:	91004000 	add	x0, x0, #0x10
      if((p = morecore(nunits)) == 0){
        heap_release();
        return 0;
      }
  }
}
    17ac:	f9401bf7 	ldr	x23, [sp, #48]
    17b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    17b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    17b8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    17bc:	d65f03c0 	ret
        p->s.size -= nunits;
    17c0:	4b130042 	sub	w2, w2, w19
    17c4:	b9000802 	str	w2, [x0, #8]
        p += p->s.size;
    17c8:	8b225000 	add	x0, x0, w2, uxtw #4
        p->s.size = nunits;
    17cc:	b9000813 	str	w19, [x0, #8]
    17d0:	17fffff2 	b	1798 <malloc+0x74>
    if(p == freep)
    17d4:	f9400281 	ldr	x1, [x20]
    17d8:	eb00003f 	cmp	x1, x0
    17dc:	540001e1 	b.ne	1818 <malloc+0xf4>  // b.any
  p = sbrk(nu * sizeof(Header));
    17e0:	2a1703e0 	mov	w0, w23
    17e4:	97fffbb0 	bl	6a4 <sbrk>
  if(p == (char*)-1)
    17e8:	b100041f 	cmn	x0, #0x1
    17ec:	540000c1 	b.ne	1804 <malloc+0xe0>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    17f0:	91002294 	add	x20, x20, #0x8
    17f4:	52800000 	mov	w0, #0x0                   	// #0
    17f8:	889ffe80 	stlr	w0, [x20]
        return 0;
    17fc:	d2800000 	mov	x0, #0x0                   	// #0
    1800:	17ffffeb 	b	17ac <malloc+0x88>
  hp->s.size = nu;
    1804:	b9000815 	str	w21, [x0, #8]
  free_locked((void*)(hp + 1));
    1808:	91004000 	add	x0, x0, #0x10
    180c:	97ffff81 	bl	1610 <free_locked>
  return freep;
    1810:	f9400280 	ldr	x0, [x20]
      if((p = morecore(nunits)) == 0){
    1814:	b4fffee0 	cbz	x0, 17f0 <malloc+0xcc>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1818:	aa0003e1 	mov	x1, x0
    181c:	f9400000 	ldr	x0, [x0]
    if(p->s.size >= nunits){
    1820:	17ffffd8 	b	1780 <malloc+0x5c>
