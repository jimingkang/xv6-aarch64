
user/_echo:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
  for(i = 1; i < argc; i++){
    write(1, argv[i], strlen(argv[i]));
    if(i + 1 < argc){
      write(1, " ", 1);
    } else {
      write(1, "\n", 1);
   c:	90000014 	adrp	x20, 0 <main>
  10:	911c0a94 	add	x20, x20, #0x702
{
  14:	a9025bf5 	stp	x21, x22, [sp, #32]
      write(1, " ", 1);
  18:	90000015 	adrp	x21, 0 <main>
  1c:	911c02b5 	add	x21, x21, #0x700
{
  20:	2a0003f6 	mov	w22, w0
  24:	f9001bf7 	str	x23, [sp, #48]
  28:	aa0103f7 	mov	x23, x1
  for(i = 1; i < argc; i++){
  2c:	d2800033 	mov	x19, #0x1                   	// #1
  30:	6b1302df 	cmp	w22, w19
  34:	5400006c 	b.gt	40 <main+0x40>
    }
  }
  exit(0);
  38:	52800000 	mov	w0, #0x0                   	// #0
  3c:	940000d9 	bl	3a0 <exit>
    write(1, argv[i], strlen(argv[i]));
  40:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
  44:	f90027e1 	str	x1, [sp, #72]
  48:	aa0103e0 	mov	x0, x1
  4c:	9400004c 	bl	17c <strlen>
  50:	2a0003e2 	mov	w2, w0
  54:	f94027e1 	ldr	x1, [sp, #72]
  58:	52800020 	mov	w0, #0x1                   	// #1
  5c:	940000dd 	bl	3d0 <write>
    if(i + 1 < argc){
  60:	11000660 	add	w0, w19, #0x1
      write(1, " ", 1);
  64:	52800022 	mov	w2, #0x1                   	// #1
    if(i + 1 < argc){
  68:	6b0002df 	cmp	w22, w0
  6c:	540000cd 	b.le	84 <main+0x84>
      write(1, " ", 1);
  70:	aa1503e1 	mov	x1, x21
      write(1, "\n", 1);
  74:	2a0203e0 	mov	w0, w2
  78:	91000673 	add	x19, x19, #0x1
  7c:	940000d5 	bl	3d0 <write>
  for(i = 1; i < argc; i++){
  80:	17ffffec 	b	30 <main+0x30>
      write(1, "\n", 1);
  84:	aa1403e1 	mov	x1, x20
  88:	17fffffb 	b	74 <main+0x74>

000000000000008c <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  8c:	d2800002 	mov	x2, #0x0                   	// #0
  90:	38626823 	ldrb	w3, [x1, x2]
  94:	38226803 	strb	w3, [x0, x2]
  98:	91000442 	add	x2, x2, #0x1
  9c:	35ffffa3 	cbnz	w3, 90 <strcpy+0x4>
    ;
  return os;
}
  a0:	d65f03c0 	ret

00000000000000a4 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
  a4:	d2800003 	mov	x3, #0x0                   	// #0
  a8:	4b030044 	sub	w4, w2, w3
  ac:	7100009f 	cmp	w4, #0x0
  b0:	5400006d 	b.le	bc <strncpy+0x18>
  b4:	38636825 	ldrb	w5, [x1, x3]
  b8:	350000e5 	cbnz	w5, d4 <strncpy+0x30>
  bc:	8b030003 	add	x3, x0, x3
  c0:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
  c4:	4b010082 	sub	w2, w4, w1
  c8:	7100005f 	cmp	w2, #0x0
  cc:	540000ac 	b.gt	e0 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
  d0:	d65f03c0 	ret
    *s++ = *t++;
  d4:	38236805 	strb	w5, [x0, x3]
    n--;
  d8:	91000463 	add	x3, x3, #0x1
  dc:	17fffff3 	b	a8 <strncpy+0x4>
    *s++ = 0;
  e0:	3821687f 	strb	wzr, [x3, x1]
  e4:	91000421 	add	x1, x1, #0x1
  e8:	17fffff7 	b	c4 <strncpy+0x20>

00000000000000ec <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
  ec:	aa0003e2 	mov	x2, x0
  f0:	39400043 	ldrb	w3, [x2]
  f4:	aa0203e4 	mov	x4, x2
    s++;
  f8:	91000442 	add	x2, x2, #0x1
  while(*s)
  fc:	35ffffa3 	cbnz	w3, f0 <strcat+0x4>
 100:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 104:	38626823 	ldrb	w3, [x1, x2]
 108:	38226883 	strb	w3, [x4, x2]
 10c:	91000442 	add	x2, x2, #0x1
 110:	35ffffa3 	cbnz	w3, 104 <strcat+0x18>
    ;
  return os;
}
 114:	d65f03c0 	ret

0000000000000118 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 118:	d2800002 	mov	x2, #0x0                   	// #0
 11c:	38626803 	ldrb	w3, [x0, x2]
 120:	38626824 	ldrb	w4, [x1, x2]
 124:	34000083 	cbz	w3, 134 <strcmp+0x1c>
 128:	91000442 	add	x2, x2, #0x1
 12c:	6b04007f 	cmp	w3, w4
 130:	54ffff60 	b.eq	11c <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 134:	4b040060 	sub	w0, w3, w4
 138:	d65f03c0 	ret

000000000000013c <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 13c:	340001c2 	cbz	w2, 174 <strncmp+0x38>
 140:	39400003 	ldrb	w3, [x0]
 144:	34000083 	cbz	w3, 154 <strncmp+0x18>
 148:	39400024 	ldrb	w4, [x1]
 14c:	6b03009f 	cmp	w4, w3
 150:	540000a0 	b.eq	164 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 154:	39400000 	ldrb	w0, [x0]
 158:	39400021 	ldrb	w1, [x1]
 15c:	4b010000 	sub	w0, w0, w1
}
 160:	d65f03c0 	ret
    n--, p++, q++;
 164:	51000442 	sub	w2, w2, #0x1
 168:	91000400 	add	x0, x0, #0x1
 16c:	91000421 	add	x1, x1, #0x1
 170:	17fffff3 	b	13c <strncmp>
    return 0;
 174:	52800000 	mov	w0, #0x0                   	// #0
 178:	17fffffa 	b	160 <strncmp+0x24>

000000000000017c <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 17c:	d1000402 	sub	x2, x0, #0x1
 180:	d2800001 	mov	x1, #0x0                   	// #0
 184:	aa0103e0 	mov	x0, x1
 188:	91000421 	add	x1, x1, #0x1
 18c:	38616843 	ldrb	w3, [x2, x1]
 190:	35ffffa3 	cbnz	w3, 184 <strlen+0x8>
    ;
  return n;
}
 194:	d65f03c0 	ret

0000000000000198 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 198:	d1000403 	sub	x3, x0, #0x1
 19c:	d2800002 	mov	x2, #0x0                   	// #0
 1a0:	2a0203e0 	mov	w0, w2
 1a4:	6b02003f 	cmp	w1, w2
 1a8:	54000089 	b.ls	1b8 <strnlen+0x20>  // b.plast
 1ac:	91000442 	add	x2, x2, #0x1
 1b0:	38626864 	ldrb	w4, [x3, x2]
 1b4:	35ffff64 	cbnz	w4, 1a0 <strnlen+0x8>
    n++;
  return n;
}
 1b8:	d65f03c0 	ret

00000000000001bc <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1bc:	d2800003 	mov	x3, #0x0                   	// #0
 1c0:	6b03005f 	cmp	w2, w3
 1c4:	54000048 	b.hi	1cc <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 1c8:	d65f03c0 	ret
    cdst[i] = c;
 1cc:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 1d0:	91000463 	add	x3, x3, #0x1
 1d4:	17fffffb 	b	1c0 <memset+0x4>

00000000000001d8 <strchr>:

char*
strchr(const char *s, char c)
{
 1d8:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 1dc:	39400002 	ldrb	w2, [x0]
 1e0:	35000062 	cbnz	w2, 1ec <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 1e4:	d2800000 	mov	x0, #0x0                   	// #0
}
 1e8:	d65f03c0 	ret
    if(*s == c)
 1ec:	6b01005f 	cmp	w2, w1
 1f0:	54ffffc0 	b.eq	1e8 <strchr+0x10>  // b.none
  for(; *s; s++)
 1f4:	91000400 	add	x0, x0, #0x1
 1f8:	17fffff9 	b	1dc <strchr+0x4>

00000000000001fc <gets>:

char*
gets(char *buf, int max)
{
 1fc:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 200:	910003fd 	mov	x29, sp
 204:	a90153f3 	stp	x19, x20, [sp, #16]
 208:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 20c:	d2800014 	mov	x20, #0x0                   	// #0
{
 210:	f9001bf7 	str	x23, [sp, #48]
 214:	2a0103f7 	mov	w23, w1
 218:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 21c:	11000695 	add	w21, w20, #0x1
 220:	2a1403f6 	mov	w22, w20
 224:	6b1702bf 	cmp	w21, w23
 228:	540000ea 	b.ge	244 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 22c:	91013fe1 	add	x1, sp, #0x4f
 230:	52800022 	mov	w2, #0x1                   	// #1
 234:	52800000 	mov	w0, #0x0                   	// #0
 238:	94000063 	bl	3c4 <read>
    if(cc < 1)
 23c:	7100001f 	cmp	w0, #0x0
 240:	5400012c 	b.gt	264 <gets+0x68>
  for(i=0; i+1 < max; ){
 244:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 248:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 24c:	aa1303e0 	mov	x0, x19
 250:	f9401bf7 	ldr	x23, [sp, #48]
 254:	a94153f3 	ldp	x19, x20, [sp, #16]
 258:	a9425bf5 	ldp	x21, x22, [sp, #32]
 25c:	a8c57bfd 	ldp	x29, x30, [sp], #80
 260:	d65f03c0 	ret
    buf[i++] = c;
 264:	39413fe0 	ldrb	w0, [sp, #79]
 268:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 26c:	91000694 	add	x20, x20, #0x1
 270:	7100281f 	cmp	w0, #0xa
 274:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 278:	54fffd21 	b.ne	21c <gets+0x20>  // b.any
 27c:	17fffff3 	b	248 <gets+0x4c>

0000000000000280 <stat>:

int
stat(const char *n, struct stat *st)
{
 280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 284:	910003fd 	mov	x29, sp
 288:	a90153f3 	stp	x19, x20, [sp, #16]
 28c:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 290:	52800001 	mov	w1, #0x0                   	// #0
 294:	9400005b 	bl	400 <open>
  if(fd < 0)
 298:	37f80160 	tbnz	w0, #31, 2c4 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 29c:	aa1303e1 	mov	x1, x19
 2a0:	2a0003f4 	mov	w20, w0
 2a4:	94000060 	bl	424 <fstat>
 2a8:	2a0003f3 	mov	w19, w0
  close(fd);
 2ac:	2a1403e0 	mov	w0, w20
 2b0:	9400004b 	bl	3dc <close>
  return r;
}
 2b4:	2a1303e0 	mov	w0, w19
 2b8:	a94153f3 	ldp	x19, x20, [sp, #16]
 2bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
 2c0:	d65f03c0 	ret
    return -1;
 2c4:	12800013 	mov	w19, #0xffffffff            	// #-1
 2c8:	17fffffb 	b	2b4 <stat+0x34>

00000000000002cc <atoi>:

int
atoi(const char *s)
{
 2cc:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 2d0:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 2d4:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 2d8:	39400043 	ldrb	w3, [x2]
 2dc:	5100c061 	sub	w1, w3, #0x30
 2e0:	12001c21 	and	w1, w1, #0xff
 2e4:	7100243f 	cmp	w1, #0x9
 2e8:	54000049 	b.ls	2f0 <atoi+0x24>  // b.plast
  return n;
}
 2ec:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 2f0:	1b040c01 	madd	w1, w0, w4, w3
 2f4:	91000442 	add	x2, x2, #0x1
 2f8:	5100c020 	sub	w0, w1, #0x30
 2fc:	17fffff7 	b	2d8 <atoi+0xc>

0000000000000300 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 300:	eb01001f 	cmp	x0, x1
 304:	54000263 	b.cc	350 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 308:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 30c:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 310:	d2800003 	mov	x3, #0x0                   	// #0
 314:	d1000463 	sub	x3, x3, #0x1
 318:	11000464 	add	w4, w3, #0x1
 31c:	0b020084 	add	w4, w4, w2
 320:	7100009f 	cmp	w4, #0x0
 324:	5400014d 	b.le	34c <memmove+0x4c>
      *--dst = *--src;
 328:	38636824 	ldrb	w4, [x1, x3]
 32c:	382368a4 	strb	w4, [x5, x3]
 330:	17fffff9 	b	314 <memmove+0x14>
      *dst++ = *src++;
 334:	38636824 	ldrb	w4, [x1, x3]
 338:	38236804 	strb	w4, [x0, x3]
 33c:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 340:	4b030044 	sub	w4, w2, w3
 344:	7100009f 	cmp	w4, #0x0
 348:	54ffff6c 	b.gt	334 <memmove+0x34>
  }
  return vdst;
}
 34c:	d65f03c0 	ret
 350:	d2800003 	mov	x3, #0x0                   	// #0
 354:	17fffffb 	b	340 <memmove+0x40>

0000000000000358 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 358:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 35c:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 360:	d2800004 	mov	x4, #0x0                   	// #0
 364:	eb02009f 	cmp	x4, x2
 368:	54000061 	b.ne	374 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 36c:	52800000 	mov	w0, #0x0                   	// #0
 370:	14000007 	b	38c <memcmp+0x34>
    if (*p1 != *p2) {
 374:	38646803 	ldrb	w3, [x0, x4]
 378:	91000484 	add	x4, x4, #0x1
 37c:	38646825 	ldrb	w5, [x1, x4]
 380:	6b05007f 	cmp	w3, w5
 384:	54ffff00 	b.eq	364 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 388:	4b050060 	sub	w0, w3, w5
}
 38c:	d65f03c0 	ret

0000000000000390 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 390:	17ffffdc 	b	300 <memmove>

0000000000000394 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 394:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 398:	d4000001 	svc	#0x0
 ret
 39c:	d65f03c0 	ret

00000000000003a0 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 3a0:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 3a4:	d4000001 	svc	#0x0
 ret
 3a8:	d65f03c0 	ret

00000000000003ac <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 3ac:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 3b0:	d4000001 	svc	#0x0
 ret
 3b4:	d65f03c0 	ret

00000000000003b8 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 3b8:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 3bc:	d4000001 	svc	#0x0
 ret
 3c0:	d65f03c0 	ret

00000000000003c4 <read>:
.global read
read:
 mov x7, #SYS_read
 3c4:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 3c8:	d4000001 	svc	#0x0
 ret
 3cc:	d65f03c0 	ret

00000000000003d0 <write>:
.global write
write:
 mov x7, #SYS_write
 3d0:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 3d4:	d4000001 	svc	#0x0
 ret
 3d8:	d65f03c0 	ret

00000000000003dc <close>:
.global close
close:
 mov x7, #SYS_close
 3dc:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 3e0:	d4000001 	svc	#0x0
 ret
 3e4:	d65f03c0 	ret

00000000000003e8 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 3e8:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 3ec:	d4000001 	svc	#0x0
 ret
 3f0:	d65f03c0 	ret

00000000000003f4 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 3f4:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 3f8:	d4000001 	svc	#0x0
 ret
 3fc:	d65f03c0 	ret

0000000000000400 <open>:
.global open
open:
 mov x7, #SYS_open
 400:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 404:	d4000001 	svc	#0x0
 ret
 408:	d65f03c0 	ret

000000000000040c <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 40c:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 410:	d4000001 	svc	#0x0
 ret
 414:	d65f03c0 	ret

0000000000000418 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 418:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 41c:	d4000001 	svc	#0x0
 ret
 420:	d65f03c0 	ret

0000000000000424 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 424:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 428:	d4000001 	svc	#0x0
 ret
 42c:	d65f03c0 	ret

0000000000000430 <link>:
.global link
link:
 mov x7, #SYS_link
 430:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 434:	d4000001 	svc	#0x0
 ret
 438:	d65f03c0 	ret

000000000000043c <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 43c:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 440:	d4000001 	svc	#0x0
 ret
 444:	d65f03c0 	ret

0000000000000448 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 448:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 44c:	d4000001 	svc	#0x0
 ret
 450:	d65f03c0 	ret

0000000000000454 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 454:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 458:	d4000001 	svc	#0x0
 ret
 45c:	d65f03c0 	ret

0000000000000460 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 460:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 464:	d4000001 	svc	#0x0
 ret
 468:	d65f03c0 	ret

000000000000046c <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 46c:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 470:	d4000001 	svc	#0x0
 ret
 474:	d65f03c0 	ret

0000000000000478 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 478:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 47c:	d4000001 	svc	#0x0
 ret
 480:	d65f03c0 	ret

0000000000000484 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 484:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 488:	d4000001 	svc	#0x0
 ret
 48c:	d65f03c0 	ret

0000000000000490 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 490:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 494:	d4000001 	svc	#0x0
 ret
 498:	d65f03c0 	ret

000000000000049c <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 49c:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 4a0:	d4000001 	svc	#0x0
 ret
 4a4:	d65f03c0 	ret

00000000000004a8 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 4a8:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 4ac:	d4000001 	svc	#0x0
 ret
 4b0:	d65f03c0 	ret

00000000000004b4 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 4b4:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 4b8:	d4000001 	svc	#0x0
 ret
 4bc:	d65f03c0 	ret

00000000000004c0 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 4c0:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 4c4:	d4000001 	svc	#0x0
 ret
 4c8:	d65f03c0 	ret

00000000000004cc <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 4cc:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 4d0:	d4000001 	svc	#0x0
 ret
 4d4:	d65f03c0 	ret

00000000000004d8 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 4d8:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 4dc:	d4000001 	svc	#0x0
 ret
 4e0:	d65f03c0 	ret

00000000000004e4 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 4e4:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 4e8:	d4000001 	svc	#0x0
 ret
 4ec:	d65f03c0 	ret

00000000000004f0 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 4f0:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 4f4:	d4000001 	svc	#0x0
 ret
 4f8:	d65f03c0 	ret

00000000000004fc <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 4fc:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 500:	d4000001 	svc	#0x0
 ret
 504:	d65f03c0 	ret

0000000000000508 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 508:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 50c:	d4000001 	svc	#0x0
 ret
 510:	d65f03c0 	ret

0000000000000514 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 514:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 518:	d4000001 	svc	#0x0
 ret
 51c:	d65f03c0 	ret

0000000000000520 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 520:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 524:	d4000001 	svc	#0x0
 ret
 528:	d65f03c0 	ret

000000000000052c <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 52c:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 530:	d4000001 	svc	#0x0
 ret
 534:	d65f03c0 	ret

0000000000000538 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 538:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 53c:	d4000001 	svc	#0x0
 ret
 540:	d65f03c0 	ret

0000000000000544 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 544:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 548:	d4000001 	svc	#0x0
 ret
 54c:	d65f03c0 	ret

0000000000000550 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 550:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 554:	d4000001 	svc	#0x0
 ret
 558:	d65f03c0 	ret

000000000000055c <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 55c:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 560:	d4000001 	svc	#0x0
 ret
 564:	d65f03c0 	ret

0000000000000568 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 568:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 56c:	d4000001 	svc	#0x0
 ret
 570:	d65f03c0 	ret

0000000000000574 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 574:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 578:	d4000001 	svc	#0x0
 ret
 57c:	d65f03c0 	ret

0000000000000580 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 580:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 584:	d4000001 	svc	#0x0
 ret
 588:	d65f03c0 	ret

000000000000058c <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 58c:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 590:	d4000001 	svc	#0x0
 ret
 594:	d65f03c0 	ret

0000000000000598 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 598:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 59c:	d4000001 	svc	#0x0
 ret
 5a0:	d65f03c0 	ret

00000000000005a4 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 5a4:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 5a8:	d4000001 	svc	#0x0
 ret
 5ac:	d65f03c0 	ret

00000000000005b0 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 5b0:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 5b4:	d4000001 	svc	#0x0
 ret
 5b8:	d65f03c0 	ret

00000000000005bc <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 5bc:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 5c0:	d4000001 	svc	#0x0
 ret
 5c4:	d65f03c0 	ret

00000000000005c8 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 5c8:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 5cc:	d4000001 	svc	#0x0
 ret
 5d0:	d65f03c0 	ret

00000000000005d4 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 5d4:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 5d8:	d4000001 	svc	#0x0
 ret
 5dc:	d65f03c0 	ret

00000000000005e0 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 5e0:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 5e4:	d4000001 	svc	#0x0
 ret
 5e8:	d65f03c0 	ret

00000000000005ec <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 5ec:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 5f0:	d4000001 	svc	#0x0
 ret
 5f4:	d65f03c0 	ret

00000000000005f8 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 5f8:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 5fc:	d4000001 	svc	#0x0
 ret
 600:	d65f03c0 	ret

0000000000000604 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 604:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 608:	d4000001 	svc	#0x0
 ret
 60c:	d65f03c0 	ret

0000000000000610 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 610:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 614:	d4000001 	svc	#0x0
 ret
 618:	d65f03c0 	ret

000000000000061c <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 61c:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 620:	d4000001 	svc	#0x0
 ret
 624:	d65f03c0 	ret

0000000000000628 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 628:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 62c:	d4000001 	svc	#0x0
 ret
 630:	d65f03c0 	ret

0000000000000634 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 634:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 638:	d4000001 	svc	#0x0
 ret
 63c:	d65f03c0 	ret

0000000000000640 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 640:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 644:	d4000001 	svc	#0x0
 ret
 648:	d65f03c0 	ret

000000000000064c <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 64c:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 650:	d4000001 	svc	#0x0
 ret
 654:	d65f03c0 	ret

0000000000000658 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 658:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 65c:	d4000001 	svc	#0x0
 ret
 660:	d65f03c0 	ret

0000000000000664 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 664:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 668:	d4000001 	svc	#0x0
 ret
 66c:	d65f03c0 	ret

0000000000000670 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 670:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 674:	d4000001 	svc	#0x0
 ret
 678:	d65f03c0 	ret

000000000000067c <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 67c:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 680:	d4000001 	svc	#0x0
 ret
 684:	d65f03c0 	ret

0000000000000688 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 688:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 68c:	d4000001 	svc	#0x0
 ret
 690:	d65f03c0 	ret

0000000000000694 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 694:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 698:	d4000001 	svc	#0x0
 ret
 69c:	d65f03c0 	ret

00000000000006a0 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 6a0:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 6a4:	d4000001 	svc	#0x0
 ret
 6a8:	d65f03c0 	ret

00000000000006ac <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 6ac:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 6b0:	d4000001 	svc	#0x0
 ret
 6b4:	d65f03c0 	ret

00000000000006b8 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 6b8:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 6bc:	d4000001 	svc	#0x0
 ret
 6c0:	d65f03c0 	ret

00000000000006c4 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 6c4:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 6c8:	d4000001 	svc	#0x0
 ret
 6cc:	d65f03c0 	ret

00000000000006d0 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 6d0:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 6d4:	d4000001 	svc	#0x0
 ret
 6d8:	d65f03c0 	ret

00000000000006dc <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 6dc:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 6e0:	d4000001 	svc	#0x0
 ret
 6e4:	d65f03c0 	ret

00000000000006e8 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 6e8:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 6ec:	d4000001 	svc	#0x0
 ret
 6f0:	d65f03c0 	ret

00000000000006f4 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 6f4:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 6f8:	d4000001 	svc	#0x0
 ret
 6fc:	d65f03c0 	ret
