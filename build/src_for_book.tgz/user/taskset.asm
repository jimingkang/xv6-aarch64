
user/_taskset:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  printf("pid %d's %s affinity mask: %x\n", si.pid, what, si.cpumask);
}

int
main(int argc, char *argv[])
{
   0:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
   c:	aa0103f3 	mov	x19, x1
  10:	a9025bf5 	stp	x21, x22, [sp, #32]
  14:	a90363f7 	stp	x23, x24, [sp, #48]
  18:	f90023f9 	str	x25, [sp, #64]
  int mask, pid;

  if(argc == 3 && strcmp(argv[1], "-p") == 0){
  1c:	71000c1f 	cmp	w0, #0x3
  20:	54000221 	b.ne	64 <main+0x64>  // b.any
  24:	f9400660 	ldr	x0, [x19, #8]
  28:	90000001 	adrp	x1, 0 <main>
  2c:	913b7021 	add	x1, x1, #0xedc
  30:	940000f2 	bl	3f8 <strcmp>
  34:	35000660 	cbnz	w0, 100 <main+0x100>
    if(!parse_num(argv[2], &pid))
  38:	f9400a60 	ldr	x0, [x19, #16]
  3c:	910183e1 	add	x1, sp, #0x60
  40:	9400006f 	bl	1fc <parse_num>
  44:	35000040 	cbnz	w0, 4c <main+0x4c>
      usage();
  48:	940000a9 	bl	2ec <usage>
    show(pid, "current");
  4c:	b94063e0 	ldr	w0, [sp, #96]
  50:	90000001 	adrp	x1, 0 <main>
  54:	913b7c21 	add	x1, x1, #0xedf
    show(pid, "current");
    if(sched_setaffinity(pid, mask) < 0){
      fprintf(2, "taskset: failed to set pid %d's affinity to %x\n", pid, mask);
      exit(1);
    }
    show(pid, "new");
  58:	940000ad 	bl	30c <show>
    exit(0);
  5c:	52800000 	mov	w0, #0x0                   	// #0
  60:	14000021 	b	e4 <main+0xe4>
  if(argc == 4 && strcmp(argv[1], "-p") == 0){
  64:	7100101f 	cmp	w0, #0x4
  68:	54000481 	b.ne	f8 <main+0xf8>  // b.any
  6c:	f9400660 	ldr	x0, [x19, #8]
  70:	90000001 	adrp	x1, 0 <main>
  74:	913b7021 	add	x1, x1, #0xedc
  78:	940000e0 	bl	3f8 <strcmp>
  7c:	35000420 	cbnz	w0, 100 <main+0x100>
    if(!parse_num(argv[2], &mask) || !parse_num(argv[3], &pid))
  80:	f9400a60 	ldr	x0, [x19, #16]
  84:	910173e1 	add	x1, sp, #0x5c
  88:	9400005d 	bl	1fc <parse_num>
  8c:	34fffde0 	cbz	w0, 48 <main+0x48>
  90:	f9400e60 	ldr	x0, [x19, #24]
  94:	910183e1 	add	x1, sp, #0x60
  98:	94000059 	bl	1fc <parse_num>
  9c:	34fffd60 	cbz	w0, 48 <main+0x48>
    show(pid, "current");
  a0:	b94063f3 	ldr	w19, [sp, #96]
  a4:	90000001 	adrp	x1, 0 <main>
  a8:	913b7c21 	add	x1, x1, #0xedf
  ac:	2a1303e0 	mov	w0, w19
  b0:	94000097 	bl	30c <show>
    if(sched_setaffinity(pid, mask) < 0){
  b4:	b9405ff4 	ldr	w20, [sp, #92]
  b8:	2a1303e0 	mov	w0, w19
  bc:	2a1403e1 	mov	w1, w20
  c0:	94000224 	bl	950 <sched_setaffinity>
  c4:	36f80120 	tbz	w0, #31, e8 <main+0xe8>
      fprintf(2, "taskset: failed to set pid %d's affinity to %x\n", pid, mask);
  c8:	90000001 	adrp	x1, 0 <main>
  cc:	913b9c21 	add	x1, x1, #0xee7
  d0:	2a1403e3 	mov	w3, w20
  d4:	2a1303e2 	mov	w2, w19
  d8:	52800040 	mov	w0, #0x2                   	// #2
  dc:	94000331 	bl	da0 <fprintf>
      exit(1);
  e0:	52800020 	mov	w0, #0x1                   	// #1
  e4:	94000167 	bl	680 <exit>
    show(pid, "new");
  e8:	90000001 	adrp	x1, 0 <main>
  ec:	913c5c21 	add	x1, x1, #0xf17
  f0:	2a1303e0 	mov	w0, w19
  f4:	17ffffd9 	b	58 <main+0x58>
  }
  if(argc < 3 || !parse_num(argv[1], &mask))
  f8:	7100081f 	cmp	w0, #0x2
  fc:	54fffa6d 	b.le	48 <main+0x48>
 100:	f9400660 	ldr	x0, [x19, #8]
 104:	910173e1 	add	x1, sp, #0x5c
 108:	9400003d 	bl	1fc <parse_num>
 10c:	2a0003f6 	mov	w22, w0
 110:	34fff9c0 	cbz	w0, 48 <main+0x48>
    usage();
  if(sched_setaffinity(0, mask) < 0){
 114:	b9405ff4 	ldr	w20, [sp, #92]
 118:	52800000 	mov	w0, #0x0                   	// #0
 11c:	2a1403e1 	mov	w1, w20
 120:	9400020c 	bl	950 <sched_setaffinity>
 124:	36f800e0 	tbz	w0, #31, 140 <main+0x140>
    fprintf(2, "taskset: invalid mask %x\n", mask);
 128:	2a1403e2 	mov	w2, w20
 12c:	90000001 	adrp	x1, 0 <main>
 130:	913c6c21 	add	x1, x1, #0xf1b
 134:	52800040 	mov	w0, #0x2                   	// #2
 138:	9400031a 	bl	da0 <fprintf>
    exit(1);
 13c:	17ffffe9 	b	e0 <main+0xe0>
// exec() argv[0] the way sh does: as given if it has a '/', else /bin, then /.
static __attribute__((unused)) void
exec_cmd(char **argv)
{
  char path[64];
  char *name = argv[0];
 140:	f9400a75 	ldr	x21, [x19, #16]
  }
  exec_cmd(&argv[2]);
 144:	91004278 	add	x24, x19, #0x10
  int n;

  for(char *c = name; *c; c++)
 148:	aa1503e0 	mov	x0, x21
 14c:	39400001 	ldrb	w1, [x0]
 150:	35000301 	cbnz	w1, 1b0 <main+0x1b0>
 154:	90000002 	adrp	x2, 0 <main>
 158:	913b5842 	add	x2, x2, #0xed6
 15c:	910183f4 	add	x20, sp, #0x60
 160:	52800017 	mov	w23, #0x0                   	// #0
    if(*c == '/'){
      exec(name, argv);
      return;
    }
  for(int pass = 0; pass < 2; pass++){
    const char *prefix = pass == 0 ? "/bin/" : "/";
 164:	90000019 	adrp	x25, 0 <main>
    n = 0;
    for(const char *c = prefix; *c; c++)
 168:	d2800000 	mov	x0, #0x0                   	// #0
 16c:	38606841 	ldrb	w1, [x2, x0]
 170:	350003a1 	cbnz	w1, 1e4 <main+0x1e4>
 174:	2a0003e2 	mov	w2, w0
      path[n++] = *c;
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 178:	cb2042a0 	sub	x0, x21, w0, uxtw
 17c:	38626801 	ldrb	w1, [x0, x2]
 180:	34000061 	cbz	w1, 18c <main+0x18c>
 184:	7100f85f 	cmp	w2, #0x3e
 188:	5400034d 	b.le	1f0 <main+0x1f0>
      path[n++] = *c;
    path[n] = 0;
 18c:	38224a9f 	strb	wzr, [x20, w2, uxtw]
    exec(path, argv);
 190:	aa1803e1 	mov	x1, x24
 194:	aa1403e0 	mov	x0, x20
 198:	9400014f 	bl	6d4 <exec>
    const char *prefix = pass == 0 ? "/bin/" : "/";
 19c:	913b6b22 	add	x2, x25, #0xeda
  for(int pass = 0; pass < 2; pass++){
 1a0:	710006ff 	cmp	w23, #0x1
 1a4:	54000100 	b.eq	1c4 <main+0x1c4>  // b.none
 1a8:	2a1603f7 	mov	w23, w22
 1ac:	17ffffef 	b	168 <main+0x168>
    if(*c == '/'){
 1b0:	7100bc3f 	cmp	w1, #0x2f
 1b4:	54000141 	b.ne	1dc <main+0x1dc>  // b.any
      exec(name, argv);
 1b8:	aa1803e1 	mov	x1, x24
 1bc:	aa1503e0 	mov	x0, x21
 1c0:	94000145 	bl	6d4 <exec>
  fprintf(2, "taskset: exec %s failed\n", argv[2]);
 1c4:	f9400a62 	ldr	x2, [x19, #16]
 1c8:	90000001 	adrp	x1, 0 <main>
 1cc:	913cd421 	add	x1, x1, #0xf35
 1d0:	52800040 	mov	w0, #0x2                   	// #2
 1d4:	940002f3 	bl	da0 <fprintf>
  exit(1);
 1d8:	17ffffc2 	b	e0 <main+0xe0>
  for(char *c = name; *c; c++)
 1dc:	91000400 	add	x0, x0, #0x1
 1e0:	17ffffdb 	b	14c <main+0x14c>
      path[n++] = *c;
 1e4:	38206a81 	strb	w1, [x20, x0]
    for(const char *c = prefix; *c; c++)
 1e8:	91000400 	add	x0, x0, #0x1
 1ec:	17ffffe0 	b	16c <main+0x16c>
      path[n++] = *c;
 1f0:	38226a81 	strb	w1, [x20, x2]
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 1f4:	91000442 	add	x2, x2, #0x1
 1f8:	17ffffe1 	b	17c <main+0x17c>

00000000000001fc <parse_num>:
{
 1fc:	aa0003e2 	mov	x2, x0
  if(*s == '-'){
 200:	39400000 	ldrb	w0, [x0]
 204:	7100b41f 	cmp	w0, #0x2d
 208:	540002c1 	b.ne	260 <parse_num+0x64>  // b.any
    s++;
 20c:	91000442 	add	x2, x2, #0x1
    neg = 1;
 210:	52800025 	mov	w5, #0x1                   	// #1
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 214:	39400040 	ldrb	w0, [x2]
 218:	7100c01f 	cmp	w0, #0x30
 21c:	540000c1 	b.ne	234 <parse_num+0x38>  // b.any
 220:	39400440 	ldrb	w0, [x2, #1]
 224:	121a7800 	and	w0, w0, #0xffffffdf
 228:	12001c00 	and	w0, w0, #0xff
 22c:	7101601f 	cmp	w0, #0x58
 230:	540001c0 	b.eq	268 <parse_num+0x6c>  // b.none
 234:	52800000 	mov	w0, #0x0                   	// #0
 238:	52800003 	mov	w3, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 23c:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
 240:	39400044 	ldrb	w4, [x2]
 244:	340001c4 	cbz	w4, 27c <parse_num+0x80>
      if(*s < '0' || *s > '9')
 248:	5100c084 	sub	w4, w4, #0x30
 24c:	12001c80 	and	w0, w4, #0xff
 250:	7100241f 	cmp	w0, #0x9
 254:	54000449 	b.ls	2dc <parse_num+0xe0>  // b.plast
      else return 0;
 258:	52800000 	mov	w0, #0x0                   	// #0
}
 25c:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
 260:	52800005 	mov	w5, #0x0                   	// #0
 264:	17ffffec 	b	214 <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
 268:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
 26c:	52800000 	mov	w0, #0x0                   	// #0
 270:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 274:	39400044 	ldrb	w4, [x2]
 278:	350000c4 	cbnz	w4, 290 <parse_num+0x94>
  if(!any)
 27c:	34ffff00 	cbz	w0, 25c <parse_num+0x60>
  *out = neg ? -v : v;
 280:	710000bf 	cmp	w5, #0x0
 284:	5a830463 	cneg	w3, w3, ne	// ne = any
 288:	b9000023 	str	w3, [x1]
  return 1;
 28c:	17fffff4 	b	25c <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 290:	5100c080 	sub	w0, w4, #0x30
 294:	12001c06 	and	w6, w0, #0xff
 298:	710024df 	cmp	w6, #0x9
 29c:	540000c9 	b.ls	2b4 <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 2a0:	51018480 	sub	w0, w4, #0x61
 2a4:	12001c00 	and	w0, w0, #0xff
 2a8:	7100141f 	cmp	w0, #0x5
 2ac:	540000c8 	b.hi	2c4 <parse_num+0xc8>  // b.pmore
 2b0:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
 2b4:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
 2b8:	91000442 	add	x2, x2, #0x1
 2bc:	52800020 	mov	w0, #0x1                   	// #1
 2c0:	17ffffed 	b	274 <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 2c4:	51010480 	sub	w0, w4, #0x41
 2c8:	12001c00 	and	w0, w0, #0xff
 2cc:	7100141f 	cmp	w0, #0x5
 2d0:	54fffc48 	b.hi	258 <parse_num+0x5c>  // b.pmore
 2d4:	5100dc80 	sub	w0, w4, #0x37
 2d8:	17fffff7 	b	2b4 <parse_num+0xb8>
      v = v * 10 + (*s - '0');
 2dc:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
 2e0:	91000442 	add	x2, x2, #0x1
 2e4:	52800020 	mov	w0, #0x1                   	// #1
 2e8:	17ffffd6 	b	240 <parse_num+0x44>

00000000000002ec <usage>:
{
 2ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: taskset -p PID\n"
 2f0:	90000001 	adrp	x1, 0 <main>
 2f4:	91393021 	add	x1, x1, #0xe4c
{
 2f8:	910003fd 	mov	x29, sp
  fprintf(2, "usage: taskset -p PID\n"
 2fc:	52800040 	mov	w0, #0x2                   	// #2
 300:	940002a8 	bl	da0 <fprintf>
  exit(1);
 304:	52800020 	mov	w0, #0x1                   	// #1
 308:	940000de 	bl	680 <exit>

000000000000030c <show>:
{
 30c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 310:	910003fd 	mov	x29, sp
 314:	f9000bf3 	str	x19, [sp, #16]
 318:	aa0103f3 	mov	x19, x1
  if(sched_getinfo(pid, &si) < 0){
 31c:	9100e3e1 	add	x1, sp, #0x38
{
 320:	b9002fe0 	str	w0, [sp, #44]
  if(sched_getinfo(pid, &si) < 0){
 324:	94000185 	bl	938 <sched_getinfo>
 328:	b9402fe2 	ldr	w2, [sp, #44]
 32c:	36f800e0 	tbz	w0, #31, 348 <show+0x3c>
    fprintf(2, "taskset: no process %d\n", pid);
 330:	90000001 	adrp	x1, 0 <main>
 334:	913a7c21 	add	x1, x1, #0xe9f
 338:	52800040 	mov	w0, #0x2                   	// #2
 33c:	94000299 	bl	da0 <fprintf>
    exit(1);
 340:	52800020 	mov	w0, #0x1                   	// #1
 344:	940000cf 	bl	680 <exit>
  printf("pid %d's %s affinity mask: %x\n", si.pid, what, si.cpumask);
 348:	b9403be1 	ldr	w1, [sp, #56]
 34c:	aa1303e2 	mov	x2, x19
 350:	b9404be3 	ldr	w3, [sp, #72]
 354:	90000000 	adrp	x0, 0 <main>
 358:	913adc00 	add	x0, x0, #0xeb7
 35c:	940002a5 	bl	df0 <printf>
}
 360:	f9400bf3 	ldr	x19, [sp, #16]
 364:	a8c67bfd 	ldp	x29, x30, [sp], #96
 368:	d65f03c0 	ret

000000000000036c <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 36c:	d2800002 	mov	x2, #0x0                   	// #0
 370:	38626823 	ldrb	w3, [x1, x2]
 374:	38226803 	strb	w3, [x0, x2]
 378:	91000442 	add	x2, x2, #0x1
 37c:	35ffffa3 	cbnz	w3, 370 <strcpy+0x4>
    ;
  return os;
}
 380:	d65f03c0 	ret

0000000000000384 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 384:	d2800003 	mov	x3, #0x0                   	// #0
 388:	4b030044 	sub	w4, w2, w3
 38c:	7100009f 	cmp	w4, #0x0
 390:	5400006d 	b.le	39c <strncpy+0x18>
 394:	38636825 	ldrb	w5, [x1, x3]
 398:	350000e5 	cbnz	w5, 3b4 <strncpy+0x30>
 39c:	8b030003 	add	x3, x0, x3
 3a0:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 3a4:	4b010082 	sub	w2, w4, w1
 3a8:	7100005f 	cmp	w2, #0x0
 3ac:	540000ac 	b.gt	3c0 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 3b0:	d65f03c0 	ret
    *s++ = *t++;
 3b4:	38236805 	strb	w5, [x0, x3]
    n--;
 3b8:	91000463 	add	x3, x3, #0x1
 3bc:	17fffff3 	b	388 <strncpy+0x4>
    *s++ = 0;
 3c0:	3821687f 	strb	wzr, [x3, x1]
 3c4:	91000421 	add	x1, x1, #0x1
 3c8:	17fffff7 	b	3a4 <strncpy+0x20>

00000000000003cc <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 3cc:	aa0003e2 	mov	x2, x0
 3d0:	39400043 	ldrb	w3, [x2]
 3d4:	aa0203e4 	mov	x4, x2
    s++;
 3d8:	91000442 	add	x2, x2, #0x1
  while(*s)
 3dc:	35ffffa3 	cbnz	w3, 3d0 <strcat+0x4>
 3e0:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 3e4:	38626823 	ldrb	w3, [x1, x2]
 3e8:	38226883 	strb	w3, [x4, x2]
 3ec:	91000442 	add	x2, x2, #0x1
 3f0:	35ffffa3 	cbnz	w3, 3e4 <strcat+0x18>
    ;
  return os;
}
 3f4:	d65f03c0 	ret

00000000000003f8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 3f8:	d2800002 	mov	x2, #0x0                   	// #0
 3fc:	38626803 	ldrb	w3, [x0, x2]
 400:	38626824 	ldrb	w4, [x1, x2]
 404:	34000083 	cbz	w3, 414 <strcmp+0x1c>
 408:	91000442 	add	x2, x2, #0x1
 40c:	6b04007f 	cmp	w3, w4
 410:	54ffff60 	b.eq	3fc <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 414:	4b040060 	sub	w0, w3, w4
 418:	d65f03c0 	ret

000000000000041c <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 41c:	340001c2 	cbz	w2, 454 <strncmp+0x38>
 420:	39400003 	ldrb	w3, [x0]
 424:	34000083 	cbz	w3, 434 <strncmp+0x18>
 428:	39400024 	ldrb	w4, [x1]
 42c:	6b03009f 	cmp	w4, w3
 430:	540000a0 	b.eq	444 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 434:	39400000 	ldrb	w0, [x0]
 438:	39400021 	ldrb	w1, [x1]
 43c:	4b010000 	sub	w0, w0, w1
}
 440:	d65f03c0 	ret
    n--, p++, q++;
 444:	51000442 	sub	w2, w2, #0x1
 448:	91000400 	add	x0, x0, #0x1
 44c:	91000421 	add	x1, x1, #0x1
 450:	17fffff3 	b	41c <strncmp>
    return 0;
 454:	52800000 	mov	w0, #0x0                   	// #0
 458:	17fffffa 	b	440 <strncmp+0x24>

000000000000045c <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 45c:	d1000402 	sub	x2, x0, #0x1
 460:	d2800001 	mov	x1, #0x0                   	// #0
 464:	aa0103e0 	mov	x0, x1
 468:	91000421 	add	x1, x1, #0x1
 46c:	38616843 	ldrb	w3, [x2, x1]
 470:	35ffffa3 	cbnz	w3, 464 <strlen+0x8>
    ;
  return n;
}
 474:	d65f03c0 	ret

0000000000000478 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 478:	d1000403 	sub	x3, x0, #0x1
 47c:	d2800002 	mov	x2, #0x0                   	// #0
 480:	2a0203e0 	mov	w0, w2
 484:	6b02003f 	cmp	w1, w2
 488:	54000089 	b.ls	498 <strnlen+0x20>  // b.plast
 48c:	91000442 	add	x2, x2, #0x1
 490:	38626864 	ldrb	w4, [x3, x2]
 494:	35ffff64 	cbnz	w4, 480 <strnlen+0x8>
    n++;
  return n;
}
 498:	d65f03c0 	ret

000000000000049c <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 49c:	d2800003 	mov	x3, #0x0                   	// #0
 4a0:	6b03005f 	cmp	w2, w3
 4a4:	54000048 	b.hi	4ac <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 4a8:	d65f03c0 	ret
    cdst[i] = c;
 4ac:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 4b0:	91000463 	add	x3, x3, #0x1
 4b4:	17fffffb 	b	4a0 <memset+0x4>

00000000000004b8 <strchr>:

char*
strchr(const char *s, char c)
{
 4b8:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 4bc:	39400002 	ldrb	w2, [x0]
 4c0:	35000062 	cbnz	w2, 4cc <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 4c4:	d2800000 	mov	x0, #0x0                   	// #0
}
 4c8:	d65f03c0 	ret
    if(*s == c)
 4cc:	6b01005f 	cmp	w2, w1
 4d0:	54ffffc0 	b.eq	4c8 <strchr+0x10>  // b.none
  for(; *s; s++)
 4d4:	91000400 	add	x0, x0, #0x1
 4d8:	17fffff9 	b	4bc <strchr+0x4>

00000000000004dc <gets>:

char*
gets(char *buf, int max)
{
 4dc:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 4e0:	910003fd 	mov	x29, sp
 4e4:	a90153f3 	stp	x19, x20, [sp, #16]
 4e8:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 4ec:	d2800014 	mov	x20, #0x0                   	// #0
{
 4f0:	f9001bf7 	str	x23, [sp, #48]
 4f4:	2a0103f7 	mov	w23, w1
 4f8:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 4fc:	11000695 	add	w21, w20, #0x1
 500:	2a1403f6 	mov	w22, w20
 504:	6b1702bf 	cmp	w21, w23
 508:	540000ea 	b.ge	524 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 50c:	91013fe1 	add	x1, sp, #0x4f
 510:	52800022 	mov	w2, #0x1                   	// #1
 514:	52800000 	mov	w0, #0x0                   	// #0
 518:	94000063 	bl	6a4 <read>
    if(cc < 1)
 51c:	7100001f 	cmp	w0, #0x0
 520:	5400012c 	b.gt	544 <gets+0x68>
  for(i=0; i+1 < max; ){
 524:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 528:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 52c:	aa1303e0 	mov	x0, x19
 530:	f9401bf7 	ldr	x23, [sp, #48]
 534:	a94153f3 	ldp	x19, x20, [sp, #16]
 538:	a9425bf5 	ldp	x21, x22, [sp, #32]
 53c:	a8c57bfd 	ldp	x29, x30, [sp], #80
 540:	d65f03c0 	ret
    buf[i++] = c;
 544:	39413fe0 	ldrb	w0, [sp, #79]
 548:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 54c:	91000694 	add	x20, x20, #0x1
 550:	7100281f 	cmp	w0, #0xa
 554:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 558:	54fffd21 	b.ne	4fc <gets+0x20>  // b.any
 55c:	17fffff3 	b	528 <gets+0x4c>

0000000000000560 <stat>:

int
stat(const char *n, struct stat *st)
{
 560:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 564:	910003fd 	mov	x29, sp
 568:	a90153f3 	stp	x19, x20, [sp, #16]
 56c:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 570:	52800001 	mov	w1, #0x0                   	// #0
 574:	9400005b 	bl	6e0 <open>
  if(fd < 0)
 578:	37f80160 	tbnz	w0, #31, 5a4 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 57c:	aa1303e1 	mov	x1, x19
 580:	2a0003f4 	mov	w20, w0
 584:	94000060 	bl	704 <fstat>
 588:	2a0003f3 	mov	w19, w0
  close(fd);
 58c:	2a1403e0 	mov	w0, w20
 590:	9400004b 	bl	6bc <close>
  return r;
}
 594:	2a1303e0 	mov	w0, w19
 598:	a94153f3 	ldp	x19, x20, [sp, #16]
 59c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 5a0:	d65f03c0 	ret
    return -1;
 5a4:	12800013 	mov	w19, #0xffffffff            	// #-1
 5a8:	17fffffb 	b	594 <stat+0x34>

00000000000005ac <atoi>:

int
atoi(const char *s)
{
 5ac:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 5b0:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 5b4:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 5b8:	39400043 	ldrb	w3, [x2]
 5bc:	5100c061 	sub	w1, w3, #0x30
 5c0:	12001c21 	and	w1, w1, #0xff
 5c4:	7100243f 	cmp	w1, #0x9
 5c8:	54000049 	b.ls	5d0 <atoi+0x24>  // b.plast
  return n;
}
 5cc:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 5d0:	1b040c01 	madd	w1, w0, w4, w3
 5d4:	91000442 	add	x2, x2, #0x1
 5d8:	5100c020 	sub	w0, w1, #0x30
 5dc:	17fffff7 	b	5b8 <atoi+0xc>

00000000000005e0 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 5e0:	eb01001f 	cmp	x0, x1
 5e4:	54000263 	b.cc	630 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 5e8:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 5ec:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 5f0:	d2800003 	mov	x3, #0x0                   	// #0
 5f4:	d1000463 	sub	x3, x3, #0x1
 5f8:	11000464 	add	w4, w3, #0x1
 5fc:	0b020084 	add	w4, w4, w2
 600:	7100009f 	cmp	w4, #0x0
 604:	5400014d 	b.le	62c <memmove+0x4c>
      *--dst = *--src;
 608:	38636824 	ldrb	w4, [x1, x3]
 60c:	382368a4 	strb	w4, [x5, x3]
 610:	17fffff9 	b	5f4 <memmove+0x14>
      *dst++ = *src++;
 614:	38636824 	ldrb	w4, [x1, x3]
 618:	38236804 	strb	w4, [x0, x3]
 61c:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 620:	4b030044 	sub	w4, w2, w3
 624:	7100009f 	cmp	w4, #0x0
 628:	54ffff6c 	b.gt	614 <memmove+0x34>
  }
  return vdst;
}
 62c:	d65f03c0 	ret
 630:	d2800003 	mov	x3, #0x0                   	// #0
 634:	17fffffb 	b	620 <memmove+0x40>

0000000000000638 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 638:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 63c:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 640:	d2800004 	mov	x4, #0x0                   	// #0
 644:	eb02009f 	cmp	x4, x2
 648:	54000061 	b.ne	654 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 64c:	52800000 	mov	w0, #0x0                   	// #0
 650:	14000007 	b	66c <memcmp+0x34>
    if (*p1 != *p2) {
 654:	38646803 	ldrb	w3, [x0, x4]
 658:	91000484 	add	x4, x4, #0x1
 65c:	38646825 	ldrb	w5, [x1, x4]
 660:	6b05007f 	cmp	w3, w5
 664:	54ffff00 	b.eq	644 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 668:	4b050060 	sub	w0, w3, w5
}
 66c:	d65f03c0 	ret

0000000000000670 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 670:	17ffffdc 	b	5e0 <memmove>

0000000000000674 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 674:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 678:	d4000001 	svc	#0x0
 ret
 67c:	d65f03c0 	ret

0000000000000680 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 680:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 684:	d4000001 	svc	#0x0
 ret
 688:	d65f03c0 	ret

000000000000068c <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 68c:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 690:	d4000001 	svc	#0x0
 ret
 694:	d65f03c0 	ret

0000000000000698 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 698:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 69c:	d4000001 	svc	#0x0
 ret
 6a0:	d65f03c0 	ret

00000000000006a4 <read>:
.global read
read:
 mov x7, #SYS_read
 6a4:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 6a8:	d4000001 	svc	#0x0
 ret
 6ac:	d65f03c0 	ret

00000000000006b0 <write>:
.global write
write:
 mov x7, #SYS_write
 6b0:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 6b4:	d4000001 	svc	#0x0
 ret
 6b8:	d65f03c0 	ret

00000000000006bc <close>:
.global close
close:
 mov x7, #SYS_close
 6bc:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 6c0:	d4000001 	svc	#0x0
 ret
 6c4:	d65f03c0 	ret

00000000000006c8 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 6c8:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 6cc:	d4000001 	svc	#0x0
 ret
 6d0:	d65f03c0 	ret

00000000000006d4 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 6d4:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 6d8:	d4000001 	svc	#0x0
 ret
 6dc:	d65f03c0 	ret

00000000000006e0 <open>:
.global open
open:
 mov x7, #SYS_open
 6e0:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 6e4:	d4000001 	svc	#0x0
 ret
 6e8:	d65f03c0 	ret

00000000000006ec <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 6ec:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 6f0:	d4000001 	svc	#0x0
 ret
 6f4:	d65f03c0 	ret

00000000000006f8 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 6f8:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 6fc:	d4000001 	svc	#0x0
 ret
 700:	d65f03c0 	ret

0000000000000704 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 704:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 708:	d4000001 	svc	#0x0
 ret
 70c:	d65f03c0 	ret

0000000000000710 <link>:
.global link
link:
 mov x7, #SYS_link
 710:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 714:	d4000001 	svc	#0x0
 ret
 718:	d65f03c0 	ret

000000000000071c <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 71c:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 720:	d4000001 	svc	#0x0
 ret
 724:	d65f03c0 	ret

0000000000000728 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 728:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 72c:	d4000001 	svc	#0x0
 ret
 730:	d65f03c0 	ret

0000000000000734 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 734:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 738:	d4000001 	svc	#0x0
 ret
 73c:	d65f03c0 	ret

0000000000000740 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 740:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 744:	d4000001 	svc	#0x0
 ret
 748:	d65f03c0 	ret

000000000000074c <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 74c:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 750:	d4000001 	svc	#0x0
 ret
 754:	d65f03c0 	ret

0000000000000758 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 758:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 75c:	d4000001 	svc	#0x0
 ret
 760:	d65f03c0 	ret

0000000000000764 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 764:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 768:	d4000001 	svc	#0x0
 ret
 76c:	d65f03c0 	ret

0000000000000770 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 770:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 774:	d4000001 	svc	#0x0
 ret
 778:	d65f03c0 	ret

000000000000077c <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 77c:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 780:	d4000001 	svc	#0x0
 ret
 784:	d65f03c0 	ret

0000000000000788 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 788:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 78c:	d4000001 	svc	#0x0
 ret
 790:	d65f03c0 	ret

0000000000000794 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 794:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 798:	d4000001 	svc	#0x0
 ret
 79c:	d65f03c0 	ret

00000000000007a0 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 7a0:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 7a4:	d4000001 	svc	#0x0
 ret
 7a8:	d65f03c0 	ret

00000000000007ac <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 7ac:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 7b0:	d4000001 	svc	#0x0
 ret
 7b4:	d65f03c0 	ret

00000000000007b8 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 7b8:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 7bc:	d4000001 	svc	#0x0
 ret
 7c0:	d65f03c0 	ret

00000000000007c4 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 7c4:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 7c8:	d4000001 	svc	#0x0
 ret
 7cc:	d65f03c0 	ret

00000000000007d0 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 7d0:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 7d4:	d4000001 	svc	#0x0
 ret
 7d8:	d65f03c0 	ret

00000000000007dc <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 7dc:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 7e0:	d4000001 	svc	#0x0
 ret
 7e4:	d65f03c0 	ret

00000000000007e8 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 7e8:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 7ec:	d4000001 	svc	#0x0
 ret
 7f0:	d65f03c0 	ret

00000000000007f4 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 7f4:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 7f8:	d4000001 	svc	#0x0
 ret
 7fc:	d65f03c0 	ret

0000000000000800 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 800:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 804:	d4000001 	svc	#0x0
 ret
 808:	d65f03c0 	ret

000000000000080c <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 80c:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 810:	d4000001 	svc	#0x0
 ret
 814:	d65f03c0 	ret

0000000000000818 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 818:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 81c:	d4000001 	svc	#0x0
 ret
 820:	d65f03c0 	ret

0000000000000824 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 824:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 828:	d4000001 	svc	#0x0
 ret
 82c:	d65f03c0 	ret

0000000000000830 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 830:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 834:	d4000001 	svc	#0x0
 ret
 838:	d65f03c0 	ret

000000000000083c <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 83c:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 840:	d4000001 	svc	#0x0
 ret
 844:	d65f03c0 	ret

0000000000000848 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 848:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 84c:	d4000001 	svc	#0x0
 ret
 850:	d65f03c0 	ret

0000000000000854 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 854:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 858:	d4000001 	svc	#0x0
 ret
 85c:	d65f03c0 	ret

0000000000000860 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 860:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 864:	d4000001 	svc	#0x0
 ret
 868:	d65f03c0 	ret

000000000000086c <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 86c:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 870:	d4000001 	svc	#0x0
 ret
 874:	d65f03c0 	ret

0000000000000878 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 878:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 87c:	d4000001 	svc	#0x0
 ret
 880:	d65f03c0 	ret

0000000000000884 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 884:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 888:	d4000001 	svc	#0x0
 ret
 88c:	d65f03c0 	ret

0000000000000890 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 890:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 894:	d4000001 	svc	#0x0
 ret
 898:	d65f03c0 	ret

000000000000089c <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 89c:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 8a0:	d4000001 	svc	#0x0
 ret
 8a4:	d65f03c0 	ret

00000000000008a8 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 8a8:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 8ac:	d4000001 	svc	#0x0
 ret
 8b0:	d65f03c0 	ret

00000000000008b4 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 8b4:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 8b8:	d4000001 	svc	#0x0
 ret
 8bc:	d65f03c0 	ret

00000000000008c0 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 8c0:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 8c4:	d4000001 	svc	#0x0
 ret
 8c8:	d65f03c0 	ret

00000000000008cc <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 8cc:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 8d0:	d4000001 	svc	#0x0
 ret
 8d4:	d65f03c0 	ret

00000000000008d8 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 8d8:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 8dc:	d4000001 	svc	#0x0
 ret
 8e0:	d65f03c0 	ret

00000000000008e4 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 8e4:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 8e8:	d4000001 	svc	#0x0
 ret
 8ec:	d65f03c0 	ret

00000000000008f0 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 8f0:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 8f4:	d4000001 	svc	#0x0
 ret
 8f8:	d65f03c0 	ret

00000000000008fc <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 8fc:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 900:	d4000001 	svc	#0x0
 ret
 904:	d65f03c0 	ret

0000000000000908 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 908:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 90c:	d4000001 	svc	#0x0
 ret
 910:	d65f03c0 	ret

0000000000000914 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 914:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 918:	d4000001 	svc	#0x0
 ret
 91c:	d65f03c0 	ret

0000000000000920 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 920:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 924:	d4000001 	svc	#0x0
 ret
 928:	d65f03c0 	ret

000000000000092c <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 92c:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 930:	d4000001 	svc	#0x0
 ret
 934:	d65f03c0 	ret

0000000000000938 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 938:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 93c:	d4000001 	svc	#0x0
 ret
 940:	d65f03c0 	ret

0000000000000944 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 944:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 948:	d4000001 	svc	#0x0
 ret
 94c:	d65f03c0 	ret

0000000000000950 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 950:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 954:	d4000001 	svc	#0x0
 ret
 958:	d65f03c0 	ret

000000000000095c <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 95c:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 960:	d4000001 	svc	#0x0
 ret
 964:	d65f03c0 	ret

0000000000000968 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 968:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 96c:	d4000001 	svc	#0x0
 ret
 970:	d65f03c0 	ret

0000000000000974 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 974:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 978:	d4000001 	svc	#0x0
 ret
 97c:	d65f03c0 	ret

0000000000000980 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 980:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 984:	d4000001 	svc	#0x0
 ret
 988:	d65f03c0 	ret

000000000000098c <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 98c:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 990:	d4000001 	svc	#0x0
 ret
 994:	d65f03c0 	ret

0000000000000998 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 998:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 99c:	d4000001 	svc	#0x0
 ret
 9a0:	d65f03c0 	ret

00000000000009a4 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 9a4:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 9a8:	d4000001 	svc	#0x0
 ret
 9ac:	d65f03c0 	ret

00000000000009b0 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 9b0:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 9b4:	d4000001 	svc	#0x0
 ret
 9b8:	d65f03c0 	ret

00000000000009bc <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 9bc:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 9c0:	d4000001 	svc	#0x0
 ret
 9c4:	d65f03c0 	ret

00000000000009c8 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 9c8:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 9cc:	d4000001 	svc	#0x0
 ret
 9d0:	d65f03c0 	ret

00000000000009d4 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 9d4:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 9d8:	d4000001 	svc	#0x0
 ret
 9dc:	d65f03c0 	ret

00000000000009e0 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 9e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 9e4:	52800022 	mov	w2, #0x1                   	// #1
{
 9e8:	910003fd 	mov	x29, sp
 9ec:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 9f0:	91007fe1 	add	x1, sp, #0x1f
 9f4:	97ffff2f 	bl	6b0 <write>
 9f8:	7100041f 	cmp	w0, #0x1
}
 9fc:	1a9f17e0 	cset	w0, eq	// eq = none
 a00:	a8c27bfd 	ldp	x29, x30, [sp], #32
 a04:	d65f03c0 	ret

0000000000000a08 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 a08:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 a0c:	910003fd 	mov	x29, sp
 a10:	a90153f3 	stp	x19, x20, [sp, #16]
 a14:	a9025bf5 	stp	x21, x22, [sp, #32]
 a18:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 a1c:	6a417c7f 	tst	w3, w1, lsr #31
 a20:	54000300 	b.eq	a80 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 a24:	4b0103e1 	neg	w1, w1
    neg = 1;
 a28:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 a2c:	90000003 	adrp	x3, 0 <main>
 a30:	913d5463 	add	x3, x3, #0xf55
 a34:	9100c3f5 	add	x21, sp, #0x30
 a38:	d2800000 	mov	x0, #0x0                   	// #0
 a3c:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 a40:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 a44:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 a48:	2a0403e1 	mov	w1, w4
 a4c:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 a50:	38666866 	ldrb	w6, [x3, x6]
 a54:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 a58:	91000400 	add	x0, x0, #0x1
 a5c:	54ffff09 	b.ls	a3c <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 a60:	11000493 	add	w19, w4, #0x1
  if(neg)
 a64:	34000085 	cbz	w5, a74 <printint+0x6c>
    buf[i++] = '-';
 a68:	528005a0 	mov	w0, #0x2d                  	// #45
 a6c:	38334aa0 	strb	w0, [x21, w19, uxtw]
 a70:	11000893 	add	w19, w4, #0x2
 a74:	51000673 	sub	w19, w19, #0x1
 a78:	52800014 	mov	w20, #0x0                   	// #0
 a7c:	14000008 	b	a9c <printint+0x94>
  neg = 0;
 a80:	52800005 	mov	w5, #0x0                   	// #0
 a84:	17ffffea 	b	a2c <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 a88:	38736aa1 	ldrb	w1, [x21, x19]
 a8c:	2a1603e0 	mov	w0, w22
 a90:	d1000673 	sub	x19, x19, #0x1
 a94:	97ffffd3 	bl	9e0 <putc>
 a98:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 a9c:	3100067f 	cmn	w19, #0x1
 aa0:	54ffff41 	b.ne	a88 <printint+0x80>  // b.any
  return written;
}
 aa4:	a9425bf5 	ldp	x21, x22, [sp, #32]
 aa8:	2a1403e0 	mov	w0, w20
 aac:	a94153f3 	ldp	x19, x20, [sp, #16]
 ab0:	a8c47bfd 	ldp	x29, x30, [sp], #64
 ab4:	d65f03c0 	ret

0000000000000ab8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 ab8:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 abc:	910003fd 	mov	x29, sp
 ac0:	a90153f3 	stp	x19, x20, [sp, #16]
 ac4:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 ac8:	52800015 	mov	w21, #0x0                   	// #0
{
 acc:	a90363f7 	stp	x23, x24, [sp, #48]
 ad0:	2a0003f7 	mov	w23, w0
 ad4:	a9046bf9 	stp	x25, x26, [sp, #64]
 ad8:	aa0103f9 	mov	x25, x1

  state = 0;
 adc:	52800001 	mov	w1, #0x0                   	// #0
{
 ae0:	a90573fb 	stp	x27, x28, [sp, #80]
 ae4:	a9406053 	ldp	x19, x24, [x2]
 ae8:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 aec:	39400320 	ldrb	w0, [x25]
 af0:	35000120 	cbnz	w0, b14 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 af4:	2a1503e0 	mov	w0, w21
 af8:	a94153f3 	ldp	x19, x20, [sp, #16]
 afc:	a9425bf5 	ldp	x21, x22, [sp, #32]
 b00:	a94363f7 	ldp	x23, x24, [sp, #48]
 b04:	a9446bf9 	ldp	x25, x26, [sp, #64]
 b08:	a94573fb 	ldp	x27, x28, [sp, #80]
 b0c:	a8c67bfd 	ldp	x29, x30, [sp], #96
 b10:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 b14:	2a0003f6 	mov	w22, w0
    if(state == 0){
 b18:	35000101 	cbnz	w1, b38 <vprintf+0x80>
      if(c == '%'){
 b1c:	7100941f 	cmp	w0, #0x25
 b20:	54000ba0 	b.eq	c94 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 b24:	2a1603e1 	mov	w1, w22
 b28:	2a1703e0 	mov	w0, w23
 b2c:	97ffffad 	bl	9e0 <putc>
 b30:	0b0002b5 	add	w21, w21, w0
 b34:	14000057 	b	c90 <vprintf+0x1d8>
      if(c == 'd'){
 b38:	7101901f 	cmp	w0, #0x64
 b3c:	540002a1 	b.ne	b90 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 b40:	37f80174 	tbnz	w20, #31, b6c <vprintf+0xb4>
 b44:	91002e76 	add	x22, x19, #0xb
 b48:	2a1403fa 	mov	w26, w20
 b4c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b50:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 b54:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 b58:	b9400261 	ldr	w1, [x19]
 b5c:	2a1703e0 	mov	w0, w23
 b60:	97ffffaa 	bl	a08 <printint>
        written += putc(fd, va_arg(ap, uint));
 b64:	0b0002b5 	add	w21, w21, w0
 b68:	14000048 	b	c88 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 b6c:	1100229a 	add	w26, w20, #0x8
 b70:	7100035f 	cmp	w26, #0x0
 b74:	5400008d 	b.le	b84 <vprintf+0xcc>
 b78:	91002e76 	add	x22, x19, #0xb
 b7c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b80:	17fffff4 	b	b50 <vprintf+0x98>
 b84:	aa1303f6 	mov	x22, x19
 b88:	8b34c313 	add	x19, x24, w20, sxtw
 b8c:	17fffff1 	b	b50 <vprintf+0x98>
      } else if(c == 'l') {
 b90:	7101b01f 	cmp	w0, #0x6c
 b94:	54000201 	b.ne	bd4 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 b98:	37f800d4 	tbnz	w20, #31, bb0 <vprintf+0xf8>
 b9c:	91003e76 	add	x22, x19, #0xf
 ba0:	2a1403fa 	mov	w26, w20
 ba4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ba8:	52800003 	mov	w3, #0x0                   	// #0
 bac:	17ffffea 	b	b54 <vprintf+0x9c>
 bb0:	1100229a 	add	w26, w20, #0x8
 bb4:	7100035f 	cmp	w26, #0x0
 bb8:	5400008d 	b.le	bc8 <vprintf+0x110>
 bbc:	91003e76 	add	x22, x19, #0xf
 bc0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 bc4:	17fffff9 	b	ba8 <vprintf+0xf0>
 bc8:	aa1303f6 	mov	x22, x19
 bcc:	8b34c313 	add	x19, x24, w20, sxtw
 bd0:	17fffff6 	b	ba8 <vprintf+0xf0>
      } else if(c == 'x') {
 bd4:	7101e01f 	cmp	w0, #0x78
 bd8:	54000221 	b.ne	c1c <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 bdc:	37f800f4 	tbnz	w20, #31, bf8 <vprintf+0x140>
 be0:	91002e76 	add	x22, x19, #0xb
 be4:	2a1403fa 	mov	w26, w20
 be8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 bec:	52800003 	mov	w3, #0x0                   	// #0
 bf0:	52800202 	mov	w2, #0x10                  	// #16
 bf4:	17ffffd9 	b	b58 <vprintf+0xa0>
 bf8:	1100229a 	add	w26, w20, #0x8
 bfc:	7100035f 	cmp	w26, #0x0
 c00:	5400008d 	b.le	c10 <vprintf+0x158>
 c04:	91002e76 	add	x22, x19, #0xb
 c08:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c0c:	17fffff8 	b	bec <vprintf+0x134>
 c10:	aa1303f6 	mov	x22, x19
 c14:	8b34c313 	add	x19, x24, w20, sxtw
 c18:	17fffff5 	b	bec <vprintf+0x134>
      } else if(c == 'p') {
 c1c:	7101c01f 	cmp	w0, #0x70
 c20:	54000521 	b.ne	cc4 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 c24:	37f803f4 	tbnz	w20, #31, ca0 <vprintf+0x1e8>
 c28:	91003e76 	add	x22, x19, #0xf
 c2c:	2a1403fa 	mov	w26, w20
 c30:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c34:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 c38:	52800601 	mov	w1, #0x30                  	// #48
 c3c:	2a1703e0 	mov	w0, w23
 c40:	97ffff68 	bl	9e0 <putc>
 c44:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 c48:	9000001c 	adrp	x28, 0 <main>
 c4c:	913d579c 	add	x28, x28, #0xf55
  written += putc(fd, 'x');
 c50:	2a1703e0 	mov	w0, w23
 c54:	52800f01 	mov	w1, #0x78                  	// #120
 c58:	97ffff62 	bl	9e0 <putc>
 c5c:	0b000273 	add	w19, w19, w0
 c60:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 c64:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 c68:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 c6c:	38606b81 	ldrb	w1, [x28, x0]
 c70:	2a1703e0 	mov	w0, w23
 c74:	97ffff5b 	bl	9e0 <putc>
 c78:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 c7c:	71000694 	subs	w20, w20, #0x1
 c80:	54ffff21 	b.ne	c64 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 c84:	0b1302b5 	add	w21, w21, w19
 c88:	2a1a03f4 	mov	w20, w26
 c8c:	aa1603f3 	mov	x19, x22
      state = 0;
 c90:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 c94:	91000739 	add	x25, x25, #0x1
  state = 0;
 c98:	2a1603e1 	mov	w1, w22
 c9c:	17ffff94 	b	aec <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 ca0:	1100229a 	add	w26, w20, #0x8
 ca4:	7100035f 	cmp	w26, #0x0
 ca8:	5400008d 	b.le	cb8 <vprintf+0x200>
 cac:	91003e76 	add	x22, x19, #0xf
 cb0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cb4:	17ffffe0 	b	c34 <vprintf+0x17c>
 cb8:	aa1303f6 	mov	x22, x19
 cbc:	8b34c313 	add	x19, x24, w20, sxtw
 cc0:	17ffffdd 	b	c34 <vprintf+0x17c>
      } else if(c == 's'){
 cc4:	7101cc1f 	cmp	w0, #0x73
 cc8:	54000381 	b.ne	d38 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 ccc:	37f80214 	tbnz	w20, #31, d0c <vprintf+0x254>
 cd0:	91003e61 	add	x1, x19, #0xf
 cd4:	aa1303e0 	mov	x0, x19
 cd8:	927df033 	and	x19, x1, #0xfffffffffffffff8
 cdc:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 ce0:	90000000 	adrp	x0, 0 <main>
 ce4:	913d3800 	add	x0, x0, #0xf4e
 ce8:	f10002df 	cmp	x22, #0x0
 cec:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 cf0:	394002c1 	ldrb	w1, [x22]
 cf4:	34fffce1 	cbz	w1, c90 <vprintf+0x1d8>
          written += putc(fd, *s);
 cf8:	2a1703e0 	mov	w0, w23
          s++;
 cfc:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 d00:	97ffff38 	bl	9e0 <putc>
 d04:	0b0002b5 	add	w21, w21, w0
          s++;
 d08:	17fffffa 	b	cf0 <vprintf+0x238>
        s = va_arg(ap, char*);
 d0c:	11002281 	add	w1, w20, #0x8
 d10:	7100003f 	cmp	w1, #0x0
 d14:	540000cd 	b.le	d2c <vprintf+0x274>
 d18:	91003e62 	add	x2, x19, #0xf
 d1c:	aa1303e0 	mov	x0, x19
 d20:	2a0103f4 	mov	w20, w1
 d24:	927df053 	and	x19, x2, #0xfffffffffffffff8
 d28:	17ffffed 	b	cdc <vprintf+0x224>
 d2c:	8b34c300 	add	x0, x24, w20, sxtw
 d30:	2a0103f4 	mov	w20, w1
 d34:	17ffffea 	b	cdc <vprintf+0x224>
      } else if(c == 'c'){
 d38:	71018c1f 	cmp	w0, #0x63
 d3c:	54000241 	b.ne	d84 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 d40:	37f80114 	tbnz	w20, #31, d60 <vprintf+0x2a8>
 d44:	91002e76 	add	x22, x19, #0xb
 d48:	2a1403fa 	mov	w26, w20
 d4c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d50:	39400261 	ldrb	w1, [x19]
 d54:	2a1703e0 	mov	w0, w23
 d58:	97ffff22 	bl	9e0 <putc>
 d5c:	17ffff82 	b	b64 <vprintf+0xac>
 d60:	1100229a 	add	w26, w20, #0x8
 d64:	7100035f 	cmp	w26, #0x0
 d68:	5400008d 	b.le	d78 <vprintf+0x2c0>
 d6c:	91002e76 	add	x22, x19, #0xb
 d70:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d74:	17fffff7 	b	d50 <vprintf+0x298>
 d78:	aa1303f6 	mov	x22, x19
 d7c:	8b34c313 	add	x19, x24, w20, sxtw
 d80:	17fffff4 	b	d50 <vprintf+0x298>
      } else if(c == '%'){
 d84:	7100941f 	cmp	w0, #0x25
 d88:	54ffece0 	b.eq	b24 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 d8c:	2a1703e0 	mov	w0, w23
 d90:	528004a1 	mov	w1, #0x25                  	// #37
 d94:	97ffff13 	bl	9e0 <putc>
 d98:	0b0002b5 	add	w21, w21, w0
 d9c:	17ffff62 	b	b24 <vprintf+0x6c>

0000000000000da0 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 da0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 da4:	910003fd 	mov	x29, sp
 da8:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 dac:	910203e2 	add	x2, sp, #0x80
 db0:	a9030be2 	stp	x2, x2, [sp, #48]
 db4:	910143e2 	add	x2, sp, #0x50
 db8:	f90023e2 	str	x2, [sp, #64]
 dbc:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 dc0:	b9004be2 	str	w2, [sp, #72]
 dc4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 dc8:	a9430fe2 	ldp	x2, x3, [sp, #48]
 dcc:	a9010fe2 	stp	x2, x3, [sp, #16]
 dd0:	a9440fe2 	ldp	x2, x3, [sp, #64]
 dd4:	a9020fe2 	stp	x2, x3, [sp, #32]
 dd8:	910043e2 	add	x2, sp, #0x10
{
 ddc:	a90617e4 	stp	x4, x5, [sp, #96]
 de0:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 de4:	97ffff35 	bl	ab8 <vprintf>
  va_end(ap);
  return result;
}
 de8:	a8c87bfd 	ldp	x29, x30, [sp], #128
 dec:	d65f03c0 	ret

0000000000000df0 <printf>:

int
printf(const char *fmt, ...)
{
 df0:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 df4:	910003fd 	mov	x29, sp
 df8:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 dfc:	910243e1 	add	x1, sp, #0x90
 e00:	a90307e1 	stp	x1, x1, [sp, #48]
 e04:	910143e1 	add	x1, sp, #0x50
 e08:	f90023e1 	str	x1, [sp, #64]
 e0c:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 e10:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 e14:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 e18:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 e1c:	52800020 	mov	w0, #0x1                   	// #1
{
 e20:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 e24:	a9430fe2 	ldp	x2, x3, [sp, #48]
 e28:	a9010fe2 	stp	x2, x3, [sp, #16]
 e2c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 e30:	a9020fe2 	stp	x2, x3, [sp, #32]
 e34:	910043e2 	add	x2, sp, #0x10
{
 e38:	a9079be5 	stp	x5, x6, [sp, #120]
 e3c:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 e40:	97ffff1e 	bl	ab8 <vprintf>
  va_end(ap);
  return result;
}
 e44:	a8c97bfd 	ldp	x29, x30, [sp], #144
 e48:	d65f03c0 	ret
