
user/_wifi:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  return 0;
}

int
main(int argc, char **argv)
{
   0:	a9ad7bfd 	stp	x29, x30, [sp, #-304]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
   c:	f90013f5 	str	x21, [sp, #32]
  char config[256], *ssid, *psk;
  int fd, n;

  if(argc == 3){
  10:	71000c1f 	cmp	w0, #0x3
  14:	540001a1 	b.ne	48 <main+0x48>  // b.any
    ssid = argv[1];
    psk = argv[2];
  18:	a940d033 	ldp	x19, x20, [x1, #8]
    if(ssid == 0 || psk == 0){
      printf("wifi: expected ssid= and psk= in /etc/wifi.conf\n");
      exit(1);
    }
  }
  printf("wifi: connecting to %s\n", ssid);
  1c:	aa1303e1 	mov	x1, x19
  20:	90000000 	adrp	x0, 0 <main>
  24:	91347000 	add	x0, x0, #0xd1c
  28:	94000304 	bl	c38 <printf>
  if(wifi_connect(ssid, psk) < 0){
  2c:	aa1403e1 	mov	x1, x20
  30:	aa1303e0 	mov	x0, x19
  34:	940001a0 	bl	6b4 <wifi_connect>
  38:	36f80580 	tbz	w0, #31, e8 <main+0xe8>
    printf("wifi: association failed\n");
  3c:	90000000 	adrp	x0, 0 <main>
  40:	9134d000 	add	x0, x0, #0xd34
  44:	14000009 	b	68 <main+0x68>
    fd = open("/etc/wifi.conf", O_RDONLY);
  48:	90000000 	adrp	x0, 0 <main>
  4c:	91325000 	add	x0, x0, #0xc94
  50:	52800001 	mov	w1, #0x0                   	// #0
  54:	94000135 	bl	528 <open>
  58:	2a0003f5 	mov	w21, w0
    if(fd < 0){
  5c:	36f800c0 	tbz	w0, #31, 74 <main+0x74>
      printf("wifi: usage: wifi SSID PASSPHRASE\n");
  60:	90000000 	adrp	x0, 0 <main>
  64:	91328c00 	add	x0, x0, #0xca3
      printf("wifi: empty /etc/wifi.conf\n");
  68:	940002f4 	bl	c38 <printf>
      exit(1);
  6c:	52800020 	mov	w0, #0x1                   	// #1
  70:	94000116 	bl	4c8 <exit>
    n = read(fd, config, sizeof(config) - 1);
  74:	9100c3f3 	add	x19, sp, #0x30
  78:	52801fe2 	mov	w2, #0xff                  	// #255
  7c:	aa1303e1 	mov	x1, x19
  80:	9400011b 	bl	4ec <read>
  84:	2a0003f4 	mov	w20, w0
    close(fd);
  88:	2a1503e0 	mov	w0, w21
  8c:	9400011e 	bl	504 <close>
    if(n <= 0){
  90:	7100029f 	cmp	w20, #0x0
  94:	5400008c 	b.gt	a4 <main+0xa4>
      printf("wifi: empty /etc/wifi.conf\n");
  98:	90000000 	adrp	x0, 0 <main>
  9c:	91331800 	add	x0, x0, #0xcc6
  a0:	17fffff2 	b	68 <main+0x68>
    psk = value(config, "psk");
  a4:	aa1303e0 	mov	x0, x19
  a8:	90000001 	adrp	x1, 0 <main>
  ac:	91338821 	add	x1, x1, #0xce2
    config[n] = 0;
  b0:	38344a7f 	strb	wzr, [x19, w20, uxtw]
    psk = value(config, "psk");
  b4:	94000012 	bl	fc <value>
  b8:	aa0003f4 	mov	x20, x0
    ssid = value(config, "ssid");
  bc:	90000001 	adrp	x1, 0 <main>
  c0:	91339821 	add	x1, x1, #0xce6
  c4:	aa1303e0 	mov	x0, x19
  c8:	9400000d 	bl	fc <value>
    if(ssid == 0 || psk == 0){
  cc:	f100001f 	cmp	x0, #0x0
    ssid = value(config, "ssid");
  d0:	aa0003f3 	mov	x19, x0
    if(ssid == 0 || psk == 0){
  d4:	fa401a84 	ccmp	x20, #0x0, #0x4, ne	// ne = any
  d8:	54fffa21 	b.ne	1c <main+0x1c>  // b.any
      printf("wifi: expected ssid= and psk= in /etc/wifi.conf\n");
  dc:	90000000 	adrp	x0, 0 <main>
  e0:	9133ac00 	add	x0, x0, #0xceb
  e4:	17ffffe1 	b	68 <main+0x68>
    exit(1);
  }
  printf("wifi: associated\n");
  e8:	90000000 	adrp	x0, 0 <main>
  ec:	91353800 	add	x0, x0, #0xd4e
  f0:	940002d2 	bl	c38 <printf>
  exit(0);
  f4:	52800000 	mov	w0, #0x0                   	// #0
  f8:	17ffffde 	b	70 <main+0x70>

00000000000000fc <value>:
{
  fc:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 100:	910003fd 	mov	x29, sp
 104:	a90153f3 	stp	x19, x20, [sp, #16]
 108:	aa0003f3 	mov	x19, x0
  int n = strlen(name);
 10c:	aa0103e0 	mov	x0, x1
{
 110:	a9025bf5 	stp	x21, x22, [sp, #32]
 114:	aa0103f5 	mov	x21, x1
  int n = strlen(name);
 118:	94000063 	bl	2a4 <strlen>
 11c:	93407c14 	sxtw	x20, w0
 120:	aa1403f6 	mov	x22, x20
  while(*p){
 124:	39400260 	ldrb	w0, [x19]
 128:	35000060 	cbnz	w0, 134 <value+0x38>
  return 0;
 12c:	d2800000 	mov	x0, #0x0                   	// #0
 130:	14000013 	b	17c <value+0x80>
    if(strncmp(p, name, n) == 0 && p[n] == '='){
 134:	2a1603e2 	mov	w2, w22
 138:	aa1503e1 	mov	x1, x21
 13c:	aa1303e0 	mov	x0, x19
 140:	94000049 	bl	264 <strncmp>
 144:	350002a0 	cbnz	w0, 198 <value+0x9c>
 148:	38746a60 	ldrb	w0, [x19, x20]
 14c:	7100f41f 	cmp	w0, #0x3d
 150:	54000241 	b.ne	198 <value+0x9c>  // b.any
      char *v = p + n + 1;
 154:	91000694 	add	x20, x20, #0x1
      while(*end && *end != '\n' && *end != '\r')
 158:	92848023 	mov	x3, #0xffffffffffffdbfe    	// #-9218
      char *v = p + n + 1;
 15c:	8b140260 	add	x0, x19, x20
      char *end = v;
 160:	aa0003e1 	mov	x1, x0
      while(*end && *end != '\n' && *end != '\r')
 164:	39400022 	ldrb	w2, [x1]
 168:	7100345f 	cmp	w2, #0xd
 16c:	54000108 	b.hi	18c <value+0x90>  // b.pmore
 170:	9ac22862 	asr	x2, x3, x2
 174:	370000c2 	tbnz	w2, #0, 18c <value+0x90>
      *end = 0;
 178:	3900003f 	strb	wzr, [x1]
}
 17c:	a94153f3 	ldp	x19, x20, [sp, #16]
 180:	a9425bf5 	ldp	x21, x22, [sp, #32]
 184:	a8c37bfd 	ldp	x29, x30, [sp], #48
 188:	d65f03c0 	ret
        end++;
 18c:	91000421 	add	x1, x1, #0x1
 190:	17fffff5 	b	164 <value+0x68>
      p++;
 194:	91000673 	add	x19, x19, #0x1
    while(*p && *p != '\n')
 198:	39400260 	ldrb	w0, [x19]
 19c:	7100001f 	cmp	w0, #0x0
 1a0:	7a4a1804 	ccmp	w0, #0xa, #0x4, ne	// ne = any
 1a4:	54ffff81 	b.ne	194 <value+0x98>  // b.any
      p++;
 1a8:	7100001f 	cmp	w0, #0x0
 1ac:	9a930673 	cinc	x19, x19, ne	// ne = any
 1b0:	17ffffdd 	b	124 <value+0x28>

00000000000001b4 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1b4:	d2800002 	mov	x2, #0x0                   	// #0
 1b8:	38626823 	ldrb	w3, [x1, x2]
 1bc:	38226803 	strb	w3, [x0, x2]
 1c0:	91000442 	add	x2, x2, #0x1
 1c4:	35ffffa3 	cbnz	w3, 1b8 <strcpy+0x4>
    ;
  return os;
}
 1c8:	d65f03c0 	ret

00000000000001cc <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 1cc:	d2800003 	mov	x3, #0x0                   	// #0
 1d0:	4b030044 	sub	w4, w2, w3
 1d4:	7100009f 	cmp	w4, #0x0
 1d8:	5400006d 	b.le	1e4 <strncpy+0x18>
 1dc:	38636825 	ldrb	w5, [x1, x3]
 1e0:	350000e5 	cbnz	w5, 1fc <strncpy+0x30>
 1e4:	8b030003 	add	x3, x0, x3
 1e8:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 1ec:	4b010082 	sub	w2, w4, w1
 1f0:	7100005f 	cmp	w2, #0x0
 1f4:	540000ac 	b.gt	208 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 1f8:	d65f03c0 	ret
    *s++ = *t++;
 1fc:	38236805 	strb	w5, [x0, x3]
    n--;
 200:	91000463 	add	x3, x3, #0x1
 204:	17fffff3 	b	1d0 <strncpy+0x4>
    *s++ = 0;
 208:	3821687f 	strb	wzr, [x3, x1]
 20c:	91000421 	add	x1, x1, #0x1
 210:	17fffff7 	b	1ec <strncpy+0x20>

0000000000000214 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 214:	aa0003e2 	mov	x2, x0
 218:	39400043 	ldrb	w3, [x2]
 21c:	aa0203e4 	mov	x4, x2
    s++;
 220:	91000442 	add	x2, x2, #0x1
  while(*s)
 224:	35ffffa3 	cbnz	w3, 218 <strcat+0x4>
 228:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 22c:	38626823 	ldrb	w3, [x1, x2]
 230:	38226883 	strb	w3, [x4, x2]
 234:	91000442 	add	x2, x2, #0x1
 238:	35ffffa3 	cbnz	w3, 22c <strcat+0x18>
    ;
  return os;
}
 23c:	d65f03c0 	ret

0000000000000240 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 240:	d2800002 	mov	x2, #0x0                   	// #0
 244:	38626803 	ldrb	w3, [x0, x2]
 248:	38626824 	ldrb	w4, [x1, x2]
 24c:	34000083 	cbz	w3, 25c <strcmp+0x1c>
 250:	91000442 	add	x2, x2, #0x1
 254:	6b04007f 	cmp	w3, w4
 258:	54ffff60 	b.eq	244 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 25c:	4b040060 	sub	w0, w3, w4
 260:	d65f03c0 	ret

0000000000000264 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 264:	340001c2 	cbz	w2, 29c <strncmp+0x38>
 268:	39400003 	ldrb	w3, [x0]
 26c:	34000083 	cbz	w3, 27c <strncmp+0x18>
 270:	39400024 	ldrb	w4, [x1]
 274:	6b03009f 	cmp	w4, w3
 278:	540000a0 	b.eq	28c <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 27c:	39400000 	ldrb	w0, [x0]
 280:	39400021 	ldrb	w1, [x1]
 284:	4b010000 	sub	w0, w0, w1
}
 288:	d65f03c0 	ret
    n--, p++, q++;
 28c:	51000442 	sub	w2, w2, #0x1
 290:	91000400 	add	x0, x0, #0x1
 294:	91000421 	add	x1, x1, #0x1
 298:	17fffff3 	b	264 <strncmp>
    return 0;
 29c:	52800000 	mov	w0, #0x0                   	// #0
 2a0:	17fffffa 	b	288 <strncmp+0x24>

00000000000002a4 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 2a4:	d1000402 	sub	x2, x0, #0x1
 2a8:	d2800001 	mov	x1, #0x0                   	// #0
 2ac:	aa0103e0 	mov	x0, x1
 2b0:	91000421 	add	x1, x1, #0x1
 2b4:	38616843 	ldrb	w3, [x2, x1]
 2b8:	35ffffa3 	cbnz	w3, 2ac <strlen+0x8>
    ;
  return n;
}
 2bc:	d65f03c0 	ret

00000000000002c0 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 2c0:	d1000403 	sub	x3, x0, #0x1
 2c4:	d2800002 	mov	x2, #0x0                   	// #0
 2c8:	2a0203e0 	mov	w0, w2
 2cc:	6b02003f 	cmp	w1, w2
 2d0:	54000089 	b.ls	2e0 <strnlen+0x20>  // b.plast
 2d4:	91000442 	add	x2, x2, #0x1
 2d8:	38626864 	ldrb	w4, [x3, x2]
 2dc:	35ffff64 	cbnz	w4, 2c8 <strnlen+0x8>
    n++;
  return n;
}
 2e0:	d65f03c0 	ret

00000000000002e4 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2e4:	d2800003 	mov	x3, #0x0                   	// #0
 2e8:	6b03005f 	cmp	w2, w3
 2ec:	54000048 	b.hi	2f4 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 2f0:	d65f03c0 	ret
    cdst[i] = c;
 2f4:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 2f8:	91000463 	add	x3, x3, #0x1
 2fc:	17fffffb 	b	2e8 <memset+0x4>

0000000000000300 <strchr>:

char*
strchr(const char *s, char c)
{
 300:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 304:	39400002 	ldrb	w2, [x0]
 308:	35000062 	cbnz	w2, 314 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 30c:	d2800000 	mov	x0, #0x0                   	// #0
}
 310:	d65f03c0 	ret
    if(*s == c)
 314:	6b01005f 	cmp	w2, w1
 318:	54ffffc0 	b.eq	310 <strchr+0x10>  // b.none
  for(; *s; s++)
 31c:	91000400 	add	x0, x0, #0x1
 320:	17fffff9 	b	304 <strchr+0x4>

0000000000000324 <gets>:

char*
gets(char *buf, int max)
{
 324:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 328:	910003fd 	mov	x29, sp
 32c:	a90153f3 	stp	x19, x20, [sp, #16]
 330:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 334:	d2800014 	mov	x20, #0x0                   	// #0
{
 338:	f9001bf7 	str	x23, [sp, #48]
 33c:	2a0103f7 	mov	w23, w1
 340:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 344:	11000695 	add	w21, w20, #0x1
 348:	2a1403f6 	mov	w22, w20
 34c:	6b1702bf 	cmp	w21, w23
 350:	540000ea 	b.ge	36c <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 354:	91013fe1 	add	x1, sp, #0x4f
 358:	52800022 	mov	w2, #0x1                   	// #1
 35c:	52800000 	mov	w0, #0x0                   	// #0
 360:	94000063 	bl	4ec <read>
    if(cc < 1)
 364:	7100001f 	cmp	w0, #0x0
 368:	5400012c 	b.gt	38c <gets+0x68>
  for(i=0; i+1 < max; ){
 36c:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 370:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 374:	aa1303e0 	mov	x0, x19
 378:	f9401bf7 	ldr	x23, [sp, #48]
 37c:	a94153f3 	ldp	x19, x20, [sp, #16]
 380:	a9425bf5 	ldp	x21, x22, [sp, #32]
 384:	a8c57bfd 	ldp	x29, x30, [sp], #80
 388:	d65f03c0 	ret
    buf[i++] = c;
 38c:	39413fe0 	ldrb	w0, [sp, #79]
 390:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 394:	91000694 	add	x20, x20, #0x1
 398:	7100281f 	cmp	w0, #0xa
 39c:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 3a0:	54fffd21 	b.ne	344 <gets+0x20>  // b.any
 3a4:	17fffff3 	b	370 <gets+0x4c>

00000000000003a8 <stat>:

int
stat(const char *n, struct stat *st)
{
 3a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 3ac:	910003fd 	mov	x29, sp
 3b0:	a90153f3 	stp	x19, x20, [sp, #16]
 3b4:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3b8:	52800001 	mov	w1, #0x0                   	// #0
 3bc:	9400005b 	bl	528 <open>
  if(fd < 0)
 3c0:	37f80160 	tbnz	w0, #31, 3ec <stat+0x44>
    return -1;
  r = fstat(fd, st);
 3c4:	aa1303e1 	mov	x1, x19
 3c8:	2a0003f4 	mov	w20, w0
 3cc:	94000060 	bl	54c <fstat>
 3d0:	2a0003f3 	mov	w19, w0
  close(fd);
 3d4:	2a1403e0 	mov	w0, w20
 3d8:	9400004b 	bl	504 <close>
  return r;
}
 3dc:	2a1303e0 	mov	w0, w19
 3e0:	a94153f3 	ldp	x19, x20, [sp, #16]
 3e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
 3e8:	d65f03c0 	ret
    return -1;
 3ec:	12800013 	mov	w19, #0xffffffff            	// #-1
 3f0:	17fffffb 	b	3dc <stat+0x34>

00000000000003f4 <atoi>:

int
atoi(const char *s)
{
 3f4:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 3f8:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 3fc:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 400:	39400043 	ldrb	w3, [x2]
 404:	5100c061 	sub	w1, w3, #0x30
 408:	12001c21 	and	w1, w1, #0xff
 40c:	7100243f 	cmp	w1, #0x9
 410:	54000049 	b.ls	418 <atoi+0x24>  // b.plast
  return n;
}
 414:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 418:	1b040c01 	madd	w1, w0, w4, w3
 41c:	91000442 	add	x2, x2, #0x1
 420:	5100c020 	sub	w0, w1, #0x30
 424:	17fffff7 	b	400 <atoi+0xc>

0000000000000428 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 428:	eb01001f 	cmp	x0, x1
 42c:	54000263 	b.cc	478 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 430:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 434:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 438:	d2800003 	mov	x3, #0x0                   	// #0
 43c:	d1000463 	sub	x3, x3, #0x1
 440:	11000464 	add	w4, w3, #0x1
 444:	0b020084 	add	w4, w4, w2
 448:	7100009f 	cmp	w4, #0x0
 44c:	5400014d 	b.le	474 <memmove+0x4c>
      *--dst = *--src;
 450:	38636824 	ldrb	w4, [x1, x3]
 454:	382368a4 	strb	w4, [x5, x3]
 458:	17fffff9 	b	43c <memmove+0x14>
      *dst++ = *src++;
 45c:	38636824 	ldrb	w4, [x1, x3]
 460:	38236804 	strb	w4, [x0, x3]
 464:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 468:	4b030044 	sub	w4, w2, w3
 46c:	7100009f 	cmp	w4, #0x0
 470:	54ffff6c 	b.gt	45c <memmove+0x34>
  }
  return vdst;
}
 474:	d65f03c0 	ret
 478:	d2800003 	mov	x3, #0x0                   	// #0
 47c:	17fffffb 	b	468 <memmove+0x40>

0000000000000480 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 480:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 484:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 488:	d2800004 	mov	x4, #0x0                   	// #0
 48c:	eb02009f 	cmp	x4, x2
 490:	54000061 	b.ne	49c <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 494:	52800000 	mov	w0, #0x0                   	// #0
 498:	14000007 	b	4b4 <memcmp+0x34>
    if (*p1 != *p2) {
 49c:	38646803 	ldrb	w3, [x0, x4]
 4a0:	91000484 	add	x4, x4, #0x1
 4a4:	38646825 	ldrb	w5, [x1, x4]
 4a8:	6b05007f 	cmp	w3, w5
 4ac:	54ffff00 	b.eq	48c <memcmp+0xc>  // b.none
      return *p1 - *p2;
 4b0:	4b050060 	sub	w0, w3, w5
}
 4b4:	d65f03c0 	ret

00000000000004b8 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 4b8:	17ffffdc 	b	428 <memmove>

00000000000004bc <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 4bc:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 4c0:	d4000001 	svc	#0x0
 ret
 4c4:	d65f03c0 	ret

00000000000004c8 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 4c8:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 4cc:	d4000001 	svc	#0x0
 ret
 4d0:	d65f03c0 	ret

00000000000004d4 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 4d4:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 4d8:	d4000001 	svc	#0x0
 ret
 4dc:	d65f03c0 	ret

00000000000004e0 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 4e0:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 4e4:	d4000001 	svc	#0x0
 ret
 4e8:	d65f03c0 	ret

00000000000004ec <read>:
.global read
read:
 mov x7, #SYS_read
 4ec:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 4f0:	d4000001 	svc	#0x0
 ret
 4f4:	d65f03c0 	ret

00000000000004f8 <write>:
.global write
write:
 mov x7, #SYS_write
 4f8:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 4fc:	d4000001 	svc	#0x0
 ret
 500:	d65f03c0 	ret

0000000000000504 <close>:
.global close
close:
 mov x7, #SYS_close
 504:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 508:	d4000001 	svc	#0x0
 ret
 50c:	d65f03c0 	ret

0000000000000510 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 510:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 514:	d4000001 	svc	#0x0
 ret
 518:	d65f03c0 	ret

000000000000051c <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 51c:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 520:	d4000001 	svc	#0x0
 ret
 524:	d65f03c0 	ret

0000000000000528 <open>:
.global open
open:
 mov x7, #SYS_open
 528:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 52c:	d4000001 	svc	#0x0
 ret
 530:	d65f03c0 	ret

0000000000000534 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 534:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 538:	d4000001 	svc	#0x0
 ret
 53c:	d65f03c0 	ret

0000000000000540 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 540:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 544:	d4000001 	svc	#0x0
 ret
 548:	d65f03c0 	ret

000000000000054c <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 54c:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 550:	d4000001 	svc	#0x0
 ret
 554:	d65f03c0 	ret

0000000000000558 <link>:
.global link
link:
 mov x7, #SYS_link
 558:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 55c:	d4000001 	svc	#0x0
 ret
 560:	d65f03c0 	ret

0000000000000564 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 564:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 568:	d4000001 	svc	#0x0
 ret
 56c:	d65f03c0 	ret

0000000000000570 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 570:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 574:	d4000001 	svc	#0x0
 ret
 578:	d65f03c0 	ret

000000000000057c <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 57c:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 580:	d4000001 	svc	#0x0
 ret
 584:	d65f03c0 	ret

0000000000000588 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 588:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 58c:	d4000001 	svc	#0x0
 ret
 590:	d65f03c0 	ret

0000000000000594 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 594:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 598:	d4000001 	svc	#0x0
 ret
 59c:	d65f03c0 	ret

00000000000005a0 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 5a0:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 5a4:	d4000001 	svc	#0x0
 ret
 5a8:	d65f03c0 	ret

00000000000005ac <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 5ac:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 5b0:	d4000001 	svc	#0x0
 ret
 5b4:	d65f03c0 	ret

00000000000005b8 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 5b8:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 5bc:	d4000001 	svc	#0x0
 ret
 5c0:	d65f03c0 	ret

00000000000005c4 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 5c4:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 5c8:	d4000001 	svc	#0x0
 ret
 5cc:	d65f03c0 	ret

00000000000005d0 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 5d0:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 5d4:	d4000001 	svc	#0x0
 ret
 5d8:	d65f03c0 	ret

00000000000005dc <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 5dc:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 5e0:	d4000001 	svc	#0x0
 ret
 5e4:	d65f03c0 	ret

00000000000005e8 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 5e8:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 5ec:	d4000001 	svc	#0x0
 ret
 5f0:	d65f03c0 	ret

00000000000005f4 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 5f4:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 5f8:	d4000001 	svc	#0x0
 ret
 5fc:	d65f03c0 	ret

0000000000000600 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 600:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 604:	d4000001 	svc	#0x0
 ret
 608:	d65f03c0 	ret

000000000000060c <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 60c:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 610:	d4000001 	svc	#0x0
 ret
 614:	d65f03c0 	ret

0000000000000618 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 618:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 61c:	d4000001 	svc	#0x0
 ret
 620:	d65f03c0 	ret

0000000000000624 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 624:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 628:	d4000001 	svc	#0x0
 ret
 62c:	d65f03c0 	ret

0000000000000630 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 630:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 634:	d4000001 	svc	#0x0
 ret
 638:	d65f03c0 	ret

000000000000063c <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 63c:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 640:	d4000001 	svc	#0x0
 ret
 644:	d65f03c0 	ret

0000000000000648 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 648:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 64c:	d4000001 	svc	#0x0
 ret
 650:	d65f03c0 	ret

0000000000000654 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 654:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 658:	d4000001 	svc	#0x0
 ret
 65c:	d65f03c0 	ret

0000000000000660 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 660:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 664:	d4000001 	svc	#0x0
 ret
 668:	d65f03c0 	ret

000000000000066c <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 66c:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 670:	d4000001 	svc	#0x0
 ret
 674:	d65f03c0 	ret

0000000000000678 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 678:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 67c:	d4000001 	svc	#0x0
 ret
 680:	d65f03c0 	ret

0000000000000684 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 684:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 688:	d4000001 	svc	#0x0
 ret
 68c:	d65f03c0 	ret

0000000000000690 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 690:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 694:	d4000001 	svc	#0x0
 ret
 698:	d65f03c0 	ret

000000000000069c <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 69c:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 6a0:	d4000001 	svc	#0x0
 ret
 6a4:	d65f03c0 	ret

00000000000006a8 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 6a8:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 6ac:	d4000001 	svc	#0x0
 ret
 6b0:	d65f03c0 	ret

00000000000006b4 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 6b4:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 6b8:	d4000001 	svc	#0x0
 ret
 6bc:	d65f03c0 	ret

00000000000006c0 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 6c0:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 6c4:	d4000001 	svc	#0x0
 ret
 6c8:	d65f03c0 	ret

00000000000006cc <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 6cc:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 6d0:	d4000001 	svc	#0x0
 ret
 6d4:	d65f03c0 	ret

00000000000006d8 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 6d8:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 6dc:	d4000001 	svc	#0x0
 ret
 6e0:	d65f03c0 	ret

00000000000006e4 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 6e4:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 6e8:	d4000001 	svc	#0x0
 ret
 6ec:	d65f03c0 	ret

00000000000006f0 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 6f0:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 6f4:	d4000001 	svc	#0x0
 ret
 6f8:	d65f03c0 	ret

00000000000006fc <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 6fc:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 700:	d4000001 	svc	#0x0
 ret
 704:	d65f03c0 	ret

0000000000000708 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 708:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 70c:	d4000001 	svc	#0x0
 ret
 710:	d65f03c0 	ret

0000000000000714 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 714:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 718:	d4000001 	svc	#0x0
 ret
 71c:	d65f03c0 	ret

0000000000000720 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 720:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 724:	d4000001 	svc	#0x0
 ret
 728:	d65f03c0 	ret

000000000000072c <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 72c:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 730:	d4000001 	svc	#0x0
 ret
 734:	d65f03c0 	ret

0000000000000738 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 738:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 73c:	d4000001 	svc	#0x0
 ret
 740:	d65f03c0 	ret

0000000000000744 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 744:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 748:	d4000001 	svc	#0x0
 ret
 74c:	d65f03c0 	ret

0000000000000750 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 750:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 754:	d4000001 	svc	#0x0
 ret
 758:	d65f03c0 	ret

000000000000075c <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 75c:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 760:	d4000001 	svc	#0x0
 ret
 764:	d65f03c0 	ret

0000000000000768 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 768:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 76c:	d4000001 	svc	#0x0
 ret
 770:	d65f03c0 	ret

0000000000000774 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 774:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 778:	d4000001 	svc	#0x0
 ret
 77c:	d65f03c0 	ret

0000000000000780 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 780:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 784:	d4000001 	svc	#0x0
 ret
 788:	d65f03c0 	ret

000000000000078c <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 78c:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 790:	d4000001 	svc	#0x0
 ret
 794:	d65f03c0 	ret

0000000000000798 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 798:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 79c:	d4000001 	svc	#0x0
 ret
 7a0:	d65f03c0 	ret

00000000000007a4 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 7a4:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 7a8:	d4000001 	svc	#0x0
 ret
 7ac:	d65f03c0 	ret

00000000000007b0 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 7b0:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 7b4:	d4000001 	svc	#0x0
 ret
 7b8:	d65f03c0 	ret

00000000000007bc <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 7bc:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 7c0:	d4000001 	svc	#0x0
 ret
 7c4:	d65f03c0 	ret

00000000000007c8 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 7c8:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 7cc:	d4000001 	svc	#0x0
 ret
 7d0:	d65f03c0 	ret

00000000000007d4 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 7d4:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 7d8:	d4000001 	svc	#0x0
 ret
 7dc:	d65f03c0 	ret

00000000000007e0 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 7e0:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 7e4:	d4000001 	svc	#0x0
 ret
 7e8:	d65f03c0 	ret

00000000000007ec <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 7ec:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 7f0:	d4000001 	svc	#0x0
 ret
 7f4:	d65f03c0 	ret

00000000000007f8 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 7f8:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 7fc:	d4000001 	svc	#0x0
 ret
 800:	d65f03c0 	ret

0000000000000804 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 804:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 808:	d4000001 	svc	#0x0
 ret
 80c:	d65f03c0 	ret

0000000000000810 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 810:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 814:	d4000001 	svc	#0x0
 ret
 818:	d65f03c0 	ret

000000000000081c <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 81c:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 820:	d4000001 	svc	#0x0
 ret
 824:	d65f03c0 	ret

0000000000000828 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 828:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 82c:	52800022 	mov	w2, #0x1                   	// #1
{
 830:	910003fd 	mov	x29, sp
 834:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 838:	91007fe1 	add	x1, sp, #0x1f
 83c:	97ffff2f 	bl	4f8 <write>
 840:	7100041f 	cmp	w0, #0x1
}
 844:	1a9f17e0 	cset	w0, eq	// eq = none
 848:	a8c27bfd 	ldp	x29, x30, [sp], #32
 84c:	d65f03c0 	ret

0000000000000850 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 850:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 854:	910003fd 	mov	x29, sp
 858:	a90153f3 	stp	x19, x20, [sp, #16]
 85c:	a9025bf5 	stp	x21, x22, [sp, #32]
 860:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 864:	6a417c7f 	tst	w3, w1, lsr #31
 868:	54000300 	b.eq	8c8 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 86c:	4b0103e1 	neg	w1, w1
    neg = 1;
 870:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 874:	90000003 	adrp	x3, 0 <main>
 878:	91359c63 	add	x3, x3, #0xd67
 87c:	9100c3f5 	add	x21, sp, #0x30
 880:	d2800000 	mov	x0, #0x0                   	// #0
 884:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 888:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 88c:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 890:	2a0403e1 	mov	w1, w4
 894:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 898:	38666866 	ldrb	w6, [x3, x6]
 89c:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 8a0:	91000400 	add	x0, x0, #0x1
 8a4:	54ffff09 	b.ls	884 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 8a8:	11000493 	add	w19, w4, #0x1
  if(neg)
 8ac:	34000085 	cbz	w5, 8bc <printint+0x6c>
    buf[i++] = '-';
 8b0:	528005a0 	mov	w0, #0x2d                  	// #45
 8b4:	38334aa0 	strb	w0, [x21, w19, uxtw]
 8b8:	11000893 	add	w19, w4, #0x2
 8bc:	51000673 	sub	w19, w19, #0x1
 8c0:	52800014 	mov	w20, #0x0                   	// #0
 8c4:	14000008 	b	8e4 <printint+0x94>
  neg = 0;
 8c8:	52800005 	mov	w5, #0x0                   	// #0
 8cc:	17ffffea 	b	874 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 8d0:	38736aa1 	ldrb	w1, [x21, x19]
 8d4:	2a1603e0 	mov	w0, w22
 8d8:	d1000673 	sub	x19, x19, #0x1
 8dc:	97ffffd3 	bl	828 <putc>
 8e0:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 8e4:	3100067f 	cmn	w19, #0x1
 8e8:	54ffff41 	b.ne	8d0 <printint+0x80>  // b.any
  return written;
}
 8ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
 8f0:	2a1403e0 	mov	w0, w20
 8f4:	a94153f3 	ldp	x19, x20, [sp, #16]
 8f8:	a8c47bfd 	ldp	x29, x30, [sp], #64
 8fc:	d65f03c0 	ret

0000000000000900 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 900:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 904:	910003fd 	mov	x29, sp
 908:	a90153f3 	stp	x19, x20, [sp, #16]
 90c:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 910:	52800015 	mov	w21, #0x0                   	// #0
{
 914:	a90363f7 	stp	x23, x24, [sp, #48]
 918:	2a0003f7 	mov	w23, w0
 91c:	a9046bf9 	stp	x25, x26, [sp, #64]
 920:	aa0103f9 	mov	x25, x1

  state = 0;
 924:	52800001 	mov	w1, #0x0                   	// #0
{
 928:	a90573fb 	stp	x27, x28, [sp, #80]
 92c:	a9406053 	ldp	x19, x24, [x2]
 930:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 934:	39400320 	ldrb	w0, [x25]
 938:	35000120 	cbnz	w0, 95c <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 93c:	2a1503e0 	mov	w0, w21
 940:	a94153f3 	ldp	x19, x20, [sp, #16]
 944:	a9425bf5 	ldp	x21, x22, [sp, #32]
 948:	a94363f7 	ldp	x23, x24, [sp, #48]
 94c:	a9446bf9 	ldp	x25, x26, [sp, #64]
 950:	a94573fb 	ldp	x27, x28, [sp, #80]
 954:	a8c67bfd 	ldp	x29, x30, [sp], #96
 958:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 95c:	2a0003f6 	mov	w22, w0
    if(state == 0){
 960:	35000101 	cbnz	w1, 980 <vprintf+0x80>
      if(c == '%'){
 964:	7100941f 	cmp	w0, #0x25
 968:	54000ba0 	b.eq	adc <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 96c:	2a1603e1 	mov	w1, w22
 970:	2a1703e0 	mov	w0, w23
 974:	97ffffad 	bl	828 <putc>
 978:	0b0002b5 	add	w21, w21, w0
 97c:	14000057 	b	ad8 <vprintf+0x1d8>
      if(c == 'd'){
 980:	7101901f 	cmp	w0, #0x64
 984:	540002a1 	b.ne	9d8 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 988:	37f80174 	tbnz	w20, #31, 9b4 <vprintf+0xb4>
 98c:	91002e76 	add	x22, x19, #0xb
 990:	2a1403fa 	mov	w26, w20
 994:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 998:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 99c:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 9a0:	b9400261 	ldr	w1, [x19]
 9a4:	2a1703e0 	mov	w0, w23
 9a8:	97ffffaa 	bl	850 <printint>
        written += putc(fd, va_arg(ap, uint));
 9ac:	0b0002b5 	add	w21, w21, w0
 9b0:	14000048 	b	ad0 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 9b4:	1100229a 	add	w26, w20, #0x8
 9b8:	7100035f 	cmp	w26, #0x0
 9bc:	5400008d 	b.le	9cc <vprintf+0xcc>
 9c0:	91002e76 	add	x22, x19, #0xb
 9c4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9c8:	17fffff4 	b	998 <vprintf+0x98>
 9cc:	aa1303f6 	mov	x22, x19
 9d0:	8b34c313 	add	x19, x24, w20, sxtw
 9d4:	17fffff1 	b	998 <vprintf+0x98>
      } else if(c == 'l') {
 9d8:	7101b01f 	cmp	w0, #0x6c
 9dc:	54000201 	b.ne	a1c <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 9e0:	37f800d4 	tbnz	w20, #31, 9f8 <vprintf+0xf8>
 9e4:	91003e76 	add	x22, x19, #0xf
 9e8:	2a1403fa 	mov	w26, w20
 9ec:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9f0:	52800003 	mov	w3, #0x0                   	// #0
 9f4:	17ffffea 	b	99c <vprintf+0x9c>
 9f8:	1100229a 	add	w26, w20, #0x8
 9fc:	7100035f 	cmp	w26, #0x0
 a00:	5400008d 	b.le	a10 <vprintf+0x110>
 a04:	91003e76 	add	x22, x19, #0xf
 a08:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a0c:	17fffff9 	b	9f0 <vprintf+0xf0>
 a10:	aa1303f6 	mov	x22, x19
 a14:	8b34c313 	add	x19, x24, w20, sxtw
 a18:	17fffff6 	b	9f0 <vprintf+0xf0>
      } else if(c == 'x') {
 a1c:	7101e01f 	cmp	w0, #0x78
 a20:	54000221 	b.ne	a64 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 a24:	37f800f4 	tbnz	w20, #31, a40 <vprintf+0x140>
 a28:	91002e76 	add	x22, x19, #0xb
 a2c:	2a1403fa 	mov	w26, w20
 a30:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a34:	52800003 	mov	w3, #0x0                   	// #0
 a38:	52800202 	mov	w2, #0x10                  	// #16
 a3c:	17ffffd9 	b	9a0 <vprintf+0xa0>
 a40:	1100229a 	add	w26, w20, #0x8
 a44:	7100035f 	cmp	w26, #0x0
 a48:	5400008d 	b.le	a58 <vprintf+0x158>
 a4c:	91002e76 	add	x22, x19, #0xb
 a50:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a54:	17fffff8 	b	a34 <vprintf+0x134>
 a58:	aa1303f6 	mov	x22, x19
 a5c:	8b34c313 	add	x19, x24, w20, sxtw
 a60:	17fffff5 	b	a34 <vprintf+0x134>
      } else if(c == 'p') {
 a64:	7101c01f 	cmp	w0, #0x70
 a68:	54000521 	b.ne	b0c <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 a6c:	37f803f4 	tbnz	w20, #31, ae8 <vprintf+0x1e8>
 a70:	91003e76 	add	x22, x19, #0xf
 a74:	2a1403fa 	mov	w26, w20
 a78:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a7c:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 a80:	52800601 	mov	w1, #0x30                  	// #48
 a84:	2a1703e0 	mov	w0, w23
 a88:	97ffff68 	bl	828 <putc>
 a8c:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a90:	9000001c 	adrp	x28, 0 <main>
 a94:	91359f9c 	add	x28, x28, #0xd67
  written += putc(fd, 'x');
 a98:	2a1703e0 	mov	w0, w23
 a9c:	52800f01 	mov	w1, #0x78                  	// #120
 aa0:	97ffff62 	bl	828 <putc>
 aa4:	0b000273 	add	w19, w19, w0
 aa8:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 aac:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 ab0:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 ab4:	38606b81 	ldrb	w1, [x28, x0]
 ab8:	2a1703e0 	mov	w0, w23
 abc:	97ffff5b 	bl	828 <putc>
 ac0:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 ac4:	71000694 	subs	w20, w20, #0x1
 ac8:	54ffff21 	b.ne	aac <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 acc:	0b1302b5 	add	w21, w21, w19
 ad0:	2a1a03f4 	mov	w20, w26
 ad4:	aa1603f3 	mov	x19, x22
      state = 0;
 ad8:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 adc:	91000739 	add	x25, x25, #0x1
  state = 0;
 ae0:	2a1603e1 	mov	w1, w22
 ae4:	17ffff94 	b	934 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 ae8:	1100229a 	add	w26, w20, #0x8
 aec:	7100035f 	cmp	w26, #0x0
 af0:	5400008d 	b.le	b00 <vprintf+0x200>
 af4:	91003e76 	add	x22, x19, #0xf
 af8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 afc:	17ffffe0 	b	a7c <vprintf+0x17c>
 b00:	aa1303f6 	mov	x22, x19
 b04:	8b34c313 	add	x19, x24, w20, sxtw
 b08:	17ffffdd 	b	a7c <vprintf+0x17c>
      } else if(c == 's'){
 b0c:	7101cc1f 	cmp	w0, #0x73
 b10:	54000381 	b.ne	b80 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 b14:	37f80214 	tbnz	w20, #31, b54 <vprintf+0x254>
 b18:	91003e61 	add	x1, x19, #0xf
 b1c:	aa1303e0 	mov	x0, x19
 b20:	927df033 	and	x19, x1, #0xfffffffffffffff8
 b24:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 b28:	90000000 	adrp	x0, 0 <main>
 b2c:	91358000 	add	x0, x0, #0xd60
 b30:	f10002df 	cmp	x22, #0x0
 b34:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 b38:	394002c1 	ldrb	w1, [x22]
 b3c:	34fffce1 	cbz	w1, ad8 <vprintf+0x1d8>
          written += putc(fd, *s);
 b40:	2a1703e0 	mov	w0, w23
          s++;
 b44:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 b48:	97ffff38 	bl	828 <putc>
 b4c:	0b0002b5 	add	w21, w21, w0
          s++;
 b50:	17fffffa 	b	b38 <vprintf+0x238>
        s = va_arg(ap, char*);
 b54:	11002281 	add	w1, w20, #0x8
 b58:	7100003f 	cmp	w1, #0x0
 b5c:	540000cd 	b.le	b74 <vprintf+0x274>
 b60:	91003e62 	add	x2, x19, #0xf
 b64:	aa1303e0 	mov	x0, x19
 b68:	2a0103f4 	mov	w20, w1
 b6c:	927df053 	and	x19, x2, #0xfffffffffffffff8
 b70:	17ffffed 	b	b24 <vprintf+0x224>
 b74:	8b34c300 	add	x0, x24, w20, sxtw
 b78:	2a0103f4 	mov	w20, w1
 b7c:	17ffffea 	b	b24 <vprintf+0x224>
      } else if(c == 'c'){
 b80:	71018c1f 	cmp	w0, #0x63
 b84:	54000241 	b.ne	bcc <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 b88:	37f80114 	tbnz	w20, #31, ba8 <vprintf+0x2a8>
 b8c:	91002e76 	add	x22, x19, #0xb
 b90:	2a1403fa 	mov	w26, w20
 b94:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b98:	39400261 	ldrb	w1, [x19]
 b9c:	2a1703e0 	mov	w0, w23
 ba0:	97ffff22 	bl	828 <putc>
 ba4:	17ffff82 	b	9ac <vprintf+0xac>
 ba8:	1100229a 	add	w26, w20, #0x8
 bac:	7100035f 	cmp	w26, #0x0
 bb0:	5400008d 	b.le	bc0 <vprintf+0x2c0>
 bb4:	91002e76 	add	x22, x19, #0xb
 bb8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 bbc:	17fffff7 	b	b98 <vprintf+0x298>
 bc0:	aa1303f6 	mov	x22, x19
 bc4:	8b34c313 	add	x19, x24, w20, sxtw
 bc8:	17fffff4 	b	b98 <vprintf+0x298>
      } else if(c == '%'){
 bcc:	7100941f 	cmp	w0, #0x25
 bd0:	54ffece0 	b.eq	96c <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 bd4:	2a1703e0 	mov	w0, w23
 bd8:	528004a1 	mov	w1, #0x25                  	// #37
 bdc:	97ffff13 	bl	828 <putc>
 be0:	0b0002b5 	add	w21, w21, w0
 be4:	17ffff62 	b	96c <vprintf+0x6c>

0000000000000be8 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 be8:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 bec:	910003fd 	mov	x29, sp
 bf0:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 bf4:	910203e2 	add	x2, sp, #0x80
 bf8:	a9030be2 	stp	x2, x2, [sp, #48]
 bfc:	910143e2 	add	x2, sp, #0x50
 c00:	f90023e2 	str	x2, [sp, #64]
 c04:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 c08:	b9004be2 	str	w2, [sp, #72]
 c0c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 c10:	a9430fe2 	ldp	x2, x3, [sp, #48]
 c14:	a9010fe2 	stp	x2, x3, [sp, #16]
 c18:	a9440fe2 	ldp	x2, x3, [sp, #64]
 c1c:	a9020fe2 	stp	x2, x3, [sp, #32]
 c20:	910043e2 	add	x2, sp, #0x10
{
 c24:	a90617e4 	stp	x4, x5, [sp, #96]
 c28:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 c2c:	97ffff35 	bl	900 <vprintf>
  va_end(ap);
  return result;
}
 c30:	a8c87bfd 	ldp	x29, x30, [sp], #128
 c34:	d65f03c0 	ret

0000000000000c38 <printf>:

int
printf(const char *fmt, ...)
{
 c38:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 c3c:	910003fd 	mov	x29, sp
 c40:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 c44:	910243e1 	add	x1, sp, #0x90
 c48:	a90307e1 	stp	x1, x1, [sp, #48]
 c4c:	910143e1 	add	x1, sp, #0x50
 c50:	f90023e1 	str	x1, [sp, #64]
 c54:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 c58:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 c5c:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 c60:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 c64:	52800020 	mov	w0, #0x1                   	// #1
{
 c68:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 c6c:	a9430fe2 	ldp	x2, x3, [sp, #48]
 c70:	a9010fe2 	stp	x2, x3, [sp, #16]
 c74:	a9440fe2 	ldp	x2, x3, [sp, #64]
 c78:	a9020fe2 	stp	x2, x3, [sp, #32]
 c7c:	910043e2 	add	x2, sp, #0x10
{
 c80:	a9079be5 	stp	x5, x6, [sp, #120]
 c84:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 c88:	97ffff1e 	bl	900 <vprintf>
  va_end(ap);
  return result;
}
 c8c:	a8c97bfd 	ldp	x29, x30, [sp], #144
 c90:	d65f03c0 	ret
