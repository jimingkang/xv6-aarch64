
user/_threadtest:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  texit(0);
}

int
main(void)
{
   0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
  thread_t a, b;
  int loops = 1000;
   4:	52807d00 	mov	w0, #0x3e8                 	// #1000
  int sa = -1, sb = -1;

  counter_lock = sync_create(SYNC_MUTEX, 1);
   8:	52800021 	mov	w1, #0x1                   	// #1
{
   c:	910003fd 	mov	x29, sp
  10:	a90153f3 	stp	x19, x20, [sp, #16]
  counter_lock = sync_create(SYNC_MUTEX, 1);
  14:	90000014 	adrp	x20, 0 <main>
  int loops = 1000;
  18:	b90027e0 	str	w0, [sp, #36]
  int sa = -1, sb = -1;
  1c:	12800000 	mov	w0, #0xffffffff            	// #-1
  20:	290503e0 	stp	w0, w0, [sp, #40]
  counter_lock = sync_create(SYNC_MUTEX, 1);
  24:	2a0103e0 	mov	w0, w1
  28:	940000ac 	bl	2d8 <sync_create>
  2c:	b90dc280 	str	w0, [x20, #3520]
  if(counter_lock < 0){
  30:	36f800c0 	tbz	w0, #31, 48 <main+0x48>
    printf("threadtest: cannot create mutex\n");
  34:	90000000 	adrp	x0, 0 <main>
  38:	91340c00 	add	x0, x0, #0xd03
    exit(1);
  }
  if(thread_create(&a, worker, &loops) < 0 ||
     thread_create(&b, worker, &loops) < 0){
    printf("threadtest: create failed\n");
  3c:	9400023e 	bl	934 <printf>
    exit(1);
  40:	52800020 	mov	w0, #0x1                   	// #1
  44:	94000060 	bl	1c4 <exit>
  if(thread_create(&a, worker, &loops) < 0 ||
  48:	90000001 	adrp	x1, 0 <main>
  4c:	91044021 	add	x1, x1, #0x110
  50:	910093e2 	add	x2, sp, #0x24
  54:	9100c3e0 	add	x0, sp, #0x30
  58:	94000257 	bl	9b4 <thread_create>
  5c:	37f800e0 	tbnz	w0, #31, 78 <main+0x78>
     thread_create(&b, worker, &loops) < 0){
  60:	90000000 	adrp	x0, 0 <main>
  64:	91044001 	add	x1, x0, #0x110
  68:	910093e2 	add	x2, sp, #0x24
  6c:	910103e0 	add	x0, sp, #0x40
  70:	94000251 	bl	9b4 <thread_create>
  if(thread_create(&a, worker, &loops) < 0 ||
  74:	36f80080 	tbz	w0, #31, 84 <main+0x84>
    printf("threadtest: create failed\n");
  78:	90000000 	adrp	x0, 0 <main>
  7c:	91349000 	add	x0, x0, #0xd24
  80:	17ffffef 	b	3c <main+0x3c>
  }
  if(thread_join(&a, &sa) < 0 || thread_join(&b, &sb) < 0){
  84:	9100a3e1 	add	x1, sp, #0x28
  88:	9100c3e0 	add	x0, sp, #0x30
  8c:	94000279 	bl	a70 <thread_join>
  90:	37f800a0 	tbnz	w0, #31, a4 <main+0xa4>
  94:	9100b3e1 	add	x1, sp, #0x2c
  98:	910103e0 	add	x0, sp, #0x40
  9c:	94000275 	bl	a70 <thread_join>
  a0:	36f80080 	tbz	w0, #31, b0 <main+0xb0>
    printf("threadtest: join failed\n");
  a4:	90000000 	adrp	x0, 0 <main>
  a8:	9134fc00 	add	x0, x0, #0xd3f
  ac:	17ffffe4 	b	3c <main+0x3c>
    exit(1);
  }
  sync_destroy(counter_lock);
  b0:	b94dc280 	ldr	w0, [x20, #3520]
  b4:	91370293 	add	x19, x20, #0xdc0
  b8:	94000097 	bl	314 <sync_destroy>
  if(counter != 2 * loops || sa != 0 || sb != 0){
  bc:	29448be1 	ldp	w1, w2, [sp, #36]
  c0:	b9400660 	ldr	w0, [x19, #4]
  c4:	b9402fe3 	ldr	w3, [sp, #44]
  c8:	6b01041f 	cmp	w0, w1, lsl #1
  cc:	54000061 	b.ne	d8 <main+0xd8>  // b.any
  d0:	2a030040 	orr	w0, w2, w3
  d4:	340000c0 	cbz	w0, ec <main+0xec>
    printf("threadtest: FAIL counter=%d status=%d,%d\n", counter, sa, sb);
  d8:	b9400661 	ldr	w1, [x19, #4]
  dc:	90000000 	adrp	x0, 0 <main>
  e0:	91356000 	add	x0, x0, #0xd58
  e4:	94000214 	bl	934 <printf>
    exit(1);
  e8:	17ffffd6 	b	40 <main+0x40>
  }
  printf("threadtest: PASS counter=%d tgid=%d\n", counter, getpid());
  ec:	b9400673 	ldr	w19, [x19, #4]
  f0:	94000065 	bl	284 <getpid>
  f4:	2a0003e2 	mov	w2, w0
  f8:	90000000 	adrp	x0, 0 <main>
  fc:	91360800 	add	x0, x0, #0xd82
 100:	2a1303e1 	mov	w1, w19
 104:	9400020c 	bl	934 <printf>
  exit(0);
 108:	52800000 	mov	w0, #0x0                   	// #0
 10c:	17ffffce 	b	44 <main+0x44>

0000000000000110 <worker>:
{
 110:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 114:	910003fd 	mov	x29, sp
 118:	a90153f3 	stp	x19, x20, [sp, #16]
 11c:	f90013f5 	str	x21, [sp, #32]
  int loops = *(int *)arg;
 120:	b9400015 	ldr	w21, [x0]
  printf("threadtest: tid=%d tgid=%d cpu=%d started\n",
 124:	940000f1 	bl	4e8 <gettid>
 128:	2a0003f3 	mov	w19, w0
 12c:	94000056 	bl	284 <getpid>
 130:	2a0003f4 	mov	w20, w0
 134:	940000e1 	bl	4b8 <getcpu>
 138:	2a1303e1 	mov	w1, w19
    if(sync_wait(counter_lock) < 0)
 13c:	90000013 	adrp	x19, 0 <main>
 140:	91370273 	add	x19, x19, #0xdc0
  printf("threadtest: tid=%d tgid=%d cpu=%d started\n",
 144:	2a1403e2 	mov	w2, w20
  for(int i = 0; i < loops; i++){
 148:	52800014 	mov	w20, #0x0                   	// #0
  printf("threadtest: tid=%d tgid=%d cpu=%d started\n",
 14c:	2a0003e3 	mov	w3, w0
 150:	90000000 	adrp	x0, 0 <main>
 154:	91336000 	add	x0, x0, #0xcd8
 158:	940001f7 	bl	934 <printf>
  for(int i = 0; i < loops; i++){
 15c:	6b15029f 	cmp	w20, w21
 160:	5400006b 	b.lt	16c <worker+0x5c>  // b.tstop
  texit(0);
 164:	52800000 	mov	w0, #0x0                   	// #0
 168:	14000005 	b	17c <worker+0x6c>
    if(sync_wait(counter_lock) < 0)
 16c:	b9400260 	ldr	w0, [x19]
 170:	9400005d 	bl	2e4 <sync_wait>
 174:	36f80060 	tbz	w0, #31, 180 <worker+0x70>
      texit(2);
 178:	52800040 	mov	w0, #0x2                   	// #2
      texit(3);
 17c:	940000d5 	bl	4d0 <texit>
    counter++;
 180:	b9400660 	ldr	w0, [x19, #4]
    if(sync_signal(counter_lock, 1) < 0)
 184:	52800021 	mov	w1, #0x1                   	// #1
    counter++;
 188:	11000400 	add	w0, w0, #0x1
 18c:	b9000660 	str	w0, [x19, #4]
    if(sync_signal(counter_lock, 1) < 0)
 190:	b9400260 	ldr	w0, [x19]
 194:	94000057 	bl	2f0 <sync_signal>
 198:	36f80060 	tbz	w0, #31, 1a4 <worker+0x94>
      texit(3);
 19c:	52800060 	mov	w0, #0x3                   	// #3
 1a0:	17fffff7 	b	17c <worker+0x6c>
    if((i & 127) == 0)
 1a4:	f2401a9f 	tst	x20, #0x7f
 1a8:	54000041 	b.ne	1b0 <worker+0xa0>  // b.any
      sched_yield();
 1ac:	940000bd 	bl	4a0 <sched_yield>
  for(int i = 0; i < loops; i++){
 1b0:	11000694 	add	w20, w20, #0x1
 1b4:	17ffffea 	b	15c <worker+0x4c>

00000000000001b8 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 1b8:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 1bc:	d4000001 	svc	#0x0
 ret
 1c0:	d65f03c0 	ret

00000000000001c4 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 1c4:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 1c8:	d4000001 	svc	#0x0
 ret
 1cc:	d65f03c0 	ret

00000000000001d0 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 1d0:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 1d4:	d4000001 	svc	#0x0
 ret
 1d8:	d65f03c0 	ret

00000000000001dc <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 1dc:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 1e0:	d4000001 	svc	#0x0
 ret
 1e4:	d65f03c0 	ret

00000000000001e8 <read>:
.global read
read:
 mov x7, #SYS_read
 1e8:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 1ec:	d4000001 	svc	#0x0
 ret
 1f0:	d65f03c0 	ret

00000000000001f4 <write>:
.global write
write:
 mov x7, #SYS_write
 1f4:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 1f8:	d4000001 	svc	#0x0
 ret
 1fc:	d65f03c0 	ret

0000000000000200 <close>:
.global close
close:
 mov x7, #SYS_close
 200:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 204:	d4000001 	svc	#0x0
 ret
 208:	d65f03c0 	ret

000000000000020c <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 20c:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 210:	d4000001 	svc	#0x0
 ret
 214:	d65f03c0 	ret

0000000000000218 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 218:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 21c:	d4000001 	svc	#0x0
 ret
 220:	d65f03c0 	ret

0000000000000224 <open>:
.global open
open:
 mov x7, #SYS_open
 224:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 228:	d4000001 	svc	#0x0
 ret
 22c:	d65f03c0 	ret

0000000000000230 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 230:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 234:	d4000001 	svc	#0x0
 ret
 238:	d65f03c0 	ret

000000000000023c <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 23c:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 240:	d4000001 	svc	#0x0
 ret
 244:	d65f03c0 	ret

0000000000000248 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 248:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 24c:	d4000001 	svc	#0x0
 ret
 250:	d65f03c0 	ret

0000000000000254 <link>:
.global link
link:
 mov x7, #SYS_link
 254:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 258:	d4000001 	svc	#0x0
 ret
 25c:	d65f03c0 	ret

0000000000000260 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 260:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 264:	d4000001 	svc	#0x0
 ret
 268:	d65f03c0 	ret

000000000000026c <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 26c:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 270:	d4000001 	svc	#0x0
 ret
 274:	d65f03c0 	ret

0000000000000278 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 278:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 27c:	d4000001 	svc	#0x0
 ret
 280:	d65f03c0 	ret

0000000000000284 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 284:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 288:	d4000001 	svc	#0x0
 ret
 28c:	d65f03c0 	ret

0000000000000290 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 290:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 294:	d4000001 	svc	#0x0
 ret
 298:	d65f03c0 	ret

000000000000029c <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 29c:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 2a0:	d4000001 	svc	#0x0
 ret
 2a4:	d65f03c0 	ret

00000000000002a8 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 2a8:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 2ac:	d4000001 	svc	#0x0
 ret
 2b0:	d65f03c0 	ret

00000000000002b4 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 2b4:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 2b8:	d4000001 	svc	#0x0
 ret
 2bc:	d65f03c0 	ret

00000000000002c0 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 2c0:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 2c4:	d4000001 	svc	#0x0
 ret
 2c8:	d65f03c0 	ret

00000000000002cc <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 2cc:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 2d0:	d4000001 	svc	#0x0
 ret
 2d4:	d65f03c0 	ret

00000000000002d8 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 2d8:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 2dc:	d4000001 	svc	#0x0
 ret
 2e0:	d65f03c0 	ret

00000000000002e4 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 2e4:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 2e8:	d4000001 	svc	#0x0
 ret
 2ec:	d65f03c0 	ret

00000000000002f0 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 2f0:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 2f4:	d4000001 	svc	#0x0
 ret
 2f8:	d65f03c0 	ret

00000000000002fc <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 2fc:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 300:	d4000001 	svc	#0x0
 ret
 304:	d65f03c0 	ret

0000000000000308 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 308:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 30c:	d4000001 	svc	#0x0
 ret
 310:	d65f03c0 	ret

0000000000000314 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 314:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 318:	d4000001 	svc	#0x0
 ret
 31c:	d65f03c0 	ret

0000000000000320 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 320:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 324:	d4000001 	svc	#0x0
 ret
 328:	d65f03c0 	ret

000000000000032c <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 32c:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 330:	d4000001 	svc	#0x0
 ret
 334:	d65f03c0 	ret

0000000000000338 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 338:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 33c:	d4000001 	svc	#0x0
 ret
 340:	d65f03c0 	ret

0000000000000344 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 344:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 348:	d4000001 	svc	#0x0
 ret
 34c:	d65f03c0 	ret

0000000000000350 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 350:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 354:	d4000001 	svc	#0x0
 ret
 358:	d65f03c0 	ret

000000000000035c <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 35c:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 360:	d4000001 	svc	#0x0
 ret
 364:	d65f03c0 	ret

0000000000000368 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 368:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 36c:	d4000001 	svc	#0x0
 ret
 370:	d65f03c0 	ret

0000000000000374 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 374:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 378:	d4000001 	svc	#0x0
 ret
 37c:	d65f03c0 	ret

0000000000000380 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 380:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 384:	d4000001 	svc	#0x0
 ret
 388:	d65f03c0 	ret

000000000000038c <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 38c:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 390:	d4000001 	svc	#0x0
 ret
 394:	d65f03c0 	ret

0000000000000398 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 398:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 39c:	d4000001 	svc	#0x0
 ret
 3a0:	d65f03c0 	ret

00000000000003a4 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 3a4:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 3a8:	d4000001 	svc	#0x0
 ret
 3ac:	d65f03c0 	ret

00000000000003b0 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 3b0:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 3b4:	d4000001 	svc	#0x0
 ret
 3b8:	d65f03c0 	ret

00000000000003bc <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 3bc:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 3c0:	d4000001 	svc	#0x0
 ret
 3c4:	d65f03c0 	ret

00000000000003c8 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 3c8:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 3cc:	d4000001 	svc	#0x0
 ret
 3d0:	d65f03c0 	ret

00000000000003d4 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 3d4:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 3d8:	d4000001 	svc	#0x0
 ret
 3dc:	d65f03c0 	ret

00000000000003e0 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 3e0:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 3e4:	d4000001 	svc	#0x0
 ret
 3e8:	d65f03c0 	ret

00000000000003ec <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 3ec:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 3f0:	d4000001 	svc	#0x0
 ret
 3f4:	d65f03c0 	ret

00000000000003f8 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 3f8:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 3fc:	d4000001 	svc	#0x0
 ret
 400:	d65f03c0 	ret

0000000000000404 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 404:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 408:	d4000001 	svc	#0x0
 ret
 40c:	d65f03c0 	ret

0000000000000410 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 410:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 414:	d4000001 	svc	#0x0
 ret
 418:	d65f03c0 	ret

000000000000041c <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 41c:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 420:	d4000001 	svc	#0x0
 ret
 424:	d65f03c0 	ret

0000000000000428 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 428:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 42c:	d4000001 	svc	#0x0
 ret
 430:	d65f03c0 	ret

0000000000000434 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 434:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 438:	d4000001 	svc	#0x0
 ret
 43c:	d65f03c0 	ret

0000000000000440 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 440:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 444:	d4000001 	svc	#0x0
 ret
 448:	d65f03c0 	ret

000000000000044c <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 44c:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 450:	d4000001 	svc	#0x0
 ret
 454:	d65f03c0 	ret

0000000000000458 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 458:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 45c:	d4000001 	svc	#0x0
 ret
 460:	d65f03c0 	ret

0000000000000464 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 464:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 468:	d4000001 	svc	#0x0
 ret
 46c:	d65f03c0 	ret

0000000000000470 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 470:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 474:	d4000001 	svc	#0x0
 ret
 478:	d65f03c0 	ret

000000000000047c <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 47c:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 480:	d4000001 	svc	#0x0
 ret
 484:	d65f03c0 	ret

0000000000000488 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 488:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 48c:	d4000001 	svc	#0x0
 ret
 490:	d65f03c0 	ret

0000000000000494 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 494:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 498:	d4000001 	svc	#0x0
 ret
 49c:	d65f03c0 	ret

00000000000004a0 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 4a0:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 4a4:	d4000001 	svc	#0x0
 ret
 4a8:	d65f03c0 	ret

00000000000004ac <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 4ac:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 4b0:	d4000001 	svc	#0x0
 ret
 4b4:	d65f03c0 	ret

00000000000004b8 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 4b8:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 4bc:	d4000001 	svc	#0x0
 ret
 4c0:	d65f03c0 	ret

00000000000004c4 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 4c4:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 4c8:	d4000001 	svc	#0x0
 ret
 4cc:	d65f03c0 	ret

00000000000004d0 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 4d0:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 4d4:	d4000001 	svc	#0x0
 ret
 4d8:	d65f03c0 	ret

00000000000004dc <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 4dc:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 4e0:	d4000001 	svc	#0x0
 ret
 4e4:	d65f03c0 	ret

00000000000004e8 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 4e8:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 4ec:	d4000001 	svc	#0x0
 ret
 4f0:	d65f03c0 	ret

00000000000004f4 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 4f4:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 4f8:	d4000001 	svc	#0x0
 ret
 4fc:	d65f03c0 	ret

0000000000000500 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 500:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 504:	d4000001 	svc	#0x0
 ret
 508:	d65f03c0 	ret

000000000000050c <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 50c:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 510:	d4000001 	svc	#0x0
 ret
 514:	d65f03c0 	ret

0000000000000518 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 518:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 51c:	d4000001 	svc	#0x0
 ret
 520:	d65f03c0 	ret

0000000000000524 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 524:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 528:	52800022 	mov	w2, #0x1                   	// #1
{
 52c:	910003fd 	mov	x29, sp
 530:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 534:	91007fe1 	add	x1, sp, #0x1f
 538:	97ffff2f 	bl	1f4 <write>
 53c:	7100041f 	cmp	w0, #0x1
}
 540:	1a9f17e0 	cset	w0, eq	// eq = none
 544:	a8c27bfd 	ldp	x29, x30, [sp], #32
 548:	d65f03c0 	ret

000000000000054c <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 54c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 550:	910003fd 	mov	x29, sp
 554:	a90153f3 	stp	x19, x20, [sp, #16]
 558:	a9025bf5 	stp	x21, x22, [sp, #32]
 55c:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 560:	6a417c7f 	tst	w3, w1, lsr #31
 564:	54000300 	b.eq	5c4 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 568:	4b0103e1 	neg	w1, w1
    neg = 1;
 56c:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 570:	90000003 	adrp	x3, 0 <main>
 574:	9136b863 	add	x3, x3, #0xdae
 578:	9100c3f5 	add	x21, sp, #0x30
 57c:	d2800000 	mov	x0, #0x0                   	// #0
 580:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 584:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 588:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 58c:	2a0403e1 	mov	w1, w4
 590:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 594:	38666866 	ldrb	w6, [x3, x6]
 598:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 59c:	91000400 	add	x0, x0, #0x1
 5a0:	54ffff09 	b.ls	580 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 5a4:	11000493 	add	w19, w4, #0x1
  if(neg)
 5a8:	34000085 	cbz	w5, 5b8 <printint+0x6c>
    buf[i++] = '-';
 5ac:	528005a0 	mov	w0, #0x2d                  	// #45
 5b0:	38334aa0 	strb	w0, [x21, w19, uxtw]
 5b4:	11000893 	add	w19, w4, #0x2
 5b8:	51000673 	sub	w19, w19, #0x1
 5bc:	52800014 	mov	w20, #0x0                   	// #0
 5c0:	14000008 	b	5e0 <printint+0x94>
  neg = 0;
 5c4:	52800005 	mov	w5, #0x0                   	// #0
 5c8:	17ffffea 	b	570 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 5cc:	38736aa1 	ldrb	w1, [x21, x19]
 5d0:	2a1603e0 	mov	w0, w22
 5d4:	d1000673 	sub	x19, x19, #0x1
 5d8:	97ffffd3 	bl	524 <putc>
 5dc:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 5e0:	3100067f 	cmn	w19, #0x1
 5e4:	54ffff41 	b.ne	5cc <printint+0x80>  // b.any
  return written;
}
 5e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
 5ec:	2a1403e0 	mov	w0, w20
 5f0:	a94153f3 	ldp	x19, x20, [sp, #16]
 5f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
 5f8:	d65f03c0 	ret

00000000000005fc <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 5fc:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 600:	910003fd 	mov	x29, sp
 604:	a90153f3 	stp	x19, x20, [sp, #16]
 608:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 60c:	52800015 	mov	w21, #0x0                   	// #0
{
 610:	a90363f7 	stp	x23, x24, [sp, #48]
 614:	2a0003f7 	mov	w23, w0
 618:	a9046bf9 	stp	x25, x26, [sp, #64]
 61c:	aa0103f9 	mov	x25, x1

  state = 0;
 620:	52800001 	mov	w1, #0x0                   	// #0
{
 624:	a90573fb 	stp	x27, x28, [sp, #80]
 628:	a9406053 	ldp	x19, x24, [x2]
 62c:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 630:	39400320 	ldrb	w0, [x25]
 634:	35000120 	cbnz	w0, 658 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 638:	2a1503e0 	mov	w0, w21
 63c:	a94153f3 	ldp	x19, x20, [sp, #16]
 640:	a9425bf5 	ldp	x21, x22, [sp, #32]
 644:	a94363f7 	ldp	x23, x24, [sp, #48]
 648:	a9446bf9 	ldp	x25, x26, [sp, #64]
 64c:	a94573fb 	ldp	x27, x28, [sp, #80]
 650:	a8c67bfd 	ldp	x29, x30, [sp], #96
 654:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 658:	2a0003f6 	mov	w22, w0
    if(state == 0){
 65c:	35000101 	cbnz	w1, 67c <vprintf+0x80>
      if(c == '%'){
 660:	7100941f 	cmp	w0, #0x25
 664:	54000ba0 	b.eq	7d8 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 668:	2a1603e1 	mov	w1, w22
 66c:	2a1703e0 	mov	w0, w23
 670:	97ffffad 	bl	524 <putc>
 674:	0b0002b5 	add	w21, w21, w0
 678:	14000057 	b	7d4 <vprintf+0x1d8>
      if(c == 'd'){
 67c:	7101901f 	cmp	w0, #0x64
 680:	540002a1 	b.ne	6d4 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 684:	37f80174 	tbnz	w20, #31, 6b0 <vprintf+0xb4>
 688:	91002e76 	add	x22, x19, #0xb
 68c:	2a1403fa 	mov	w26, w20
 690:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 694:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 698:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 69c:	b9400261 	ldr	w1, [x19]
 6a0:	2a1703e0 	mov	w0, w23
 6a4:	97ffffaa 	bl	54c <printint>
        written += putc(fd, va_arg(ap, uint));
 6a8:	0b0002b5 	add	w21, w21, w0
 6ac:	14000048 	b	7cc <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 6b0:	1100229a 	add	w26, w20, #0x8
 6b4:	7100035f 	cmp	w26, #0x0
 6b8:	5400008d 	b.le	6c8 <vprintf+0xcc>
 6bc:	91002e76 	add	x22, x19, #0xb
 6c0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6c4:	17fffff4 	b	694 <vprintf+0x98>
 6c8:	aa1303f6 	mov	x22, x19
 6cc:	8b34c313 	add	x19, x24, w20, sxtw
 6d0:	17fffff1 	b	694 <vprintf+0x98>
      } else if(c == 'l') {
 6d4:	7101b01f 	cmp	w0, #0x6c
 6d8:	54000201 	b.ne	718 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 6dc:	37f800d4 	tbnz	w20, #31, 6f4 <vprintf+0xf8>
 6e0:	91003e76 	add	x22, x19, #0xf
 6e4:	2a1403fa 	mov	w26, w20
 6e8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6ec:	52800003 	mov	w3, #0x0                   	// #0
 6f0:	17ffffea 	b	698 <vprintf+0x9c>
 6f4:	1100229a 	add	w26, w20, #0x8
 6f8:	7100035f 	cmp	w26, #0x0
 6fc:	5400008d 	b.le	70c <vprintf+0x110>
 700:	91003e76 	add	x22, x19, #0xf
 704:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 708:	17fffff9 	b	6ec <vprintf+0xf0>
 70c:	aa1303f6 	mov	x22, x19
 710:	8b34c313 	add	x19, x24, w20, sxtw
 714:	17fffff6 	b	6ec <vprintf+0xf0>
      } else if(c == 'x') {
 718:	7101e01f 	cmp	w0, #0x78
 71c:	54000221 	b.ne	760 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 720:	37f800f4 	tbnz	w20, #31, 73c <vprintf+0x140>
 724:	91002e76 	add	x22, x19, #0xb
 728:	2a1403fa 	mov	w26, w20
 72c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 730:	52800003 	mov	w3, #0x0                   	// #0
 734:	52800202 	mov	w2, #0x10                  	// #16
 738:	17ffffd9 	b	69c <vprintf+0xa0>
 73c:	1100229a 	add	w26, w20, #0x8
 740:	7100035f 	cmp	w26, #0x0
 744:	5400008d 	b.le	754 <vprintf+0x158>
 748:	91002e76 	add	x22, x19, #0xb
 74c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 750:	17fffff8 	b	730 <vprintf+0x134>
 754:	aa1303f6 	mov	x22, x19
 758:	8b34c313 	add	x19, x24, w20, sxtw
 75c:	17fffff5 	b	730 <vprintf+0x134>
      } else if(c == 'p') {
 760:	7101c01f 	cmp	w0, #0x70
 764:	54000521 	b.ne	808 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 768:	37f803f4 	tbnz	w20, #31, 7e4 <vprintf+0x1e8>
 76c:	91003e76 	add	x22, x19, #0xf
 770:	2a1403fa 	mov	w26, w20
 774:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 778:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 77c:	52800601 	mov	w1, #0x30                  	// #48
 780:	2a1703e0 	mov	w0, w23
 784:	97ffff68 	bl	524 <putc>
 788:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 78c:	9000001c 	adrp	x28, 0 <main>
 790:	9136bb9c 	add	x28, x28, #0xdae
  written += putc(fd, 'x');
 794:	2a1703e0 	mov	w0, w23
 798:	52800f01 	mov	w1, #0x78                  	// #120
 79c:	97ffff62 	bl	524 <putc>
 7a0:	0b000273 	add	w19, w19, w0
 7a4:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7a8:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7ac:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7b0:	38606b81 	ldrb	w1, [x28, x0]
 7b4:	2a1703e0 	mov	w0, w23
 7b8:	97ffff5b 	bl	524 <putc>
 7bc:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7c0:	71000694 	subs	w20, w20, #0x1
 7c4:	54ffff21 	b.ne	7a8 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 7c8:	0b1302b5 	add	w21, w21, w19
 7cc:	2a1a03f4 	mov	w20, w26
 7d0:	aa1603f3 	mov	x19, x22
      state = 0;
 7d4:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 7d8:	91000739 	add	x25, x25, #0x1
  state = 0;
 7dc:	2a1603e1 	mov	w1, w22
 7e0:	17ffff94 	b	630 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 7e4:	1100229a 	add	w26, w20, #0x8
 7e8:	7100035f 	cmp	w26, #0x0
 7ec:	5400008d 	b.le	7fc <vprintf+0x200>
 7f0:	91003e76 	add	x22, x19, #0xf
 7f4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 7f8:	17ffffe0 	b	778 <vprintf+0x17c>
 7fc:	aa1303f6 	mov	x22, x19
 800:	8b34c313 	add	x19, x24, w20, sxtw
 804:	17ffffdd 	b	778 <vprintf+0x17c>
      } else if(c == 's'){
 808:	7101cc1f 	cmp	w0, #0x73
 80c:	54000381 	b.ne	87c <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 810:	37f80214 	tbnz	w20, #31, 850 <vprintf+0x254>
 814:	91003e61 	add	x1, x19, #0xf
 818:	aa1303e0 	mov	x0, x19
 81c:	927df033 	and	x19, x1, #0xfffffffffffffff8
 820:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 824:	90000000 	adrp	x0, 0 <main>
 828:	91369c00 	add	x0, x0, #0xda7
 82c:	f10002df 	cmp	x22, #0x0
 830:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 834:	394002c1 	ldrb	w1, [x22]
 838:	34fffce1 	cbz	w1, 7d4 <vprintf+0x1d8>
          written += putc(fd, *s);
 83c:	2a1703e0 	mov	w0, w23
          s++;
 840:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 844:	97ffff38 	bl	524 <putc>
 848:	0b0002b5 	add	w21, w21, w0
          s++;
 84c:	17fffffa 	b	834 <vprintf+0x238>
        s = va_arg(ap, char*);
 850:	11002281 	add	w1, w20, #0x8
 854:	7100003f 	cmp	w1, #0x0
 858:	540000cd 	b.le	870 <vprintf+0x274>
 85c:	91003e62 	add	x2, x19, #0xf
 860:	aa1303e0 	mov	x0, x19
 864:	2a0103f4 	mov	w20, w1
 868:	927df053 	and	x19, x2, #0xfffffffffffffff8
 86c:	17ffffed 	b	820 <vprintf+0x224>
 870:	8b34c300 	add	x0, x24, w20, sxtw
 874:	2a0103f4 	mov	w20, w1
 878:	17ffffea 	b	820 <vprintf+0x224>
      } else if(c == 'c'){
 87c:	71018c1f 	cmp	w0, #0x63
 880:	54000241 	b.ne	8c8 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 884:	37f80114 	tbnz	w20, #31, 8a4 <vprintf+0x2a8>
 888:	91002e76 	add	x22, x19, #0xb
 88c:	2a1403fa 	mov	w26, w20
 890:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 894:	39400261 	ldrb	w1, [x19]
 898:	2a1703e0 	mov	w0, w23
 89c:	97ffff22 	bl	524 <putc>
 8a0:	17ffff82 	b	6a8 <vprintf+0xac>
 8a4:	1100229a 	add	w26, w20, #0x8
 8a8:	7100035f 	cmp	w26, #0x0
 8ac:	5400008d 	b.le	8bc <vprintf+0x2c0>
 8b0:	91002e76 	add	x22, x19, #0xb
 8b4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8b8:	17fffff7 	b	894 <vprintf+0x298>
 8bc:	aa1303f6 	mov	x22, x19
 8c0:	8b34c313 	add	x19, x24, w20, sxtw
 8c4:	17fffff4 	b	894 <vprintf+0x298>
      } else if(c == '%'){
 8c8:	7100941f 	cmp	w0, #0x25
 8cc:	54ffece0 	b.eq	668 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 8d0:	2a1703e0 	mov	w0, w23
 8d4:	528004a1 	mov	w1, #0x25                  	// #37
 8d8:	97ffff13 	bl	524 <putc>
 8dc:	0b0002b5 	add	w21, w21, w0
 8e0:	17ffff62 	b	668 <vprintf+0x6c>

00000000000008e4 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 8e4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 8e8:	910003fd 	mov	x29, sp
 8ec:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 8f0:	910203e2 	add	x2, sp, #0x80
 8f4:	a9030be2 	stp	x2, x2, [sp, #48]
 8f8:	910143e2 	add	x2, sp, #0x50
 8fc:	f90023e2 	str	x2, [sp, #64]
 900:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 904:	b9004be2 	str	w2, [sp, #72]
 908:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 90c:	a9430fe2 	ldp	x2, x3, [sp, #48]
 910:	a9010fe2 	stp	x2, x3, [sp, #16]
 914:	a9440fe2 	ldp	x2, x3, [sp, #64]
 918:	a9020fe2 	stp	x2, x3, [sp, #32]
 91c:	910043e2 	add	x2, sp, #0x10
{
 920:	a90617e4 	stp	x4, x5, [sp, #96]
 924:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 928:	97ffff35 	bl	5fc <vprintf>
  va_end(ap);
  return result;
}
 92c:	a8c87bfd 	ldp	x29, x30, [sp], #128
 930:	d65f03c0 	ret

0000000000000934 <printf>:

int
printf(const char *fmt, ...)
{
 934:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 938:	910003fd 	mov	x29, sp
 93c:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 940:	910243e1 	add	x1, sp, #0x90
 944:	a90307e1 	stp	x1, x1, [sp, #48]
 948:	910143e1 	add	x1, sp, #0x50
 94c:	f90023e1 	str	x1, [sp, #64]
 950:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 954:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 958:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 95c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 960:	52800020 	mov	w0, #0x1                   	// #1
{
 964:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 968:	a9430fe2 	ldp	x2, x3, [sp, #48]
 96c:	a9010fe2 	stp	x2, x3, [sp, #16]
 970:	a9440fe2 	ldp	x2, x3, [sp, #64]
 974:	a9020fe2 	stp	x2, x3, [sp, #32]
 978:	910043e2 	add	x2, sp, #0x10
{
 97c:	a9079be5 	stp	x5, x6, [sp, #120]
 980:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 984:	97ffff1e 	bl	5fc <vprintf>
  va_end(ap);
  return result;
}
 988:	a8c97bfd 	ldp	x29, x30, [sp], #144
 98c:	d65f03c0 	ret

0000000000000990 <thread_boot>:
  void *arg;
};

static void
thread_boot(void *opaque)
{
 990:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 994:	910003fd 	mov	x29, sp
 998:	a90153f3 	stp	x19, x20, [sp, #16]
  struct thread_start start = *(struct thread_start *)opaque;
 99c:	a9405013 	ldp	x19, x20, [x0]

  // The creator no longer needs this small launch record.  The separately
  // allocated stack remains owned by thread_t until thread_join().
  free(opaque);
 9a0:	9400007f 	bl	b9c <free>
  start.fn(start.arg);
 9a4:	aa1403e0 	mov	x0, x20
 9a8:	d63f0260 	blr	x19
  texit(0);
 9ac:	52800000 	mov	w0, #0x0                   	// #0
 9b0:	97fffec8 	bl	4d0 <texit>

00000000000009b4 <thread_create>:
thread_create(thread_t *thread, void (*fn)(void *), void *arg)
{
  struct thread_start *start;
  uint64 top;

  if(thread == 0 || fn == 0)
 9b4:	f100001f 	cmp	x0, #0x0
 9b8:	fa401824 	ccmp	x1, #0x0, #0x4, ne	// ne = any
 9bc:	54000560 	b.eq	a68 <thread_create+0xb4>  // b.none
{
 9c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 9c4:	910003fd 	mov	x29, sp
 9c8:	a90153f3 	stp	x19, x20, [sp, #16]
 9cc:	aa0003f3 	mov	x19, x0
    return -1;
  thread->tid = -1;
 9d0:	12800000 	mov	w0, #0xffffffff            	// #-1
{
 9d4:	a9025bf5 	stp	x21, x22, [sp, #32]
 9d8:	aa0103f5 	mov	x21, x1
 9dc:	aa0203f6 	mov	x22, x2
  thread->tid = -1;
 9e0:	b9000260 	str	w0, [x19]
  thread->stack = malloc(THREAD_STACK_SIZE + 16);
 9e4:	52880200 	mov	w0, #0x4010                	// #16400
 9e8:	9400007c 	bl	bd8 <malloc>
 9ec:	f9000660 	str	x0, [x19, #8]
  if(thread->stack == 0)
 9f0:	b50000c0 	cbnz	x0, a08 <thread_create+0x54>
    return -1;
 9f4:	12800000 	mov	w0, #0xffffffff            	// #-1
    free(thread->stack);
    thread->stack = 0;
    return -1;
  }
  return 0;
}
 9f8:	a94153f3 	ldp	x19, x20, [sp, #16]
 9fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
 a00:	a8c37bfd 	ldp	x29, x30, [sp], #48
 a04:	d65f03c0 	ret
  start = malloc(sizeof(*start));
 a08:	52800200 	mov	w0, #0x10                  	// #16
 a0c:	94000073 	bl	bd8 <malloc>
 a10:	aa0003f4 	mov	x20, x0
  top = ((uint64)thread->stack + THREAD_STACK_SIZE + 16) & ~15ULL;
 a14:	f9400660 	ldr	x0, [x19, #8]
  if(start == 0){
 a18:	b5000094 	cbnz	x20, a28 <thread_create+0x74>
    free(thread->stack);
 a1c:	94000060 	bl	b9c <free>
    thread->stack = 0;
 a20:	f900067f 	str	xzr, [x19, #8]
    return -1;
 a24:	17fffff4 	b	9f4 <thread_create+0x40>
  top = ((uint64)thread->stack + THREAD_STACK_SIZE + 16) & ~15ULL;
 a28:	d2880201 	mov	x1, #0x4010                	// #16400
  start->fn = fn;
 a2c:	a9005a95 	stp	x21, x22, [x20]
  top = ((uint64)thread->stack + THREAD_STACK_SIZE + 16) & ~15ULL;
 a30:	8b010002 	add	x2, x0, x1
  thread->tid = clone(thread_boot, start, (void *)top);
 a34:	aa1403e1 	mov	x1, x20
 a38:	927cec42 	and	x2, x2, #0xfffffffffffffff0
 a3c:	90000000 	adrp	x0, 0 <main>
 a40:	91264000 	add	x0, x0, #0x990
 a44:	97fffea0 	bl	4c4 <clone>
 a48:	2a0003e1 	mov	w1, w0
 a4c:	b9000261 	str	w1, [x19]
  return 0;
 a50:	52800000 	mov	w0, #0x0                   	// #0
  if(thread->tid < 0){
 a54:	36fffd21 	tbz	w1, #31, 9f8 <thread_create+0x44>
    free(start);
 a58:	aa1403e0 	mov	x0, x20
 a5c:	94000050 	bl	b9c <free>
    free(thread->stack);
 a60:	f9400660 	ldr	x0, [x19, #8]
 a64:	17ffffee 	b	a1c <thread_create+0x68>
    return -1;
 a68:	12800000 	mov	w0, #0xffffffff            	// #-1
}
 a6c:	d65f03c0 	ret

0000000000000a70 <thread_join>:

int
thread_join(thread_t *thread, int *status)
{
 a70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 a74:	910003fd 	mov	x29, sp
 a78:	a90153f3 	stp	x19, x20, [sp, #16]
  int tid;

  if(thread == 0 || thread->tid < 0)
 a7c:	b50000c0 	cbnz	x0, a94 <thread_join+0x24>
    return -1;
 a80:	12800014 	mov	w20, #0xffffffff            	// #-1
    return -1;
  free(thread->stack);
  thread->stack = 0;
  thread->tid = -1;
  return tid;
}
 a84:	2a1403e0 	mov	w0, w20
 a88:	a94153f3 	ldp	x19, x20, [sp, #16]
 a8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 a90:	d65f03c0 	ret
 a94:	aa0003f3 	mov	x19, x0
  if(thread == 0 || thread->tid < 0)
 a98:	b9400000 	ldr	w0, [x0]
 a9c:	37ffff20 	tbnz	w0, #31, a80 <thread_join+0x10>
  tid = tjoin(thread->tid, status);
 aa0:	97fffe8f 	bl	4dc <tjoin>
 aa4:	2a0003f4 	mov	w20, w0
  if(tid < 0)
 aa8:	37fffec0 	tbnz	w0, #31, a80 <thread_join+0x10>
  free(thread->stack);
 aac:	f9400660 	ldr	x0, [x19, #8]
 ab0:	9400003b 	bl	b9c <free>
  thread->stack = 0;
 ab4:	f900067f 	str	xzr, [x19, #8]
  thread->tid = -1;
 ab8:	12800000 	mov	w0, #0xffffffff            	// #-1
 abc:	b9000260 	str	w0, [x19]
  return tid;
 ac0:	17fffff1 	b	a84 <thread_join+0x14>

0000000000000ac4 <free_locked>:
free_locked(void *ap)
{
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 ac4:	90000005 	adrp	x5, 0 <main>
 ac8:	f946e4a2 	ldr	x2, [x5, #3528]
  bp = (Header*)ap - 1;
 acc:	d1004003 	sub	x3, x0, #0x10
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ad0:	f9400041 	ldr	x1, [x2]
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 ad4:	eb03005f 	cmp	x2, x3
 ad8:	54000342 	b.cs	b40 <free_locked+0x7c>  // b.hs, b.nlast
 adc:	eb01007f 	cmp	x3, x1
 ae0:	540002a2 	b.cs	b34 <free_locked+0x70>  // b.hs, b.nlast
      break;
  if(bp + bp->s.size == p->s.ptr){
 ae4:	b85f8006 	ldur	w6, [x0, #-8]
 ae8:	8b265064 	add	x4, x3, w6, uxtw #4
 aec:	eb04003f 	cmp	x1, x4
 af0:	540000a1 	b.ne	b04 <free_locked+0x40>  // b.any
    bp->s.size += p->s.ptr->s.size;
 af4:	b9400824 	ldr	w4, [x1, #8]
    bp->s.ptr = p->s.ptr->s.ptr;
 af8:	f9400021 	ldr	x1, [x1]
    bp->s.size += p->s.ptr->s.size;
 afc:	0b060084 	add	w4, w4, w6
 b00:	b81f8004 	stur	w4, [x0, #-8]
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 b04:	b9400844 	ldr	w4, [x2, #8]
 b08:	f81f0001 	stur	x1, [x0, #-16]
 b0c:	8b245046 	add	x6, x2, w4, uxtw #4
 b10:	eb06007f 	cmp	x3, x6
 b14:	540000a1 	b.ne	b28 <free_locked+0x64>  // b.any
    p->s.size += bp->s.size;
 b18:	b85f8000 	ldur	w0, [x0, #-8]
    p->s.ptr = bp->s.ptr;
 b1c:	aa0103e3 	mov	x3, x1
    p->s.size += bp->s.size;
 b20:	0b040000 	add	w0, w0, w4
 b24:	b9000840 	str	w0, [x2, #8]
  } else
    p->s.ptr = bp;
  freep = p;
 b28:	f906e4a2 	str	x2, [x5, #3528]
 b2c:	f9000043 	str	x3, [x2]
}
 b30:	d65f03c0 	ret
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b34:	eb01005f 	cmp	x2, x1
 b38:	540000c3 	b.cc	b50 <free_locked+0x8c>  // b.lo, b.ul, b.last
 b3c:	17ffffea 	b	ae4 <free_locked+0x20>
 b40:	eb01005f 	cmp	x2, x1
 b44:	54000063 	b.cc	b50 <free_locked+0x8c>  // b.lo, b.ul, b.last
 b48:	eb01007f 	cmp	x3, x1
 b4c:	54fffcc3 	b.cc	ae4 <free_locked+0x20>  // b.lo, b.ul, b.last
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b50:	aa0103e2 	mov	x2, x1
 b54:	17ffffdf 	b	ad0 <free_locked+0xc>

0000000000000b58 <heap_acquire>:
{
 b58:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 b5c:	910003fd 	mov	x29, sp
 b60:	a90153f3 	stp	x19, x20, [sp, #16]
    asm volatile("ldaxr %w0, [%1]"
 b64:	90000013 	adrp	x19, 0 <main>
 b68:	91372273 	add	x19, x19, #0xdc8
 b6c:	91002273 	add	x19, x19, #0x8
      asm volatile("stxr %w0, %w1, [%2]"
 b70:	52800034 	mov	w20, #0x1                   	// #1
    asm volatile("ldaxr %w0, [%1]"
 b74:	885ffe60 	ldaxr	w0, [x19]
    if(old == 0){
 b78:	350000c0 	cbnz	w0, b90 <heap_acquire+0x38>
      asm volatile("stxr %w0, %w1, [%2]"
 b7c:	88007e74 	stxr	w0, w20, [x19]
      if(failed == 0)
 b80:	350000a0 	cbnz	w0, b94 <heap_acquire+0x3c>
}
 b84:	a94153f3 	ldp	x19, x20, [sp, #16]
 b88:	a8c27bfd 	ldp	x29, x30, [sp], #32
 b8c:	d65f03c0 	ret
      asm volatile("clrex" ::: "memory");
 b90:	d5033f5f 	clrex
    sched_yield();
 b94:	97fffe43 	bl	4a0 <sched_yield>
  for(;;){
 b98:	17fffff7 	b	b74 <heap_acquire+0x1c>

0000000000000b9c <free>:

void
free(void *ap)
{
  if(ap == 0)
 b9c:	b40001c0 	cbz	x0, bd4 <free+0x38>
{
 ba0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 ba4:	910003fd 	mov	x29, sp
 ba8:	f9000fe0 	str	x0, [sp, #24]
    return;
  heap_acquire();
 bac:	97ffffeb 	bl	b58 <heap_acquire>
  free_locked(ap);
 bb0:	f9400fe0 	ldr	x0, [sp, #24]
 bb4:	97ffffc4 	bl	ac4 <free_locked>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
 bb8:	90000000 	adrp	x0, 0 <main>
 bbc:	91372000 	add	x0, x0, #0xdc8
 bc0:	52800001 	mov	w1, #0x0                   	// #0
 bc4:	91002000 	add	x0, x0, #0x8
 bc8:	889ffc01 	stlr	w1, [x0]
  heap_release();
}
 bcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
 bd0:	d65f03c0 	ret
 bd4:	d65f03c0 	ret

0000000000000bd8 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 bd8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 bdc:	910003fd 	mov	x29, sp
 be0:	a90153f3 	stp	x19, x20, [sp, #16]
  Header *p, *prevp;
  uint nunits;

  heap_acquire();
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 be4:	2a0003f3 	mov	w19, w0
 be8:	91003e73 	add	x19, x19, #0xf
{
 bec:	a9025bf5 	stp	x21, x22, [sp, #32]
  if((prevp = freep) == 0){
 bf0:	90000016 	adrp	x22, 0 <main>
 bf4:	913722d4 	add	x20, x22, #0xdc8
{
 bf8:	f9001bf7 	str	x23, [sp, #48]
  heap_acquire();
 bfc:	97ffffd7 	bl	b58 <heap_acquire>
  if((prevp = freep) == 0){
 c00:	f946e6c1 	ldr	x1, [x22, #3528]
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 c04:	d344fe73 	lsr	x19, x19, #4
 c08:	11000673 	add	w19, w19, #0x1
  if((prevp = freep) == 0){
 c0c:	b50000a1 	cbnz	x1, c20 <malloc+0x48>
    base.s.ptr = freep = prevp = &base;
 c10:	91004281 	add	x1, x20, #0x10
 c14:	f906e6c1 	str	x1, [x22, #3528]
 c18:	f9000a81 	str	x1, [x20, #16]
    base.s.size = 0;
 c1c:	b9001a9f 	str	wzr, [x20, #24]
  if(nu < 4096)
 c20:	7140067f 	cmp	w19, #0x1, lsl #12
 c24:	52820015 	mov	w21, #0x1000                	// #4096
 c28:	1a952275 	csel	w21, w19, w21, cs	// cs = hs, nlast
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c2c:	f9400020 	ldr	x0, [x1]
  p = sbrk(nu * sizeof(Header));
 c30:	531c6eb7 	lsl	w23, w21, #4
    if(p->s.size >= nunits){
 c34:	b9400802 	ldr	w2, [x0, #8]
 c38:	6b13005f 	cmp	w2, w19
 c3c:	54000263 	b.cc	c88 <malloc+0xb0>  // b.lo, b.ul, b.last
      if(p->s.size == nunits)
 c40:	540001a1 	b.ne	c74 <malloc+0x9c>  // b.any
        prevp->s.ptr = p->s.ptr;
 c44:	f9400002 	ldr	x2, [x0]
 c48:	f9000022 	str	x2, [x1]
      else {
        p->s.size -= nunits;
        p += p->s.size;
        p->s.size = nunits;
      }
      freep = prevp;
 c4c:	f906e6c1 	str	x1, [x22, #3528]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
 c50:	91002294 	add	x20, x20, #0x8
 c54:	52800001 	mov	w1, #0x0                   	// #0
 c58:	889ffe81 	stlr	w1, [x20]
      heap_release();
      return (void*)(p + 1);
 c5c:	91004000 	add	x0, x0, #0x10
      if((p = morecore(nunits)) == 0){
        heap_release();
        return 0;
      }
  }
}
 c60:	f9401bf7 	ldr	x23, [sp, #48]
 c64:	a94153f3 	ldp	x19, x20, [sp, #16]
 c68:	a9425bf5 	ldp	x21, x22, [sp, #32]
 c6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
 c70:	d65f03c0 	ret
        p->s.size -= nunits;
 c74:	4b130042 	sub	w2, w2, w19
 c78:	b9000802 	str	w2, [x0, #8]
        p += p->s.size;
 c7c:	8b225000 	add	x0, x0, w2, uxtw #4
        p->s.size = nunits;
 c80:	b9000813 	str	w19, [x0, #8]
 c84:	17fffff2 	b	c4c <malloc+0x74>
    if(p == freep)
 c88:	f9400281 	ldr	x1, [x20]
 c8c:	eb00003f 	cmp	x1, x0
 c90:	540001e1 	b.ne	ccc <malloc+0xf4>  // b.any
  p = sbrk(nu * sizeof(Header));
 c94:	2a1703e0 	mov	w0, w23
 c98:	97fffd7e 	bl	290 <sbrk>
  if(p == (char*)-1)
 c9c:	b100041f 	cmn	x0, #0x1
 ca0:	540000c1 	b.ne	cb8 <malloc+0xe0>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
 ca4:	91002294 	add	x20, x20, #0x8
 ca8:	52800000 	mov	w0, #0x0                   	// #0
 cac:	889ffe80 	stlr	w0, [x20]
        return 0;
 cb0:	d2800000 	mov	x0, #0x0                   	// #0
 cb4:	17ffffeb 	b	c60 <malloc+0x88>
  hp->s.size = nu;
 cb8:	b9000815 	str	w21, [x0, #8]
  free_locked((void*)(hp + 1));
 cbc:	91004000 	add	x0, x0, #0x10
 cc0:	97ffff81 	bl	ac4 <free_locked>
  return freep;
 cc4:	f9400280 	ldr	x0, [x20]
      if((p = morecore(nunits)) == 0){
 cc8:	b4fffee0 	cbz	x0, ca4 <malloc+0xcc>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ccc:	aa0003e1 	mov	x1, x0
 cd0:	f9400000 	ldr	x0, [x0]
    if(p->s.size >= nunits){
 cd4:	17ffffd8 	b	c34 <malloc+0x5c>
