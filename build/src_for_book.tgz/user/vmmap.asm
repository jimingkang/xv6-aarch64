
user/_vmmap:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "user/user.h"

int
main(int argc, char **argv)
{
   0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
   4:	910003fd 	mov	x29, sp
   8:	f9000bf3 	str	x19, [sp, #16]
  int pid = 0;
  if(argc > 2){
   c:	7100081f 	cmp	w0, #0x2
  10:	540000ed 	b.le	2c <main+0x2c>
    fprintf(2, "usage: vmmap [pid]\n");
  14:	90000001 	adrp	x1, 0 <main>
  18:	912d3021 	add	x1, x1, #0xb4c
  1c:	52800040 	mov	w0, #0x2                   	// #2
  20:	940002a0 	bl	aa0 <fprintf>
    exit(1);
  24:	52800020 	mov	w0, #0x1                   	// #1
  28:	940000d6 	bl	380 <exit>
  }
  if(argc == 2){
  2c:	54000101 	b.ne	4c <main+0x4c>  // b.any
    pid = atoi(argv[1]);
  30:	f9400420 	ldr	x0, [x1, #8]
  34:	9400009e 	bl	2ac <atoi>
    if(pid <= 0){
  38:	7100001f 	cmp	w0, #0x0
  3c:	540000ac 	b.gt	50 <main+0x50>
      fprintf(2, "vmmap: invalid pid\n");
  40:	90000001 	adrp	x1, 0 <main>
  44:	912d8021 	add	x1, x1, #0xb60
  48:	17fffff5 	b	1c <main+0x1c>
  int pid = 0;
  4c:	52800000 	mov	w0, #0x0                   	// #0
      exit(1);
    }
  }
  if(vmdump(pid) < 0){
  50:	94000144 	bl	560 <vmdump>
  54:	36f80080 	tbz	w0, #31, 64 <main+0x64>
    fprintf(2, "vmmap: process not found\n");
  58:	90000001 	adrp	x1, 0 <main>
  5c:	912dd021 	add	x1, x1, #0xb74
  60:	17ffffef 	b	1c <main+0x1c>
    exit(1);
  }
  exit(0);
  64:	52800000 	mov	w0, #0x0                   	// #0
  68:	17fffff0 	b	28 <main+0x28>

000000000000006c <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  6c:	d2800002 	mov	x2, #0x0                   	// #0
  70:	38626823 	ldrb	w3, [x1, x2]
  74:	38226803 	strb	w3, [x0, x2]
  78:	91000442 	add	x2, x2, #0x1
  7c:	35ffffa3 	cbnz	w3, 70 <strcpy+0x4>
    ;
  return os;
}
  80:	d65f03c0 	ret

0000000000000084 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
  84:	d2800003 	mov	x3, #0x0                   	// #0
  88:	4b030044 	sub	w4, w2, w3
  8c:	7100009f 	cmp	w4, #0x0
  90:	5400006d 	b.le	9c <strncpy+0x18>
  94:	38636825 	ldrb	w5, [x1, x3]
  98:	350000e5 	cbnz	w5, b4 <strncpy+0x30>
  9c:	8b030003 	add	x3, x0, x3
  a0:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
  a4:	4b010082 	sub	w2, w4, w1
  a8:	7100005f 	cmp	w2, #0x0
  ac:	540000ac 	b.gt	c0 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
  b0:	d65f03c0 	ret
    *s++ = *t++;
  b4:	38236805 	strb	w5, [x0, x3]
    n--;
  b8:	91000463 	add	x3, x3, #0x1
  bc:	17fffff3 	b	88 <strncpy+0x4>
    *s++ = 0;
  c0:	3821687f 	strb	wzr, [x3, x1]
  c4:	91000421 	add	x1, x1, #0x1
  c8:	17fffff7 	b	a4 <strncpy+0x20>

00000000000000cc <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
  cc:	aa0003e2 	mov	x2, x0
  d0:	39400043 	ldrb	w3, [x2]
  d4:	aa0203e4 	mov	x4, x2
    s++;
  d8:	91000442 	add	x2, x2, #0x1
  while(*s)
  dc:	35ffffa3 	cbnz	w3, d0 <strcat+0x4>
  e0:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
  e4:	38626823 	ldrb	w3, [x1, x2]
  e8:	38226883 	strb	w3, [x4, x2]
  ec:	91000442 	add	x2, x2, #0x1
  f0:	35ffffa3 	cbnz	w3, e4 <strcat+0x18>
    ;
  return os;
}
  f4:	d65f03c0 	ret

00000000000000f8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
  f8:	d2800002 	mov	x2, #0x0                   	// #0
  fc:	38626803 	ldrb	w3, [x0, x2]
 100:	38626824 	ldrb	w4, [x1, x2]
 104:	34000083 	cbz	w3, 114 <strcmp+0x1c>
 108:	91000442 	add	x2, x2, #0x1
 10c:	6b04007f 	cmp	w3, w4
 110:	54ffff60 	b.eq	fc <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 114:	4b040060 	sub	w0, w3, w4
 118:	d65f03c0 	ret

000000000000011c <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 11c:	340001c2 	cbz	w2, 154 <strncmp+0x38>
 120:	39400003 	ldrb	w3, [x0]
 124:	34000083 	cbz	w3, 134 <strncmp+0x18>
 128:	39400024 	ldrb	w4, [x1]
 12c:	6b03009f 	cmp	w4, w3
 130:	540000a0 	b.eq	144 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 134:	39400000 	ldrb	w0, [x0]
 138:	39400021 	ldrb	w1, [x1]
 13c:	4b010000 	sub	w0, w0, w1
}
 140:	d65f03c0 	ret
    n--, p++, q++;
 144:	51000442 	sub	w2, w2, #0x1
 148:	91000400 	add	x0, x0, #0x1
 14c:	91000421 	add	x1, x1, #0x1
 150:	17fffff3 	b	11c <strncmp>
    return 0;
 154:	52800000 	mov	w0, #0x0                   	// #0
 158:	17fffffa 	b	140 <strncmp+0x24>

000000000000015c <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 15c:	d1000402 	sub	x2, x0, #0x1
 160:	d2800001 	mov	x1, #0x0                   	// #0
 164:	aa0103e0 	mov	x0, x1
 168:	91000421 	add	x1, x1, #0x1
 16c:	38616843 	ldrb	w3, [x2, x1]
 170:	35ffffa3 	cbnz	w3, 164 <strlen+0x8>
    ;
  return n;
}
 174:	d65f03c0 	ret

0000000000000178 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 178:	d1000403 	sub	x3, x0, #0x1
 17c:	d2800002 	mov	x2, #0x0                   	// #0
 180:	2a0203e0 	mov	w0, w2
 184:	6b02003f 	cmp	w1, w2
 188:	54000089 	b.ls	198 <strnlen+0x20>  // b.plast
 18c:	91000442 	add	x2, x2, #0x1
 190:	38626864 	ldrb	w4, [x3, x2]
 194:	35ffff64 	cbnz	w4, 180 <strnlen+0x8>
    n++;
  return n;
}
 198:	d65f03c0 	ret

000000000000019c <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 19c:	d2800003 	mov	x3, #0x0                   	// #0
 1a0:	6b03005f 	cmp	w2, w3
 1a4:	54000048 	b.hi	1ac <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 1a8:	d65f03c0 	ret
    cdst[i] = c;
 1ac:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 1b0:	91000463 	add	x3, x3, #0x1
 1b4:	17fffffb 	b	1a0 <memset+0x4>

00000000000001b8 <strchr>:

char*
strchr(const char *s, char c)
{
 1b8:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 1bc:	39400002 	ldrb	w2, [x0]
 1c0:	35000062 	cbnz	w2, 1cc <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 1c4:	d2800000 	mov	x0, #0x0                   	// #0
}
 1c8:	d65f03c0 	ret
    if(*s == c)
 1cc:	6b01005f 	cmp	w2, w1
 1d0:	54ffffc0 	b.eq	1c8 <strchr+0x10>  // b.none
  for(; *s; s++)
 1d4:	91000400 	add	x0, x0, #0x1
 1d8:	17fffff9 	b	1bc <strchr+0x4>

00000000000001dc <gets>:

char*
gets(char *buf, int max)
{
 1dc:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 1e0:	910003fd 	mov	x29, sp
 1e4:	a90153f3 	stp	x19, x20, [sp, #16]
 1e8:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1ec:	d2800014 	mov	x20, #0x0                   	// #0
{
 1f0:	f9001bf7 	str	x23, [sp, #48]
 1f4:	2a0103f7 	mov	w23, w1
 1f8:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 1fc:	11000695 	add	w21, w20, #0x1
 200:	2a1403f6 	mov	w22, w20
 204:	6b1702bf 	cmp	w21, w23
 208:	540000ea 	b.ge	224 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 20c:	91013fe1 	add	x1, sp, #0x4f
 210:	52800022 	mov	w2, #0x1                   	// #1
 214:	52800000 	mov	w0, #0x0                   	// #0
 218:	94000063 	bl	3a4 <read>
    if(cc < 1)
 21c:	7100001f 	cmp	w0, #0x0
 220:	5400012c 	b.gt	244 <gets+0x68>
  for(i=0; i+1 < max; ){
 224:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 228:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 22c:	aa1303e0 	mov	x0, x19
 230:	f9401bf7 	ldr	x23, [sp, #48]
 234:	a94153f3 	ldp	x19, x20, [sp, #16]
 238:	a9425bf5 	ldp	x21, x22, [sp, #32]
 23c:	a8c57bfd 	ldp	x29, x30, [sp], #80
 240:	d65f03c0 	ret
    buf[i++] = c;
 244:	39413fe0 	ldrb	w0, [sp, #79]
 248:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 24c:	91000694 	add	x20, x20, #0x1
 250:	7100281f 	cmp	w0, #0xa
 254:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 258:	54fffd21 	b.ne	1fc <gets+0x20>  // b.any
 25c:	17fffff3 	b	228 <gets+0x4c>

0000000000000260 <stat>:

int
stat(const char *n, struct stat *st)
{
 260:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 264:	910003fd 	mov	x29, sp
 268:	a90153f3 	stp	x19, x20, [sp, #16]
 26c:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 270:	52800001 	mov	w1, #0x0                   	// #0
 274:	9400005b 	bl	3e0 <open>
  if(fd < 0)
 278:	37f80160 	tbnz	w0, #31, 2a4 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 27c:	aa1303e1 	mov	x1, x19
 280:	2a0003f4 	mov	w20, w0
 284:	94000060 	bl	404 <fstat>
 288:	2a0003f3 	mov	w19, w0
  close(fd);
 28c:	2a1403e0 	mov	w0, w20
 290:	9400004b 	bl	3bc <close>
  return r;
}
 294:	2a1303e0 	mov	w0, w19
 298:	a94153f3 	ldp	x19, x20, [sp, #16]
 29c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 2a0:	d65f03c0 	ret
    return -1;
 2a4:	12800013 	mov	w19, #0xffffffff            	// #-1
 2a8:	17fffffb 	b	294 <stat+0x34>

00000000000002ac <atoi>:

int
atoi(const char *s)
{
 2ac:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 2b0:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 2b4:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 2b8:	39400043 	ldrb	w3, [x2]
 2bc:	5100c061 	sub	w1, w3, #0x30
 2c0:	12001c21 	and	w1, w1, #0xff
 2c4:	7100243f 	cmp	w1, #0x9
 2c8:	54000049 	b.ls	2d0 <atoi+0x24>  // b.plast
  return n;
}
 2cc:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 2d0:	1b040c01 	madd	w1, w0, w4, w3
 2d4:	91000442 	add	x2, x2, #0x1
 2d8:	5100c020 	sub	w0, w1, #0x30
 2dc:	17fffff7 	b	2b8 <atoi+0xc>

00000000000002e0 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2e0:	eb01001f 	cmp	x0, x1
 2e4:	54000263 	b.cc	330 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 2e8:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 2ec:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 2f0:	d2800003 	mov	x3, #0x0                   	// #0
 2f4:	d1000463 	sub	x3, x3, #0x1
 2f8:	11000464 	add	w4, w3, #0x1
 2fc:	0b020084 	add	w4, w4, w2
 300:	7100009f 	cmp	w4, #0x0
 304:	5400014d 	b.le	32c <memmove+0x4c>
      *--dst = *--src;
 308:	38636824 	ldrb	w4, [x1, x3]
 30c:	382368a4 	strb	w4, [x5, x3]
 310:	17fffff9 	b	2f4 <memmove+0x14>
      *dst++ = *src++;
 314:	38636824 	ldrb	w4, [x1, x3]
 318:	38236804 	strb	w4, [x0, x3]
 31c:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 320:	4b030044 	sub	w4, w2, w3
 324:	7100009f 	cmp	w4, #0x0
 328:	54ffff6c 	b.gt	314 <memmove+0x34>
  }
  return vdst;
}
 32c:	d65f03c0 	ret
 330:	d2800003 	mov	x3, #0x0                   	// #0
 334:	17fffffb 	b	320 <memmove+0x40>

0000000000000338 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 338:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 33c:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 340:	d2800004 	mov	x4, #0x0                   	// #0
 344:	eb02009f 	cmp	x4, x2
 348:	54000061 	b.ne	354 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 34c:	52800000 	mov	w0, #0x0                   	// #0
 350:	14000007 	b	36c <memcmp+0x34>
    if (*p1 != *p2) {
 354:	38646803 	ldrb	w3, [x0, x4]
 358:	91000484 	add	x4, x4, #0x1
 35c:	38646825 	ldrb	w5, [x1, x4]
 360:	6b05007f 	cmp	w3, w5
 364:	54ffff00 	b.eq	344 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 368:	4b050060 	sub	w0, w3, w5
}
 36c:	d65f03c0 	ret

0000000000000370 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 370:	17ffffdc 	b	2e0 <memmove>

0000000000000374 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 374:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 378:	d4000001 	svc	#0x0
 ret
 37c:	d65f03c0 	ret

0000000000000380 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 380:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 384:	d4000001 	svc	#0x0
 ret
 388:	d65f03c0 	ret

000000000000038c <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 38c:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 390:	d4000001 	svc	#0x0
 ret
 394:	d65f03c0 	ret

0000000000000398 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 398:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 39c:	d4000001 	svc	#0x0
 ret
 3a0:	d65f03c0 	ret

00000000000003a4 <read>:
.global read
read:
 mov x7, #SYS_read
 3a4:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 3a8:	d4000001 	svc	#0x0
 ret
 3ac:	d65f03c0 	ret

00000000000003b0 <write>:
.global write
write:
 mov x7, #SYS_write
 3b0:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 3b4:	d4000001 	svc	#0x0
 ret
 3b8:	d65f03c0 	ret

00000000000003bc <close>:
.global close
close:
 mov x7, #SYS_close
 3bc:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 3c0:	d4000001 	svc	#0x0
 ret
 3c4:	d65f03c0 	ret

00000000000003c8 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 3c8:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 3cc:	d4000001 	svc	#0x0
 ret
 3d0:	d65f03c0 	ret

00000000000003d4 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 3d4:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 3d8:	d4000001 	svc	#0x0
 ret
 3dc:	d65f03c0 	ret

00000000000003e0 <open>:
.global open
open:
 mov x7, #SYS_open
 3e0:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 3e4:	d4000001 	svc	#0x0
 ret
 3e8:	d65f03c0 	ret

00000000000003ec <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 3ec:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 3f0:	d4000001 	svc	#0x0
 ret
 3f4:	d65f03c0 	ret

00000000000003f8 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 3f8:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 3fc:	d4000001 	svc	#0x0
 ret
 400:	d65f03c0 	ret

0000000000000404 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 404:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 408:	d4000001 	svc	#0x0
 ret
 40c:	d65f03c0 	ret

0000000000000410 <link>:
.global link
link:
 mov x7, #SYS_link
 410:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 414:	d4000001 	svc	#0x0
 ret
 418:	d65f03c0 	ret

000000000000041c <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 41c:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 420:	d4000001 	svc	#0x0
 ret
 424:	d65f03c0 	ret

0000000000000428 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 428:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 42c:	d4000001 	svc	#0x0
 ret
 430:	d65f03c0 	ret

0000000000000434 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 434:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 438:	d4000001 	svc	#0x0
 ret
 43c:	d65f03c0 	ret

0000000000000440 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 440:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 444:	d4000001 	svc	#0x0
 ret
 448:	d65f03c0 	ret

000000000000044c <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 44c:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 450:	d4000001 	svc	#0x0
 ret
 454:	d65f03c0 	ret

0000000000000458 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 458:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 45c:	d4000001 	svc	#0x0
 ret
 460:	d65f03c0 	ret

0000000000000464 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 464:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 468:	d4000001 	svc	#0x0
 ret
 46c:	d65f03c0 	ret

0000000000000470 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 470:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 474:	d4000001 	svc	#0x0
 ret
 478:	d65f03c0 	ret

000000000000047c <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 47c:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 480:	d4000001 	svc	#0x0
 ret
 484:	d65f03c0 	ret

0000000000000488 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 488:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 48c:	d4000001 	svc	#0x0
 ret
 490:	d65f03c0 	ret

0000000000000494 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 494:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 498:	d4000001 	svc	#0x0
 ret
 49c:	d65f03c0 	ret

00000000000004a0 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 4a0:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 4a4:	d4000001 	svc	#0x0
 ret
 4a8:	d65f03c0 	ret

00000000000004ac <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 4ac:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 4b0:	d4000001 	svc	#0x0
 ret
 4b4:	d65f03c0 	ret

00000000000004b8 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 4b8:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 4bc:	d4000001 	svc	#0x0
 ret
 4c0:	d65f03c0 	ret

00000000000004c4 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 4c4:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 4c8:	d4000001 	svc	#0x0
 ret
 4cc:	d65f03c0 	ret

00000000000004d0 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 4d0:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 4d4:	d4000001 	svc	#0x0
 ret
 4d8:	d65f03c0 	ret

00000000000004dc <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 4dc:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 4e0:	d4000001 	svc	#0x0
 ret
 4e4:	d65f03c0 	ret

00000000000004e8 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 4e8:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 4ec:	d4000001 	svc	#0x0
 ret
 4f0:	d65f03c0 	ret

00000000000004f4 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 4f4:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 4f8:	d4000001 	svc	#0x0
 ret
 4fc:	d65f03c0 	ret

0000000000000500 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 500:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 504:	d4000001 	svc	#0x0
 ret
 508:	d65f03c0 	ret

000000000000050c <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 50c:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 510:	d4000001 	svc	#0x0
 ret
 514:	d65f03c0 	ret

0000000000000518 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 518:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 51c:	d4000001 	svc	#0x0
 ret
 520:	d65f03c0 	ret

0000000000000524 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 524:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 528:	d4000001 	svc	#0x0
 ret
 52c:	d65f03c0 	ret

0000000000000530 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 530:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 534:	d4000001 	svc	#0x0
 ret
 538:	d65f03c0 	ret

000000000000053c <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 53c:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 540:	d4000001 	svc	#0x0
 ret
 544:	d65f03c0 	ret

0000000000000548 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 548:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 54c:	d4000001 	svc	#0x0
 ret
 550:	d65f03c0 	ret

0000000000000554 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 554:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 558:	d4000001 	svc	#0x0
 ret
 55c:	d65f03c0 	ret

0000000000000560 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 560:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 564:	d4000001 	svc	#0x0
 ret
 568:	d65f03c0 	ret

000000000000056c <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 56c:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 570:	d4000001 	svc	#0x0
 ret
 574:	d65f03c0 	ret

0000000000000578 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 578:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 57c:	d4000001 	svc	#0x0
 ret
 580:	d65f03c0 	ret

0000000000000584 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 584:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 588:	d4000001 	svc	#0x0
 ret
 58c:	d65f03c0 	ret

0000000000000590 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 590:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 594:	d4000001 	svc	#0x0
 ret
 598:	d65f03c0 	ret

000000000000059c <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 59c:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 5a0:	d4000001 	svc	#0x0
 ret
 5a4:	d65f03c0 	ret

00000000000005a8 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 5a8:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 5ac:	d4000001 	svc	#0x0
 ret
 5b0:	d65f03c0 	ret

00000000000005b4 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 5b4:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 5b8:	d4000001 	svc	#0x0
 ret
 5bc:	d65f03c0 	ret

00000000000005c0 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 5c0:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 5c4:	d4000001 	svc	#0x0
 ret
 5c8:	d65f03c0 	ret

00000000000005cc <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 5cc:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 5d0:	d4000001 	svc	#0x0
 ret
 5d4:	d65f03c0 	ret

00000000000005d8 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 5d8:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 5dc:	d4000001 	svc	#0x0
 ret
 5e0:	d65f03c0 	ret

00000000000005e4 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 5e4:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 5e8:	d4000001 	svc	#0x0
 ret
 5ec:	d65f03c0 	ret

00000000000005f0 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 5f0:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 5f4:	d4000001 	svc	#0x0
 ret
 5f8:	d65f03c0 	ret

00000000000005fc <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 5fc:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 600:	d4000001 	svc	#0x0
 ret
 604:	d65f03c0 	ret

0000000000000608 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 608:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 60c:	d4000001 	svc	#0x0
 ret
 610:	d65f03c0 	ret

0000000000000614 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 614:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 618:	d4000001 	svc	#0x0
 ret
 61c:	d65f03c0 	ret

0000000000000620 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 620:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 624:	d4000001 	svc	#0x0
 ret
 628:	d65f03c0 	ret

000000000000062c <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 62c:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 630:	d4000001 	svc	#0x0
 ret
 634:	d65f03c0 	ret

0000000000000638 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 638:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 63c:	d4000001 	svc	#0x0
 ret
 640:	d65f03c0 	ret

0000000000000644 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 644:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 648:	d4000001 	svc	#0x0
 ret
 64c:	d65f03c0 	ret

0000000000000650 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 650:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 654:	d4000001 	svc	#0x0
 ret
 658:	d65f03c0 	ret

000000000000065c <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 65c:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 660:	d4000001 	svc	#0x0
 ret
 664:	d65f03c0 	ret

0000000000000668 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 668:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 66c:	d4000001 	svc	#0x0
 ret
 670:	d65f03c0 	ret

0000000000000674 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 674:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 678:	d4000001 	svc	#0x0
 ret
 67c:	d65f03c0 	ret

0000000000000680 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 680:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 684:	d4000001 	svc	#0x0
 ret
 688:	d65f03c0 	ret

000000000000068c <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 68c:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 690:	d4000001 	svc	#0x0
 ret
 694:	d65f03c0 	ret

0000000000000698 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 698:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 69c:	d4000001 	svc	#0x0
 ret
 6a0:	d65f03c0 	ret

00000000000006a4 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 6a4:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 6a8:	d4000001 	svc	#0x0
 ret
 6ac:	d65f03c0 	ret

00000000000006b0 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 6b0:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 6b4:	d4000001 	svc	#0x0
 ret
 6b8:	d65f03c0 	ret

00000000000006bc <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 6bc:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 6c0:	d4000001 	svc	#0x0
 ret
 6c4:	d65f03c0 	ret

00000000000006c8 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 6c8:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 6cc:	d4000001 	svc	#0x0
 ret
 6d0:	d65f03c0 	ret

00000000000006d4 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 6d4:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 6d8:	d4000001 	svc	#0x0
 ret
 6dc:	d65f03c0 	ret

00000000000006e0 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 6e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 6e4:	52800022 	mov	w2, #0x1                   	// #1
{
 6e8:	910003fd 	mov	x29, sp
 6ec:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 6f0:	91007fe1 	add	x1, sp, #0x1f
 6f4:	97ffff2f 	bl	3b0 <write>
 6f8:	7100041f 	cmp	w0, #0x1
}
 6fc:	1a9f17e0 	cset	w0, eq	// eq = none
 700:	a8c27bfd 	ldp	x29, x30, [sp], #32
 704:	d65f03c0 	ret

0000000000000708 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 708:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 70c:	910003fd 	mov	x29, sp
 710:	a90153f3 	stp	x19, x20, [sp, #16]
 714:	a9025bf5 	stp	x21, x22, [sp, #32]
 718:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 71c:	6a417c7f 	tst	w3, w1, lsr #31
 720:	54000300 	b.eq	780 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 724:	4b0103e1 	neg	w1, w1
    neg = 1;
 728:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 72c:	90000003 	adrp	x3, 0 <main>
 730:	912e5463 	add	x3, x3, #0xb95
 734:	9100c3f5 	add	x21, sp, #0x30
 738:	d2800000 	mov	x0, #0x0                   	// #0
 73c:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 740:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 744:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 748:	2a0403e1 	mov	w1, w4
 74c:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 750:	38666866 	ldrb	w6, [x3, x6]
 754:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 758:	91000400 	add	x0, x0, #0x1
 75c:	54ffff09 	b.ls	73c <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 760:	11000493 	add	w19, w4, #0x1
  if(neg)
 764:	34000085 	cbz	w5, 774 <printint+0x6c>
    buf[i++] = '-';
 768:	528005a0 	mov	w0, #0x2d                  	// #45
 76c:	38334aa0 	strb	w0, [x21, w19, uxtw]
 770:	11000893 	add	w19, w4, #0x2
 774:	51000673 	sub	w19, w19, #0x1
 778:	52800014 	mov	w20, #0x0                   	// #0
 77c:	14000008 	b	79c <printint+0x94>
  neg = 0;
 780:	52800005 	mov	w5, #0x0                   	// #0
 784:	17ffffea 	b	72c <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 788:	38736aa1 	ldrb	w1, [x21, x19]
 78c:	2a1603e0 	mov	w0, w22
 790:	d1000673 	sub	x19, x19, #0x1
 794:	97ffffd3 	bl	6e0 <putc>
 798:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 79c:	3100067f 	cmn	w19, #0x1
 7a0:	54ffff41 	b.ne	788 <printint+0x80>  // b.any
  return written;
}
 7a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
 7a8:	2a1403e0 	mov	w0, w20
 7ac:	a94153f3 	ldp	x19, x20, [sp, #16]
 7b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
 7b4:	d65f03c0 	ret

00000000000007b8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 7b8:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 7bc:	910003fd 	mov	x29, sp
 7c0:	a90153f3 	stp	x19, x20, [sp, #16]
 7c4:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 7c8:	52800015 	mov	w21, #0x0                   	// #0
{
 7cc:	a90363f7 	stp	x23, x24, [sp, #48]
 7d0:	2a0003f7 	mov	w23, w0
 7d4:	a9046bf9 	stp	x25, x26, [sp, #64]
 7d8:	aa0103f9 	mov	x25, x1

  state = 0;
 7dc:	52800001 	mov	w1, #0x0                   	// #0
{
 7e0:	a90573fb 	stp	x27, x28, [sp, #80]
 7e4:	a9406053 	ldp	x19, x24, [x2]
 7e8:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 7ec:	39400320 	ldrb	w0, [x25]
 7f0:	35000120 	cbnz	w0, 814 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 7f4:	2a1503e0 	mov	w0, w21
 7f8:	a94153f3 	ldp	x19, x20, [sp, #16]
 7fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
 800:	a94363f7 	ldp	x23, x24, [sp, #48]
 804:	a9446bf9 	ldp	x25, x26, [sp, #64]
 808:	a94573fb 	ldp	x27, x28, [sp, #80]
 80c:	a8c67bfd 	ldp	x29, x30, [sp], #96
 810:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 814:	2a0003f6 	mov	w22, w0
    if(state == 0){
 818:	35000101 	cbnz	w1, 838 <vprintf+0x80>
      if(c == '%'){
 81c:	7100941f 	cmp	w0, #0x25
 820:	54000ba0 	b.eq	994 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 824:	2a1603e1 	mov	w1, w22
 828:	2a1703e0 	mov	w0, w23
 82c:	97ffffad 	bl	6e0 <putc>
 830:	0b0002b5 	add	w21, w21, w0
 834:	14000057 	b	990 <vprintf+0x1d8>
      if(c == 'd'){
 838:	7101901f 	cmp	w0, #0x64
 83c:	540002a1 	b.ne	890 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 840:	37f80174 	tbnz	w20, #31, 86c <vprintf+0xb4>
 844:	91002e76 	add	x22, x19, #0xb
 848:	2a1403fa 	mov	w26, w20
 84c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 850:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 854:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 858:	b9400261 	ldr	w1, [x19]
 85c:	2a1703e0 	mov	w0, w23
 860:	97ffffaa 	bl	708 <printint>
        written += putc(fd, va_arg(ap, uint));
 864:	0b0002b5 	add	w21, w21, w0
 868:	14000048 	b	988 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 86c:	1100229a 	add	w26, w20, #0x8
 870:	7100035f 	cmp	w26, #0x0
 874:	5400008d 	b.le	884 <vprintf+0xcc>
 878:	91002e76 	add	x22, x19, #0xb
 87c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 880:	17fffff4 	b	850 <vprintf+0x98>
 884:	aa1303f6 	mov	x22, x19
 888:	8b34c313 	add	x19, x24, w20, sxtw
 88c:	17fffff1 	b	850 <vprintf+0x98>
      } else if(c == 'l') {
 890:	7101b01f 	cmp	w0, #0x6c
 894:	54000201 	b.ne	8d4 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 898:	37f800d4 	tbnz	w20, #31, 8b0 <vprintf+0xf8>
 89c:	91003e76 	add	x22, x19, #0xf
 8a0:	2a1403fa 	mov	w26, w20
 8a4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8a8:	52800003 	mov	w3, #0x0                   	// #0
 8ac:	17ffffea 	b	854 <vprintf+0x9c>
 8b0:	1100229a 	add	w26, w20, #0x8
 8b4:	7100035f 	cmp	w26, #0x0
 8b8:	5400008d 	b.le	8c8 <vprintf+0x110>
 8bc:	91003e76 	add	x22, x19, #0xf
 8c0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8c4:	17fffff9 	b	8a8 <vprintf+0xf0>
 8c8:	aa1303f6 	mov	x22, x19
 8cc:	8b34c313 	add	x19, x24, w20, sxtw
 8d0:	17fffff6 	b	8a8 <vprintf+0xf0>
      } else if(c == 'x') {
 8d4:	7101e01f 	cmp	w0, #0x78
 8d8:	54000221 	b.ne	91c <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 8dc:	37f800f4 	tbnz	w20, #31, 8f8 <vprintf+0x140>
 8e0:	91002e76 	add	x22, x19, #0xb
 8e4:	2a1403fa 	mov	w26, w20
 8e8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8ec:	52800003 	mov	w3, #0x0                   	// #0
 8f0:	52800202 	mov	w2, #0x10                  	// #16
 8f4:	17ffffd9 	b	858 <vprintf+0xa0>
 8f8:	1100229a 	add	w26, w20, #0x8
 8fc:	7100035f 	cmp	w26, #0x0
 900:	5400008d 	b.le	910 <vprintf+0x158>
 904:	91002e76 	add	x22, x19, #0xb
 908:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 90c:	17fffff8 	b	8ec <vprintf+0x134>
 910:	aa1303f6 	mov	x22, x19
 914:	8b34c313 	add	x19, x24, w20, sxtw
 918:	17fffff5 	b	8ec <vprintf+0x134>
      } else if(c == 'p') {
 91c:	7101c01f 	cmp	w0, #0x70
 920:	54000521 	b.ne	9c4 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 924:	37f803f4 	tbnz	w20, #31, 9a0 <vprintf+0x1e8>
 928:	91003e76 	add	x22, x19, #0xf
 92c:	2a1403fa 	mov	w26, w20
 930:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 934:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 938:	52800601 	mov	w1, #0x30                  	// #48
 93c:	2a1703e0 	mov	w0, w23
 940:	97ffff68 	bl	6e0 <putc>
 944:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 948:	9000001c 	adrp	x28, 0 <main>
 94c:	912e579c 	add	x28, x28, #0xb95
  written += putc(fd, 'x');
 950:	2a1703e0 	mov	w0, w23
 954:	52800f01 	mov	w1, #0x78                  	// #120
 958:	97ffff62 	bl	6e0 <putc>
 95c:	0b000273 	add	w19, w19, w0
 960:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 964:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 968:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 96c:	38606b81 	ldrb	w1, [x28, x0]
 970:	2a1703e0 	mov	w0, w23
 974:	97ffff5b 	bl	6e0 <putc>
 978:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 97c:	71000694 	subs	w20, w20, #0x1
 980:	54ffff21 	b.ne	964 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 984:	0b1302b5 	add	w21, w21, w19
 988:	2a1a03f4 	mov	w20, w26
 98c:	aa1603f3 	mov	x19, x22
      state = 0;
 990:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 994:	91000739 	add	x25, x25, #0x1
  state = 0;
 998:	2a1603e1 	mov	w1, w22
 99c:	17ffff94 	b	7ec <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 9a0:	1100229a 	add	w26, w20, #0x8
 9a4:	7100035f 	cmp	w26, #0x0
 9a8:	5400008d 	b.le	9b8 <vprintf+0x200>
 9ac:	91003e76 	add	x22, x19, #0xf
 9b0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9b4:	17ffffe0 	b	934 <vprintf+0x17c>
 9b8:	aa1303f6 	mov	x22, x19
 9bc:	8b34c313 	add	x19, x24, w20, sxtw
 9c0:	17ffffdd 	b	934 <vprintf+0x17c>
      } else if(c == 's'){
 9c4:	7101cc1f 	cmp	w0, #0x73
 9c8:	54000381 	b.ne	a38 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 9cc:	37f80214 	tbnz	w20, #31, a0c <vprintf+0x254>
 9d0:	91003e61 	add	x1, x19, #0xf
 9d4:	aa1303e0 	mov	x0, x19
 9d8:	927df033 	and	x19, x1, #0xfffffffffffffff8
 9dc:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 9e0:	90000000 	adrp	x0, 0 <main>
 9e4:	912e3800 	add	x0, x0, #0xb8e
 9e8:	f10002df 	cmp	x22, #0x0
 9ec:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 9f0:	394002c1 	ldrb	w1, [x22]
 9f4:	34fffce1 	cbz	w1, 990 <vprintf+0x1d8>
          written += putc(fd, *s);
 9f8:	2a1703e0 	mov	w0, w23
          s++;
 9fc:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 a00:	97ffff38 	bl	6e0 <putc>
 a04:	0b0002b5 	add	w21, w21, w0
          s++;
 a08:	17fffffa 	b	9f0 <vprintf+0x238>
        s = va_arg(ap, char*);
 a0c:	11002281 	add	w1, w20, #0x8
 a10:	7100003f 	cmp	w1, #0x0
 a14:	540000cd 	b.le	a2c <vprintf+0x274>
 a18:	91003e62 	add	x2, x19, #0xf
 a1c:	aa1303e0 	mov	x0, x19
 a20:	2a0103f4 	mov	w20, w1
 a24:	927df053 	and	x19, x2, #0xfffffffffffffff8
 a28:	17ffffed 	b	9dc <vprintf+0x224>
 a2c:	8b34c300 	add	x0, x24, w20, sxtw
 a30:	2a0103f4 	mov	w20, w1
 a34:	17ffffea 	b	9dc <vprintf+0x224>
      } else if(c == 'c'){
 a38:	71018c1f 	cmp	w0, #0x63
 a3c:	54000241 	b.ne	a84 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 a40:	37f80114 	tbnz	w20, #31, a60 <vprintf+0x2a8>
 a44:	91002e76 	add	x22, x19, #0xb
 a48:	2a1403fa 	mov	w26, w20
 a4c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a50:	39400261 	ldrb	w1, [x19]
 a54:	2a1703e0 	mov	w0, w23
 a58:	97ffff22 	bl	6e0 <putc>
 a5c:	17ffff82 	b	864 <vprintf+0xac>
 a60:	1100229a 	add	w26, w20, #0x8
 a64:	7100035f 	cmp	w26, #0x0
 a68:	5400008d 	b.le	a78 <vprintf+0x2c0>
 a6c:	91002e76 	add	x22, x19, #0xb
 a70:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a74:	17fffff7 	b	a50 <vprintf+0x298>
 a78:	aa1303f6 	mov	x22, x19
 a7c:	8b34c313 	add	x19, x24, w20, sxtw
 a80:	17fffff4 	b	a50 <vprintf+0x298>
      } else if(c == '%'){
 a84:	7100941f 	cmp	w0, #0x25
 a88:	54ffece0 	b.eq	824 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 a8c:	2a1703e0 	mov	w0, w23
 a90:	528004a1 	mov	w1, #0x25                  	// #37
 a94:	97ffff13 	bl	6e0 <putc>
 a98:	0b0002b5 	add	w21, w21, w0
 a9c:	17ffff62 	b	824 <vprintf+0x6c>

0000000000000aa0 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 aa0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 aa4:	910003fd 	mov	x29, sp
 aa8:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 aac:	910203e2 	add	x2, sp, #0x80
 ab0:	a9030be2 	stp	x2, x2, [sp, #48]
 ab4:	910143e2 	add	x2, sp, #0x50
 ab8:	f90023e2 	str	x2, [sp, #64]
 abc:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 ac0:	b9004be2 	str	w2, [sp, #72]
 ac4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 ac8:	a9430fe2 	ldp	x2, x3, [sp, #48]
 acc:	a9010fe2 	stp	x2, x3, [sp, #16]
 ad0:	a9440fe2 	ldp	x2, x3, [sp, #64]
 ad4:	a9020fe2 	stp	x2, x3, [sp, #32]
 ad8:	910043e2 	add	x2, sp, #0x10
{
 adc:	a90617e4 	stp	x4, x5, [sp, #96]
 ae0:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 ae4:	97ffff35 	bl	7b8 <vprintf>
  va_end(ap);
  return result;
}
 ae8:	a8c87bfd 	ldp	x29, x30, [sp], #128
 aec:	d65f03c0 	ret

0000000000000af0 <printf>:

int
printf(const char *fmt, ...)
{
 af0:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 af4:	910003fd 	mov	x29, sp
 af8:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 afc:	910243e1 	add	x1, sp, #0x90
 b00:	a90307e1 	stp	x1, x1, [sp, #48]
 b04:	910143e1 	add	x1, sp, #0x50
 b08:	f90023e1 	str	x1, [sp, #64]
 b0c:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 b10:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 b14:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 b18:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 b1c:	52800020 	mov	w0, #0x1                   	// #1
{
 b20:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 b24:	a9430fe2 	ldp	x2, x3, [sp, #48]
 b28:	a9010fe2 	stp	x2, x3, [sp, #16]
 b2c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 b30:	a9020fe2 	stp	x2, x3, [sp, #32]
 b34:	910043e2 	add	x2, sp, #0x10
{
 b38:	a9079be5 	stp	x5, x6, [sp, #120]
 b3c:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 b40:	97ffff1e 	bl	7b8 <vprintf>
  va_end(ap);
  return result;
}
 b44:	a8c97bfd 	ldp	x29, x30, [sp], #144
 b48:	d65f03c0 	ret
