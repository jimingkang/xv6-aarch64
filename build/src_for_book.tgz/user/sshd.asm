
user/_sshd:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  free(payload);
}

int
main(int argc, char **argv)
{
       0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
       4:	910003fd 	mov	x29, sp
       8:	a90153f3 	stp	x19, x20, [sp, #16]
  int port = 22;
  if(argc > 1)
       c:	7100041f 	cmp	w0, #0x1
      10:	5400020d 	b.le	50 <main+0x50>
    port = atoi(argv[1]);
      14:	f9400420 	ldr	x0, [x1, #8]
      18:	94000949 	bl	253c <atoi>
      1c:	2a0003f3 	mov	w19, w0
  ssh_listener = socket_listen(port, 4);
      20:	d0000034 	adrp	x20, 6000 <crypto_sign_ed25519_tweet_open+0x940>
      24:	2a1303e0 	mov	w0, w19
      28:	52800081 	mov	w1, #0x4                   	// #4
      2c:	94000a09 	bl	2850 <socket_listen>
      30:	b90aea80 	str	w0, [x20, #2792]
  if(ssh_listener < 0){
      34:	36f80120 	tbz	w0, #31, 58 <main+0x58>
    printf("sshd: cannot listen on port %d\n", port);
      38:	2a1303e1 	mov	w1, w19
      3c:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
      40:	913d7400 	add	x0, x0, #0xf5d
      44:	94000b4f 	bl	2d80 <printf>
    exit(1);
      48:	52800020 	mov	w0, #0x1                   	// #1
      4c:	94000971 	bl	2610 <exit>
  int port = 22;
      50:	528002d3 	mov	w19, #0x16                  	// #22
      54:	17fffff3 	b	20 <main+0x20>
  }
  printf("sshd: SSH-2 transport bring-up listening on port %d\n", port);
  for(;;){
    int connection = socket_accept(ssh_listener);
      58:	912ba294 	add	x20, x20, #0xae8
  printf("sshd: SSH-2 transport bring-up listening on port %d\n", port);
      5c:	2a1303e1 	mov	w1, w19
      60:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
      64:	913df400 	add	x0, x0, #0xf7d
      68:	94000b46 	bl	2d80 <printf>
    int connection = socket_accept(ssh_listener);
      6c:	b9400280 	ldr	w0, [x20]
      70:	940009fb 	bl	285c <socket_accept>
      74:	2a0003f3 	mov	w19, w0
    if(connection < 0)
      78:	37ffffa0 	tbnz	w0, #31, 6c <main+0x6c>
      continue;
    serve_connection(connection);
      7c:	940005ce 	bl	17b4 <serve_connection>
    close(connection);
      80:	2a1303e0 	mov	w0, w19
      84:	94000972 	bl	264c <close>
      88:	17fffff9 	b	6c <main+0x6c>

000000000000008c <get32>:
  return ((uint32)p[0] << 24) | ((uint32)p[1] << 16) |
      8c:	b9400000 	ldr	w0, [x0]
}
      90:	5ac00800 	rev	w0, w0
      94:	d65f03c0 	ret

0000000000000098 <parse_u32>:
  if(*offset < 0 || *offset + 4 > length)
      98:	b9400044 	ldr	w4, [x2]
      9c:	36f80064 	tbz	w4, #31, a8 <parse_u32+0x10>
    return -1;
      a0:	12800000 	mov	w0, #0xffffffff            	// #-1
}
      a4:	d65f03c0 	ret
  if(*offset < 0 || *offset + 4 > length)
      a8:	11000c85 	add	w5, w4, #0x3
      ac:	6b0100bf 	cmp	w5, w1
      b0:	54ffff8a 	b.ge	a0 <parse_u32+0x8>  // b.tcont
{
      b4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  *value = get32(p + *offset);
      b8:	8b244000 	add	x0, x0, w4, uxtw
{
      bc:	910003fd 	mov	x29, sp
  *value = get32(p + *offset);
      c0:	97fffff3 	bl	8c <get32>
}
      c4:	a8c17bfd 	ldp	x29, x30, [sp], #16
  *value = get32(p + *offset);
      c8:	b9000060 	str	w0, [x3]
  *offset += 4;
      cc:	b9400040 	ldr	w0, [x2]
      d0:	11001000 	add	w0, w0, #0x4
      d4:	b9000040 	str	w0, [x2]
  return 0;
      d8:	52800000 	mov	w0, #0x0                   	// #0
}
      dc:	d65f03c0 	ret

00000000000000e0 <parse_string>:
{
      e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
      e4:	aa0303e8 	mov	x8, x3
      e8:	aa0003e9 	mov	x9, x0
      ec:	910003fd 	mov	x29, sp
      f0:	aa0403e7 	mov	x7, x4
  if(parse_u32(p, length, offset, &n) < 0 ||
      f4:	910073e3 	add	x3, sp, #0x1c
      f8:	97ffffe8 	bl	98 <parse_u32>
      fc:	3100041f 	cmn	w0, #0x1
     100:	540001c0 	b.eq	138 <parse_string+0x58>  // b.none
     104:	aa0203e6 	mov	x6, x2
     n > (uint32)(length - *offset))
     108:	b9400042 	ldr	w2, [x2]
     10c:	b9401fe5 	ldr	w5, [sp, #28]
     110:	4b020021 	sub	w1, w1, w2
  if(parse_u32(p, length, offset, &n) < 0 ||
     114:	6b05003f 	cmp	w1, w5
     118:	54000143 	b.cc	140 <parse_string+0x60>  // b.lo, b.ul, b.last
  *value = p + *offset;
     11c:	8b22c122 	add	x2, x9, w2, sxtw
     120:	f9000102 	str	x2, [x8]
  *value_length = n;
     124:	b90000e5 	str	w5, [x7]
  *offset += n;
     128:	b94000c0 	ldr	w0, [x6]
     12c:	0b050000 	add	w0, w0, w5
     130:	b90000c0 	str	w0, [x6]
  return 0;
     134:	52800000 	mov	w0, #0x0                   	// #0
}
     138:	a8c27bfd 	ldp	x29, x30, [sp], #32
     13c:	d65f03c0 	ret
    return -1;
     140:	12800000 	mov	w0, #0xffffffff            	// #-1
     144:	17fffffd 	b	138 <parse_string+0x58>

0000000000000148 <append_bytes>:
  if(n < 0 || *offset + n > capacity)
     148:	36f800e4 	tbz	w4, #31, 164 <append_bytes+0x1c>
    return -1;
     14c:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     150:	d65f03c0 	ret
    return -1;
     154:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     158:	f9400bf3 	ldr	x19, [sp, #16]
     15c:	a8c37bfd 	ldp	x29, x30, [sp], #48
     160:	d65f03c0 	ret
{
     164:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     168:	910003fd 	mov	x29, sp
  if(n < 0 || *offset + n > capacity)
     16c:	b9400045 	ldr	w5, [x2]
{
     170:	f9000bf3 	str	x19, [sp, #16]
     174:	aa0203f3 	mov	x19, x2
  if(n < 0 || *offset + n > capacity)
     178:	0b0400a2 	add	w2, w5, w4
     17c:	6b01005f 	cmp	w2, w1
     180:	54fffeac 	b.gt	154 <append_bytes+0xc>
  memmove(p + *offset, src, n);
     184:	2a0403e2 	mov	w2, w4
     188:	aa0303e1 	mov	x1, x3
     18c:	8b25c000 	add	x0, x0, w5, sxtw
     190:	b9002fe4 	str	w4, [sp, #44]
     194:	940008f7 	bl	2570 <memmove>
  *offset += n;
     198:	b9400260 	ldr	w0, [x19]
     19c:	b9402fe4 	ldr	w4, [sp, #44]
     1a0:	0b040000 	add	w0, w0, w4
     1a4:	b9000260 	str	w0, [x19]
  return 0;
     1a8:	52800000 	mov	w0, #0x0                   	// #0
     1ac:	17ffffeb 	b	158 <append_bytes+0x10>

00000000000001b0 <string_is>:
{
     1b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     1b4:	910003fd 	mov	x29, sp
     1b8:	a90153f3 	stp	x19, x20, [sp, #16]
     1bc:	aa0003f4 	mov	x20, x0
     1c0:	aa0203f3 	mov	x19, x2
  int n = strlen(expected);
     1c4:	aa0203e0 	mov	x0, x2
{
     1c8:	b9002fe1 	str	w1, [sp, #44]
  int n = strlen(expected);
     1cc:	94000888 	bl	23ec <strlen>
  return length == (uint32)n && memcmp(value, expected, n) == 0;
     1d0:	b9402fe1 	ldr	w1, [sp, #44]
     1d4:	6b01001f 	cmp	w0, w1
     1d8:	54000141 	b.ne	200 <string_is+0x50>  // b.any
     1dc:	2a0003e2 	mov	w2, w0
     1e0:	aa1303e1 	mov	x1, x19
     1e4:	aa1403e0 	mov	x0, x20
     1e8:	940008f8 	bl	25c8 <memcmp>
     1ec:	7100001f 	cmp	w0, #0x0
     1f0:	1a9f17e0 	cset	w0, eq	// eq = none
}
     1f4:	a94153f3 	ldp	x19, x20, [sp, #16]
     1f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
     1fc:	d65f03c0 	ret
  return length == (uint32)n && memcmp(value, expected, n) == 0;
     200:	52800000 	mov	w0, #0x0                   	// #0
     204:	17fffffc 	b	1f4 <string_is+0x44>

0000000000000208 <writen>:
{
     208:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     20c:	910003fd 	mov	x29, sp
     210:	a90153f3 	stp	x19, x20, [sp, #16]
     214:	2a0203f4 	mov	w20, w2
  int done = 0;
     218:	52800013 	mov	w19, #0x0                   	// #0
{
     21c:	a9025bf5 	stp	x21, x22, [sp, #32]
     220:	2a0003f6 	mov	w22, w0
     224:	aa0103f5 	mov	x21, x1
  while(done < n){
     228:	6b14027f 	cmp	w19, w20
     22c:	540000cb 	b.lt	244 <writen+0x3c>  // b.tstop
  return 0;
     230:	52800000 	mov	w0, #0x0                   	// #0
}
     234:	a94153f3 	ldp	x19, x20, [sp, #16]
     238:	a9425bf5 	ldp	x21, x22, [sp, #32]
     23c:	a8c37bfd 	ldp	x29, x30, [sp], #48
     240:	d65f03c0 	ret
    int r = write(fd, p + done, n - done);
     244:	4b130282 	sub	w2, w20, w19
     248:	8b33c2a1 	add	x1, x21, w19, sxtw
     24c:	2a1603e0 	mov	w0, w22
     250:	940008fc 	bl	2640 <write>
    if(r <= 0)
     254:	7100001f 	cmp	w0, #0x0
     258:	5400006d 	b.le	264 <writen+0x5c>
    done += r;
     25c:	0b000273 	add	w19, w19, w0
     260:	17fffff2 	b	228 <writen+0x20>
      return -1;
     264:	12800000 	mov	w0, #0xffffffff            	// #-1
     268:	17fffff3 	b	234 <writen+0x2c>

000000000000026c <readn>:
{
     26c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     270:	910003fd 	mov	x29, sp
     274:	a90153f3 	stp	x19, x20, [sp, #16]
     278:	2a0203f4 	mov	w20, w2
  int done = 0;
     27c:	52800013 	mov	w19, #0x0                   	// #0
{
     280:	a9025bf5 	stp	x21, x22, [sp, #32]
     284:	2a0003f6 	mov	w22, w0
     288:	aa0103f5 	mov	x21, x1
  while(done < n){
     28c:	6b14027f 	cmp	w19, w20
     290:	540000cb 	b.lt	2a8 <readn+0x3c>  // b.tstop
  return 0;
     294:	52800000 	mov	w0, #0x0                   	// #0
}
     298:	a94153f3 	ldp	x19, x20, [sp, #16]
     29c:	a9425bf5 	ldp	x21, x22, [sp, #32]
     2a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
     2a4:	d65f03c0 	ret
    int r = read(fd, p + done, n - done);
     2a8:	4b130282 	sub	w2, w20, w19
     2ac:	8b33c2a1 	add	x1, x21, w19, sxtw
     2b0:	2a1603e0 	mov	w0, w22
     2b4:	940008e0 	bl	2634 <read>
    if(r <= 0)
     2b8:	7100001f 	cmp	w0, #0x0
     2bc:	5400006d 	b.le	2c8 <readn+0x5c>
    done += r;
     2c0:	0b000273 	add	w19, w19, w0
     2c4:	17fffff2 	b	28c <readn+0x20>
      return -1;
     2c8:	12800000 	mov	w0, #0xffffffff            	// #-1
     2cc:	17fffff3 	b	298 <readn+0x2c>

00000000000002d0 <append_u32>:
{
     2d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  p[3] = v;
     2d4:	5ac00863 	rev	w3, w3
  return append_bytes(p, capacity, offset, b, sizeof(b));
     2d8:	52800084 	mov	w4, #0x4                   	// #4
{
     2dc:	910003fd 	mov	x29, sp
  p[0] = v >> 24;
     2e0:	b9001be3 	str	w3, [sp, #24]
  return append_bytes(p, capacity, offset, b, sizeof(b));
     2e4:	910063e3 	add	x3, sp, #0x18
     2e8:	97ffff98 	bl	148 <append_bytes>
}
     2ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
     2f0:	d65f03c0 	ret

00000000000002f4 <append_string>:
{
     2f4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     2f8:	910003fd 	mov	x29, sp
     2fc:	a90153f3 	stp	x19, x20, [sp, #16]
     300:	aa0003f3 	mov	x19, x0
     304:	2a0103f4 	mov	w20, w1
  int n = strlen(s);
     308:	aa0303e0 	mov	x0, x3
{
     30c:	a9025bf5 	stp	x21, x22, [sp, #32]
     310:	aa0203f5 	mov	x21, x2
     314:	aa0303f6 	mov	x22, x3
  int n = strlen(s);
     318:	94000835 	bl	23ec <strlen>
  if(append_u32(p, capacity, offset, n) < 0)
     31c:	aa1503e2 	mov	x2, x21
     320:	2a0003e3 	mov	w3, w0
     324:	2a1403e1 	mov	w1, w20
     328:	b9003fe0 	str	w0, [sp, #60]
     32c:	aa1303e0 	mov	x0, x19
     330:	97ffffe8 	bl	2d0 <append_u32>
     334:	3100041f 	cmn	w0, #0x1
     338:	54000140 	b.eq	360 <append_string+0x6c>  // b.none
  return append_bytes(p, capacity, offset, s, n);
     33c:	b9403fe4 	ldr	w4, [sp, #60]
     340:	aa1603e3 	mov	x3, x22
     344:	aa1503e2 	mov	x2, x21
     348:	2a1403e1 	mov	w1, w20
}
     34c:	a9425bf5 	ldp	x21, x22, [sp, #32]
  return append_bytes(p, capacity, offset, s, n);
     350:	aa1303e0 	mov	x0, x19
}
     354:	a94153f3 	ldp	x19, x20, [sp, #16]
     358:	a8c47bfd 	ldp	x29, x30, [sp], #64
  return append_bytes(p, capacity, offset, s, n);
     35c:	17ffff7b 	b	148 <append_bytes>
}
     360:	a94153f3 	ldp	x19, x20, [sp, #16]
     364:	a9425bf5 	ldp	x21, x22, [sp, #32]
     368:	a8c47bfd 	ldp	x29, x30, [sp], #64
     36c:	d65f03c0 	ret

0000000000000370 <append_blob>:
{
     370:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     374:	910003fd 	mov	x29, sp
     378:	a90153f3 	stp	x19, x20, [sp, #16]
     37c:	aa0303f4 	mov	x20, x3
     380:	aa0003f3 	mov	x19, x0
  if(append_u32(p, capacity, offset, length) < 0)
     384:	2a0403e3 	mov	w3, w4
{
     388:	f90013e2 	str	x2, [sp, #32]
  if(append_u32(p, capacity, offset, length) < 0)
     38c:	290507e4 	stp	w4, w1, [sp, #40]
     390:	97ffffd0 	bl	2d0 <append_u32>
     394:	3100041f 	cmn	w0, #0x1
     398:	54000100 	b.eq	3b8 <append_blob+0x48>  // b.none
  return append_bytes(p, capacity, offset, data, length);
     39c:	f94013e2 	ldr	x2, [sp, #32]
     3a0:	aa1403e3 	mov	x3, x20
     3a4:	294507e4 	ldp	w4, w1, [sp, #40]
     3a8:	aa1303e0 	mov	x0, x19
}
     3ac:	a94153f3 	ldp	x19, x20, [sp, #16]
     3b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
  return append_bytes(p, capacity, offset, data, length);
     3b4:	17ffff65 	b	148 <append_bytes>
}
     3b8:	a94153f3 	ldp	x19, x20, [sp, #16]
     3bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
     3c0:	d65f03c0 	ret

00000000000003c4 <append_shared_secret_mpint>:
{
     3c4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
     3c8:	910003fd 	mov	x29, sp
     3cc:	a9025bf5 	stp	x21, x22, [sp, #32]
     3d0:	aa0003f6 	mov	x22, x0
     3d4:	a90363f7 	stp	x23, x24, [sp, #48]
     3d8:	2a0103f7 	mov	w23, w1
     3dc:	aa0203f8 	mov	x24, x2
     3e0:	a90153f3 	stp	x19, x20, [sp, #16]
     3e4:	f90023f9 	str	x25, [sp, #64]
     3e8:	aa0303f9 	mov	x25, x3
     3ec:	d2800003 	mov	x3, #0x0                   	// #0
  while(first < 32 && shared[first] == 0)
     3f0:	38636b20 	ldrb	w0, [x25, x3]
     3f4:	35000080 	cbnz	w0, 404 <append_shared_secret_mpint+0x40>
     3f8:	91000463 	add	x3, x3, #0x1
     3fc:	f100807f 	cmp	x3, #0x20
     400:	54ffff81 	b.ne	3f0 <append_shared_secret_mpint+0x2c>  // b.any
  int length = 32 - first;
     404:	52800415 	mov	w21, #0x20                  	// #32
  while(first < 32 && shared[first] == 0)
     408:	2a0303f3 	mov	w19, w3
  int length = 32 - first;
     40c:	4b0302b5 	sub	w21, w21, w3
  int zero_prefix = length > 0 && (shared[first] & 0x80);
     410:	7100807f 	cmp	w3, #0x20
     414:	540003e0 	b.eq	490 <append_shared_secret_mpint+0xcc>  // b.none
     418:	38e34b34 	ldrsb	w20, [x25, w3, uxtw]
     41c:	531f7e94 	lsr	w20, w20, #31
  if(append_u32(p, capacity, offset, length + zero_prefix) < 0)
     420:	0b150283 	add	w3, w20, w21
     424:	aa1803e2 	mov	x2, x24
     428:	2a1703e1 	mov	w1, w23
     42c:	aa1603e0 	mov	x0, x22
     430:	97ffffa8 	bl	2d0 <append_u32>
     434:	3100041f 	cmn	w0, #0x1
     438:	54000300 	b.eq	498 <append_shared_secret_mpint+0xd4>  // b.none
  if(zero_prefix){
     43c:	34000154 	cbz	w20, 464 <append_shared_secret_mpint+0xa0>
    if(append_bytes(p, capacity, offset, &zero, 1) < 0)
     440:	91017fe3 	add	x3, sp, #0x5f
     444:	aa1803e2 	mov	x2, x24
     448:	2a1703e1 	mov	w1, w23
     44c:	aa1603e0 	mov	x0, x22
     450:	52800024 	mov	w4, #0x1                   	// #1
    uchar zero = 0;
     454:	39017fff 	strb	wzr, [sp, #95]
    if(append_bytes(p, capacity, offset, &zero, 1) < 0)
     458:	97ffff3c 	bl	148 <append_bytes>
     45c:	3100041f 	cmn	w0, #0x1
     460:	540001c0 	b.eq	498 <append_shared_secret_mpint+0xd4>  // b.none
  return append_bytes(p, capacity, offset, shared + first, length);
     464:	8b334323 	add	x3, x25, w19, uxtw
     468:	2a1503e4 	mov	w4, w21
}
     46c:	f94023f9 	ldr	x25, [sp, #64]
  return append_bytes(p, capacity, offset, shared + first, length);
     470:	aa1803e2 	mov	x2, x24
}
     474:	a94153f3 	ldp	x19, x20, [sp, #16]
  return append_bytes(p, capacity, offset, shared + first, length);
     478:	2a1703e1 	mov	w1, w23
     47c:	aa1603e0 	mov	x0, x22
}
     480:	a94363f7 	ldp	x23, x24, [sp, #48]
     484:	a9425bf5 	ldp	x21, x22, [sp, #32]
     488:	a8c67bfd 	ldp	x29, x30, [sp], #96
  return append_bytes(p, capacity, offset, shared + first, length);
     48c:	17ffff2f 	b	148 <append_bytes>
  int zero_prefix = length > 0 && (shared[first] & 0x80);
     490:	52800014 	mov	w20, #0x0                   	// #0
     494:	17ffffe3 	b	420 <append_shared_secret_mpint+0x5c>
}
     498:	f94023f9 	ldr	x25, [sp, #64]
     49c:	12800000 	mov	w0, #0xffffffff            	// #-1
     4a0:	a94153f3 	ldp	x19, x20, [sp, #16]
     4a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
     4a8:	a94363f7 	ldp	x23, x24, [sp, #48]
     4ac:	a8c67bfd 	ldp	x29, x30, [sp], #96
     4b0:	d65f03c0 	ret

00000000000004b4 <derive_key>:
{
     4b4:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
     4b8:	910003fd 	mov	x29, sp
     4bc:	a90153f3 	stp	x19, x20, [sp, #16]
     4c0:	aa0003f3 	mov	x19, x0
     4c4:	2a0103f4 	mov	w20, w1
     append_shared_secret_mpint(encoded, sizeof(encoded), &off, shared) < 0 ||
     4c8:	910183e0 	add	x0, sp, #0x60
     4cc:	52801001 	mov	w1, #0x80                  	// #128
{
     4d0:	a9025bf5 	stp	x21, x22, [sp, #32]
     4d4:	aa0303f5 	mov	x21, x3
     4d8:	aa0503f6 	mov	x22, x5
     append_shared_secret_mpint(encoded, sizeof(encoded), &off, shared) < 0 ||
     4dc:	aa0203e3 	mov	x3, x2
     4e0:	9100f3e2 	add	x2, sp, #0x3c
  uchar letter_byte = letter;
     4e4:	3900efe4 	strb	w4, [sp, #59]
  int off = 0;
     4e8:	b9003fff 	str	wzr, [sp, #60]
     append_shared_secret_mpint(encoded, sizeof(encoded), &off, shared) < 0 ||
     4ec:	97ffffb6 	bl	3c4 <append_shared_secret_mpint>
  if(length > 32 ||
     4f0:	3100041f 	cmn	w0, #0x1
     4f4:	54000560 	b.eq	5a0 <derive_key+0xec>  // b.none
     append_bytes(encoded, sizeof(encoded), &off, hash, 32) < 0 ||
     4f8:	aa1503e3 	mov	x3, x21
     4fc:	9100f3e2 	add	x2, sp, #0x3c
     500:	910183e0 	add	x0, sp, #0x60
     504:	52800404 	mov	w4, #0x20                  	// #32
     508:	52801001 	mov	w1, #0x80                  	// #128
     50c:	97ffff0f 	bl	148 <append_bytes>
     append_shared_secret_mpint(encoded, sizeof(encoded), &off, shared) < 0 ||
     510:	3100041f 	cmn	w0, #0x1
     514:	54000460 	b.eq	5a0 <derive_key+0xec>  // b.none
     append_bytes(encoded, sizeof(encoded), &off, &letter_byte, 1) < 0 ||
     518:	9100efe3 	add	x3, sp, #0x3b
     51c:	9100f3e2 	add	x2, sp, #0x3c
     520:	910183e0 	add	x0, sp, #0x60
     524:	52800024 	mov	w4, #0x1                   	// #1
     528:	52801001 	mov	w1, #0x80                  	// #128
     52c:	97ffff07 	bl	148 <append_bytes>
     append_bytes(encoded, sizeof(encoded), &off, hash, 32) < 0 ||
     530:	3100041f 	cmn	w0, #0x1
     534:	54000360 	b.eq	5a0 <derive_key+0xec>  // b.none
     append_bytes(encoded, sizeof(encoded), &off, session_id, 32) < 0 ||
     538:	aa1603e3 	mov	x3, x22
     53c:	9100f3e2 	add	x2, sp, #0x3c
     540:	910183e0 	add	x0, sp, #0x60
     544:	52800404 	mov	w4, #0x20                  	// #32
     548:	52801001 	mov	w1, #0x80                  	// #128
     54c:	97fffeff 	bl	148 <append_bytes>
     append_bytes(encoded, sizeof(encoded), &off, &letter_byte, 1) < 0 ||
     550:	3100041f 	cmn	w0, #0x1
     554:	54000260 	b.eq	5a0 <derive_key+0xec>  // b.none
     ssh_sha256(digest, encoded, off) < 0)
     558:	b9803fe2 	ldrsw	x2, [sp, #60]
     55c:	910183e1 	add	x1, sp, #0x60
     560:	910103e0 	add	x0, sp, #0x40
     564:	94000ac5 	bl	3078 <ssh_sha256>
     append_bytes(encoded, sizeof(encoded), &off, session_id, 32) < 0 ||
     568:	37f80240 	tbnz	w0, #31, 5b0 <derive_key+0xfc>
  memmove(out, digest, length);
     56c:	2a1403e2 	mov	w2, w20
     570:	910103e1 	add	x1, sp, #0x40
     574:	aa1303e0 	mov	x0, x19
     578:	940007fe 	bl	2570 <memmove>
  memset(encoded, 0, sizeof(encoded));
     57c:	52801002 	mov	w2, #0x80                  	// #128
     580:	52800001 	mov	w1, #0x0                   	// #0
     584:	910183e0 	add	x0, sp, #0x60
     588:	940007a9 	bl	242c <memset>
  memset(digest, 0, sizeof(digest));
     58c:	910103e0 	add	x0, sp, #0x40
     590:	52800402 	mov	w2, #0x20                  	// #32
     594:	52800001 	mov	w1, #0x0                   	// #0
     598:	940007a5 	bl	242c <memset>
  return 0;
     59c:	52800000 	mov	w0, #0x0                   	// #0
}
     5a0:	a94153f3 	ldp	x19, x20, [sp, #16]
     5a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
     5a8:	a8ce7bfd 	ldp	x29, x30, [sp], #224
     5ac:	d65f03c0 	ret
    return -1;
     5b0:	12800000 	mov	w0, #0xffffffff            	// #-1
     5b4:	17fffffb 	b	5a0 <derive_key+0xec>

00000000000005b8 <packet_write>:
{
     5b8:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
     5bc:	910003fd 	mov	x29, sp
     5c0:	a90153f3 	stp	x19, x20, [sp, #16]
     5c4:	a9025bf5 	stp	x21, x22, [sp, #32]
     5c8:	aa0403f5 	mov	x21, x4
     5cc:	a90363f7 	stp	x23, x24, [sp, #48]
  padding = block_size - ((payload_len + 5) % block_size);
     5d0:	11001458 	add	w24, w2, #0x5
{
     5d4:	a9046bf9 	stp	x25, x26, [sp, #64]
     5d8:	aa0303f9 	mov	x25, x3
  block_size = transport->encrypt_out ? 16 : 8;
     5dc:	b9400883 	ldr	w3, [x4, #8]
     5e0:	52800104 	mov	w4, #0x8                   	// #8
{
     5e4:	f9002bfb 	str	x27, [sp, #80]
  block_size = transport->encrypt_out ? 16 : 8;
     5e8:	7100007f 	cmp	w3, #0x0
     5ec:	52800203 	mov	w3, #0x10                  	// #16
     5f0:	1a830084 	csel	w4, w4, w3, eq	// eq = none
  padding = block_size - ((payload_len + 5) % block_size);
     5f4:	1ac40f14 	sdiv	w20, w24, w4
     5f8:	1b04e294 	msub	w20, w20, w4, w24
     5fc:	4b140094 	sub	w20, w4, w20
    padding += block_size;
     600:	71000e9f 	cmp	w20, #0x3
     604:	1a9fd084 	csel	w4, w4, wzr, le
     608:	0b040294 	add	w20, w20, w4
  packet_len = payload_len + padding + 1;
     60c:	0b02029b 	add	w27, w20, w2
  total = packet_len + 4;
     610:	11001777 	add	w23, w27, #0x5
  if(total > SSH_PACKET_MAX || (packet = malloc(total)) == 0)
     614:	714006ff 	cmp	w23, #0x1, lsl #12
     618:	5400054c 	b.gt	6c0 <packet_write+0x108>
     61c:	aa0103fa 	mov	x26, x1
     620:	2a0003f6 	mov	w22, w0
     624:	2a1703e0 	mov	w0, w23
     628:	b9006fe2 	str	w2, [sp, #108]
     62c:	94000a31 	bl	2ef0 <malloc>
     630:	aa0003f3 	mov	x19, x0
     634:	b4000460 	cbz	x0, 6c0 <packet_write+0x108>
  memmove(packet + 5, payload, payload_len);
     638:	b9406fe2 	ldr	w2, [sp, #108]
  packet_len = payload_len + padding + 1;
     63c:	11000760 	add	w0, w27, #0x1
     640:	5ac00800 	rev	w0, w0
  p[0] = v >> 24;
     644:	b9000260 	str	w0, [x19]
  packet[4] = padding;
     648:	39001274 	strb	w20, [x19, #4]
  memmove(packet + 5, payload, payload_len);
     64c:	aa1a03e1 	mov	x1, x26
  if(ssh_random(packet + 5 + payload_len, padding) < 0)
     650:	8b38c278 	add	x24, x19, w24, sxtw
  memmove(packet + 5, payload, payload_len);
     654:	91001660 	add	x0, x19, #0x5
     658:	940007c6 	bl	2570 <memmove>
  if(ssh_random(packet + 5 + payload_len, padding) < 0)
     65c:	2a1403e1 	mov	w1, w20
     660:	aa1803e0 	mov	x0, x24
     664:	94000a79 	bl	3048 <ssh_random>
     668:	36f80160 	tbz	w0, #31, 694 <packet_write+0xdc>
     66c:	d2800000 	mov	x0, #0x0                   	// #0
  uint32 x = *state;
     670:	b9400321 	ldr	w1, [x25]
  x ^= x << 13;
     674:	4a013421 	eor	w1, w1, w1, lsl #13
  x ^= x >> 17;
     678:	4a414421 	eor	w1, w1, w1, lsr #17
  x ^= x << 5;
     67c:	4a011421 	eor	w1, w1, w1, lsl #5
  *state = x;
     680:	b9000321 	str	w1, [x25]
      packet[5 + payload_len + i] = prng_next(random);
     684:	38206b01 	strb	w1, [x24, x0]
    for(int i = 0; i < padding; i++)
     688:	91000400 	add	x0, x0, #0x1
     68c:	6b00029f 	cmp	w20, w0
     690:	54ffff0c 	b.gt	670 <packet_write+0xb8>
  if(transport->encrypt_out){
     694:	b9400aa0 	ldr	w0, [x21, #8]
     698:	340007e0 	cbz	w0, 794 <packet_write+0x1dc>
    put32(mac_input, transport->send_sequence);
     69c:	b94002a0 	ldr	w0, [x21]
     6a0:	5ac00800 	rev	w0, w0
  p[0] = v >> 24;
     6a4:	b9007be0 	str	w0, [sp, #120]
    uchar *authenticated = malloc(4 + total);
     6a8:	11002760 	add	w0, w27, #0x9
     6ac:	94000a11 	bl	2ef0 <malloc>
     6b0:	aa0003f8 	mov	x24, x0
    if(authenticated == 0){
     6b4:	b5000180 	cbnz	x0, 6e4 <packet_write+0x12c>
      free(packet);
     6b8:	aa1303e0 	mov	x0, x19
     6bc:	940009fe 	bl	2eb4 <free>
    return -1;
     6c0:	12800014 	mov	w20, #0xffffffff            	// #-1
}
     6c4:	f9402bfb 	ldr	x27, [sp, #80]
     6c8:	2a1403e0 	mov	w0, w20
     6cc:	a94153f3 	ldp	x19, x20, [sp, #16]
     6d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
     6d4:	a94363f7 	ldp	x23, x24, [sp, #48]
     6d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
     6dc:	a8ca7bfd 	ldp	x29, x30, [sp], #160
     6e0:	d65f03c0 	ret
    memmove(authenticated, mac_input, 4);
     6e4:	9101e3e1 	add	x1, sp, #0x78
     6e8:	52800082 	mov	w2, #0x4                   	// #4
     6ec:	940007a1 	bl	2570 <memmove>
    memmove(authenticated + 4, packet, total);
     6f0:	2a1703e2 	mov	w2, w23
     6f4:	aa1303e1 	mov	x1, x19
     6f8:	91001300 	add	x0, x24, #0x4
     6fc:	9400079d 	bl	2570 <memmove>
    if(ssh_hmac_sha256(mac, transport->mac_out, 32,
     700:	11002764 	add	w4, w27, #0x9
     704:	aa1803e3 	mov	x3, x24
     708:	9106e2a1 	add	x1, x21, #0x1b8
     70c:	910203e0 	add	x0, sp, #0x80
     710:	52800402 	mov	w2, #0x20                  	// #32
     714:	94000bfa 	bl	36fc <ssh_hmac_sha256>
     718:	36f80080 	tbz	w0, #31, 728 <packet_write+0x170>
      free(authenticated);
     71c:	aa1803e0 	mov	x0, x24
     720:	940009e5 	bl	2eb4 <free>
      free(packet);
     724:	17ffffe5 	b	6b8 <packet_write+0x100>
    free(authenticated);
     728:	aa1803e0 	mov	x0, x24
     72c:	940009e2 	bl	2eb4 <free>
    ssh_aes128_ctr_xor(&transport->cipher_out, packet, total);
     730:	2a1703e2 	mov	w2, w23
     734:	aa1303e1 	mov	x1, x19
     738:	910042a0 	add	x0, x21, #0x10
     73c:	94000c8a 	bl	3964 <ssh_aes128_ctr_xor>
    result = writen(fd, packet, total) < 0 || writen(fd, mac, 32) < 0 ? -1 : 0;
     740:	2a1703e2 	mov	w2, w23
     744:	aa1303e1 	mov	x1, x19
     748:	2a1603e0 	mov	w0, w22
     74c:	97fffeaf 	bl	208 <writen>
     750:	2a0003f4 	mov	w20, w0
     754:	3100041f 	cmn	w0, #0x1
     758:	54000180 	b.eq	788 <packet_write+0x1d0>  // b.none
     75c:	910203e1 	add	x1, sp, #0x80
     760:	2a1603e0 	mov	w0, w22
     764:	52800402 	mov	w2, #0x20                  	// #32
     768:	97fffea8 	bl	208 <writen>
     76c:	2a0003f4 	mov	w20, w0
     770:	3100041f 	cmn	w0, #0x1
     774:	540000a0 	b.eq	788 <packet_write+0x1d0>  // b.none
    transport->send_sequence++;
     778:	b94002a0 	ldr	w0, [x21]
     77c:	52800014 	mov	w20, #0x0                   	// #0
     780:	11000400 	add	w0, w0, #0x1
     784:	b90002a0 	str	w0, [x21]
  free(packet);
     788:	aa1303e0 	mov	x0, x19
     78c:	940009ca 	bl	2eb4 <free>
  return result;
     790:	17ffffcd 	b	6c4 <packet_write+0x10c>
    result = writen(fd, packet, total);
     794:	2a1703e2 	mov	w2, w23
     798:	aa1303e1 	mov	x1, x19
     79c:	2a1603e0 	mov	w0, w22
     7a0:	97fffe9a 	bl	208 <writen>
  if(result == 0)
     7a4:	34fffea0 	cbz	w0, 778 <packet_write+0x1c0>
     7a8:	12800014 	mov	w20, #0xffffffff            	// #-1
     7ac:	17fffff7 	b	788 <packet_write+0x1d0>

00000000000007b0 <send_disconnect>:
{
     7b0:	a9ac7bfd 	stp	x29, x30, [sp, #-320]!
     7b4:	910003fd 	mov	x29, sp
     7b8:	a90153f3 	stp	x19, x20, [sp, #16]
     7bc:	2a0003f3 	mov	w19, w0
  payload[off++] = SSH_MSG_DISCONNECT;
     7c0:	52800020 	mov	w0, #0x1                   	// #1
{
     7c4:	aa0103f4 	mov	x20, x1
  if(append_u32(payload, sizeof(payload), &off,
     7c8:	52802001 	mov	w1, #0x100                 	// #256
{
     7cc:	a9025bf5 	stp	x21, x22, [sp, #32]
     7d0:	aa0203f5 	mov	x21, x2
     7d4:	aa0303f6 	mov	x22, x3
  if(append_u32(payload, sizeof(payload), &off,
     7d8:	9100f3e2 	add	x2, sp, #0x3c
     7dc:	52800063 	mov	w3, #0x3                   	// #3
  payload[off++] = SSH_MSG_DISCONNECT;
     7e0:	b9003fe0 	str	w0, [sp, #60]
     7e4:	390103e0 	strb	w0, [sp, #64]
  if(append_u32(payload, sizeof(payload), &off,
     7e8:	910103e0 	add	x0, sp, #0x40
     7ec:	97fffeb9 	bl	2d0 <append_u32>
     7f0:	3100041f 	cmn	w0, #0x1
     7f4:	540002c0 	b.eq	84c <send_disconnect+0x9c>  // b.none
     append_string(payload, sizeof(payload), &off, description) < 0 ||
     7f8:	aa1403e3 	mov	x3, x20
     7fc:	9100f3e2 	add	x2, sp, #0x3c
     800:	910103e0 	add	x0, sp, #0x40
     804:	52802001 	mov	w1, #0x100                 	// #256
     808:	97fffebb 	bl	2f4 <append_string>
                SSH_DISCONNECT_KEY_EXCHANGE_FAILED) < 0 ||
     80c:	3100041f 	cmn	w0, #0x1
     810:	540001e0 	b.eq	84c <send_disconnect+0x9c>  // b.none
     append_string(payload, sizeof(payload), &off, "") < 0)
     814:	b0000023 	adrp	x3, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     818:	91321063 	add	x3, x3, #0xc84
     81c:	9100f3e2 	add	x2, sp, #0x3c
     820:	910103e0 	add	x0, sp, #0x40
     824:	52802001 	mov	w1, #0x100                 	// #256
     828:	97fffeb3 	bl	2f4 <append_string>
     append_string(payload, sizeof(payload), &off, description) < 0 ||
     82c:	3100041f 	cmn	w0, #0x1
     830:	540000e0 	b.eq	84c <send_disconnect+0x9c>  // b.none
  packet_write(fd, payload, off, random, transport);
     834:	b9403fe2 	ldr	w2, [sp, #60]
     838:	aa1603e4 	mov	x4, x22
     83c:	aa1503e3 	mov	x3, x21
     840:	910103e1 	add	x1, sp, #0x40
     844:	2a1303e0 	mov	w0, w19
     848:	97ffff5c 	bl	5b8 <packet_write>
}
     84c:	a94153f3 	ldp	x19, x20, [sp, #16]
     850:	a9425bf5 	ldp	x21, x22, [sp, #32]
     854:	a8d47bfd 	ldp	x29, x30, [sp], #320
     858:	d65f03c0 	ret

000000000000085c <send_channel_status>:
{
     85c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  p[0] = success ? SSH_MSG_CHANNEL_SUCCESS : SSH_MSG_CHANNEL_FAILURE;
     860:	52800c85 	mov	w5, #0x64                  	// #100
     864:	4b0100a5 	sub	w5, w5, w1
{
     868:	910003fd 	mov	x29, sp
     86c:	5ac00842 	rev	w2, w2
  return packet_write(fd, p, sizeof(p), random, transport);
     870:	910063e1 	add	x1, sp, #0x18
  p[0] = success ? SSH_MSG_CHANNEL_SUCCESS : SSH_MSG_CHANNEL_FAILURE;
     874:	390063e5 	strb	w5, [sp, #24]
  p[0] = v >> 24;
     878:	b80193e2 	stur	w2, [sp, #25]
  return packet_write(fd, p, sizeof(p), random, transport);
     87c:	528000a2 	mov	w2, #0x5                   	// #5
     880:	97ffff4e 	bl	5b8 <packet_write>
}
     884:	a8c27bfd 	ldp	x29, x30, [sp], #32
     888:	d65f03c0 	ret

000000000000088c <packet_read.constprop.0>:
packet_read(int fd, uchar *payload, int capacity,
     88c:	a9b47bfd 	stp	x29, x30, [sp, #-192]!
     890:	910003fd 	mov	x29, sp
     894:	a90153f3 	stp	x19, x20, [sp, #16]
     898:	aa0203f4 	mov	x20, x2
     89c:	a9025bf5 	stp	x21, x22, [sp, #32]
     8a0:	aa0103f6 	mov	x22, x1
     8a4:	a90363f7 	stp	x23, x24, [sp, #48]
     8a8:	a9046bf9 	stp	x25, x26, [sp, #64]
     8ac:	2a0003f9 	mov	w25, w0
  if(transport->encrypt_in){
     8b0:	b9400c41 	ldr	w1, [x2, #12]
packet_read(int fd, uchar *payload, int capacity,
     8b4:	f9002bfb 	str	x27, [sp, #80]
  if(transport->encrypt_in){
     8b8:	34000d21 	cbz	w1, a5c <packet_read.constprop.0+0x1d0>
    if(readn(fd, header, 16) < 0)
     8bc:	9101c3e1 	add	x1, sp, #0x70
     8c0:	52800202 	mov	w2, #0x10                  	// #16
     8c4:	97fffe6a 	bl	26c <readn>
     8c8:	2a0003f3 	mov	w19, w0
     8cc:	3100041f 	cmn	w0, #0x1
     8d0:	54000d20 	b.eq	a74 <packet_read.constprop.0+0x1e8>  // b.none
    ssh_aes128_ctr_xor(&transport->cipher_in, header, 16);
     8d4:	9101c3e1 	add	x1, sp, #0x70
     8d8:	91039280 	add	x0, x20, #0xe4
     8dc:	52800202 	mov	w2, #0x10                  	// #16
     8e0:	94000c21 	bl	3964 <ssh_aes128_ctr_xor>
  packet_len = get32(header);
     8e4:	9101c3e0 	add	x0, sp, #0x70
     8e8:	97fffde9 	bl	8c <get32>
  total = packet_len + 4;
     8ec:	11001017 	add	w23, w0, #0x4
  packet_len = get32(header);
     8f0:	2a0003f3 	mov	w19, w0
  if(packet_len < 5 || total > SSH_PACKET_MAX ||
     8f4:	714006ff 	cmp	w23, #0x1, lsl #12
     8f8:	7a44d800 	ccmp	w0, #0x4, #0x0, le
     8fc:	54000ac9 	b.ls	a54 <packet_read.constprop.0+0x1c8>  // b.plast
     total % (transport->encrypt_in ? 16 : 8) != 0)
     900:	b9400e80 	ldr	w0, [x20, #12]
     904:	52800218 	mov	w24, #0x10                  	// #16
     908:	7100001f 	cmp	w0, #0x0
     90c:	52800100 	mov	w0, #0x8                   	// #8
     910:	1a980000 	csel	w0, w0, w24, eq	// eq = none
     914:	1ac00ee1 	sdiv	w1, w23, w0
     918:	1b00dc20 	msub	w0, w1, w0, w23
  if(packet_len < 5 || total > SSH_PACKET_MAX ||
     91c:	350009c0 	cbnz	w0, a54 <packet_read.constprop.0+0x1c8>
  if((body = malloc(total)) == 0)
     920:	2a1703e0 	mov	w0, w23
     924:	94000973 	bl	2ef0 <malloc>
     928:	aa0003f5 	mov	x21, x0
     92c:	b4000940 	cbz	x0, a54 <packet_read.constprop.0+0x1c8>
  memmove(body, header, transport->encrypt_in ? 16 : 4);
     930:	b9400e81 	ldr	w1, [x20, #12]
     934:	7100003f 	cmp	w1, #0x0
     938:	52800081 	mov	w1, #0x4                   	// #4
     93c:	1a980022 	csel	w2, w1, w24, eq	// eq = none
     940:	9101c3e1 	add	x1, sp, #0x70
     944:	9400070b 	bl	2570 <memmove>
  int have = transport->encrypt_in ? 16 : 4;
     948:	b9400e80 	ldr	w0, [x20, #12]
     94c:	7100001f 	cmp	w0, #0x0
     950:	52800080 	mov	w0, #0x4                   	// #4
     954:	1a980001 	csel	w1, w0, w24, eq	// eq = none
  if(readn(fd, body + have, total - have) < 0)
     958:	2a1903e0 	mov	w0, w25
     95c:	4b0102e2 	sub	w2, w23, w1
     960:	8b2142a1 	add	x1, x21, w1, uxtw
     964:	97fffe42 	bl	26c <readn>
     968:	3100041f 	cmn	w0, #0x1
     96c:	54000700 	b.eq	a4c <packet_read.constprop.0+0x1c0>  // b.none
  if(transport->encrypt_in){
     970:	b9400e80 	ldr	w0, [x20, #12]
     974:	34000940 	cbz	w0, a9c <packet_read.constprop.0+0x210>
    ssh_aes128_ctr_xor(&transport->cipher_in, body + 16, total - 16);
     978:	51003262 	sub	w2, w19, #0xc
     97c:	910042a1 	add	x1, x21, #0x10
     980:	91039280 	add	x0, x20, #0xe4
    if(readn(fd, received_mac, sizeof(received_mac)) < 0)
     984:	910203f8 	add	x24, sp, #0x80
    ssh_aes128_ctr_xor(&transport->cipher_in, body + 16, total - 16);
     988:	94000bf7 	bl	3964 <ssh_aes128_ctr_xor>
    if(readn(fd, received_mac, sizeof(received_mac)) < 0)
     98c:	aa1803e1 	mov	x1, x24
     990:	2a1903e0 	mov	w0, w25
     994:	52800402 	mov	w2, #0x20                  	// #32
     998:	97fffe35 	bl	26c <readn>
     99c:	3100041f 	cmn	w0, #0x1
     9a0:	54000560 	b.eq	a4c <packet_read.constprop.0+0x1c0>  // b.none
    put32(sequence, transport->receive_sequence);
     9a4:	b9400680 	ldr	w0, [x20, #4]
     9a8:	5ac00800 	rev	w0, w0
  p[0] = v >> 24;
     9ac:	b9006be0 	str	w0, [sp, #104]
    uchar *authenticated = malloc(4 + total);
     9b0:	11002260 	add	w0, w19, #0x8
     9b4:	9400094f 	bl	2ef0 <malloc>
     9b8:	aa0003f9 	mov	x25, x0
    if(authenticated == 0)
     9bc:	b4000480 	cbz	x0, a4c <packet_read.constprop.0+0x1c0>
    memmove(authenticated, sequence, 4);
     9c0:	9101a3e1 	add	x1, sp, #0x68
     9c4:	52800082 	mov	w2, #0x4                   	// #4
     9c8:	940006ea 	bl	2570 <memmove>
    int failed = ssh_hmac_sha256(computed_mac, transport->mac_in, 32,
     9cc:	910283fa 	add	x26, sp, #0xa0
    memmove(authenticated + 4, body, total);
     9d0:	2a1703e2 	mov	w2, w23
     9d4:	aa1503e1 	mov	x1, x21
     9d8:	91001320 	add	x0, x25, #0x4
     9dc:	940006e5 	bl	2570 <memmove>
    int failed = ssh_hmac_sha256(computed_mac, transport->mac_in, 32,
     9e0:	11002264 	add	w4, w19, #0x8
     9e4:	aa1903e3 	mov	x3, x25
     9e8:	91076281 	add	x1, x20, #0x1d8
     9ec:	52800402 	mov	w2, #0x20                  	// #32
     9f0:	aa1a03e0 	mov	x0, x26
     9f4:	94000b42 	bl	36fc <ssh_hmac_sha256>
     9f8:	2a0003f7 	mov	w23, w0
    free(authenticated);
     9fc:	aa1903e0 	mov	x0, x25
     a00:	9400092d 	bl	2eb4 <free>
    if(failed == 0)
     a04:	35000497 	cbnz	w23, a94 <packet_read.constprop.0+0x208>
     a08:	d2800001 	mov	x1, #0x0                   	// #0
    uchar difference = 0;
     a0c:	52800000 	mov	w0, #0x0                   	// #0
        difference |= computed_mac[i] ^ received_mac[i];
     a10:	38616b42 	ldrb	w2, [x26, x1]
     a14:	38616b03 	ldrb	w3, [x24, x1]
      for(int i = 0; i < 32; i++)
     a18:	91000421 	add	x1, x1, #0x1
        difference |= computed_mac[i] ^ received_mac[i];
     a1c:	4a030042 	eor	w2, w2, w3
     a20:	2a020000 	orr	w0, w0, w2
     a24:	12001c00 	and	w0, w0, #0xff
      for(int i = 0; i < 32; i++)
     a28:	f100803f 	cmp	x1, #0x20
     a2c:	54ffff21 	b.ne	a10 <packet_read.constprop.0+0x184>  // b.any
    if(failed < 0 || difference){
     a30:	710002ff 	cmp	w23, #0x0
     a34:	7a40a800 	ccmp	w0, #0x0, #0x0, ge	// ge = tcont
     a38:	54000320 	b.eq	a9c <packet_read.constprop.0+0x210>  // b.none
      printf("sshd: encrypted packet MAC failure seq=%d\n",
     a3c:	b9400681 	ldr	w1, [x20, #4]
     a40:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     a44:	91282000 	add	x0, x0, #0xa08
     a48:	940008ce 	bl	2d80 <printf>
  free(body);
     a4c:	aa1503e0 	mov	x0, x21
     a50:	94000919 	bl	2eb4 <free>
      return -1;
     a54:	12800013 	mov	w19, #0xffffffff            	// #-1
     a58:	14000007 	b	a74 <packet_read.constprop.0+0x1e8>
  } else if(readn(fd, header, 4) < 0){
     a5c:	9101c3e1 	add	x1, sp, #0x70
     a60:	52800082 	mov	w2, #0x4                   	// #4
     a64:	97fffe02 	bl	26c <readn>
     a68:	2a0003f3 	mov	w19, w0
     a6c:	3100041f 	cmn	w0, #0x1
     a70:	54fff3a1 	b.ne	8e4 <packet_read.constprop.0+0x58>  // b.any
}
     a74:	f9402bfb 	ldr	x27, [sp, #80]
     a78:	2a1303e0 	mov	w0, w19
     a7c:	a94153f3 	ldp	x19, x20, [sp, #16]
     a80:	a9425bf5 	ldp	x21, x22, [sp, #32]
     a84:	a94363f7 	ldp	x23, x24, [sp, #48]
     a88:	a9446bf9 	ldp	x25, x26, [sp, #64]
     a8c:	a8cc7bfd 	ldp	x29, x30, [sp], #192
     a90:	d65f03c0 	ret
    uchar difference = 0;
     a94:	52800000 	mov	w0, #0x0                   	// #0
     a98:	17ffffe6 	b	a30 <packet_read.constprop.0+0x1a4>
  padding = body[4];
     a9c:	394012a0 	ldrb	w0, [x21, #4]
  payload_len = packet_len - padding - 1;
     aa0:	4b000273 	sub	w19, w19, w0
  if(padding < 4 || payload_len <= 0 || payload_len > capacity){
     aa4:	51000a61 	sub	w1, w19, #0x2
     aa8:	713ffc3f 	cmp	w1, #0xfff
     aac:	7a439800 	ccmp	w0, #0x3, #0x0, ls	// ls = plast
     ab0:	54fffce9 	b.ls	a4c <packet_read.constprop.0+0x1c0>  // b.plast
  payload_len = packet_len - padding - 1;
     ab4:	51000673 	sub	w19, w19, #0x1
  memmove(payload, body + 5, payload_len);
     ab8:	910016a1 	add	x1, x21, #0x5
     abc:	2a1303e2 	mov	w2, w19
     ac0:	aa1603e0 	mov	x0, x22
     ac4:	940006ab 	bl	2570 <memmove>
  transport->receive_sequence++;
     ac8:	b9400680 	ldr	w0, [x20, #4]
     acc:	11000400 	add	w0, w0, #0x1
     ad0:	b9000680 	str	w0, [x20, #4]
  free(body);
     ad4:	aa1503e0 	mov	x0, x21
     ad8:	940008f7 	bl	2eb4 <free>
  return payload_len;
     adc:	17ffffe6 	b	a74 <packet_read.constprop.0+0x1e8>

0000000000000ae0 <channel_session>:
{
     ae0:	a9ac7bfd 	stp	x29, x30, [sp, #-320]!
     ae4:	910003fd 	mov	x29, sp
     ae8:	a90153f3 	stp	x19, x20, [sp, #16]
     aec:	2a0003f4 	mov	w20, w0
     af0:	aa0103f3 	mov	x19, x1
     af4:	a9025bf5 	stp	x21, x22, [sp, #32]
     af8:	aa0203f6 	mov	x22, x2
     afc:	aa0303f5 	mov	x21, x3
  int n = packet_read(fd, payload, SSH_PACKET_MAX, transport), off = 1;
     b00:	aa0303e2 	mov	x2, x3
{
     b04:	a90363f7 	stp	x23, x24, [sp, #48]
     b08:	a9046bf9 	stp	x25, x26, [sp, #64]
     b0c:	aa0403fa 	mov	x26, x4
     b10:	a90573fb 	stp	x27, x28, [sp, #80]
     b14:	f9003fe5 	str	x5, [sp, #120]
  int n = packet_read(fd, payload, SSH_PACKET_MAX, transport), off = 1;
     b18:	97ffff5d 	bl	88c <packet_read.constprop.0>
     b1c:	2a0003ea 	mov	w10, w0
     b20:	52800020 	mov	w0, #0x1                   	// #1
     b24:	b900a7e0 	str	w0, [sp, #164]
  if(n < 1 || payload[0] != SSH_MSG_CHANNEL_OPEN ||
     b28:	7100015f 	cmp	w10, #0x0
     b2c:	540000cc 	b.gt	b44 <channel_session+0x64>
    printf("sshd: expected session channel open\n");
     b30:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     b34:	9128cc00 	add	x0, x0, #0xa33
     b38:	94000892 	bl	2d80 <printf>
      return -1;
     b3c:	12800017 	mov	w23, #0xffffffff            	// #-1
     b40:	14000103 	b	f4c <channel_session+0x46c>
  if(n < 1 || payload[0] != SSH_MSG_CHANNEL_OPEN ||
     b44:	39400260 	ldrb	w0, [x19]
     b48:	7101681f 	cmp	w0, #0x5a
     b4c:	54ffff21 	b.ne	b30 <channel_session+0x50>  // b.any
     parse_string(payload, n, &off, &type, &type_len) < 0 ||
     b50:	9102a3e4 	add	x4, sp, #0xa8
     b54:	910343e3 	add	x3, sp, #0xd0
     b58:	910293e2 	add	x2, sp, #0xa4
     b5c:	2a0a03e1 	mov	w1, w10
     b60:	aa1303e0 	mov	x0, x19
     b64:	97fffd5f 	bl	e0 <parse_string>
  if(n < 1 || payload[0] != SSH_MSG_CHANNEL_OPEN ||
     b68:	3100041f 	cmn	w0, #0x1
     b6c:	54fffe20 	b.eq	b30 <channel_session+0x50>  // b.none
     parse_u32(payload, n, &off, &remote_channel) < 0 ||
     b70:	9102b3e3 	add	x3, sp, #0xac
     b74:	910293e2 	add	x2, sp, #0xa4
     b78:	2a0a03e1 	mov	w1, w10
     b7c:	aa1303e0 	mov	x0, x19
     b80:	97fffd46 	bl	98 <parse_u32>
     parse_string(payload, n, &off, &type, &type_len) < 0 ||
     b84:	3100041f 	cmn	w0, #0x1
     b88:	54fffd40 	b.eq	b30 <channel_session+0x50>  // b.none
     parse_u32(payload, n, &off, &remote_window) < 0 ||
     b8c:	9102c3e3 	add	x3, sp, #0xb0
     b90:	aa1303e0 	mov	x0, x19
     b94:	97fffd41 	bl	98 <parse_u32>
     parse_u32(payload, n, &off, &remote_channel) < 0 ||
     b98:	3100041f 	cmn	w0, #0x1
     b9c:	54fffca0 	b.eq	b30 <channel_session+0x50>  // b.none
     parse_u32(payload, n, &off, &remote_max_packet) < 0 || off != n ||
     ba0:	9102d3e3 	add	x3, sp, #0xb4
     ba4:	aa1303e0 	mov	x0, x19
     ba8:	97fffd3c 	bl	98 <parse_u32>
     parse_u32(payload, n, &off, &remote_window) < 0 ||
     bac:	3100041f 	cmn	w0, #0x1
     bb0:	54fffc00 	b.eq	b30 <channel_session+0x50>  // b.none
     parse_u32(payload, n, &off, &remote_max_packet) < 0 || off != n ||
     bb4:	b940a7e0 	ldr	w0, [sp, #164]
     bb8:	6b0a001f 	cmp	w0, w10
     bbc:	54fffba1 	b.ne	b30 <channel_session+0x50>  // b.any
     remote_max_packet == 0 ||
     bc0:	b940b7e0 	ldr	w0, [sp, #180]
     bc4:	b90083e0 	str	w0, [sp, #128]
     parse_u32(payload, n, &off, &remote_max_packet) < 0 || off != n ||
     bc8:	34fffb40 	cbz	w0, b30 <channel_session+0x50>
     !string_is(type, type_len, "session")){
     bcc:	f9406be0 	ldr	x0, [sp, #208]
     bd0:	b0000022 	adrp	x2, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     bd4:	91296042 	add	x2, x2, #0xa58
     bd8:	b940abe1 	ldr	w1, [sp, #168]
     bdc:	97fffd75 	bl	1b0 <string_is>
     remote_max_packet == 0 ||
     be0:	34fffa80 	cbz	w0, b30 <channel_session+0x50>
  p[0] = v >> 24;
     be4:	910427e1 	add	x1, sp, #0x109
     be8:	b940aff8 	ldr	w24, [sp, #172]
  confirmation[0] = SSH_MSG_CHANNEL_OPEN_CONFIRMATION;
     bec:	52800b60 	mov	w0, #0x5b                  	// #91
     bf0:	390423e0 	strb	w0, [sp, #264]
  put32(confirmation + 1, remote_channel);
     bf4:	5ac00b00 	rev	w0, w24
     bf8:	b90093e0 	str	w0, [sp, #144]
  p[0] = v >> 24;
     bfc:	b9000020 	str	w0, [x1]
     c00:	910437e1 	add	x1, sp, #0x10d
     c04:	d2c02000 	mov	x0, #0x10000000000         	// #1099511627776
  if(packet_write(fd, confirmation, sizeof(confirmation), random, transport) < 0)
     c08:	aa1503e4 	mov	x4, x21
     c0c:	aa1603e3 	mov	x3, x22
     c10:	52800222 	mov	w2, #0x11                  	// #17
  p[0] = v >> 24;
     c14:	f9000020 	str	x0, [x1]
     c18:	910457e1 	add	x1, sp, #0x115
     c1c:	52a00100 	mov	w0, #0x80000               	// #524288
     c20:	b9000020 	str	w0, [x1]
  if(packet_write(fd, confirmation, sizeof(confirmation), random, transport) < 0)
     c24:	910423e1 	add	x1, sp, #0x108
     c28:	2a1403e0 	mov	w0, w20
     c2c:	97fffe63 	bl	5b8 <packet_write>
     c30:	2a0003f7 	mov	w23, w0
     c34:	3100041f 	cmn	w0, #0x1
     c38:	540018a0 	b.eq	f4c <channel_session+0x46c>  // b.none
  printf("sshd: session channel opened local=%d remote=%d\n",
     c3c:	2a1803e2 	mov	w2, w24
     c40:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     c44:	91298000 	add	x0, x0, #0xa60
     c48:	52800001 	mov	w1, #0x0                   	// #0
     c4c:	9400084d 	bl	2d80 <printf>
    off = 1;
     c50:	5280003c 	mov	w28, #0x1                   	// #1
    if(string_is(request, request_len, "pty-req")){
     c54:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     c58:	912a4400 	add	x0, x0, #0xa91
     c5c:	f90037e0 	str	x0, [sp, #104]
    } else if(string_is(request, request_len, "shell") && off == n){
     c60:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     c64:	912ad400 	add	x0, x0, #0xab5
     c68:	f9003be0 	str	x0, [sp, #112]
    n = packet_read(fd, payload, SSH_PACKET_MAX, transport);
     c6c:	aa1503e2 	mov	x2, x21
     c70:	aa1303e1 	mov	x1, x19
     c74:	2a1403e0 	mov	w0, w20
     c78:	97ffff05 	bl	88c <packet_read.constprop.0>
    off = 1;
     c7c:	b900a7fc 	str	w28, [sp, #164]
    n = packet_read(fd, payload, SSH_PACKET_MAX, transport);
     c80:	2a0003f9 	mov	w25, w0
    if(n < 1)
     c84:	7100001f 	cmp	w0, #0x0
     c88:	54fff5ad 	b.le	b3c <channel_session+0x5c>
    if(payload[0] == SSH_MSG_CHANNEL_CLOSE)
     c8c:	39400260 	ldrb	w0, [x19]
     c90:	7101841f 	cmp	w0, #0x61
     c94:	54003640 	b.eq	135c <channel_session+0x87c>  // b.none
    if(payload[0] != SSH_MSG_CHANNEL_REQUEST ||
     c98:	7101881f 	cmp	w0, #0x62
     c9c:	54fff501 	b.ne	b3c <channel_session+0x5c>  // b.any
       parse_u32(payload, n, &off, &recipient) < 0 ||
     ca0:	9102e3e3 	add	x3, sp, #0xb8
     ca4:	910293e2 	add	x2, sp, #0xa4
     ca8:	2a1903e1 	mov	w1, w25
     cac:	aa1303e0 	mov	x0, x19
     cb0:	97fffcfa 	bl	98 <parse_u32>
     cb4:	2a0003f7 	mov	w23, w0
    if(payload[0] != SSH_MSG_CHANNEL_REQUEST ||
     cb8:	3100041f 	cmn	w0, #0x1
     cbc:	54001480 	b.eq	f4c <channel_session+0x46c>  // b.none
       parse_string(payload, n, &off, &request, &request_len) < 0 ||
     cc0:	9102f3e4 	add	x4, sp, #0xbc
     cc4:	910363e3 	add	x3, sp, #0xd8
     cc8:	aa1303e0 	mov	x0, x19
     ccc:	97fffd05 	bl	e0 <parse_string>
     cd0:	2a0003f7 	mov	w23, w0
       parse_u32(payload, n, &off, &recipient) < 0 ||
     cd4:	3100041f 	cmn	w0, #0x1
     cd8:	540013a0 	b.eq	f4c <channel_session+0x46c>  // b.none
       off >= n || recipient != local_channel)
     cdc:	b940a7e0 	ldr	w0, [sp, #164]
       parse_string(payload, n, &off, &request, &request_len) < 0 ||
     ce0:	6b19001f 	cmp	w0, w25
     ce4:	54fff2ca 	b.ge	b3c <channel_session+0x5c>  // b.tcont
       off >= n || recipient != local_channel)
     ce8:	b940bbe1 	ldr	w1, [sp, #184]
     cec:	35fff281 	cbnz	w1, b3c <channel_session+0x5c>
    if(string_is(request, request_len, "pty-req")){
     cf0:	f94037e2 	ldr	x2, [sp, #104]
    int want_reply = payload[off++] != 0;
     cf4:	1100041b 	add	w27, w0, #0x1
    if(string_is(request, request_len, "pty-req")){
     cf8:	f9406fe3 	ldr	x3, [sp, #216]
     cfc:	f90047e3 	str	x3, [sp, #136]
     d00:	b940bfe1 	ldr	w1, [sp, #188]
    int want_reply = payload[off++] != 0;
     d04:	3860ca77 	ldrb	w23, [x19, w0, sxtw]
    if(string_is(request, request_len, "pty-req")){
     d08:	aa0303e0 	mov	x0, x3
     d0c:	b90097e1 	str	w1, [sp, #148]
    int want_reply = payload[off++] != 0;
     d10:	b900a7fb 	str	w27, [sp, #164]
    if(string_is(request, request_len, "pty-req")){
     d14:	97fffd27 	bl	1b0 <string_is>
     d18:	b90087e0 	str	w0, [sp, #132]
     d1c:	b94097e1 	ldr	w1, [sp, #148]
     d20:	34000620 	cbz	w0, de4 <channel_session+0x304>
      int valid = parse_string(payload, n, &off, &term, &term_len) == 0 &&
     d24:	910303e4 	add	x4, sp, #0xc0
     d28:	9103e3e3 	add	x3, sp, #0xf8
     d2c:	910293e2 	add	x2, sp, #0xa4
     d30:	2a1903e1 	mov	w1, w25
     d34:	aa1303e0 	mov	x0, x19
     d38:	97fffcea 	bl	e0 <parse_string>
                  parse_string(payload, n, &off, &modes, &modes_len) == 0 &&
     d3c:	35003140 	cbnz	w0, 1364 <channel_session+0x884>
                  parse_u32(payload, n, &off, &columns) == 0 &&
     d40:	910313e3 	add	x3, sp, #0xc4
     d44:	910293e2 	add	x2, sp, #0xa4
     d48:	2a1903e1 	mov	w1, w25
     d4c:	aa1303e0 	mov	x0, x19
     d50:	97fffcd2 	bl	98 <parse_u32>
      int valid = parse_string(payload, n, &off, &term, &term_len) == 0 &&
     d54:	35003080 	cbnz	w0, 1364 <channel_session+0x884>
                  parse_u32(payload, n, &off, &rows) == 0 &&
     d58:	910323e3 	add	x3, sp, #0xc8
     d5c:	aa1303e0 	mov	x0, x19
     d60:	97fffcce 	bl	98 <parse_u32>
                  parse_u32(payload, n, &off, &columns) == 0 &&
     d64:	35003000 	cbnz	w0, 1364 <channel_session+0x884>
                  parse_u32(payload, n, &off, &width) == 0 &&
     d68:	910333e3 	add	x3, sp, #0xcc
     d6c:	aa1303e0 	mov	x0, x19
     d70:	97fffcca 	bl	98 <parse_u32>
                  parse_u32(payload, n, &off, &rows) == 0 &&
     d74:	35002f80 	cbnz	w0, 1364 <channel_session+0x884>
                  parse_u32(payload, n, &off, &height) == 0 &&
     d78:	910383e3 	add	x3, sp, #0xe0
     d7c:	aa1303e0 	mov	x0, x19
     d80:	97fffcc6 	bl	98 <parse_u32>
                  parse_u32(payload, n, &off, &width) == 0 &&
     d84:	35002f00 	cbnz	w0, 1364 <channel_session+0x884>
                  parse_string(payload, n, &off, &modes, &modes_len) == 0 &&
     d88:	9103a3e4 	add	x4, sp, #0xe8
     d8c:	910483e3 	add	x3, sp, #0x120
     d90:	aa1303e0 	mov	x0, x19
     d94:	97fffcd3 	bl	e0 <parse_string>
                  parse_u32(payload, n, &off, &height) == 0 &&
     d98:	35002e60 	cbnz	w0, 1364 <channel_session+0x884>
                  parse_string(payload, n, &off, &modes, &modes_len) == 0 &&
     d9c:	b940a7e0 	ldr	w0, [sp, #164]
     da0:	6b19001f 	cmp	w0, w25
     da4:	1a9f17f9 	cset	w25, eq	// eq = none
      if(want_reply && send_channel_status(fd, valid, remote_channel, random,
     da8:	34000157 	cbz	w23, dd0 <channel_session+0x2f0>
     dac:	aa1503e4 	mov	x4, x21
     db0:	aa1603e3 	mov	x3, x22
     db4:	2a1803e2 	mov	w2, w24
     db8:	2a1903e1 	mov	w1, w25
     dbc:	2a1403e0 	mov	w0, w20
     dc0:	97fffea7 	bl	85c <send_channel_status>
     dc4:	2a0003f7 	mov	w23, w0
     dc8:	3100041f 	cmn	w0, #0x1
     dcc:	54000c00 	b.eq	f4c <channel_session+0x46c>  // b.none
      if(valid)
     dd0:	34fff4f9 	cbz	w25, c6c <channel_session+0x18c>
        printf("sshd: PTY request accepted\n");
     dd4:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     dd8:	912a6400 	add	x0, x0, #0xa99
     ddc:	940007e9 	bl	2d80 <printf>
     de0:	17ffffa3 	b	c6c <channel_session+0x18c>
    } else if(string_is(request, request_len, "shell") && off == n){
     de4:	f9403be2 	ldr	x2, [sp, #112]
     de8:	f94047e0 	ldr	x0, [sp, #136]
     dec:	97fffcf1 	bl	1b0 <string_is>
     df0:	34002a00 	cbz	w0, 1330 <channel_session+0x850>
     df4:	6b19037f 	cmp	w27, w25
     df8:	540029c1 	b.ne	1330 <channel_session+0x850>  // b.any
      if(pty_open(pty_fd) < 0){
     dfc:	910383e0 	add	x0, sp, #0xe0
     e00:	940006a6 	bl	2898 <pty_open>
     e04:	36f80120 	tbz	w0, #31, e28 <channel_session+0x348>
        if(want_reply)
     e08:	34ffe9b7 	cbz	w23, b3c <channel_session+0x5c>
          send_channel_status(fd, 0, remote_channel, random, transport);
     e0c:	aa1503e4 	mov	x4, x21
     e10:	aa1603e3 	mov	x3, x22
     e14:	2a1803e2 	mov	w2, w24
     e18:	2a1403e0 	mov	w0, w20
     e1c:	52800001 	mov	w1, #0x0                   	// #0
     e20:	97fffe8f 	bl	85c <send_channel_status>
     e24:	17ffff46 	b	b3c <channel_session+0x5c>
  int pid = fork();
     e28:	940005f7 	bl	2604 <fork>
     e2c:	b9006be0 	str	w0, [sp, #104]
  if(pid != 0)
     e30:	7100001f 	cmp	w0, #0x0
     e34:	340000e0 	cbz	w0, e50 <channel_session+0x370>
      if(child < 0){
     e38:	5400066a 	b.ge	f04 <channel_session+0x424>  // b.tcont
        close(pty_fd[0]);
     e3c:	b940e3e0 	ldr	w0, [sp, #224]
     e40:	94000603 	bl	264c <close>
        close(pty_fd[1]);
     e44:	b940e7e0 	ldr	w0, [sp, #228]
     e48:	94000601 	bl	264c <close>
        return -1;
     e4c:	17ffff3c 	b	b3c <channel_session+0x5c>
  close(pty_fd[0]);
     e50:	b940e3e0 	ldr	w0, [sp, #224]
     e54:	940005fe 	bl	264c <close>
  close(network_fd);
     e58:	2a1403e0 	mov	w0, w20
     e5c:	940005fc 	bl	264c <close>
  if(ssh_listener >= 0)
     e60:	d0000020 	adrp	x0, 6000 <crypto_sign_ed25519_tweet_open+0x940>
     e64:	b94ae800 	ldr	w0, [x0, #2792]
     e68:	37f80040 	tbnz	w0, #31, e70 <channel_session+0x390>
    close(ssh_listener);
     e6c:	940005f8 	bl	264c <close>
  close(0);
     e70:	52800000 	mov	w0, #0x0                   	// #0
     e74:	940005f6 	bl	264c <close>
  dup(pty_fd[1]);
     e78:	b940e7e0 	ldr	w0, [sp, #228]
     e7c:	94000612 	bl	26c4 <dup>
  close(1);
     e80:	52800020 	mov	w0, #0x1                   	// #1
     e84:	940005f2 	bl	264c <close>
  dup(pty_fd[1]);
     e88:	b940e7e0 	ldr	w0, [sp, #228]
     e8c:	9400060e 	bl	26c4 <dup>
  close(2);
     e90:	52800040 	mov	w0, #0x2                   	// #2
     e94:	940005ee 	bl	264c <close>
  dup(pty_fd[1]);
     e98:	b940e7e0 	ldr	w0, [sp, #228]
     e9c:	9400060a 	bl	26c4 <dup>
  if(pty_fd[1] > 2)
     ea0:	b940e7e0 	ldr	w0, [sp, #228]
     ea4:	7100081f 	cmp	w0, #0x2
     ea8:	5400004d 	b.le	eb0 <channel_session+0x3d0>
    close(pty_fd[1]);
     eac:	940005e8 	bl	264c <close>
  if(home[0] && chdir(home) < 0)
     eb0:	39400340 	ldrb	w0, [x26]
     eb4:	340000e0 	cbz	w0, ed0 <channel_session+0x3f0>
     eb8:	aa1a03e0 	mov	x0, x26
     ebc:	940005ff 	bl	26b8 <chdir>
     ec0:	36f80080 	tbz	w0, #31, ed0 <channel_session+0x3f0>
    chdir("/");
     ec4:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     ec8:	912aec00 	add	x0, x0, #0xabb
     ecc:	940005fb 	bl	26b8 <chdir>
  char *argv[] = { "-sh", home, 0 };
     ed0:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     ed4:	912af400 	add	x0, x0, #0xabd
     ed8:	a9126be0 	stp	x0, x26, [sp, #288]
  exec(shell, argv);
     edc:	910483e1 	add	x1, sp, #0x120
     ee0:	f9403fe0 	ldr	x0, [sp, #120]
  char *argv[] = { "-sh", home, 0 };
     ee4:	f9009bff 	str	xzr, [sp, #304]
  exec(shell, argv);
     ee8:	940005df 	bl	2664 <exec>
  exec("/bin/sh", argv);
     eec:	910483e1 	add	x1, sp, #0x120
     ef0:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     ef4:	912b0400 	add	x0, x0, #0xac1
     ef8:	940005db 	bl	2664 <exec>
  exit(127);
     efc:	52800fe0 	mov	w0, #0x7f                  	// #127
     f00:	940005c4 	bl	2610 <exit>
      close(pty_fd[1]);
     f04:	b940e7e0 	ldr	w0, [sp, #228]
     f08:	940005d1 	bl	264c <close>
      if(want_reply && send_channel_status(fd, 1, remote_channel, random,
     f0c:	34000317 	cbz	w23, f6c <channel_session+0x48c>
     f10:	aa1503e4 	mov	x4, x21
     f14:	aa1603e3 	mov	x3, x22
     f18:	2a1803e2 	mov	w2, w24
     f1c:	2a1403e0 	mov	w0, w20
     f20:	52800021 	mov	w1, #0x1                   	// #1
     f24:	97fffe4e 	bl	85c <send_channel_status>
     f28:	2a0003f7 	mov	w23, w0
     f2c:	3100041f 	cmn	w0, #0x1
     f30:	540001e1 	b.ne	f6c <channel_session+0x48c>  // b.any
        close(pty_fd[0]);
     f34:	b940e3e0 	ldr	w0, [sp, #224]
     f38:	940005c5 	bl	264c <close>
        kill(child);
     f3c:	b9406be0 	ldr	w0, [sp, #104]
     f40:	940005c6 	bl	2658 <kill>
        wait(0);
     f44:	d2800000 	mov	x0, #0x0                   	// #0
     f48:	940005b5 	bl	261c <wait>
}
     f4c:	a94153f3 	ldp	x19, x20, [sp, #16]
     f50:	2a1703e0 	mov	w0, w23
     f54:	a9425bf5 	ldp	x21, x22, [sp, #32]
     f58:	a94363f7 	ldp	x23, x24, [sp, #48]
     f5c:	a9446bf9 	ldp	x25, x26, [sp, #64]
     f60:	a94573fb 	ldp	x27, x28, [sp, #80]
     f64:	a8d47bfd 	ldp	x29, x30, [sp], #320
     f68:	d65f03c0 	ret
      printf("sshd: PTY shell started pid=%d\n", child);
     f6c:	b9406be1 	ldr	w1, [sp, #104]
     f70:	b0000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
     f74:	912b2400 	add	x0, x0, #0xac9
     f78:	94000782 	bl	2d80 <printf>
      int result = relay_shell(fd, pty_fd[0], child, local_channel,
     f7c:	b940b3f7 	ldr	w23, [sp, #176]
     f80:	b940e3fa 	ldr	w26, [sp, #224]
  uchar *terminal = malloc(SSH_CHANNEL_PACKET);
     f84:	52810000 	mov	w0, #0x800                 	// #2048
     f88:	940007da 	bl	2ef0 <malloc>
     f8c:	aa0003f9 	mov	x25, x0
  if(terminal == 0)
     f90:	b50000e0 	cbnz	x0, fac <channel_session+0x4cc>
    return -1;
     f94:	12800000 	mov	w0, #0xffffffff            	// #-1
     f98:	b90087e0 	str	w0, [sp, #132]
      close(pty_fd[0]);
     f9c:	b940e3e0 	ldr	w0, [sp, #224]
     fa0:	940005ab 	bl	264c <close>
      return result;
     fa4:	b94087f7 	ldr	w23, [sp, #132]
     fa8:	17ffffe9 	b	f4c <channel_session+0x46c>
  int epfd = epoll_create();
     fac:	9400062f 	bl	2868 <epoll_create>
     fb0:	b90073e0 	str	w0, [sp, #112]
  if(epfd < 0){
     fb4:	36f80080 	tbz	w0, #31, fc4 <channel_session+0x4e4>
  free(terminal);
     fb8:	aa1903e0 	mov	x0, x25
     fbc:	940007be 	bl	2eb4 <free>
  return -1;
     fc0:	17fffff5 	b	f94 <channel_session+0x4b4>
  event.events = EPOLLIN;
     fc4:	5280003c 	mov	w28, #0x1                   	// #1
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event) < 0)
     fc8:	9103e3e3 	add	x3, sp, #0xf8
     fcc:	2a1403e2 	mov	w2, w20
     fd0:	2a1c03e1 	mov	w1, w28
  event.events = EPOLLIN;
     fd4:	b900fbfc 	str	w28, [sp, #248]
  event.data.fd = fd;
     fd8:	b90103f4 	str	w20, [sp, #256]
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event) < 0)
     fdc:	94000626 	bl	2874 <epoll_ctl>
     fe0:	37f81a20 	tbnz	w0, #31, 1324 <channel_session+0x844>
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, master, &event) < 0)
     fe4:	b94073e0 	ldr	w0, [sp, #112]
     fe8:	9103e3e3 	add	x3, sp, #0xf8
     fec:	2a1a03e2 	mov	w2, w26
     ff0:	2a1c03e1 	mov	w1, w28
  event.data.fd = master;
     ff4:	b90103fa 	str	w26, [sp, #256]
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, master, &event) < 0)
     ff8:	9400061f 	bl	2874 <epoll_ctl>
     ffc:	37f81940 	tbnz	w0, #31, 1324 <channel_session+0x844>
  p[off++] = SSH_MSG_CHANNEL_DATA;
    1000:	b9009bfc 	str	w28, [sp, #152]
    int ready = epoll_wait(epfd, events, 2, -1);
    1004:	b94073e0 	ldr	w0, [sp, #112]
    1008:	910483e1 	add	x1, sp, #0x120
    100c:	12800003 	mov	w3, #0xffffffff            	// #-1
    1010:	52800042 	mov	w2, #0x2                   	// #2
    1014:	9400061b 	bl	2880 <epoll_wait>
    1018:	b90097e0 	str	w0, [sp, #148]
    if(ready < 0)
    101c:	37f81640 	tbnz	w0, #31, 12e4 <channel_session+0x804>
    1020:	910483e0 	add	x0, sp, #0x120
    1024:	f9003fe0 	str	x0, [sp, #120]
    for(int i = 0; i < ready; i++){
    1028:	b9008bff 	str	wzr, [sp, #136]
    102c:	b9408be1 	ldr	w1, [sp, #136]
    1030:	b94097e0 	ldr	w0, [sp, #148]
    1034:	6b01001f 	cmp	w0, w1
    1038:	54fffe60 	b.eq	1004 <channel_session+0x524>  // b.none
      if(events[i].data.fd == fd){
    103c:	f9403fe0 	ldr	x0, [sp, #120]
    1040:	b940081c 	ldr	w28, [x0, #8]
    1044:	6b1c029f 	cmp	w20, w28
    1048:	54000d21 	b.ne	11ec <channel_session+0x70c>  // b.any
        int n = packet_read(fd, payload, SSH_PACKET_MAX, transport);
    104c:	aa1503e2 	mov	x2, x21
    1050:	aa1303e1 	mov	x1, x19
    1054:	2a1403e0 	mov	w0, w20
    1058:	97fffe0d 	bl	88c <packet_read.constprop.0>
    105c:	2a0003e2 	mov	w2, w0
        if(n < 1)
    1060:	7100001f 	cmp	w0, #0x0
    1064:	5400076d 	b.le	1150 <channel_session+0x670>
        if(payload[0] == SSH_MSG_CHANNEL_WINDOW_ADJUST && n == 9 &&
    1068:	39400261 	ldrb	w1, [x19]
    106c:	7101743f 	cmp	w1, #0x5d
    1070:	54000281 	b.ne	10c0 <channel_session+0x5e0>  // b.any
    1074:	7100241f 	cmp	w0, #0x9
    1078:	54000121 	b.ne	109c <channel_session+0x5bc>  // b.any
           get32(payload + 1) == local_channel){
    107c:	91000660 	add	x0, x19, #0x1
    1080:	97fffc03 	bl	8c <get32>
        if(payload[0] == SSH_MSG_CHANNEL_WINDOW_ADJUST && n == 9 &&
    1084:	350000c0 	cbnz	w0, 109c <channel_session+0x5bc>
          uint32 added = get32(payload + 5);
    1088:	91001660 	add	x0, x19, #0x5
    108c:	97fffc00 	bl	8c <get32>
          if(0xffffffffU - remote_window < added)
    1090:	2b0002e1 	adds	w1, w23, w0
    1094:	54000122 	b.cs	10b8 <channel_session+0x5d8>  // b.hs, b.nlast
            remote_window += added;
    1098:	2a0103f7 	mov	w23, w1
    for(int i = 0; i < ready; i++){
    109c:	b9408be0 	ldr	w0, [sp, #136]
    10a0:	11000400 	add	w0, w0, #0x1
    10a4:	b9008be0 	str	w0, [sp, #136]
    10a8:	f9403fe0 	ldr	x0, [sp, #120]
    10ac:	91004000 	add	x0, x0, #0x10
    10b0:	f9003fe0 	str	x0, [sp, #120]
    10b4:	17ffffde 	b	102c <channel_session+0x54c>
            remote_window = 0xffffffffU;
    10b8:	12800017 	mov	w23, #0xffffffff            	// #-1
    10bc:	17fffff8 	b	109c <channel_session+0x5bc>
        } else if(payload[0] == SSH_MSG_CHANNEL_DATA && n >= 9 &&
    10c0:	7101783f 	cmp	w1, #0x5e
    10c4:	54000581 	b.ne	1174 <channel_session+0x694>  // b.any
    10c8:	7100201f 	cmp	w0, #0x8
    10cc:	54fffe8d 	b.le	109c <channel_session+0x5bc>
                  get32(payload + 1) == local_channel){
    10d0:	91000660 	add	x0, x19, #0x1
    10d4:	97fffbee 	bl	8c <get32>
        } else if(payload[0] == SSH_MSG_CHANNEL_DATA && n >= 9 &&
    10d8:	35fffe20 	cbnz	w0, 109c <channel_session+0x5bc>
          uint32 length = get32(payload + 5);
    10dc:	91001660 	add	x0, x19, #0x5
    10e0:	97fffbeb 	bl	8c <get32>
    10e4:	2a0003fb 	mov	w27, w0
          if(length > SSH_CHANNEL_PACKET || length > (uint32)(n - 9) ||
    10e8:	7120001f 	cmp	w0, #0x800
    10ec:	54000328 	b.hi	1150 <channel_session+0x670>  // b.pmore
    10f0:	51002440 	sub	w0, w2, #0x9
    10f4:	6b00037f 	cmp	w27, w0
    10f8:	540002c8 	b.hi	1150 <channel_session+0x670>  // b.pmore
             writen(master, payload + 9, length) < 0 ||
    10fc:	2a1b03e2 	mov	w2, w27
    1100:	91002661 	add	x1, x19, #0x9
    1104:	2a1a03e0 	mov	w0, w26
    1108:	97fffc40 	bl	208 <writen>
          if(length > SSH_CHANNEL_PACKET || length > (uint32)(n - 9) ||
    110c:	3100041f 	cmn	w0, #0x1
    1110:	54000200 	b.eq	1150 <channel_session+0x670>  // b.none
  p[0] = SSH_MSG_CHANNEL_WINDOW_ADJUST;
    1114:	52800ba0 	mov	w0, #0x5d                  	// #93
  p[2] = v >> 8;
    1118:	5ac00763 	rev16	w3, w27
  p[0] = SSH_MSG_CHANNEL_WINDOW_ADJUST;
    111c:	3903a3e0 	strb	w0, [sp, #232]
  return packet_write(fd, p, sizeof(p), random, transport);
    1120:	aa1503e4 	mov	x4, x21
  p[0] = v >> 24;
    1124:	b94093e0 	ldr	w0, [sp, #144]
  return packet_write(fd, p, sizeof(p), random, transport);
    1128:	9103a3e1 	add	x1, sp, #0xe8
    112c:	52800122 	mov	w2, #0x9                   	// #9
  p[0] = v >> 24;
    1130:	b80e93e0 	stur	w0, [sp, #233]
  return packet_write(fd, p, sizeof(p), random, transport);
    1134:	2a1c03e0 	mov	w0, w28
  p[0] = v >> 24;
    1138:	780ed3ff 	sturh	wzr, [sp, #237]
  p[2] = v >> 8;
    113c:	780ef3e3 	sturh	w3, [sp, #239]
  return packet_write(fd, p, sizeof(p), random, transport);
    1140:	aa1603e3 	mov	x3, x22
    1144:	97fffd1d 	bl	5b8 <packet_write>
             writen(master, payload + 9, length) < 0 ||
    1148:	3100041f 	cmn	w0, #0x1
    114c:	54fffa81 	b.ne	109c <channel_session+0x5bc>  // b.any
  close(epfd);
    1150:	b94073e0 	ldr	w0, [sp, #112]
    1154:	9400053e 	bl	264c <close>
  free(terminal);
    1158:	aa1903e0 	mov	x0, x25
    115c:	94000756 	bl	2eb4 <free>
  kill(child);
    1160:	b9406be0 	ldr	w0, [sp, #104]
    1164:	9400053d 	bl	2658 <kill>
  wait(0);
    1168:	d2800000 	mov	x0, #0x0                   	// #0
    116c:	9400052c 	bl	261c <wait>
  return 0;
    1170:	17ffff8b 	b	f9c <channel_session+0x4bc>
        } else if(payload[0] == SSH_MSG_CHANNEL_EOF && n == 5 &&
    1174:	7101803f 	cmp	w1, #0x60
    1178:	540001a1 	b.ne	11ac <channel_session+0x6cc>  // b.any
    117c:	7100141f 	cmp	w0, #0x5
    1180:	54fff8e1 	b.ne	109c <channel_session+0x5bc>  // b.any
                  get32(payload + 1) == local_channel){
    1184:	91000660 	add	x0, x19, #0x1
    1188:	97fffbc1 	bl	8c <get32>
        } else if(payload[0] == SSH_MSG_CHANNEL_EOF && n == 5 &&
    118c:	35fff880 	cbnz	w0, 109c <channel_session+0x5bc>
          uchar eof = 4;
    1190:	52800080 	mov	w0, #0x4                   	// #4
          write(master, &eof, 1);
    1194:	9103a3e1 	add	x1, sp, #0xe8
    1198:	52800022 	mov	w2, #0x1                   	// #1
          uchar eof = 4;
    119c:	3903a3e0 	strb	w0, [sp, #232]
          write(master, &eof, 1);
    11a0:	2a1a03e0 	mov	w0, w26
    11a4:	94000527 	bl	2640 <write>
                  get32(payload + 1) == local_channel){
    11a8:	17ffffbd 	b	109c <channel_session+0x5bc>
        } else if(payload[0] == SSH_MSG_CHANNEL_CLOSE && n == 5 &&
    11ac:	7101843f 	cmp	w1, #0x61
    11b0:	54fff761 	b.ne	109c <channel_session+0x5bc>  // b.any
    11b4:	7100141f 	cmp	w0, #0x5
    11b8:	54fff721 	b.ne	109c <channel_session+0x5bc>  // b.any
                  get32(payload + 1) == local_channel){
    11bc:	91000660 	add	x0, x19, #0x1
    11c0:	97fffbb3 	bl	8c <get32>
        } else if(payload[0] == SSH_MSG_CHANNEL_CLOSE && n == 5 &&
    11c4:	35fff6c0 	cbnz	w0, 109c <channel_session+0x5bc>
  p[0] = v >> 24;
    11c8:	b94093e0 	ldr	w0, [sp, #144]
          packet_write(fd, close_packet, sizeof(close_packet), random,
    11cc:	aa1503e4 	mov	x4, x21
    11d0:	aa1603e3 	mov	x3, x22
          close_packet[0] = SSH_MSG_CHANNEL_CLOSE;
    11d4:	3903a3e1 	strb	w1, [sp, #232]
  p[0] = v >> 24;
    11d8:	b80e93e0 	stur	w0, [sp, #233]
    packet_write(fd, p, sizeof(p), random, transport);
    11dc:	9103a3e1 	add	x1, sp, #0xe8
    11e0:	2a1403e0 	mov	w0, w20
    11e4:	97fffcf5 	bl	5b8 <packet_write>
    11e8:	17ffffda 	b	1150 <channel_session+0x670>
      } else if(events[i].data.fd == master){
    11ec:	6b1c035f 	cmp	w26, w28
    11f0:	54fff561 	b.ne	109c <channel_session+0x5bc>  // b.any
        if(events[i].events & EPOLLERR)
    11f4:	f9403fe0 	ldr	x0, [sp, #120]
    11f8:	b9400000 	ldr	w0, [x0]
    11fc:	37180740 	tbnz	w0, #3, 12e4 <channel_session+0x804>
        if(limit > SSH_CHANNEL_PACKET)
    1200:	b94083e0 	ldr	w0, [sp, #128]
    1204:	52810001 	mov	w1, #0x800                 	// #2048
    1208:	7120001f 	cmp	w0, #0x800
    120c:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
        if(limit > remote_window)
    1210:	6b17005f 	cmp	w2, w23
    1214:	1a979042 	csel	w2, w2, w23, ls	// ls = plast
        if(limit == 0)
    1218:	34fff422 	cbz	w2, 109c <channel_session+0x5bc>
        int n = read(master, terminal, limit);
    121c:	aa1903e1 	mov	x1, x25
    1220:	2a1a03e0 	mov	w0, w26
    1224:	94000504 	bl	2634 <read>
    1228:	2a0003fb 	mov	w27, w0
        if(n <= 0)
    122c:	7100001f 	cmp	w0, #0x0
    1230:	540005ad 	b.le	12e4 <channel_session+0x804>
  if(length < 0 || length > SSH_CHANNEL_PACKET ||
    1234:	7120001f 	cmp	w0, #0x800
    1238:	54fff8c8 	b.hi	1150 <channel_session+0x670>  // b.pmore
     (p = malloc(9 + length)) == 0)
    123c:	11002401 	add	w1, w0, #0x9
    1240:	b9009fe1 	str	w1, [sp, #156]
    1244:	2a0103e0 	mov	w0, w1
    1248:	9400072a 	bl	2ef0 <malloc>
    124c:	aa0003fc 	mov	x28, x0
  if(length < 0 || length > SSH_CHANNEL_PACKET ||
    1250:	b4fff800 	cbz	x0, 1150 <channel_session+0x670>
  p[off++] = SSH_MSG_CHANNEL_DATA;
    1254:	b9409be1 	ldr	w1, [sp, #152]
  if(append_u32(p, 9 + length, &off, remote_channel) < 0 ||
    1258:	2a1803e3 	mov	w3, w24
  p[off++] = SSH_MSG_CHANNEL_DATA;
    125c:	b900ebe1 	str	w1, [sp, #232]
  if(append_u32(p, 9 + length, &off, remote_channel) < 0 ||
    1260:	9103a3e2 	add	x2, sp, #0xe8
  p[off++] = SSH_MSG_CHANNEL_DATA;
    1264:	52800bc1 	mov	w1, #0x5e                  	// #94
    1268:	39000001 	strb	w1, [x0]
  if(append_u32(p, 9 + length, &off, remote_channel) < 0 ||
    126c:	b9409fe1 	ldr	w1, [sp, #156]
    1270:	b9009fe1 	str	w1, [sp, #156]
    1274:	97fffc17 	bl	2d0 <append_u32>
    1278:	3100041f 	cmn	w0, #0x1
    127c:	b9409fe1 	ldr	w1, [sp, #156]
    1280:	54000081 	b.ne	1290 <channel_session+0x7b0>  // b.any
    free(p);
    1284:	aa1c03e0 	mov	x0, x28
    1288:	9400070b 	bl	2eb4 <free>
    return -1;
    128c:	17ffffb1 	b	1150 <channel_session+0x670>
     append_blob(p, 9 + length, &off, data, length) < 0){
    1290:	2a1b03e4 	mov	w4, w27
    1294:	aa1903e3 	mov	x3, x25
    1298:	9103a3e2 	add	x2, sp, #0xe8
    129c:	aa1c03e0 	mov	x0, x28
    12a0:	97fffc34 	bl	370 <append_blob>
  if(append_u32(p, 9 + length, &off, remote_channel) < 0 ||
    12a4:	3100041f 	cmn	w0, #0x1
    12a8:	54fffee0 	b.eq	1284 <channel_session+0x7a4>  // b.none
  int result = packet_write(fd, p, off, random, transport);
    12ac:	b940ebe2 	ldr	w2, [sp, #232]
    12b0:	aa1503e4 	mov	x4, x21
    12b4:	aa1603e3 	mov	x3, x22
    12b8:	aa1c03e1 	mov	x1, x28
    12bc:	2a1403e0 	mov	w0, w20
    12c0:	97fffcbe 	bl	5b8 <packet_write>
    12c4:	b9009fe0 	str	w0, [sp, #156]
  free(p);
    12c8:	aa1c03e0 	mov	x0, x28
    12cc:	940006fa 	bl	2eb4 <free>
        if(send_channel_data(fd, remote_channel, terminal, n, random,
    12d0:	b9409fe0 	ldr	w0, [sp, #156]
    12d4:	3100041f 	cmn	w0, #0x1
    12d8:	54fff3c0 	b.eq	1150 <channel_session+0x670>  // b.none
        remote_window -= n;
    12dc:	4b1b02f7 	sub	w23, w23, w27
    12e0:	17ffff6f 	b	109c <channel_session+0x5bc>
    p[0] = SSH_MSG_CHANNEL_EOF;
    12e4:	52800c00 	mov	w0, #0x60                  	// #96
    12e8:	3903a3e0 	strb	w0, [sp, #232]
  p[0] = v >> 24;
    12ec:	b94093e0 	ldr	w0, [sp, #144]
    packet_write(fd, p, sizeof(p), random, transport);
    12f0:	aa1503e4 	mov	x4, x21
    12f4:	aa1603e3 	mov	x3, x22
    12f8:	528000a2 	mov	w2, #0x5                   	// #5
    12fc:	9103a3e1 	add	x1, sp, #0xe8
  p[0] = v >> 24;
    1300:	b80e93e0 	stur	w0, [sp, #233]
    packet_write(fd, p, sizeof(p), random, transport);
    1304:	2a1403e0 	mov	w0, w20
    1308:	97fffcac 	bl	5b8 <packet_write>
    p[0] = SSH_MSG_CHANNEL_CLOSE;
    130c:	52800c20 	mov	w0, #0x61                  	// #97
    packet_write(fd, p, sizeof(p), random, transport);
    1310:	aa1503e4 	mov	x4, x21
    1314:	aa1603e3 	mov	x3, x22
    1318:	528000a2 	mov	w2, #0x5                   	// #5
    p[0] = SSH_MSG_CHANNEL_CLOSE;
    131c:	3903a3e0 	strb	w0, [sp, #232]
    packet_write(fd, p, sizeof(p), random, transport);
    1320:	17ffffaf 	b	11dc <channel_session+0x6fc>
  close(epfd);
    1324:	b94073e0 	ldr	w0, [sp, #112]
    1328:	940004c9 	bl	264c <close>
    132c:	17ffff23 	b	fb8 <channel_session+0x4d8>
      if(want_reply && send_channel_status(fd, 0, remote_channel, random,
    1330:	34ffc9f7 	cbz	w23, c6c <channel_session+0x18c>
    1334:	aa1503e4 	mov	x4, x21
    1338:	aa1603e3 	mov	x3, x22
    133c:	2a1803e2 	mov	w2, w24
    1340:	2a1403e0 	mov	w0, w20
    1344:	52800001 	mov	w1, #0x0                   	// #0
    1348:	97fffd45 	bl	85c <send_channel_status>
    134c:	2a0003f7 	mov	w23, w0
    1350:	3100041f 	cmn	w0, #0x1
    1354:	54ffc8c1 	b.ne	c6c <channel_session+0x18c>  // b.any
    1358:	17fffefd 	b	f4c <channel_session+0x46c>
      return 0;
    135c:	52800017 	mov	w23, #0x0                   	// #0
    1360:	17fffefb 	b	f4c <channel_session+0x46c>
      if(want_reply && send_channel_status(fd, valid, remote_channel, random,
    1364:	34ffc857 	cbz	w23, c6c <channel_session+0x18c>
    1368:	52800019 	mov	w25, #0x0                   	// #0
    136c:	17fffe90 	b	dac <channel_session+0x2cc>

0000000000001370 <userauth>:
{
    1370:	d10c43ff 	sub	sp, sp, #0x310
    1374:	a9007bfd 	stp	x29, x30, [sp]
    1378:	910003fd 	mov	x29, sp
    137c:	a90153f3 	stp	x19, x20, [sp, #16]
    1380:	aa0103f3 	mov	x19, x1
    1384:	a9046bf9 	stp	x25, x26, [sp, #64]
    1388:	aa0303fa 	mov	x26, x3
    138c:	2a0003f9 	mov	w25, w0
       !string_is(service, service_len, "ssh-connection")){
    1390:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1394:	912ba400 	add	x0, x0, #0xae9
{
    1398:	a9025bf5 	stp	x21, x22, [sp, #32]
    139c:	a90363f7 	stp	x23, x24, [sp, #48]
    13a0:	a90573fb 	stp	x27, x28, [sp, #80]
    13a4:	528000db 	mov	w27, #0x6                   	// #6
    13a8:	a90697e4 	stp	x4, x5, [sp, #104]
    13ac:	f9003fe2 	str	x2, [sp, #120]
       !string_is(service, service_len, "ssh-connection")){
    13b0:	f90047e0 	str	x0, [sp, #136]
    int n = packet_read(fd, payload, SSH_PACKET_MAX, transport);
    13b4:	aa1a03e2 	mov	x2, x26
    13b8:	aa1303e1 	mov	x1, x19
    13bc:	2a1903e0 	mov	w0, w25
    13c0:	97fffd33 	bl	88c <packet_read.constprop.0>
    13c4:	2a0003f4 	mov	w20, w0
    int off = 1;
    13c8:	52800020 	mov	w0, #0x1                   	// #1
    13cc:	b900a7e0 	str	w0, [sp, #164]
    if(n < 1 || payload[0] != SSH_MSG_USERAUTH_REQUEST ||
    13d0:	7100029f 	cmp	w20, #0x0
    13d4:	5400042d 	b.le	1458 <userauth+0xe8>
    13d8:	39400260 	ldrb	w0, [x19]
    13dc:	7100c81f 	cmp	w0, #0x32
    13e0:	540003c1 	b.ne	1458 <userauth+0xe8>  // b.any
       parse_string(payload, n, &off, &name, &name_len) < 0 ||
    13e4:	9102a3e4 	add	x4, sp, #0xa8
    13e8:	9102e3e3 	add	x3, sp, #0xb8
    13ec:	910293e2 	add	x2, sp, #0xa4
    13f0:	2a1403e1 	mov	w1, w20
    13f4:	aa1303e0 	mov	x0, x19
    13f8:	97fffb3a 	bl	e0 <parse_string>
    if(n < 1 || payload[0] != SSH_MSG_USERAUTH_REQUEST ||
    13fc:	3100041f 	cmn	w0, #0x1
    1400:	540002c0 	b.eq	1458 <userauth+0xe8>  // b.none
       parse_string(payload, n, &off, &service, &service_len) < 0 ||
    1404:	9102b3e4 	add	x4, sp, #0xac
    1408:	910303e3 	add	x3, sp, #0xc0
    140c:	910293e2 	add	x2, sp, #0xa4
    1410:	2a1403e1 	mov	w1, w20
    1414:	aa1303e0 	mov	x0, x19
    1418:	97fffb32 	bl	e0 <parse_string>
       parse_string(payload, n, &off, &name, &name_len) < 0 ||
    141c:	3100041f 	cmn	w0, #0x1
    1420:	540001c0 	b.eq	1458 <userauth+0xe8>  // b.none
       parse_string(payload, n, &off, &method, &method_len) < 0 ||
    1424:	9102c3e4 	add	x4, sp, #0xb0
    1428:	910323e3 	add	x3, sp, #0xc8
    142c:	910293e2 	add	x2, sp, #0xa4
    1430:	2a1403e1 	mov	w1, w20
    1434:	aa1303e0 	mov	x0, x19
    1438:	97fffb2a 	bl	e0 <parse_string>
       parse_string(payload, n, &off, &service, &service_len) < 0 ||
    143c:	3100041f 	cmn	w0, #0x1
    1440:	540000c0 	b.eq	1458 <userauth+0xe8>  // b.none
       !string_is(service, service_len, "ssh-connection")){
    1444:	f94047e2 	ldr	x2, [sp, #136]
    1448:	f94063e0 	ldr	x0, [sp, #192]
    144c:	b940afe1 	ldr	w1, [sp, #172]
    1450:	97fffb58 	bl	1b0 <string_is>
       parse_string(payload, n, &off, &method, &method_len) < 0 ||
    1454:	350000c0 	cbnz	w0, 146c <userauth+0xfc>
      printf("sshd: malformed SSH_MSG_USERAUTH_REQUEST\n");
    1458:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    145c:	912be000 	add	x0, x0, #0xaf8
    1460:	94000648 	bl	2d80 <printf>
      return -1;
    1464:	12800000 	mov	w0, #0xffffffff            	// #-1
    1468:	140000c0 	b	1768 <userauth+0x3f8>
    if(string_is(method, method_len, "password")){
    146c:	f94067e0 	ldr	x0, [sp, #200]
    1470:	90000038 	adrp	x24, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1474:	912c8b18 	add	x24, x24, #0xb22
    1478:	b940b3e1 	ldr	w1, [sp, #176]
    147c:	aa1803e2 	mov	x2, x24
    1480:	97fffb4c 	bl	1b0 <string_is>
    1484:	34000660 	cbz	w0, 1550 <userauth+0x1e0>
      if(off >= n || payload[off++] != 0 ||
    1488:	b940a7e0 	ldr	w0, [sp, #164]
    148c:	6b14001f 	cmp	w0, w20
    1490:	54fffeaa 	b.ge	1464 <userauth+0xf4>  // b.tcont
    1494:	11000401 	add	w1, w0, #0x1
    1498:	3860ca60 	ldrb	w0, [x19, w0, sxtw]
    149c:	b900a7e1 	str	w1, [sp, #164]
    14a0:	35fffe20 	cbnz	w0, 1464 <userauth+0xf4>
         parse_string(payload, n, &off, &password, &password_len) < 0 ||
    14a4:	9102d3e4 	add	x4, sp, #0xb4
    14a8:	910343e3 	add	x3, sp, #0xd0
    14ac:	910293e2 	add	x2, sp, #0xa4
    14b0:	2a1403e1 	mov	w1, w20
    14b4:	aa1303e0 	mov	x0, x19
    14b8:	97fffb0a 	bl	e0 <parse_string>
      if(off >= n || payload[off++] != 0 ||
    14bc:	3100041f 	cmn	w0, #0x1
    14c0:	54001540 	b.eq	1768 <userauth+0x3f8>  // b.none
         parse_string(payload, n, &off, &password, &password_len) < 0 ||
    14c4:	b940a7e0 	ldr	w0, [sp, #164]
    14c8:	6b14001f 	cmp	w0, w20
    14cc:	54fffcc1 	b.ne	1464 <userauth+0xf4>  // b.any
      if(authenticate(name, name_len, password, password_len, home, shell) == 0){
    14d0:	f9405fe0 	ldr	x0, [sp, #184]
    14d4:	f90033e0 	str	x0, [sp, #96]
    14d8:	f9406be0 	ldr	x0, [sp, #208]
  int fd = open("/etc/passwd", O_RDONLY);
    14dc:	52800001 	mov	w1, #0x0                   	// #0
      if(authenticate(name, name_len, password, password_len, home, shell) == 0){
    14e0:	b940abf6 	ldr	w22, [sp, #168]
    14e4:	b940b7f7 	ldr	w23, [sp, #180]
    14e8:	f90043e0 	str	x0, [sp, #128]
  int fd = open("/etc/passwd", O_RDONLY);
    14ec:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    14f0:	912cac00 	add	x0, x0, #0xb2b
    14f4:	9400045f 	bl	2670 <open>
    14f8:	2a0003fc 	mov	w28, w0
  if(fd < 0)
    14fc:	37f80240 	tbnz	w0, #31, 1544 <userauth+0x1d4>
  int n = read(fd, buf, sizeof(buf) - 1);
    1500:	910443f4 	add	x20, sp, #0x110
    1504:	52803fe2 	mov	w2, #0x1ff                 	// #511
    1508:	aa1403e1 	mov	x1, x20
    150c:	9400044a 	bl	2634 <read>
    1510:	2a0003f5 	mov	w21, w0
  close(fd);
    1514:	2a1c03e0 	mov	w0, w28
    1518:	9400044d 	bl	264c <close>
  if(n <= 0)
    151c:	710002bf 	cmp	w21, #0x0
    1520:	5400012d 	b.le	1544 <userauth+0x1d4>
  for(line = buf; *line; line = end){
    1524:	aa1403fc 	mov	x28, x20
  buf[n] = 0;
    1528:	38354a9f 	strb	wzr, [x20, w21, uxtw]
  for(line = buf; *line; line = end){
    152c:	39400380 	ldrb	w0, [x28]
    1530:	35000420 	cbnz	w0, 15b4 <userauth+0x244>
  memset(buf, 0, sizeof(buf));
    1534:	aa1403e0 	mov	x0, x20
    1538:	52804002 	mov	w2, #0x200                 	// #512
    153c:	52800001 	mov	w1, #0x0                   	// #0
    1540:	940003bb 	bl	242c <memset>
      printf("sshd: password authentication rejected\n");
    1544:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1548:	912dcc00 	add	x0, x0, #0xb73
    154c:	9400060d 	bl	2d80 <printf>
  p[off++] = SSH_MSG_USERAUTH_FAILURE;
    1550:	52800020 	mov	w0, #0x1                   	// #1
  if(append_string(p, sizeof(p), &off, "password") < 0)
    1554:	910443f4 	add	x20, sp, #0x110
  p[off++] = SSH_MSG_USERAUTH_FAILURE;
    1558:	b900dbe0 	str	w0, [sp, #216]
    155c:	52800660 	mov	w0, #0x33                  	// #51
  if(append_string(p, sizeof(p), &off, "password") < 0)
    1560:	aa1803e3 	mov	x3, x24
    1564:	910363e2 	add	x2, sp, #0xd8
    1568:	52800801 	mov	w1, #0x40                  	// #64
  p[off++] = SSH_MSG_USERAUTH_FAILURE;
    156c:	390443e0 	strb	w0, [sp, #272]
  if(append_string(p, sizeof(p), &off, "password") < 0)
    1570:	aa1403e0 	mov	x0, x20
    1574:	97fffb60 	bl	2f4 <append_string>
    1578:	3100041f 	cmn	w0, #0x1
    157c:	54000f60 	b.eq	1768 <userauth+0x3f8>  // b.none
  p[off++] = 0; // partial success = false
    1580:	b940dbe2 	ldr	w2, [sp, #216]
  return packet_write(fd, p, off, random, transport);
    1584:	aa1a03e4 	mov	x4, x26
    1588:	f9403fe3 	ldr	x3, [sp, #120]
    158c:	aa1403e1 	mov	x1, x20
    1590:	2a1903e0 	mov	w0, w25
  p[off++] = 0; // partial success = false
    1594:	3822ca9f 	strb	wzr, [x20, w2, sxtw]
  return packet_write(fd, p, off, random, transport);
    1598:	11000442 	add	w2, w2, #0x1
    159c:	97fffc07 	bl	5b8 <packet_write>
    if(send_userauth_failure(fd, random, transport) < 0)
    15a0:	3100041f 	cmn	w0, #0x1
    15a4:	54000e20 	b.eq	1768 <userauth+0x3f8>  // b.none
  for(int attempt = 0; attempt < 6; attempt++){
    15a8:	7100077b 	subs	w27, w27, #0x1
    15ac:	54fff041 	b.ne	13b4 <userauth+0x44>  // b.any
    15b0:	17ffffad 	b	1464 <userauth+0xf4>
    end = strchr(line, '\n');
    15b4:	aa1c03e0 	mov	x0, x28
    15b8:	52800141 	mov	w1, #0xa                   	// #10
    15bc:	940003a3 	bl	2448 <strchr>
    if(end)
    15c0:	b40004a0 	cbz	x0, 1654 <userauth+0x2e4>
      *end++ = 0;
    15c4:	aa0003f5 	mov	x21, x0
    15c8:	380016bf 	strb	wzr, [x21], #1
    if(*line == 0 || *line == '#')
    15cc:	39400380 	ldrb	w0, [x28]
    15d0:	71008c1f 	cmp	w0, #0x23
    15d4:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    15d8:	54000e00 	b.eq	1798 <userauth+0x428>  // b.none
    char *field[7], *cursor = line;
    15dc:	aa1c03e0 	mov	x0, x28
    if(*line == 0 || *line == '#')
    15e0:	d2800022 	mov	x2, #0x1                   	// #1
      cursor = strchr(cursor, ':');
    15e4:	52800741 	mov	w1, #0x3a                  	// #58
    15e8:	f9004be2 	str	x2, [sp, #144]
    15ec:	94000397 	bl	2448 <strchr>
      if(cursor == 0){
    15f0:	b4000d40 	cbz	x0, 1798 <userauth+0x428>
      field[i + 1] = cursor;
    15f4:	f9404be2 	ldr	x2, [sp, #144]
    15f8:	910363e1 	add	x1, sp, #0xd8
      *cursor++ = 0;
    15fc:	3800141f 	strb	wzr, [x0], #1
      field[i + 1] = cursor;
    1600:	f8227820 	str	x0, [x1, x2, lsl #3]
    for(int i = 0; i < 6; i++){
    1604:	91000442 	add	x2, x2, #0x1
    1608:	f1001c5f 	cmp	x2, #0x7
    160c:	54fffec1 	b.ne	15e4 <userauth+0x274>  // b.any
    uint32 user_len = strlen(field[0]);
    1610:	aa1c03e0 	mov	x0, x28
    1614:	94000376 	bl	23ec <strlen>
    uint32 pass_len = strlen(field[1]);
    1618:	f94073e6 	ldr	x6, [sp, #224]
    uint32 user_len = strlen(field[0]);
    161c:	2a0003e5 	mov	w5, w0
    uint32 pass_len = strlen(field[1]);
    1620:	f9004be6 	str	x6, [sp, #144]
    1624:	aa0603e0 	mov	x0, x6
    uint32 user_len = strlen(field[0]);
    1628:	b9009fe5 	str	w5, [sp, #156]
    uint32 pass_len = strlen(field[1]);
    162c:	94000370 	bl	23ec <strlen>
    uchar difference = (user_len != name_length) | (pass_len != password_length);
    1630:	b9409fe5 	ldr	w5, [sp, #156]
    for(uint32 i = 0; i < max; i++){
    1634:	d2800001 	mov	x1, #0x0                   	// #0
    1638:	f9404be6 	ldr	x6, [sp, #144]
    uchar difference = (user_len != name_length) | (pass_len != password_length);
    163c:	6b0502df 	cmp	w22, w5
    1640:	7a4002e0 	ccmp	w23, w0, #0x0, eq	// eq = none
    1644:	1a9f07e4 	cset	w4, ne	// ne = any
    uint32 max = pass_len > password_length ? pass_len : password_length;
    1648:	6b0002ff 	cmp	w23, w0
    164c:	1a8022e8 	csel	w8, w23, w0, cs	// cs = hs, nlast
    for(uint32 i = 0; i < max; i++){
    1650:	1400000f 	b	168c <userauth+0x31c>
      end = line + strlen(line);
    1654:	aa1c03e0 	mov	x0, x28
    1658:	94000365 	bl	23ec <strlen>
    165c:	8b204395 	add	x21, x28, w0, uxtw
    1660:	17ffffdb 	b	15cc <userauth+0x25c>
      uchar a = i < pass_len ? (uchar)field[1][i] : 0;
    1664:	6b00003f 	cmp	w1, w0
    1668:	54000902 	b.cs	1788 <userauth+0x418>  // b.hs, b.nlast
    166c:	386168c2 	ldrb	w2, [x6, x1]
      uchar b = i < password_length ? password[i] : 0;
    1670:	6b0702ff 	cmp	w23, w7
    1674:	540008e9 	b.ls	1790 <userauth+0x420>  // b.plast
    1678:	f94043e3 	ldr	x3, [sp, #128]
    167c:	38616867 	ldrb	w7, [x3, x1]
      difference |= a ^ b;
    1680:	4a070042 	eor	w2, w2, w7
    1684:	91000421 	add	x1, x1, #0x1
    1688:	2a020084 	orr	w4, w4, w2
    for(uint32 i = 0; i < max; i++){
    168c:	2a0103e7 	mov	w7, w1
    1690:	6b08003f 	cmp	w1, w8
    1694:	54fffe83 	b.cc	1664 <userauth+0x2f4>  // b.lo, b.ul, b.last
    if(user_len == name_length && memcmp(field[0], name, name_length) == 0 &&
    1698:	6b0502df 	cmp	w22, w5
    169c:	540007e1 	b.ne	1798 <userauth+0x428>  // b.any
    16a0:	f94033e1 	ldr	x1, [sp, #96]
    16a4:	2a1603e2 	mov	w2, w22
    16a8:	aa1c03e0 	mov	x0, x28
    16ac:	b90093e4 	str	w4, [sp, #144]
    16b0:	940003c6 	bl	25c8 <memcmp>
    16b4:	35000720 	cbnz	w0, 1798 <userauth+0x428>
    16b8:	b94093e4 	ldr	w4, [sp, #144]
    16bc:	350006e4 	cbnz	w4, 1798 <userauth+0x428>
      strncpy(home, field[5], 63);
    16c0:	f94037e0 	ldr	x0, [sp, #104]
    16c4:	528007e2 	mov	w2, #0x3f                  	// #63
    16c8:	f94083e1 	ldr	x1, [sp, #256]
    16cc:	94000312 	bl	2314 <strncpy>
      home[63] = 0;
    16d0:	f94037e0 	ldr	x0, [sp, #104]
      strncpy(shell, field[6], 63);
    16d4:	528007e2 	mov	w2, #0x3f                  	// #63
    16d8:	f94087e1 	ldr	x1, [sp, #264]
      home[63] = 0;
    16dc:	3900fc1f 	strb	wzr, [x0, #63]
      strncpy(shell, field[6], 63);
    16e0:	f9403be0 	ldr	x0, [sp, #112]
    16e4:	9400030c 	bl	2314 <strncpy>
      shell[63] = 0;
    16e8:	f9403be0 	ldr	x0, [sp, #112]
      memset(buf, 0, sizeof(buf));
    16ec:	52804002 	mov	w2, #0x200                 	// #512
    16f0:	52800001 	mov	w1, #0x0                   	// #0
      shell[63] = 0;
    16f4:	3900fc1f 	strb	wzr, [x0, #63]
      memset(buf, 0, sizeof(buf));
    16f8:	aa1403e0 	mov	x0, x20
    16fc:	9400034c 	bl	242c <memset>
        if(packet_write(fd, payload, 1, random, transport) < 0)
    1700:	f9403fe3 	ldr	x3, [sp, #120]
        payload[0] = SSH_MSG_USERAUTH_SUCCESS;
    1704:	52800680 	mov	w0, #0x34                  	// #52
    1708:	39000260 	strb	w0, [x19]
        if(packet_write(fd, payload, 1, random, transport) < 0)
    170c:	aa1a03e4 	mov	x4, x26
    1710:	aa1303e1 	mov	x1, x19
    1714:	2a1903e0 	mov	w0, w25
    1718:	52800022 	mov	w2, #0x1                   	// #1
    171c:	97fffba7 	bl	5b8 <packet_write>
    1720:	3100041f 	cmn	w0, #0x1
    1724:	54000220 	b.eq	1768 <userauth+0x3f8>  // b.none
  if(capacity <= 0 || length >= (uint32)capacity)
    1728:	71007edf 	cmp	w22, #0x1f
    172c:	540003a8 	b.hi	17a0 <userauth+0x430>  // b.pmore
  memmove(dst, src, length);
    1730:	f94033e1 	ldr	x1, [sp, #96]
    1734:	2a1603e2 	mov	w2, w22
    1738:	aa1403e0 	mov	x0, x20
    173c:	9400038d 	bl	2570 <memmove>
  dst[length] = 0;
    1740:	38364a9f 	strb	wzr, [x20, w22, uxtw]
        printf("sshd: password authentication accepted user=%s\n", user);
    1744:	aa1403e1 	mov	x1, x20
    1748:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    174c:	912d0c00 	add	x0, x0, #0xb43
    1750:	9400058c 	bl	2d80 <printf>
        memset(user, 0, sizeof(user));
    1754:	aa1403e0 	mov	x0, x20
    1758:	52800402 	mov	w2, #0x20                  	// #32
    175c:	52800001 	mov	w1, #0x0                   	// #0
    1760:	94000333 	bl	242c <memset>
        return 0;
    1764:	52800000 	mov	w0, #0x0                   	// #0
}
    1768:	a9407bfd 	ldp	x29, x30, [sp]
    176c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1770:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1774:	a94363f7 	ldp	x23, x24, [sp, #48]
    1778:	a9446bf9 	ldp	x25, x26, [sp, #64]
    177c:	a94573fb 	ldp	x27, x28, [sp, #80]
    1780:	910c43ff 	add	sp, sp, #0x310
    1784:	d65f03c0 	ret
      uchar a = i < pass_len ? (uchar)field[1][i] : 0;
    1788:	52800002 	mov	w2, #0x0                   	// #0
    178c:	17ffffb9 	b	1670 <userauth+0x300>
      uchar b = i < password_length ? password[i] : 0;
    1790:	52800007 	mov	w7, #0x0                   	// #0
    1794:	17ffffbb 	b	1680 <userauth+0x310>
  for(line = buf; *line; line = end){
    1798:	aa1503fc 	mov	x28, x21
    179c:	17ffff64 	b	152c <userauth+0x1bc>
          strcpy(user, "<long-name>");
    17a0:	aa1403e0 	mov	x0, x20
    17a4:	90000021 	adrp	x1, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    17a8:	912cdc21 	add	x1, x1, #0xb37
    17ac:	940002d4 	bl	22fc <strcpy>
    17b0:	17ffffe5 	b	1744 <userauth+0x3d4>

00000000000017b4 <serve_connection>:
{
    17b4:	a9ac7bfd 	stp	x29, x30, [sp, #-320]!
    17b8:	910003fd 	mov	x29, sp
    17bc:	a90153f3 	stp	x19, x20, [sp, #16]
    17c0:	a9025bf5 	stp	x21, x22, [sp, #32]
    17c4:	2a0003f5 	mov	w21, w0
    17c8:	a90363f7 	stp	x23, x24, [sp, #48]
    17cc:	a9046bf9 	stp	x25, x26, [sp, #64]
    17d0:	a90573fb 	stp	x27, x28, [sp, #80]
  uint32 random = (uint32)uptime() ^ ((uint32)getpid() << 16) ^ 0x58d6a73bU;
    17d4:	940003c8 	bl	26f4 <uptime>
    17d8:	2a0003f3 	mov	w19, w0
    17dc:	940003bd 	bl	26d0 <getpid>
    17e0:	4a004260 	eor	w0, w19, w0, lsl #16
    17e4:	5294e761 	mov	w1, #0xa73b                	// #42811
    17e8:	72ab1ac1 	movk	w1, #0x58d6, lsl #16
    17ec:	4a010000 	eor	w0, w0, w1
    17f0:	b90087e0 	str	w0, [sp, #132]
  state = malloc(sizeof(*state));
    17f4:	5280bb00 	mov	w0, #0x5d8                 	// #1496
    17f8:	940005be 	bl	2ef0 <malloc>
  if(state == 0)
    17fc:	b40005c0 	cbz	x0, 18b4 <serve_connection+0x100>
  memset(state, 0, sizeof(*state));
    1800:	5280bb02 	mov	w2, #0x5d8                 	// #1496
    1804:	52800001 	mov	w1, #0x0                   	// #0
    1808:	aa0003f3 	mov	x19, x0
    180c:	94000308 	bl	242c <memset>
  if(writen(fd, server_ident_line, strlen(server_ident_line)) < 0 ||
    1810:	b0000020 	adrp	x0, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    1814:	912ba000 	add	x0, x0, #0xae8
    1818:	91001014 	add	x20, x0, #0x4
    181c:	f90033e0 	str	x0, [sp, #96]
    1820:	aa1403e0 	mov	x0, x20
    1824:	940002f2 	bl	23ec <strlen>
    1828:	aa1403e1 	mov	x1, x20
    182c:	2a0003e2 	mov	w2, w0
    1830:	2a1503e0 	mov	w0, w21
    1834:	97fffa75 	bl	208 <writen>
    1838:	3100041f 	cmn	w0, #0x1
    183c:	54000140 	b.eq	1864 <serve_connection+0xb0>  // b.none
     read_identification(fd, state->client_ident,
    1840:	9107e278 	add	x24, x19, #0x1f8
      if(readn(fd, &ch, 1) < 0)
    1844:	9103a3fb 	add	x27, sp, #0xe8
     read_identification(fd, state->client_ident,
    1848:	52800216 	mov	w22, #0x10                  	// #16
    int n = 0;
    184c:	52800014 	mov	w20, #0x0                   	// #0
    1850:	1400023e 	b	2148 <serve_connection+0x994>
      if(ch == '\n')
    1854:	2a1403e0 	mov	w0, w20
    1858:	1400024c 	b	2188 <serve_connection+0x9d4>
  for(int lines = 0; lines < 16; lines++){
    185c:	710006d6 	subs	w22, w22, #0x1
    1860:	54ffff61 	b.ne	184c <serve_connection+0x98>  // b.any
  uchar *payload = 0, *client_kexinit = 0, *server_kexinit = 0;
    1864:	d2800016 	mov	x22, #0x0                   	// #0
    1868:	d2800017 	mov	x23, #0x0                   	// #0
    186c:	d2800014 	mov	x20, #0x0                   	// #0
    printf("sshd: invalid client identification\n");
    1870:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1874:	912ea400 	add	x0, x0, #0xba9
    1878:	94000542 	bl	2d80 <printf>
    memset(state, 0, sizeof(*state));
    187c:	5280bb02 	mov	w2, #0x5d8                 	// #1496
    1880:	52800001 	mov	w1, #0x0                   	// #0
    1884:	aa1303e0 	mov	x0, x19
    1888:	940002e9 	bl	242c <memset>
    free(state);
    188c:	aa1303e0 	mov	x0, x19
    1890:	94000589 	bl	2eb4 <free>
  if(client_kexinit)
    1894:	b4000077 	cbz	x23, 18a0 <serve_connection+0xec>
    free(client_kexinit);
    1898:	aa1703e0 	mov	x0, x23
    189c:	94000586 	bl	2eb4 <free>
  if(server_kexinit)
    18a0:	b4000076 	cbz	x22, 18ac <serve_connection+0xf8>
    free(server_kexinit);
    18a4:	aa1603e0 	mov	x0, x22
    18a8:	94000583 	bl	2eb4 <free>
  free(payload);
    18ac:	aa1403e0 	mov	x0, x20
    18b0:	94000581 	bl	2eb4 <free>
}
    18b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    18b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    18bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    18c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    18c4:	a94573fb 	ldp	x27, x28, [sp, #80]
    18c8:	a8d47bfd 	ldp	x29, x30, [sp], #320
    18cc:	d65f03c0 	ret
  memmove(client_kexinit, payload, n);
    18d0:	2a1903e2 	mov	w2, w25
    18d4:	aa1403e1 	mov	x1, x20
    18d8:	aa1703e0 	mov	x0, x23
    18dc:	94000325 	bl	2570 <memmove>
  if(*offset + 4 > payload_len)
    18e0:	7100533f 	cmp	w25, #0x14
    18e4:	5400080d 	b.le	19e4 <serve_connection+0x230>
  uint32 n = get32(payload + *offset);
    18e8:	91004680 	add	x0, x20, #0x11
    18ec:	97fff9e8 	bl	8c <get32>
    18f0:	2a0003fa 	mov	w26, w0
  if(n > (uint32)(payload_len - *offset))
    18f4:	51005720 	sub	w0, w25, #0x15
    18f8:	6b00035f 	cmp	w26, w0
    18fc:	54000748 	b.hi	19e4 <serve_connection+0x230>  // b.pmore
  int copy = n < (uint32)(dst_size - 1) ? n : dst_size - 1;
    1900:	71027f5f 	cmp	w26, #0x9f
  if(copy_name_list(state->client_kex, sizeof(state->client_kex),
    1904:	910be27c 	add	x28, x19, #0x2f8
  memmove(dst, payload + *offset, copy);
    1908:	91005681 	add	x1, x20, #0x15
    190c:	aa1c03e0 	mov	x0, x28
  int copy = n < (uint32)(dst_size - 1) ? n : dst_size - 1;
    1910:	528013e2 	mov	w2, #0x9f                  	// #159
    1914:	1a829342 	csel	w2, w26, w2, ls	// ls = plast
  memmove(dst, payload + *offset, copy);
    1918:	b9006be2 	str	w2, [sp, #104]
    191c:	94000315 	bl	2570 <memmove>
  dst[copy] = 0;
    1920:	b9406be2 	ldr	w2, [sp, #104]
  if(*offset + 4 > payload_len)
    1924:	11006340 	add	w0, w26, #0x18
  dst[copy] = 0;
    1928:	38224b9f 	strb	wzr, [x28, w2, uxtw]
  if(*offset + 4 > payload_len)
    192c:	6b00033f 	cmp	w25, w0
    1930:	540005ad 	b.le	19e4 <serve_connection+0x230>
  uint32 n = get32(payload + *offset);
    1934:	11006741 	add	w1, w26, #0x19
    1938:	11005740 	add	w0, w26, #0x15
  if(n > (uint32)(payload_len - *offset))
    193c:	4b010322 	sub	w2, w25, w1
  uint32 n = get32(payload + *offset);
    1940:	8b000280 	add	x0, x20, x0
    1944:	97fff9d2 	bl	8c <get32>
  if(n > (uint32)(payload_len - *offset))
    1948:	6b02001f 	cmp	w0, w2
    194c:	540004c8 	b.hi	19e4 <serve_connection+0x230>  // b.pmore
  int copy = n < (uint32)(dst_size - 1) ? n : dst_size - 1;
    1950:	71027c1f 	cmp	w0, #0x9f
     copy_name_list(state->client_hostkey, sizeof(state->client_hostkey),
    1954:	910e627a 	add	x26, x19, #0x398
  memmove(dst, payload + *offset, copy);
    1958:	8b214281 	add	x1, x20, w1, uxtw
  int copy = n < (uint32)(dst_size - 1) ? n : dst_size - 1;
    195c:	528013e2 	mov	w2, #0x9f                  	// #159
    1960:	1a829002 	csel	w2, w0, w2, ls	// ls = plast
  memmove(dst, payload + *offset, copy);
    1964:	aa1a03e0 	mov	x0, x26
    1968:	b9006be2 	str	w2, [sp, #104]
    196c:	94000301 	bl	2570 <memmove>
  dst[copy] = 0;
    1970:	b9406be2 	ldr	w2, [sp, #104]
  printf("sshd: KEXINIT received\n");
    1974:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1978:	912fb800 	add	x0, x0, #0xbee
  dst[copy] = 0;
    197c:	38224b5f 	strb	wzr, [x26, w2, uxtw]
  printf("sshd: KEXINIT received\n");
    1980:	94000500 	bl	2d80 <printf>
  printf("sshd: client kex=%s\n", state->client_kex);
    1984:	aa1c03e1 	mov	x1, x28
    1988:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    198c:	91301800 	add	x0, x0, #0xc06
    1990:	940004fc 	bl	2d80 <printf>
  printf("sshd: client hostkey=%s\n", state->client_hostkey);
    1994:	aa1a03e1 	mov	x1, x26
    1998:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    199c:	91306c00 	add	x0, x0, #0xc1b
    19a0:	940004f8 	bl	2d80 <printf>
  n = packet_read(fd, payload, SSH_PACKET_MAX, &state->transport);
    19a4:	aa1303e2 	mov	x2, x19
    19a8:	aa1403e1 	mov	x1, x20
    19ac:	2a1503e0 	mov	w0, w21
    19b0:	97fffbb7 	bl	88c <packet_read.constprop.0>
  if(payload_len != 1 + 4 + 32 || payload[0] != SSH_MSG_KEX_ECDH_INIT ||
    19b4:	7100941f 	cmp	w0, #0x25
    19b8:	540001c0 	b.eq	19f0 <serve_connection+0x23c>  // b.none
    printf("sshd: malformed SSH_MSG_KEX_ECDH_INIT\n");
    19bc:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    19c0:	91321400 	add	x0, x0, #0xc85
    19c4:	940004ef 	bl	2d80 <printf>
    send_disconnect(fd, "invalid Curve25519 public key", &random,
    19c8:	90000021 	adrp	x1, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    19cc:	9132b021 	add	x1, x1, #0xcac
    send_disconnect(fd, "key generation failed", &random, &state->transport);
    19d0:	aa1303e3 	mov	x3, x19
    19d4:	910213e2 	add	x2, sp, #0x84
    19d8:	2a1503e0 	mov	w0, w21
    19dc:	97fffb75 	bl	7b0 <send_disconnect>
    goto out;
    19e0:	17ffffa7 	b	187c <serve_connection+0xc8>
    printf("sshd: malformed KEXINIT\n");
    19e4:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    19e8:	9130d000 	add	x0, x0, #0xc34
    19ec:	14000242 	b	22f4 <serve_connection+0xb40>
  if(payload_len != 1 + 4 + 32 || payload[0] != SSH_MSG_KEX_ECDH_INIT ||
    19f0:	39400280 	ldrb	w0, [x20]
    19f4:	7100781f 	cmp	w0, #0x1e
    19f8:	54fffe21 	b.ne	19bc <serve_connection+0x208>  // b.any
     get32(payload + 1) != 32)
    19fc:	91000680 	add	x0, x20, #0x1
    1a00:	f90037e0 	str	x0, [sp, #104]
    1a04:	97fff9a2 	bl	8c <get32>
    1a08:	2a0003fc 	mov	w28, w0
  if(payload_len != 1 + 4 + 32 || payload[0] != SSH_MSG_KEX_ECDH_INIT ||
    1a0c:	7100801f 	cmp	w0, #0x20
    1a10:	54fffd61 	b.ne	19bc <serve_connection+0x208>  // b.any
  memmove(public_key, payload + 5, 32);
    1a14:	91001680 	add	x0, x20, #0x5
    1a18:	2a1c03e2 	mov	w2, w28
    1a1c:	aa0003e1 	mov	x1, x0
    1a20:	f90037e0 	str	x0, [sp, #104]
    1a24:	9110e260 	add	x0, x19, #0x438
    1a28:	940002d2 	bl	2570 <memmove>
  printf("sshd: Curve25519 client public key received (32 bytes)\n");
    1a2c:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1a30:	91313400 	add	x0, x0, #0xc4d
    1a34:	940004d3 	bl	2d80 <printf>
  if(load_host_key(state->host_seed, state->host_public,
    1a38:	9112e27a 	add	x26, x19, #0x4b8
  int fd = open(path, O_RDONLY);
    1a3c:	f94033e0 	ldr	x0, [sp, #96]
    1a40:	52800001 	mov	w1, #0x0                   	// #0
    1a44:	91007800 	add	x0, x0, #0x1e
    1a48:	f90033e0 	str	x0, [sp, #96]
    1a4c:	94000309 	bl	2670 <open>
    1a50:	b9006be0 	str	w0, [sp, #104]
  if(fd >= 0){
    1a54:	b0000021 	adrp	x1, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    1a58:	912ba021 	add	x1, x1, #0xae8
    1a5c:	f9003fe1 	str	x1, [sp, #120]
    1a60:	36f801c0 	tbz	w0, #31, 1a98 <serve_connection+0x2e4>
    if(ssh_random(seed, 32) < 0){
    1a64:	2a1c03e1 	mov	w1, w28
    1a68:	aa1a03e0 	mov	x0, x26
    1a6c:	94000577 	bl	3048 <ssh_random>
    1a70:	36f803a0 	tbz	w0, #31, 1ae4 <serve_connection+0x330>
      printf("sshd: hardware RNG unavailable\n");
    1a74:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1a78:	9133d000 	add	x0, x0, #0xcf4
    1a7c:	940004c1 	bl	2d80 <printf>
    printf("sshd: key generation failed\n");
    1a80:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1a84:	91354400 	add	x0, x0, #0xd51
    1a88:	940004be 	bl	2d80 <printf>
    send_disconnect(fd, "key generation failed", &random, &state->transport);
    1a8c:	90000021 	adrp	x1, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1a90:	9135b821 	add	x1, x1, #0xd6e
    1a94:	17ffffcf 	b	19d0 <serve_connection+0x21c>
    int n = read(fd, seed, 32);
    1a98:	2a1c03e2 	mov	w2, w28
    1a9c:	aa1a03e1 	mov	x1, x26
    1aa0:	940002e5 	bl	2634 <read>
    1aa4:	2a0003fc 	mov	w28, w0
    int trailing = read(fd, &extra, 1);
    1aa8:	b9406be0 	ldr	w0, [sp, #104]
    1aac:	aa1b03e1 	mov	x1, x27
    1ab0:	52800022 	mov	w2, #0x1                   	// #1
    1ab4:	940002e0 	bl	2634 <read>
    1ab8:	2a0003fb 	mov	w27, w0
    close(fd);
    1abc:	b9406be0 	ldr	w0, [sp, #104]
    1ac0:	940002e3 	bl	264c <close>
    if(n != 32 || trailing != 0){
    1ac4:	7100839f 	cmp	w28, #0x20
    1ac8:	7a400b60 	ccmp	w27, #0x0, #0x0, eq	// eq = none
    1acc:	54000400 	b.eq	1b4c <serve_connection+0x398>  // b.none
      printf("sshd: invalid %s (expected 32 raw bytes)\n", path);
    1ad0:	f94033e1 	ldr	x1, [sp, #96]
    1ad4:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1ad8:	91332800 	add	x0, x0, #0xcca
      printf("sshd: cannot create %s\n", path);
    1adc:	940004a9 	bl	2d80 <printf>
      return -1;
    1ae0:	17ffffe8 	b	1a80 <serve_connection+0x2cc>
    fd = open(path, O_CREATE | O_WRONLY | O_TRUNC);
    1ae4:	f94033e0 	ldr	x0, [sp, #96]
    1ae8:	5280c021 	mov	w1, #0x601                 	// #1537
    1aec:	940002e1 	bl	2670 <open>
    1af0:	2a0003fb 	mov	w27, w0
    if(fd < 0 || writen(fd, seed, 32) < 0){
    1af4:	37f80100 	tbnz	w0, #31, 1b14 <serve_connection+0x360>
    1af8:	2a1c03e2 	mov	w2, w28
    1afc:	aa1a03e1 	mov	x1, x26
    1b00:	97fff9c2 	bl	208 <writen>
    1b04:	3100041f 	cmn	w0, #0x1
        close(fd);
    1b08:	2a1b03e0 	mov	w0, w27
    if(fd < 0 || writen(fd, seed, 32) < 0){
    1b0c:	54000161 	b.ne	1b38 <serve_connection+0x384>  // b.any
        close(fd);
    1b10:	940002cf 	bl	264c <close>
      memset(seed, 0, 32);
    1b14:	52800001 	mov	w1, #0x0                   	// #0
    1b18:	aa1a03e0 	mov	x0, x26
    1b1c:	52800402 	mov	w2, #0x20                  	// #32
    1b20:	94000243 	bl	242c <memset>
      printf("sshd: cannot create %s\n", path);
    1b24:	f9403fe1 	ldr	x1, [sp, #120]
    1b28:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1b2c:	91345000 	add	x0, x0, #0xd14
    1b30:	91007821 	add	x1, x1, #0x1e
    1b34:	17ffffea 	b	1adc <serve_connection+0x328>
    close(fd);
    1b38:	940002c5 	bl	264c <close>
    printf("sshd: generated Ed25519 host key %s\n", path);
    1b3c:	f94033e1 	ldr	x1, [sp, #96]
    1b40:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1b44:	9134b000 	add	x0, x0, #0xd2c
    1b48:	9400048e 	bl	2d80 <printf>
                   state->host_secret) < 0 ||
    1b4c:	9113e260 	add	x0, x19, #0x4f8
  if(ssh_ed25519_keypair(public_key, secret_key, seed) < 0){
    1b50:	aa1a03e2 	mov	x2, x26
    1b54:	aa0003e1 	mov	x1, x0
                   state->host_secret) < 0 ||
    1b58:	f90033e0 	str	x0, [sp, #96]
  if(ssh_ed25519_keypair(public_key, secret_key, seed) < 0){
    1b5c:	91136260 	add	x0, x19, #0x4d8
    1b60:	940006bf 	bl	365c <ssh_ed25519_keypair>
    1b64:	36f800c0 	tbz	w0, #31, 1b7c <serve_connection+0x3c8>
    memset(seed, 0, 32);
    1b68:	aa1a03e0 	mov	x0, x26
    1b6c:	52800402 	mov	w2, #0x20                  	// #32
    1b70:	52800001 	mov	w1, #0x0                   	// #0
    1b74:	9400022e 	bl	242c <memset>
    return -1;
    1b78:	17ffffc2 	b	1a80 <serve_connection+0x2cc>
     ssh_random(state->server_secret, sizeof(state->server_secret)) < 0 ||
    1b7c:	91116260 	add	x0, x19, #0x458
    1b80:	52800401 	mov	w1, #0x20                  	// #32
    1b84:	94000531 	bl	3048 <ssh_random>
                   state->host_secret) < 0 ||
    1b88:	37fff7c0 	tbnz	w0, #31, 1a80 <serve_connection+0x2cc>
     ssh_x25519_public(state->server_ephemeral, state->server_secret) < 0 ||
    1b8c:	9111e260 	add	x0, x19, #0x478
    1b90:	91116261 	add	x1, x19, #0x458
    1b94:	f90033e0 	str	x0, [sp, #96]
    1b98:	9400069c 	bl	3608 <ssh_x25519_public>
     ssh_random(state->server_secret, sizeof(state->server_secret)) < 0 ||
    1b9c:	37fff720 	tbnz	w0, #31, 1a80 <serve_connection+0x2cc>
     ssh_x25519(state->shared, state->server_secret,
    1ba0:	9110e262 	add	x2, x19, #0x438
    1ba4:	91116261 	add	x1, x19, #0x458
    1ba8:	91126260 	add	x0, x19, #0x498
    1bac:	94000698 	bl	360c <ssh_x25519>
     ssh_x25519_public(state->server_ephemeral, state->server_secret) < 0 ||
    1bb0:	37fff680 	tbnz	w0, #31, 1a80 <serve_connection+0x2cc>
  if(append_string(blob, capacity, &off, "ssh-ed25519") < 0 ||
    1bb4:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1bb8:	91361000 	add	x0, x0, #0xd84
    1bbc:	aa0003e3 	mov	x3, x0
    1bc0:	9103a3e2 	add	x2, sp, #0xe8
    1bc4:	52800801 	mov	w1, #0x40                  	// #64
    1bc8:	f90037e0 	str	x0, [sp, #104]
    1bcc:	9114e260 	add	x0, x19, #0x538
  int off = 0;
    1bd0:	b900ebff 	str	wzr, [sp, #232]
  if(append_string(blob, capacity, &off, "ssh-ed25519") < 0 ||
    1bd4:	97fff9c8 	bl	2f4 <append_string>
    1bd8:	3100041f 	cmn	w0, #0x1
    1bdc:	54000b00 	b.eq	1d3c <serve_connection+0x588>  // b.none
     append_blob(blob, capacity, &off, public_key, 32) < 0)
    1be0:	91136263 	add	x3, x19, #0x4d8
    1be4:	9103a3e2 	add	x2, sp, #0xe8
    1be8:	9114e260 	add	x0, x19, #0x538
    1bec:	52800404 	mov	w4, #0x20                  	// #32
    1bf0:	52800801 	mov	w1, #0x40                  	// #64
    1bf4:	97fff9df 	bl	370 <append_blob>
  if(append_string(blob, capacity, &off, "ssh-ed25519") < 0 ||
    1bf8:	3100041f 	cmn	w0, #0x1
    1bfc:	54000a00 	b.eq	1d3c <serve_connection+0x588>  // b.none
  return off;
    1c00:	b940ebe0 	ldr	w0, [sp, #232]
    1c04:	b90063e0 	str	w0, [sp, #96]
  if(host_blob_len < 0 ||
    1c08:	37f809a0 	tbnz	w0, #31, 1d3c <serve_connection+0x588>
  uchar *encoded = malloc(SSH_PACKET_MAX);
    1c0c:	52820000 	mov	w0, #0x1000                	// #4096
    1c10:	940004b8 	bl	2ef0 <malloc>
  int off = 0;
    1c14:	b900ebff 	str	wzr, [sp, #232]
  uchar *encoded = malloc(SSH_PACKET_MAX);
    1c18:	aa0003fa 	mov	x26, x0
  if(encoded == 0)
    1c1c:	b4000900 	cbz	x0, 1d3c <serve_connection+0x588>
                 strlen(client_ident)) < 0 ||
    1c20:	aa1803e0 	mov	x0, x24
    1c24:	940001f2 	bl	23ec <strlen>
  if(append_blob(encoded, SSH_PACKET_MAX, &off, client_ident,
    1c28:	aa1803e3 	mov	x3, x24
    1c2c:	2a0003e4 	mov	w4, w0
    1c30:	9103a3e2 	add	x2, sp, #0xe8
    1c34:	aa1a03e0 	mov	x0, x26
    1c38:	52820001 	mov	w1, #0x1000                	// #4096
    1c3c:	97fff9cd 	bl	370 <append_blob>
    1c40:	3100041f 	cmn	w0, #0x1
    1c44:	54000780 	b.eq	1d34 <serve_connection+0x580>  // b.none
                 strlen(server_ident)) < 0 ||
    1c48:	f9403fe0 	ldr	x0, [sp, #120]
    1c4c:	9100e018 	add	x24, x0, #0x38
    1c50:	aa1803e0 	mov	x0, x24
    1c54:	940001e6 	bl	23ec <strlen>
     append_blob(encoded, SSH_PACKET_MAX, &off, server_ident,
    1c58:	aa1803e3 	mov	x3, x24
    1c5c:	2a0003e4 	mov	w4, w0
    1c60:	9103a3e2 	add	x2, sp, #0xe8
    1c64:	aa1a03e0 	mov	x0, x26
    1c68:	52820001 	mov	w1, #0x1000                	// #4096
    1c6c:	97fff9c1 	bl	370 <append_blob>
                 strlen(client_ident)) < 0 ||
    1c70:	3100041f 	cmn	w0, #0x1
    1c74:	54000600 	b.eq	1d34 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, client_kexinit,
    1c78:	2a1903e4 	mov	w4, w25
    1c7c:	aa1703e3 	mov	x3, x23
    1c80:	9103a3e2 	add	x2, sp, #0xe8
    1c84:	aa1a03e0 	mov	x0, x26
    1c88:	52820001 	mov	w1, #0x1000                	// #4096
    1c8c:	97fff9b9 	bl	370 <append_blob>
                 strlen(server_ident)) < 0 ||
    1c90:	3100041f 	cmn	w0, #0x1
    1c94:	54000500 	b.eq	1d34 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, server_kexinit,
    1c98:	b94077e4 	ldr	w4, [sp, #116]
    1c9c:	aa1603e3 	mov	x3, x22
    1ca0:	9103a3e2 	add	x2, sp, #0xe8
    1ca4:	aa1a03e0 	mov	x0, x26
    1ca8:	52820001 	mov	w1, #0x1000                	// #4096
    1cac:	97fff9b1 	bl	370 <append_blob>
                 client_kexinit_len) < 0 ||
    1cb0:	3100041f 	cmn	w0, #0x1
    1cb4:	54000400 	b.eq	1d34 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, host_blob, host_blob_len) < 0 ||
    1cb8:	b94063e4 	ldr	w4, [sp, #96]
    1cbc:	9114e263 	add	x3, x19, #0x538
    1cc0:	9103a3e2 	add	x2, sp, #0xe8
    1cc4:	aa1a03e0 	mov	x0, x26
    1cc8:	52820001 	mov	w1, #0x1000                	// #4096
    1ccc:	97fff9a9 	bl	370 <append_blob>
                 server_kexinit_len) < 0 ||
    1cd0:	3100041f 	cmn	w0, #0x1
    1cd4:	54000300 	b.eq	1d34 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, client_ephemeral, 32) < 0 ||
    1cd8:	9110e263 	add	x3, x19, #0x438
    1cdc:	9103a3e2 	add	x2, sp, #0xe8
    1ce0:	aa1a03e0 	mov	x0, x26
    1ce4:	52800404 	mov	w4, #0x20                  	// #32
    1ce8:	52820001 	mov	w1, #0x1000                	// #4096
    1cec:	97fff9a1 	bl	370 <append_blob>
     append_blob(encoded, SSH_PACKET_MAX, &off, host_blob, host_blob_len) < 0 ||
    1cf0:	3100041f 	cmn	w0, #0x1
    1cf4:	54000200 	b.eq	1d34 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, server_ephemeral, 32) < 0 ||
    1cf8:	9111e263 	add	x3, x19, #0x478
    1cfc:	9103a3e2 	add	x2, sp, #0xe8
    1d00:	aa1a03e0 	mov	x0, x26
    1d04:	52800404 	mov	w4, #0x20                  	// #32
    1d08:	52820001 	mov	w1, #0x1000                	// #4096
    1d0c:	97fff999 	bl	370 <append_blob>
     append_blob(encoded, SSH_PACKET_MAX, &off, client_ephemeral, 32) < 0 ||
    1d10:	3100041f 	cmn	w0, #0x1
    1d14:	54000100 	b.eq	1d34 <serve_connection+0x580>  // b.none
     append_shared_secret_mpint(encoded, SSH_PACKET_MAX, &off, shared) < 0){
    1d18:	91126263 	add	x3, x19, #0x498
    1d1c:	9103a3e2 	add	x2, sp, #0xe8
    1d20:	aa1a03e0 	mov	x0, x26
    1d24:	52820001 	mov	w1, #0x1000                	// #4096
    1d28:	97fff9a7 	bl	3c4 <append_shared_secret_mpint>
     append_blob(encoded, SSH_PACKET_MAX, &off, server_ephemeral, 32) < 0 ||
    1d2c:	3100041f 	cmn	w0, #0x1
    1d30:	54000121 	b.ne	1d54 <serve_connection+0x5a0>  // b.any
    free(encoded);
    1d34:	aa1a03e0 	mov	x0, x26
    1d38:	9400045f 	bl	2eb4 <free>
    printf("sshd: exchange hash/signature failed\n");
    1d3c:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1d40:	91364000 	add	x0, x0, #0xd90
    1d44:	9400040f 	bl	2d80 <printf>
    send_disconnect(fd, "key exchange signing failed", &random,
    1d48:	90000021 	adrp	x1, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1d4c:	9136d821 	add	x1, x1, #0xdb6
    1d50:	17ffff20 	b	19d0 <serve_connection+0x21c>
  int result = ssh_sha256(hash, encoded, off);
    1d54:	b980ebe2 	ldrsw	x2, [sp, #232]
    1d58:	aa1a03e1 	mov	x1, x26
    1d5c:	9115e260 	add	x0, x19, #0x578
    1d60:	940004c6 	bl	3078 <ssh_sha256>
    1d64:	2a0003f9 	mov	w25, w0
  memset(encoded, 0, SSH_PACKET_MAX);
    1d68:	52820002 	mov	w2, #0x1000                	// #4096
    1d6c:	52800001 	mov	w1, #0x0                   	// #0
    1d70:	aa1a03e0 	mov	x0, x26
    1d74:	940001ae 	bl	242c <memset>
  free(encoded);
    1d78:	aa1a03e0 	mov	x0, x26
    1d7c:	9400044e 	bl	2eb4 <free>
  if(host_blob_len < 0 ||
    1d80:	37fffdf9 	tbnz	w25, #31, 1d3c <serve_connection+0x588>
     ssh_ed25519_sign(state->signature, state->hash,
    1d84:	9113e263 	add	x3, x19, #0x4f8
    1d88:	9115e261 	add	x1, x19, #0x578
    1d8c:	91166260 	add	x0, x19, #0x598
    1d90:	d2800402 	mov	x2, #0x20                  	// #32
    1d94:	94000633 	bl	3660 <ssh_ed25519_sign>
                         state->server_ephemeral, state->shared) < 0 ||
    1d98:	37fffd20 	tbnz	w0, #31, 1d3c <serve_connection+0x588>
  if(append_string(signature_blob, sizeof(signature_blob), &signature_len,
    1d9c:	f94037e3 	ldr	x3, [sp, #104]
    1da0:	910263e2 	add	x2, sp, #0x98
    1da4:	9103a3e0 	add	x0, sp, #0xe8
    1da8:	52800a61 	mov	w1, #0x53                  	// #83
  int signature_len = 0, off = 0;
    1dac:	b9009bff 	str	wzr, [sp, #152]
  if(append_string(signature_blob, sizeof(signature_blob), &signature_len,
    1db0:	97fff951 	bl	2f4 <append_string>
    1db4:	3100041f 	cmn	w0, #0x1
    1db8:	54ffd620 	b.eq	187c <serve_connection+0xc8>  // b.none
     append_blob(signature_blob, sizeof(signature_blob), &signature_len,
    1dbc:	91166263 	add	x3, x19, #0x598
    1dc0:	910263e2 	add	x2, sp, #0x98
    1dc4:	9103a3e0 	add	x0, sp, #0xe8
    1dc8:	52800804 	mov	w4, #0x40                  	// #64
    1dcc:	52800a61 	mov	w1, #0x53                  	// #83
    1dd0:	97fff968 	bl	370 <append_blob>
                   "ssh-ed25519") < 0 ||
    1dd4:	3100041f 	cmn	w0, #0x1
    1dd8:	54ffd520 	b.eq	187c <serve_connection+0xc8>  // b.none
  if(append_blob(reply, capacity, &off, host_blob, host_blob_len) < 0 ||
    1ddc:	b94063e4 	ldr	w4, [sp, #96]
  reply[off++] = SSH_MSG_KEX_ECDH_REPLY;
    1de0:	52800020 	mov	w0, #0x1                   	// #1
    1de4:	b900abe0 	str	w0, [sp, #168]
    1de8:	528003e0 	mov	w0, #0x1f                  	// #31
    1dec:	39000280 	strb	w0, [x20]
  if(append_blob(reply, capacity, &off, host_blob, host_blob_len) < 0 ||
    1df0:	9114e263 	add	x3, x19, #0x538
    1df4:	9102a3e2 	add	x2, sp, #0xa8
    1df8:	aa1403e0 	mov	x0, x20
    1dfc:	52820001 	mov	w1, #0x1000                	// #4096
    1e00:	97fff95c 	bl	370 <append_blob>
    1e04:	3100041f 	cmn	w0, #0x1
    1e08:	54ffd3a0 	b.eq	187c <serve_connection+0xc8>  // b.none
     append_blob(reply, capacity, &off, server_ephemeral, 32) < 0 ||
    1e0c:	9111e263 	add	x3, x19, #0x478
    1e10:	9102a3e2 	add	x2, sp, #0xa8
    1e14:	aa1403e0 	mov	x0, x20
    1e18:	52800404 	mov	w4, #0x20                  	// #32
    1e1c:	52820001 	mov	w1, #0x1000                	// #4096
    1e20:	97fff954 	bl	370 <append_blob>
  if(append_blob(reply, capacity, &off, host_blob, host_blob_len) < 0 ||
    1e24:	3100041f 	cmn	w0, #0x1
    1e28:	54ffd2a0 	b.eq	187c <serve_connection+0xc8>  // b.none
     append_blob(reply, capacity, &off, signature_blob, signature_len) < 0)
    1e2c:	b9409be4 	ldr	w4, [sp, #152]
    1e30:	9103a3e3 	add	x3, sp, #0xe8
    1e34:	9102a3e2 	add	x2, sp, #0xa8
    1e38:	aa1403e0 	mov	x0, x20
    1e3c:	52820001 	mov	w1, #0x1000                	// #4096
    1e40:	97fff94c 	bl	370 <append_blob>
     append_blob(reply, capacity, &off, server_ephemeral, 32) < 0 ||
    1e44:	3100041f 	cmn	w0, #0x1
    1e48:	54ffd1a0 	b.eq	187c <serve_connection+0xc8>  // b.none
  return off;
    1e4c:	b940abe2 	ldr	w2, [sp, #168]
  if(reply_len < 0 ||
    1e50:	37ffd162 	tbnz	w2, #31, 187c <serve_connection+0xc8>
     packet_write(fd, payload, reply_len, &random, &state->transport) < 0)
    1e54:	aa1303e4 	mov	x4, x19
    1e58:	910213e3 	add	x3, sp, #0x84
    1e5c:	aa1403e1 	mov	x1, x20
    1e60:	2a1503e0 	mov	w0, w21
    1e64:	97fff9d5 	bl	5b8 <packet_write>
  if(reply_len < 0 ||
    1e68:	3100041f 	cmn	w0, #0x1
    1e6c:	54ffd080 	b.eq	187c <serve_connection+0xc8>  // b.none
  printf("sshd: sent SSH_MSG_KEX_ECDH_REPLY type=31\n");
    1e70:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1e74:	91374800 	add	x0, x0, #0xdd2
    1e78:	940003c2 	bl	2d80 <printf>
  if(derive_key(client_iv, 16, shared, hash, 'A', hash) < 0 ||
    1e7c:	9115e265 	add	x5, x19, #0x578
    1e80:	9115e263 	add	x3, x19, #0x578
    1e84:	91126262 	add	x2, x19, #0x498
    1e88:	910223e0 	add	x0, sp, #0x88
    1e8c:	52800824 	mov	w4, #0x41                  	// #65
    1e90:	52800201 	mov	w1, #0x10                  	// #16
    1e94:	97fff988 	bl	4b4 <derive_key>
    1e98:	3100041f 	cmn	w0, #0x1
    1e9c:	54ffcf00 	b.eq	187c <serve_connection+0xc8>  // b.none
     derive_key(server_iv, 16, shared, hash, 'B', hash) < 0 ||
    1ea0:	9115e265 	add	x5, x19, #0x578
    1ea4:	9115e263 	add	x3, x19, #0x578
    1ea8:	91126262 	add	x2, x19, #0x498
    1eac:	910263e0 	add	x0, sp, #0x98
    1eb0:	52800844 	mov	w4, #0x42                  	// #66
    1eb4:	52800201 	mov	w1, #0x10                  	// #16
    1eb8:	97fff97f 	bl	4b4 <derive_key>
  if(derive_key(client_iv, 16, shared, hash, 'A', hash) < 0 ||
    1ebc:	3100041f 	cmn	w0, #0x1
    1ec0:	54ffcde0 	b.eq	187c <serve_connection+0xc8>  // b.none
     derive_key(client_key, 16, shared, hash, 'C', hash) < 0 ||
    1ec4:	9115e265 	add	x5, x19, #0x578
    1ec8:	9115e263 	add	x3, x19, #0x578
    1ecc:	91126262 	add	x2, x19, #0x498
    1ed0:	9102a3e0 	add	x0, sp, #0xa8
    1ed4:	52800864 	mov	w4, #0x43                  	// #67
    1ed8:	52800201 	mov	w1, #0x10                  	// #16
    1edc:	97fff976 	bl	4b4 <derive_key>
     derive_key(server_iv, 16, shared, hash, 'B', hash) < 0 ||
    1ee0:	3100041f 	cmn	w0, #0x1
    1ee4:	54ffccc0 	b.eq	187c <serve_connection+0xc8>  // b.none
     derive_key(server_key, 16, shared, hash, 'D', hash) < 0 ||
    1ee8:	9115e265 	add	x5, x19, #0x578
    1eec:	9115e263 	add	x3, x19, #0x578
    1ef0:	91126262 	add	x2, x19, #0x498
    1ef4:	9103a3e0 	add	x0, sp, #0xe8
    1ef8:	52800884 	mov	w4, #0x44                  	// #68
    1efc:	52800201 	mov	w1, #0x10                  	// #16
    1f00:	97fff96d 	bl	4b4 <derive_key>
     derive_key(client_key, 16, shared, hash, 'C', hash) < 0 ||
    1f04:	3100041f 	cmn	w0, #0x1
    1f08:	54ffcba0 	b.eq	187c <serve_connection+0xc8>  // b.none
     derive_key(transport->mac_in, 32, shared, hash, 'E', hash) < 0 ||
    1f0c:	9115e265 	add	x5, x19, #0x578
    1f10:	9115e263 	add	x3, x19, #0x578
    1f14:	91126262 	add	x2, x19, #0x498
    1f18:	91076260 	add	x0, x19, #0x1d8
    1f1c:	528008a4 	mov	w4, #0x45                  	// #69
    1f20:	52800401 	mov	w1, #0x20                  	// #32
    1f24:	97fff964 	bl	4b4 <derive_key>
     derive_key(server_key, 16, shared, hash, 'D', hash) < 0 ||
    1f28:	3100041f 	cmn	w0, #0x1
    1f2c:	54ffca80 	b.eq	187c <serve_connection+0xc8>  // b.none
     derive_key(transport->mac_out, 32, shared, hash, 'F', hash) < 0)
    1f30:	9115e265 	add	x5, x19, #0x578
    1f34:	91126262 	add	x2, x19, #0x498
    1f38:	aa0503e3 	mov	x3, x5
    1f3c:	9106e260 	add	x0, x19, #0x1b8
    1f40:	528008c4 	mov	w4, #0x46                  	// #70
    1f44:	52800401 	mov	w1, #0x20                  	// #32
    1f48:	97fff95b 	bl	4b4 <derive_key>
     derive_key(transport->mac_in, 32, shared, hash, 'E', hash) < 0 ||
    1f4c:	3100041f 	cmn	w0, #0x1
    1f50:	54ffc960 	b.eq	187c <serve_connection+0xc8>  // b.none
  ssh_aes128_ctr_init(&transport->cipher_in, client_key, client_iv);
    1f54:	910223e2 	add	x2, sp, #0x88
    1f58:	9102a3e1 	add	x1, sp, #0xa8
    1f5c:	91039260 	add	x0, x19, #0xe4
    1f60:	94000641 	bl	3864 <ssh_aes128_ctr_init>
  ssh_aes128_ctr_init(&transport->cipher_out, server_key, server_iv);
    1f64:	910263e2 	add	x2, sp, #0x98
    1f68:	9103a3e1 	add	x1, sp, #0xe8
    1f6c:	91004260 	add	x0, x19, #0x10
    1f70:	9400063d 	bl	3864 <ssh_aes128_ctr_init>
  memset(client_iv, 0, sizeof(client_iv));
    1f74:	52800202 	mov	w2, #0x10                  	// #16
    1f78:	52800001 	mov	w1, #0x0                   	// #0
    1f7c:	910223e0 	add	x0, sp, #0x88
    1f80:	9400012b 	bl	242c <memset>
  memset(server_iv, 0, sizeof(server_iv));
    1f84:	52800202 	mov	w2, #0x10                  	// #16
    1f88:	52800001 	mov	w1, #0x0                   	// #0
    1f8c:	910263e0 	add	x0, sp, #0x98
    1f90:	94000127 	bl	242c <memset>
  memset(client_key, 0, sizeof(client_key));
    1f94:	52800202 	mov	w2, #0x10                  	// #16
    1f98:	52800001 	mov	w1, #0x0                   	// #0
    1f9c:	9102a3e0 	add	x0, sp, #0xa8
    1fa0:	94000123 	bl	242c <memset>
  memset(server_key, 0, sizeof(server_key));
    1fa4:	52800202 	mov	w2, #0x10                  	// #16
    1fa8:	52800001 	mov	w1, #0x0                   	// #0
    1fac:	9103a3e0 	add	x0, sp, #0xe8
    1fb0:	9400011f 	bl	242c <memset>
  payload[0] = SSH_MSG_NEWKEYS;
    1fb4:	528002a0 	mov	w0, #0x15                  	// #21
    1fb8:	39000280 	strb	w0, [x20]
  if(packet_write(fd, payload, 1, &random, &state->transport) < 0)
    1fbc:	aa1303e4 	mov	x4, x19
    1fc0:	910213e3 	add	x3, sp, #0x84
    1fc4:	aa1403e1 	mov	x1, x20
    1fc8:	2a1503e0 	mov	w0, w21
    1fcc:	52800022 	mov	w2, #0x1                   	// #1
    1fd0:	97fff97a 	bl	5b8 <packet_write>
    1fd4:	3100041f 	cmn	w0, #0x1
    1fd8:	54ffc520 	b.eq	187c <serve_connection+0xc8>  // b.none
  state->transport.encrypt_out = 1;
    1fdc:	52800020 	mov	w0, #0x1                   	// #1
    1fe0:	b9000a60 	str	w0, [x19, #8]
  printf("sshd: sent SSH_MSG_NEWKEYS; outbound encryption active\n");
    1fe4:	90000020 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    1fe8:	9137f400 	add	x0, x0, #0xdfd
    1fec:	94000365 	bl	2d80 <printf>
  n = packet_read(fd, payload, SSH_PACKET_MAX, &state->transport);
    1ff0:	aa1303e2 	mov	x2, x19
    1ff4:	aa1403e1 	mov	x1, x20
    1ff8:	2a1503e0 	mov	w0, w21
    1ffc:	97fffa24 	bl	88c <packet_read.constprop.0>
  if(n != 1 || payload[0] != SSH_MSG_NEWKEYS){
    2000:	7100041f 	cmp	w0, #0x1
    2004:	54000081 	b.ne	2014 <serve_connection+0x860>  // b.any
    2008:	39400281 	ldrb	w1, [x20]
    200c:	7100543f 	cmp	w1, #0x15
    2010:	54000080 	b.eq	2020 <serve_connection+0x86c>  // b.none
    printf("sshd: expected SSH_MSG_NEWKEYS\n");
    2014:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    2018:	9138d400 	add	x0, x0, #0xe35
    201c:	140000b6 	b	22f4 <serve_connection+0xb40>
  state->transport.encrypt_in = 1;
    2020:	b9000e60 	str	w0, [x19, #12]
  printf("sshd: received SSH_MSG_NEWKEYS; inbound encryption active\n");
    2024:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    2028:	91395400 	add	x0, x0, #0xe55
    202c:	94000355 	bl	2d80 <printf>
  n = packet_read(fd, payload, SSH_PACKET_MAX, &state->transport);
    2030:	aa1303e2 	mov	x2, x19
    2034:	aa1403e1 	mov	x1, x20
    2038:	2a1503e0 	mov	w0, w21
    203c:	97fffa14 	bl	88c <packet_read.constprop.0>
    2040:	2a0003f8 	mov	w24, w0
  if(n != 17 || payload[0] != SSH_MSG_SERVICE_REQUEST ||
    2044:	7100441f 	cmp	w0, #0x11
    2048:	540001c1 	b.ne	2080 <serve_connection+0x8cc>  // b.any
    204c:	39400280 	ldrb	w0, [x20]
    2050:	7100141f 	cmp	w0, #0x5
    2054:	54000161 	b.ne	2080 <serve_connection+0x8cc>  // b.any
     get32(payload + 1) != 12 ||
    2058:	91000680 	add	x0, x20, #0x1
    205c:	97fff80c 	bl	8c <get32>
  if(n != 17 || payload[0] != SSH_MSG_SERVICE_REQUEST ||
    2060:	7100301f 	cmp	w0, #0xc
    2064:	540000e1 	b.ne	2080 <serve_connection+0x8cc>  // b.any
     memcmp(payload + 5, "ssh-userauth", 12) != 0){
    2068:	2a0003e2 	mov	w2, w0
    206c:	f0000001 	adrp	x1, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    2070:	913a4021 	add	x1, x1, #0xe90
    2074:	91001680 	add	x0, x20, #0x5
    2078:	94000154 	bl	25c8 <memcmp>
     get32(payload + 1) != 12 ||
    207c:	34000080 	cbz	w0, 208c <serve_connection+0x8d8>
    printf("sshd: expected encrypted SSH_MSG_SERVICE_REQUEST\n");
    2080:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    2084:	913a7400 	add	x0, x0, #0xe9d
    2088:	1400009b 	b	22f4 <serve_connection+0xb40>
  payload[0] = SSH_MSG_SERVICE_ACCEPT;
    208c:	528000c0 	mov	w0, #0x6                   	// #6
    2090:	39000280 	strb	w0, [x20]
  if(packet_write(fd, payload, n, &random, &state->transport) < 0)
    2094:	aa1303e4 	mov	x4, x19
    2098:	910213e3 	add	x3, sp, #0x84
    209c:	2a1803e2 	mov	w2, w24
    20a0:	aa1403e1 	mov	x1, x20
    20a4:	2a1503e0 	mov	w0, w21
    20a8:	97fff944 	bl	5b8 <packet_write>
    20ac:	3100041f 	cmn	w0, #0x1
    20b0:	54ffbe60 	b.eq	187c <serve_connection+0xc8>  // b.none
  printf("sshd: encrypted transport ready; service accepted\n");
    20b4:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    20b8:	913b3c00 	add	x0, x0, #0xecf
    20bc:	94000331 	bl	2d80 <printf>
  memset(home, 0, sizeof(home));
    20c0:	52800802 	mov	w2, #0x40                  	// #64
    20c4:	52800001 	mov	w1, #0x0                   	// #0
    20c8:	9102a3e0 	add	x0, sp, #0xa8
    20cc:	940000d8 	bl	242c <memset>
  memset(shell, 0, sizeof(shell));
    20d0:	52800802 	mov	w2, #0x40                  	// #64
    20d4:	52800001 	mov	w1, #0x0                   	// #0
    20d8:	9103a3e0 	add	x0, sp, #0xe8
    20dc:	940000d4 	bl	242c <memset>
  if(userauth(fd, payload, &random, &state->transport, home, shell) < 0){
    20e0:	9103a3e5 	add	x5, sp, #0xe8
    20e4:	9102a3e4 	add	x4, sp, #0xa8
    20e8:	aa1303e3 	mov	x3, x19
    20ec:	910213e2 	add	x2, sp, #0x84
    20f0:	aa1403e1 	mov	x1, x20
    20f4:	2a1503e0 	mov	w0, w21
    20f8:	97fffc9e 	bl	1370 <userauth>
    20fc:	3100041f 	cmn	w0, #0x1
    2100:	54000081 	b.ne	2110 <serve_connection+0x95c>  // b.any
    printf("sshd: authentication failed\n");
    2104:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    2108:	913c0800 	add	x0, x0, #0xf02
    210c:	1400007a 	b	22f4 <serve_connection+0xb40>
  if(channel_session(fd, payload, &random, &state->transport,
    2110:	9103a3e5 	add	x5, sp, #0xe8
    2114:	9102a3e4 	add	x4, sp, #0xa8
    2118:	aa1303e3 	mov	x3, x19
    211c:	910213e2 	add	x2, sp, #0x84
    2120:	aa1403e1 	mov	x1, x20
    2124:	2a1503e0 	mov	w0, w21
    2128:	97fffa6e 	bl	ae0 <channel_session>
    212c:	3100041f 	cmn	w0, #0x1
    2130:	54ffba61 	b.ne	187c <serve_connection+0xc8>  // b.any
    printf("sshd: channel ended with protocol/I/O error\n");
    2134:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    2138:	913c7c00 	add	x0, x0, #0xf1f
    213c:	1400006e 	b	22f4 <serve_connection+0xb40>
      if(ch != '\r'){
    2140:	2a1403e0 	mov	w0, w20
    2144:	2a0003f4 	mov	w20, w0
      if(readn(fd, &ch, 1) < 0)
    2148:	aa1b03e1 	mov	x1, x27
    214c:	2a1503e0 	mov	w0, w21
    2150:	52800022 	mov	w2, #0x1                   	// #1
    2154:	97fff846 	bl	26c <readn>
    2158:	3100041f 	cmn	w0, #0x1
    215c:	54ffb840 	b.eq	1864 <serve_connection+0xb0>  // b.none
      if(ch == 0)
    2160:	3943a3e1 	ldrb	w1, [sp, #232]
    2164:	34ffb801 	cbz	w1, 1864 <serve_connection+0xb0>
      if(ch == '\n')
    2168:	7100283f 	cmp	w1, #0xa
    216c:	54ffb740 	b.eq	1854 <serve_connection+0xa0>  // b.none
      if(ch != '\r'){
    2170:	7100343f 	cmp	w1, #0xd
    2174:	54fffe60 	b.eq	2140 <serve_connection+0x98c>  // b.none
        ident[n++] = ch;
    2178:	38344b01 	strb	w1, [x24, w20, uxtw]
        if(n + 1 >= size)
    217c:	11000680 	add	w0, w20, #0x1
    while(n < 255){
    2180:	7103fa9f 	cmp	w20, #0xfe
    2184:	54fffe01 	b.ne	2144 <serve_connection+0x990>  // b.any
  while(*prefix)
    2188:	f0000001 	adrp	x1, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    218c:	912e6c21 	add	x1, x1, #0xb9b
    ident[n] = 0;
    2190:	38204b1f 	strb	wzr, [x24, w0, uxtw]
    2194:	d2800000 	mov	x0, #0x0                   	// #0
    if(*s++ != *prefix++)
    2198:	38606b03 	ldrb	w3, [x24, x0]
    219c:	38606822 	ldrb	w2, [x1, x0]
    21a0:	6b02007f 	cmp	w3, w2
    21a4:	54ffb5c1 	b.ne	185c <serve_connection+0xa8>  // b.any
    21a8:	91000400 	add	x0, x0, #0x1
  while(*prefix)
    21ac:	f100101f 	cmp	x0, #0x4
    21b0:	54ffff41 	b.ne	2198 <serve_connection+0x9e4>  // b.any
    21b4:	f0000001 	adrp	x1, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    21b8:	912e8021 	add	x1, x1, #0xba0
    21bc:	d2800000 	mov	x0, #0x0                   	// #0
    if(*s++ != *prefix++)
    21c0:	38606b03 	ldrb	w3, [x24, x0]
    21c4:	38606822 	ldrb	w2, [x1, x0]
    21c8:	6b02007f 	cmp	w3, w2
    21cc:	54ffb4c1 	b.ne	1864 <serve_connection+0xb0>  // b.any
    21d0:	91000400 	add	x0, x0, #0x1
  while(*prefix)
    21d4:	f100201f 	cmp	x0, #0x8
    21d8:	54ffff41 	b.ne	21c0 <serve_connection+0xa0c>  // b.any
  printf("sshd: client %s\n", state->client_ident);
    21dc:	aa1803e1 	mov	x1, x24
    21e0:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    21e4:	913d3000 	add	x0, x0, #0xf4c
    21e8:	940002e6 	bl	2d80 <printf>
  payload = malloc(SSH_PACKET_MAX);
    21ec:	52820000 	mov	w0, #0x1000                	// #4096
    21f0:	94000340 	bl	2ef0 <malloc>
    21f4:	aa0003f4 	mov	x20, x0
  client_kexinit = malloc(SSH_PACKET_MAX);
    21f8:	52820000 	mov	w0, #0x1000                	// #4096
    21fc:	9400033d 	bl	2ef0 <malloc>
    2200:	aa0003f7 	mov	x23, x0
  server_kexinit = malloc(SSH_PACKET_MAX);
    2204:	52820000 	mov	w0, #0x1000                	// #4096
    2208:	9400033a 	bl	2ef0 <malloc>
    220c:	aa0003f6 	mov	x22, x0
  if(payload == 0 || client_kexinit == 0 || server_kexinit == 0)
    2210:	f100029f 	cmp	x20, #0x0
    2214:	fa401ae4 	ccmp	x23, #0x0, #0x4, ne	// ne = any
    2218:	54ffb320 	b.eq	187c <serve_connection+0xc8>  // b.none
    221c:	b4ffb316 	cbz	x22, 187c <serve_connection+0xc8>
  p[off++] = SSH_MSG_KEXINIT;
    2220:	aa1603e0 	mov	x0, x22
    2224:	52800281 	mov	w1, #0x14                  	// #20
    2228:	38001401 	strb	w1, [x0], #1
  if(ssh_random(p + off, 16) < 0)
    222c:	52800201 	mov	w1, #0x10                  	// #16
    2230:	94000386 	bl	3048 <ssh_random>
    2234:	37ffb240 	tbnz	w0, #31, 187c <serve_connection+0xc8>
  off += 16;
    2238:	52800220 	mov	w0, #0x11                  	// #17
  char *lists[] = {
    223c:	f0000001 	adrp	x1, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    2240:	913fc021 	add	x1, x1, #0xff0
    2244:	d2800a02 	mov	x2, #0x50                  	// #80
    2248:	d2800019 	mov	x25, #0x0                   	// #0
  off += 16;
    224c:	b900abe0 	str	w0, [sp, #168]
  char *lists[] = {
    2250:	aa1b03e0 	mov	x0, x27
    2254:	940000eb 	bl	2600 <memcpy>
    if(append_string(p, capacity, &off, lists[i]) < 0)
    2258:	f8797b63 	ldr	x3, [x27, x25, lsl #3]
    225c:	9102a3e2 	add	x2, sp, #0xa8
    2260:	aa1603e0 	mov	x0, x22
    2264:	52820001 	mov	w1, #0x1000                	// #4096
    2268:	97fff823 	bl	2f4 <append_string>
    226c:	3100041f 	cmn	w0, #0x1
    2270:	54ffb060 	b.eq	187c <serve_connection+0xc8>  // b.none
  for(int i = 0; i < 10; i++)
    2274:	91000739 	add	x25, x25, #0x1
    2278:	f1002b3f 	cmp	x25, #0xa
    227c:	54fffee1 	b.ne	2258 <serve_connection+0xaa4>  // b.any
  if(off + 5 > capacity)
    2280:	b940abe0 	ldr	w0, [sp, #168]
    2284:	713fec1f 	cmp	w0, #0xffb
    2288:	54ffafac 	b.gt	187c <serve_connection+0xc8>
  p[off++] = 0;                 // first_kex_packet_follows = false
    228c:	11000401 	add	w1, w0, #0x1
    2290:	3820cadf 	strb	wzr, [x22, w0, sxtw]
  if(server_kexinit_len < 0 ||
    2294:	31001400 	adds	w0, w0, #0x5
    2298:	b90077e0 	str	w0, [sp, #116]
  p[0] = v >> 24;
    229c:	b821cadf 	str	wzr, [x22, w1, sxtw]
  if(server_kexinit_len < 0 ||
    22a0:	54ffaee4 	b.mi	187c <serve_connection+0xc8>  // b.first
     packet_write(fd, server_kexinit, server_kexinit_len, &random,
    22a4:	2a0003e2 	mov	w2, w0
    22a8:	aa1303e4 	mov	x4, x19
    22ac:	910213e3 	add	x3, sp, #0x84
    22b0:	aa1603e1 	mov	x1, x22
    22b4:	2a1503e0 	mov	w0, w21
    22b8:	97fff8c0 	bl	5b8 <packet_write>
  if(server_kexinit_len < 0 ||
    22bc:	3100041f 	cmn	w0, #0x1
    22c0:	54ffade0 	b.eq	187c <serve_connection+0xc8>  // b.none
  n = packet_read(fd, payload, SSH_PACKET_MAX, &state->transport);
    22c4:	aa1303e2 	mov	x2, x19
    22c8:	aa1403e1 	mov	x1, x20
    22cc:	2a1503e0 	mov	w0, w21
    22d0:	97fff96f 	bl	88c <packet_read.constprop.0>
    22d4:	2a0003f9 	mov	w25, w0
  if(n < 0 || payload[0] != SSH_MSG_KEXINIT){
    22d8:	3100041f 	cmn	w0, #0x1
    22dc:	54000080 	b.eq	22ec <serve_connection+0xb38>  // b.none
    22e0:	39400280 	ldrb	w0, [x20]
    22e4:	7100501f 	cmp	w0, #0x14
    22e8:	54ffaf40 	b.eq	18d0 <serve_connection+0x11c>  // b.none
    printf("sshd: expected SSH_MSG_KEXINIT\n");
    22ec:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    22f0:	912f3800 	add	x0, x0, #0xbce
    printf("sshd: channel ended with protocol/I/O error\n");
    22f4:	940002a3 	bl	2d80 <printf>
    22f8:	17fffd61 	b	187c <serve_connection+0xc8>

00000000000022fc <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
    22fc:	d2800002 	mov	x2, #0x0                   	// #0
    2300:	38626823 	ldrb	w3, [x1, x2]
    2304:	38226803 	strb	w3, [x0, x2]
    2308:	91000442 	add	x2, x2, #0x1
    230c:	35ffffa3 	cbnz	w3, 2300 <strcpy+0x4>
    ;
  return os;
}
    2310:	d65f03c0 	ret

0000000000002314 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
    2314:	d2800003 	mov	x3, #0x0                   	// #0
    2318:	4b030044 	sub	w4, w2, w3
    231c:	7100009f 	cmp	w4, #0x0
    2320:	5400006d 	b.le	232c <strncpy+0x18>
    2324:	38636825 	ldrb	w5, [x1, x3]
    2328:	350000e5 	cbnz	w5, 2344 <strncpy+0x30>
    232c:	8b030003 	add	x3, x0, x3
    2330:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
    2334:	4b010082 	sub	w2, w4, w1
    2338:	7100005f 	cmp	w2, #0x0
    233c:	540000ac 	b.gt	2350 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
    2340:	d65f03c0 	ret
    *s++ = *t++;
    2344:	38236805 	strb	w5, [x0, x3]
    n--;
    2348:	91000463 	add	x3, x3, #0x1
    234c:	17fffff3 	b	2318 <strncpy+0x4>
    *s++ = 0;
    2350:	3821687f 	strb	wzr, [x3, x1]
    2354:	91000421 	add	x1, x1, #0x1
    2358:	17fffff7 	b	2334 <strncpy+0x20>

000000000000235c <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
    235c:	aa0003e2 	mov	x2, x0
    2360:	39400043 	ldrb	w3, [x2]
    2364:	aa0203e4 	mov	x4, x2
    s++;
    2368:	91000442 	add	x2, x2, #0x1
  while(*s)
    236c:	35ffffa3 	cbnz	w3, 2360 <strcat+0x4>
    2370:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
    2374:	38626823 	ldrb	w3, [x1, x2]
    2378:	38226883 	strb	w3, [x4, x2]
    237c:	91000442 	add	x2, x2, #0x1
    2380:	35ffffa3 	cbnz	w3, 2374 <strcat+0x18>
    ;
  return os;
}
    2384:	d65f03c0 	ret

0000000000002388 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
    2388:	d2800002 	mov	x2, #0x0                   	// #0
    238c:	38626803 	ldrb	w3, [x0, x2]
    2390:	38626824 	ldrb	w4, [x1, x2]
    2394:	34000083 	cbz	w3, 23a4 <strcmp+0x1c>
    2398:	91000442 	add	x2, x2, #0x1
    239c:	6b04007f 	cmp	w3, w4
    23a0:	54ffff60 	b.eq	238c <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
    23a4:	4b040060 	sub	w0, w3, w4
    23a8:	d65f03c0 	ret

00000000000023ac <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
    23ac:	340001c2 	cbz	w2, 23e4 <strncmp+0x38>
    23b0:	39400003 	ldrb	w3, [x0]
    23b4:	34000083 	cbz	w3, 23c4 <strncmp+0x18>
    23b8:	39400024 	ldrb	w4, [x1]
    23bc:	6b03009f 	cmp	w4, w3
    23c0:	540000a0 	b.eq	23d4 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
    23c4:	39400000 	ldrb	w0, [x0]
    23c8:	39400021 	ldrb	w1, [x1]
    23cc:	4b010000 	sub	w0, w0, w1
}
    23d0:	d65f03c0 	ret
    n--, p++, q++;
    23d4:	51000442 	sub	w2, w2, #0x1
    23d8:	91000400 	add	x0, x0, #0x1
    23dc:	91000421 	add	x1, x1, #0x1
    23e0:	17fffff3 	b	23ac <strncmp>
    return 0;
    23e4:	52800000 	mov	w0, #0x0                   	// #0
    23e8:	17fffffa 	b	23d0 <strncmp+0x24>

00000000000023ec <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
    23ec:	d1000402 	sub	x2, x0, #0x1
    23f0:	d2800001 	mov	x1, #0x0                   	// #0
    23f4:	aa0103e0 	mov	x0, x1
    23f8:	91000421 	add	x1, x1, #0x1
    23fc:	38616843 	ldrb	w3, [x2, x1]
    2400:	35ffffa3 	cbnz	w3, 23f4 <strlen+0x8>
    ;
  return n;
}
    2404:	d65f03c0 	ret

0000000000002408 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
    2408:	d1000403 	sub	x3, x0, #0x1
    240c:	d2800002 	mov	x2, #0x0                   	// #0
    2410:	2a0203e0 	mov	w0, w2
    2414:	6b02003f 	cmp	w1, w2
    2418:	54000089 	b.ls	2428 <strnlen+0x20>  // b.plast
    241c:	91000442 	add	x2, x2, #0x1
    2420:	38626864 	ldrb	w4, [x3, x2]
    2424:	35ffff64 	cbnz	w4, 2410 <strnlen+0x8>
    n++;
  return n;
}
    2428:	d65f03c0 	ret

000000000000242c <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    242c:	d2800003 	mov	x3, #0x0                   	// #0
    2430:	6b03005f 	cmp	w2, w3
    2434:	54000048 	b.hi	243c <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
    2438:	d65f03c0 	ret
    cdst[i] = c;
    243c:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
    2440:	91000463 	add	x3, x3, #0x1
    2444:	17fffffb 	b	2430 <memset+0x4>

0000000000002448 <strchr>:

char*
strchr(const char *s, char c)
{
    2448:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
    244c:	39400002 	ldrb	w2, [x0]
    2450:	35000062 	cbnz	w2, 245c <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
    2454:	d2800000 	mov	x0, #0x0                   	// #0
}
    2458:	d65f03c0 	ret
    if(*s == c)
    245c:	6b01005f 	cmp	w2, w1
    2460:	54ffffc0 	b.eq	2458 <strchr+0x10>  // b.none
  for(; *s; s++)
    2464:	91000400 	add	x0, x0, #0x1
    2468:	17fffff9 	b	244c <strchr+0x4>

000000000000246c <gets>:

char*
gets(char *buf, int max)
{
    246c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2470:	910003fd 	mov	x29, sp
    2474:	a90153f3 	stp	x19, x20, [sp, #16]
    2478:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    247c:	d2800014 	mov	x20, #0x0                   	// #0
{
    2480:	f9001bf7 	str	x23, [sp, #48]
    2484:	2a0103f7 	mov	w23, w1
    2488:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
    248c:	11000695 	add	w21, w20, #0x1
    2490:	2a1403f6 	mov	w22, w20
    2494:	6b1702bf 	cmp	w21, w23
    2498:	540000ea 	b.ge	24b4 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
    249c:	91013fe1 	add	x1, sp, #0x4f
    24a0:	52800022 	mov	w2, #0x1                   	// #1
    24a4:	52800000 	mov	w0, #0x0                   	// #0
    24a8:	94000063 	bl	2634 <read>
    if(cc < 1)
    24ac:	7100001f 	cmp	w0, #0x0
    24b0:	5400012c 	b.gt	24d4 <gets+0x68>
  for(i=0; i+1 < max; ){
    24b4:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
    24b8:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
    24bc:	aa1303e0 	mov	x0, x19
    24c0:	f9401bf7 	ldr	x23, [sp, #48]
    24c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    24c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    24cc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    24d0:	d65f03c0 	ret
    buf[i++] = c;
    24d4:	39413fe0 	ldrb	w0, [sp, #79]
    24d8:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
    24dc:	91000694 	add	x20, x20, #0x1
    24e0:	7100281f 	cmp	w0, #0xa
    24e4:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
    24e8:	54fffd21 	b.ne	248c <gets+0x20>  // b.any
    24ec:	17fffff3 	b	24b8 <gets+0x4c>

00000000000024f0 <stat>:

int
stat(const char *n, struct stat *st)
{
    24f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    24f4:	910003fd 	mov	x29, sp
    24f8:	a90153f3 	stp	x19, x20, [sp, #16]
    24fc:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    2500:	52800001 	mov	w1, #0x0                   	// #0
    2504:	9400005b 	bl	2670 <open>
  if(fd < 0)
    2508:	37f80160 	tbnz	w0, #31, 2534 <stat+0x44>
    return -1;
  r = fstat(fd, st);
    250c:	aa1303e1 	mov	x1, x19
    2510:	2a0003f4 	mov	w20, w0
    2514:	94000060 	bl	2694 <fstat>
    2518:	2a0003f3 	mov	w19, w0
  close(fd);
    251c:	2a1403e0 	mov	w0, w20
    2520:	9400004b 	bl	264c <close>
  return r;
}
    2524:	2a1303e0 	mov	w0, w19
    2528:	a94153f3 	ldp	x19, x20, [sp, #16]
    252c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2530:	d65f03c0 	ret
    return -1;
    2534:	12800013 	mov	w19, #0xffffffff            	// #-1
    2538:	17fffffb 	b	2524 <stat+0x34>

000000000000253c <atoi>:

int
atoi(const char *s)
{
    253c:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
    2540:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
    2544:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
    2548:	39400043 	ldrb	w3, [x2]
    254c:	5100c061 	sub	w1, w3, #0x30
    2550:	12001c21 	and	w1, w1, #0xff
    2554:	7100243f 	cmp	w1, #0x9
    2558:	54000049 	b.ls	2560 <atoi+0x24>  // b.plast
  return n;
}
    255c:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
    2560:	1b040c01 	madd	w1, w0, w4, w3
    2564:	91000442 	add	x2, x2, #0x1
    2568:	5100c020 	sub	w0, w1, #0x30
    256c:	17fffff7 	b	2548 <atoi+0xc>

0000000000002570 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    2570:	eb01001f 	cmp	x0, x1
    2574:	54000263 	b.cc	25c0 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
    2578:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
    257c:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
    2580:	d2800003 	mov	x3, #0x0                   	// #0
    2584:	d1000463 	sub	x3, x3, #0x1
    2588:	11000464 	add	w4, w3, #0x1
    258c:	0b020084 	add	w4, w4, w2
    2590:	7100009f 	cmp	w4, #0x0
    2594:	5400014d 	b.le	25bc <memmove+0x4c>
      *--dst = *--src;
    2598:	38636824 	ldrb	w4, [x1, x3]
    259c:	382368a4 	strb	w4, [x5, x3]
    25a0:	17fffff9 	b	2584 <memmove+0x14>
      *dst++ = *src++;
    25a4:	38636824 	ldrb	w4, [x1, x3]
    25a8:	38236804 	strb	w4, [x0, x3]
    25ac:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
    25b0:	4b030044 	sub	w4, w2, w3
    25b4:	7100009f 	cmp	w4, #0x0
    25b8:	54ffff6c 	b.gt	25a4 <memmove+0x34>
  }
  return vdst;
}
    25bc:	d65f03c0 	ret
    25c0:	d2800003 	mov	x3, #0x0                   	// #0
    25c4:	17fffffb 	b	25b0 <memmove+0x40>

00000000000025c8 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    25c8:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
    25cc:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
    25d0:	d2800004 	mov	x4, #0x0                   	// #0
    25d4:	eb02009f 	cmp	x4, x2
    25d8:	54000061 	b.ne	25e4 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
    25dc:	52800000 	mov	w0, #0x0                   	// #0
    25e0:	14000007 	b	25fc <memcmp+0x34>
    if (*p1 != *p2) {
    25e4:	38646803 	ldrb	w3, [x0, x4]
    25e8:	91000484 	add	x4, x4, #0x1
    25ec:	38646825 	ldrb	w5, [x1, x4]
    25f0:	6b05007f 	cmp	w3, w5
    25f4:	54ffff00 	b.eq	25d4 <memcmp+0xc>  // b.none
      return *p1 - *p2;
    25f8:	4b050060 	sub	w0, w3, w5
}
    25fc:	d65f03c0 	ret

0000000000002600 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
    2600:	17ffffdc 	b	2570 <memmove>

0000000000002604 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
    2604:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
    2608:	d4000001 	svc	#0x0
 ret
    260c:	d65f03c0 	ret

0000000000002610 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
    2610:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
    2614:	d4000001 	svc	#0x0
 ret
    2618:	d65f03c0 	ret

000000000000261c <wait>:
.global wait
wait:
 mov x7, #SYS_wait
    261c:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
    2620:	d4000001 	svc	#0x0
 ret
    2624:	d65f03c0 	ret

0000000000002628 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
    2628:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
    262c:	d4000001 	svc	#0x0
 ret
    2630:	d65f03c0 	ret

0000000000002634 <read>:
.global read
read:
 mov x7, #SYS_read
    2634:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
    2638:	d4000001 	svc	#0x0
 ret
    263c:	d65f03c0 	ret

0000000000002640 <write>:
.global write
write:
 mov x7, #SYS_write
    2640:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
    2644:	d4000001 	svc	#0x0
 ret
    2648:	d65f03c0 	ret

000000000000264c <close>:
.global close
close:
 mov x7, #SYS_close
    264c:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
    2650:	d4000001 	svc	#0x0
 ret
    2654:	d65f03c0 	ret

0000000000002658 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
    2658:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
    265c:	d4000001 	svc	#0x0
 ret
    2660:	d65f03c0 	ret

0000000000002664 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
    2664:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
    2668:	d4000001 	svc	#0x0
 ret
    266c:	d65f03c0 	ret

0000000000002670 <open>:
.global open
open:
 mov x7, #SYS_open
    2670:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
    2674:	d4000001 	svc	#0x0
 ret
    2678:	d65f03c0 	ret

000000000000267c <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
    267c:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
    2680:	d4000001 	svc	#0x0
 ret
    2684:	d65f03c0 	ret

0000000000002688 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
    2688:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
    268c:	d4000001 	svc	#0x0
 ret
    2690:	d65f03c0 	ret

0000000000002694 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
    2694:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
    2698:	d4000001 	svc	#0x0
 ret
    269c:	d65f03c0 	ret

00000000000026a0 <link>:
.global link
link:
 mov x7, #SYS_link
    26a0:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
    26a4:	d4000001 	svc	#0x0
 ret
    26a8:	d65f03c0 	ret

00000000000026ac <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
    26ac:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
    26b0:	d4000001 	svc	#0x0
 ret
    26b4:	d65f03c0 	ret

00000000000026b8 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
    26b8:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
    26bc:	d4000001 	svc	#0x0
 ret
    26c0:	d65f03c0 	ret

00000000000026c4 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
    26c4:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
    26c8:	d4000001 	svc	#0x0
 ret
    26cc:	d65f03c0 	ret

00000000000026d0 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
    26d0:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
    26d4:	d4000001 	svc	#0x0
 ret
    26d8:	d65f03c0 	ret

00000000000026dc <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
    26dc:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
    26e0:	d4000001 	svc	#0x0
 ret
    26e4:	d65f03c0 	ret

00000000000026e8 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
    26e8:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
    26ec:	d4000001 	svc	#0x0
 ret
    26f0:	d65f03c0 	ret

00000000000026f4 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
    26f4:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
    26f8:	d4000001 	svc	#0x0
 ret
    26fc:	d65f03c0 	ret

0000000000002700 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
    2700:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
    2704:	d4000001 	svc	#0x0
 ret
    2708:	d65f03c0 	ret

000000000000270c <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
    270c:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
    2710:	d4000001 	svc	#0x0
 ret
    2714:	d65f03c0 	ret

0000000000002718 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
    2718:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
    271c:	d4000001 	svc	#0x0
 ret
    2720:	d65f03c0 	ret

0000000000002724 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
    2724:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
    2728:	d4000001 	svc	#0x0
 ret
    272c:	d65f03c0 	ret

0000000000002730 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
    2730:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
    2734:	d4000001 	svc	#0x0
 ret
    2738:	d65f03c0 	ret

000000000000273c <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
    273c:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
    2740:	d4000001 	svc	#0x0
 ret
    2744:	d65f03c0 	ret

0000000000002748 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
    2748:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
    274c:	d4000001 	svc	#0x0
 ret
    2750:	d65f03c0 	ret

0000000000002754 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
    2754:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
    2758:	d4000001 	svc	#0x0
 ret
    275c:	d65f03c0 	ret

0000000000002760 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
    2760:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
    2764:	d4000001 	svc	#0x0
 ret
    2768:	d65f03c0 	ret

000000000000276c <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
    276c:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
    2770:	d4000001 	svc	#0x0
 ret
    2774:	d65f03c0 	ret

0000000000002778 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
    2778:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
    277c:	d4000001 	svc	#0x0
 ret
    2780:	d65f03c0 	ret

0000000000002784 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
    2784:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
    2788:	d4000001 	svc	#0x0
 ret
    278c:	d65f03c0 	ret

0000000000002790 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
    2790:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
    2794:	d4000001 	svc	#0x0
 ret
    2798:	d65f03c0 	ret

000000000000279c <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
    279c:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
    27a0:	d4000001 	svc	#0x0
 ret
    27a4:	d65f03c0 	ret

00000000000027a8 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
    27a8:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
    27ac:	d4000001 	svc	#0x0
 ret
    27b0:	d65f03c0 	ret

00000000000027b4 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
    27b4:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
    27b8:	d4000001 	svc	#0x0
 ret
    27bc:	d65f03c0 	ret

00000000000027c0 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
    27c0:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
    27c4:	d4000001 	svc	#0x0
 ret
    27c8:	d65f03c0 	ret

00000000000027cc <mount>:
.global mount
mount:
 mov x7, #SYS_mount
    27cc:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
    27d0:	d4000001 	svc	#0x0
 ret
    27d4:	d65f03c0 	ret

00000000000027d8 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
    27d8:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
    27dc:	d4000001 	svc	#0x0
 ret
    27e0:	d65f03c0 	ret

00000000000027e4 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
    27e4:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
    27e8:	d4000001 	svc	#0x0
 ret
    27ec:	d65f03c0 	ret

00000000000027f0 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
    27f0:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
    27f4:	d4000001 	svc	#0x0
 ret
    27f8:	d65f03c0 	ret

00000000000027fc <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
    27fc:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
    2800:	d4000001 	svc	#0x0
 ret
    2804:	d65f03c0 	ret

0000000000002808 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
    2808:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
    280c:	d4000001 	svc	#0x0
 ret
    2810:	d65f03c0 	ret

0000000000002814 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
    2814:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
    2818:	d4000001 	svc	#0x0
 ret
    281c:	d65f03c0 	ret

0000000000002820 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
    2820:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
    2824:	d4000001 	svc	#0x0
 ret
    2828:	d65f03c0 	ret

000000000000282c <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
    282c:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
    2830:	d4000001 	svc	#0x0
 ret
    2834:	d65f03c0 	ret

0000000000002838 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
    2838:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
    283c:	d4000001 	svc	#0x0
 ret
    2840:	d65f03c0 	ret

0000000000002844 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
    2844:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
    2848:	d4000001 	svc	#0x0
 ret
    284c:	d65f03c0 	ret

0000000000002850 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
    2850:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
    2854:	d4000001 	svc	#0x0
 ret
    2858:	d65f03c0 	ret

000000000000285c <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
    285c:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
    2860:	d4000001 	svc	#0x0
 ret
    2864:	d65f03c0 	ret

0000000000002868 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
    2868:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
    286c:	d4000001 	svc	#0x0
 ret
    2870:	d65f03c0 	ret

0000000000002874 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
    2874:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
    2878:	d4000001 	svc	#0x0
 ret
    287c:	d65f03c0 	ret

0000000000002880 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
    2880:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
    2884:	d4000001 	svc	#0x0
 ret
    2888:	d65f03c0 	ret

000000000000288c <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
    288c:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
    2890:	d4000001 	svc	#0x0
 ret
    2894:	d65f03c0 	ret

0000000000002898 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
    2898:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
    289c:	d4000001 	svc	#0x0
 ret
    28a0:	d65f03c0 	ret

00000000000028a4 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
    28a4:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
    28a8:	d4000001 	svc	#0x0
 ret
    28ac:	d65f03c0 	ret

00000000000028b0 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
    28b0:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
    28b4:	d4000001 	svc	#0x0
 ret
    28b8:	d65f03c0 	ret

00000000000028bc <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
    28bc:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
    28c0:	d4000001 	svc	#0x0
 ret
    28c4:	d65f03c0 	ret

00000000000028c8 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
    28c8:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
    28cc:	d4000001 	svc	#0x0
 ret
    28d0:	d65f03c0 	ret

00000000000028d4 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
    28d4:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
    28d8:	d4000001 	svc	#0x0
 ret
    28dc:	d65f03c0 	ret

00000000000028e0 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
    28e0:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
    28e4:	d4000001 	svc	#0x0
 ret
    28e8:	d65f03c0 	ret

00000000000028ec <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
    28ec:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
    28f0:	d4000001 	svc	#0x0
 ret
    28f4:	d65f03c0 	ret

00000000000028f8 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
    28f8:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
    28fc:	d4000001 	svc	#0x0
 ret
    2900:	d65f03c0 	ret

0000000000002904 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
    2904:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
    2908:	d4000001 	svc	#0x0
 ret
    290c:	d65f03c0 	ret

0000000000002910 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
    2910:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
    2914:	d4000001 	svc	#0x0
 ret
    2918:	d65f03c0 	ret

000000000000291c <texit>:
.global texit
texit:
 mov x7, #SYS_texit
    291c:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
    2920:	d4000001 	svc	#0x0
 ret
    2924:	d65f03c0 	ret

0000000000002928 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
    2928:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
    292c:	d4000001 	svc	#0x0
 ret
    2930:	d65f03c0 	ret

0000000000002934 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
    2934:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
    2938:	d4000001 	svc	#0x0
 ret
    293c:	d65f03c0 	ret

0000000000002940 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
    2940:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
    2944:	d4000001 	svc	#0x0
 ret
    2948:	d65f03c0 	ret

000000000000294c <bind>:
.global bind
bind:
 mov x7, #SYS_bind
    294c:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
    2950:	d4000001 	svc	#0x0
 ret
    2954:	d65f03c0 	ret

0000000000002958 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
    2958:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
    295c:	d4000001 	svc	#0x0
 ret
    2960:	d65f03c0 	ret

0000000000002964 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
    2964:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
    2968:	d4000001 	svc	#0x0
 ret
    296c:	d65f03c0 	ret

0000000000002970 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
    2970:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
    2974:	52800022 	mov	w2, #0x1                   	// #1
{
    2978:	910003fd 	mov	x29, sp
    297c:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
    2980:	91007fe1 	add	x1, sp, #0x1f
    2984:	97ffff2f 	bl	2640 <write>
    2988:	7100041f 	cmp	w0, #0x1
}
    298c:	1a9f17e0 	cset	w0, eq	// eq = none
    2990:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2994:	d65f03c0 	ret

0000000000002998 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
    2998:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    299c:	910003fd 	mov	x29, sp
    29a0:	a90153f3 	stp	x19, x20, [sp, #16]
    29a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    29a8:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    29ac:	6a417c7f 	tst	w3, w1, lsr #31
    29b0:	54000300 	b.eq	2a10 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
    29b4:	4b0103e1 	neg	w1, w1
    neg = 1;
    29b8:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
    29bc:	90000023 	adrp	x3, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    29c0:	91010063 	add	x3, x3, #0x40
    29c4:	9100c3f5 	add	x21, sp, #0x30
    29c8:	d2800000 	mov	x0, #0x0                   	// #0
    29cc:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
    29d0:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
    29d4:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
    29d8:	2a0403e1 	mov	w1, w4
    29dc:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
    29e0:	38666866 	ldrb	w6, [x3, x6]
    29e4:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
    29e8:	91000400 	add	x0, x0, #0x1
    29ec:	54ffff09 	b.ls	29cc <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
    29f0:	11000493 	add	w19, w4, #0x1
  if(neg)
    29f4:	34000085 	cbz	w5, 2a04 <printint+0x6c>
    buf[i++] = '-';
    29f8:	528005a0 	mov	w0, #0x2d                  	// #45
    29fc:	38334aa0 	strb	w0, [x21, w19, uxtw]
    2a00:	11000893 	add	w19, w4, #0x2
    2a04:	51000673 	sub	w19, w19, #0x1
    2a08:	52800014 	mov	w20, #0x0                   	// #0
    2a0c:	14000008 	b	2a2c <printint+0x94>
  neg = 0;
    2a10:	52800005 	mov	w5, #0x0                   	// #0
    2a14:	17ffffea 	b	29bc <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
    2a18:	38736aa1 	ldrb	w1, [x21, x19]
    2a1c:	2a1603e0 	mov	w0, w22
    2a20:	d1000673 	sub	x19, x19, #0x1
    2a24:	97ffffd3 	bl	2970 <putc>
    2a28:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
    2a2c:	3100067f 	cmn	w19, #0x1
    2a30:	54ffff41 	b.ne	2a18 <printint+0x80>  // b.any
  return written;
}
    2a34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2a38:	2a1403e0 	mov	w0, w20
    2a3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2a40:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2a44:	d65f03c0 	ret

0000000000002a48 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
    2a48:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    2a4c:	910003fd 	mov	x29, sp
    2a50:	a90153f3 	stp	x19, x20, [sp, #16]
    2a54:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
    2a58:	52800015 	mov	w21, #0x0                   	// #0
{
    2a5c:	a90363f7 	stp	x23, x24, [sp, #48]
    2a60:	2a0003f7 	mov	w23, w0
    2a64:	a9046bf9 	stp	x25, x26, [sp, #64]
    2a68:	aa0103f9 	mov	x25, x1

  state = 0;
    2a6c:	52800001 	mov	w1, #0x0                   	// #0
{
    2a70:	a90573fb 	stp	x27, x28, [sp, #80]
    2a74:	a9406053 	ldp	x19, x24, [x2]
    2a78:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
    2a7c:	39400320 	ldrb	w0, [x25]
    2a80:	35000120 	cbnz	w0, 2aa4 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
    2a84:	2a1503e0 	mov	w0, w21
    2a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    2a8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2a90:	a94363f7 	ldp	x23, x24, [sp, #48]
    2a94:	a9446bf9 	ldp	x25, x26, [sp, #64]
    2a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    2a9c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    2aa0:	d65f03c0 	ret
    c = fmt[i] & 0xff;
    2aa4:	2a0003f6 	mov	w22, w0
    if(state == 0){
    2aa8:	35000101 	cbnz	w1, 2ac8 <vprintf+0x80>
      if(c == '%'){
    2aac:	7100941f 	cmp	w0, #0x25
    2ab0:	54000ba0 	b.eq	2c24 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
    2ab4:	2a1603e1 	mov	w1, w22
    2ab8:	2a1703e0 	mov	w0, w23
    2abc:	97ffffad 	bl	2970 <putc>
    2ac0:	0b0002b5 	add	w21, w21, w0
    2ac4:	14000057 	b	2c20 <vprintf+0x1d8>
      if(c == 'd'){
    2ac8:	7101901f 	cmp	w0, #0x64
    2acc:	540002a1 	b.ne	2b20 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
    2ad0:	37f80174 	tbnz	w20, #31, 2afc <vprintf+0xb4>
    2ad4:	91002e76 	add	x22, x19, #0xb
    2ad8:	2a1403fa 	mov	w26, w20
    2adc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2ae0:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    2ae4:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
    2ae8:	b9400261 	ldr	w1, [x19]
    2aec:	2a1703e0 	mov	w0, w23
    2af0:	97ffffaa 	bl	2998 <printint>
        written += putc(fd, va_arg(ap, uint));
    2af4:	0b0002b5 	add	w21, w21, w0
    2af8:	14000048 	b	2c18 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
    2afc:	1100229a 	add	w26, w20, #0x8
    2b00:	7100035f 	cmp	w26, #0x0
    2b04:	5400008d 	b.le	2b14 <vprintf+0xcc>
    2b08:	91002e76 	add	x22, x19, #0xb
    2b0c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2b10:	17fffff4 	b	2ae0 <vprintf+0x98>
    2b14:	aa1303f6 	mov	x22, x19
    2b18:	8b34c313 	add	x19, x24, w20, sxtw
    2b1c:	17fffff1 	b	2ae0 <vprintf+0x98>
      } else if(c == 'l') {
    2b20:	7101b01f 	cmp	w0, #0x6c
    2b24:	54000201 	b.ne	2b64 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    2b28:	37f800d4 	tbnz	w20, #31, 2b40 <vprintf+0xf8>
    2b2c:	91003e76 	add	x22, x19, #0xf
    2b30:	2a1403fa 	mov	w26, w20
    2b34:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2b38:	52800003 	mov	w3, #0x0                   	// #0
    2b3c:	17ffffea 	b	2ae4 <vprintf+0x9c>
    2b40:	1100229a 	add	w26, w20, #0x8
    2b44:	7100035f 	cmp	w26, #0x0
    2b48:	5400008d 	b.le	2b58 <vprintf+0x110>
    2b4c:	91003e76 	add	x22, x19, #0xf
    2b50:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2b54:	17fffff9 	b	2b38 <vprintf+0xf0>
    2b58:	aa1303f6 	mov	x22, x19
    2b5c:	8b34c313 	add	x19, x24, w20, sxtw
    2b60:	17fffff6 	b	2b38 <vprintf+0xf0>
      } else if(c == 'x') {
    2b64:	7101e01f 	cmp	w0, #0x78
    2b68:	54000221 	b.ne	2bac <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
    2b6c:	37f800f4 	tbnz	w20, #31, 2b88 <vprintf+0x140>
    2b70:	91002e76 	add	x22, x19, #0xb
    2b74:	2a1403fa 	mov	w26, w20
    2b78:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2b7c:	52800003 	mov	w3, #0x0                   	// #0
    2b80:	52800202 	mov	w2, #0x10                  	// #16
    2b84:	17ffffd9 	b	2ae8 <vprintf+0xa0>
    2b88:	1100229a 	add	w26, w20, #0x8
    2b8c:	7100035f 	cmp	w26, #0x0
    2b90:	5400008d 	b.le	2ba0 <vprintf+0x158>
    2b94:	91002e76 	add	x22, x19, #0xb
    2b98:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2b9c:	17fffff8 	b	2b7c <vprintf+0x134>
    2ba0:	aa1303f6 	mov	x22, x19
    2ba4:	8b34c313 	add	x19, x24, w20, sxtw
    2ba8:	17fffff5 	b	2b7c <vprintf+0x134>
      } else if(c == 'p') {
    2bac:	7101c01f 	cmp	w0, #0x70
    2bb0:	54000521 	b.ne	2c54 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    2bb4:	37f803f4 	tbnz	w20, #31, 2c30 <vprintf+0x1e8>
    2bb8:	91003e76 	add	x22, x19, #0xf
    2bbc:	2a1403fa 	mov	w26, w20
    2bc0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2bc4:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
    2bc8:	52800601 	mov	w1, #0x30                  	// #48
    2bcc:	2a1703e0 	mov	w0, w23
    2bd0:	97ffff68 	bl	2970 <putc>
    2bd4:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    2bd8:	9000003c 	adrp	x28, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    2bdc:	9101039c 	add	x28, x28, #0x40
  written += putc(fd, 'x');
    2be0:	2a1703e0 	mov	w0, w23
    2be4:	52800f01 	mov	w1, #0x78                  	// #120
    2be8:	97ffff62 	bl	2970 <putc>
    2bec:	0b000273 	add	w19, w19, w0
    2bf0:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    2bf4:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    2bf8:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    2bfc:	38606b81 	ldrb	w1, [x28, x0]
    2c00:	2a1703e0 	mov	w0, w23
    2c04:	97ffff5b 	bl	2970 <putc>
    2c08:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    2c0c:	71000694 	subs	w20, w20, #0x1
    2c10:	54ffff21 	b.ne	2bf4 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    2c14:	0b1302b5 	add	w21, w21, w19
    2c18:	2a1a03f4 	mov	w20, w26
    2c1c:	aa1603f3 	mov	x19, x22
      state = 0;
    2c20:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
    2c24:	91000739 	add	x25, x25, #0x1
  state = 0;
    2c28:	2a1603e1 	mov	w1, w22
    2c2c:	17ffff94 	b	2a7c <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
    2c30:	1100229a 	add	w26, w20, #0x8
    2c34:	7100035f 	cmp	w26, #0x0
    2c38:	5400008d 	b.le	2c48 <vprintf+0x200>
    2c3c:	91003e76 	add	x22, x19, #0xf
    2c40:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2c44:	17ffffe0 	b	2bc4 <vprintf+0x17c>
    2c48:	aa1303f6 	mov	x22, x19
    2c4c:	8b34c313 	add	x19, x24, w20, sxtw
    2c50:	17ffffdd 	b	2bc4 <vprintf+0x17c>
      } else if(c == 's'){
    2c54:	7101cc1f 	cmp	w0, #0x73
    2c58:	54000381 	b.ne	2cc8 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
    2c5c:	37f80214 	tbnz	w20, #31, 2c9c <vprintf+0x254>
    2c60:	91003e61 	add	x1, x19, #0xf
    2c64:	aa1303e0 	mov	x0, x19
    2c68:	927df033 	and	x19, x1, #0xfffffffffffffff8
    2c6c:	f9400016 	ldr	x22, [x0]
          s = "(null)";
    2c70:	f0000000 	adrp	x0, 5000 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm+0x30>
    2c74:	913f8800 	add	x0, x0, #0xfe2
    2c78:	f10002df 	cmp	x22, #0x0
    2c7c:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
    2c80:	394002c1 	ldrb	w1, [x22]
    2c84:	34fffce1 	cbz	w1, 2c20 <vprintf+0x1d8>
          written += putc(fd, *s);
    2c88:	2a1703e0 	mov	w0, w23
          s++;
    2c8c:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
    2c90:	97ffff38 	bl	2970 <putc>
    2c94:	0b0002b5 	add	w21, w21, w0
          s++;
    2c98:	17fffffa 	b	2c80 <vprintf+0x238>
        s = va_arg(ap, char*);
    2c9c:	11002281 	add	w1, w20, #0x8
    2ca0:	7100003f 	cmp	w1, #0x0
    2ca4:	540000cd 	b.le	2cbc <vprintf+0x274>
    2ca8:	91003e62 	add	x2, x19, #0xf
    2cac:	aa1303e0 	mov	x0, x19
    2cb0:	2a0103f4 	mov	w20, w1
    2cb4:	927df053 	and	x19, x2, #0xfffffffffffffff8
    2cb8:	17ffffed 	b	2c6c <vprintf+0x224>
    2cbc:	8b34c300 	add	x0, x24, w20, sxtw
    2cc0:	2a0103f4 	mov	w20, w1
    2cc4:	17ffffea 	b	2c6c <vprintf+0x224>
      } else if(c == 'c'){
    2cc8:	71018c1f 	cmp	w0, #0x63
    2ccc:	54000241 	b.ne	2d14 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
    2cd0:	37f80114 	tbnz	w20, #31, 2cf0 <vprintf+0x2a8>
    2cd4:	91002e76 	add	x22, x19, #0xb
    2cd8:	2a1403fa 	mov	w26, w20
    2cdc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2ce0:	39400261 	ldrb	w1, [x19]
    2ce4:	2a1703e0 	mov	w0, w23
    2ce8:	97ffff22 	bl	2970 <putc>
    2cec:	17ffff82 	b	2af4 <vprintf+0xac>
    2cf0:	1100229a 	add	w26, w20, #0x8
    2cf4:	7100035f 	cmp	w26, #0x0
    2cf8:	5400008d 	b.le	2d08 <vprintf+0x2c0>
    2cfc:	91002e76 	add	x22, x19, #0xb
    2d00:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    2d04:	17fffff7 	b	2ce0 <vprintf+0x298>
    2d08:	aa1303f6 	mov	x22, x19
    2d0c:	8b34c313 	add	x19, x24, w20, sxtw
    2d10:	17fffff4 	b	2ce0 <vprintf+0x298>
      } else if(c == '%'){
    2d14:	7100941f 	cmp	w0, #0x25
    2d18:	54ffece0 	b.eq	2ab4 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
    2d1c:	2a1703e0 	mov	w0, w23
    2d20:	528004a1 	mov	w1, #0x25                  	// #37
    2d24:	97ffff13 	bl	2970 <putc>
    2d28:	0b0002b5 	add	w21, w21, w0
    2d2c:	17ffff62 	b	2ab4 <vprintf+0x6c>

0000000000002d30 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
    2d30:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    2d34:	910003fd 	mov	x29, sp
    2d38:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
    2d3c:	910203e2 	add	x2, sp, #0x80
    2d40:	a9030be2 	stp	x2, x2, [sp, #48]
    2d44:	910143e2 	add	x2, sp, #0x50
    2d48:	f90023e2 	str	x2, [sp, #64]
    2d4c:	128005e2 	mov	w2, #0xffffffd0            	// #-48
    2d50:	b9004be2 	str	w2, [sp, #72]
    2d54:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
    2d58:	a9430fe2 	ldp	x2, x3, [sp, #48]
    2d5c:	a9010fe2 	stp	x2, x3, [sp, #16]
    2d60:	a9440fe2 	ldp	x2, x3, [sp, #64]
    2d64:	a9020fe2 	stp	x2, x3, [sp, #32]
    2d68:	910043e2 	add	x2, sp, #0x10
{
    2d6c:	a90617e4 	stp	x4, x5, [sp, #96]
    2d70:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
    2d74:	97ffff35 	bl	2a48 <vprintf>
  va_end(ap);
  return result;
}
    2d78:	a8c87bfd 	ldp	x29, x30, [sp], #128
    2d7c:	d65f03c0 	ret

0000000000002d80 <printf>:

int
printf(const char *fmt, ...)
{
    2d80:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    2d84:	910003fd 	mov	x29, sp
    2d88:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
    2d8c:	910243e1 	add	x1, sp, #0x90
    2d90:	a90307e1 	stp	x1, x1, [sp, #48]
    2d94:	910143e1 	add	x1, sp, #0x50
    2d98:	f90023e1 	str	x1, [sp, #64]
    2d9c:	128006e1 	mov	w1, #0xffffffc8            	// #-56
    2da0:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
    2da4:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
    2da8:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
    2dac:	52800020 	mov	w0, #0x1                   	// #1
{
    2db0:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
    2db4:	a9430fe2 	ldp	x2, x3, [sp, #48]
    2db8:	a9010fe2 	stp	x2, x3, [sp, #16]
    2dbc:	a9440fe2 	ldp	x2, x3, [sp, #64]
    2dc0:	a9020fe2 	stp	x2, x3, [sp, #32]
    2dc4:	910043e2 	add	x2, sp, #0x10
{
    2dc8:	a9079be5 	stp	x5, x6, [sp, #120]
    2dcc:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
    2dd0:	97ffff1e 	bl	2a48 <vprintf>
  va_end(ap);
  return result;
}
    2dd4:	a8c97bfd 	ldp	x29, x30, [sp], #144
    2dd8:	d65f03c0 	ret

0000000000002ddc <free_locked>:
free_locked(void *ap)
{
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    2ddc:	90000025 	adrp	x5, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    2de0:	f9459ca2 	ldr	x2, [x5, #2872]
  bp = (Header*)ap - 1;
    2de4:	d1004003 	sub	x3, x0, #0x10
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    2de8:	f9400041 	ldr	x1, [x2]
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    2dec:	eb03005f 	cmp	x2, x3
    2df0:	54000342 	b.cs	2e58 <free_locked+0x7c>  // b.hs, b.nlast
    2df4:	eb01007f 	cmp	x3, x1
    2df8:	540002a2 	b.cs	2e4c <free_locked+0x70>  // b.hs, b.nlast
      break;
  if(bp + bp->s.size == p->s.ptr){
    2dfc:	b85f8006 	ldur	w6, [x0, #-8]
    2e00:	8b265064 	add	x4, x3, w6, uxtw #4
    2e04:	eb04003f 	cmp	x1, x4
    2e08:	540000a1 	b.ne	2e1c <free_locked+0x40>  // b.any
    bp->s.size += p->s.ptr->s.size;
    2e0c:	b9400824 	ldr	w4, [x1, #8]
    bp->s.ptr = p->s.ptr->s.ptr;
    2e10:	f9400021 	ldr	x1, [x1]
    bp->s.size += p->s.ptr->s.size;
    2e14:	0b060084 	add	w4, w4, w6
    2e18:	b81f8004 	stur	w4, [x0, #-8]
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    2e1c:	b9400844 	ldr	w4, [x2, #8]
    2e20:	f81f0001 	stur	x1, [x0, #-16]
    2e24:	8b245046 	add	x6, x2, w4, uxtw #4
    2e28:	eb06007f 	cmp	x3, x6
    2e2c:	540000a1 	b.ne	2e40 <free_locked+0x64>  // b.any
    p->s.size += bp->s.size;
    2e30:	b85f8000 	ldur	w0, [x0, #-8]
    p->s.ptr = bp->s.ptr;
    2e34:	aa0103e3 	mov	x3, x1
    p->s.size += bp->s.size;
    2e38:	0b040000 	add	w0, w0, w4
    2e3c:	b9000840 	str	w0, [x2, #8]
  } else
    p->s.ptr = bp;
  freep = p;
    2e40:	f9059ca2 	str	x2, [x5, #2872]
    2e44:	f9000043 	str	x3, [x2]
}
    2e48:	d65f03c0 	ret
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    2e4c:	eb01005f 	cmp	x2, x1
    2e50:	540000c3 	b.cc	2e68 <free_locked+0x8c>  // b.lo, b.ul, b.last
    2e54:	17ffffea 	b	2dfc <free_locked+0x20>
    2e58:	eb01005f 	cmp	x2, x1
    2e5c:	54000063 	b.cc	2e68 <free_locked+0x8c>  // b.lo, b.ul, b.last
    2e60:	eb01007f 	cmp	x3, x1
    2e64:	54fffcc3 	b.cc	2dfc <free_locked+0x20>  // b.lo, b.ul, b.last
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    2e68:	aa0103e2 	mov	x2, x1
    2e6c:	17ffffdf 	b	2de8 <free_locked+0xc>

0000000000002e70 <heap_acquire>:
{
    2e70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e74:	910003fd 	mov	x29, sp
    2e78:	a90153f3 	stp	x19, x20, [sp, #16]
    asm volatile("ldaxr %w0, [%1]"
    2e7c:	90000033 	adrp	x19, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    2e80:	912ce273 	add	x19, x19, #0xb38
    2e84:	91002273 	add	x19, x19, #0x8
      asm volatile("stxr %w0, %w1, [%2]"
    2e88:	52800034 	mov	w20, #0x1                   	// #1
    asm volatile("ldaxr %w0, [%1]"
    2e8c:	885ffe60 	ldaxr	w0, [x19]
    if(old == 0){
    2e90:	350000c0 	cbnz	w0, 2ea8 <heap_acquire+0x38>
      asm volatile("stxr %w0, %w1, [%2]"
    2e94:	88007e74 	stxr	w0, w20, [x19]
      if(failed == 0)
    2e98:	350000a0 	cbnz	w0, 2eac <heap_acquire+0x3c>
}
    2e9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ea0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2ea4:	d65f03c0 	ret
      asm volatile("clrex" ::: "memory");
    2ea8:	d5033f5f 	clrex
    sched_yield();
    2eac:	97fffe90 	bl	28ec <sched_yield>
  for(;;){
    2eb0:	17fffff7 	b	2e8c <heap_acquire+0x1c>

0000000000002eb4 <free>:

void
free(void *ap)
{
  if(ap == 0)
    2eb4:	b40001c0 	cbz	x0, 2eec <free+0x38>
{
    2eb8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ebc:	910003fd 	mov	x29, sp
    2ec0:	f9000fe0 	str	x0, [sp, #24]
    return;
  heap_acquire();
    2ec4:	97ffffeb 	bl	2e70 <heap_acquire>
  free_locked(ap);
    2ec8:	f9400fe0 	ldr	x0, [sp, #24]
    2ecc:	97ffffc4 	bl	2ddc <free_locked>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    2ed0:	90000020 	adrp	x0, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    2ed4:	912ce000 	add	x0, x0, #0xb38
    2ed8:	52800001 	mov	w1, #0x0                   	// #0
    2edc:	91002000 	add	x0, x0, #0x8
    2ee0:	889ffc01 	stlr	w1, [x0]
  heap_release();
}
    2ee4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2ee8:	d65f03c0 	ret
    2eec:	d65f03c0 	ret

0000000000002ef0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    2ef0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2ef4:	910003fd 	mov	x29, sp
    2ef8:	a90153f3 	stp	x19, x20, [sp, #16]
  Header *p, *prevp;
  uint nunits;

  heap_acquire();
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    2efc:	2a0003f3 	mov	w19, w0
    2f00:	91003e73 	add	x19, x19, #0xf
{
    2f04:	a9025bf5 	stp	x21, x22, [sp, #32]
  if((prevp = freep) == 0){
    2f08:	90000036 	adrp	x22, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    2f0c:	912ce2d4 	add	x20, x22, #0xb38
{
    2f10:	f9001bf7 	str	x23, [sp, #48]
  heap_acquire();
    2f14:	97ffffd7 	bl	2e70 <heap_acquire>
  if((prevp = freep) == 0){
    2f18:	f9459ec1 	ldr	x1, [x22, #2872]
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    2f1c:	d344fe73 	lsr	x19, x19, #4
    2f20:	11000673 	add	w19, w19, #0x1
  if((prevp = freep) == 0){
    2f24:	b50000a1 	cbnz	x1, 2f38 <malloc+0x48>
    base.s.ptr = freep = prevp = &base;
    2f28:	91004281 	add	x1, x20, #0x10
    2f2c:	f9059ec1 	str	x1, [x22, #2872]
    2f30:	f9000a81 	str	x1, [x20, #16]
    base.s.size = 0;
    2f34:	b9001a9f 	str	wzr, [x20, #24]
  if(nu < 4096)
    2f38:	7140067f 	cmp	w19, #0x1, lsl #12
    2f3c:	52820015 	mov	w21, #0x1000                	// #4096
    2f40:	1a952275 	csel	w21, w19, w21, cs	// cs = hs, nlast
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    2f44:	f9400020 	ldr	x0, [x1]
  p = sbrk(nu * sizeof(Header));
    2f48:	531c6eb7 	lsl	w23, w21, #4
    if(p->s.size >= nunits){
    2f4c:	b9400802 	ldr	w2, [x0, #8]
    2f50:	6b13005f 	cmp	w2, w19
    2f54:	54000263 	b.cc	2fa0 <malloc+0xb0>  // b.lo, b.ul, b.last
      if(p->s.size == nunits)
    2f58:	540001a1 	b.ne	2f8c <malloc+0x9c>  // b.any
        prevp->s.ptr = p->s.ptr;
    2f5c:	f9400002 	ldr	x2, [x0]
    2f60:	f9000022 	str	x2, [x1]
      else {
        p->s.size -= nunits;
        p += p->s.size;
        p->s.size = nunits;
      }
      freep = prevp;
    2f64:	f9059ec1 	str	x1, [x22, #2872]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    2f68:	91002294 	add	x20, x20, #0x8
    2f6c:	52800001 	mov	w1, #0x0                   	// #0
    2f70:	889ffe81 	stlr	w1, [x20]
      heap_release();
      return (void*)(p + 1);
    2f74:	91004000 	add	x0, x0, #0x10
      if((p = morecore(nunits)) == 0){
        heap_release();
        return 0;
      }
  }
}
    2f78:	f9401bf7 	ldr	x23, [sp, #48]
    2f7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f84:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2f88:	d65f03c0 	ret
        p->s.size -= nunits;
    2f8c:	4b130042 	sub	w2, w2, w19
    2f90:	b9000802 	str	w2, [x0, #8]
        p += p->s.size;
    2f94:	8b225000 	add	x0, x0, w2, uxtw #4
        p->s.size = nunits;
    2f98:	b9000813 	str	w19, [x0, #8]
    2f9c:	17fffff2 	b	2f64 <malloc+0x74>
    if(p == freep)
    2fa0:	f9400281 	ldr	x1, [x20]
    2fa4:	eb00003f 	cmp	x1, x0
    2fa8:	540001e1 	b.ne	2fe4 <malloc+0xf4>  // b.any
  p = sbrk(nu * sizeof(Header));
    2fac:	2a1703e0 	mov	w0, w23
    2fb0:	97fffdcb 	bl	26dc <sbrk>
  if(p == (char*)-1)
    2fb4:	b100041f 	cmn	x0, #0x1
    2fb8:	540000c1 	b.ne	2fd0 <malloc+0xe0>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    2fbc:	91002294 	add	x20, x20, #0x8
    2fc0:	52800000 	mov	w0, #0x0                   	// #0
    2fc4:	889ffe80 	stlr	w0, [x20]
        return 0;
    2fc8:	d2800000 	mov	x0, #0x0                   	// #0
    2fcc:	17ffffeb 	b	2f78 <malloc+0x88>
  hp->s.size = nu;
    2fd0:	b9000815 	str	w21, [x0, #8]
  free_locked((void*)(hp + 1));
    2fd4:	91004000 	add	x0, x0, #0x10
    2fd8:	97ffff81 	bl	2ddc <free_locked>
  return freep;
    2fdc:	f9400280 	ldr	x0, [x20]
      if((p = morecore(nunits)) == 0){
    2fe0:	b4fffee0 	cbz	x0, 2fbc <malloc+0xcc>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    2fe4:	aa0003e1 	mov	x1, x0
    2fe8:	f9400000 	ldr	x0, [x0]
    if(p->s.size >= nunits){
    2fec:	17ffffd8 	b	2f4c <malloc+0x5c>

0000000000002ff0 <randombytes>:
#include "user/tweetnacl.h"
#include "user/ssh_crypto.h"

void
randombytes(unsigned char *p, unsigned long long n)
{
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	aa0103e2 	mov	x2, x1
  if(n > 0x7fffffffULL || getrandom(p, (int)n) != (int)n){
    2ff8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
{
    2ffc:	910003fd 	mov	x29, sp
    3000:	f9000bf3 	str	x19, [sp, #16]
    3004:	aa0003f3 	mov	x19, x0
  if(n > 0x7fffffffULL || getrandom(p, (int)n) != (int)n){
    3008:	eb01005f 	cmp	x2, x1
    300c:	540000c9 	b.ls	3024 <randombytes+0x34>  // b.plast
    // TweetNaCl's keypair entry point has no error return for entropy
    // failure. SSH uses the explicit ssh_random() path and never reaches
    // this fallback; zeroing prevents use of uninitialized stack bytes.
    memset(p, 0, (uint)n);
    3010:	aa1303e0 	mov	x0, x19
    3014:	52800001 	mov	w1, #0x0                   	// #0
  }
}
    3018:	f9400bf3 	ldr	x19, [sp, #16]
    301c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    memset(p, 0, (uint)n);
    3020:	17fffd03 	b	242c <memset>
  if(n > 0x7fffffffULL || getrandom(p, (int)n) != (int)n){
    3024:	2a0203e1 	mov	w1, w2
    3028:	f90017e2 	str	x2, [sp, #40]
    302c:	97fffe1e 	bl	28a4 <getrandom>
    3030:	f94017e2 	ldr	x2, [sp, #40]
    3034:	6b02001f 	cmp	w0, w2
    3038:	54fffec1 	b.ne	3010 <randombytes+0x20>  // b.any
}
    303c:	f9400bf3 	ldr	x19, [sp, #16]
    3040:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3044:	d65f03c0 	ret

0000000000003048 <ssh_random>:

int
ssh_random(void *p, int n)
{
  return n >= 0 && getrandom(p, n) == n ? 0 : -1;
    3048:	37f80141 	tbnz	w1, #31, 3070 <ssh_random+0x28>
{
    304c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3050:	910003fd 	mov	x29, sp
    3054:	b9001fe1 	str	w1, [sp, #28]
  return n >= 0 && getrandom(p, n) == n ? 0 : -1;
    3058:	97fffe13 	bl	28a4 <getrandom>
    305c:	b9401fe2 	ldr	w2, [sp, #28]
}
    3060:	a8c27bfd 	ldp	x29, x30, [sp], #32
  return n >= 0 && getrandom(p, n) == n ? 0 : -1;
    3064:	6b02001f 	cmp	w0, w2
    3068:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    306c:	d65f03c0 	ret
  return n >= 0 && getrandom(p, n) == n ? 0 : -1;
    3070:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    3074:	d65f03c0 	ret

0000000000003078 <ssh_sha256>:

int
ssh_sha256(unsigned char out[32], const unsigned char *p,
           unsigned long long n)
{
    3078:	a9a37bfd 	stp	x29, x30, [sp, #-464]!
    307c:	927ae444 	and	x4, x2, #0xffffffffffffffc0
    for(int i=0;i<64;i++){ uint32 s1=RR(e,6)^RR(e,11)^RR(e,25); uint32 ch=(e&f)^((~e)&g); uint32 t1=hh+s1+ch+k[i]+w[i]; uint32 s0=RR(a,2)^RR(a,13)^RR(a,22); uint32 maj=(a&b)^(a&c)^(b&c); uint32 t2=s0+maj; hh=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2; } \
    h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;h[5]+=f;h[6]+=g;h[7]+=hh; \
  } while(0)

  while(n >= 64){
    SHA_BLOCK(p);
    3080:	f0000009 	adrp	x9, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    3084:	91015129 	add	x9, x9, #0x54
{
    3088:	910003fd 	mov	x29, sp
    308c:	8b04002a 	add	x10, x1, x4
    SHA_BLOCK(p);
    3090:	910343e8 	add	x8, sp, #0xd0
{
    3094:	a9046bf9 	stp	x25, x26, [sp, #64]
    3098:	aa0203fa 	mov	x26, x2
  while(n >= 64){
    309c:	529e6e59 	mov	w25, #0xf372                	// #62322
    30a0:	72a78dd9 	movk	w25, #0x3c6e, lsl #16
{
    30a4:	a90153f3 	stp	x19, x20, [sp, #16]
  while(n >= 64){
    30a8:	5299a334 	mov	w20, #0xcd19                	// #52505
    30ac:	72ab7c14 	movk	w20, #0x5be0, lsl #16
{
    30b0:	a9025bf5 	stp	x21, x22, [sp, #32]
  while(n >= 64){
    30b4:	529b3575 	mov	w21, #0xd9ab                	// #55723
    30b8:	72a3f075 	movk	w21, #0x1f83, lsl #16
    30bc:	528d1196 	mov	w22, #0x688c                	// #26764
    30c0:	72b360b6 	movk	w22, #0x9b05, lsl #16
{
    30c4:	a90363f7 	stp	x23, x24, [sp, #48]
  while(n >= 64){
    30c8:	528a4ff7 	mov	w23, #0x527f                	// #21119
    30cc:	72aa21d7 	movk	w23, #0x510e, lsl #16
    30d0:	529ea758 	mov	w24, #0xf53a                	// #62778
    30d4:	72b4a9f8 	movk	w24, #0xa54f, lsl #16
{
    30d8:	a90573fb 	stp	x27, x28, [sp, #80]
  while(n >= 64){
    30dc:	5295d0bb 	mov	w27, #0xae85                	// #44677
    30e0:	72b76cfb 	movk	w27, #0xbb67, lsl #16
    30e4:	529cccfc 	mov	w28, #0xe667                	// #58983
    30e8:	72ad413c 	movk	w28, #0x6a09, lsl #16
{
    30ec:	f90033e0 	str	x0, [sp, #96]
  while(n >= 64){
    30f0:	eb0a003f 	cmp	x1, x10
    30f4:	54001c01 	b.ne	3474 <ssh_sha256+0x3fc>  // b.any
    p += 64;
    n -= 64;
  }
  used = (int)n;
  if(used)
    30f8:	eb040344 	subs	x4, x26, x4
    30fc:	910243f3 	add	x19, sp, #0x90
    3100:	540000c0 	b.eq	3118 <ssh_sha256+0xa0>  // b.none
    memmove(block, p, used);
    3104:	2a0403e2 	mov	w2, w4
    3108:	aa1303e0 	mov	x0, x19
    310c:	f90037e4 	str	x4, [sp, #104]
    3110:	97fffd18 	bl	2570 <memmove>
    3114:	f94037e4 	ldr	x4, [sp, #104]
  block[used++] = 0x80;
    3118:	12800fe1 	mov	w1, #0xffffff80            	// #-128
    311c:	11000480 	add	w0, w4, #0x1
    3120:	38244a61 	strb	w1, [x19, w4, uxtw]
  if(used > 56){
    3124:	7100e01f 	cmp	w0, #0x38
    3128:	54000b0d 	b.le	3288 <ssh_sha256+0x210>
    memset(block + used, 0, 64 - used);
    312c:	52800802 	mov	w2, #0x40                  	// #64
    3130:	52800001 	mov	w1, #0x0                   	// #0
    3134:	4b000042 	sub	w2, w2, w0
    3138:	8b204260 	add	x0, x19, w0, uxtw
    313c:	97fffcbc 	bl	242c <memset>
    SHA_BLOCK(block);
    3140:	aa1303e0 	mov	x0, x19
    3144:	910343e6 	add	x6, sp, #0xd0
    memset(block + used, 0, 64 - used);
    3148:	d2800002 	mov	x2, #0x0                   	// #0
    SHA_BLOCK(block);
    314c:	39400404 	ldrb	w4, [x0, #1]
    3150:	91001000 	add	x0, x0, #0x4
    3154:	385fc001 	ldurb	w1, [x0, #-4]
    3158:	385ff005 	ldurb	w5, [x0, #-1]
    315c:	53103c84 	lsl	w4, w4, #16
    3160:	2a016081 	orr	w1, w4, w1, lsl #24
    3164:	385fe004 	ldurb	w4, [x0, #-2]
    3168:	2a0420a4 	orr	w4, w5, w4, lsl #8
    316c:	2a040021 	orr	w1, w1, w4
    3170:	b8266841 	str	w1, [x2, x6]
    3174:	91001042 	add	x2, x2, #0x4
    3178:	f101005f 	cmp	x2, #0x40
    317c:	54fffe81 	b.ne	314c <ssh_sha256+0xd4>  // b.any
    3180:	aa0603e1 	mov	x1, x6
    3184:	52800204 	mov	w4, #0x10                  	// #16
    3188:	29400025 	ldp	w5, w0, [x1]
    318c:	11000484 	add	w4, w4, #0x1
    3190:	b9403822 	ldr	w2, [x1, #56]
    3194:	91001021 	add	x1, x1, #0x4
    3198:	13804807 	ror	w7, w0, #18
    319c:	4ac01ce7 	eor	w7, w7, w0, ror #7
    31a0:	4a400ce0 	eor	w0, w7, w0, lsr #3
    31a4:	13824c47 	ror	w7, w2, #19
    31a8:	4ac244e7 	eor	w7, w7, w2, ror #17
    31ac:	4a4228e2 	eor	w2, w7, w2, lsr #10
    31b0:	0b020000 	add	w0, w0, w2
    31b4:	b9402022 	ldr	w2, [x1, #32]
    31b8:	0b0200a2 	add	w2, w5, w2
    31bc:	0b020000 	add	w0, w0, w2
    31c0:	b9003c20 	str	w0, [x1, #60]
    31c4:	7101009f 	cmp	w4, #0x40
    31c8:	54fffe01 	b.ne	3188 <ssh_sha256+0x110>  // b.any
    31cc:	f000000b 	adrp	x11, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    31d0:	9101516b 	add	x11, x11, #0x54
    31d4:	2a1403ed 	mov	w13, w20
    31d8:	2a1503e9 	mov	w9, w21
    31dc:	2a1603ea 	mov	w10, w22
    31e0:	2a1703e1 	mov	w1, w23
    31e4:	2a1803ec 	mov	w12, w24
    31e8:	2a1903e5 	mov	w5, w25
    31ec:	2a1b03e7 	mov	w7, w27
    31f0:	2a1c03e2 	mov	w2, w28
    31f4:	d2800008 	mov	x8, #0x0                   	// #0
    31f8:	0a0a002e 	and	w14, w1, w10
    31fc:	13812c20 	ror	w0, w1, #11
    3200:	4ac11800 	eor	w0, w0, w1, ror #6
    3204:	0a210124 	bic	w4, w9, w1
    3208:	4a0e0084 	eor	w4, w4, w14
    320c:	4ac16400 	eor	w0, w0, w1, ror #25
    3210:	b86868ce 	ldr	w14, [x6, x8]
    3214:	0b040000 	add	w0, w0, w4
    3218:	b86b6904 	ldr	w4, [x8, x11]
    321c:	91001108 	add	x8, x8, #0x4
    3220:	0b0e0084 	add	w4, w4, w14
    3224:	0a0500ee 	and	w14, w7, w5
    3228:	0b040000 	add	w0, w0, w4
    322c:	13823444 	ror	w4, w2, #13
    3230:	0b0d0000 	add	w0, w0, w13
    3234:	4a0500ed 	eor	w13, w7, w5
    3238:	4ac20884 	eor	w4, w4, w2, ror #2
    323c:	0a0201ad 	and	w13, w13, w2
    3240:	4a0e01ad 	eor	w13, w13, w14
    3244:	4ac25884 	eor	w4, w4, w2, ror #22
    3248:	0b0d0084 	add	w4, w4, w13
    324c:	0b0c000e 	add	w14, w0, w12
    3250:	2a0903ed 	mov	w13, w9
    3254:	0b040000 	add	w0, w0, w4
    3258:	2a0503ec 	mov	w12, w5
    325c:	f104011f 	cmp	x8, #0x100
    3260:	54001b81 	b.ne	35d0 <ssh_sha256+0x558>  // b.any
    3264:	0b02037b 	add	w27, w27, w2
    3268:	0b070339 	add	w25, w25, w7
    326c:	0b050318 	add	w24, w24, w5
    3270:	0b0e02f7 	add	w23, w23, w14
    3274:	0b0102d6 	add	w22, w22, w1
    3278:	0b0a02b5 	add	w21, w21, w10
    327c:	0b090294 	add	w20, w20, w9
    3280:	0b00039c 	add	w28, w28, w0
    used = 0;
    3284:	52800000 	mov	w0, #0x0                   	// #0
  }
  memset(block + used, 0, 56 - used);
    3288:	52800001 	mov	w1, #0x0                   	// #0
    328c:	52800702 	mov	w2, #0x38                  	// #56
    3290:	4b000042 	sub	w2, w2, w0
    3294:	8b204260 	add	x0, x19, w0, uxtw
    3298:	97fffc65 	bl	242c <memset>
  unsigned long long bits = total << 3;
    329c:	d37df35a 	lsl	x26, x26, #3
  for(int i = 0; i < 8; i++)
    32a0:	aa1303e1 	mov	x1, x19
  unsigned long long bits = total << 3;
    32a4:	aa1303e2 	mov	x2, x19
    32a8:	52800000 	mov	w0, #0x0                   	// #0
    block[63-i] = bits >> (8*i);
    32ac:	9ac02743 	lsr	x3, x26, x0
  for(int i = 0; i < 8; i++)
    32b0:	11002000 	add	w0, w0, #0x8
    block[63-i] = bits >> (8*i);
    32b4:	3900fc43 	strb	w3, [x2, #63]
  for(int i = 0; i < 8; i++)
    32b8:	d1000442 	sub	x2, x2, #0x1
    32bc:	7101001f 	cmp	w0, #0x40
    32c0:	54ffff61 	b.ne	32ac <ssh_sha256+0x234>  // b.any
  SHA_BLOCK(block);
    32c4:	910343e8 	add	x8, sp, #0xd0
  for(int i = 0; i < 8; i++)
    32c8:	d2800002 	mov	x2, #0x0                   	// #0
  SHA_BLOCK(block);
    32cc:	39400423 	ldrb	w3, [x1, #1]
    32d0:	91001021 	add	x1, x1, #0x4
    32d4:	385fc020 	ldurb	w0, [x1, #-4]
    32d8:	385ff024 	ldurb	w4, [x1, #-1]
    32dc:	53103c63 	lsl	w3, w3, #16
    32e0:	2a006060 	orr	w0, w3, w0, lsl #24
    32e4:	385fe023 	ldurb	w3, [x1, #-2]
    32e8:	2a032083 	orr	w3, w4, w3, lsl #8
    32ec:	2a030000 	orr	w0, w0, w3
    32f0:	b8286840 	str	w0, [x2, x8]
    32f4:	91001042 	add	x2, x2, #0x4
    32f8:	f101005f 	cmp	x2, #0x40
    32fc:	54fffe81 	b.ne	32cc <ssh_sha256+0x254>  // b.any
    3300:	aa0803e1 	mov	x1, x8
    3304:	52800203 	mov	w3, #0x10                  	// #16
    3308:	29400024 	ldp	w4, w0, [x1]
    330c:	11000463 	add	w3, w3, #0x1
    3310:	b9403822 	ldr	w2, [x1, #56]
    3314:	91001021 	add	x1, x1, #0x4
    3318:	13804805 	ror	w5, w0, #18
    331c:	4ac01ca5 	eor	w5, w5, w0, ror #7
    3320:	4a400ca0 	eor	w0, w5, w0, lsr #3
    3324:	13824c45 	ror	w5, w2, #19
    3328:	4ac244a5 	eor	w5, w5, w2, ror #17
    332c:	4a4228a2 	eor	w2, w5, w2, lsr #10
    3330:	0b020000 	add	w0, w0, w2
    3334:	b9402022 	ldr	w2, [x1, #32]
    3338:	0b020082 	add	w2, w4, w2
    333c:	0b020000 	add	w0, w0, w2
    3340:	b9003c20 	str	w0, [x1, #60]
    3344:	7101007f 	cmp	w3, #0x40
    3348:	54fffe01 	b.ne	3308 <ssh_sha256+0x290>  // b.any
    334c:	f000000a 	adrp	x10, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    3350:	9101514a 	add	x10, x10, #0x54
    3354:	2a1403ed 	mov	w13, w20
    3358:	2a1503e6 	mov	w6, w21
    335c:	2a1603e7 	mov	w7, w22
    3360:	2a1703e0 	mov	w0, w23
    3364:	2a1803eb 	mov	w11, w24
    3368:	2a1903e3 	mov	w3, w25
    336c:	2a1b03e4 	mov	w4, w27
    3370:	2a1c03e2 	mov	w2, w28
    3374:	d2800009 	mov	x9, #0x0                   	// #0
    3378:	0a07000c 	and	w12, w0, w7
    337c:	13802c01 	ror	w1, w0, #11
    3380:	4ac01821 	eor	w1, w1, w0, ror #6
    3384:	0a2000c5 	bic	w5, w6, w0
    3388:	4a0c00a5 	eor	w5, w5, w12
    338c:	4ac06421 	eor	w1, w1, w0, ror #25
    3390:	b869690c 	ldr	w12, [x8, x9]
    3394:	0b050021 	add	w1, w1, w5
    3398:	b86a6925 	ldr	w5, [x9, x10]
    339c:	91001129 	add	x9, x9, #0x4
    33a0:	0b0c00a5 	add	w5, w5, w12
    33a4:	4a03008c 	eor	w12, w4, w3
    33a8:	0b050021 	add	w1, w1, w5
    33ac:	13823445 	ror	w5, w2, #13
    33b0:	0b0d0021 	add	w1, w1, w13
    33b4:	4ac208a5 	eor	w5, w5, w2, ror #2
    33b8:	0a03008d 	and	w13, w4, w3
    33bc:	0a02018c 	and	w12, w12, w2
    33c0:	4a0d018c 	eor	w12, w12, w13
    33c4:	4ac258a5 	eor	w5, w5, w2, ror #22
    33c8:	0b0c00a5 	add	w5, w5, w12
    33cc:	2a0603ed 	mov	w13, w6
    33d0:	0b0b002c 	add	w12, w1, w11
    33d4:	0b050021 	add	w1, w1, w5
    33d8:	2a0303eb 	mov	w11, w3
    33dc:	f104013f 	cmp	x9, #0x100
    33e0:	54001061 	b.ne	35ec <ssh_sha256+0x574>  // b.any
    33e4:	f94033f3 	ldr	x19, [sp, #96]
    33e8:	0b180063 	add	w3, w3, w24
    33ec:	0b1c0021 	add	w1, w1, w28
    33f0:	0b160000 	add	w0, w0, w22
    33f4:	0b190084 	add	w4, w4, w25
    33f8:	290f0fe4 	stp	w4, w3, [sp, #120]
  for(int i = 0; i < 8; i++){
    out[4*i] = h[i] >> 24;
    33fc:	9101c3e3 	add	x3, sp, #0x70
  SHA_BLOCK(block);
    3400:	0b17018c 	add	w12, w12, w23
    3404:	0b1500e7 	add	w7, w7, w21
    3408:	0b1400c6 	add	w6, w6, w20
    340c:	b90073e1 	str	w1, [sp, #112]
    3410:	0b1b0041 	add	w1, w2, w27
    3414:	b90077e1 	str	w1, [sp, #116]
    3418:	291003ec 	stp	w12, w0, [sp, #128]
    341c:	d2800000 	mov	x0, #0x0                   	// #0
    3420:	29111be7 	stp	w7, w6, [sp, #136]
    out[4*i] = h[i] >> 24;
    3424:	b8636801 	ldr	w1, [x0, x3]
  for(int i = 0; i < 8; i++){
    3428:	91001000 	add	x0, x0, #0x4
    out[4*i+1] = h[i] >> 16;
    out[4*i+2] = h[i] >> 8;
    out[4*i+3] = h[i];
    342c:	39000e61 	strb	w1, [x19, #3]
  for(int i = 0; i < 8; i++){
    3430:	91001273 	add	x19, x19, #0x4
    out[4*i] = h[i] >> 24;
    3434:	53187c22 	lsr	w2, w1, #24
    3438:	381fc262 	sturb	w2, [x19, #-4]
    out[4*i+1] = h[i] >> 16;
    343c:	53107c22 	lsr	w2, w1, #16
    3440:	381fd262 	sturb	w2, [x19, #-3]
    out[4*i+2] = h[i] >> 8;
    3444:	53087c22 	lsr	w2, w1, #8
    3448:	381fe262 	sturb	w2, [x19, #-2]
  for(int i = 0; i < 8; i++){
    344c:	f100801f 	cmp	x0, #0x20
    3450:	54fffea1 	b.ne	3424 <ssh_sha256+0x3ac>  // b.any
  }
#undef SHA_BLOCK
#undef RR
  return 0;
}
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	52800000 	mov	w0, #0x0                   	// #0
    345c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3460:	a94363f7 	ldp	x23, x24, [sp, #48]
    3464:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3468:	a94573fb 	ldp	x27, x28, [sp, #80]
    346c:	a8dd7bfd 	ldp	x29, x30, [sp], #464
    3470:	d65f03c0 	ret
    3474:	aa0103e0 	mov	x0, x1
  while(n >= 64){
    3478:	d2800003 	mov	x3, #0x0                   	// #0
    SHA_BLOCK(p);
    347c:	39400405 	ldrb	w5, [x0, #1]
    3480:	91001000 	add	x0, x0, #0x4
    3484:	385fc002 	ldurb	w2, [x0, #-4]
    3488:	385ff006 	ldurb	w6, [x0, #-1]
    348c:	53103ca5 	lsl	w5, w5, #16
    3490:	2a0260a2 	orr	w2, w5, w2, lsl #24
    3494:	385fe005 	ldurb	w5, [x0, #-2]
    3498:	2a0520c5 	orr	w5, w6, w5, lsl #8
    349c:	2a050042 	orr	w2, w2, w5
    34a0:	b8286862 	str	w2, [x3, x8]
    34a4:	91001063 	add	x3, x3, #0x4
    34a8:	f101007f 	cmp	x3, #0x40
    34ac:	54fffe81 	b.ne	347c <ssh_sha256+0x404>  // b.any
    34b0:	aa0803e2 	mov	x2, x8
    34b4:	52800205 	mov	w5, #0x10                  	// #16
    34b8:	29400046 	ldp	w6, w0, [x2]
    34bc:	110004a5 	add	w5, w5, #0x1
    34c0:	b9403843 	ldr	w3, [x2, #56]
    34c4:	91001042 	add	x2, x2, #0x4
    34c8:	13804807 	ror	w7, w0, #18
    34cc:	4ac01ce7 	eor	w7, w7, w0, ror #7
    34d0:	4a400ce0 	eor	w0, w7, w0, lsr #3
    34d4:	13834c67 	ror	w7, w3, #19
    34d8:	4ac344e7 	eor	w7, w7, w3, ror #17
    34dc:	4a4328e3 	eor	w3, w7, w3, lsr #10
    34e0:	0b030000 	add	w0, w0, w3
    34e4:	b9402043 	ldr	w3, [x2, #32]
    34e8:	0b0300c3 	add	w3, w6, w3
    34ec:	0b030000 	add	w0, w0, w3
    34f0:	b9003c40 	str	w0, [x2, #60]
    34f4:	710100bf 	cmp	w5, #0x40
    34f8:	54fffe01 	b.ne	34b8 <ssh_sha256+0x440>  // b.any
    34fc:	2a1403e5 	mov	w5, w20
    3500:	2a1503ec 	mov	w12, w21
    3504:	2a1603ed 	mov	w13, w22
    3508:	2a1703e2 	mov	w2, w23
    350c:	2a1803ee 	mov	w14, w24
    3510:	2a1903e6 	mov	w6, w25
    3514:	2a1b03e7 	mov	w7, w27
    3518:	2a1c03e3 	mov	w3, w28
    351c:	d280000b 	mov	x11, #0x0                   	// #0
    3520:	0a0d0050 	and	w16, w2, w13
    3524:	13822c40 	ror	w0, w2, #11
    3528:	4ac21800 	eor	w0, w0, w2, ror #6
    352c:	0a22018f 	bic	w15, w12, w2
    3530:	4a1001ef 	eor	w15, w15, w16
    3534:	4ac26400 	eor	w0, w0, w2, ror #25
    3538:	b86b6910 	ldr	w16, [x8, x11]
    353c:	0b0f0000 	add	w0, w0, w15
    3540:	b869696f 	ldr	w15, [x11, x9]
    3544:	9100116b 	add	x11, x11, #0x4
    3548:	0b1001ef 	add	w15, w15, w16
    354c:	0a0600f0 	and	w16, w7, w6
    3550:	0b0f0000 	add	w0, w0, w15
    3554:	4a0600ef 	eor	w15, w7, w6
    3558:	0b050000 	add	w0, w0, w5
    355c:	13833465 	ror	w5, w3, #13
    3560:	4ac308a5 	eor	w5, w5, w3, ror #2
    3564:	0a0301ef 	and	w15, w15, w3
    3568:	4a1001ef 	eor	w15, w15, w16
    356c:	4ac358a5 	eor	w5, w5, w3, ror #22
    3570:	0b0f00a5 	add	w5, w5, w15
    3574:	0b0e000f 	add	w15, w0, w14
    3578:	0b050000 	add	w0, w0, w5
    357c:	2a0603ee 	mov	w14, w6
    3580:	2a0c03e5 	mov	w5, w12
    3584:	f104017f 	cmp	x11, #0x100
    3588:	54000161 	b.ne	35b4 <ssh_sha256+0x53c>  // b.any
    358c:	0b00039c 	add	w28, w28, w0
    3590:	0b03037b 	add	w27, w27, w3
    3594:	0b070339 	add	w25, w25, w7
    3598:	0b060318 	add	w24, w24, w6
    359c:	0b0f02f7 	add	w23, w23, w15
    35a0:	0b0202d6 	add	w22, w22, w2
    35a4:	0b0d02b5 	add	w21, w21, w13
    35a8:	0b0c0294 	add	w20, w20, w12
    p += 64;
    35ac:	91010021 	add	x1, x1, #0x40
    n -= 64;
    35b0:	17fffed0 	b	30f0 <ssh_sha256+0x78>
    SHA_BLOCK(p);
    35b4:	2a0d03ec 	mov	w12, w13
    35b8:	2a0703e6 	mov	w6, w7
    35bc:	2a0203ed 	mov	w13, w2
    35c0:	2a0303e7 	mov	w7, w3
    35c4:	2a0f03e2 	mov	w2, w15
    35c8:	2a0003e3 	mov	w3, w0
    35cc:	17ffffd5 	b	3520 <ssh_sha256+0x4a8>
    SHA_BLOCK(block);
    35d0:	2a0a03e9 	mov	w9, w10
    35d4:	2a0703e5 	mov	w5, w7
    35d8:	2a0103ea 	mov	w10, w1
    35dc:	2a0203e7 	mov	w7, w2
    35e0:	2a0e03e1 	mov	w1, w14
    35e4:	2a0003e2 	mov	w2, w0
    35e8:	17ffff04 	b	31f8 <ssh_sha256+0x180>
  SHA_BLOCK(block);
    35ec:	2a0703e6 	mov	w6, w7
    35f0:	2a0403e3 	mov	w3, w4
    35f4:	2a0003e7 	mov	w7, w0
    35f8:	2a0203e4 	mov	w4, w2
    35fc:	2a0c03e0 	mov	w0, w12
    3600:	2a0103e2 	mov	w2, w1
    3604:	17ffff5d 	b	3378 <ssh_sha256+0x300>

0000000000003608 <ssh_x25519_public>:

int
ssh_x25519_public(unsigned char out[32], const unsigned char secret[32])
{
  return crypto_scalarmult_base(out, secret);
    3608:	1400065e 	b	4f80 <crypto_scalarmult_curve25519_tweet_base>

000000000000360c <ssh_x25519>:
}

int
ssh_x25519(unsigned char out[32], const unsigned char secret[32],
           const unsigned char peer[32])
{
    360c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3610:	910003fd 	mov	x29, sp
    3614:	f9000bf3 	str	x19, [sp, #16]
    3618:	aa0003f3 	mov	x19, x0
  if(crypto_scalarmult(out, secret, peer) < 0)
    361c:	940005bc 	bl	4d0c <crypto_scalarmult_curve25519_tweet>
    3620:	37f801a0 	tbnz	w0, #31, 3654 <ssh_x25519+0x48>
    3624:	d2800000 	mov	x0, #0x0                   	// #0
    return -1;
  unsigned char any = 0;
    3628:	52800001 	mov	w1, #0x0                   	// #0
  for(int i = 0; i < 32; i++)
    any |= out[i];
    362c:	38606a62 	ldrb	w2, [x19, x0]
  for(int i = 0; i < 32; i++)
    3630:	91000400 	add	x0, x0, #0x1
    any |= out[i];
    3634:	2a010041 	orr	w1, w2, w1
  for(int i = 0; i < 32; i++)
    3638:	f100801f 	cmp	x0, #0x20
    363c:	54ffff81 	b.ne	362c <ssh_x25519+0x20>  // b.any
  return any ? 0 : -1;
    3640:	7100003f 	cmp	w1, #0x0
    3644:	5a9f13e0 	csetm	w0, eq	// eq = none
}
    3648:	f9400bf3 	ldr	x19, [sp, #16]
    364c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3650:	d65f03c0 	ret
    return -1;
    3654:	12800000 	mov	w0, #0xffffffff            	// #-1
    3658:	17fffffc 	b	3648 <ssh_x25519+0x3c>

000000000000365c <ssh_ed25519_keypair>:
int
ssh_ed25519_keypair(unsigned char public_key[32],
                    unsigned char secret_key[64],
                    const unsigned char seed[32])
{
  return crypto_sign_seed_keypair(public_key, secret_key, seed);
    365c:	14000774 	b	542c <crypto_sign_seed_keypair>

0000000000003660 <ssh_ed25519_sign>:

int
ssh_ed25519_sign(unsigned char signature[64], const unsigned char *message,
                 unsigned long long length,
                 const unsigned char secret_key[64])
{
    3660:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3664:	910003fd 	mov	x29, sp
    3668:	a90153f3 	stp	x19, x20, [sp, #16]
    366c:	aa0103f3 	mov	x19, x1
    3670:	aa0203f4 	mov	x20, x2
    3674:	a9025bf5 	stp	x21, x22, [sp, #32]
    3678:	aa0003f6 	mov	x22, x0
  unsigned char *signed_message = malloc((uint)length + 64);
    367c:	11010040 	add	w0, w2, #0x40
{
    3680:	f9001fe3 	str	x3, [sp, #56]
  unsigned char *signed_message = malloc((uint)length + 64);
    3684:	97fffe1b 	bl	2ef0 <malloc>
  unsigned long long signed_length = 0;
    3688:	f90027ff 	str	xzr, [sp, #72]
  if(signed_message == 0)
    368c:	b4000340 	cbz	x0, 36f4 <ssh_ed25519_sign+0x94>
    return -1;
  int result = crypto_sign(signed_message, &signed_length, message, length,
    3690:	f9401fe4 	ldr	x4, [sp, #56]
    3694:	aa1303e2 	mov	x2, x19
    3698:	aa0003f5 	mov	x21, x0
    369c:	aa1403e3 	mov	x3, x20
    36a0:	910123e1 	add	x1, sp, #0x48
    36a4:	9400079d 	bl	5518 <crypto_sign_ed25519_tweet>
    36a8:	2a0003f3 	mov	w19, w0
                           secret_key);
  if(result == 0 && signed_length == length + 64)
    36ac:	34000120 	cbz	w0, 36d0 <ssh_ed25519_sign+0x70>
    memmove(signature, signed_message, 64);
  else
    result = -1;
    36b0:	12800013 	mov	w19, #0xffffffff            	// #-1
  free(signed_message);
    36b4:	aa1503e0 	mov	x0, x21
    36b8:	97fffdff 	bl	2eb4 <free>
  return result;
}
    36bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36c0:	2a1303e0 	mov	w0, w19
    36c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    36c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    36cc:	d65f03c0 	ret
  if(result == 0 && signed_length == length + 64)
    36d0:	f94027e0 	ldr	x0, [sp, #72]
    36d4:	91010294 	add	x20, x20, #0x40
    36d8:	eb00029f 	cmp	x20, x0
    36dc:	54fffea1 	b.ne	36b0 <ssh_ed25519_sign+0x50>  // b.any
    memmove(signature, signed_message, 64);
    36e0:	aa1503e1 	mov	x1, x21
    36e4:	aa1603e0 	mov	x0, x22
    36e8:	52800802 	mov	w2, #0x40                  	// #64
    36ec:	97fffba1 	bl	2570 <memmove>
    36f0:	17fffff1 	b	36b4 <ssh_ed25519_sign+0x54>
    return -1;
    36f4:	12800013 	mov	w19, #0xffffffff            	// #-1
    36f8:	17fffff1 	b	36bc <ssh_ed25519_sign+0x5c>

00000000000036fc <ssh_hmac_sha256>:
ssh_hmac_sha256(unsigned char out[32], const unsigned char *key, int keylen,
                const unsigned char *message, int length)
{
  uchar k0[64], outer[96];
  uchar *inner;
  if(keylen < 0 || length < 0 || (inner = malloc(64 + length)) == 0)
    36fc:	2a040045 	orr	w5, w2, w4
    3700:	36f80145 	tbz	w5, #31, 3728 <ssh_hmac_sha256+0x2c>
    return -1;
    3704:	12800000 	mov	w0, #0xffffffff            	// #-1
  memset(k0, 0, sizeof(k0));
  memset(outer, 0, sizeof(outer));
  memset(inner, 0, 64 + length);
  free(inner);
  return 0;
}
    3708:	d65f03c0 	ret
    return -1;
    370c:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    3710:	a94153f3 	ldp	x19, x20, [sp, #16]
    3714:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3718:	a94363f7 	ldp	x23, x24, [sp, #48]
    371c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3720:	a8cf7bfd 	ldp	x29, x30, [sp], #240
    3724:	d65f03c0 	ret
{
    3728:	a9b17bfd 	stp	x29, x30, [sp, #-240]!
    372c:	910003fd 	mov	x29, sp
    3730:	a90363f7 	stp	x23, x24, [sp, #48]
  if(keylen < 0 || length < 0 || (inner = malloc(64 + length)) == 0)
    3734:	11010098 	add	w24, w4, #0x40
    3738:	aa0103f7 	mov	x23, x1
{
    373c:	a90153f3 	stp	x19, x20, [sp, #16]
    3740:	2a0203f4 	mov	w20, w2
    3744:	a9025bf5 	stp	x21, x22, [sp, #32]
    3748:	2a0403f6 	mov	w22, w4
    374c:	a9046bf9 	stp	x25, x26, [sp, #64]
    3750:	aa0303f9 	mov	x25, x3
    3754:	aa0003fa 	mov	x26, x0
  if(keylen < 0 || length < 0 || (inner = malloc(64 + length)) == 0)
    3758:	2a1803e0 	mov	w0, w24
    375c:	97fffde5 	bl	2ef0 <malloc>
    3760:	aa0003f3 	mov	x19, x0
    3764:	b4fffd40 	cbz	x0, 370c <ssh_hmac_sha256+0x10>
  memset(k0, 0, sizeof(k0));
    3768:	910143f5 	add	x21, sp, #0x50
    376c:	52800802 	mov	w2, #0x40                  	// #64
    3770:	aa1503e0 	mov	x0, x21
    3774:	52800001 	mov	w1, #0x0                   	// #0
    3778:	97fffb2d 	bl	242c <memset>
  if(keylen > 64){
    377c:	7101029f 	cmp	w20, #0x40
    3780:	5400066d 	b.le	384c <ssh_hmac_sha256+0x150>
    ssh_sha256(k0, key, keylen);
    3784:	2a1403e2 	mov	w2, w20
    3788:	aa1703e1 	mov	x1, x23
    378c:	aa1503e0 	mov	x0, x21
    3790:	97fffe3a 	bl	3078 <ssh_sha256>
{
    3794:	d2800002 	mov	x2, #0x0                   	// #0
    inner[i] = k0[i] ^ 0x36;
    3798:	528006c1 	mov	w1, #0x36                  	// #54
    379c:	38626aa0 	ldrb	w0, [x21, x2]
    37a0:	4a010000 	eor	w0, w0, w1
    37a4:	38226a60 	strb	w0, [x19, x2]
  for(int i = 0; i < 64; i++)
    37a8:	91000442 	add	x2, x2, #0x1
    37ac:	f101005f 	cmp	x2, #0x40
    37b0:	54ffff61 	b.ne	379c <ssh_hmac_sha256+0xa0>  // b.any
  if(length)
    37b4:	340000b6 	cbz	w22, 37c8 <ssh_hmac_sha256+0xcc>
    memmove(inner + 64, message, length);
    37b8:	2a1603e2 	mov	w2, w22
    37bc:	aa1903e1 	mov	x1, x25
    37c0:	91010260 	add	x0, x19, #0x40
    37c4:	97fffb6b 	bl	2570 <memmove>
  ssh_sha256(outer + 64, inner, 64 + length);
    37c8:	aa1303e1 	mov	x1, x19
    37cc:	2a1803e2 	mov	w2, w24
    37d0:	910343e0 	add	x0, sp, #0xd0
    outer[i] = k0[i] ^ 0x5c;
    37d4:	910243f6 	add	x22, sp, #0x90
  ssh_sha256(outer + 64, inner, 64 + length);
    37d8:	97fffe28 	bl	3078 <ssh_sha256>
    37dc:	d2800014 	mov	x20, #0x0                   	// #0
    outer[i] = k0[i] ^ 0x5c;
    37e0:	52800b81 	mov	w1, #0x5c                  	// #92
    37e4:	38746aa0 	ldrb	w0, [x21, x20]
    37e8:	4a010000 	eor	w0, w0, w1
    37ec:	38366a80 	strb	w0, [x20, x22]
  for(int i = 0; i < 64; i++)
    37f0:	91000694 	add	x20, x20, #0x1
    37f4:	f101029f 	cmp	x20, #0x40
    37f8:	54ffff61 	b.ne	37e4 <ssh_hmac_sha256+0xe8>  // b.any
  ssh_sha256(out, outer, sizeof(outer));
    37fc:	aa1603e1 	mov	x1, x22
    3800:	d2800c02 	mov	x2, #0x60                  	// #96
    3804:	aa1a03e0 	mov	x0, x26
    3808:	97fffe1c 	bl	3078 <ssh_sha256>
  memset(k0, 0, sizeof(k0));
    380c:	2a1403e2 	mov	w2, w20
    3810:	52800001 	mov	w1, #0x0                   	// #0
    3814:	aa1503e0 	mov	x0, x21
    3818:	97fffb05 	bl	242c <memset>
  memset(outer, 0, sizeof(outer));
    381c:	52800c02 	mov	w2, #0x60                  	// #96
    3820:	52800001 	mov	w1, #0x0                   	// #0
    3824:	aa1603e0 	mov	x0, x22
    3828:	97fffb01 	bl	242c <memset>
  memset(inner, 0, 64 + length);
    382c:	2a1803e2 	mov	w2, w24
    3830:	52800001 	mov	w1, #0x0                   	// #0
    3834:	aa1303e0 	mov	x0, x19
    3838:	97fffafd 	bl	242c <memset>
  free(inner);
    383c:	aa1303e0 	mov	x0, x19
    3840:	97fffd9d 	bl	2eb4 <free>
  return 0;
    3844:	52800000 	mov	w0, #0x0                   	// #0
    3848:	17ffffb2 	b	3710 <ssh_hmac_sha256+0x14>
  } else if(keylen){
    384c:	34fffa54 	cbz	w20, 3794 <ssh_hmac_sha256+0x98>
    memmove(k0, key, keylen);
    3850:	2a1403e2 	mov	w2, w20
    3854:	aa1703e1 	mov	x1, x23
    3858:	aa1503e0 	mov	x0, x21
    385c:	97fffb45 	bl	2570 <memmove>
    3860:	17ffffcd 	b	3794 <ssh_hmac_sha256+0x98>

0000000000003864 <ssh_aes128_ctr_init>:
}

void
ssh_aes128_ctr_init(struct ssh_aes128_ctr *ctx, const uchar key[16],
                    const uchar iv[16])
{
    3864:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	aa0203f4 	mov	x20, x2
  memmove(out, key, 16);
    3878:	52800202 	mov	w2, #0x10                  	// #16
    387c:	97fffb3d 	bl	2570 <memmove>
      t[0] = aes_sbox[t[1]] ^ rcon[round++];
    3880:	f0000000 	adrp	x0, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    3884:	91015000 	add	x0, x0, #0x54
    3888:	91040004 	add	x4, x0, #0x100
    388c:	91004262 	add	x2, x19, #0x10
    for(int i = 0; i < 4; i++) t[i] = out[bytes - 4 + i];
    3890:	9100a3e8 	add	x8, sp, #0x28
      t[0] = aes_sbox[t[1]] ^ rcon[round++];
    3894:	91080000 	add	x0, x0, #0x200
  int bytes = 16, round = 0;
    3898:	52800005 	mov	w5, #0x0                   	// #0
    389c:	52800203 	mov	w3, #0x10                  	// #16
    for(int i = 0; i < 4; i++) t[i] = out[bytes - 4 + i];
    38a0:	d1001046 	sub	x6, x2, #0x4
{
    38a4:	d2800001 	mov	x1, #0x0                   	// #0
    for(int i = 0; i < 4; i++) t[i] = out[bytes - 4 + i];
    38a8:	386168c7 	ldrb	w7, [x6, x1]
    38ac:	38286827 	strb	w7, [x1, x8]
    38b0:	91000421 	add	x1, x1, #0x1
    38b4:	f100103f 	cmp	x1, #0x4
    38b8:	54ffff81 	b.ne	38a8 <ssh_aes128_ctr_init+0x44>  // b.any
    if((bytes & 15) == 0){
    38bc:	f2400c7f 	tst	x3, #0xf
    38c0:	54000201 	b.ne	3900 <ssh_aes128_ctr_init+0x9c>  // b.any
      t[0] = aes_sbox[t[1]] ^ rcon[round++];
    38c4:	3940a7e1 	ldrb	w1, [sp, #41]
    38c8:	38654807 	ldrb	w7, [x0, w5, uxtw]
    38cc:	110004a5 	add	w5, w5, #0x1
      out[bytes] = out[bytes - 16] ^ t[i];
    38d0:	3940a3e6 	ldrb	w6, [sp, #40]
      t[0] = aes_sbox[t[1]] ^ rcon[round++];
    38d4:	38616881 	ldrb	w1, [x4, x1]
    38d8:	4a070021 	eor	w1, w1, w7
    38dc:	3900a3e1 	strb	w1, [sp, #40]
      t[1] = aes_sbox[t[2]];
    38e0:	3940abe1 	ldrb	w1, [sp, #42]
    38e4:	38616881 	ldrb	w1, [x4, x1]
    38e8:	3900a7e1 	strb	w1, [sp, #41]
      t[2] = aes_sbox[t[3]];
    38ec:	3940afe1 	ldrb	w1, [sp, #43]
    38f0:	38616881 	ldrb	w1, [x4, x1]
    38f4:	3900abe1 	strb	w1, [sp, #42]
      t[3] = aes_sbox[q];
    38f8:	38664881 	ldrb	w1, [x4, w6, uxtw]
    38fc:	3900afe1 	strb	w1, [sp, #43]
      t[0] = aes_sbox[t[1]] ^ rcon[round++];
    3900:	aa0203e6 	mov	x6, x2
    3904:	d2800001 	mov	x1, #0x0                   	// #0
      out[bytes] = out[bytes - 16] ^ t[i];
    3908:	385f00c7 	ldurb	w7, [x6, #-16]
    390c:	38616909 	ldrb	w9, [x8, x1]
    for(int i = 0; i < 4; i++, bytes++)
    3910:	91000421 	add	x1, x1, #0x1
      out[bytes] = out[bytes - 16] ^ t[i];
    3914:	4a0900e7 	eor	w7, w7, w9
    3918:	380014c7 	strb	w7, [x6], #1
    for(int i = 0; i < 4; i++, bytes++)
    391c:	f100103f 	cmp	x1, #0x4
    3920:	54ffff41 	b.ne	3908 <ssh_aes128_ctr_init+0xa4>  // b.any
    3924:	11001063 	add	w3, w3, #0x4
  while(bytes < 176){
    3928:	91001042 	add	x2, x2, #0x4
    392c:	7102c07f 	cmp	w3, #0xb0
    3930:	54fffb81 	b.ne	38a0 <ssh_aes128_ctr_init+0x3c>  // b.any
  aes_key_expand(ctx->round_key, key);
  memmove(ctx->counter, iv, 16);
    3934:	aa1403e1 	mov	x1, x20
    3938:	9102c260 	add	x0, x19, #0xb0
    393c:	52800202 	mov	w2, #0x10                  	// #16
    3940:	97fffb0c 	bl	2570 <memmove>
  memset(ctx->stream, 0, 16);
    3944:	91030260 	add	x0, x19, #0xc0
    3948:	52800202 	mov	w2, #0x10                  	// #16
    394c:	52800001 	mov	w1, #0x0                   	// #0
    3950:	97fffab7 	bl	242c <memset>
  ctx->available = 0;
    3954:	b900d27f 	str	wzr, [x19, #208]
}
    3958:	a94153f3 	ldp	x19, x20, [sp, #16]
    395c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3960:	d65f03c0 	ret

0000000000003964 <ssh_aes128_ctr_xor>:

void
ssh_aes128_ctr_xor(struct ssh_aes128_ctr *ctx, uchar *data, int length)
{
    3964:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3968:	910003fd 	mov	x29, sp
    396c:	a90153f3 	stp	x19, x20, [sp, #16]
    for(int i = 0; i < 16; i++) t[i] = aes_sbox[s[i]];
    3970:	f0000014 	adrp	x20, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    3974:	91015294 	add	x20, x20, #0x54
{
    3978:	aa0003f3 	mov	x19, x0
    for(int i = 0; i < 16; i++) t[i] = aes_sbox[s[i]];
    397c:	91040294 	add	x20, x20, #0x100
{
    3980:	a9025bf5 	stp	x21, x22, [sp, #32]
    3984:	aa0103f5 	mov	x21, x1
    3988:	a90363f7 	stp	x23, x24, [sp, #48]
    398c:	2a0203f7 	mov	w23, w2
    3990:	a9046bf9 	stp	x25, x26, [sp, #64]
  for(int i = 0; i < length; i++){
    3994:	d2800019 	mov	x25, #0x0                   	// #0
  return (x << 1) ^ ((x >> 7) * 0x1b);
    3998:	5280037a 	mov	w26, #0x1b                  	// #27
  for(int i = 0; i < length; i++){
    399c:	6b1902ff 	cmp	w23, w25
    39a0:	540000ec 	b.gt	39bc <ssh_aes128_ctr_xor+0x58>
        ;
      ctx->available = 16;
    }
    data[i] ^= ctx->stream[16 - ctx->available--];
  }
}
    39a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    39a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    39b0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    39b4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    39b8:	d65f03c0 	ret
    if(ctx->available == 0){
    39bc:	b940d261 	ldr	w1, [x19, #208]
    39c0:	35001061 	cbnz	w1, 3bcc <ssh_aes128_ctr_xor+0x268>
      memmove(ctx->stream, ctx->counter, 16);
    39c4:	9102c261 	add	x1, x19, #0xb0
    39c8:	52800202 	mov	w2, #0x10                  	// #16
    39cc:	91030260 	add	x0, x19, #0xc0
  memmove(s, block, 16);
    39d0:	910143f8 	add	x24, sp, #0x50
      memmove(ctx->stream, ctx->counter, 16);
    39d4:	97fffae7 	bl	2570 <memmove>
  memmove(s, block, 16);
    39d8:	91030261 	add	x1, x19, #0xc0
    39dc:	aa1803e0 	mov	x0, x24
    39e0:	52800202 	mov	w2, #0x10                  	// #16
    39e4:	97fffae3 	bl	2570 <memmove>
  for(int i = 0; i < 16; i++) s[i] ^= round_key[i];
    39e8:	d1000664 	sub	x4, x19, #0x1
  memmove(s, block, 16);
    39ec:	d2800020 	mov	x0, #0x1                   	// #1
  for(int i = 0; i < 16; i++) s[i] ^= round_key[i];
    39f0:	8b000302 	add	x2, x24, x0
    39f4:	38606881 	ldrb	w1, [x4, x0]
    39f8:	91000400 	add	x0, x0, #0x1
    39fc:	385ff043 	ldurb	w3, [x2, #-1]
    3a00:	4a030021 	eor	w1, w1, w3
    3a04:	381ff041 	sturb	w1, [x2, #-1]
    3a08:	f100441f 	cmp	x0, #0x11
    3a0c:	54ffff21 	b.ne	39f0 <ssh_aes128_ctr_xor+0x8c>  // b.any
    3a10:	91003e67 	add	x7, x19, #0xf
    for(int i = 0; i < 16; i++) t[i] = aes_sbox[s[i]];
    3a14:	910183e8 	add	x8, sp, #0x60
  for(int round = 1; round <= 10; round++){
    3a18:	52800026 	mov	w6, #0x1                   	// #1
  memmove(s, block, 16);
    3a1c:	d2800000 	mov	x0, #0x0                   	// #0
    for(int i = 0; i < 16; i++) t[i] = aes_sbox[s[i]];
    3a20:	38606b01 	ldrb	w1, [x24, x0]
    3a24:	38616a81 	ldrb	w1, [x20, x1]
    3a28:	38286801 	strb	w1, [x0, x8]
    3a2c:	91000400 	add	x0, x0, #0x1
    3a30:	f100401f 	cmp	x0, #0x10
    3a34:	54ffff61 	b.ne	3a20 <ssh_aes128_ctr_xor+0xbc>  // b.any
    s[0]=t[0];s[1]=t[5];s[2]=t[10];s[3]=t[15];
    3a38:	394183e0 	ldrb	w0, [sp, #96]
    3a3c:	390143e0 	strb	w0, [sp, #80]
    3a40:	394197e0 	ldrb	w0, [sp, #101]
    3a44:	390147e0 	strb	w0, [sp, #81]
    3a48:	3941abe0 	ldrb	w0, [sp, #106]
    3a4c:	39014be0 	strb	w0, [sp, #82]
    3a50:	3941bfe0 	ldrb	w0, [sp, #111]
    3a54:	39014fe0 	strb	w0, [sp, #83]
    s[4]=t[4];s[5]=t[9];s[6]=t[14];s[7]=t[3];
    3a58:	394193e0 	ldrb	w0, [sp, #100]
    3a5c:	390153e0 	strb	w0, [sp, #84]
    3a60:	3941a7e0 	ldrb	w0, [sp, #105]
    3a64:	390157e0 	strb	w0, [sp, #85]
    3a68:	3941bbe0 	ldrb	w0, [sp, #110]
    3a6c:	39015be0 	strb	w0, [sp, #86]
    3a70:	39418fe0 	ldrb	w0, [sp, #99]
    3a74:	39015fe0 	strb	w0, [sp, #87]
    s[8]=t[8];s[9]=t[13];s[10]=t[2];s[11]=t[7];
    3a78:	3941a3e0 	ldrb	w0, [sp, #104]
    3a7c:	390163e0 	strb	w0, [sp, #88]
    3a80:	3941b7e0 	ldrb	w0, [sp, #109]
    3a84:	390167e0 	strb	w0, [sp, #89]
    3a88:	39418be0 	ldrb	w0, [sp, #98]
    3a8c:	39016be0 	strb	w0, [sp, #90]
    3a90:	39419fe0 	ldrb	w0, [sp, #103]
    3a94:	39016fe0 	strb	w0, [sp, #91]
    s[12]=t[12];s[13]=t[1];s[14]=t[6];s[15]=t[11];
    3a98:	3941b3e0 	ldrb	w0, [sp, #108]
    3a9c:	390173e0 	strb	w0, [sp, #92]
    3aa0:	394187e0 	ldrb	w0, [sp, #97]
    3aa4:	390177e0 	strb	w0, [sp, #93]
    3aa8:	39419be0 	ldrb	w0, [sp, #102]
    3aac:	39017be0 	strb	w0, [sp, #94]
    3ab0:	3941afe0 	ldrb	w0, [sp, #107]
    3ab4:	39017fe0 	strb	w0, [sp, #95]
    if(round != 10){
    3ab8:	710028df 	cmp	w6, #0xa
    3abc:	54000500 	b.eq	3b5c <ssh_aes128_ctr_xor+0x1f8>  // b.none
    3ac0:	aa1803e0 	mov	x0, x24
      for(int c = 0; c < 4; c++){
    3ac4:	52800009 	mov	w9, #0x0                   	// #0
        uchar x = a[0]^a[1]^a[2]^a[3], u = a[0];
    3ac8:	39400002 	ldrb	w2, [x0]
      for(int c = 0; c < 4; c++){
    3acc:	11000529 	add	w9, w9, #0x1
        uchar x = a[0]^a[1]^a[2]^a[3], u = a[0];
    3ad0:	3940040a 	ldrb	w10, [x0, #1]
      for(int c = 0; c < 4; c++){
    3ad4:	91001000 	add	x0, x0, #0x4
        uchar x = a[0]^a[1]^a[2]^a[3], u = a[0];
    3ad8:	385fe005 	ldurb	w5, [x0, #-2]
    3adc:	4a0a0043 	eor	w3, w2, w10
    3ae0:	385ff004 	ldurb	w4, [x0, #-1]
  return (x << 1) ^ ((x >> 7) * 0x1b);
    3ae4:	93471c6c 	sbfx	x12, x3, #7, #1
    3ae8:	4a0400a1 	eor	w1, w5, w4
        uchar x = a[0]^a[1]^a[2]^a[3], u = a[0];
    3aec:	4a01006b 	eor	w11, w3, w1
  return (x << 1) ^ ((x >> 7) * 0x1b);
    3af0:	0a1a018c 	and	w12, w12, w26
    3af4:	4a030583 	eor	w3, w12, w3, lsl #1
        a[0] ^= x ^ aes_xtime(a[0]^a[1]);
    3af8:	4a0b004c 	eor	w12, w2, w11
    3afc:	4a0c0063 	eor	w3, w3, w12
    3b00:	381fc003 	sturb	w3, [x0, #-4]
        a[1] ^= x ^ aes_xtime(a[1]^a[2]);
    3b04:	4a050143 	eor	w3, w10, w5
    3b08:	4a0b014a 	eor	w10, w10, w11
        a[3] ^= x ^ aes_xtime(a[3]^u);
    3b0c:	4a040042 	eor	w2, w2, w4
        a[2] ^= x ^ aes_xtime(a[2]^a[3]);
    3b10:	4a0b00a5 	eor	w5, w5, w11
  return (x << 1) ^ ((x >> 7) * 0x1b);
    3b14:	93471c6c 	sbfx	x12, x3, #7, #1
        a[3] ^= x ^ aes_xtime(a[3]^u);
    3b18:	4a0b0084 	eor	w4, w4, w11
  return (x << 1) ^ ((x >> 7) * 0x1b);
    3b1c:	0a1a018c 	and	w12, w12, w26
    3b20:	4a030583 	eor	w3, w12, w3, lsl #1
        a[1] ^= x ^ aes_xtime(a[1]^a[2]);
    3b24:	4a0a0063 	eor	w3, w3, w10
    3b28:	381fd003 	sturb	w3, [x0, #-3]
  return (x << 1) ^ ((x >> 7) * 0x1b);
    3b2c:	93471c23 	sbfx	x3, x1, #7, #1
    3b30:	0a1a0063 	and	w3, w3, w26
    3b34:	4a010461 	eor	w1, w3, w1, lsl #1
        a[2] ^= x ^ aes_xtime(a[2]^a[3]);
    3b38:	4a050021 	eor	w1, w1, w5
    3b3c:	381fe001 	sturb	w1, [x0, #-2]
  return (x << 1) ^ ((x >> 7) * 0x1b);
    3b40:	93471c41 	sbfx	x1, x2, #7, #1
    3b44:	0a1a0021 	and	w1, w1, w26
    3b48:	4a020422 	eor	w2, w1, w2, lsl #1
        a[3] ^= x ^ aes_xtime(a[3]^u);
    3b4c:	4a040042 	eor	w2, w2, w4
    3b50:	381ff002 	sturb	w2, [x0, #-1]
      for(int c = 0; c < 4; c++){
    3b54:	7100113f 	cmp	w9, #0x4
    3b58:	54fffb81 	b.ne	3ac8 <ssh_aes128_ctr_xor+0x164>  // b.any
    3b5c:	d2800020 	mov	x0, #0x1                   	// #1
    for(int i = 0; i < 16; i++) s[i] ^= round_key[16*round+i];
    3b60:	8b000302 	add	x2, x24, x0
    3b64:	386068e3 	ldrb	w3, [x7, x0]
    3b68:	91000400 	add	x0, x0, #0x1
    3b6c:	385ff041 	ldurb	w1, [x2, #-1]
    3b70:	4a030021 	eor	w1, w1, w3
    3b74:	381ff041 	sturb	w1, [x2, #-1]
    3b78:	f100441f 	cmp	x0, #0x11
    3b7c:	54ffff21 	b.ne	3b60 <ssh_aes128_ctr_xor+0x1fc>  // b.any
  for(int round = 1; round <= 10; round++){
    3b80:	110004c6 	add	w6, w6, #0x1
    3b84:	910040e7 	add	x7, x7, #0x10
    3b88:	71002cdf 	cmp	w6, #0xb
    3b8c:	54fff481 	b.ne	3a1c <ssh_aes128_ctr_xor+0xb8>  // b.any
  memmove(block, s, 16);
    3b90:	aa1803e1 	mov	x1, x24
    3b94:	52800202 	mov	w2, #0x10                  	// #16
    3b98:	91030260 	add	x0, x19, #0xc0
    3b9c:	97fffa75 	bl	2570 <memmove>
      for(int j = 15; j >= 0 && ++ctx->counter[j] == 0; j--)
    3ba0:	9102fe61 	add	x1, x19, #0xbf
    3ba4:	9102be62 	add	x2, x19, #0xaf
    3ba8:	39400020 	ldrb	w0, [x1]
    3bac:	11000400 	add	w0, w0, #0x1
    3bb0:	12001c00 	and	w0, w0, #0xff
    3bb4:	39000020 	strb	w0, [x1]
    3bb8:	35000080 	cbnz	w0, 3bc8 <ssh_aes128_ctr_xor+0x264>
    3bbc:	d1000421 	sub	x1, x1, #0x1
    3bc0:	eb01005f 	cmp	x2, x1
    3bc4:	54ffff21 	b.ne	3ba8 <ssh_aes128_ctr_xor+0x244>  // b.any
  for(int round = 1; round <= 10; round++){
    3bc8:	52800201 	mov	w1, #0x10                  	// #16
    data[i] ^= ctx->stream[16 - ctx->available--];
    3bcc:	51000420 	sub	w0, w1, #0x1
    3bd0:	b900d260 	str	w0, [x19, #208]
    3bd4:	52800200 	mov	w0, #0x10                  	// #16
    3bd8:	4b010000 	sub	w0, w0, w1
    3bdc:	38796aa1 	ldrb	w1, [x21, x25]
    3be0:	8b20c260 	add	x0, x19, w0, sxtw
    3be4:	39430000 	ldrb	w0, [x0, #192]
    3be8:	4a010000 	eor	w0, w0, w1
    3bec:	38396aa0 	strb	w0, [x21, x25]
  for(int i = 0; i < length; i++){
    3bf0:	91000739 	add	x25, x25, #0x1
    3bf4:	17ffff6a 	b	399c <ssh_aes128_ctr_xor+0x38>

0000000000003bf8 <ld32>:
{
  u32 u = x[3];
  u = (u<<8)|x[2];
  u = (u<<8)|x[1];
  return (u<<8)|x[0];
}
    3bf8:	b9400000 	ldr	w0, [x0]
    3bfc:	d65f03c0 	ret

0000000000003c00 <add1305>:
  return crypto_stream_salsa20_xor(c,m,d,n+16,s);
}

sv add1305(u32 *h,const u32 *c)
{
  u32 j,u = 0;
    3c00:	d2800003 	mov	x3, #0x0                   	// #0
  FOR(j,17) {
    3c04:	d2800002 	mov	x2, #0x0                   	// #0
    u += h[j] + c[j];
    3c08:	f8627804 	ldr	x4, [x0, x2, lsl #3]
    3c0c:	f8627825 	ldr	x5, [x1, x2, lsl #3]
    3c10:	8b050084 	add	x4, x4, x5
    3c14:	8b030083 	add	x3, x4, x3
    h[j] = u & 255;
    3c18:	92401c64 	and	x4, x3, #0xff
    3c1c:	f8227804 	str	x4, [x0, x2, lsl #3]
  FOR(j,17) {
    3c20:	91000442 	add	x2, x2, #0x1
    u >>= 8;
    3c24:	d348fc63 	lsr	x3, x3, #8
  FOR(j,17) {
    3c28:	f100445f 	cmp	x2, #0x11
    3c2c:	54fffee1 	b.ne	3c08 <add1305+0x8>  // b.any
  }
}
    3c30:	d65f03c0 	ret

0000000000003c34 <set25519>:
  FOR(i,32) m[i] = 0;
  return 0;
}

sv set25519(gf r, const gf a)
{
    3c34:	d2800002 	mov	x2, #0x0                   	// #0
  int i;
  FOR(i,16) r[i]=a[i];
    3c38:	f8626823 	ldr	x3, [x1, x2]
    3c3c:	f8226803 	str	x3, [x0, x2]
    3c40:	91002042 	add	x2, x2, #0x8
    3c44:	f102005f 	cmp	x2, #0x80
    3c48:	54ffff81 	b.ne	3c38 <set25519+0x4>  // b.any
}
    3c4c:	d65f03c0 	ret

0000000000003c50 <car25519>:

sv car25519(gf o)
{
    3c50:	d2800001 	mov	x1, #0x0                   	// #0
  int i;
  i64 c;
  FOR(i,16) {
    o[i]+=(1LL<<16);
    c=o[i]>>16;
    o[(i+1)*(i<15)]+=c-1+37*(c-1)*(i==15);
    3c54:	d28004a6 	mov	x6, #0x25                  	// #37
    o[i]+=(1LL<<16);
    3c58:	f8617802 	ldr	x2, [x0, x1, lsl #3]
    o[(i+1)*(i<15)]+=c-1+37*(c-1)*(i==15);
    3c5c:	f1003c3f 	cmp	x1, #0xf
    3c60:	1a8107e3 	csinc	w3, wzr, w1, eq	// eq = none
    o[i]+=(1LL<<16);
    3c64:	91404042 	add	x2, x2, #0x10, lsl #12
    3c68:	f8217802 	str	x2, [x0, x1, lsl #3]
    o[(i+1)*(i<15)]+=c-1+37*(c-1)*(i==15);
    3c6c:	d37d7c63 	ubfiz	x3, x3, #3, #32
    c=o[i]>>16;
    3c70:	9350fc44 	asr	x4, x2, #16
    o[i]-=c<<16;
    3c74:	9270bc42 	and	x2, x2, #0xffffffffffff0000
    o[(i+1)*(i<15)]+=c-1+37*(c-1)*(i==15);
    3c78:	d1000484 	sub	x4, x4, #0x1
    3c7c:	9a9f0085 	csel	x5, x4, xzr, eq	// eq = none
    3c80:	9b0610a5 	madd	x5, x5, x6, x4
    3c84:	f8636804 	ldr	x4, [x0, x3]
    3c88:	8b050084 	add	x4, x4, x5
    3c8c:	f8236804 	str	x4, [x0, x3]
    o[i]-=c<<16;
    3c90:	f8617803 	ldr	x3, [x0, x1, lsl #3]
    3c94:	cb020062 	sub	x2, x3, x2
    3c98:	f8217802 	str	x2, [x0, x1, lsl #3]
  FOR(i,16) {
    3c9c:	91000421 	add	x1, x1, #0x1
    3ca0:	f100403f 	cmp	x1, #0x10
    3ca4:	54fffda1 	b.ne	3c58 <car25519+0x8>  // b.any
  }
}
    3ca8:	d65f03c0 	ret

0000000000003cac <sel25519>:

sv sel25519(gf p,gf q,int b)
{
  i64 t,i,c=~(b-1);
  FOR(i,16) {
    3cac:	2a0203e6 	mov	w6, w2
    t= c&(p[i]^q[i]);
    p[i]^=t;
    3cb0:	12000042 	and	w2, w2, #0x1
  FOR(i,16) {
    3cb4:	d2800003 	mov	x3, #0x0                   	// #0
    t= c&(p[i]^q[i]);
    3cb8:	f8637825 	ldr	x5, [x1, x3, lsl #3]
    p[i]^=t;
    3cbc:	7100005f 	cmp	w2, #0x0
    t= c&(p[i]^q[i]);
    3cc0:	f8637804 	ldr	x4, [x0, x3, lsl #3]
    p[i]^=t;
    3cc4:	9a8410a7 	csel	x7, x5, x4, ne	// ne = any
    t= c&(p[i]^q[i]);
    3cc8:	ca050084 	eor	x4, x4, x5
    p[i]^=t;
    3ccc:	f8237807 	str	x7, [x0, x3, lsl #3]
    q[i]^=t;
    3cd0:	f8637825 	ldr	x5, [x1, x3, lsl #3]
    t= c&(p[i]^q[i]);
    3cd4:	9b067c84 	mul	x4, x4, x6
    q[i]^=t;
    3cd8:	ca0400a4 	eor	x4, x5, x4
    3cdc:	f8237824 	str	x4, [x1, x3, lsl #3]
  FOR(i,16) {
    3ce0:	91000463 	add	x3, x3, #0x1
    3ce4:	f100407f 	cmp	x3, #0x10
    3ce8:	54fffe81 	b.ne	3cb8 <sel25519+0xc>  // b.any
  }
}
    3cec:	d65f03c0 	ret

0000000000003cf0 <pack25519>:

sv pack25519(u8 *o,const gf n)
{
    3cf0:	a9af7bfd 	stp	x29, x30, [sp, #-272]!
    3cf4:	aa0003e8 	mov	x8, x0
    3cf8:	d2800002 	mov	x2, #0x0                   	// #0
  int i,j,b;
  gf m,t;
  FOR(i,16) t[i]=n[i];
    3cfc:	910243e0 	add	x0, sp, #0x90
{
    3d00:	910003fd 	mov	x29, sp
  FOR(i,16) t[i]=n[i];
    3d04:	f8626823 	ldr	x3, [x1, x2]
    3d08:	f8206843 	str	x3, [x2, x0]
    3d0c:	91002042 	add	x2, x2, #0x8
    3d10:	f102005f 	cmp	x2, #0x80
    3d14:	54ffff81 	b.ne	3d04 <pack25519+0x14>  // b.any
  car25519(t);
  car25519(t);
  car25519(t);
    3d18:	52800049 	mov	w9, #0x2                   	// #2
  car25519(t);
    3d1c:	97ffffcd 	bl	3c50 <car25519>
  car25519(t);
    3d20:	97ffffcc 	bl	3c50 <car25519>
  car25519(t);
    3d24:	97ffffcb 	bl	3c50 <car25519>
  FOR(j,2) {
    m[0]=t[0]-0xffed;
    3d28:	f9404be1 	ldr	x1, [sp, #144]
    3d2c:	929ffd85 	mov	x5, #0xffffffffffff0013    	// #-65517
    3d30:	d2800023 	mov	x3, #0x1                   	// #1
    3d34:	8b050021 	add	x1, x1, x5
    3d38:	f9000be1 	str	x1, [sp, #16]
    for(i=1;i<15;i++) {
    3d3c:	910043e1 	add	x1, sp, #0x10
      m[i]=t[i]-0xffff-((m[i-1]>>16)&1);
    3d40:	f8637802 	ldr	x2, [x0, x3, lsl #3]
    3d44:	929fffc4 	mov	x4, #0xffffffffffff0001    	// #-65535
    for(i=1;i<15;i++) {
    3d48:	91000463 	add	x3, x3, #0x1
      m[i]=t[i]-0xffff-((m[i-1]>>16)&1);
    3d4c:	8b040042 	add	x2, x2, x4
    3d50:	f9400024 	ldr	x4, [x1]
    3d54:	d3504085 	ubfx	x5, x4, #16, #1
      m[i-1]&=0xffff;
    3d58:	92403c84 	and	x4, x4, #0xffff
      m[i]=t[i]-0xffff-((m[i-1]>>16)&1);
    3d5c:	cb050042 	sub	x2, x2, x5
    3d60:	a8808824 	stp	x4, x2, [x1], #8
    for(i=1;i<15;i++) {
    3d64:	f1003c7f 	cmp	x3, #0xf
    3d68:	54fffec1 	b.ne	3d40 <pack25519+0x50>  // b.any
    }
    m[15]=t[15]-0x7fff-((m[14]>>16)&1);
    3d6c:	f94043e1 	ldr	x1, [sp, #128]
    3d70:	928fffc3 	mov	x3, #0xffffffffffff8001    	// #-32767
    3d74:	f94087e2 	ldr	x2, [sp, #264]
    3d78:	8b030042 	add	x2, x2, x3
    3d7c:	d3504023 	ubfx	x3, x1, #16, #1
    3d80:	cb030042 	sub	x2, x2, x3
    b=(m[15]>>16)&1;
    m[14]&=0xffff;
    3d84:	92403c21 	and	x1, x1, #0xffff
    3d88:	a9080be1 	stp	x1, x2, [sp, #128]
    sel25519(t,m,1-b);
    3d8c:	910043e1 	add	x1, sp, #0x10
    b=(m[15]>>16)&1;
    3d90:	9350fc42 	asr	x2, x2, #16
    sel25519(t,m,1-b);
    3d94:	2a2203e2 	mvn	w2, w2
    3d98:	12000042 	and	w2, w2, #0x1
    3d9c:	97ffffc4 	bl	3cac <sel25519>
  FOR(j,2) {
    3da0:	7100053f 	cmp	w9, #0x1
    3da4:	540001a1 	b.ne	3dd8 <pack25519+0xe8>  // b.any
  }
  FOR(i,16) {
    o[2*i]=t[i]&0xff;
    o[2*i+1]=t[i]>>8;
    3da8:	91000503 	add	x3, x8, #0x1
  FOR(j,2) {
    3dac:	d2800001 	mov	x1, #0x0                   	// #0
    o[2*i]=t[i]&0xff;
    3db0:	d37e7c22 	ubfiz	x2, x1, #2, #32
    3db4:	f8626802 	ldr	x2, [x0, x2]
    3db8:	38216902 	strb	w2, [x8, x1]
    o[2*i+1]=t[i]>>8;
    3dbc:	9348fc42 	asr	x2, x2, #8
    3dc0:	38216862 	strb	w2, [x3, x1]
  FOR(i,16) {
    3dc4:	91000821 	add	x1, x1, #0x2
    3dc8:	f100803f 	cmp	x1, #0x20
    3dcc:	54ffff21 	b.ne	3db0 <pack25519+0xc0>  // b.any
  }
}
    3dd0:	a8d17bfd 	ldp	x29, x30, [sp], #272
    3dd4:	d65f03c0 	ret
  FOR(j,2) {
    3dd8:	52800029 	mov	w9, #0x1                   	// #1
    3ddc:	17ffffd3 	b	3d28 <pack25519+0x38>

0000000000003de0 <unpack25519>:
}

sv unpack25519(gf o, const u8 *n)
{
  int i;
  FOR(i,16) o[i]=n[2*i]+((i64)n[2*i+1]<<8);
    3de0:	91000426 	add	x6, x1, #0x1
{
    3de4:	d2800002 	mov	x2, #0x0                   	// #0
  FOR(i,16) o[i]=n[2*i]+((i64)n[2*i+1]<<8);
    3de8:	386268c3 	ldrb	w3, [x6, x2]
    3dec:	d37e7c44 	ubfiz	x4, x2, #2, #32
    3df0:	38626825 	ldrb	w5, [x1, x2]
    3df4:	91000842 	add	x2, x2, #0x2
    3df8:	8b0320a3 	add	x3, x5, x3, lsl #8
    3dfc:	f8246803 	str	x3, [x0, x4]
    3e00:	f100805f 	cmp	x2, #0x20
    3e04:	54ffff21 	b.ne	3de8 <unpack25519+0x8>  // b.any
  o[15]&=0x7fff;
    3e08:	f9403c01 	ldr	x1, [x0, #120]
    3e0c:	92403821 	and	x1, x1, #0x7fff
    3e10:	f9003c01 	str	x1, [x0, #120]
}
    3e14:	d65f03c0 	ret

0000000000003e18 <A>:

sv A(gf o,const gf a,const gf b)
{
    3e18:	d2800003 	mov	x3, #0x0                   	// #0
  int i;
  FOR(i,16) o[i]=a[i]+b[i];
    3e1c:	f8636824 	ldr	x4, [x1, x3]
    3e20:	f8636845 	ldr	x5, [x2, x3]
    3e24:	8b050084 	add	x4, x4, x5
    3e28:	f8236804 	str	x4, [x0, x3]
    3e2c:	91002063 	add	x3, x3, #0x8
    3e30:	f102007f 	cmp	x3, #0x80
    3e34:	54ffff41 	b.ne	3e1c <A+0x4>  // b.any
}
    3e38:	d65f03c0 	ret

0000000000003e3c <Z>:

sv Z(gf o,const gf a,const gf b)
{
    3e3c:	d2800003 	mov	x3, #0x0                   	// #0
  int i;
  FOR(i,16) o[i]=a[i]-b[i];
    3e40:	f8636824 	ldr	x4, [x1, x3]
    3e44:	f8636845 	ldr	x5, [x2, x3]
    3e48:	cb050084 	sub	x4, x4, x5
    3e4c:	f8236804 	str	x4, [x0, x3]
    3e50:	91002063 	add	x3, x3, #0x8
    3e54:	f102007f 	cmp	x3, #0x80
    3e58:	54ffff41 	b.ne	3e40 <Z+0x4>  // b.any
}
    3e5c:	d65f03c0 	ret

0000000000003e60 <M>:

sv M(gf o,const gf a,const gf b)
{
    3e60:	a9af7bfd 	stp	x29, x30, [sp, #-272]!
  i64 i,j,t[31];
  FOR(i,31) t[i]=0;
    3e64:	d2800003 	mov	x3, #0x0                   	// #0
    3e68:	910063e4 	add	x4, sp, #0x18
{
    3e6c:	910003fd 	mov	x29, sp
  FOR(i,31) t[i]=0;
    3e70:	f823789f 	str	xzr, [x4, x3, lsl #3]
    3e74:	91000463 	add	x3, x3, #0x1
    3e78:	f1007c7f 	cmp	x3, #0x1f
    3e7c:	54ffffa1 	b.ne	3e70 <M+0x10>  // b.any
    3e80:	aa0403e5 	mov	x5, x4
    3e84:	aa0403e7 	mov	x7, x4
  FOR(i,16) FOR(j,16) t[i+j]+=a[i]*b[j];
    3e88:	d2800006 	mov	x6, #0x0                   	// #0
    3e8c:	f8667829 	ldr	x9, [x1, x6, lsl #3]
    3e90:	d2800003 	mov	x3, #0x0                   	// #0
    3e94:	f86378ea 	ldr	x10, [x7, x3, lsl #3]
    3e98:	f8637848 	ldr	x8, [x2, x3, lsl #3]
    3e9c:	9b082928 	madd	x8, x9, x8, x10
    3ea0:	f82378e8 	str	x8, [x7, x3, lsl #3]
    3ea4:	91000463 	add	x3, x3, #0x1
    3ea8:	f100407f 	cmp	x3, #0x10
    3eac:	54ffff41 	b.ne	3e94 <M+0x34>  // b.any
    3eb0:	910004c6 	add	x6, x6, #0x1
    3eb4:	910020e7 	add	x7, x7, #0x8
    3eb8:	f10040df 	cmp	x6, #0x10
    3ebc:	54fffe81 	b.ne	3e8c <M+0x2c>  // b.any
  FOR(i,15) t[i]+=38*t[i+16];
    3ec0:	d2800001 	mov	x1, #0x0                   	// #0
    3ec4:	d28004c6 	mov	x6, #0x26                  	// #38
    3ec8:	f94000a3 	ldr	x3, [x5]
    3ecc:	91000421 	add	x1, x1, #0x1
    3ed0:	f94040a2 	ldr	x2, [x5, #128]
    3ed4:	9b060c42 	madd	x2, x2, x6, x3
    3ed8:	f80084a2 	str	x2, [x5], #8
    3edc:	f1003c3f 	cmp	x1, #0xf
    3ee0:	54ffff41 	b.ne	3ec8 <M+0x68>  // b.any
  FOR(i,16) o[i]=t[i];
    3ee4:	d2800001 	mov	x1, #0x0                   	// #0
    3ee8:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    3eec:	f8217802 	str	x2, [x0, x1, lsl #3]
    3ef0:	91000421 	add	x1, x1, #0x1
    3ef4:	f100403f 	cmp	x1, #0x10
    3ef8:	54ffff81 	b.ne	3ee8 <M+0x88>  // b.any
  car25519(o);
    3efc:	97ffff55 	bl	3c50 <car25519>
  car25519(o);
}
    3f00:	a8d17bfd 	ldp	x29, x30, [sp], #272
  car25519(o);
    3f04:	17ffff53 	b	3c50 <car25519>

0000000000003f08 <S>:

sv S(gf o,const gf a)
{
    3f08:	aa0103e2 	mov	x2, x1
  M(o,a,a);
    3f0c:	17ffffd5 	b	3e60 <M>

0000000000003f10 <inv25519>:
}

sv inv25519(gf o,const gf i)
{
    3f10:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    3f14:	aa0003ed 	mov	x13, x0
    3f18:	aa0103ee 	mov	x14, x1
  gf c;
  int a;
  FOR(a,16) c[a]=i[a];
    3f1c:	910043ec 	add	x12, sp, #0x10
{
    3f20:	d2800001 	mov	x1, #0x0                   	// #0
    3f24:	910003fd 	mov	x29, sp
  FOR(a,16) c[a]=i[a];
    3f28:	f86169c0 	ldr	x0, [x14, x1]
    3f2c:	f82c6820 	str	x0, [x1, x12]
    3f30:	91002021 	add	x1, x1, #0x8
    3f34:	f102003f 	cmp	x1, #0x80
    3f38:	54ffff81 	b.ne	3f28 <inv25519+0x18>  // b.any
  for(a=253;a>=0;a--) {
    3f3c:	52801fab 	mov	w11, #0xfd                  	// #253
    S(c,c);
    3f40:	aa0c03e1 	mov	x1, x12
    3f44:	aa0c03e0 	mov	x0, x12
    3f48:	97fffff0 	bl	3f08 <S>
    if(a!=2&&a!=4) M(c,c,i);
    3f4c:	7100097f 	cmp	w11, #0x2
    3f50:	7a441964 	ccmp	w11, #0x4, #0x4, ne	// ne = any
    3f54:	54000061 	b.ne	3f60 <inv25519+0x50>  // b.any
  for(a=253;a>=0;a--) {
    3f58:	5100056b 	sub	w11, w11, #0x1
    3f5c:	17fffff9 	b	3f40 <inv25519+0x30>
    if(a!=2&&a!=4) M(c,c,i);
    3f60:	aa0e03e2 	mov	x2, x14
    3f64:	aa0c03e1 	mov	x1, x12
  for(a=253;a>=0;a--) {
    3f68:	5100056b 	sub	w11, w11, #0x1
    if(a!=2&&a!=4) M(c,c,i);
    3f6c:	97ffffbd 	bl	3e60 <M>
  for(a=253;a>=0;a--) {
    3f70:	3100057f 	cmn	w11, #0x1
    3f74:	54fffe61 	b.ne	3f40 <inv25519+0x30>  // b.any
    3f78:	d2800002 	mov	x2, #0x0                   	// #0
  }
  FOR(a,16) o[a]=c[a];
    3f7c:	f8626980 	ldr	x0, [x12, x2]
    3f80:	f82269a0 	str	x0, [x13, x2]
    3f84:	91002042 	add	x2, x2, #0x8
    3f88:	f102005f 	cmp	x2, #0x80
    3f8c:	54ffff81 	b.ne	3f7c <inv25519+0x6c>  // b.any
}
    3f90:	a8c97bfd 	ldp	x29, x30, [sp], #144
    3f94:	d65f03c0 	ret

0000000000003f98 <add>:

  return 0;
}

sv add(gf p[4],gf q[4])
{
    3f98:	d11243ff 	sub	sp, sp, #0x490
    3f9c:	aa0103ec 	mov	x12, x1
  gf a,b,c,d,t,e,f,g,h;
  
  Z(a, p[1], p[0]);
    3fa0:	91020001 	add	x1, x0, #0x80
{
    3fa4:	aa0003eb 	mov	x11, x0
  Z(a, p[1], p[0]);
    3fa8:	aa0003e2 	mov	x2, x0
    3fac:	910043e0 	add	x0, sp, #0x10
{
    3fb0:	a9007bfd 	stp	x29, x30, [sp]
    3fb4:	910003fd 	mov	x29, sp
  Z(a, p[1], p[0]);
    3fb8:	97ffffa1 	bl	3e3c <Z>
  Z(t, q[1], q[0]);
    3fbc:	91020181 	add	x1, x12, #0x80
    3fc0:	910843e0 	add	x0, sp, #0x210
    3fc4:	aa0c03e2 	mov	x2, x12
    3fc8:	97ffff9d 	bl	3e3c <Z>
  M(a, a, t);
    3fcc:	910043e1 	add	x1, sp, #0x10
    3fd0:	aa0003e2 	mov	x2, x0
    3fd4:	aa0103e0 	mov	x0, x1
    3fd8:	97ffffa2 	bl	3e60 <M>
  A(b, p[0], p[1]);
    3fdc:	aa0b03e1 	mov	x1, x11
    3fe0:	91020162 	add	x2, x11, #0x80
    3fe4:	910243e0 	add	x0, sp, #0x90
    3fe8:	97ffff8c 	bl	3e18 <A>
  A(t, q[0], q[1]);
    3fec:	aa0c03e1 	mov	x1, x12
    3ff0:	910843e0 	add	x0, sp, #0x210
    3ff4:	91020182 	add	x2, x12, #0x80
    3ff8:	97ffff88 	bl	3e18 <A>
  M(b, b, t);
    3ffc:	910243e1 	add	x1, sp, #0x90
    4000:	aa0003e2 	mov	x2, x0
    4004:	aa0103e0 	mov	x0, x1
    4008:	97ffff96 	bl	3e60 <M>
  M(c, p[3], q[3]);
    400c:	91060182 	add	x2, x12, #0x180
    4010:	910443e0 	add	x0, sp, #0x110
    4014:	91060161 	add	x1, x11, #0x180
    4018:	97ffff92 	bl	3e60 <M>
  M(c, c, D2);
    401c:	aa0003e1 	mov	x1, x0
    4020:	d0000002 	adrp	x2, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4024:	91098042 	add	x2, x2, #0x260
    4028:	97ffff8e 	bl	3e60 <M>
  M(d, p[2], q[2]);
    402c:	91040182 	add	x2, x12, #0x100
    4030:	910643e0 	add	x0, sp, #0x190
    4034:	91040161 	add	x1, x11, #0x100
    4038:	97ffff8a 	bl	3e60 <M>
  A(d, d, d);
    403c:	aa0003e2 	mov	x2, x0
    4040:	aa0003e1 	mov	x1, x0
    4044:	97ffff75 	bl	3e18 <A>
  Z(e, b, a);
    4048:	910a43e0 	add	x0, sp, #0x290
    404c:	910043e2 	add	x2, sp, #0x10
    4050:	910243e1 	add	x1, sp, #0x90
    4054:	97ffff7a 	bl	3e3c <Z>
  Z(f, d, c);
    4058:	910c43e0 	add	x0, sp, #0x310
    405c:	910443e2 	add	x2, sp, #0x110
    4060:	910643e1 	add	x1, sp, #0x190
    4064:	97ffff76 	bl	3e3c <Z>
  A(g, d, c);
    4068:	910e43e0 	add	x0, sp, #0x390
    406c:	97ffff6b 	bl	3e18 <A>
  A(h, b, a);
    4070:	910043e2 	add	x2, sp, #0x10
    4074:	910243e1 	add	x1, sp, #0x90
    4078:	911043e0 	add	x0, sp, #0x410
    407c:	97ffff67 	bl	3e18 <A>

  M(p[0], e, f);
    4080:	910c43e2 	add	x2, sp, #0x310
    4084:	910a43e1 	add	x1, sp, #0x290
    4088:	aa0b03e0 	mov	x0, x11
    408c:	97ffff75 	bl	3e60 <M>
  M(p[1], h, g);
    4090:	91020160 	add	x0, x11, #0x80
    4094:	910e43e2 	add	x2, sp, #0x390
    4098:	911043e1 	add	x1, sp, #0x410
    409c:	97ffff71 	bl	3e60 <M>
  M(p[2], g, f);
    40a0:	91040160 	add	x0, x11, #0x100
    40a4:	910c43e2 	add	x2, sp, #0x310
    40a8:	910e43e1 	add	x1, sp, #0x390
    40ac:	97ffff6d 	bl	3e60 <M>
  M(p[3], e, h);
    40b0:	91060160 	add	x0, x11, #0x180
    40b4:	911043e2 	add	x2, sp, #0x410
    40b8:	910a43e1 	add	x1, sp, #0x290
    40bc:	97ffff69 	bl	3e60 <M>
}
    40c0:	a9407bfd 	ldp	x29, x30, [sp]
    40c4:	911243ff 	add	sp, sp, #0x490
    40c8:	d65f03c0 	ret

00000000000040cc <modL>:
{
  i64 carry,i,j;
  for (i = 63;i >= 32;--i) {
    carry = 0;
    for (j = i - 32;j < i - 12;++j) {
      x[j] += carry - 16 * x[i] * L[j - (i - 32)];
    40cc:	d0000005 	adrp	x5, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    40d0:	910980a5 	add	x5, x5, #0x260
    40d4:	9103e023 	add	x3, x1, #0xf8
    40d8:	910200a5 	add	x5, x5, #0x80
{
    40dc:	d28003e7 	mov	x7, #0x1f                  	// #31
    for (j = i - 32;j < i - 12;++j) {
    40e0:	d2800004 	mov	x4, #0x0                   	// #0
    carry = 0;
    40e4:	d2800008 	mov	x8, #0x0                   	// #0
      carry = (x[j] + 128) >> 8;
      x[j] -= carry << 8;
    }
    x[j] += carry;
    40e8:	f8646866 	ldr	x6, [x3, x4]
    for (j = i - 32;j < i - 12;++j) {
    40ec:	f102809f 	cmp	x4, #0xa0
    40f0:	8b0800c6 	add	x6, x6, x8
    40f4:	540005a1 	b.ne	41a8 <modL+0xdc>  // b.any
  for (i = 63;i >= 32;--i) {
    40f8:	d10004e7 	sub	x7, x7, #0x1
    x[j] += carry;
    40fc:	f9005066 	str	x6, [x3, #160]
    x[i] = 0;
    4100:	f900807f 	str	xzr, [x3, #256]
  for (i = 63;i >= 32;--i) {
    4104:	d1002063 	sub	x3, x3, #0x8
    4108:	b10004ff 	cmn	x7, #0x1
    410c:	54fffea1 	b.ne	40e0 <modL+0x14>  // b.any
  }
  carry = 0;
  FOR(j,32) {
    x[j] += carry - (x[31] >> 4) * L[j];
    4110:	d0000003 	adrp	x3, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4114:	91098063 	add	x3, x3, #0x260
    4118:	91020068 	add	x8, x3, #0x80
  FOR(j,32) {
    411c:	d2800004 	mov	x4, #0x0                   	// #0
  carry = 0;
    4120:	d2800005 	mov	x5, #0x0                   	// #0
    x[j] += carry - (x[31] >> 4) * L[j];
    4124:	f9407c22 	ldr	x2, [x1, #248]
    4128:	f8647827 	ldr	x7, [x1, x4, lsl #3]
    412c:	f8647906 	ldr	x6, [x8, x4, lsl #3]
    4130:	9344fc42 	asr	x2, x2, #4
    4134:	9b069c42 	msub	x2, x2, x6, x7
    4138:	8b050042 	add	x2, x2, x5
    carry = x[j] >> 8;
    413c:	9348fc45 	asr	x5, x2, #8
    x[j] &= 255;
    4140:	92401c42 	and	x2, x2, #0xff
    4144:	f8247822 	str	x2, [x1, x4, lsl #3]
  FOR(j,32) {
    4148:	91000484 	add	x4, x4, #0x1
    414c:	f100809f 	cmp	x4, #0x20
    4150:	54fffea1 	b.ne	4124 <modL+0x58>  // b.any
  }
  FOR(j,32) x[j] -= carry * L[j];
    4154:	91020063 	add	x3, x3, #0x80
    4158:	d2800002 	mov	x2, #0x0                   	// #0
    415c:	f8627826 	ldr	x6, [x1, x2, lsl #3]
    4160:	f8627864 	ldr	x4, [x3, x2, lsl #3]
    4164:	9b0498a4 	msub	x4, x5, x4, x6
    4168:	f8227824 	str	x4, [x1, x2, lsl #3]
    416c:	91000442 	add	x2, x2, #0x1
    4170:	f100805f 	cmp	x2, #0x20
    4174:	54ffff41 	b.ne	415c <modL+0x90>  // b.any
    4178:	91002024 	add	x4, x1, #0x8
  FOR(i,32) {
    417c:	d2800002 	mov	x2, #0x0                   	// #0
    x[i+1] += x[i] >> 8;
    4180:	f8627823 	ldr	x3, [x1, x2, lsl #3]
    4184:	f8627885 	ldr	x5, [x4, x2, lsl #3]
    4188:	8b8320a3 	add	x3, x5, x3, asr #8
    418c:	f8227883 	str	x3, [x4, x2, lsl #3]
    r[i] = x[i] & 255;
    4190:	f8627823 	ldr	x3, [x1, x2, lsl #3]
    4194:	38226803 	strb	w3, [x0, x2]
  FOR(i,32) {
    4198:	91000442 	add	x2, x2, #0x1
    419c:	f100805f 	cmp	x2, #0x20
    41a0:	54ffff01 	b.ne	4180 <modL+0xb4>  // b.any
  }
}
    41a4:	d65f03c0 	ret
      x[j] += carry - 16 * x[i] * L[j - (i - 32)];
    41a8:	f8656888 	ldr	x8, [x4, x5]
    41ac:	f9408062 	ldr	x2, [x3, #256]
    41b0:	9b087c42 	mul	x2, x2, x8
    41b4:	cb0210c2 	sub	x2, x6, x2, lsl #4
      carry = (x[j] + 128) >> 8;
    41b8:	91020046 	add	x6, x2, #0x80
    41bc:	9348fcc8 	asr	x8, x6, #8
      x[j] -= carry << 8;
    41c0:	9278dcc6 	and	x6, x6, #0xffffffffffffff00
    41c4:	cb060042 	sub	x2, x2, x6
    41c8:	f8246862 	str	x2, [x3, x4]
    for (j = i - 32;j < i - 12;++j) {
    41cc:	91002084 	add	x4, x4, #0x8
    41d0:	17ffffc6 	b	40e8 <modL+0x1c>

00000000000041d4 <reduce>:

sv reduce(u8 *r)
{
    41d4:	d10843ff 	sub	sp, sp, #0x210
  i64 x[64],i;
  FOR(i,64) x[i] = (u64) r[i];
    41d8:	d2800001 	mov	x1, #0x0                   	// #0
{
    41dc:	a9007bfd 	stp	x29, x30, [sp]
    41e0:	910003fd 	mov	x29, sp
  FOR(i,64) x[i] = (u64) r[i];
    41e4:	910043e3 	add	x3, sp, #0x10
    41e8:	38616802 	ldrb	w2, [x0, x1]
    41ec:	f8217862 	str	x2, [x3, x1, lsl #3]
    41f0:	91000421 	add	x1, x1, #0x1
    41f4:	f101003f 	cmp	x1, #0x40
    41f8:	54ffff61 	b.ne	41e4 <reduce+0x10>  // b.any
  FOR(i,64) r[i] = 0;
    41fc:	d2800001 	mov	x1, #0x0                   	// #0
    4200:	3821681f 	strb	wzr, [x0, x1]
    4204:	91000421 	add	x1, x1, #0x1
    4208:	f101003f 	cmp	x1, #0x40
    420c:	54ffffa1 	b.ne	4200 <reduce+0x2c>  // b.any
  modL(r,x);
    4210:	910043e1 	add	x1, sp, #0x10
    4214:	97ffffae 	bl	40cc <modL>
}
    4218:	a9407bfd 	ldp	x29, x30, [sp]
    421c:	910843ff 	add	sp, sp, #0x210
    4220:	d65f03c0 	ret

0000000000004224 <pack>:
{
    4224:	a9a57bfd 	stp	x29, x30, [sp, #-432]!
    4228:	aa0003ef 	mov	x15, x0
    422c:	aa0103f2 	mov	x18, x1
    4230:	910003fd 	mov	x29, sp
  inv25519(zi, p[2]); 
    4234:	9104c3e0 	add	x0, sp, #0x130
    4238:	91040021 	add	x1, x1, #0x100
    423c:	97ffff35 	bl	3f10 <inv25519>
  M(tx, p[0], zi);
    4240:	9104c3e2 	add	x2, sp, #0x130
    4244:	aa1203e1 	mov	x1, x18
    4248:	9100c3e0 	add	x0, sp, #0x30
    424c:	97ffff05 	bl	3e60 <M>
  M(ty, p[1], zi);
    4250:	9104c3e2 	add	x2, sp, #0x130
    4254:	9102c3e0 	add	x0, sp, #0xb0
    4258:	91020241 	add	x1, x18, #0x80
    425c:	97ffff01 	bl	3e60 <M>
  pack25519(r, ty);
    4260:	aa0003e1 	mov	x1, x0
    4264:	aa0f03e0 	mov	x0, x15
    4268:	97fffea2 	bl	3cf0 <pack25519>
  pack25519(d,a);
    426c:	9100c3e1 	add	x1, sp, #0x30
    4270:	910043e0 	add	x0, sp, #0x10
    4274:	97fffe9f 	bl	3cf0 <pack25519>
  return d[0]&1;
    4278:	394043e0 	ldrb	w0, [sp, #16]
  r[31] ^= par25519(tx) << 7;
    427c:	39407de1 	ldrb	w1, [x15, #31]
    4280:	4a001c20 	eor	w0, w1, w0, lsl #7
    4284:	39007de0 	strb	w0, [x15, #31]
}
    4288:	a8db7bfd 	ldp	x29, x30, [sp], #432
    428c:	d65f03c0 	ret

0000000000004290 <scalarmult>:
{
    4290:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  set25519(p[0],gf0);
    4294:	d0000004 	adrp	x4, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4298:	91098084 	add	x4, x4, #0x260
{
    429c:	910003fd 	mov	x29, sp
    42a0:	aa0003ed 	mov	x13, x0
    42a4:	aa0103f2 	mov	x18, x1
  set25519(p[0],gf0);
    42a8:	91060081 	add	x1, x4, #0x180
{
    42ac:	f9000bf3 	str	x19, [sp, #16]
    42b0:	aa0203f3 	mov	x19, x2
  set25519(p[0],gf0);
    42b4:	97fffe60 	bl	3c34 <set25519>
  set25519(p[1],gf1);
    42b8:	91020000 	add	x0, x0, #0x80
    42bc:	91080081 	add	x1, x4, #0x200
    42c0:	97fffe5d 	bl	3c34 <set25519>
  set25519(p[2],gf1);
    42c4:	910401a0 	add	x0, x13, #0x100
  for (i = 255;i >= 0;--i) {
    42c8:	52801fef 	mov	w15, #0xff                  	// #255
  set25519(p[2],gf1);
    42cc:	97fffe5a 	bl	3c34 <set25519>
  set25519(p[3],gf0);
    42d0:	91060081 	add	x1, x4, #0x180
    42d4:	910601a0 	add	x0, x13, #0x180
    42d8:	97fffe57 	bl	3c34 <set25519>
    u8 b = (s[i/8]>>(i&7))&1;
    42dc:	13037de0 	asr	w0, w15, #3
    sel25519(p[i],q[i],b);
    42e0:	d2800008 	mov	x8, #0x0                   	// #0
    u8 b = (s[i/8]>>(i&7))&1;
    42e4:	38606a6e 	ldrb	w14, [x19, x0]
    42e8:	120009e0 	and	w0, w15, #0x7
    42ec:	1ac029ce 	asr	w14, w14, w0
    sel25519(p[i],q[i],b);
    42f0:	120001ce 	and	w14, w14, #0x1
    42f4:	8b080241 	add	x1, x18, x8
    42f8:	8b0801a0 	add	x0, x13, x8
    42fc:	2a0e03e2 	mov	w2, w14
  FOR(i,4)
    4300:	91020108 	add	x8, x8, #0x80
    sel25519(p[i],q[i],b);
    4304:	97fffe6a 	bl	3cac <sel25519>
  FOR(i,4)
    4308:	f108011f 	cmp	x8, #0x200
    430c:	54ffff41 	b.ne	42f4 <scalarmult+0x64>  // b.any
    add(q,p);
    4310:	aa0d03e1 	mov	x1, x13
    4314:	aa1203e0 	mov	x0, x18
    4318:	97ffff20 	bl	3f98 <add>
    add(p,p);
    431c:	aa0d03e1 	mov	x1, x13
    4320:	aa0d03e0 	mov	x0, x13
    4324:	97ffff1d 	bl	3f98 <add>
    4328:	d2800008 	mov	x8, #0x0                   	// #0
    sel25519(p[i],q[i],b);
    432c:	8b080241 	add	x1, x18, x8
    4330:	8b0801a0 	add	x0, x13, x8
    4334:	2a0e03e2 	mov	w2, w14
  FOR(i,4)
    4338:	91020108 	add	x8, x8, #0x80
    sel25519(p[i],q[i],b);
    433c:	97fffe5c 	bl	3cac <sel25519>
  FOR(i,4)
    4340:	f108011f 	cmp	x8, #0x200
    4344:	54ffff41 	b.ne	432c <scalarmult+0x9c>  // b.any
  for (i = 255;i >= 0;--i) {
    4348:	510005ef 	sub	w15, w15, #0x1
    434c:	310005ff 	cmn	w15, #0x1
    4350:	54fffc61 	b.ne	42dc <scalarmult+0x4c>  // b.any
}
    4354:	f9400bf3 	ldr	x19, [sp, #16]
    4358:	a8c27bfd 	ldp	x29, x30, [sp], #32
    435c:	d65f03c0 	ret

0000000000004360 <scalarbase>:
{
    4360:	d10843ff 	sub	sp, sp, #0x210
  set25519(q[0],X);
    4364:	d0000004 	adrp	x4, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4368:	91098084 	add	x4, x4, #0x260
{
    436c:	aa0003eb 	mov	x11, x0
    4370:	aa0103ec 	mov	x12, x1
  set25519(q[0],X);
    4374:	910043e0 	add	x0, sp, #0x10
{
    4378:	a9007bfd 	stp	x29, x30, [sp]
  set25519(q[0],X);
    437c:	910a0081 	add	x1, x4, #0x280
{
    4380:	910003fd 	mov	x29, sp
  set25519(q[0],X);
    4384:	97fffe2c 	bl	3c34 <set25519>
  set25519(q[1],Y);
    4388:	910c0081 	add	x1, x4, #0x300
    438c:	910243e0 	add	x0, sp, #0x90
    4390:	97fffe29 	bl	3c34 <set25519>
  set25519(q[2],gf1);
    4394:	91080081 	add	x1, x4, #0x200
    4398:	910443e0 	add	x0, sp, #0x110
    439c:	97fffe26 	bl	3c34 <set25519>
  M(q[3],X,Y);
    43a0:	910c0082 	add	x2, x4, #0x300
    43a4:	910a0081 	add	x1, x4, #0x280
    43a8:	910643e0 	add	x0, sp, #0x190
    43ac:	97fffead 	bl	3e60 <M>
  scalarmult(p,q,s);
    43b0:	910043e1 	add	x1, sp, #0x10
    43b4:	aa0c03e2 	mov	x2, x12
    43b8:	aa0b03e0 	mov	x0, x11
    43bc:	97ffffb5 	bl	4290 <scalarmult>
}
    43c0:	a9407bfd 	ldp	x29, x30, [sp]
    43c4:	910843ff 	add	sp, sp, #0x210
    43c8:	d65f03c0 	ret

00000000000043cc <core>:
{
    43cc:	a9a57bfd 	stp	x29, x30, [sp, #-432]!
    43d0:	aa0003e7 	mov	x7, x0
    x[11+i] = ld32(k+16+4*i);
    43d4:	9100404a 	add	x10, x2, #0x10
    43d8:	9102c3e5 	add	x5, sp, #0xb0
{
    43dc:	d2800006 	mov	x6, #0x0                   	// #0
    43e0:	aa0503e9 	mov	x9, x5
    43e4:	aa0503e8 	mov	x8, x5
    x[5*i] = ld32(c+4*i);
    43e8:	5280014c 	mov	w12, #0xa                   	// #10
{
    43ec:	910003fd 	mov	x29, sp
    x[5*i] = ld32(c+4*i);
    43f0:	9bac7ccb 	umull	x11, w6, w12
    43f4:	8b060060 	add	x0, x3, x6
    43f8:	97fffe00 	bl	3bf8 <ld32>
  FOR(i,4) {
    43fc:	91002129 	add	x9, x9, #0x8
    x[5*i] = ld32(c+4*i);
    4400:	f82b68a0 	str	x0, [x5, x11]
    x[1+i] = ld32(k+4*i);
    4404:	8b060040 	add	x0, x2, x6
    4408:	97fffdfc 	bl	3bf8 <ld32>
    440c:	f9000120 	str	x0, [x9]
    x[6+i] = ld32(in+4*i);
    4410:	8b060020 	add	x0, x1, x6
    4414:	97fffdf9 	bl	3bf8 <ld32>
    4418:	f9001520 	str	x0, [x9, #40]
    x[11+i] = ld32(k+16+4*i);
    441c:	8b060140 	add	x0, x10, x6
  FOR(i,4) {
    4420:	910010c6 	add	x6, x6, #0x4
    x[11+i] = ld32(k+16+4*i);
    4424:	97fffdf5 	bl	3bf8 <ld32>
    4428:	f9002920 	str	x0, [x9, #80]
  FOR(i,4) {
    442c:	f10040df 	cmp	x6, #0x10
    4430:	54fffe01 	b.ne	43f0 <core+0x24>  // b.any
  FOR(i,16) y[i] = x[i];
    4434:	9104c3e9 	add	x9, sp, #0x130
  FOR(i,4) {
    4438:	d2800000 	mov	x0, #0x0                   	// #0
  FOR(i,16) y[i] = x[i];
    443c:	f86068a2 	ldr	x2, [x5, x0]
    4440:	f8296802 	str	x2, [x0, x9]
    4444:	91002000 	add	x0, x0, #0x8
    4448:	f102001f 	cmp	x0, #0x80
    444c:	54ffff81 	b.ne	443c <core+0x70>  // b.any
      FOR(m,4) t[m] = x[(5*j+4*m)%16];
    4450:	910043eb 	add	x11, sp, #0x10
      FOR(m,4) w[4*j+(j+m)%4] = t[m];
    4454:	9100c3ec 	add	x12, sp, #0x30
  FOR(i,16) y[i] = x[i];
    4458:	5280028a 	mov	w10, #0x14                  	// #20
    FOR(j,4) {
    445c:	52800006 	mov	w6, #0x0                   	// #0
    4460:	1400002b 	b	450c <core+0x140>
      FOR(m,4) t[m] = x[(5*j+4*m)%16];
    4464:	d37d0c4e 	ubfiz	x14, x2, #3, #4
    4468:	11001042 	add	w2, w2, #0x4
    446c:	f86e68ae 	ldr	x14, [x5, x14]
    4470:	f820796e 	str	x14, [x11, x0, lsl #3]
    4474:	91000400 	add	x0, x0, #0x1
    4478:	f100101f 	cmp	x0, #0x4
    447c:	54ffff41 	b.ne	4464 <core+0x98>  // b.any
      t[1] ^= L32(t[0]+t[3], 7);
    4480:	f9400bee 	ldr	x14, [sp, #16]
    4484:	f94017ef 	ldr	x15, [sp, #40]
    4488:	8b0f01c0 	add	x0, x14, x15
static u32 L32(u32 x,int c) { return (x << c) | ((x&0xffffffff) >> (32 - c)); }
    448c:	53197c02 	lsr	w2, w0, #25
    4490:	aa001c40 	orr	x0, x2, x0, lsl #7
      t[1] ^= L32(t[0]+t[3], 7);
    4494:	f9400fe2 	ldr	x2, [sp, #24]
    4498:	ca020000 	eor	x0, x0, x2
      t[2] ^= L32(t[1]+t[0], 9);
    449c:	8b0001c2 	add	x2, x14, x0
static u32 L32(u32 x,int c) { return (x << c) | ((x&0xffffffff) >> (32 - c)); }
    44a0:	53177c50 	lsr	w16, w2, #23
    44a4:	aa022602 	orr	x2, x16, x2, lsl #9
      t[2] ^= L32(t[1]+t[0], 9);
    44a8:	f94013f0 	ldr	x16, [sp, #32]
    44ac:	ca100042 	eor	x2, x2, x16
      t[1] ^= L32(t[0]+t[3], 7);
    44b0:	a9018be0 	stp	x0, x2, [sp, #24]
      t[3] ^= L32(t[2]+t[1],13);
    44b4:	8b020000 	add	x0, x0, x2
static u32 L32(u32 x,int c) { return (x << c) | ((x&0xffffffff) >> (32 - c)); }
    44b8:	53137c10 	lsr	w16, w0, #19
    44bc:	aa003600 	orr	x0, x16, x0, lsl #13
      t[3] ^= L32(t[2]+t[1],13);
    44c0:	ca0f0000 	eor	x0, x0, x15
    44c4:	f90017e0 	str	x0, [sp, #40]
      t[0] ^= L32(t[3]+t[2],18);
    44c8:	8b000042 	add	x2, x2, x0
static u32 L32(u32 x,int c) { return (x << c) | ((x&0xffffffff) >> (32 - c)); }
    44cc:	530e7c40 	lsr	w0, w2, #14
    44d0:	aa024802 	orr	x2, x0, x2, lsl #18
      FOR(m,4) w[4*j+(j+m)%4] = t[m];
    44d4:	d2800000 	mov	x0, #0x0                   	// #0
      t[0] ^= L32(t[3]+t[2],18);
    44d8:	ca0e0042 	eor	x2, x2, x14
    44dc:	f9000be2 	str	x2, [sp, #16]
      FOR(m,4) w[4*j+(j+m)%4] = t[m];
    44e0:	0b0000c2 	add	w2, w6, w0
    44e4:	12000442 	and	w2, w2, #0x3
    44e8:	0b0d0042 	add	w2, w2, w13
    44ec:	f860796e 	ldr	x14, [x11, x0, lsl #3]
    44f0:	91000400 	add	x0, x0, #0x1
    44f4:	f822798e 	str	x14, [x12, x2, lsl #3]
    44f8:	f100101f 	cmp	x0, #0x4
    44fc:	54ffff21 	b.ne	44e0 <core+0x114>  // b.any
    FOR(j,4) {
    4500:	110004c6 	add	w6, w6, #0x1
    4504:	710010df 	cmp	w6, #0x4
    4508:	540000a0 	b.eq	451c <core+0x150>  // b.none
      FOR(m,4) t[m] = x[(5*j+4*m)%16];
    450c:	531e74cd 	lsl	w13, w6, #2
    4510:	0b0608c2 	add	w2, w6, w6, lsl #2
  FOR(i,4) {
    4514:	d2800000 	mov	x0, #0x0                   	// #0
    4518:	17ffffd3 	b	4464 <core+0x98>
    FOR(j,4) {
    451c:	d2800000 	mov	x0, #0x0                   	// #0
    FOR(m,16) x[m] = w[m];
    4520:	f8606982 	ldr	x2, [x12, x0]
    4524:	f82068a2 	str	x2, [x5, x0]
    4528:	91002000 	add	x0, x0, #0x8
    452c:	f102001f 	cmp	x0, #0x80
    4530:	54ffff81 	b.ne	4520 <core+0x154>  // b.any
  FOR(i,20) {
    4534:	7100054a 	subs	w10, w10, #0x1
    4538:	54fff921 	b.ne	445c <core+0x90>  // b.any
  if (h) {
    453c:	340006a4 	cbz	w4, 4610 <core+0x244>
    4540:	aa0503e2 	mov	x2, x5
    4544:	d2800000 	mov	x0, #0x0                   	// #0
    FOR(i,16) x[i] += y[i];
    4548:	f8606926 	ldr	x6, [x9, x0]
    454c:	91002000 	add	x0, x0, #0x8
    4550:	f9400044 	ldr	x4, [x2]
    4554:	8b060084 	add	x4, x4, x6
    4558:	f8008444 	str	x4, [x2], #8
    455c:	f102001f 	cmp	x0, #0x80
    4560:	54ffff41 	b.ne	4548 <core+0x17c>  // b.any
    4564:	aa0503e4 	mov	x4, x5
    4568:	aa0503e9 	mov	x9, x5
    456c:	d2800002 	mov	x2, #0x0                   	// #0
      x[5*i] -= ld32(c+4*i);
    4570:	8b020060 	add	x0, x3, x2
    4574:	97fffda1 	bl	3bf8 <ld32>
    4578:	f9400126 	ldr	x6, [x9]
    FOR(i,4) {
    457c:	91002084 	add	x4, x4, #0x8
      x[5*i] -= ld32(c+4*i);
    4580:	cb0000c6 	sub	x6, x6, x0
    4584:	f8028526 	str	x6, [x9], #40
      x[6+i] -= ld32(in+4*i);
    4588:	8b020020 	add	x0, x1, x2
    FOR(i,4) {
    458c:	91001042 	add	x2, x2, #0x4
      x[6+i] -= ld32(in+4*i);
    4590:	97fffd9a 	bl	3bf8 <ld32>
    4594:	f9401486 	ldr	x6, [x4, #40]
    4598:	cb0000c6 	sub	x6, x6, x0
    459c:	f9001486 	str	x6, [x4, #40]
    FOR(i,4) {
    45a0:	f100405f 	cmp	x2, #0x10
    45a4:	54fffe61 	b.ne	4570 <core+0x1a4>  // b.any
  FOR(i,4) { x[i] = u; u >>= 8; }
    45a8:	910040e4 	add	x4, x7, #0x10
    FOR(i,4) {
    45ac:	d2800000 	mov	x0, #0x0                   	// #0
      st32(out+4*i,x[5*i]);
    45b0:	52800143 	mov	w3, #0xa                   	// #10
    45b4:	9ba37c01 	umull	x1, w0, w3
  FOR(i,4) { x[i] = u; u >>= 8; }
    45b8:	8b0000e6 	add	x6, x7, x0
      st32(out+4*i,x[5*i]);
    45bc:	f8616902 	ldr	x2, [x8, x1]
    45c0:	d2800001 	mov	x1, #0x0                   	// #0
  FOR(i,4) { x[i] = u; u >>= 8; }
    45c4:	382168c2 	strb	w2, [x6, x1]
    45c8:	91000421 	add	x1, x1, #0x1
    45cc:	d348fc42 	lsr	x2, x2, #8
    45d0:	f100103f 	cmp	x1, #0x4
    45d4:	54ffff81 	b.ne	45c4 <core+0x1f8>  // b.any
      st32(out+16+4*i,x[6+i]);
    45d8:	f94018a2 	ldr	x2, [x5, #48]
  FOR(i,4) { x[i] = u; u >>= 8; }
    45dc:	8b000086 	add	x6, x4, x0
      st32(out+16+4*i,x[6+i]);
    45e0:	d2800001 	mov	x1, #0x0                   	// #0
  FOR(i,4) { x[i] = u; u >>= 8; }
    45e4:	382168c2 	strb	w2, [x6, x1]
    45e8:	91000421 	add	x1, x1, #0x1
    45ec:	d348fc42 	lsr	x2, x2, #8
    45f0:	f100103f 	cmp	x1, #0x4
    45f4:	54ffff81 	b.ne	45e4 <core+0x218>  // b.any
    FOR(i,4) {
    45f8:	91001000 	add	x0, x0, #0x4
    45fc:	910020a5 	add	x5, x5, #0x8
    4600:	f100401f 	cmp	x0, #0x10
    4604:	54fffd81 	b.ne	45b4 <core+0x1e8>  // b.any
}
    4608:	a8db7bfd 	ldp	x29, x30, [sp], #432
    460c:	d65f03c0 	ret
  if (h) {
    4610:	d2800000 	mov	x0, #0x0                   	// #0
    FOR(i,16) st32(out + 4 * i,x[i] + y[i]);
    4614:	d37f7c02 	ubfiz	x2, x0, #1, #32
  FOR(i,4) { x[i] = u; u >>= 8; }
    4618:	8b0000e3 	add	x3, x7, x0
    FOR(i,16) st32(out + 4 * i,x[i] + y[i]);
    461c:	f86268a1 	ldr	x1, [x5, x2]
    4620:	f8626922 	ldr	x2, [x9, x2]
    4624:	8b020021 	add	x1, x1, x2
    4628:	d2800002 	mov	x2, #0x0                   	// #0
  FOR(i,4) { x[i] = u; u >>= 8; }
    462c:	38226861 	strb	w1, [x3, x2]
    4630:	91000442 	add	x2, x2, #0x1
    4634:	d348fc21 	lsr	x1, x1, #8
    4638:	f100105f 	cmp	x2, #0x4
    463c:	54ffff81 	b.ne	462c <core+0x260>  // b.any
    FOR(i,16) st32(out + 4 * i,x[i] + y[i]);
    4640:	91001000 	add	x0, x0, #0x4
    4644:	f101001f 	cmp	x0, #0x40
    4648:	54fffe61 	b.ne	4614 <core+0x248>  // b.any
    464c:	17ffffef 	b	4608 <core+0x23c>

0000000000004650 <crypto_verify_16_tweet>:
  u32 i,d = 0;
    4650:	d2800002 	mov	x2, #0x0                   	// #0
  FOR(i,n) d |= x[i]^y[i];
    4654:	d2800003 	mov	x3, #0x0                   	// #0
    4658:	38636804 	ldrb	w4, [x0, x3]
    465c:	38636825 	ldrb	w5, [x1, x3]
    4660:	91000463 	add	x3, x3, #0x1
    4664:	4a050084 	eor	w4, w4, w5
    4668:	92401c84 	and	x4, x4, #0xff
    466c:	aa040042 	orr	x2, x2, x4
    4670:	f100407f 	cmp	x3, #0x10
    4674:	54ffff21 	b.ne	4658 <crypto_verify_16_tweet+0x8>  // b.any
  return (1 & ((d - 1) >> 8)) - 1;
    4678:	d1000440 	sub	x0, x2, #0x1
    467c:	53082000 	ubfx	w0, w0, #8, #1
}
    4680:	51000400 	sub	w0, w0, #0x1
    4684:	d65f03c0 	ret

0000000000004688 <crypto_verify_32_tweet>:
  u32 i,d = 0;
    4688:	d2800002 	mov	x2, #0x0                   	// #0
  FOR(i,n) d |= x[i]^y[i];
    468c:	d2800003 	mov	x3, #0x0                   	// #0
    4690:	38636804 	ldrb	w4, [x0, x3]
    4694:	38636825 	ldrb	w5, [x1, x3]
    4698:	91000463 	add	x3, x3, #0x1
    469c:	4a050084 	eor	w4, w4, w5
    46a0:	92401c84 	and	x4, x4, #0xff
    46a4:	aa040042 	orr	x2, x2, x4
    46a8:	f100807f 	cmp	x3, #0x20
    46ac:	54ffff21 	b.ne	4690 <crypto_verify_32_tweet+0x8>  // b.any
  return (1 & ((d - 1) >> 8)) - 1;
    46b0:	d1000440 	sub	x0, x2, #0x1
    46b4:	53082000 	ubfx	w0, w0, #8, #1
}
    46b8:	51000400 	sub	w0, w0, #0x1
    46bc:	d65f03c0 	ret

00000000000046c0 <crypto_core_salsa20_tweet>:
{
    46c0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  core(out,in,k,c,0);
    46c4:	52800004 	mov	w4, #0x0                   	// #0
{
    46c8:	910003fd 	mov	x29, sp
  core(out,in,k,c,0);
    46cc:	97ffff40 	bl	43cc <core>
}
    46d0:	52800000 	mov	w0, #0x0                   	// #0
    46d4:	a8c17bfd 	ldp	x29, x30, [sp], #16
    46d8:	d65f03c0 	ret

00000000000046dc <crypto_core_hsalsa20_tweet>:
{
    46dc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  core(out,in,k,c,1);
    46e0:	52800024 	mov	w4, #0x1                   	// #1
{
    46e4:	910003fd 	mov	x29, sp
  core(out,in,k,c,1);
    46e8:	97ffff39 	bl	43cc <core>
}
    46ec:	52800000 	mov	w0, #0x0                   	// #0
    46f0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    46f4:	d65f03c0 	ret

00000000000046f8 <crypto_stream_salsa20_tweet_xor>:
  if (!b) return 0;
    46f8:	b4000b82 	cbz	x2, 4868 <crypto_stream_salsa20_tweet_xor+0x170>
{
    46fc:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
    4700:	aa0203f2 	mov	x18, x2
  FOR(i,16) z[i] = 0;
    4704:	d2800005 	mov	x5, #0x0                   	// #0
{
    4708:	910003fd 	mov	x29, sp
    470c:	a90153f3 	stp	x19, x20, [sp, #16]
    4710:	aa0103f3 	mov	x19, x1
  FOR(i,16) z[i] = 0;
    4714:	910143e1 	add	x1, sp, #0x50
{
    4718:	a9025bf5 	stp	x21, x22, [sp, #32]
    471c:	a90363f7 	stp	x23, x24, [sp, #48]
  FOR(i,16) z[i] = 0;
    4720:	382168bf 	strb	wzr, [x5, x1]
    4724:	910004a5 	add	x5, x5, #0x1
    4728:	f10040bf 	cmp	x5, #0x10
    472c:	54ffffa1 	b.ne	4720 <crypto_stream_salsa20_tweet_xor+0x28>  // b.any
  FOR(i,8) z[i] = n[i];
    4730:	d2800005 	mov	x5, #0x0                   	// #0
    4734:	38656862 	ldrb	w2, [x3, x5]
    4738:	38256822 	strb	w2, [x1, x5]
    473c:	910004a5 	add	x5, x5, #0x1
    4740:	f10020bf 	cmp	x5, #0x8
    4744:	54ffff81 	b.ne	4734 <crypto_stream_salsa20_tweet_xor+0x3c>  // b.any
    crypto_core_salsa20(x,z,k,sigma);
    4748:	d0000014 	adrp	x20, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    474c:	91098294 	add	x20, x20, #0x260
    4750:	aa0403e2 	mov	x2, x4
    4754:	aa0003f8 	mov	x24, x0
  FOR(i,8) z[i] = n[i];
    4758:	aa1203f5 	mov	x21, x18
    crypto_core_salsa20(x,z,k,sigma);
    475c:	910e0294 	add	x20, x20, #0x380
  while (b >= 64) {
    4760:	f100febf 	cmp	x21, #0x3f
    4764:	54000388 	b.hi	47d4 <crypto_stream_salsa20_tweet_xor+0xdc>  // b.pmore
  if (b) {
    4768:	d346fe43 	lsr	x3, x18, #6
    476c:	928007e0 	mov	x0, #0xffffffffffffffc0    	// #-64
    4770:	9b007c63 	mul	x3, x3, x0
    4774:	ab030252 	adds	x18, x18, x3
    4778:	54000220 	b.eq	47bc <crypto_stream_salsa20_tweet_xor+0xc4>  // b.none
    477c:	cb030318 	sub	x24, x24, x3
    crypto_core_salsa20(x,z,k,sigma);
    4780:	910183f5 	add	x21, sp, #0x60
    4784:	d0000003 	adrp	x3, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4788:	91098063 	add	x3, x3, #0x260
    478c:	910e0063 	add	x3, x3, #0x380
    4790:	aa1503e0 	mov	x0, x21
    4794:	97ffffcb 	bl	46c0 <crypto_core_salsa20_tweet>
    FOR(i,b) c[i] = (m?m[i]:0) ^ x[i];
    4798:	d2800001 	mov	x1, #0x0                   	// #0
    479c:	b4000633 	cbz	x19, 4860 <crypto_stream_salsa20_tweet_xor+0x168>
    47a0:	38616a60 	ldrb	w0, [x19, x1]
    47a4:	38616aa2 	ldrb	w2, [x21, x1]
    47a8:	4a020000 	eor	w0, w0, w2
    47ac:	38216b00 	strb	w0, [x24, x1]
    47b0:	91000421 	add	x1, x1, #0x1
    47b4:	eb12003f 	cmp	x1, x18
    47b8:	54ffff21 	b.ne	479c <crypto_stream_salsa20_tweet_xor+0xa4>  // b.any
}
    47bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    47c0:	52800000 	mov	w0, #0x0                   	// #0
    47c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    47cc:	a8ca7bfd 	ldp	x29, x30, [sp], #160
    47d0:	d65f03c0 	ret
    crypto_core_salsa20(x,z,k,sigma);
    47d4:	910183f7 	add	x23, sp, #0x60
    47d8:	aa1403e3 	mov	x3, x20
    47dc:	aa1703e0 	mov	x0, x23
    47e0:	f90027e2 	str	x2, [sp, #72]
    47e4:	97ffffb7 	bl	46c0 <crypto_core_salsa20_tweet>
    47e8:	8b120316 	add	x22, x24, x18
    FOR(i,64) c[i] = (m?m[i]:0) ^ x[i];
    47ec:	f94027e2 	ldr	x2, [sp, #72]
    47f0:	cb1502d6 	sub	x22, x22, x21
    47f4:	910143e1 	add	x1, sp, #0x50
    47f8:	d2800005 	mov	x5, #0x0                   	// #0
    47fc:	b40002f3 	cbz	x19, 4858 <crypto_stream_salsa20_tweet_xor+0x160>
    4800:	38656a63 	ldrb	w3, [x19, x5]
    4804:	38656ae0 	ldrb	w0, [x23, x5]
    4808:	4a000063 	eor	w3, w3, w0
    480c:	38256ac3 	strb	w3, [x22, x5]
    4810:	910004a5 	add	x5, x5, #0x1
    4814:	f10100bf 	cmp	x5, #0x40
    4818:	54ffff21 	b.ne	47fc <crypto_stream_salsa20_tweet_xor+0x104>  // b.any
    481c:	d2800003 	mov	x3, #0x0                   	// #0
    u = 1;
    4820:	d2800025 	mov	x5, #0x1                   	// #1
      u += (u32) z[i];
    4824:	8b030024 	add	x4, x1, x3
    for (i = 8;i < 16;++i) {
    4828:	91000463 	add	x3, x3, #0x1
      u += (u32) z[i];
    482c:	39402080 	ldrb	w0, [x4, #8]
    4830:	8b050005 	add	x5, x0, x5
      z[i] = u;
    4834:	39002085 	strb	w5, [x4, #8]
      u >>= 8;
    4838:	d348fca5 	lsr	x5, x5, #8
    for (i = 8;i < 16;++i) {
    483c:	f100207f 	cmp	x3, #0x8
    4840:	54ffff21 	b.ne	4824 <crypto_stream_salsa20_tweet_xor+0x12c>  // b.any
    if (m) m += 64;
    4844:	91010260 	add	x0, x19, #0x40
    4848:	f100027f 	cmp	x19, #0x0
    b -= 64;
    484c:	d10102b5 	sub	x21, x21, #0x40
    if (m) m += 64;
    4850:	9a931013 	csel	x19, x0, x19, ne	// ne = any
    4854:	17ffffc3 	b	4760 <crypto_stream_salsa20_tweet_xor+0x68>
    FOR(i,64) c[i] = (m?m[i]:0) ^ x[i];
    4858:	52800003 	mov	w3, #0x0                   	// #0
    485c:	17ffffea 	b	4804 <crypto_stream_salsa20_tweet_xor+0x10c>
    FOR(i,b) c[i] = (m?m[i]:0) ^ x[i];
    4860:	52800000 	mov	w0, #0x0                   	// #0
    4864:	17ffffd0 	b	47a4 <crypto_stream_salsa20_tweet_xor+0xac>
}
    4868:	52800000 	mov	w0, #0x0                   	// #0
    486c:	d65f03c0 	ret

0000000000004870 <crypto_stream_salsa20_tweet>:
  return crypto_stream_salsa20_xor(c,0,d,n,k);
    4870:	aa0303e4 	mov	x4, x3
    4874:	aa0203e3 	mov	x3, x2
    4878:	aa0103e2 	mov	x2, x1
    487c:	d2800001 	mov	x1, #0x0                   	// #0
    4880:	17ffff9e 	b	46f8 <crypto_stream_salsa20_tweet_xor>

0000000000004884 <crypto_stream_xsalsa20_tweet>:
{
    4884:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4888:	aa0203f2 	mov	x18, x2
    488c:	aa0303e2 	mov	x2, x3
    4890:	910003fd 	mov	x29, sp
  crypto_core_hsalsa20(s,n,k,sigma);
    4894:	d0000003 	adrp	x3, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4898:	91098063 	add	x3, x3, #0x260
    489c:	910e0063 	add	x3, x3, #0x380
{
    48a0:	a90153f3 	stp	x19, x20, [sp, #16]
    48a4:	aa0003f3 	mov	x19, x0
    48a8:	aa0103f4 	mov	x20, x1
  crypto_core_hsalsa20(s,n,k,sigma);
    48ac:	910083e0 	add	x0, sp, #0x20
    48b0:	aa1203e1 	mov	x1, x18
    48b4:	97ffff8a 	bl	46dc <crypto_core_hsalsa20_tweet>
  return crypto_stream_salsa20_xor(c,0,d,n,k);
    48b8:	910083e4 	add	x4, sp, #0x20
    48bc:	aa1403e2 	mov	x2, x20
    48c0:	91004243 	add	x3, x18, #0x10
    48c4:	aa1303e0 	mov	x0, x19
    48c8:	d2800001 	mov	x1, #0x0                   	// #0
    48cc:	97ffff8b 	bl	46f8 <crypto_stream_salsa20_tweet_xor>
}
    48d0:	52800000 	mov	w0, #0x0                   	// #0
    48d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    48d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    48dc:	d65f03c0 	ret

00000000000048e0 <crypto_stream_xsalsa20_tweet_xor>:
{
    48e0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    48e4:	aa0303f2 	mov	x18, x3
  crypto_core_hsalsa20(s,n,k,sigma);
    48e8:	d0000003 	adrp	x3, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    48ec:	91098063 	add	x3, x3, #0x260
{
    48f0:	910003fd 	mov	x29, sp
  crypto_core_hsalsa20(s,n,k,sigma);
    48f4:	910e0063 	add	x3, x3, #0x380
{
    48f8:	a90153f3 	stp	x19, x20, [sp, #16]
    48fc:	aa0003f3 	mov	x19, x0
    4900:	aa0103f4 	mov	x20, x1
  crypto_core_hsalsa20(s,n,k,sigma);
    4904:	9100c3e0 	add	x0, sp, #0x30
    4908:	aa1203e1 	mov	x1, x18
{
    490c:	f90013f5 	str	x21, [sp, #32]
    4910:	aa0203f5 	mov	x21, x2
    4914:	aa0403e2 	mov	x2, x4
  crypto_core_hsalsa20(s,n,k,sigma);
    4918:	97ffff71 	bl	46dc <crypto_core_hsalsa20_tweet>
  return crypto_stream_salsa20_xor(c,m,d,n+16,s);
    491c:	9100c3e4 	add	x4, sp, #0x30
    4920:	aa1503e2 	mov	x2, x21
    4924:	aa1403e1 	mov	x1, x20
    4928:	91004243 	add	x3, x18, #0x10
    492c:	aa1303e0 	mov	x0, x19
    4930:	97ffff72 	bl	46f8 <crypto_stream_salsa20_tweet_xor>
}
    4934:	f94013f5 	ldr	x21, [sp, #32]
    4938:	52800000 	mov	w0, #0x0                   	// #0
    493c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4940:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4944:	d65f03c0 	ret

0000000000004948 <crypto_onetimeauth_poly1305_tweet>:
{
    4948:	d10b03ff 	sub	sp, sp, #0x2c0
    494c:	aa0003e9 	mov	x9, x0
    4950:	aa0203e6 	mov	x6, x2
    4954:	aa0303e8 	mov	x8, x3
  FOR(j,17) r[j]=h[j]=0;
    4958:	9104a3e0 	add	x0, sp, #0x128
    495c:	910283ea 	add	x10, sp, #0xa0
{
    4960:	aa0103e7 	mov	x7, x1
  FOR(j,17) r[j]=h[j]=0;
    4964:	d2800001 	mov	x1, #0x0                   	// #0
{
    4968:	a9007bfd 	stp	x29, x30, [sp]
    496c:	910003fd 	mov	x29, sp
  FOR(j,17) r[j]=h[j]=0;
    4970:	f821781f 	str	xzr, [x0, x1, lsl #3]
    4974:	f821795f 	str	xzr, [x10, x1, lsl #3]
    4978:	91000421 	add	x1, x1, #0x1
    497c:	f100443f 	cmp	x1, #0x11
    4980:	54ffff81 	b.ne	4970 <crypto_onetimeauth_poly1305_tweet+0x28>  // b.any
  FOR(j,16) r[j]=k[j];
    4984:	d2800001 	mov	x1, #0x0                   	// #0
    4988:	38616902 	ldrb	w2, [x8, x1]
    498c:	f8217942 	str	x2, [x10, x1, lsl #3]
    4990:	91000421 	add	x1, x1, #0x1
    4994:	f100403f 	cmp	x1, #0x10
    4998:	54ffff81 	b.ne	4988 <crypto_onetimeauth_poly1305_tweet+0x40>  // b.any
  r[3]&=15;
    499c:	f9405fe1 	ldr	x1, [sp, #184]
      FOR(j,17) x[i] += h[j] * ((j <= i) ? r[i - j] : 320 * r[i + 17 - j]);
    49a0:	d280280b 	mov	x11, #0x140                 	// #320
  r[3]&=15;
    49a4:	92400c21 	and	x1, x1, #0xf
    49a8:	f9005fe1 	str	x1, [sp, #184]
  r[4]&=252;
    49ac:	f94063e1 	ldr	x1, [sp, #192]
    49b0:	927e1421 	and	x1, x1, #0xfc
    49b4:	f90063e1 	str	x1, [sp, #192]
  r[7]&=15;
    49b8:	f9406fe1 	ldr	x1, [sp, #216]
    49bc:	92400c21 	and	x1, x1, #0xf
    49c0:	f9006fe1 	str	x1, [sp, #216]
  r[8]&=252;
    49c4:	f94073e1 	ldr	x1, [sp, #224]
    49c8:	927e1421 	and	x1, x1, #0xfc
    49cc:	f90073e1 	str	x1, [sp, #224]
  r[11]&=15;
    49d0:	f9407fe1 	ldr	x1, [sp, #248]
    49d4:	92400c21 	and	x1, x1, #0xf
    49d8:	f9007fe1 	str	x1, [sp, #248]
  r[12]&=252;
    49dc:	f94083e1 	ldr	x1, [sp, #256]
    49e0:	927e1421 	and	x1, x1, #0xfc
    49e4:	f90083e1 	str	x1, [sp, #256]
  r[15]&=15;
    49e8:	f9408fe1 	ldr	x1, [sp, #280]
    49ec:	92400c21 	and	x1, x1, #0xf
    49f0:	f9008fe1 	str	x1, [sp, #280]
    FOR(j,17) c[j] = 0;
    49f4:	9106c3e1 	add	x1, sp, #0x1b0
  while (n > 0) {
    49f8:	b50005a6 	cbnz	x6, 4aac <crypto_onetimeauth_poly1305_tweet+0x164>
  FOR(j,17) g[j] = h[j];
    49fc:	9108e3e7 	add	x7, sp, #0x238
    4a00:	d2800001 	mov	x1, #0x0                   	// #0
    4a04:	f8617802 	ldr	x2, [x0, x1, lsl #3]
    4a08:	f82178e2 	str	x2, [x7, x1, lsl #3]
    4a0c:	91000421 	add	x1, x1, #0x1
    4a10:	f100443f 	cmp	x1, #0x11
    4a14:	54ffff81 	b.ne	4a04 <crypto_onetimeauth_poly1305_tweet+0xbc>  // b.any
  add1305(h,minusp);
    4a18:	d0000001 	adrp	x1, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4a1c:	91098021 	add	x1, x1, #0x260
    4a20:	910e4021 	add	x1, x1, #0x390
    4a24:	97fffc77 	bl	3c00 <add1305>
  s = -(h[16] >> 7);
    4a28:	f940d7e4 	ldr	x4, [sp, #424]
    4a2c:	aa0003e3 	mov	x3, x0
  FOR(j,17) h[j] ^= s & (g[j] ^ h[j]);
    4a30:	d2800002 	mov	x2, #0x0                   	// #0
  s = -(h[16] >> 7);
    4a34:	cb441fe4 	neg	x4, x4, lsr #7
  FOR(j,17) h[j] ^= s & (g[j] ^ h[j]);
    4a38:	f9400065 	ldr	x5, [x3]
    4a3c:	f86278e1 	ldr	x1, [x7, x2, lsl #3]
    4a40:	91000442 	add	x2, x2, #0x1
    4a44:	ca0100a1 	eor	x1, x5, x1
    4a48:	8a040021 	and	x1, x1, x4
    4a4c:	ca050021 	eor	x1, x1, x5
    4a50:	f8008461 	str	x1, [x3], #8
    4a54:	f100445f 	cmp	x2, #0x11
    4a58:	54ffff01 	b.ne	4a38 <crypto_onetimeauth_poly1305_tweet+0xf0>  // b.any
  FOR(j,16) c[j] = k[j + 16];
    4a5c:	91004108 	add	x8, x8, #0x10
    4a60:	d2800001 	mov	x1, #0x0                   	// #0
    4a64:	9106c3e3 	add	x3, sp, #0x1b0
    4a68:	38616902 	ldrb	w2, [x8, x1]
    4a6c:	f8217862 	str	x2, [x3, x1, lsl #3]
    4a70:	91000421 	add	x1, x1, #0x1
    4a74:	f100403f 	cmp	x1, #0x10
    4a78:	54ffff61 	b.ne	4a64 <crypto_onetimeauth_poly1305_tweet+0x11c>  // b.any
  add1305(h,c);
    4a7c:	aa0303e1 	mov	x1, x3
  c[16] = 0;
    4a80:	f9011bff 	str	xzr, [sp, #560]
  add1305(h,c);
    4a84:	97fffc5f 	bl	3c00 <add1305>
  FOR(j,16) out[j] = h[j];
    4a88:	f8667801 	ldr	x1, [x0, x6, lsl #3]
    4a8c:	38266921 	strb	w1, [x9, x6]
    4a90:	910004c6 	add	x6, x6, #0x1
    4a94:	f10040df 	cmp	x6, #0x10
    4a98:	54ffff81 	b.ne	4a88 <crypto_onetimeauth_poly1305_tweet+0x140>  // b.any
}
    4a9c:	a9407bfd 	ldp	x29, x30, [sp]
    4aa0:	52800000 	mov	w0, #0x0                   	// #0
    4aa4:	910b03ff 	add	sp, sp, #0x2c0
    4aa8:	d65f03c0 	ret
    FOR(j,17) c[j] = 0;
    4aac:	d2800002 	mov	x2, #0x0                   	// #0
    4ab0:	f822783f 	str	xzr, [x1, x2, lsl #3]
    4ab4:	91000442 	add	x2, x2, #0x1
    4ab8:	f100445f 	cmp	x2, #0x11
    4abc:	54ffffa1 	b.ne	4ab0 <crypto_onetimeauth_poly1305_tweet+0x168>  // b.any
    for (j = 0;(j < 16) && (j < n);++j) c[j] = m[j];
    4ac0:	d2800002 	mov	x2, #0x0                   	// #0
    4ac4:	386268e3 	ldrb	w3, [x7, x2]
    4ac8:	f8227823 	str	x3, [x1, x2, lsl #3]
    4acc:	91000442 	add	x2, x2, #0x1
    4ad0:	f100405f 	cmp	x2, #0x10
    4ad4:	fa4210c0 	ccmp	x6, x2, #0x0, ne	// ne = any
    4ad8:	54ffff68 	b.hi	4ac4 <crypto_onetimeauth_poly1305_tweet+0x17c>  // b.pmore
    c[j] = 1;
    4adc:	d2800023 	mov	x3, #0x1                   	// #1
    m += j; n -= j;
    4ae0:	8b0200e7 	add	x7, x7, x2
    4ae4:	cb0200c6 	sub	x6, x6, x2
    4ae8:	aa0a03ec 	mov	x12, x10
    4aec:	910063ee 	add	x14, sp, #0x18
    c[j] = 1;
    4af0:	f8227823 	str	x3, [x1, x2, lsl #3]
    add1305(h,c);
    4af4:	97fffc43 	bl	3c00 <add1305>
    FOR(i,17) {
    4af8:	d2800002 	mov	x2, #0x0                   	// #0
    4afc:	aa0c03e3 	mov	x3, x12
    4b00:	d280000d 	mov	x13, #0x0                   	// #0
      FOR(j,17) x[i] += h[j] * ((j <= i) ? r[i - j] : 320 * r[i + 17 - j]);
    4b04:	d2800004 	mov	x4, #0x0                   	// #0
    4b08:	f864780f 	ldr	x15, [x0, x4, lsl #3]
    4b0c:	eb04005f 	cmp	x2, x4
    4b10:	540005e3 	b.cc	4bcc <crypto_onetimeauth_poly1305_tweet+0x284>  // b.lo, b.ul, b.last
    4b14:	f9400065 	ldr	x5, [x3]
    4b18:	91000484 	add	x4, x4, #0x1
    4b1c:	9b0535ed 	madd	x13, x15, x5, x13
    4b20:	d1002063 	sub	x3, x3, #0x8
    4b24:	f100449f 	cmp	x4, #0x11
    4b28:	54ffff01 	b.ne	4b08 <crypto_onetimeauth_poly1305_tweet+0x1c0>  // b.any
    4b2c:	f82279cd 	str	x13, [x14, x2, lsl #3]
    FOR(i,17) {
    4b30:	91000442 	add	x2, x2, #0x1
    4b34:	9100218c 	add	x12, x12, #0x8
    4b38:	f100445f 	cmp	x2, #0x11
    4b3c:	54fffe01 	b.ne	4afc <crypto_onetimeauth_poly1305_tweet+0x1b4>  // b.any
    FOR(i,17) h[i] = x[i];
    4b40:	d2800002 	mov	x2, #0x0                   	// #0
    4b44:	f86279c3 	ldr	x3, [x14, x2, lsl #3]
    4b48:	f8227803 	str	x3, [x0, x2, lsl #3]
    4b4c:	91000442 	add	x2, x2, #0x1
    4b50:	f100445f 	cmp	x2, #0x11
    4b54:	54ffff81 	b.ne	4b44 <crypto_onetimeauth_poly1305_tweet+0x1fc>  // b.any
    4b58:	d2800022 	mov	x2, #0x1                   	// #1
    u = 0;
    4b5c:	d2800004 	mov	x4, #0x0                   	// #0
      u += h[j];
    4b60:	8b020c03 	add	x3, x0, x2, lsl #3
    FOR(j,16) {
    4b64:	91000442 	add	x2, x2, #0x1
      u += h[j];
    4b68:	f85f8065 	ldur	x5, [x3, #-8]
    4b6c:	8b050084 	add	x4, x4, x5
      h[j] = u & 255;
    4b70:	92401c85 	and	x5, x4, #0xff
    4b74:	f81f8065 	stur	x5, [x3, #-8]
      u >>= 8;
    4b78:	d348fc84 	lsr	x4, x4, #8
    FOR(j,16) {
    4b7c:	f100445f 	cmp	x2, #0x11
    4b80:	54ffff01 	b.ne	4b60 <crypto_onetimeauth_poly1305_tweet+0x218>  // b.any
    u += h[16]; h[16] = u & 3;
    4b84:	f940d7e2 	ldr	x2, [sp, #424]
    4b88:	8b020084 	add	x4, x4, x2
    u = 5 * (u >> 2);
    4b8c:	927ef482 	and	x2, x4, #0xfffffffffffffffc
    u += h[16]; h[16] = u & 3;
    4b90:	92400483 	and	x3, x4, #0x3
    u = 5 * (u >> 2);
    4b94:	8b440844 	add	x4, x2, x4, lsr #2
    4b98:	d2800022 	mov	x2, #0x1                   	// #1
      u += h[j];
    4b9c:	8b020c05 	add	x5, x0, x2, lsl #3
    FOR(j,16) {
    4ba0:	91000442 	add	x2, x2, #0x1
      u += h[j];
    4ba4:	f85f80ac 	ldur	x12, [x5, #-8]
    4ba8:	8b0c0084 	add	x4, x4, x12
      h[j] = u & 255;
    4bac:	92401c8c 	and	x12, x4, #0xff
    4bb0:	f81f80ac 	stur	x12, [x5, #-8]
      u >>= 8;
    4bb4:	d348fc84 	lsr	x4, x4, #8
    FOR(j,16) {
    4bb8:	f100445f 	cmp	x2, #0x11
    4bbc:	54ffff01 	b.ne	4b9c <crypto_onetimeauth_poly1305_tweet+0x254>  // b.any
    u += h[16]; h[16] = u;
    4bc0:	8b040062 	add	x2, x3, x4
    4bc4:	f900d7e2 	str	x2, [sp, #424]
    4bc8:	17ffff8c 	b	49f8 <crypto_onetimeauth_poly1305_tweet+0xb0>
      FOR(j,17) x[i] += h[j] * ((j <= i) ? r[i - j] : 320 * r[i + 17 - j]);
    4bcc:	f9404465 	ldr	x5, [x3, #136]
    4bd0:	9b0b7ca5 	mul	x5, x5, x11
    4bd4:	17ffffd1 	b	4b18 <crypto_onetimeauth_poly1305_tweet+0x1d0>

0000000000004bd8 <crypto_onetimeauth_poly1305_tweet_verify>:
{
    4bd8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4bdc:	aa0003f2 	mov	x18, x0
    4be0:	910003fd 	mov	x29, sp
  crypto_onetimeauth(x,m,n,k);
    4be4:	910043e0 	add	x0, sp, #0x10
    4be8:	97ffff58 	bl	4948 <crypto_onetimeauth_poly1305_tweet>
  return crypto_verify_16(h,x);
    4bec:	910043e1 	add	x1, sp, #0x10
    4bf0:	aa1203e0 	mov	x0, x18
    4bf4:	97fffe97 	bl	4650 <crypto_verify_16_tweet>
}
    4bf8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4bfc:	d65f03c0 	ret

0000000000004c00 <crypto_secretbox_xsalsa20poly1305_tweet>:
  if (d < 32) return -1;
    4c00:	f1007c5f 	cmp	x2, #0x1f
    4c04:	540002a9 	b.ls	4c58 <crypto_secretbox_xsalsa20poly1305_tweet+0x58>  // b.plast
{
    4c08:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4c0c:	910003fd 	mov	x29, sp
    4c10:	a90153f3 	stp	x19, x20, [sp, #16]
    4c14:	aa0003f3 	mov	x19, x0
    4c18:	aa0203f4 	mov	x20, x2
  crypto_stream_xor(c,m,d,n,k);
    4c1c:	97ffff31 	bl	48e0 <crypto_stream_xsalsa20_tweet_xor>
  crypto_onetimeauth(c + 16,c + 32,d - 32,c);
    4c20:	aa1303e3 	mov	x3, x19
    4c24:	d1008282 	sub	x2, x20, #0x20
    4c28:	91008261 	add	x1, x19, #0x20
    4c2c:	91004260 	add	x0, x19, #0x10
    4c30:	97ffff46 	bl	4948 <crypto_onetimeauth_poly1305_tweet>
    4c34:	d2800000 	mov	x0, #0x0                   	// #0
  FOR(i,16) c[i] = 0;
    4c38:	38206a7f 	strb	wzr, [x19, x0]
    4c3c:	91000400 	add	x0, x0, #0x1
    4c40:	f100401f 	cmp	x0, #0x10
    4c44:	54ffffa1 	b.ne	4c38 <crypto_secretbox_xsalsa20poly1305_tweet+0x38>  // b.any
}
    4c48:	a94153f3 	ldp	x19, x20, [sp, #16]
  FOR(i,16) c[i] = 0;
    4c4c:	52800000 	mov	w0, #0x0                   	// #0
}
    4c50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4c54:	d65f03c0 	ret
  if (d < 32) return -1;
    4c58:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    4c5c:	d65f03c0 	ret

0000000000004c60 <crypto_secretbox_xsalsa20poly1305_tweet_open>:
{
    4c60:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c64:	910003fd 	mov	x29, sp
    4c68:	a90153f3 	stp	x19, x20, [sp, #16]
    4c6c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c70:	a90363f7 	stp	x23, x24, [sp, #48]
  if (d < 32) return -1;
    4c74:	f1007c5f 	cmp	x2, #0x1f
    4c78:	54000108 	b.hi	4c98 <crypto_secretbox_xsalsa20poly1305_tweet_open+0x38>  // b.pmore
    4c7c:	12800013 	mov	w19, #0xffffffff            	// #-1
}
    4c80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c84:	2a1303e0 	mov	w0, w19
    4c88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c8c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c90:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4c94:	d65f03c0 	ret
    4c98:	aa0303f7 	mov	x23, x3
    4c9c:	aa0103f4 	mov	x20, x1
  crypto_stream(x,32,n,k);
    4ca0:	aa0403e3 	mov	x3, x4
    4ca4:	aa0403f8 	mov	x24, x4
    4ca8:	aa0203f5 	mov	x21, x2
    4cac:	d2800401 	mov	x1, #0x20                  	// #32
    4cb0:	aa1703e2 	mov	x2, x23
    4cb4:	aa0003f6 	mov	x22, x0
    4cb8:	910103e0 	add	x0, sp, #0x40
    4cbc:	97fffef2 	bl	4884 <crypto_stream_xsalsa20_tweet>
  if (crypto_onetimeauth_verify(c + 16,c + 32,d - 32,x) != 0) return -1;
    4cc0:	910103e3 	add	x3, sp, #0x40
    4cc4:	d10082a2 	sub	x2, x21, #0x20
    4cc8:	91008281 	add	x1, x20, #0x20
    4ccc:	91004280 	add	x0, x20, #0x10
    4cd0:	97ffffc2 	bl	4bd8 <crypto_onetimeauth_poly1305_tweet_verify>
    4cd4:	2a0003f3 	mov	w19, w0
    4cd8:	35fffd20 	cbnz	w0, 4c7c <crypto_secretbox_xsalsa20poly1305_tweet_open+0x1c>
  crypto_stream_xor(m,c,d,n,k);
    4cdc:	aa1403e1 	mov	x1, x20
    4ce0:	aa1803e4 	mov	x4, x24
    4ce4:	aa1703e3 	mov	x3, x23
    4ce8:	aa1503e2 	mov	x2, x21
    4cec:	aa1603e0 	mov	x0, x22
    4cf0:	97fffefc 	bl	48e0 <crypto_stream_xsalsa20_tweet_xor>
    4cf4:	d2800001 	mov	x1, #0x0                   	// #0
  FOR(i,32) m[i] = 0;
    4cf8:	38216adf 	strb	wzr, [x22, x1]
    4cfc:	91000421 	add	x1, x1, #0x1
    4d00:	f100803f 	cmp	x1, #0x20
    4d04:	54ffffa1 	b.ne	4cf8 <crypto_secretbox_xsalsa20poly1305_tweet_open+0x98>  // b.any
    4d08:	17ffffde 	b	4c80 <crypto_secretbox_xsalsa20poly1305_tweet_open+0x20>

0000000000004d0c <crypto_scalarmult_curve25519_tweet>:
{
    4d0c:	d11743ff 	sub	sp, sp, #0x5d0
    4d10:	a9007bfd 	stp	x29, x30, [sp]
    4d14:	910003fd 	mov	x29, sp
    4d18:	a9025bf5 	stp	x21, x22, [sp, #32]
  FOR(i,31) z[i]=n[i];
    4d1c:	9100c3f5 	add	x21, sp, #0x30
{
    4d20:	aa0003f6 	mov	x22, x0
  FOR(i,31) z[i]=n[i];
    4d24:	d2800000 	mov	x0, #0x0                   	// #0
{
    4d28:	a90153f3 	stp	x19, x20, [sp, #16]
  FOR(i,31) z[i]=n[i];
    4d2c:	38606823 	ldrb	w3, [x1, x0]
    4d30:	38356803 	strb	w3, [x0, x21]
    4d34:	91000400 	add	x0, x0, #0x1
    4d38:	f1007c1f 	cmp	x0, #0x1f
    4d3c:	54ffff81 	b.ne	4d2c <crypto_scalarmult_curve25519_tweet+0x20>  // b.any
  z[31]=(n[31]&127)|64;
    4d40:	39407c20 	ldrb	w0, [x1, #31]
  unpack25519(x,p);
    4d44:	910d43ed 	add	x13, sp, #0x350
    b[i]=x[i];
    4d48:	910343ef 	add	x15, sp, #0xd0
    d[i]=a[i]=c[i]=0;
    4d4c:	910543ec 	add	x12, sp, #0x150
  z[31]=(n[31]&127)|64;
    4d50:	12001400 	and	w0, w0, #0x3f
    d[i]=a[i]=c[i]=0;
    4d54:	910143eb 	add	x11, sp, #0x50
  z[31]=(n[31]&127)|64;
    4d58:	321a0000 	orr	w0, w0, #0x40
    4d5c:	39013fe0 	strb	w0, [sp, #79]
  z[0]&=248;
    4d60:	3940c3e0 	ldrb	w0, [sp, #48]
    d[i]=a[i]=c[i]=0;
    4d64:	910743ee 	add	x14, sp, #0x1d0
  unpack25519(x,p);
    4d68:	aa0203e1 	mov	x1, x2
  z[0]&=248;
    4d6c:	121d7000 	and	w0, w0, #0xfffffff8
    4d70:	3900c3e0 	strb	w0, [sp, #48]
  unpack25519(x,p);
    4d74:	aa0d03e0 	mov	x0, x13
    4d78:	97fffc1a 	bl	3de0 <unpack25519>
  FOR(i,16) {
    4d7c:	d2800000 	mov	x0, #0x0                   	// #0
    b[i]=x[i];
    4d80:	f86079a1 	ldr	x1, [x13, x0, lsl #3]
    4d84:	f82079e1 	str	x1, [x15, x0, lsl #3]
    d[i]=a[i]=c[i]=0;
    4d88:	f820799f 	str	xzr, [x12, x0, lsl #3]
    4d8c:	f820797f 	str	xzr, [x11, x0, lsl #3]
    4d90:	f82079df 	str	xzr, [x14, x0, lsl #3]
  FOR(i,16) {
    4d94:	91000400 	add	x0, x0, #0x1
    4d98:	f100401f 	cmp	x0, #0x10
    4d9c:	54ffff21 	b.ne	4d80 <crypto_scalarmult_curve25519_tweet+0x74>  // b.any
    M(a,c,_121665);
    4da0:	d0000014 	adrp	x20, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4da4:	91098294 	add	x20, x20, #0x260
    4da8:	91106294 	add	x20, x20, #0x418
  a[0]=d[0]=1;
    4dac:	d2800020 	mov	x0, #0x1                   	// #1
  for(i=254;i>=0;--i) {
    4db0:	d2801fd3 	mov	x19, #0xfe                  	// #254
  a[0]=d[0]=1;
    4db4:	f9002be0 	str	x0, [sp, #80]
    4db8:	f900ebe0 	str	x0, [sp, #464]
    r=(z[i>>3]>>(i&7))&1;
    4dbc:	9343fe60 	asr	x0, x19, #3
    sel25519(a,b,r);
    4dc0:	aa0f03e1 	mov	x1, x15
    r=(z[i>>3]>>(i&7))&1;
    4dc4:	38606ab2 	ldrb	w18, [x21, x0]
    4dc8:	12000a60 	and	w0, w19, #0x7
  for(i=254;i>=0;--i) {
    4dcc:	d1000673 	sub	x19, x19, #0x1
    r=(z[i>>3]>>(i&7))&1;
    4dd0:	1ac02a52 	asr	w18, w18, w0
    sel25519(a,b,r);
    4dd4:	aa0b03e0 	mov	x0, x11
    4dd8:	12000242 	and	w2, w18, #0x1
    4ddc:	97fffbb4 	bl	3cac <sel25519>
    sel25519(c,d,r);
    4de0:	12000242 	and	w2, w18, #0x1
    4de4:	aa0e03e1 	mov	x1, x14
    4de8:	aa0c03e0 	mov	x0, x12
    4dec:	97fffbb0 	bl	3cac <sel25519>
    A(e,a,c);
    4df0:	aa0c03e2 	mov	x2, x12
    4df4:	910943e0 	add	x0, sp, #0x250
    4df8:	aa0b03e1 	mov	x1, x11
    4dfc:	97fffc07 	bl	3e18 <A>
    Z(a,a,c);
    4e00:	aa0b03e0 	mov	x0, x11
    4e04:	97fffc0e 	bl	3e3c <Z>
    A(c,b,d);
    4e08:	aa0e03e2 	mov	x2, x14
    4e0c:	aa0c03e0 	mov	x0, x12
    4e10:	aa0f03e1 	mov	x1, x15
    4e14:	97fffc01 	bl	3e18 <A>
    Z(b,b,d);
    4e18:	aa0f03e0 	mov	x0, x15
    4e1c:	97fffc08 	bl	3e3c <Z>
    S(d,e);
    4e20:	910943e1 	add	x1, sp, #0x250
    4e24:	aa0e03e0 	mov	x0, x14
    4e28:	97fffc38 	bl	3f08 <S>
    S(f,a);
    4e2c:	910b43e0 	add	x0, sp, #0x2d0
    4e30:	aa0b03e1 	mov	x1, x11
    4e34:	97fffc35 	bl	3f08 <S>
    M(a,c,a);
    4e38:	aa0b03e2 	mov	x2, x11
    4e3c:	aa0c03e1 	mov	x1, x12
    4e40:	aa0b03e0 	mov	x0, x11
    4e44:	97fffc07 	bl	3e60 <M>
    M(c,b,e);
    4e48:	910943e2 	add	x2, sp, #0x250
    4e4c:	aa0f03e1 	mov	x1, x15
    4e50:	aa0c03e0 	mov	x0, x12
    4e54:	97fffc03 	bl	3e60 <M>
    A(e,a,c);
    4e58:	aa0c03e2 	mov	x2, x12
    4e5c:	910943e0 	add	x0, sp, #0x250
    4e60:	aa0b03e1 	mov	x1, x11
    4e64:	97fffbed 	bl	3e18 <A>
    Z(a,a,c);
    4e68:	aa0b03e0 	mov	x0, x11
    4e6c:	97fffbf4 	bl	3e3c <Z>
    S(b,a);
    4e70:	aa0f03e0 	mov	x0, x15
    4e74:	97fffc25 	bl	3f08 <S>
    Z(c,d,f);
    4e78:	910b43e2 	add	x2, sp, #0x2d0
    4e7c:	aa0e03e1 	mov	x1, x14
    4e80:	aa0c03e0 	mov	x0, x12
    4e84:	97fffbee 	bl	3e3c <Z>
    M(a,c,_121665);
    4e88:	aa0b03e0 	mov	x0, x11
    4e8c:	aa1403e2 	mov	x2, x20
    4e90:	aa0c03e1 	mov	x1, x12
    4e94:	97fffbf3 	bl	3e60 <M>
    A(a,a,d);
    4e98:	aa0e03e2 	mov	x2, x14
    4e9c:	aa0b03e1 	mov	x1, x11
    4ea0:	97fffbde 	bl	3e18 <A>
    M(c,c,a);
    4ea4:	aa0b03e2 	mov	x2, x11
    4ea8:	aa0c03e1 	mov	x1, x12
    4eac:	aa0c03e0 	mov	x0, x12
    4eb0:	97fffbec 	bl	3e60 <M>
    M(a,d,f);
    4eb4:	aa0b03e0 	mov	x0, x11
    4eb8:	910b43e2 	add	x2, sp, #0x2d0
    4ebc:	aa0e03e1 	mov	x1, x14
    4ec0:	97fffbe8 	bl	3e60 <M>
    M(d,b,x);
    4ec4:	aa0e03e0 	mov	x0, x14
    4ec8:	aa0d03e2 	mov	x2, x13
    4ecc:	aa0f03e1 	mov	x1, x15
    4ed0:	97fffbe4 	bl	3e60 <M>
    S(b,e);
    4ed4:	aa0f03e0 	mov	x0, x15
    4ed8:	910943e1 	add	x1, sp, #0x250
    4edc:	97fffc0b 	bl	3f08 <S>
    sel25519(a,b,r);
    4ee0:	aa0b03e0 	mov	x0, x11
    4ee4:	12000242 	and	w2, w18, #0x1
    4ee8:	aa0f03e1 	mov	x1, x15
    4eec:	97fffb70 	bl	3cac <sel25519>
    sel25519(c,d,r);
    4ef0:	aa0e03e1 	mov	x1, x14
    4ef4:	12000242 	and	w2, w18, #0x1
    4ef8:	aa0c03e0 	mov	x0, x12
    4efc:	97fffb6c 	bl	3cac <sel25519>
  for(i=254;i>=0;--i) {
    4f00:	b100067f 	cmn	x19, #0x1
    4f04:	54fff5c1 	b.ne	4dbc <crypto_scalarmult_curve25519_tweet+0xb0>  // b.any
    4f08:	aa0d03e0 	mov	x0, x13
  FOR(i,16) {
    4f0c:	d2800001 	mov	x1, #0x0                   	// #0
    x[i+16]=a[i];
    4f10:	f8617962 	ldr	x2, [x11, x1, lsl #3]
    4f14:	f9004002 	str	x2, [x0, #128]
    x[i+32]=c[i];
    4f18:	f8617982 	ldr	x2, [x12, x1, lsl #3]
    4f1c:	f9008002 	str	x2, [x0, #256]
    x[i+48]=b[i];
    4f20:	f86179e2 	ldr	x2, [x15, x1, lsl #3]
    4f24:	f900c002 	str	x2, [x0, #384]
    x[i+64]=d[i];
    4f28:	f86179c2 	ldr	x2, [x14, x1, lsl #3]
  FOR(i,16) {
    4f2c:	91000421 	add	x1, x1, #0x1
    x[i+64]=d[i];
    4f30:	f9010002 	str	x2, [x0, #512]
  FOR(i,16) {
    4f34:	91002000 	add	x0, x0, #0x8
    4f38:	f100403f 	cmp	x1, #0x10
    4f3c:	54fffea1 	b.ne	4f10 <crypto_scalarmult_curve25519_tweet+0x204>  // b.any
  inv25519(x+32,x+32);
    4f40:	911143e1 	add	x1, sp, #0x450
    4f44:	aa0103e0 	mov	x0, x1
    4f48:	97fffbf2 	bl	3f10 <inv25519>
  M(x+16,x+16,x+32);
    4f4c:	911143e2 	add	x2, sp, #0x450
    4f50:	910f43e1 	add	x1, sp, #0x3d0
    4f54:	aa0103e0 	mov	x0, x1
    4f58:	97fffbc2 	bl	3e60 <M>
  pack25519(q,x+16);
    4f5c:	aa0003e1 	mov	x1, x0
    4f60:	aa1603e0 	mov	x0, x22
    4f64:	97fffb63 	bl	3cf0 <pack25519>
}
    4f68:	a9407bfd 	ldp	x29, x30, [sp]
    4f6c:	52800000 	mov	w0, #0x0                   	// #0
    4f70:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f74:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f78:	911743ff 	add	sp, sp, #0x5d0
    4f7c:	d65f03c0 	ret

0000000000004f80 <crypto_scalarmult_curve25519_tweet_base>:
  return crypto_scalarmult(q,n,_9);
    4f80:	d0000002 	adrp	x2, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4f84:	91098042 	add	x2, x2, #0x260
    4f88:	91126042 	add	x2, x2, #0x498
    4f8c:	17ffff60 	b	4d0c <crypto_scalarmult_curve25519_tweet>

0000000000004f90 <crypto_box_curve25519xsalsa20poly1305_tweet_keypair>:
{
    4f90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f94:	910003fd 	mov	x29, sp
    4f98:	f9000bf3 	str	x19, [sp, #16]
    4f9c:	aa0003f3 	mov	x19, x0
    4fa0:	aa0103e0 	mov	x0, x1
  randombytes(x,32);
    4fa4:	d2800401 	mov	x1, #0x20                  	// #32
    4fa8:	f90017e0 	str	x0, [sp, #40]
    4fac:	97fff811 	bl	2ff0 <randombytes>
  return crypto_scalarmult(q,n,_9);
    4fb0:	f94017e1 	ldr	x1, [sp, #40]
    4fb4:	aa1303e0 	mov	x0, x19
}
    4fb8:	f9400bf3 	ldr	x19, [sp, #16]
  return crypto_scalarmult(q,n,_9);
    4fbc:	d0000002 	adrp	x2, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4fc0:	91098042 	add	x2, x2, #0x260
}
    4fc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
  return crypto_scalarmult(q,n,_9);
    4fc8:	91126042 	add	x2, x2, #0x498
    4fcc:	17ffff50 	b	4d0c <crypto_scalarmult_curve25519_tweet>

0000000000004fd0 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm>:
{
    4fd0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fd4:	910003fd 	mov	x29, sp
    4fd8:	f9000bf3 	str	x19, [sp, #16]
    4fdc:	aa0003f3 	mov	x19, x0
    4fe0:	aa0203e0 	mov	x0, x2
  crypto_scalarmult(s,x,y);
    4fe4:	aa0103e2 	mov	x2, x1
    4fe8:	aa0003e1 	mov	x1, x0
    4fec:	910083e0 	add	x0, sp, #0x20
    4ff0:	97ffff47 	bl	4d0c <crypto_scalarmult_curve25519_tweet>
  core(out,in,k,c,1);
    4ff4:	d0000001 	adrp	x1, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    4ff8:	91098021 	add	x1, x1, #0x260
    4ffc:	910e0023 	add	x3, x1, #0x380
    5000:	910083e2 	add	x2, sp, #0x20
    5004:	aa1303e0 	mov	x0, x19
    5008:	9112e021 	add	x1, x1, #0x4b8
    500c:	52800024 	mov	w4, #0x1                   	// #1
    5010:	97fffcef 	bl	43cc <core>
}
    5014:	f9400bf3 	ldr	x19, [sp, #16]
    5018:	52800000 	mov	w0, #0x0                   	// #0
    501c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5020:	d65f03c0 	ret

0000000000005024 <crypto_box_curve25519xsalsa20poly1305_tweet_afternm>:
  return crypto_secretbox(c,m,d,n,k);
    5024:	17fffef7 	b	4c00 <crypto_secretbox_xsalsa20poly1305_tweet>

0000000000005028 <crypto_box_curve25519xsalsa20poly1305_tweet_open_afternm>:
  return crypto_secretbox_open(m,c,d,n,k);
    5028:	17ffff0e 	b	4c60 <crypto_secretbox_xsalsa20poly1305_tweet_open>

000000000000502c <crypto_box_curve25519xsalsa20poly1305_tweet>:
{
    502c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    5030:	910003fd 	mov	x29, sp
    5034:	a90153f3 	stp	x19, x20, [sp, #16]
    5038:	aa0003f3 	mov	x19, x0
    503c:	aa0103f4 	mov	x20, x1
  crypto_box_beforenm(k,y,x);
    5040:	910103e0 	add	x0, sp, #0x40
{
    5044:	aa0403e1 	mov	x1, x4
    5048:	f90013f5 	str	x21, [sp, #32]
    504c:	aa0203f5 	mov	x21, x2
    5050:	aa0503e2 	mov	x2, x5
    5054:	f9001fe3 	str	x3, [sp, #56]
  crypto_box_beforenm(k,y,x);
    5058:	97ffffde 	bl	4fd0 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm>
  return crypto_secretbox(c,m,d,n,k);
    505c:	f9401fe3 	ldr	x3, [sp, #56]
    5060:	910103e4 	add	x4, sp, #0x40
    5064:	aa1503e2 	mov	x2, x21
    5068:	aa1403e1 	mov	x1, x20
    506c:	aa1303e0 	mov	x0, x19
    5070:	97fffee4 	bl	4c00 <crypto_secretbox_xsalsa20poly1305_tweet>
}
    5074:	f94013f5 	ldr	x21, [sp, #32]
    5078:	a94153f3 	ldp	x19, x20, [sp, #16]
    507c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    5080:	d65f03c0 	ret

0000000000005084 <crypto_box_curve25519xsalsa20poly1305_tweet_open>:
{
    5084:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	aa0003f3 	mov	x19, x0
    5094:	aa0103f4 	mov	x20, x1
  crypto_box_beforenm(k,y,x);
    5098:	910103e0 	add	x0, sp, #0x40
{
    509c:	aa0403e1 	mov	x1, x4
    50a0:	f90013f5 	str	x21, [sp, #32]
    50a4:	aa0203f5 	mov	x21, x2
    50a8:	aa0503e2 	mov	x2, x5
    50ac:	f9001fe3 	str	x3, [sp, #56]
  crypto_box_beforenm(k,y,x);
    50b0:	97ffffc8 	bl	4fd0 <crypto_box_curve25519xsalsa20poly1305_tweet_beforenm>
  return crypto_secretbox_open(m,c,d,n,k);
    50b4:	f9401fe3 	ldr	x3, [sp, #56]
    50b8:	910103e4 	add	x4, sp, #0x40
    50bc:	aa1503e2 	mov	x2, x21
    50c0:	aa1403e1 	mov	x1, x20
    50c4:	aa1303e0 	mov	x0, x19
    50c8:	97fffee6 	bl	4c60 <crypto_secretbox_xsalsa20poly1305_tweet_open>
}
    50cc:	f94013f5 	ldr	x21, [sp, #32]
    50d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    50d4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    50d8:	d65f03c0 	ret

00000000000050dc <crypto_hashblocks_sha512_tweet>:
{
    50dc:	d10503ff 	sub	sp, sp, #0x140
    50e0:	d2800003 	mov	x3, #0x0                   	// #0
  FOR(i,8) z[i] = a[i] = dl64(x + 8 * i);
    50e4:	910203e7 	add	x7, sp, #0x80
    50e8:	910003e8 	mov	x8, sp
  FOR(i,8) u=(u<<8)|x[i];
    50ec:	8b030009 	add	x9, x0, x3
    50f0:	d2800005 	mov	x5, #0x0                   	// #0
  u64 i,u=0;
    50f4:	d2800004 	mov	x4, #0x0                   	// #0
  FOR(i,8) u=(u<<8)|x[i];
    50f8:	38656926 	ldrb	w6, [x9, x5]
    50fc:	910004a5 	add	x5, x5, #0x1
    5100:	aa0420c4 	orr	x4, x6, x4, lsl #8
    5104:	f10020bf 	cmp	x5, #0x8
    5108:	54ffff81 	b.ne	50f8 <crypto_hashblocks_sha512_tweet+0x1c>  // b.any
  FOR(i,8) z[i] = a[i] = dl64(x + 8 * i);
    510c:	f8276864 	str	x4, [x3, x7]
    5110:	f8286864 	str	x4, [x3, x8]
    5114:	91002063 	add	x3, x3, #0x8
    5118:	f101007f 	cmp	x3, #0x40
    511c:	54fffe81 	b.ne	50ec <crypto_hashblocks_sha512_tweet+0x10>  // b.any
    5120:	9279e049 	and	x9, x2, #0xffffffffffffff80
      t = a[7] + Sigma1(a[4]) + Ch(a[4],a[5],a[6]) + K[i] + w[i%16];
    5124:	b0000006 	adrp	x6, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    5128:	910980c6 	add	x6, x6, #0x260
    512c:	8b09002b 	add	x11, x1, x9
    FOR(i,16) w[i] = dl64(m + 8 * i);
    5130:	910303e5 	add	x5, sp, #0xc0
      FOR(j,8) b[j] = a[j];
    5134:	910103ea 	add	x10, sp, #0x40
      t = a[7] + Sigma1(a[4]) + Ch(a[4],a[5],a[6]) + K[i] + w[i%16];
    5138:	911320c6 	add	x6, x6, #0x4c8
  while (n >= 128) {
    513c:	eb0b003f 	cmp	x1, x11
    5140:	54000221 	b.ne	5184 <crypto_hashblocks_sha512_tweet+0xa8>  // b.any
    5144:	cb090042 	sub	x2, x2, x9
    5148:	d2800001 	mov	x1, #0x0                   	// #0
  FOR(i,8) ts64(x+8*i,z[i]);
    514c:	f8616904 	ldr	x4, [x8, x1]
  for (i = 7;i >= 0;--i) { x[i] = u; u >>= 8; }
    5150:	8b010005 	add	x5, x0, x1
  FOR(i,8) ts64(x+8*i,z[i]);
    5154:	d28000e3 	mov	x3, #0x7                   	// #7
  for (i = 7;i >= 0;--i) { x[i] = u; u >>= 8; }
    5158:	382368a4 	strb	w4, [x5, x3]
    515c:	d1000463 	sub	x3, x3, #0x1
    5160:	d348fc84 	lsr	x4, x4, #8
    5164:	b100047f 	cmn	x3, #0x1
    5168:	54ffff81 	b.ne	5158 <crypto_hashblocks_sha512_tweet+0x7c>  // b.any
  FOR(i,8) ts64(x+8*i,z[i]);
    516c:	91002021 	add	x1, x1, #0x8
    5170:	f101003f 	cmp	x1, #0x40
    5174:	54fffec1 	b.ne	514c <crypto_hashblocks_sha512_tweet+0x70>  // b.any
}
    5178:	2a0203e0 	mov	w0, w2
    517c:	910503ff 	add	sp, sp, #0x140
    5180:	d65f03c0 	ret
  while (n >= 128) {
    5184:	d2800003 	mov	x3, #0x0                   	// #0
  FOR(i,8) u=(u<<8)|x[i];
    5188:	8b03002e 	add	x14, x1, x3
    518c:	d2800004 	mov	x4, #0x0                   	// #0
  u64 i,u=0;
    5190:	d280000c 	mov	x12, #0x0                   	// #0
  FOR(i,8) u=(u<<8)|x[i];
    5194:	386469cd 	ldrb	w13, [x14, x4]
    5198:	91000484 	add	x4, x4, #0x1
    519c:	aa0c21ac 	orr	x12, x13, x12, lsl #8
    51a0:	f100209f 	cmp	x4, #0x8
    51a4:	54ffff81 	b.ne	5194 <crypto_hashblocks_sha512_tweet+0xb8>  // b.any
    FOR(i,16) w[i] = dl64(m + 8 * i);
    51a8:	f825686c 	str	x12, [x3, x5]
    51ac:	91002063 	add	x3, x3, #0x8
    51b0:	f102007f 	cmp	x3, #0x80
    51b4:	54fffea1 	b.ne	5188 <crypto_hashblocks_sha512_tweet+0xac>  // b.any
    51b8:	d280000c 	mov	x12, #0x0                   	// #0
    51bc:	2a0c03ed 	mov	w13, w12
  u64 i,u=0;
    51c0:	d2800003 	mov	x3, #0x0                   	// #0
      FOR(j,8) b[j] = a[j];
    51c4:	f86368e4 	ldr	x4, [x7, x3]
    51c8:	f82a6864 	str	x4, [x3, x10]
    51cc:	91002063 	add	x3, x3, #0x8
    51d0:	f101007f 	cmp	x3, #0x40
    51d4:	54ffff81 	b.ne	51c4 <crypto_hashblocks_sha512_tweet+0xe8>  // b.any
static u64 Ch(u64 x,u64 y,u64 z) { return (x & y) ^ (~x & z); }
    51d8:	a94a3fe4 	ldp	x4, x15, [sp, #160]
      t = a[7] + Sigma1(a[4]) + Ch(a[4],a[5],a[6]) + K[i] + w[i%16];
    51dc:	12000dae 	and	w14, w13, #0xf
static u64 Ch(u64 x,u64 y,u64 z) { return (x & y) ^ (~x & z); }
    51e0:	f9405be3 	ldr	x3, [sp, #176]
      t = a[7] + Sigma1(a[4]) + Ch(a[4],a[5],a[6]) + K[i] + w[i%16];
    51e4:	d37d0dad 	ubfiz	x13, x13, #3, #4
      b[7] = t + Sigma0(a[0]) + Maj(a[0],a[1],a[2]);
    51e8:	f9404bf1 	ldr	x17, [sp, #144]
static u64 Ch(u64 x,u64 y,u64 z) { return (x & y) ^ (~x & z); }
    51ec:	8a0f008f 	and	x15, x4, x15
    51f0:	8a240063 	bic	x3, x3, x4
    51f4:	ca0f0063 	eor	x3, x3, x15
static u64 R(u64 x,int c) { return (x >> c) | (x << (64 - c)); }
    51f8:	93c4488f 	ror	x15, x4, #18
static u64 Sigma1(u64 x) { return R(x,14) ^ R(x,18) ^ R(x,41); }
    51fc:	cac439ef 	eor	x15, x15, x4, ror #14
    5200:	cac4a5e4 	eor	x4, x15, x4, ror #41
      t = a[7] + Sigma1(a[4]) + Ch(a[4],a[5],a[6]) + K[i] + w[i%16];
    5204:	8b040063 	add	x3, x3, x4
    5208:	f86d68a4 	ldr	x4, [x5, x13]
      b[7] = t + Sigma0(a[0]) + Maj(a[0],a[1],a[2]);
    520c:	a9483ff0 	ldp	x16, x15, [sp, #128]
      t = a[7] + Sigma1(a[4]) + Ch(a[4],a[5],a[6]) + K[i] + w[i%16];
    5210:	8b040063 	add	x3, x3, x4
    5214:	f86c78cd 	ldr	x13, [x6, x12, lsl #3]
    5218:	f9405fe4 	ldr	x4, [sp, #184]
    521c:	8b0d0084 	add	x4, x4, x13
static u64 Maj(u64 x,u64 y,u64 z) { return (x & y) ^ (x & z) ^ (y & z); }
    5220:	ca1101ed 	eor	x13, x15, x17
      t = a[7] + Sigma1(a[4]) + Ch(a[4],a[5],a[6]) + K[i] + w[i%16];
    5224:	8b040063 	add	x3, x3, x4
static u64 R(u64 x,int c) { return (x >> c) | (x << (64 - c)); }
    5228:	93d08a04 	ror	x4, x16, #34
static u64 Sigma0(u64 x) { return R(x,28) ^ R(x,34) ^ R(x,39); }
    522c:	cad07084 	eor	x4, x4, x16, ror #28
static u64 Maj(u64 x,u64 y,u64 z) { return (x & y) ^ (x & z) ^ (y & z); }
    5230:	8a1001ad 	and	x13, x13, x16
    5234:	8a1101ef 	and	x15, x15, x17
static u64 Sigma0(u64 x) { return R(x,28) ^ R(x,34) ^ R(x,39); }
    5238:	cad09c84 	eor	x4, x4, x16, ror #39
static u64 Maj(u64 x,u64 y,u64 z) { return (x & y) ^ (x & z) ^ (y & z); }
    523c:	ca0f01ad 	eor	x13, x13, x15
      b[7] = t + Sigma0(a[0]) + Maj(a[0],a[1],a[2]);
    5240:	8b0d0084 	add	x4, x4, x13
    5244:	8b030084 	add	x4, x4, x3
    5248:	f9003fe4 	str	x4, [sp, #120]
      b[3] += t;
    524c:	f9402fe4 	ldr	x4, [sp, #88]
    5250:	8b030083 	add	x3, x4, x3
    5254:	f9002fe3 	str	x3, [sp, #88]
    5258:	d2800003 	mov	x3, #0x0                   	// #0
      FOR(j,8) a[(j+1)%8] = b[j];
    525c:	11000464 	add	w4, w3, #0x1
    5260:	f863794d 	ldr	x13, [x10, x3, lsl #3]
    5264:	d37d0884 	ubfiz	x4, x4, #3, #3
    5268:	91000463 	add	x3, x3, #0x1
    526c:	f82468ed 	str	x13, [x7, x4]
    5270:	f100207f 	cmp	x3, #0x8
    5274:	54ffff41 	b.ne	525c <crypto_hashblocks_sha512_tweet+0x180>  // b.any
      if (i%16 == 15)
    5278:	71003ddf 	cmp	w14, #0xf
    527c:	54000321 	b.ne	52e0 <crypto_hashblocks_sha512_tweet+0x204>  // b.any
    5280:	d2800024 	mov	x4, #0x1                   	// #1
	  w[j] += w[(j+9)%16] + sigma0(w[(j+1)%16]) + sigma1(w[(j+14)%16]);
    5284:	d37d0c83 	ubfiz	x3, x4, #3, #4
    5288:	8b040caf 	add	x15, x5, x4, lsl #3
    528c:	f86368ad 	ldr	x13, [x5, x3]
    5290:	11003483 	add	w3, w4, #0xd
    5294:	d37d0c63 	ubfiz	x3, x3, #3, #4
    5298:	f86368a3 	ldr	x3, [x5, x3]
static u64 R(u64 x,int c) { return (x >> c) | (x << (64 - c)); }
    529c:	93c3f46e 	ror	x14, x3, #61
static u64 sigma1(u64 x) { return R(x,19) ^ R(x,61) ^ (x >> 6); }
    52a0:	cac34dce 	eor	x14, x14, x3, ror #19
    52a4:	ca4319c3 	eor	x3, x14, x3, lsr #6
static u64 R(u64 x,int c) { return (x >> c) | (x << (64 - c)); }
    52a8:	93cd21ae 	ror	x14, x13, #8
static u64 sigma0(u64 x) { return R(x, 1) ^ R(x, 8) ^ (x >> 7); }
    52ac:	cacd05ce 	eor	x14, x14, x13, ror #1
    52b0:	ca4d1dcd 	eor	x13, x14, x13, lsr #7
	  w[j] += w[(j+9)%16] + sigma0(w[(j+1)%16]) + sigma1(w[(j+14)%16]);
    52b4:	8b0d0063 	add	x3, x3, x13
    52b8:	1100208d 	add	w13, w4, #0x8
    52bc:	f85f81ee 	ldur	x14, [x15, #-8]
    52c0:	d37d0dad 	ubfiz	x13, x13, #3, #4
	FOR(j,16)
    52c4:	91000484 	add	x4, x4, #0x1
	  w[j] += w[(j+9)%16] + sigma0(w[(j+1)%16]) + sigma1(w[(j+14)%16]);
    52c8:	f86d68ad 	ldr	x13, [x5, x13]
    52cc:	8b0e01ad 	add	x13, x13, x14
    52d0:	8b0d0063 	add	x3, x3, x13
    52d4:	f81f81e3 	stur	x3, [x15, #-8]
	FOR(j,16)
    52d8:	f100449f 	cmp	x4, #0x11
    52dc:	54fffd41 	b.ne	5284 <crypto_hashblocks_sha512_tweet+0x1a8>  // b.any
    FOR(i,80) {
    52e0:	9100058c 	add	x12, x12, #0x1
    52e4:	f101419f 	cmp	x12, #0x50
    52e8:	54fff6a1 	b.ne	51bc <crypto_hashblocks_sha512_tweet+0xe0>  // b.any
    52ec:	d2800023 	mov	x3, #0x1                   	// #1
    FOR(i,8) { a[i] += z[i]; z[i] = a[i]; }
    52f0:	8b030ced 	add	x13, x7, x3, lsl #3
    52f4:	8b030d0c 	add	x12, x8, x3, lsl #3
    52f8:	91000463 	add	x3, x3, #0x1
    52fc:	f85f818e 	ldur	x14, [x12, #-8]
    5300:	f85f81a4 	ldur	x4, [x13, #-8]
    5304:	8b0e0084 	add	x4, x4, x14
    5308:	f81f8184 	stur	x4, [x12, #-8]
    530c:	f81f81a4 	stur	x4, [x13, #-8]
    5310:	f100247f 	cmp	x3, #0x9
    5314:	54fffee1 	b.ne	52f0 <crypto_hashblocks_sha512_tweet+0x214>  // b.any
    m += 128;
    5318:	91020021 	add	x1, x1, #0x80
    n -= 128;
    531c:	17ffff88 	b	513c <crypto_hashblocks_sha512_tweet+0x60>

0000000000005320 <crypto_hash_sha512_tweet>:
{
    5320:	a9a97bfd 	stp	x29, x30, [sp, #-368]!
  FOR(i,64) h[i] = iv[i];
    5324:	b0000003 	adrp	x3, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    5328:	91098063 	add	x3, x3, #0x260
{
    532c:	910003fd 	mov	x29, sp
  FOR(i,64) h[i] = iv[i];
    5330:	911d2063 	add	x3, x3, #0x748
{
    5334:	a90153f3 	stp	x19, x20, [sp, #16]
    5338:	aa0003f3 	mov	x19, x0
  FOR(i,64) h[i] = iv[i];
    533c:	9100c3f4 	add	x20, sp, #0x30
{
    5340:	aa0203f2 	mov	x18, x2
  FOR(i,64) h[i] = iv[i];
    5344:	d2800002 	mov	x2, #0x0                   	// #0
    5348:	38636840 	ldrb	w0, [x2, x3]
    534c:	38346840 	strb	w0, [x2, x20]
    5350:	91000442 	add	x2, x2, #0x1
    5354:	f101005f 	cmp	x2, #0x40
    5358:	54ffff81 	b.ne	5348 <crypto_hash_sha512_tweet+0x28>  // b.any
  crypto_hashblocks(h,m,n);
    535c:	aa1203e2 	mov	x2, x18
    5360:	aa1403e0 	mov	x0, x20
    5364:	f90017e1 	str	x1, [sp, #40]
    5368:	97ffff5d 	bl	50dc <crypto_hashblocks_sha512_tweet>
  FOR(i,256) x[i] = 0;
    536c:	f94017e1 	ldr	x1, [sp, #40]
  n &= 127;
    5370:	92401a40 	and	x0, x18, #0x7f
  m -= n;
    5374:	9279e245 	and	x5, x18, #0xffffffffffffff80
  FOR(i,256) x[i] = 0;
    5378:	9101c3e4 	add	x4, sp, #0x70
    537c:	d2800003 	mov	x3, #0x0                   	// #0
    5380:	3824687f 	strb	wzr, [x3, x4]
    5384:	91000463 	add	x3, x3, #0x1
    5388:	f104007f 	cmp	x3, #0x100
    538c:	54ffffa1 	b.ne	5380 <crypto_hash_sha512_tweet+0x60>  // b.any
  FOR(i,n) x[i] = m[i];
    5390:	8b050021 	add	x1, x1, x5
    5394:	d2800002 	mov	x2, #0x0                   	// #0
    5398:	eb00005f 	cmp	x2, x0
    539c:	54000401 	b.ne	541c <crypto_hash_sha512_tweet+0xfc>  // b.any
  x[n] = 128;
    53a0:	12800fe0 	mov	w0, #0xffffff80            	// #-128
  n = 256-128*(n<112);
    53a4:	f101bc5f 	cmp	x2, #0x6f
  x[n] = 128;
    53a8:	38226880 	strb	w0, [x4, x2]
  n = 256-128*(n<112);
    53ac:	d2801000 	mov	x0, #0x80                  	// #128
    53b0:	9a808063 	csel	x3, x3, x0, hi	// hi = pmore
  x[n-9] = b >> 61;
    53b4:	91019fe0 	add	x0, sp, #0x67
    53b8:	d37dfe41 	lsr	x1, x18, #61
  ts64(x+n-8,b<<3);
    53bc:	d37df252 	lsl	x18, x18, #3
  x[n-9] = b >> 61;
    53c0:	38236801 	strb	w1, [x0, x3]
  for (i = 7;i >= 0;--i) { x[i] = u; u >>= 8; }
    53c4:	d1001c61 	sub	x1, x3, #0x7
    53c8:	8b010081 	add	x1, x4, x1
  ts64(x+n-8,b<<3);
    53cc:	d28000c0 	mov	x0, #0x6                   	// #6
  for (i = 7;i >= 0;--i) { x[i] = u; u >>= 8; }
    53d0:	38206832 	strb	w18, [x1, x0]
    53d4:	d1000400 	sub	x0, x0, #0x1
    53d8:	d348fe52 	lsr	x18, x18, #8
    53dc:	b100081f 	cmn	x0, #0x2
    53e0:	54ffff81 	b.ne	53d0 <crypto_hash_sha512_tweet+0xb0>  // b.any
  crypto_hashblocks(h,x,n);
    53e4:	aa0403e1 	mov	x1, x4
    53e8:	aa0303e2 	mov	x2, x3
    53ec:	aa1403e0 	mov	x0, x20
    53f0:	97ffff3b 	bl	50dc <crypto_hashblocks_sha512_tweet>
  FOR(i,64) out[i] = h[i];
    53f4:	d2800001 	mov	x1, #0x0                   	// #0
    53f8:	38616a80 	ldrb	w0, [x20, x1]
    53fc:	38216a60 	strb	w0, [x19, x1]
    5400:	91000421 	add	x1, x1, #0x1
    5404:	f101003f 	cmp	x1, #0x40
    5408:	54ffff81 	b.ne	53f8 <crypto_hash_sha512_tweet+0xd8>  // b.any
}
    540c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5410:	52800000 	mov	w0, #0x0                   	// #0
    5414:	a8d77bfd 	ldp	x29, x30, [sp], #368
    5418:	d65f03c0 	ret
  FOR(i,n) x[i] = m[i];
    541c:	38626825 	ldrb	w5, [x1, x2]
    5420:	38226885 	strb	w5, [x4, x2]
    5424:	91000442 	add	x2, x2, #0x1
    5428:	17ffffdc 	b	5398 <crypto_hash_sha512_tweet+0x78>

000000000000542c <crypto_sign_seed_keypair>:
{
    542c:	d10983ff 	sub	sp, sp, #0x260
    5430:	a9007bfd 	stp	x29, x30, [sp]
    5434:	910003fd 	mov	x29, sp
    5438:	a90153f3 	stp	x19, x20, [sp, #16]
    543c:	aa0103f3 	mov	x19, x1
    5440:	aa0003f4 	mov	x20, x0
    5444:	d2800000 	mov	x0, #0x0                   	// #0
  FOR(i,32) sk[i] = seed[i];
    5448:	38606841 	ldrb	w1, [x2, x0]
    544c:	38206a61 	strb	w1, [x19, x0]
    5450:	91000400 	add	x0, x0, #0x1
    5454:	f100801f 	cmp	x0, #0x20
    5458:	54ffff81 	b.ne	5448 <crypto_sign_seed_keypair+0x1c>  // b.any
  crypto_hash(d, sk, 32);
    545c:	aa0003e2 	mov	x2, x0
    5460:	aa1303e1 	mov	x1, x19
    5464:	910083e0 	add	x0, sp, #0x20
    5468:	390083ff 	strb	wzr, [sp, #32]
    546c:	3900ffff 	strb	wzr, [sp, #63]
    5470:	97ffffac 	bl	5320 <crypto_hash_sha512_tweet>
  d[31] &= 127;
    5474:	3940ffe0 	ldrb	w0, [sp, #63]
  FOR(i,32) sk[32 + i] = pk[i];
    5478:	91008273 	add	x19, x19, #0x20
  d[0] &= 248;
    547c:	394083e1 	ldrb	w1, [sp, #32]
  d[31] &= 127;
    5480:	12001800 	and	w0, w0, #0x7f
  d[31] |= 64;
    5484:	321a0000 	orr	w0, w0, #0x40
  d[0] &= 248;
    5488:	121d7021 	and	w1, w1, #0xfffffff8
  scalarbase(p,d);
    548c:	390083e1 	strb	w1, [sp, #32]
    5490:	910083e1 	add	x1, sp, #0x20
    5494:	3900ffe0 	strb	w0, [sp, #63]
    5498:	910183e0 	add	x0, sp, #0x60
    549c:	97fffbb1 	bl	4360 <scalarbase>
  pack(pk,p);
    54a0:	aa1403e0 	mov	x0, x20
    54a4:	910183e1 	add	x1, sp, #0x60
    54a8:	97fffb5f 	bl	4224 <pack>
    54ac:	d2800000 	mov	x0, #0x0                   	// #0
  FOR(i,32) sk[32 + i] = pk[i];
    54b0:	38606a81 	ldrb	w1, [x20, x0]
    54b4:	38206a61 	strb	w1, [x19, x0]
    54b8:	91000400 	add	x0, x0, #0x1
    54bc:	f100801f 	cmp	x0, #0x20
    54c0:	54ffff81 	b.ne	54b0 <crypto_sign_seed_keypair+0x84>  // b.any
}
    54c4:	a9407bfd 	ldp	x29, x30, [sp]
    54c8:	52800000 	mov	w0, #0x0                   	// #0
    54cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    54d0:	910983ff 	add	sp, sp, #0x260
    54d4:	d65f03c0 	ret

00000000000054d8 <crypto_sign_ed25519_tweet_keypair>:
{
    54d8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    54dc:	910003fd 	mov	x29, sp
    54e0:	a90153f3 	stp	x19, x20, [sp, #16]
    54e4:	aa0003f3 	mov	x19, x0
    54e8:	aa0103f4 	mov	x20, x1
  randombytes(seed, sizeof seed);
    54ec:	d2800401 	mov	x1, #0x20                  	// #32
    54f0:	8b2163e0 	add	x0, sp, x1
    54f4:	97fff6bf 	bl	2ff0 <randombytes>
  return crypto_sign_seed_keypair(pk, sk, seed);
    54f8:	910083e2 	add	x2, sp, #0x20
    54fc:	aa1403e1 	mov	x1, x20
    5500:	aa1303e0 	mov	x0, x19
    5504:	97ffffca 	bl	542c <crypto_sign_seed_keypair>
}
    5508:	52800000 	mov	w0, #0x0                   	// #0
    550c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5510:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5514:	d65f03c0 	ret

0000000000005518 <crypto_sign_ed25519_tweet>:

int crypto_sign(u8 *sm,u64 *smlen,const u8 *m,u64 n,const u8 *sk)
{
    5518:	d11443ff 	sub	sp, sp, #0x510
    551c:	a9007bfd 	stp	x29, x30, [sp]
    5520:	910003fd 	mov	x29, sp
    5524:	a90153f3 	stp	x19, x20, [sp, #16]
  u8 d[64],h[64],r[64];
  i64 i,j,x[64];
  gf p[4];

  crypto_hash(d, sk, 32);
    5528:	910143f4 	add	x20, sp, #0x50
{
    552c:	aa0103f3 	mov	x19, x1
  crypto_hash(d, sk, 32);
    5530:	aa0403e1 	mov	x1, x4
{
    5534:	a9025bf5 	stp	x21, x22, [sp, #32]
    5538:	aa0003f5 	mov	x21, x0
    553c:	aa0403f6 	mov	x22, x4
  crypto_hash(d, sk, 32);
    5540:	aa1403e0 	mov	x0, x20
{
    5544:	a90363f7 	stp	x23, x24, [sp, #48]
    5548:	aa0303f8 	mov	x24, x3
    554c:	aa0203f7 	mov	x23, x2
  crypto_hash(d, sk, 32);
    5550:	d2800402 	mov	x2, #0x20                  	// #32
{
    5554:	f90023f9 	str	x25, [sp, #64]
  crypto_hash(d, sk, 32);
    5558:	97ffff72 	bl	5320 <crypto_hash_sha512_tweet>
  d[0] &= 248;
  d[31] &= 127;
  d[31] |= 64;

  *smlen = n+64;
    555c:	91010319 	add	x25, x24, #0x40
  d[0] &= 248;
    5560:	394143e0 	ldrb	w0, [sp, #80]
  FOR(i,n) sm[64 + i] = m[i];
    5564:	910102a1 	add	x1, x21, #0x40
  *smlen = n+64;
    5568:	f9000279 	str	x25, [x19]
  d[0] &= 248;
    556c:	121d7000 	and	w0, w0, #0xfffffff8
    5570:	390143e0 	strb	w0, [sp, #80]
  d[31] &= 127;
    5574:	3941bfe0 	ldrb	w0, [sp, #111]
    5578:	12001800 	and	w0, w0, #0x7f
  d[31] |= 64;
    557c:	321a0000 	orr	w0, w0, #0x40
    5580:	3901bfe0 	strb	w0, [sp, #111]
  FOR(i,n) sm[64 + i] = m[i];
    5584:	d2800000 	mov	x0, #0x0                   	// #0
    5588:	eb18001f 	cmp	x0, x24
    558c:	54000921 	b.ne	56b0 <crypto_sign_ed25519_tweet+0x198>  // b.any
    5590:	910082b3 	add	x19, x21, #0x20
  FOR(i,32) sm[32 + i] = d[32 + i];
    5594:	d2800000 	mov	x0, #0x0                   	// #0
    5598:	8b000281 	add	x1, x20, x0
    559c:	39408021 	ldrb	w1, [x1, #32]
    55a0:	38206a61 	strb	w1, [x19, x0]
    55a4:	91000400 	add	x0, x0, #0x1
    55a8:	f100801f 	cmp	x0, #0x20
    55ac:	54ffff61 	b.ne	5598 <crypto_sign_ed25519_tweet+0x80>  // b.any

  crypto_hash(r, sm+32, n+32);
    55b0:	91008302 	add	x2, x24, #0x20
    55b4:	aa1303e1 	mov	x1, x19
    55b8:	910343f7 	add	x23, sp, #0xd0
  reduce(r);
  scalarbase(p,r);
  pack(sm,p);

  FOR(i,32) sm[i+32] = sk[i+32];
    55bc:	910082d6 	add	x22, x22, #0x20
  crypto_hash(r, sm+32, n+32);
    55c0:	aa1703e0 	mov	x0, x23
    55c4:	97ffff57 	bl	5320 <crypto_hash_sha512_tweet>
  reduce(r);
    55c8:	aa1703e0 	mov	x0, x23
    55cc:	97fffb02 	bl	41d4 <reduce>
  scalarbase(p,r);
    55d0:	aa1703e1 	mov	x1, x23
    55d4:	910c43e0 	add	x0, sp, #0x310
    55d8:	97fffb62 	bl	4360 <scalarbase>
  pack(sm,p);
    55dc:	aa1503e0 	mov	x0, x21
    55e0:	910c43e1 	add	x1, sp, #0x310
    55e4:	97fffb10 	bl	4224 <pack>
  FOR(i,32) sm[i+32] = sk[i+32];
    55e8:	d2800000 	mov	x0, #0x0                   	// #0
    55ec:	38606ac1 	ldrb	w1, [x22, x0]
    55f0:	38206a61 	strb	w1, [x19, x0]
    55f4:	91000400 	add	x0, x0, #0x1
    55f8:	f100801f 	cmp	x0, #0x20
    55fc:	54ffff81 	b.ne	55ec <crypto_sign_ed25519_tweet+0xd4>  // b.any
  crypto_hash(h,sm,n + 64);
    5600:	aa1503e1 	mov	x1, x21
    5604:	aa1903e2 	mov	x2, x25
    5608:	910243f6 	add	x22, sp, #0x90
    560c:	aa1603e0 	mov	x0, x22
    5610:	97ffff44 	bl	5320 <crypto_hash_sha512_tweet>
  reduce(h);
    5614:	aa1603e0 	mov	x0, x22
    5618:	97fffaef 	bl	41d4 <reduce>

  FOR(i,64) x[i] = 0;
    561c:	910443e1 	add	x1, sp, #0x110
    5620:	d2800000 	mov	x0, #0x0                   	// #0
    5624:	f820783f 	str	xzr, [x1, x0, lsl #3]
    5628:	91000400 	add	x0, x0, #0x1
    562c:	f101001f 	cmp	x0, #0x40
    5630:	54ffffa1 	b.ne	5624 <crypto_sign_ed25519_tweet+0x10c>  // b.any
  FOR(i,32) x[i] = (u64) r[i];
    5634:	d2800000 	mov	x0, #0x0                   	// #0
    5638:	38606ae2 	ldrb	w2, [x23, x0]
    563c:	f8207822 	str	x2, [x1, x0, lsl #3]
    5640:	91000400 	add	x0, x0, #0x1
    5644:	f100801f 	cmp	x0, #0x20
    5648:	54ffff81 	b.ne	5638 <crypto_sign_ed25519_tweet+0x120>  // b.any
    564c:	aa0103e3 	mov	x3, x1
  FOR(i,32) FOR(j,32) x[i+j] += h[i] * (u64) d[j];
    5650:	d2800002 	mov	x2, #0x0                   	// #0
    5654:	38626ac5 	ldrb	w5, [x22, x2]
    5658:	d2800000 	mov	x0, #0x0                   	// #0
    565c:	f8607866 	ldr	x6, [x3, x0, lsl #3]
    5660:	38606a84 	ldrb	w4, [x20, x0]
    5664:	9ba418a4 	umaddl	x4, w5, w4, x6
    5668:	f8207864 	str	x4, [x3, x0, lsl #3]
    566c:	91000400 	add	x0, x0, #0x1
    5670:	f100801f 	cmp	x0, #0x20
    5674:	54ffff41 	b.ne	565c <crypto_sign_ed25519_tweet+0x144>  // b.any
    5678:	91000442 	add	x2, x2, #0x1
    567c:	91002063 	add	x3, x3, #0x8
    5680:	f100805f 	cmp	x2, #0x20
    5684:	54fffe81 	b.ne	5654 <crypto_sign_ed25519_tweet+0x13c>  // b.any
  modL(sm + 32,x);
    5688:	aa1303e0 	mov	x0, x19
    568c:	97fffa90 	bl	40cc <modL>

  return 0;
}
    5690:	f94023f9 	ldr	x25, [sp, #64]
    5694:	52800000 	mov	w0, #0x0                   	// #0
    5698:	a9407bfd 	ldp	x29, x30, [sp]
    569c:	a94153f3 	ldp	x19, x20, [sp, #16]
    56a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56a4:	a94363f7 	ldp	x23, x24, [sp, #48]
    56a8:	911443ff 	add	sp, sp, #0x510
    56ac:	d65f03c0 	ret
  FOR(i,n) sm[64 + i] = m[i];
    56b0:	38606ae2 	ldrb	w2, [x23, x0]
    56b4:	38206822 	strb	w2, [x1, x0]
    56b8:	91000400 	add	x0, x0, #0x1
    56bc:	17ffffb3 	b	5588 <crypto_sign_ed25519_tweet+0x70>

00000000000056c0 <crypto_sign_ed25519_tweet_open>:
  M(r[3],r[0],r[1]);
  return 0;
}

int crypto_sign_open(u8 *m,u64 *mlen,const u8 *sm,u64 n,const u8 *pk)
{
    56c0:	d11e03ff 	sub	sp, sp, #0x780
    56c4:	a9007bfd 	stp	x29, x30, [sp]
    56c8:	910003fd 	mov	x29, sp
    56cc:	a90153f3 	stp	x19, x20, [sp, #16]
  int i;
  u8 t[32],h[64];
  gf p[4],q[4];

  *mlen = -1;
    56d0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
{
    56d4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56d8:	a90363f7 	stp	x23, x24, [sp, #48]
  *mlen = -1;
    56dc:	f9000034 	str	x20, [x1]
  if (n < 64) return -1;
    56e0:	f100fc7f 	cmp	x3, #0x3f
    56e4:	54001789 	b.ls	59d4 <crypto_sign_ed25519_tweet_open+0x314>  // b.plast
  set25519(r[2],gf1);
    56e8:	b000000c 	adrp	x12, 6000 <crypto_sign_ed25519_tweet_open+0x940>
    56ec:	9109818c 	add	x12, x12, #0x260
    56f0:	aa0003f6 	mov	x22, x0
    56f4:	aa0103f7 	mov	x23, x1
    56f8:	911a03e0 	add	x0, sp, #0x680
    56fc:	91080181 	add	x1, x12, #0x200
    5700:	aa0303ee 	mov	x14, x3
    5704:	aa0403ed 	mov	x13, x4
    5708:	aa0203f5 	mov	x21, x2
    570c:	97fff94a 	bl	3c34 <set25519>
  unpack25519(r[1],p);
    5710:	aa0403e1 	mov	x1, x4
    5714:	911803e0 	add	x0, sp, #0x600
    5718:	97fff9b2 	bl	3de0 <unpack25519>
  M(t,den6,num);
    571c:	910203eb 	add	x11, sp, #0x80
  S(num,r[1]);
    5720:	aa0003e1 	mov	x1, x0
    5724:	910403e0 	add	x0, sp, #0x100
    5728:	97fff9f8 	bl	3f08 <S>
  FOR(a,16) c[a]=i[a];
    572c:	910e03f3 	add	x19, sp, #0x380
  M(den,num,D);
    5730:	aa0003e1 	mov	x1, x0
    5734:	911e2182 	add	x2, x12, #0x788
    5738:	910603e0 	add	x0, sp, #0x180
    573c:	97fff9c9 	bl	3e60 <M>
  Z(num,num,r[2]);
    5740:	910403e1 	add	x1, sp, #0x100
    5744:	911a03e2 	add	x2, sp, #0x680
    5748:	aa0103e0 	mov	x0, x1
    574c:	97fff9bc 	bl	3e3c <Z>
  A(den,r[2],den);
    5750:	910603e2 	add	x2, sp, #0x180
    5754:	911a03e1 	add	x1, sp, #0x680
    5758:	aa0203e0 	mov	x0, x2
    575c:	97fff9af 	bl	3e18 <A>
  S(den2,den);
    5760:	aa0203e1 	mov	x1, x2
    5764:	910803e0 	add	x0, sp, #0x200
    5768:	97fff9e8 	bl	3f08 <S>
  S(den4,den2);
    576c:	aa0003e1 	mov	x1, x0
    5770:	910a03e0 	add	x0, sp, #0x280
    5774:	97fff9e5 	bl	3f08 <S>
  M(den6,den4,den2);
    5778:	aa0003e1 	mov	x1, x0
    577c:	910803e2 	add	x2, sp, #0x200
    5780:	910c03e0 	add	x0, sp, #0x300
    5784:	97fff9b7 	bl	3e60 <M>
  M(t,den6,num);
    5788:	aa0003e1 	mov	x1, x0
    578c:	910403e2 	add	x2, sp, #0x100
    5790:	aa0b03e0 	mov	x0, x11
    5794:	97fff9b3 	bl	3e60 <M>
  M(t,t,den);
    5798:	910603e2 	add	x2, sp, #0x180
    579c:	aa0b03e1 	mov	x1, x11
    57a0:	97fff9b0 	bl	3e60 <M>
    57a4:	d2800000 	mov	x0, #0x0                   	// #0
  FOR(a,16) c[a]=i[a];
    57a8:	f8606961 	ldr	x1, [x11, x0]
    57ac:	f8336801 	str	x1, [x0, x19]
    57b0:	91002000 	add	x0, x0, #0x8
    57b4:	f102001f 	cmp	x0, #0x80
    57b8:	54ffff81 	b.ne	57a8 <crypto_sign_ed25519_tweet_open+0xe8>  // b.any
  for(a=250;a>=0;a--) {
    57bc:	52801f54 	mov	w20, #0xfa                  	// #250
    S(c,c);
    57c0:	aa1303e1 	mov	x1, x19
    57c4:	aa1303e0 	mov	x0, x19
    57c8:	97fff9d0 	bl	3f08 <S>
    if(a!=1) M(c,c,i);
    57cc:	7100069f 	cmp	w20, #0x1
    57d0:	54000f60 	b.eq	59bc <crypto_sign_ed25519_tweet_open+0x2fc>  // b.none
    57d4:	aa0b03e2 	mov	x2, x11
    57d8:	aa1303e1 	mov	x1, x19
  for(a=250;a>=0;a--) {
    57dc:	51000694 	sub	w20, w20, #0x1
    if(a!=1) M(c,c,i);
    57e0:	97fff9a0 	bl	3e60 <M>
  for(a=250;a>=0;a--) {
    57e4:	3100069f 	cmn	w20, #0x1
    57e8:	54fffec1 	b.ne	57c0 <crypto_sign_ed25519_tweet_open+0x100>  // b.any
    57ec:	d2800000 	mov	x0, #0x0                   	// #0
  FOR(a,16) o[a]=c[a];
    57f0:	f8606a61 	ldr	x1, [x19, x0]
    57f4:	f8206961 	str	x1, [x11, x0]
    57f8:	91002000 	add	x0, x0, #0x8
    57fc:	f102001f 	cmp	x0, #0x80
    5800:	54ffff81 	b.ne	57f0 <crypto_sign_ed25519_tweet_open+0x130>  // b.any
  M(t,t,num);
    5804:	aa0b03e0 	mov	x0, x11
    5808:	910403e2 	add	x2, sp, #0x100
    580c:	aa0b03e1 	mov	x1, x11
    5810:	97fff994 	bl	3e60 <M>
  M(t,t,den);
    5814:	910603e2 	add	x2, sp, #0x180
    5818:	aa0b03e1 	mov	x1, x11
    581c:	97fff991 	bl	3e60 <M>
  M(t,t,den);
    5820:	910603e2 	add	x2, sp, #0x180
    5824:	aa0b03e1 	mov	x1, x11
    5828:	97fff98e 	bl	3e60 <M>
  M(r[0],t,den);
    582c:	911603e0 	add	x0, sp, #0x580
    5830:	910603e2 	add	x2, sp, #0x180
    5834:	aa0b03e1 	mov	x1, x11
    5838:	97fff98a 	bl	3e60 <M>
  S(chk,r[0]);
    583c:	aa0003e1 	mov	x1, x0
    5840:	aa1303e0 	mov	x0, x19
    5844:	97fff9b1 	bl	3f08 <S>
  M(chk,chk,den);
    5848:	910603e2 	add	x2, sp, #0x180
    584c:	aa1303e1 	mov	x1, x19
    5850:	97fff984 	bl	3e60 <M>
  pack25519(c,a);
    5854:	910103e0 	add	x0, sp, #0x40
    5858:	aa1303e1 	mov	x1, x19
    585c:	97fff925 	bl	3cf0 <pack25519>
  pack25519(d,b);
    5860:	910403e1 	add	x1, sp, #0x100
    5864:	910183e0 	add	x0, sp, #0x60
    5868:	97fff922 	bl	3cf0 <pack25519>
  return crypto_verify_32(c,d);
    586c:	910183e1 	add	x1, sp, #0x60
    5870:	910103e0 	add	x0, sp, #0x40
    5874:	97fffb85 	bl	4688 <crypto_verify_32_tweet>
  if (neq25519(chk, num)) M(r[0],r[0],I);
    5878:	340000a0 	cbz	w0, 588c <crypto_sign_ed25519_tweet_open+0x1cc>
    587c:	911603e1 	add	x1, sp, #0x580
    5880:	91202182 	add	x2, x12, #0x808
    5884:	aa0103e0 	mov	x0, x1
    5888:	97fff976 	bl	3e60 <M>
  S(chk,r[0]);
    588c:	aa1303e0 	mov	x0, x19
    5890:	911603e1 	add	x1, sp, #0x580
    5894:	97fff99d 	bl	3f08 <S>
  M(chk,chk,den);
    5898:	910603e2 	add	x2, sp, #0x180
    589c:	aa1303e1 	mov	x1, x19
    58a0:	97fff970 	bl	3e60 <M>
  pack25519(c,a);
    58a4:	910103e0 	add	x0, sp, #0x40
    58a8:	aa1303e1 	mov	x1, x19
    58ac:	97fff911 	bl	3cf0 <pack25519>
  pack25519(d,b);
    58b0:	910403e1 	add	x1, sp, #0x100
    58b4:	910183e0 	add	x0, sp, #0x60
    58b8:	97fff90e 	bl	3cf0 <pack25519>
  return crypto_verify_32(c,d);
    58bc:	910183e1 	add	x1, sp, #0x60
    58c0:	910103e0 	add	x0, sp, #0x40
    58c4:	97fffb71 	bl	4688 <crypto_verify_32_tweet>
  if (neq25519(chk, num)) return -1;
    58c8:	35000860 	cbnz	w0, 59d4 <crypto_sign_ed25519_tweet_open+0x314>
  pack25519(d,a);
    58cc:	911603e1 	add	x1, sp, #0x580
    58d0:	910183e0 	add	x0, sp, #0x60
    58d4:	97fff907 	bl	3cf0 <pack25519>
  return d[0]&1;
    58d8:	394183e0 	ldrb	w0, [sp, #96]
  if (par25519(r[0]) == (p[31]>>7)) Z(r[0],gf0,r[0]);
    58dc:	39407da1 	ldrb	w1, [x13, #31]
  return d[0]&1;
    58e0:	12000000 	and	w0, w0, #0x1
  if (par25519(r[0]) == (p[31]>>7)) Z(r[0],gf0,r[0]);
    58e4:	6b411c1f 	cmp	w0, w1, lsr #7
    58e8:	540000a1 	b.ne	58fc <crypto_sign_ed25519_tweet_open+0x23c>  // b.any
    58ec:	911603e2 	add	x2, sp, #0x580
    58f0:	91060181 	add	x1, x12, #0x180
    58f4:	aa0203e0 	mov	x0, x2
    58f8:	97fff951 	bl	3e3c <Z>
  M(r[3],r[0],r[1]);
    58fc:	911803e2 	add	x2, sp, #0x600
    5900:	911603e1 	add	x1, sp, #0x580
    5904:	911c03e0 	add	x0, sp, #0x700
    5908:	97fff956 	bl	3e60 <M>
    590c:	d2800002 	mov	x2, #0x0                   	// #0

  if (unpackneg(q,pk)) return -1;

  FOR(i,n) m[i] = sm[i];
    5910:	38626aa0 	ldrb	w0, [x21, x2]
    5914:	aa0203f8 	mov	x24, x2
    5918:	38226ac0 	strb	w0, [x22, x2]
    591c:	91000442 	add	x2, x2, #0x1
    5920:	eb0201df 	cmp	x14, x2
    5924:	54ffff61 	b.ne	5910 <crypto_sign_ed25519_tweet_open+0x250>  // b.any
  FOR(i,32) m[i+32] = pk[i];
    5928:	910082c1 	add	x1, x22, #0x20
  FOR(i,n) m[i] = sm[i];
    592c:	d2800000 	mov	x0, #0x0                   	// #0
  FOR(i,32) m[i+32] = pk[i];
    5930:	386069a3 	ldrb	w3, [x13, x0]
    5934:	38206823 	strb	w3, [x1, x0]
    5938:	91000400 	add	x0, x0, #0x1
    593c:	f100801f 	cmp	x0, #0x20
    5940:	54ffff81 	b.ne	5930 <crypto_sign_ed25519_tweet_open+0x270>  // b.any
  crypto_hash(h,m,n);
    5944:	aa1603e1 	mov	x1, x22
    5948:	910c03e0 	add	x0, sp, #0x300
    594c:	97fffe75 	bl	5320 <crypto_hash_sha512_tweet>

  scalarbase(q,sm + 32);
  add(p,q);
  pack(t,p);

  n -= 64;
    5950:	d100ff18 	sub	x24, x24, #0x3f
  reduce(h);
    5954:	910c03e0 	add	x0, sp, #0x300
    5958:	97fffa1f 	bl	41d4 <reduce>
  scalarmult(p,q,h);
    595c:	aa0003e2 	mov	x2, x0
    5960:	911603e1 	add	x1, sp, #0x580
    5964:	aa1303e0 	mov	x0, x19
    5968:	97fffa4a 	bl	4290 <scalarmult>
  scalarbase(q,sm + 32);
    596c:	910082a1 	add	x1, x21, #0x20
    5970:	911603e0 	add	x0, sp, #0x580
    5974:	97fffa7b 	bl	4360 <scalarbase>
  add(p,q);
    5978:	911603e1 	add	x1, sp, #0x580
    597c:	aa1303e0 	mov	x0, x19
    5980:	97fff986 	bl	3f98 <add>
  pack(t,p);
    5984:	aa1303e1 	mov	x1, x19
    5988:	910a03e0 	add	x0, sp, #0x280
    598c:	97fffa26 	bl	4224 <pack>
  if (crypto_verify_32(sm, t)) {
    5990:	910a03e1 	add	x1, sp, #0x280
    5994:	aa1503e0 	mov	x0, x21
    5998:	97fffb3c 	bl	4688 <crypto_verify_32_tweet>
    599c:	350002a0 	cbnz	w0, 59f0 <crypto_sign_ed25519_tweet_open+0x330>
    FOR(i,n) m[i] = 0;
    return -1;
  }

  FOR(i,n) m[i] = sm[i + 64];
    59a0:	910102b5 	add	x21, x21, #0x40
  if (crypto_verify_32(sm, t)) {
    59a4:	d2800000 	mov	x0, #0x0                   	// #0
  FOR(i,n) m[i] = sm[i + 64];
    59a8:	eb00031f 	cmp	x24, x0
    59ac:	54000268 	b.hi	59f8 <crypto_sign_ed25519_tweet_open+0x338>  // b.pmore
  *mlen = n;
  return 0;
    59b0:	52800014 	mov	w20, #0x0                   	// #0
  *mlen = n;
    59b4:	f90002f8 	str	x24, [x23]
  return 0;
    59b8:	14000007 	b	59d4 <crypto_sign_ed25519_tweet_open+0x314>
  for(a=250;a>=0;a--) {
    59bc:	52800014 	mov	w20, #0x0                   	// #0
    59c0:	17ffff80 	b	57c0 <crypto_sign_ed25519_tweet_open+0x100>
    FOR(i,n) m[i] = 0;
    59c4:	38206adf 	strb	wzr, [x22, x0]
    59c8:	91000400 	add	x0, x0, #0x1
    59cc:	eb00031f 	cmp	x24, x0
    59d0:	54ffffa8 	b.hi	59c4 <crypto_sign_ed25519_tweet_open+0x304>  // b.pmore
}
    59d4:	a9407bfd 	ldp	x29, x30, [sp]
    59d8:	2a1403e0 	mov	w0, w20
    59dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    59e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    59e8:	911e03ff 	add	sp, sp, #0x780
    59ec:	d65f03c0 	ret
  if (crypto_verify_32(sm, t)) {
    59f0:	d2800000 	mov	x0, #0x0                   	// #0
    59f4:	17fffff6 	b	59cc <crypto_sign_ed25519_tweet_open+0x30c>
  FOR(i,n) m[i] = sm[i + 64];
    59f8:	38606aa1 	ldrb	w1, [x21, x0]
    59fc:	38206ac1 	strb	w1, [x22, x0]
    5a00:	91000400 	add	x0, x0, #0x1
    5a04:	17ffffe9 	b	59a8 <crypto_sign_ed25519_tweet_open+0x2e8>
