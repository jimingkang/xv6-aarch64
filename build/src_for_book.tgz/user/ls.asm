
user/_ls:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  close(fd);
}

int
main(int argc, char *argv[])
{
   0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
  int i;

  if(argc < 2){
   c:	7100041f 	cmp	w0, #0x1
  10:	540000cc 	b.gt	28 <main+0x28>
    ls(".");
  14:	90000000 	adrp	x0, 0 <main>
  18:	91376400 	add	x0, x0, #0xdd9
  1c:	94000038 	bl	fc <ls>
    exit(0);
  }
  for(i=1; i<argc; i++)
    ls(argv[i]);
  exit(0);
  20:	52800000 	mov	w0, #0x0                   	// #0
  24:	94000165 	bl	5b8 <exit>
  28:	2a0003f4 	mov	w20, w0
  if(argc < 2){
  2c:	d2800033 	mov	x19, #0x1                   	// #1
    ls(argv[i]);
  30:	f8737820 	ldr	x0, [x1, x19, lsl #3]
  for(i=1; i<argc; i++)
  34:	91000673 	add	x19, x19, #0x1
    ls(argv[i]);
  38:	f90017e1 	str	x1, [sp, #40]
  3c:	94000030 	bl	fc <ls>
  for(i=1; i<argc; i++)
  40:	f94017e1 	ldr	x1, [sp, #40]
  44:	6b13029f 	cmp	w20, w19
  48:	54ffff4c 	b.gt	30 <main+0x30>
  4c:	17fffff5 	b	20 <main+0x20>

0000000000000050 <fmtname>:
{
  50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  54:	910003fd 	mov	x29, sp
  58:	a90153f3 	stp	x19, x20, [sp, #16]
  5c:	aa0003f4 	mov	x20, x0
  60:	f90013f5 	str	x21, [sp, #32]
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
  64:	940000cc 	bl	394 <strlen>
  68:	8b204293 	add	x19, x20, w0, uxtw
  6c:	eb14027f 	cmp	x19, x20
  70:	540003c2 	b.cs	e8 <fmtname+0x98>  // b.hs, b.nlast
  p++;
  74:	91000673 	add	x19, x19, #0x1
  if(strlen(p) >= DIRSIZ)
  78:	aa1303e0 	mov	x0, x19
  7c:	940000c6 	bl	394 <strlen>
  80:	7100741f 	cmp	w0, #0x1d
  84:	54000288 	b.hi	d4 <fmtname+0x84>  // b.pmore
  memmove(buf, p, strlen(p));
  88:	aa1303e0 	mov	x0, x19
  8c:	940000c2 	bl	394 <strlen>
  90:	aa1303e1 	mov	x1, x19
  94:	2a0003e2 	mov	w2, w0
  98:	90000014 	adrp	x20, 0 <main>
  9c:	9137ce94 	add	x20, x20, #0xdf3
  a0:	aa1403e0 	mov	x0, x20
  a4:	9400011d 	bl	518 <memmove>
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  a8:	aa1303e0 	mov	x0, x19
  ac:	940000ba 	bl	394 <strlen>
  b0:	2a0003f5 	mov	w21, w0
  b4:	aa1303e0 	mov	x0, x19
  return buf;
  b8:	aa1403f3 	mov	x19, x20
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  bc:	940000b6 	bl	394 <strlen>
  c0:	528003c2 	mov	w2, #0x1e                  	// #30
  c4:	52800401 	mov	w1, #0x20                  	// #32
  c8:	4b000042 	sub	w2, w2, w0
  cc:	8b354280 	add	x0, x20, w21, uxtw
  d0:	940000c1 	bl	3d4 <memset>
}
  d4:	f94013f5 	ldr	x21, [sp, #32]
  d8:	aa1303e0 	mov	x0, x19
  dc:	a94153f3 	ldp	x19, x20, [sp, #16]
  e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
  e4:	d65f03c0 	ret
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
  e8:	39400260 	ldrb	w0, [x19]
  ec:	7100bc1f 	cmp	w0, #0x2f
  f0:	54fffc20 	b.eq	74 <fmtname+0x24>  // b.none
  f4:	d1000673 	sub	x19, x19, #0x1
  f8:	17ffffdd 	b	6c <fmtname+0x1c>

00000000000000fc <ls>:
{
  fc:	d10a03ff 	sub	sp, sp, #0x280
  if((fd = open(path, 0)) < 0){
 100:	52800001 	mov	w1, #0x0                   	// #0
{
 104:	a9007bfd 	stp	x29, x30, [sp]
 108:	910003fd 	mov	x29, sp
 10c:	a90153f3 	stp	x19, x20, [sp, #16]
 110:	aa0003f4 	mov	x20, x0
 114:	a9025bf5 	stp	x21, x22, [sp, #32]
 118:	a90363f7 	stp	x23, x24, [sp, #48]
  if((fd = open(path, 0)) < 0){
 11c:	9400013f 	bl	618 <open>
 120:	36f80160 	tbz	w0, #31, 14c <ls+0x50>
}
 124:	a9407bfd 	ldp	x29, x30, [sp]
    fprintf(2, "ls: cannot open %s\n", path);
 128:	aa1403e2 	mov	x2, x20
}
 12c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    fprintf(2, "ls: cannot open %s\n", path);
 130:	90000001 	adrp	x1, 0 <main>
 134:	91361021 	add	x1, x1, #0xd84
 138:	52800040 	mov	w0, #0x2                   	// #2
}
 13c:	a94153f3 	ldp	x19, x20, [sp, #16]
 140:	a94363f7 	ldp	x23, x24, [sp, #48]
 144:	910a03ff 	add	sp, sp, #0x280
    fprintf(2, "ls: cannot open %s\n", path);
 148:	140002e4 	b	cd8 <fprintf>
 14c:	2a0003f5 	mov	w21, w0
  if(fstat(fd, &st) < 0){
 150:	910123e1 	add	x1, sp, #0x48
 154:	9400013a 	bl	63c <fstat>
 158:	36f801c0 	tbz	w0, #31, 190 <ls+0x94>
    fprintf(2, "ls: cannot stat %s\n", path);
 15c:	90000001 	adrp	x1, 0 <main>
 160:	91366021 	add	x1, x1, #0xd98
 164:	aa1403e2 	mov	x2, x20
 168:	52800040 	mov	w0, #0x2                   	// #2
 16c:	940002db 	bl	cd8 <fprintf>
  close(fd);
 170:	2a1503e0 	mov	w0, w21
 174:	94000120 	bl	5f4 <close>
}
 178:	a9407bfd 	ldp	x29, x30, [sp]
 17c:	a94153f3 	ldp	x19, x20, [sp, #16]
 180:	a9425bf5 	ldp	x21, x22, [sp, #32]
 184:	a94363f7 	ldp	x23, x24, [sp, #48]
 188:	910a03ff 	add	sp, sp, #0x280
 18c:	d65f03c0 	ret
  switch(st.type){
 190:	79c0a3e0 	ldrsh	w0, [sp, #80]
 194:	7100041f 	cmp	w0, #0x1
 198:	540001e0 	b.eq	1d4 <ls+0xd8>  // b.none
 19c:	51000800 	sub	w0, w0, #0x2
 1a0:	12003c00 	and	w0, w0, #0xffff
 1a4:	7100041f 	cmp	w0, #0x1
 1a8:	54fffe48 	b.hi	170 <ls+0x74>  // b.pmore
    printf("%s %d %d %l\n", fmtname(path), st.type, st.ino, st.size);
 1ac:	aa1403e0 	mov	x0, x20
 1b0:	97ffffa8 	bl	50 <fmtname>
 1b4:	f9402fe4 	ldr	x4, [sp, #88]
 1b8:	aa0003e1 	mov	x1, x0
 1bc:	79c0a3e2 	ldrsh	w2, [sp, #80]
 1c0:	90000000 	adrp	x0, 0 <main>
 1c4:	9136b000 	add	x0, x0, #0xdac
 1c8:	b9404fe3 	ldr	w3, [sp, #76]
 1cc:	940002d7 	bl	d28 <printf>
    break;
 1d0:	17ffffe8 	b	170 <ls+0x74>
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 1d4:	aa1403e0 	mov	x0, x20
 1d8:	9400006f 	bl	394 <strlen>
 1dc:	11008000 	add	w0, w0, #0x20
 1e0:	7108001f 	cmp	w0, #0x200
 1e4:	540000a9 	b.ls	1f8 <ls+0xfc>  // b.plast
      printf("ls: path too long\n");
 1e8:	90000000 	adrp	x0, 0 <main>
 1ec:	9136e400 	add	x0, x0, #0xdb9
 1f0:	940002ce 	bl	d28 <printf>
      break;
 1f4:	17ffffdf 	b	170 <ls+0x74>
    strcpy(buf, path);
 1f8:	aa1403e1 	mov	x1, x20
 1fc:	910203f3 	add	x19, sp, #0x80
 200:	aa1303e0 	mov	x0, x19
 204:	94000028 	bl	2a4 <strcpy>
    p = buf+strlen(buf);
 208:	aa1303e0 	mov	x0, x19
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);
 20c:	90000014 	adrp	x20, 0 <main>
 210:	91373294 	add	x20, x20, #0xdcc
    p = buf+strlen(buf);
 214:	94000060 	bl	394 <strlen>
        printf("ls: cannot stat %s\n", buf);
 218:	90000016 	adrp	x22, 0 <main>
 21c:	913662d6 	add	x22, x22, #0xd98
    p = buf+strlen(buf);
 220:	8b204277 	add	x23, x19, w0, uxtw
    *p++ = '/';
 224:	528005e1 	mov	w1, #0x2f                  	// #47
 228:	38204a61 	strb	w1, [x19, w0, uxtw]
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 22c:	910183e1 	add	x1, sp, #0x60
 230:	2a1503e0 	mov	w0, w21
 234:	52800402 	mov	w2, #0x20                  	// #32
 238:	940000e9 	bl	5dc <read>
 23c:	7100801f 	cmp	w0, #0x20
 240:	54fff981 	b.ne	170 <ls+0x74>  // b.any
      if(de.inum == 0)
 244:	7940c3e0 	ldrh	w0, [sp, #96]
 248:	34ffff20 	cbz	w0, 22c <ls+0x130>
      memmove(p, de.name, DIRSIZ);
 24c:	91018be1 	add	x1, sp, #0x62
 250:	910006e0 	add	x0, x23, #0x1
 254:	528003c2 	mov	w2, #0x1e                  	// #30
 258:	940000b0 	bl	518 <memmove>
      p[DIRSIZ] = 0;
 25c:	39007eff 	strb	wzr, [x23, #31]
      if(stat(buf, &st) < 0){
 260:	910123e1 	add	x1, sp, #0x48
 264:	aa1303e0 	mov	x0, x19
 268:	9400008c 	bl	498 <stat>
 26c:	36f800a0 	tbz	w0, #31, 280 <ls+0x184>
        printf("ls: cannot stat %s\n", buf);
 270:	aa1303e1 	mov	x1, x19
 274:	aa1603e0 	mov	x0, x22
 278:	940002ac 	bl	d28 <printf>
        continue;
 27c:	17ffffec 	b	22c <ls+0x130>
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);
 280:	aa1303e0 	mov	x0, x19
 284:	97ffff73 	bl	50 <fmtname>
 288:	f9402fe4 	ldr	x4, [sp, #88]
 28c:	aa0003e1 	mov	x1, x0
 290:	79c0a3e2 	ldrsh	w2, [sp, #80]
 294:	aa1403e0 	mov	x0, x20
 298:	b9404fe3 	ldr	w3, [sp, #76]
 29c:	940002a3 	bl	d28 <printf>
 2a0:	17ffffe3 	b	22c <ls+0x130>

00000000000002a4 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 2a4:	d2800002 	mov	x2, #0x0                   	// #0
 2a8:	38626823 	ldrb	w3, [x1, x2]
 2ac:	38226803 	strb	w3, [x0, x2]
 2b0:	91000442 	add	x2, x2, #0x1
 2b4:	35ffffa3 	cbnz	w3, 2a8 <strcpy+0x4>
    ;
  return os;
}
 2b8:	d65f03c0 	ret

00000000000002bc <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 2bc:	d2800003 	mov	x3, #0x0                   	// #0
 2c0:	4b030044 	sub	w4, w2, w3
 2c4:	7100009f 	cmp	w4, #0x0
 2c8:	5400006d 	b.le	2d4 <strncpy+0x18>
 2cc:	38636825 	ldrb	w5, [x1, x3]
 2d0:	350000e5 	cbnz	w5, 2ec <strncpy+0x30>
 2d4:	8b030003 	add	x3, x0, x3
 2d8:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 2dc:	4b010082 	sub	w2, w4, w1
 2e0:	7100005f 	cmp	w2, #0x0
 2e4:	540000ac 	b.gt	2f8 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 2e8:	d65f03c0 	ret
    *s++ = *t++;
 2ec:	38236805 	strb	w5, [x0, x3]
    n--;
 2f0:	91000463 	add	x3, x3, #0x1
 2f4:	17fffff3 	b	2c0 <strncpy+0x4>
    *s++ = 0;
 2f8:	3821687f 	strb	wzr, [x3, x1]
 2fc:	91000421 	add	x1, x1, #0x1
 300:	17fffff7 	b	2dc <strncpy+0x20>

0000000000000304 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 304:	aa0003e2 	mov	x2, x0
 308:	39400043 	ldrb	w3, [x2]
 30c:	aa0203e4 	mov	x4, x2
    s++;
 310:	91000442 	add	x2, x2, #0x1
  while(*s)
 314:	35ffffa3 	cbnz	w3, 308 <strcat+0x4>
 318:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 31c:	38626823 	ldrb	w3, [x1, x2]
 320:	38226883 	strb	w3, [x4, x2]
 324:	91000442 	add	x2, x2, #0x1
 328:	35ffffa3 	cbnz	w3, 31c <strcat+0x18>
    ;
  return os;
}
 32c:	d65f03c0 	ret

0000000000000330 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 330:	d2800002 	mov	x2, #0x0                   	// #0
 334:	38626803 	ldrb	w3, [x0, x2]
 338:	38626824 	ldrb	w4, [x1, x2]
 33c:	34000083 	cbz	w3, 34c <strcmp+0x1c>
 340:	91000442 	add	x2, x2, #0x1
 344:	6b04007f 	cmp	w3, w4
 348:	54ffff60 	b.eq	334 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 34c:	4b040060 	sub	w0, w3, w4
 350:	d65f03c0 	ret

0000000000000354 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 354:	340001c2 	cbz	w2, 38c <strncmp+0x38>
 358:	39400003 	ldrb	w3, [x0]
 35c:	34000083 	cbz	w3, 36c <strncmp+0x18>
 360:	39400024 	ldrb	w4, [x1]
 364:	6b03009f 	cmp	w4, w3
 368:	540000a0 	b.eq	37c <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 36c:	39400000 	ldrb	w0, [x0]
 370:	39400021 	ldrb	w1, [x1]
 374:	4b010000 	sub	w0, w0, w1
}
 378:	d65f03c0 	ret
    n--, p++, q++;
 37c:	51000442 	sub	w2, w2, #0x1
 380:	91000400 	add	x0, x0, #0x1
 384:	91000421 	add	x1, x1, #0x1
 388:	17fffff3 	b	354 <strncmp>
    return 0;
 38c:	52800000 	mov	w0, #0x0                   	// #0
 390:	17fffffa 	b	378 <strncmp+0x24>

0000000000000394 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 394:	d1000402 	sub	x2, x0, #0x1
 398:	d2800001 	mov	x1, #0x0                   	// #0
 39c:	aa0103e0 	mov	x0, x1
 3a0:	91000421 	add	x1, x1, #0x1
 3a4:	38616843 	ldrb	w3, [x2, x1]
 3a8:	35ffffa3 	cbnz	w3, 39c <strlen+0x8>
    ;
  return n;
}
 3ac:	d65f03c0 	ret

00000000000003b0 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 3b0:	d1000403 	sub	x3, x0, #0x1
 3b4:	d2800002 	mov	x2, #0x0                   	// #0
 3b8:	2a0203e0 	mov	w0, w2
 3bc:	6b02003f 	cmp	w1, w2
 3c0:	54000089 	b.ls	3d0 <strnlen+0x20>  // b.plast
 3c4:	91000442 	add	x2, x2, #0x1
 3c8:	38626864 	ldrb	w4, [x3, x2]
 3cc:	35ffff64 	cbnz	w4, 3b8 <strnlen+0x8>
    n++;
  return n;
}
 3d0:	d65f03c0 	ret

00000000000003d4 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 3d4:	d2800003 	mov	x3, #0x0                   	// #0
 3d8:	6b03005f 	cmp	w2, w3
 3dc:	54000048 	b.hi	3e4 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 3e0:	d65f03c0 	ret
    cdst[i] = c;
 3e4:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 3e8:	91000463 	add	x3, x3, #0x1
 3ec:	17fffffb 	b	3d8 <memset+0x4>

00000000000003f0 <strchr>:

char*
strchr(const char *s, char c)
{
 3f0:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 3f4:	39400002 	ldrb	w2, [x0]
 3f8:	35000062 	cbnz	w2, 404 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 3fc:	d2800000 	mov	x0, #0x0                   	// #0
}
 400:	d65f03c0 	ret
    if(*s == c)
 404:	6b01005f 	cmp	w2, w1
 408:	54ffffc0 	b.eq	400 <strchr+0x10>  // b.none
  for(; *s; s++)
 40c:	91000400 	add	x0, x0, #0x1
 410:	17fffff9 	b	3f4 <strchr+0x4>

0000000000000414 <gets>:

char*
gets(char *buf, int max)
{
 414:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 418:	910003fd 	mov	x29, sp
 41c:	a90153f3 	stp	x19, x20, [sp, #16]
 420:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 424:	d2800014 	mov	x20, #0x0                   	// #0
{
 428:	f9001bf7 	str	x23, [sp, #48]
 42c:	2a0103f7 	mov	w23, w1
 430:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 434:	11000695 	add	w21, w20, #0x1
 438:	2a1403f6 	mov	w22, w20
 43c:	6b1702bf 	cmp	w21, w23
 440:	540000ea 	b.ge	45c <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 444:	91013fe1 	add	x1, sp, #0x4f
 448:	52800022 	mov	w2, #0x1                   	// #1
 44c:	52800000 	mov	w0, #0x0                   	// #0
 450:	94000063 	bl	5dc <read>
    if(cc < 1)
 454:	7100001f 	cmp	w0, #0x0
 458:	5400012c 	b.gt	47c <gets+0x68>
  for(i=0; i+1 < max; ){
 45c:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 460:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 464:	aa1303e0 	mov	x0, x19
 468:	f9401bf7 	ldr	x23, [sp, #48]
 46c:	a94153f3 	ldp	x19, x20, [sp, #16]
 470:	a9425bf5 	ldp	x21, x22, [sp, #32]
 474:	a8c57bfd 	ldp	x29, x30, [sp], #80
 478:	d65f03c0 	ret
    buf[i++] = c;
 47c:	39413fe0 	ldrb	w0, [sp, #79]
 480:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 484:	91000694 	add	x20, x20, #0x1
 488:	7100281f 	cmp	w0, #0xa
 48c:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 490:	54fffd21 	b.ne	434 <gets+0x20>  // b.any
 494:	17fffff3 	b	460 <gets+0x4c>

0000000000000498 <stat>:

int
stat(const char *n, struct stat *st)
{
 498:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 49c:	910003fd 	mov	x29, sp
 4a0:	a90153f3 	stp	x19, x20, [sp, #16]
 4a4:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 4a8:	52800001 	mov	w1, #0x0                   	// #0
 4ac:	9400005b 	bl	618 <open>
  if(fd < 0)
 4b0:	37f80160 	tbnz	w0, #31, 4dc <stat+0x44>
    return -1;
  r = fstat(fd, st);
 4b4:	aa1303e1 	mov	x1, x19
 4b8:	2a0003f4 	mov	w20, w0
 4bc:	94000060 	bl	63c <fstat>
 4c0:	2a0003f3 	mov	w19, w0
  close(fd);
 4c4:	2a1403e0 	mov	w0, w20
 4c8:	9400004b 	bl	5f4 <close>
  return r;
}
 4cc:	2a1303e0 	mov	w0, w19
 4d0:	a94153f3 	ldp	x19, x20, [sp, #16]
 4d4:	a8c27bfd 	ldp	x29, x30, [sp], #32
 4d8:	d65f03c0 	ret
    return -1;
 4dc:	12800013 	mov	w19, #0xffffffff            	// #-1
 4e0:	17fffffb 	b	4cc <stat+0x34>

00000000000004e4 <atoi>:

int
atoi(const char *s)
{
 4e4:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 4e8:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 4ec:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 4f0:	39400043 	ldrb	w3, [x2]
 4f4:	5100c061 	sub	w1, w3, #0x30
 4f8:	12001c21 	and	w1, w1, #0xff
 4fc:	7100243f 	cmp	w1, #0x9
 500:	54000049 	b.ls	508 <atoi+0x24>  // b.plast
  return n;
}
 504:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 508:	1b040c01 	madd	w1, w0, w4, w3
 50c:	91000442 	add	x2, x2, #0x1
 510:	5100c020 	sub	w0, w1, #0x30
 514:	17fffff7 	b	4f0 <atoi+0xc>

0000000000000518 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 518:	eb01001f 	cmp	x0, x1
 51c:	54000263 	b.cc	568 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 520:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 524:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 528:	d2800003 	mov	x3, #0x0                   	// #0
 52c:	d1000463 	sub	x3, x3, #0x1
 530:	11000464 	add	w4, w3, #0x1
 534:	0b020084 	add	w4, w4, w2
 538:	7100009f 	cmp	w4, #0x0
 53c:	5400014d 	b.le	564 <memmove+0x4c>
      *--dst = *--src;
 540:	38636824 	ldrb	w4, [x1, x3]
 544:	382368a4 	strb	w4, [x5, x3]
 548:	17fffff9 	b	52c <memmove+0x14>
      *dst++ = *src++;
 54c:	38636824 	ldrb	w4, [x1, x3]
 550:	38236804 	strb	w4, [x0, x3]
 554:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 558:	4b030044 	sub	w4, w2, w3
 55c:	7100009f 	cmp	w4, #0x0
 560:	54ffff6c 	b.gt	54c <memmove+0x34>
  }
  return vdst;
}
 564:	d65f03c0 	ret
 568:	d2800003 	mov	x3, #0x0                   	// #0
 56c:	17fffffb 	b	558 <memmove+0x40>

0000000000000570 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 570:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 574:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 578:	d2800004 	mov	x4, #0x0                   	// #0
 57c:	eb02009f 	cmp	x4, x2
 580:	54000061 	b.ne	58c <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 584:	52800000 	mov	w0, #0x0                   	// #0
 588:	14000007 	b	5a4 <memcmp+0x34>
    if (*p1 != *p2) {
 58c:	38646803 	ldrb	w3, [x0, x4]
 590:	91000484 	add	x4, x4, #0x1
 594:	38646825 	ldrb	w5, [x1, x4]
 598:	6b05007f 	cmp	w3, w5
 59c:	54ffff00 	b.eq	57c <memcmp+0xc>  // b.none
      return *p1 - *p2;
 5a0:	4b050060 	sub	w0, w3, w5
}
 5a4:	d65f03c0 	ret

00000000000005a8 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 5a8:	17ffffdc 	b	518 <memmove>

00000000000005ac <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 5ac:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 5b0:	d4000001 	svc	#0x0
 ret
 5b4:	d65f03c0 	ret

00000000000005b8 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 5b8:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 5bc:	d4000001 	svc	#0x0
 ret
 5c0:	d65f03c0 	ret

00000000000005c4 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 5c4:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 5c8:	d4000001 	svc	#0x0
 ret
 5cc:	d65f03c0 	ret

00000000000005d0 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 5d0:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 5d4:	d4000001 	svc	#0x0
 ret
 5d8:	d65f03c0 	ret

00000000000005dc <read>:
.global read
read:
 mov x7, #SYS_read
 5dc:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 5e0:	d4000001 	svc	#0x0
 ret
 5e4:	d65f03c0 	ret

00000000000005e8 <write>:
.global write
write:
 mov x7, #SYS_write
 5e8:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 5ec:	d4000001 	svc	#0x0
 ret
 5f0:	d65f03c0 	ret

00000000000005f4 <close>:
.global close
close:
 mov x7, #SYS_close
 5f4:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 5f8:	d4000001 	svc	#0x0
 ret
 5fc:	d65f03c0 	ret

0000000000000600 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 600:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 604:	d4000001 	svc	#0x0
 ret
 608:	d65f03c0 	ret

000000000000060c <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 60c:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 610:	d4000001 	svc	#0x0
 ret
 614:	d65f03c0 	ret

0000000000000618 <open>:
.global open
open:
 mov x7, #SYS_open
 618:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 61c:	d4000001 	svc	#0x0
 ret
 620:	d65f03c0 	ret

0000000000000624 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 624:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 628:	d4000001 	svc	#0x0
 ret
 62c:	d65f03c0 	ret

0000000000000630 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 630:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 634:	d4000001 	svc	#0x0
 ret
 638:	d65f03c0 	ret

000000000000063c <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 63c:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 640:	d4000001 	svc	#0x0
 ret
 644:	d65f03c0 	ret

0000000000000648 <link>:
.global link
link:
 mov x7, #SYS_link
 648:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 64c:	d4000001 	svc	#0x0
 ret
 650:	d65f03c0 	ret

0000000000000654 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 654:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 658:	d4000001 	svc	#0x0
 ret
 65c:	d65f03c0 	ret

0000000000000660 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 660:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 664:	d4000001 	svc	#0x0
 ret
 668:	d65f03c0 	ret

000000000000066c <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 66c:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 670:	d4000001 	svc	#0x0
 ret
 674:	d65f03c0 	ret

0000000000000678 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 678:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 67c:	d4000001 	svc	#0x0
 ret
 680:	d65f03c0 	ret

0000000000000684 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 684:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 688:	d4000001 	svc	#0x0
 ret
 68c:	d65f03c0 	ret

0000000000000690 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 690:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 694:	d4000001 	svc	#0x0
 ret
 698:	d65f03c0 	ret

000000000000069c <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 69c:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 6a0:	d4000001 	svc	#0x0
 ret
 6a4:	d65f03c0 	ret

00000000000006a8 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 6a8:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 6ac:	d4000001 	svc	#0x0
 ret
 6b0:	d65f03c0 	ret

00000000000006b4 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 6b4:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 6b8:	d4000001 	svc	#0x0
 ret
 6bc:	d65f03c0 	ret

00000000000006c0 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 6c0:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 6c4:	d4000001 	svc	#0x0
 ret
 6c8:	d65f03c0 	ret

00000000000006cc <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 6cc:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 6d0:	d4000001 	svc	#0x0
 ret
 6d4:	d65f03c0 	ret

00000000000006d8 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 6d8:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 6dc:	d4000001 	svc	#0x0
 ret
 6e0:	d65f03c0 	ret

00000000000006e4 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 6e4:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 6e8:	d4000001 	svc	#0x0
 ret
 6ec:	d65f03c0 	ret

00000000000006f0 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 6f0:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 6f4:	d4000001 	svc	#0x0
 ret
 6f8:	d65f03c0 	ret

00000000000006fc <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 6fc:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 700:	d4000001 	svc	#0x0
 ret
 704:	d65f03c0 	ret

0000000000000708 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 708:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 70c:	d4000001 	svc	#0x0
 ret
 710:	d65f03c0 	ret

0000000000000714 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 714:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 718:	d4000001 	svc	#0x0
 ret
 71c:	d65f03c0 	ret

0000000000000720 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 720:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 724:	d4000001 	svc	#0x0
 ret
 728:	d65f03c0 	ret

000000000000072c <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 72c:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 730:	d4000001 	svc	#0x0
 ret
 734:	d65f03c0 	ret

0000000000000738 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 738:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 73c:	d4000001 	svc	#0x0
 ret
 740:	d65f03c0 	ret

0000000000000744 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 744:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 748:	d4000001 	svc	#0x0
 ret
 74c:	d65f03c0 	ret

0000000000000750 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 750:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 754:	d4000001 	svc	#0x0
 ret
 758:	d65f03c0 	ret

000000000000075c <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 75c:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 760:	d4000001 	svc	#0x0
 ret
 764:	d65f03c0 	ret

0000000000000768 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 768:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 76c:	d4000001 	svc	#0x0
 ret
 770:	d65f03c0 	ret

0000000000000774 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 774:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 778:	d4000001 	svc	#0x0
 ret
 77c:	d65f03c0 	ret

0000000000000780 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 780:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 784:	d4000001 	svc	#0x0
 ret
 788:	d65f03c0 	ret

000000000000078c <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 78c:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 790:	d4000001 	svc	#0x0
 ret
 794:	d65f03c0 	ret

0000000000000798 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 798:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 79c:	d4000001 	svc	#0x0
 ret
 7a0:	d65f03c0 	ret

00000000000007a4 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 7a4:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 7a8:	d4000001 	svc	#0x0
 ret
 7ac:	d65f03c0 	ret

00000000000007b0 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 7b0:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 7b4:	d4000001 	svc	#0x0
 ret
 7b8:	d65f03c0 	ret

00000000000007bc <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 7bc:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 7c0:	d4000001 	svc	#0x0
 ret
 7c4:	d65f03c0 	ret

00000000000007c8 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 7c8:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 7cc:	d4000001 	svc	#0x0
 ret
 7d0:	d65f03c0 	ret

00000000000007d4 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 7d4:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 7d8:	d4000001 	svc	#0x0
 ret
 7dc:	d65f03c0 	ret

00000000000007e0 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 7e0:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 7e4:	d4000001 	svc	#0x0
 ret
 7e8:	d65f03c0 	ret

00000000000007ec <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 7ec:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 7f0:	d4000001 	svc	#0x0
 ret
 7f4:	d65f03c0 	ret

00000000000007f8 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 7f8:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 7fc:	d4000001 	svc	#0x0
 ret
 800:	d65f03c0 	ret

0000000000000804 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 804:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 808:	d4000001 	svc	#0x0
 ret
 80c:	d65f03c0 	ret

0000000000000810 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 810:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 814:	d4000001 	svc	#0x0
 ret
 818:	d65f03c0 	ret

000000000000081c <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 81c:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 820:	d4000001 	svc	#0x0
 ret
 824:	d65f03c0 	ret

0000000000000828 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 828:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 82c:	d4000001 	svc	#0x0
 ret
 830:	d65f03c0 	ret

0000000000000834 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 834:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 838:	d4000001 	svc	#0x0
 ret
 83c:	d65f03c0 	ret

0000000000000840 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 840:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 844:	d4000001 	svc	#0x0
 ret
 848:	d65f03c0 	ret

000000000000084c <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 84c:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 850:	d4000001 	svc	#0x0
 ret
 854:	d65f03c0 	ret

0000000000000858 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 858:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 85c:	d4000001 	svc	#0x0
 ret
 860:	d65f03c0 	ret

0000000000000864 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 864:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 868:	d4000001 	svc	#0x0
 ret
 86c:	d65f03c0 	ret

0000000000000870 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 870:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 874:	d4000001 	svc	#0x0
 ret
 878:	d65f03c0 	ret

000000000000087c <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 87c:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 880:	d4000001 	svc	#0x0
 ret
 884:	d65f03c0 	ret

0000000000000888 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 888:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 88c:	d4000001 	svc	#0x0
 ret
 890:	d65f03c0 	ret

0000000000000894 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 894:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 898:	d4000001 	svc	#0x0
 ret
 89c:	d65f03c0 	ret

00000000000008a0 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 8a0:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 8a4:	d4000001 	svc	#0x0
 ret
 8a8:	d65f03c0 	ret

00000000000008ac <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 8ac:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 8b0:	d4000001 	svc	#0x0
 ret
 8b4:	d65f03c0 	ret

00000000000008b8 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 8b8:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 8bc:	d4000001 	svc	#0x0
 ret
 8c0:	d65f03c0 	ret

00000000000008c4 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 8c4:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 8c8:	d4000001 	svc	#0x0
 ret
 8cc:	d65f03c0 	ret

00000000000008d0 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 8d0:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 8d4:	d4000001 	svc	#0x0
 ret
 8d8:	d65f03c0 	ret

00000000000008dc <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 8dc:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 8e0:	d4000001 	svc	#0x0
 ret
 8e4:	d65f03c0 	ret

00000000000008e8 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 8e8:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 8ec:	d4000001 	svc	#0x0
 ret
 8f0:	d65f03c0 	ret

00000000000008f4 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 8f4:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 8f8:	d4000001 	svc	#0x0
 ret
 8fc:	d65f03c0 	ret

0000000000000900 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 900:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 904:	d4000001 	svc	#0x0
 ret
 908:	d65f03c0 	ret

000000000000090c <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 90c:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 910:	d4000001 	svc	#0x0
 ret
 914:	d65f03c0 	ret

0000000000000918 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 918:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 91c:	52800022 	mov	w2, #0x1                   	// #1
{
 920:	910003fd 	mov	x29, sp
 924:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 928:	91007fe1 	add	x1, sp, #0x1f
 92c:	97ffff2f 	bl	5e8 <write>
 930:	7100041f 	cmp	w0, #0x1
}
 934:	1a9f17e0 	cset	w0, eq	// eq = none
 938:	a8c27bfd 	ldp	x29, x30, [sp], #32
 93c:	d65f03c0 	ret

0000000000000940 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 940:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 944:	910003fd 	mov	x29, sp
 948:	a90153f3 	stp	x19, x20, [sp, #16]
 94c:	a9025bf5 	stp	x21, x22, [sp, #32]
 950:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 954:	6a417c7f 	tst	w3, w1, lsr #31
 958:	54000300 	b.eq	9b8 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 95c:	4b0103e1 	neg	w1, w1
    neg = 1;
 960:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 964:	90000003 	adrp	x3, 0 <main>
 968:	91378863 	add	x3, x3, #0xde2
 96c:	9100c3f5 	add	x21, sp, #0x30
 970:	d2800000 	mov	x0, #0x0                   	// #0
 974:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 978:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 97c:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 980:	2a0403e1 	mov	w1, w4
 984:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 988:	38666866 	ldrb	w6, [x3, x6]
 98c:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 990:	91000400 	add	x0, x0, #0x1
 994:	54ffff09 	b.ls	974 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 998:	11000493 	add	w19, w4, #0x1
  if(neg)
 99c:	34000085 	cbz	w5, 9ac <printint+0x6c>
    buf[i++] = '-';
 9a0:	528005a0 	mov	w0, #0x2d                  	// #45
 9a4:	38334aa0 	strb	w0, [x21, w19, uxtw]
 9a8:	11000893 	add	w19, w4, #0x2
 9ac:	51000673 	sub	w19, w19, #0x1
 9b0:	52800014 	mov	w20, #0x0                   	// #0
 9b4:	14000008 	b	9d4 <printint+0x94>
  neg = 0;
 9b8:	52800005 	mov	w5, #0x0                   	// #0
 9bc:	17ffffea 	b	964 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 9c0:	38736aa1 	ldrb	w1, [x21, x19]
 9c4:	2a1603e0 	mov	w0, w22
 9c8:	d1000673 	sub	x19, x19, #0x1
 9cc:	97ffffd3 	bl	918 <putc>
 9d0:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 9d4:	3100067f 	cmn	w19, #0x1
 9d8:	54ffff41 	b.ne	9c0 <printint+0x80>  // b.any
  return written;
}
 9dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
 9e0:	2a1403e0 	mov	w0, w20
 9e4:	a94153f3 	ldp	x19, x20, [sp, #16]
 9e8:	a8c47bfd 	ldp	x29, x30, [sp], #64
 9ec:	d65f03c0 	ret

00000000000009f0 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 9f0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 9f4:	910003fd 	mov	x29, sp
 9f8:	a90153f3 	stp	x19, x20, [sp, #16]
 9fc:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 a00:	52800015 	mov	w21, #0x0                   	// #0
{
 a04:	a90363f7 	stp	x23, x24, [sp, #48]
 a08:	2a0003f7 	mov	w23, w0
 a0c:	a9046bf9 	stp	x25, x26, [sp, #64]
 a10:	aa0103f9 	mov	x25, x1

  state = 0;
 a14:	52800001 	mov	w1, #0x0                   	// #0
{
 a18:	a90573fb 	stp	x27, x28, [sp, #80]
 a1c:	a9406053 	ldp	x19, x24, [x2]
 a20:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 a24:	39400320 	ldrb	w0, [x25]
 a28:	35000120 	cbnz	w0, a4c <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 a2c:	2a1503e0 	mov	w0, w21
 a30:	a94153f3 	ldp	x19, x20, [sp, #16]
 a34:	a9425bf5 	ldp	x21, x22, [sp, #32]
 a38:	a94363f7 	ldp	x23, x24, [sp, #48]
 a3c:	a9446bf9 	ldp	x25, x26, [sp, #64]
 a40:	a94573fb 	ldp	x27, x28, [sp, #80]
 a44:	a8c67bfd 	ldp	x29, x30, [sp], #96
 a48:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 a4c:	2a0003f6 	mov	w22, w0
    if(state == 0){
 a50:	35000101 	cbnz	w1, a70 <vprintf+0x80>
      if(c == '%'){
 a54:	7100941f 	cmp	w0, #0x25
 a58:	54000ba0 	b.eq	bcc <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 a5c:	2a1603e1 	mov	w1, w22
 a60:	2a1703e0 	mov	w0, w23
 a64:	97ffffad 	bl	918 <putc>
 a68:	0b0002b5 	add	w21, w21, w0
 a6c:	14000057 	b	bc8 <vprintf+0x1d8>
      if(c == 'd'){
 a70:	7101901f 	cmp	w0, #0x64
 a74:	540002a1 	b.ne	ac8 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 a78:	37f80174 	tbnz	w20, #31, aa4 <vprintf+0xb4>
 a7c:	91002e76 	add	x22, x19, #0xb
 a80:	2a1403fa 	mov	w26, w20
 a84:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a88:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 a8c:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 a90:	b9400261 	ldr	w1, [x19]
 a94:	2a1703e0 	mov	w0, w23
 a98:	97ffffaa 	bl	940 <printint>
        written += putc(fd, va_arg(ap, uint));
 a9c:	0b0002b5 	add	w21, w21, w0
 aa0:	14000048 	b	bc0 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 aa4:	1100229a 	add	w26, w20, #0x8
 aa8:	7100035f 	cmp	w26, #0x0
 aac:	5400008d 	b.le	abc <vprintf+0xcc>
 ab0:	91002e76 	add	x22, x19, #0xb
 ab4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ab8:	17fffff4 	b	a88 <vprintf+0x98>
 abc:	aa1303f6 	mov	x22, x19
 ac0:	8b34c313 	add	x19, x24, w20, sxtw
 ac4:	17fffff1 	b	a88 <vprintf+0x98>
      } else if(c == 'l') {
 ac8:	7101b01f 	cmp	w0, #0x6c
 acc:	54000201 	b.ne	b0c <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 ad0:	37f800d4 	tbnz	w20, #31, ae8 <vprintf+0xf8>
 ad4:	91003e76 	add	x22, x19, #0xf
 ad8:	2a1403fa 	mov	w26, w20
 adc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ae0:	52800003 	mov	w3, #0x0                   	// #0
 ae4:	17ffffea 	b	a8c <vprintf+0x9c>
 ae8:	1100229a 	add	w26, w20, #0x8
 aec:	7100035f 	cmp	w26, #0x0
 af0:	5400008d 	b.le	b00 <vprintf+0x110>
 af4:	91003e76 	add	x22, x19, #0xf
 af8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 afc:	17fffff9 	b	ae0 <vprintf+0xf0>
 b00:	aa1303f6 	mov	x22, x19
 b04:	8b34c313 	add	x19, x24, w20, sxtw
 b08:	17fffff6 	b	ae0 <vprintf+0xf0>
      } else if(c == 'x') {
 b0c:	7101e01f 	cmp	w0, #0x78
 b10:	54000221 	b.ne	b54 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 b14:	37f800f4 	tbnz	w20, #31, b30 <vprintf+0x140>
 b18:	91002e76 	add	x22, x19, #0xb
 b1c:	2a1403fa 	mov	w26, w20
 b20:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b24:	52800003 	mov	w3, #0x0                   	// #0
 b28:	52800202 	mov	w2, #0x10                  	// #16
 b2c:	17ffffd9 	b	a90 <vprintf+0xa0>
 b30:	1100229a 	add	w26, w20, #0x8
 b34:	7100035f 	cmp	w26, #0x0
 b38:	5400008d 	b.le	b48 <vprintf+0x158>
 b3c:	91002e76 	add	x22, x19, #0xb
 b40:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b44:	17fffff8 	b	b24 <vprintf+0x134>
 b48:	aa1303f6 	mov	x22, x19
 b4c:	8b34c313 	add	x19, x24, w20, sxtw
 b50:	17fffff5 	b	b24 <vprintf+0x134>
      } else if(c == 'p') {
 b54:	7101c01f 	cmp	w0, #0x70
 b58:	54000521 	b.ne	bfc <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 b5c:	37f803f4 	tbnz	w20, #31, bd8 <vprintf+0x1e8>
 b60:	91003e76 	add	x22, x19, #0xf
 b64:	2a1403fa 	mov	w26, w20
 b68:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b6c:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 b70:	52800601 	mov	w1, #0x30                  	// #48
 b74:	2a1703e0 	mov	w0, w23
 b78:	97ffff68 	bl	918 <putc>
 b7c:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b80:	9000001c 	adrp	x28, 0 <main>
 b84:	91378b9c 	add	x28, x28, #0xde2
  written += putc(fd, 'x');
 b88:	2a1703e0 	mov	w0, w23
 b8c:	52800f01 	mov	w1, #0x78                  	// #120
 b90:	97ffff62 	bl	918 <putc>
 b94:	0b000273 	add	w19, w19, w0
 b98:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b9c:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 ba0:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 ba4:	38606b81 	ldrb	w1, [x28, x0]
 ba8:	2a1703e0 	mov	w0, w23
 bac:	97ffff5b 	bl	918 <putc>
 bb0:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 bb4:	71000694 	subs	w20, w20, #0x1
 bb8:	54ffff21 	b.ne	b9c <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 bbc:	0b1302b5 	add	w21, w21, w19
 bc0:	2a1a03f4 	mov	w20, w26
 bc4:	aa1603f3 	mov	x19, x22
      state = 0;
 bc8:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 bcc:	91000739 	add	x25, x25, #0x1
  state = 0;
 bd0:	2a1603e1 	mov	w1, w22
 bd4:	17ffff94 	b	a24 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 bd8:	1100229a 	add	w26, w20, #0x8
 bdc:	7100035f 	cmp	w26, #0x0
 be0:	5400008d 	b.le	bf0 <vprintf+0x200>
 be4:	91003e76 	add	x22, x19, #0xf
 be8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 bec:	17ffffe0 	b	b6c <vprintf+0x17c>
 bf0:	aa1303f6 	mov	x22, x19
 bf4:	8b34c313 	add	x19, x24, w20, sxtw
 bf8:	17ffffdd 	b	b6c <vprintf+0x17c>
      } else if(c == 's'){
 bfc:	7101cc1f 	cmp	w0, #0x73
 c00:	54000381 	b.ne	c70 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 c04:	37f80214 	tbnz	w20, #31, c44 <vprintf+0x254>
 c08:	91003e61 	add	x1, x19, #0xf
 c0c:	aa1303e0 	mov	x0, x19
 c10:	927df033 	and	x19, x1, #0xfffffffffffffff8
 c14:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 c18:	90000000 	adrp	x0, 0 <main>
 c1c:	91376c00 	add	x0, x0, #0xddb
 c20:	f10002df 	cmp	x22, #0x0
 c24:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 c28:	394002c1 	ldrb	w1, [x22]
 c2c:	34fffce1 	cbz	w1, bc8 <vprintf+0x1d8>
          written += putc(fd, *s);
 c30:	2a1703e0 	mov	w0, w23
          s++;
 c34:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 c38:	97ffff38 	bl	918 <putc>
 c3c:	0b0002b5 	add	w21, w21, w0
          s++;
 c40:	17fffffa 	b	c28 <vprintf+0x238>
        s = va_arg(ap, char*);
 c44:	11002281 	add	w1, w20, #0x8
 c48:	7100003f 	cmp	w1, #0x0
 c4c:	540000cd 	b.le	c64 <vprintf+0x274>
 c50:	91003e62 	add	x2, x19, #0xf
 c54:	aa1303e0 	mov	x0, x19
 c58:	2a0103f4 	mov	w20, w1
 c5c:	927df053 	and	x19, x2, #0xfffffffffffffff8
 c60:	17ffffed 	b	c14 <vprintf+0x224>
 c64:	8b34c300 	add	x0, x24, w20, sxtw
 c68:	2a0103f4 	mov	w20, w1
 c6c:	17ffffea 	b	c14 <vprintf+0x224>
      } else if(c == 'c'){
 c70:	71018c1f 	cmp	w0, #0x63
 c74:	54000241 	b.ne	cbc <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 c78:	37f80114 	tbnz	w20, #31, c98 <vprintf+0x2a8>
 c7c:	91002e76 	add	x22, x19, #0xb
 c80:	2a1403fa 	mov	w26, w20
 c84:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c88:	39400261 	ldrb	w1, [x19]
 c8c:	2a1703e0 	mov	w0, w23
 c90:	97ffff22 	bl	918 <putc>
 c94:	17ffff82 	b	a9c <vprintf+0xac>
 c98:	1100229a 	add	w26, w20, #0x8
 c9c:	7100035f 	cmp	w26, #0x0
 ca0:	5400008d 	b.le	cb0 <vprintf+0x2c0>
 ca4:	91002e76 	add	x22, x19, #0xb
 ca8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cac:	17fffff7 	b	c88 <vprintf+0x298>
 cb0:	aa1303f6 	mov	x22, x19
 cb4:	8b34c313 	add	x19, x24, w20, sxtw
 cb8:	17fffff4 	b	c88 <vprintf+0x298>
      } else if(c == '%'){
 cbc:	7100941f 	cmp	w0, #0x25
 cc0:	54ffece0 	b.eq	a5c <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 cc4:	2a1703e0 	mov	w0, w23
 cc8:	528004a1 	mov	w1, #0x25                  	// #37
 ccc:	97ffff13 	bl	918 <putc>
 cd0:	0b0002b5 	add	w21, w21, w0
 cd4:	17ffff62 	b	a5c <vprintf+0x6c>

0000000000000cd8 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 cd8:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 cdc:	910003fd 	mov	x29, sp
 ce0:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 ce4:	910203e2 	add	x2, sp, #0x80
 ce8:	a9030be2 	stp	x2, x2, [sp, #48]
 cec:	910143e2 	add	x2, sp, #0x50
 cf0:	f90023e2 	str	x2, [sp, #64]
 cf4:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 cf8:	b9004be2 	str	w2, [sp, #72]
 cfc:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 d00:	a9430fe2 	ldp	x2, x3, [sp, #48]
 d04:	a9010fe2 	stp	x2, x3, [sp, #16]
 d08:	a9440fe2 	ldp	x2, x3, [sp, #64]
 d0c:	a9020fe2 	stp	x2, x3, [sp, #32]
 d10:	910043e2 	add	x2, sp, #0x10
{
 d14:	a90617e4 	stp	x4, x5, [sp, #96]
 d18:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 d1c:	97ffff35 	bl	9f0 <vprintf>
  va_end(ap);
  return result;
}
 d20:	a8c87bfd 	ldp	x29, x30, [sp], #128
 d24:	d65f03c0 	ret

0000000000000d28 <printf>:

int
printf(const char *fmt, ...)
{
 d28:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 d2c:	910003fd 	mov	x29, sp
 d30:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 d34:	910243e1 	add	x1, sp, #0x90
 d38:	a90307e1 	stp	x1, x1, [sp, #48]
 d3c:	910143e1 	add	x1, sp, #0x50
 d40:	f90023e1 	str	x1, [sp, #64]
 d44:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 d48:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 d4c:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 d50:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 d54:	52800020 	mov	w0, #0x1                   	// #1
{
 d58:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 d5c:	a9430fe2 	ldp	x2, x3, [sp, #48]
 d60:	a9010fe2 	stp	x2, x3, [sp, #16]
 d64:	a9440fe2 	ldp	x2, x3, [sp, #64]
 d68:	a9020fe2 	stp	x2, x3, [sp, #32]
 d6c:	910043e2 	add	x2, sp, #0x10
{
 d70:	a9079be5 	stp	x5, x6, [sp, #120]
 d74:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 d78:	97ffff1e 	bl	9f0 <vprintf>
  va_end(ap);
  return result;
}
 d7c:	a8c97bfd 	ldp	x29, x30, [sp], #144
 d80:	d65f03c0 	ret
