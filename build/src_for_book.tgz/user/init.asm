
user/_init:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  }
}

int
main(void)
{
   0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  int pid, wpid;

  // Install the Unix device namespace before opening the first user-space
  // standard descriptors.  Early kernel diagnostics do not need a device
  // node: kernel printf uses the console subsystem directly.
  unlink("/console");  // Remove the obsolete root-level compatibility node.
   4:	90000000 	adrp	x0, 0 <main>
   8:	913f6800 	add	x0, x0, #0xfda
{
   c:	910003fd 	mov	x29, sp
  10:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("/console");  // Remove the obsolete root-level compatibility node.
  14:	94000208 	bl	834 <unlink>
  mkdir("dev");
  18:	90000000 	adrp	x0, 0 <main>
  1c:	913e6400 	add	x0, x0, #0xf99
  20:	9400020e 	bl	858 <mkdir>
  mkdir("dev/input");
  24:	90000000 	adrp	x0, 0 <main>
  28:	913e7400 	add	x0, x0, #0xf9d
  2c:	9400020b 	bl	858 <mkdir>
  mknod("dev/console", CONSOLE, 0);
  30:	52800002 	mov	w2, #0x0                   	// #0
  34:	52800021 	mov	w1, #0x1                   	// #1
  38:	90000000 	adrp	x0, 0 <main>
  3c:	913f5c00 	add	x0, x0, #0xfd7
  40:	940001fa 	bl	828 <mknod>
  mknod("dev/tty", TTY, 0);
  44:	52800002 	mov	w2, #0x0                   	// #0
  48:	52800041 	mov	w1, #0x2                   	// #2
  4c:	90000000 	adrp	x0, 0 <main>
  50:	913e9c00 	add	x0, x0, #0xfa7
  54:	940001f5 	bl	828 <mknod>
  mknod("dev/ttyS0", TTYS0, 0);
  58:	52800002 	mov	w2, #0x0                   	// #0
  5c:	52800061 	mov	w1, #0x3                   	// #3
  60:	90000000 	adrp	x0, 0 <main>
  64:	913f3000 	add	x0, x0, #0xfcc
  68:	940001f0 	bl	828 <mknod>
  mknod("dev/input/event0", INPUT, 0);
  6c:	52800002 	mov	w2, #0x0                   	// #0
  70:	52800081 	mov	w1, #0x4                   	// #4
  74:	90000000 	adrp	x0, 0 <main>
  78:	913ebc00 	add	x0, x0, #0xfaf
  7c:	940001eb 	bl	828 <mknod>
  mknod("dev/video0", CAMERA, 0);
  80:	52800002 	mov	w2, #0x0                   	// #0
  84:	528000a1 	mov	w1, #0x5                   	// #5
  88:	90000000 	adrp	x0, 0 <main>
  8c:	913f0000 	add	x0, x0, #0xfc0
  90:	940001e6 	bl	828 <mknod>
  if(open("/dev/ttyS0", O_RDWR) < 0 &&
  94:	90000000 	adrp	x0, 0 <main>
  98:	913f2c00 	add	x0, x0, #0xfcb
  9c:	52800041 	mov	w1, #0x2                   	// #2
  a0:	940001df 	bl	81c <open>
  a4:	36f80100 	tbz	w0, #31, c4 <main+0xc4>
     open("/dev/console", O_RDWR) < 0)
  a8:	90000000 	adrp	x0, 0 <main>
  ac:	913f5800 	add	x0, x0, #0xfd6
  b0:	52800041 	mov	w1, #0x2                   	// #2
  b4:	940001da 	bl	81c <open>
  if(open("/dev/ttyS0", O_RDWR) < 0 &&
  b8:	36f80060 	tbz	w0, #31, c4 <main+0xc4>
  printf("init: connecting Wi-Fi from /etc/wifi.conf\n");
  pid = fork();
  if(pid == 0){
    exec("/bin/wifi", wifi_argv);
    printf("init: exec /bin/wifi failed\n");
    exit(1);
  bc:	52800020 	mov	w0, #0x1                   	// #1
  c0:	940001bf 	bl	7bc <exit>
  dup(0);
  c4:	52800000 	mov	w0, #0x0                   	// #0
  c8:	940001ea 	bl	870 <dup>
  dup(0);
  cc:	52800000 	mov	w0, #0x0                   	// #0
  d0:	940001e8 	bl	870 <dup>
  mkdir("proc");
  d4:	90000000 	adrp	x0, 0 <main>
  d8:	913f8c00 	add	x0, x0, #0xfe3
  dc:	940001df 	bl	858 <mkdir>
  mkdir("boot");
  e0:	90000000 	adrp	x0, 0 <main>
  e4:	913fa000 	add	x0, x0, #0xfe8
  e8:	940001dc 	bl	858 <mkdir>
  mkdir("mnt");
  ec:	90000000 	adrp	x0, 0 <main>
  f0:	913fb400 	add	x0, x0, #0xfed
  f4:	940001d9 	bl	858 <mkdir>
  mkdir("mnt/ext2");
  f8:	90000000 	adrp	x0, 0 <main>
  fc:	913fc400 	add	x0, x0, #0xff1
 100:	940001d6 	bl	858 <mkdir>
  mkdir("etc");
 104:	90000000 	adrp	x0, 0 <main>
 108:	913fe800 	add	x0, x0, #0xffa
 10c:	940001d3 	bl	858 <mkdir>
  mkdir("root");
 110:	90000000 	adrp	x0, 0 <main>
 114:	913ff800 	add	x0, x0, #0xffe
 118:	940001d0 	bl	858 <mkdir>
  mkdir("bin");
 11c:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 120:	91002c00 	add	x0, x0, #0xb
 124:	940001cd 	bl	858 <mkdir>
  mkdir("usr");
 128:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 12c:	91000c00 	add	x0, x0, #0x3
 130:	940001ca 	bl	858 <mkdir>
  mkdir("usr/bin");
 134:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 138:	91001c00 	add	x0, x0, #0x7
 13c:	940001c7 	bl	858 <mkdir>
  create_config("etc/hostname", "xv6-rpi3\n");
 140:	b0000001 	adrp	x1, 1000 <printf+0xd4>
 144:	91003c21 	add	x1, x1, #0xf
 148:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 14c:	91006400 	add	x0, x0, #0x19
 150:	940000bb 	bl	43c <create_config>
  create_config("etc/passwd", "root:xv6:0:0:root:/root:/bin/sh\n");
 154:	b0000001 	adrp	x1, 1000 <printf+0xd4>
 158:	91009821 	add	x1, x1, #0x26
 15c:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 160:	91011c00 	add	x0, x0, #0x47
 164:	940000b6 	bl	43c <create_config>
  create_config("etc/rc", "export PATH=/bin:/usr/bin:/:.\n");
 168:	b0000001 	adrp	x1, 1000 <printf+0xd4>
 16c:	91014821 	add	x1, x1, #0x52
 170:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 174:	9101c400 	add	x0, x0, #0x71
 178:	940000b1 	bl	43c <create_config>
  create_config("etc/fstab",
 17c:	b0000001 	adrp	x1, 1000 <printf+0xd4>
 180:	9101e021 	add	x1, x1, #0x78
 184:	90000000 	adrp	x0, 0 <main>
 188:	913e2400 	add	x0, x0, #0xf89
 18c:	940000ac 	bl	43c <create_config>
  create_config("etc/wifi.conf",
 190:	b0000001 	adrp	x1, 1000 <printf+0xd4>
 194:	91031c21 	add	x1, x1, #0xc7
 198:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 19c:	9103a400 	add	x0, x0, #0xe9
 1a0:	940000a7 	bl	43c <create_config>
  mount_fstab();
 1a4:	94000050 	bl	2e4 <mount_fstab>
  char *wifi_argv[] = { "wifi", 0 };
 1a8:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 1ac:	9104a000 	add	x0, x0, #0x128
 1b0:	a9027fe0 	stp	x0, xzr, [sp, #32]
  printf("init: connecting Wi-Fi from /etc/wifi.conf\n");
 1b4:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 1b8:	9103dc00 	add	x0, x0, #0xf7
 1bc:	9400035c 	bl	f2c <printf>
  pid = fork();
 1c0:	9400017c 	bl	7b0 <fork>
  if(pid == 0){
 1c4:	7100001f 	cmp	w0, #0x0
 1c8:	35000120 	cbnz	w0, 1ec <main+0x1ec>
    exec("/bin/wifi", wifi_argv);
 1cc:	910083e1 	add	x1, sp, #0x20
 1d0:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 1d4:	91048c00 	add	x0, x0, #0x123
 1d8:	9400018e 	bl	810 <exec>
    printf("init: exec /bin/wifi failed\n");
 1dc:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 1e0:	9104b400 	add	x0, x0, #0x12d
 1e4:	94000352 	bl	f2c <printf>
 1e8:	17ffffb5 	b	bc <main+0xbc>
  }
  if(pid > 0)
 1ec:	5400006d 	b.le	1f8 <main+0x1f8>
    wait(0);
 1f0:	d2800000 	mov	x0, #0x0                   	// #0
 1f4:	94000175 	bl	7c8 <wait>
#endif

  for(;;){
    printf("init: starting local login on /dev/ttyS0\n");
 1f8:	b0000013 	adrp	x19, 1000 <printf+0xd4>
 1fc:	91052a73 	add	x19, x19, #0x14a
 200:	aa1303e0 	mov	x0, x19
 204:	9400034a 	bl	f2c <printf>
    pid = fork();
 208:	9400016a 	bl	7b0 <fork>
 20c:	2a0003f4 	mov	w20, w0
    if(pid < 0){
 210:	36f80080 	tbz	w0, #31, 220 <main+0x220>
      printf("init: fork failed\n");
 214:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 218:	9105d000 	add	x0, x0, #0x174
 21c:	17fffff2 	b	1e4 <main+0x1e4>
      exit(1);
    }
    if(pid == 0){
 220:	35000120 	cbnz	w0, 244 <main+0x244>
      exec("/bin/login", argv);
 224:	b0000001 	adrp	x1, 1000 <printf+0xd4>
 228:	9107a021 	add	x1, x1, #0x1e8
 22c:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 230:	91061c00 	add	x0, x0, #0x187
 234:	94000177 	bl	810 <exec>
      printf("init: exec login failed\n");
 238:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 23c:	91064800 	add	x0, x0, #0x192
 240:	17ffffe9 	b	1e4 <main+0x1e4>
    }

    for(;;){
      // this call to wait() returns if the shell exits,
      // or if a parentless process exits.
      wpid = wait((int *) 0);
 244:	d2800000 	mov	x0, #0x0                   	// #0
 248:	94000160 	bl	7c8 <wait>
      if(wpid == pid){
 24c:	6b00029f 	cmp	w20, w0
 250:	54fffd80 	b.eq	200 <main+0x200>  // b.none
        // the shell exited; restart it.
        break;
      } else if(wpid < 0){
 254:	36ffff80 	tbz	w0, #31, 244 <main+0x244>
        printf("init: wait returned an error\n");
 258:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 25c:	9106ac00 	add	x0, x0, #0x1ab
 260:	17ffffe1 	b	1e4 <main+0x1e4>

0000000000000264 <field>:
{
 264:	aa0003e3 	mov	x3, x0
  char *p = *cursor, *start;
 268:	f9400000 	ldr	x0, [x0]
  while(*p == ' ' || *p == '\t')
 26c:	39400001 	ldrb	w1, [x0]
 270:	7100803f 	cmp	w1, #0x20
 274:	7a491824 	ccmp	w1, #0x9, #0x4, ne	// ne = any
 278:	540001a0 	b.eq	2ac <field+0x48>  // b.none
  if(*p == 0 || *p == '\n' || *p == '#'){
 27c:	71008c3f 	cmp	w1, #0x23
 280:	540001a9 	b.ls	2b4 <field+0x50>  // b.plast
  while(*p == ' ' || *p == '\t')
 284:	aa0003e1 	mov	x1, x0
  while(*p && *p != ' ' && *p != '\t' && *p != '\n')
 288:	39400022 	ldrb	w2, [x1]
 28c:	121a7844 	and	w4, w2, #0xffffffdf
 290:	34000244 	cbz	w4, 2d8 <field+0x74>
 294:	51002442 	sub	w2, w2, #0x9
 298:	12001c42 	and	w2, w2, #0xff
 29c:	7100045f 	cmp	w2, #0x1
 2a0:	54000188 	b.hi	2d0 <field+0x6c>  // b.pmore
    *p++ = 0;
 2a4:	3800143f 	strb	wzr, [x1], #1
 2a8:	1400000d 	b	2dc <field+0x78>
    p++;
 2ac:	91000400 	add	x0, x0, #0x1
 2b0:	17ffffef 	b	26c <field+0x8>
 2b4:	d2808022 	mov	x2, #0x401                 	// #1025
 2b8:	f2c00102 	movk	x2, #0x8, lsl #32
 2bc:	9ac12441 	lsr	x1, x2, x1
 2c0:	3607fe21 	tbz	w1, #0, 284 <field+0x20>
  while(*p == ' ' || *p == '\t')
 2c4:	aa0003e1 	mov	x1, x0
 2c8:	d2800000 	mov	x0, #0x0                   	// #0
 2cc:	14000004 	b	2dc <field+0x78>
    p++;
 2d0:	91000421 	add	x1, x1, #0x1
 2d4:	17ffffed 	b	288 <field+0x24>
  if(*p)
 2d8:	35fffe62 	cbnz	w2, 2a4 <field+0x40>
    *cursor = p;
 2dc:	f9000061 	str	x1, [x3]
}
 2e0:	d65f03c0 	ret

00000000000002e4 <mount_fstab>:
{
 2e4:	d10943ff 	sub	sp, sp, #0x250
  int fd = open("/etc/fstab", O_RDONLY);
 2e8:	90000000 	adrp	x0, 0 <main>
 2ec:	913e2000 	add	x0, x0, #0xf88
 2f0:	52800001 	mov	w1, #0x0                   	// #0
{
 2f4:	a9007bfd 	stp	x29, x30, [sp]
 2f8:	910003fd 	mov	x29, sp
 2fc:	a90153f3 	stp	x19, x20, [sp, #16]
 300:	a9025bf5 	stp	x21, x22, [sp, #32]
 304:	a90363f7 	stp	x23, x24, [sp, #48]
  int fd = open("/etc/fstab", O_RDONLY);
 308:	94000145 	bl	81c <open>
  if(fd < 0)
 30c:	37f80260 	tbnz	w0, #31, 358 <mount_fstab+0x74>
  n = read(fd, buf, sizeof(buf) - 1);
 310:	910143f5 	add	x21, sp, #0x50
 314:	52803fe2 	mov	w2, #0x1ff                 	// #511
 318:	aa1503e1 	mov	x1, x21
 31c:	2a0003f4 	mov	w20, w0
 320:	94000130 	bl	7e0 <read>
 324:	2a0003f3 	mov	w19, w0
  close(fd);
 328:	2a1403e0 	mov	w0, w20
 32c:	94000133 	bl	7f8 <close>
  if(n <= 0)
 330:	7100027f 	cmp	w19, #0x0
 334:	5400012d 	b.le	358 <mount_fstab+0x74>
  while(*p){
 338:	aa1503e1 	mov	x1, x21
  buf[n] = 0;
 33c:	38334abf 	strb	wzr, [x21, w19, uxtw]
        int flags = strcmp(options, "ro") == 0 ? 1 : 0;
 340:	90000013 	adrp	x19, 0 <main>
 344:	913e4e73 	add	x19, x19, #0xf93
  p = buf;
 348:	f90027e1 	str	x1, [sp, #72]
  while(*p){
 34c:	f94027e0 	ldr	x0, [sp, #72]
 350:	39400000 	ldrb	w0, [x0]
 354:	350000e0 	cbnz	w0, 370 <mount_fstab+0x8c>
}
 358:	a9407bfd 	ldp	x29, x30, [sp]
 35c:	a94153f3 	ldp	x19, x20, [sp, #16]
 360:	a9425bf5 	ldp	x21, x22, [sp, #32]
 364:	a94363f7 	ldp	x23, x24, [sp, #48]
 368:	910943ff 	add	sp, sp, #0x250
 36c:	d65f03c0 	ret
    source = field(&p);
 370:	910123e0 	add	x0, sp, #0x48
 374:	97ffffbc 	bl	264 <field>
 378:	aa0003f5 	mov	x21, x0
    if(source){
 37c:	b4000400 	cbz	x0, 3fc <mount_fstab+0x118>
      target = field(&p);
 380:	910123e0 	add	x0, sp, #0x48
 384:	97ffffb8 	bl	264 <field>
 388:	aa0003f6 	mov	x22, x0
      type = field(&p);
 38c:	910123e0 	add	x0, sp, #0x48
 390:	97ffffb5 	bl	264 <field>
 394:	aa0003f7 	mov	x23, x0
      options = field(&p);
 398:	910123e0 	add	x0, sp, #0x48
 39c:	97ffffb2 	bl	264 <field>
      if(target && type && options){
 3a0:	f10002df 	cmp	x22, #0x0
      options = field(&p);
 3a4:	aa0003f4 	mov	x20, x0
      if(target && type && options){
 3a8:	fa401ae4 	ccmp	x23, #0x0, #0x4, ne	// ne = any
 3ac:	54000280 	b.eq	3fc <mount_fstab+0x118>  // b.none
 3b0:	b4000260 	cbz	x0, 3fc <mount_fstab+0x118>
        int flags = strcmp(options, "ro") == 0 ? 1 : 0;
 3b4:	aa1303e1 	mov	x1, x19
 3b8:	9400005f 	bl	534 <strcmp>
        if(strcmp(options, "ro") == 0 || strcmp(options, "rw") == 0)
 3bc:	aa1303e1 	mov	x1, x19
        int flags = strcmp(options, "ro") == 0 ? 1 : 0;
 3c0:	2a0003f8 	mov	w24, w0
        if(strcmp(options, "ro") == 0 || strcmp(options, "rw") == 0)
 3c4:	aa1403e0 	mov	x0, x20
 3c8:	9400005b 	bl	534 <strcmp>
 3cc:	340000c0 	cbz	w0, 3e4 <mount_fstab+0x100>
 3d0:	90000001 	adrp	x1, 0 <main>
 3d4:	913e5821 	add	x1, x1, #0xf96
 3d8:	aa1403e0 	mov	x0, x20
 3dc:	94000056 	bl	534 <strcmp>
 3e0:	350000e0 	cbnz	w0, 3fc <mount_fstab+0x118>
        int flags = strcmp(options, "ro") == 0 ? 1 : 0;
 3e4:	7100031f 	cmp	w24, #0x0
          mount(source, target, type, flags);
 3e8:	aa1703e2 	mov	x2, x23
 3ec:	1a9f17e3 	cset	w3, eq	// eq = none
 3f0:	aa1603e1 	mov	x1, x22
 3f4:	aa1503e0 	mov	x0, x21
 3f8:	94000160 	bl	978 <mount>
 3fc:	f94027e2 	ldr	x2, [sp, #72]
{
 400:	52800003 	mov	w3, #0x0                   	// #0
    while(*p && *p != '\n')
 404:	39400041 	ldrb	w1, [x2]
 408:	aa0203e0 	mov	x0, x2
 40c:	2a0303e4 	mov	w4, w3
 410:	91000442 	add	x2, x2, #0x1
 414:	7100003f 	cmp	w1, #0x0
 418:	7a4a1824 	ccmp	w1, #0xa, #0x4, ne	// ne = any
 41c:	1a9f07e3 	cset	w3, ne	// ne = any
 420:	54ffff21 	b.ne	404 <mount_fstab+0x120>  // b.any
 424:	34000044 	cbz	w4, 42c <mount_fstab+0x148>
 428:	f90027e0 	str	x0, [sp, #72]
    if(*p == '\n')
 42c:	7100283f 	cmp	w1, #0xa
 430:	54fff8e1 	b.ne	34c <mount_fstab+0x68>  // b.any
      p++;
 434:	91000401 	add	x1, x0, #0x1
 438:	17ffffc4 	b	348 <mount_fstab+0x64>

000000000000043c <create_config>:
{
 43c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 440:	910003fd 	mov	x29, sp
 444:	a90153f3 	stp	x19, x20, [sp, #16]
 448:	aa0103f4 	mov	x20, x1
 44c:	aa0003f3 	mov	x19, x0
  int fd = open(path, O_RDONLY);
 450:	52800001 	mov	w1, #0x0                   	// #0
 454:	940000f2 	bl	81c <open>
  if(fd >= 0){
 458:	37f80080 	tbnz	w0, #31, 468 <create_config+0x2c>
}
 45c:	a94153f3 	ldp	x19, x20, [sp, #16]
 460:	a8c27bfd 	ldp	x29, x30, [sp], #32
    close(fd);
 464:	140000e5 	b	7f8 <close>
  fd = open(path, O_CREATE | O_WRONLY);
 468:	aa1303e0 	mov	x0, x19
 46c:	52804021 	mov	w1, #0x201                 	// #513
 470:	940000eb 	bl	81c <open>
 474:	2a0003f3 	mov	w19, w0
  if(fd >= 0){
 478:	37f80120 	tbnz	w0, #31, 49c <create_config+0x60>
    write(fd, contents, strlen(contents));
 47c:	aa1403e0 	mov	x0, x20
 480:	94000046 	bl	598 <strlen>
 484:	aa1403e1 	mov	x1, x20
 488:	2a0003e2 	mov	w2, w0
 48c:	2a1303e0 	mov	w0, w19
 490:	940000d7 	bl	7ec <write>
    close(fd);
 494:	2a1303e0 	mov	w0, w19
 498:	17fffff1 	b	45c <create_config+0x20>
}
 49c:	a94153f3 	ldp	x19, x20, [sp, #16]
 4a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
 4a4:	d65f03c0 	ret

00000000000004a8 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 4a8:	d2800002 	mov	x2, #0x0                   	// #0
 4ac:	38626823 	ldrb	w3, [x1, x2]
 4b0:	38226803 	strb	w3, [x0, x2]
 4b4:	91000442 	add	x2, x2, #0x1
 4b8:	35ffffa3 	cbnz	w3, 4ac <strcpy+0x4>
    ;
  return os;
}
 4bc:	d65f03c0 	ret

00000000000004c0 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 4c0:	d2800003 	mov	x3, #0x0                   	// #0
 4c4:	4b030044 	sub	w4, w2, w3
 4c8:	7100009f 	cmp	w4, #0x0
 4cc:	5400006d 	b.le	4d8 <strncpy+0x18>
 4d0:	38636825 	ldrb	w5, [x1, x3]
 4d4:	350000e5 	cbnz	w5, 4f0 <strncpy+0x30>
 4d8:	8b030003 	add	x3, x0, x3
 4dc:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 4e0:	4b010082 	sub	w2, w4, w1
 4e4:	7100005f 	cmp	w2, #0x0
 4e8:	540000ac 	b.gt	4fc <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 4ec:	d65f03c0 	ret
    *s++ = *t++;
 4f0:	38236805 	strb	w5, [x0, x3]
    n--;
 4f4:	91000463 	add	x3, x3, #0x1
 4f8:	17fffff3 	b	4c4 <strncpy+0x4>
    *s++ = 0;
 4fc:	3821687f 	strb	wzr, [x3, x1]
 500:	91000421 	add	x1, x1, #0x1
 504:	17fffff7 	b	4e0 <strncpy+0x20>

0000000000000508 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 508:	aa0003e2 	mov	x2, x0
 50c:	39400043 	ldrb	w3, [x2]
 510:	aa0203e4 	mov	x4, x2
    s++;
 514:	91000442 	add	x2, x2, #0x1
  while(*s)
 518:	35ffffa3 	cbnz	w3, 50c <strcat+0x4>
 51c:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 520:	38626823 	ldrb	w3, [x1, x2]
 524:	38226883 	strb	w3, [x4, x2]
 528:	91000442 	add	x2, x2, #0x1
 52c:	35ffffa3 	cbnz	w3, 520 <strcat+0x18>
    ;
  return os;
}
 530:	d65f03c0 	ret

0000000000000534 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 534:	d2800002 	mov	x2, #0x0                   	// #0
 538:	38626803 	ldrb	w3, [x0, x2]
 53c:	38626824 	ldrb	w4, [x1, x2]
 540:	34000083 	cbz	w3, 550 <strcmp+0x1c>
 544:	91000442 	add	x2, x2, #0x1
 548:	6b04007f 	cmp	w3, w4
 54c:	54ffff60 	b.eq	538 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 550:	4b040060 	sub	w0, w3, w4
 554:	d65f03c0 	ret

0000000000000558 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 558:	340001c2 	cbz	w2, 590 <strncmp+0x38>
 55c:	39400003 	ldrb	w3, [x0]
 560:	34000083 	cbz	w3, 570 <strncmp+0x18>
 564:	39400024 	ldrb	w4, [x1]
 568:	6b03009f 	cmp	w4, w3
 56c:	540000a0 	b.eq	580 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 570:	39400000 	ldrb	w0, [x0]
 574:	39400021 	ldrb	w1, [x1]
 578:	4b010000 	sub	w0, w0, w1
}
 57c:	d65f03c0 	ret
    n--, p++, q++;
 580:	51000442 	sub	w2, w2, #0x1
 584:	91000400 	add	x0, x0, #0x1
 588:	91000421 	add	x1, x1, #0x1
 58c:	17fffff3 	b	558 <strncmp>
    return 0;
 590:	52800000 	mov	w0, #0x0                   	// #0
 594:	17fffffa 	b	57c <strncmp+0x24>

0000000000000598 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 598:	d1000402 	sub	x2, x0, #0x1
 59c:	d2800001 	mov	x1, #0x0                   	// #0
 5a0:	aa0103e0 	mov	x0, x1
 5a4:	91000421 	add	x1, x1, #0x1
 5a8:	38616843 	ldrb	w3, [x2, x1]
 5ac:	35ffffa3 	cbnz	w3, 5a0 <strlen+0x8>
    ;
  return n;
}
 5b0:	d65f03c0 	ret

00000000000005b4 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 5b4:	d1000403 	sub	x3, x0, #0x1
 5b8:	d2800002 	mov	x2, #0x0                   	// #0
 5bc:	2a0203e0 	mov	w0, w2
 5c0:	6b02003f 	cmp	w1, w2
 5c4:	54000089 	b.ls	5d4 <strnlen+0x20>  // b.plast
 5c8:	91000442 	add	x2, x2, #0x1
 5cc:	38626864 	ldrb	w4, [x3, x2]
 5d0:	35ffff64 	cbnz	w4, 5bc <strnlen+0x8>
    n++;
  return n;
}
 5d4:	d65f03c0 	ret

00000000000005d8 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 5d8:	d2800003 	mov	x3, #0x0                   	// #0
 5dc:	6b03005f 	cmp	w2, w3
 5e0:	54000048 	b.hi	5e8 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 5e4:	d65f03c0 	ret
    cdst[i] = c;
 5e8:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 5ec:	91000463 	add	x3, x3, #0x1
 5f0:	17fffffb 	b	5dc <memset+0x4>

00000000000005f4 <strchr>:

char*
strchr(const char *s, char c)
{
 5f4:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 5f8:	39400002 	ldrb	w2, [x0]
 5fc:	35000062 	cbnz	w2, 608 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 600:	d2800000 	mov	x0, #0x0                   	// #0
}
 604:	d65f03c0 	ret
    if(*s == c)
 608:	6b01005f 	cmp	w2, w1
 60c:	54ffffc0 	b.eq	604 <strchr+0x10>  // b.none
  for(; *s; s++)
 610:	91000400 	add	x0, x0, #0x1
 614:	17fffff9 	b	5f8 <strchr+0x4>

0000000000000618 <gets>:

char*
gets(char *buf, int max)
{
 618:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 61c:	910003fd 	mov	x29, sp
 620:	a90153f3 	stp	x19, x20, [sp, #16]
 624:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 628:	d2800014 	mov	x20, #0x0                   	// #0
{
 62c:	f9001bf7 	str	x23, [sp, #48]
 630:	2a0103f7 	mov	w23, w1
 634:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 638:	11000695 	add	w21, w20, #0x1
 63c:	2a1403f6 	mov	w22, w20
 640:	6b1702bf 	cmp	w21, w23
 644:	540000ea 	b.ge	660 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 648:	91013fe1 	add	x1, sp, #0x4f
 64c:	52800022 	mov	w2, #0x1                   	// #1
 650:	52800000 	mov	w0, #0x0                   	// #0
 654:	94000063 	bl	7e0 <read>
    if(cc < 1)
 658:	7100001f 	cmp	w0, #0x0
 65c:	5400012c 	b.gt	680 <gets+0x68>
  for(i=0; i+1 < max; ){
 660:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 664:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 668:	aa1303e0 	mov	x0, x19
 66c:	f9401bf7 	ldr	x23, [sp, #48]
 670:	a94153f3 	ldp	x19, x20, [sp, #16]
 674:	a9425bf5 	ldp	x21, x22, [sp, #32]
 678:	a8c57bfd 	ldp	x29, x30, [sp], #80
 67c:	d65f03c0 	ret
    buf[i++] = c;
 680:	39413fe0 	ldrb	w0, [sp, #79]
 684:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 688:	91000694 	add	x20, x20, #0x1
 68c:	7100281f 	cmp	w0, #0xa
 690:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 694:	54fffd21 	b.ne	638 <gets+0x20>  // b.any
 698:	17fffff3 	b	664 <gets+0x4c>

000000000000069c <stat>:

int
stat(const char *n, struct stat *st)
{
 69c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 6a0:	910003fd 	mov	x29, sp
 6a4:	a90153f3 	stp	x19, x20, [sp, #16]
 6a8:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 6ac:	52800001 	mov	w1, #0x0                   	// #0
 6b0:	9400005b 	bl	81c <open>
  if(fd < 0)
 6b4:	37f80160 	tbnz	w0, #31, 6e0 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 6b8:	aa1303e1 	mov	x1, x19
 6bc:	2a0003f4 	mov	w20, w0
 6c0:	94000060 	bl	840 <fstat>
 6c4:	2a0003f3 	mov	w19, w0
  close(fd);
 6c8:	2a1403e0 	mov	w0, w20
 6cc:	9400004b 	bl	7f8 <close>
  return r;
}
 6d0:	2a1303e0 	mov	w0, w19
 6d4:	a94153f3 	ldp	x19, x20, [sp, #16]
 6d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
 6dc:	d65f03c0 	ret
    return -1;
 6e0:	12800013 	mov	w19, #0xffffffff            	// #-1
 6e4:	17fffffb 	b	6d0 <stat+0x34>

00000000000006e8 <atoi>:

int
atoi(const char *s)
{
 6e8:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 6ec:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 6f0:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 6f4:	39400043 	ldrb	w3, [x2]
 6f8:	5100c061 	sub	w1, w3, #0x30
 6fc:	12001c21 	and	w1, w1, #0xff
 700:	7100243f 	cmp	w1, #0x9
 704:	54000049 	b.ls	70c <atoi+0x24>  // b.plast
  return n;
}
 708:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 70c:	1b040c01 	madd	w1, w0, w4, w3
 710:	91000442 	add	x2, x2, #0x1
 714:	5100c020 	sub	w0, w1, #0x30
 718:	17fffff7 	b	6f4 <atoi+0xc>

000000000000071c <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 71c:	eb01001f 	cmp	x0, x1
 720:	54000263 	b.cc	76c <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 724:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 728:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 72c:	d2800003 	mov	x3, #0x0                   	// #0
 730:	d1000463 	sub	x3, x3, #0x1
 734:	11000464 	add	w4, w3, #0x1
 738:	0b020084 	add	w4, w4, w2
 73c:	7100009f 	cmp	w4, #0x0
 740:	5400014d 	b.le	768 <memmove+0x4c>
      *--dst = *--src;
 744:	38636824 	ldrb	w4, [x1, x3]
 748:	382368a4 	strb	w4, [x5, x3]
 74c:	17fffff9 	b	730 <memmove+0x14>
      *dst++ = *src++;
 750:	38636824 	ldrb	w4, [x1, x3]
 754:	38236804 	strb	w4, [x0, x3]
 758:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 75c:	4b030044 	sub	w4, w2, w3
 760:	7100009f 	cmp	w4, #0x0
 764:	54ffff6c 	b.gt	750 <memmove+0x34>
  }
  return vdst;
}
 768:	d65f03c0 	ret
 76c:	d2800003 	mov	x3, #0x0                   	// #0
 770:	17fffffb 	b	75c <memmove+0x40>

0000000000000774 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 774:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 778:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 77c:	d2800004 	mov	x4, #0x0                   	// #0
 780:	eb02009f 	cmp	x4, x2
 784:	54000061 	b.ne	790 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 788:	52800000 	mov	w0, #0x0                   	// #0
 78c:	14000007 	b	7a8 <memcmp+0x34>
    if (*p1 != *p2) {
 790:	38646803 	ldrb	w3, [x0, x4]
 794:	91000484 	add	x4, x4, #0x1
 798:	38646825 	ldrb	w5, [x1, x4]
 79c:	6b05007f 	cmp	w3, w5
 7a0:	54ffff00 	b.eq	780 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 7a4:	4b050060 	sub	w0, w3, w5
}
 7a8:	d65f03c0 	ret

00000000000007ac <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 7ac:	17ffffdc 	b	71c <memmove>

00000000000007b0 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 7b0:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 7b4:	d4000001 	svc	#0x0
 ret
 7b8:	d65f03c0 	ret

00000000000007bc <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 7bc:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 7c0:	d4000001 	svc	#0x0
 ret
 7c4:	d65f03c0 	ret

00000000000007c8 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 7c8:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 7cc:	d4000001 	svc	#0x0
 ret
 7d0:	d65f03c0 	ret

00000000000007d4 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 7d4:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 7d8:	d4000001 	svc	#0x0
 ret
 7dc:	d65f03c0 	ret

00000000000007e0 <read>:
.global read
read:
 mov x7, #SYS_read
 7e0:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 7e4:	d4000001 	svc	#0x0
 ret
 7e8:	d65f03c0 	ret

00000000000007ec <write>:
.global write
write:
 mov x7, #SYS_write
 7ec:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 7f0:	d4000001 	svc	#0x0
 ret
 7f4:	d65f03c0 	ret

00000000000007f8 <close>:
.global close
close:
 mov x7, #SYS_close
 7f8:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 7fc:	d4000001 	svc	#0x0
 ret
 800:	d65f03c0 	ret

0000000000000804 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 804:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 808:	d4000001 	svc	#0x0
 ret
 80c:	d65f03c0 	ret

0000000000000810 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 810:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 814:	d4000001 	svc	#0x0
 ret
 818:	d65f03c0 	ret

000000000000081c <open>:
.global open
open:
 mov x7, #SYS_open
 81c:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 820:	d4000001 	svc	#0x0
 ret
 824:	d65f03c0 	ret

0000000000000828 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 828:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 82c:	d4000001 	svc	#0x0
 ret
 830:	d65f03c0 	ret

0000000000000834 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 834:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 838:	d4000001 	svc	#0x0
 ret
 83c:	d65f03c0 	ret

0000000000000840 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 840:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 844:	d4000001 	svc	#0x0
 ret
 848:	d65f03c0 	ret

000000000000084c <link>:
.global link
link:
 mov x7, #SYS_link
 84c:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 850:	d4000001 	svc	#0x0
 ret
 854:	d65f03c0 	ret

0000000000000858 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 858:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 85c:	d4000001 	svc	#0x0
 ret
 860:	d65f03c0 	ret

0000000000000864 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 864:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 868:	d4000001 	svc	#0x0
 ret
 86c:	d65f03c0 	ret

0000000000000870 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 870:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 874:	d4000001 	svc	#0x0
 ret
 878:	d65f03c0 	ret

000000000000087c <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 87c:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 880:	d4000001 	svc	#0x0
 ret
 884:	d65f03c0 	ret

0000000000000888 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 888:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 88c:	d4000001 	svc	#0x0
 ret
 890:	d65f03c0 	ret

0000000000000894 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 894:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 898:	d4000001 	svc	#0x0
 ret
 89c:	d65f03c0 	ret

00000000000008a0 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 8a0:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 8a4:	d4000001 	svc	#0x0
 ret
 8a8:	d65f03c0 	ret

00000000000008ac <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 8ac:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 8b0:	d4000001 	svc	#0x0
 ret
 8b4:	d65f03c0 	ret

00000000000008b8 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 8b8:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 8bc:	d4000001 	svc	#0x0
 ret
 8c0:	d65f03c0 	ret

00000000000008c4 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 8c4:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 8c8:	d4000001 	svc	#0x0
 ret
 8cc:	d65f03c0 	ret

00000000000008d0 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 8d0:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 8d4:	d4000001 	svc	#0x0
 ret
 8d8:	d65f03c0 	ret

00000000000008dc <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 8dc:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 8e0:	d4000001 	svc	#0x0
 ret
 8e4:	d65f03c0 	ret

00000000000008e8 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 8e8:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 8ec:	d4000001 	svc	#0x0
 ret
 8f0:	d65f03c0 	ret

00000000000008f4 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 8f4:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 8f8:	d4000001 	svc	#0x0
 ret
 8fc:	d65f03c0 	ret

0000000000000900 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 900:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 904:	d4000001 	svc	#0x0
 ret
 908:	d65f03c0 	ret

000000000000090c <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 90c:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 910:	d4000001 	svc	#0x0
 ret
 914:	d65f03c0 	ret

0000000000000918 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 918:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 91c:	d4000001 	svc	#0x0
 ret
 920:	d65f03c0 	ret

0000000000000924 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 924:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 928:	d4000001 	svc	#0x0
 ret
 92c:	d65f03c0 	ret

0000000000000930 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 930:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 934:	d4000001 	svc	#0x0
 ret
 938:	d65f03c0 	ret

000000000000093c <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 93c:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 940:	d4000001 	svc	#0x0
 ret
 944:	d65f03c0 	ret

0000000000000948 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 948:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 94c:	d4000001 	svc	#0x0
 ret
 950:	d65f03c0 	ret

0000000000000954 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 954:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 958:	d4000001 	svc	#0x0
 ret
 95c:	d65f03c0 	ret

0000000000000960 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 960:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 964:	d4000001 	svc	#0x0
 ret
 968:	d65f03c0 	ret

000000000000096c <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 96c:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 970:	d4000001 	svc	#0x0
 ret
 974:	d65f03c0 	ret

0000000000000978 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 978:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 97c:	d4000001 	svc	#0x0
 ret
 980:	d65f03c0 	ret

0000000000000984 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 984:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 988:	d4000001 	svc	#0x0
 ret
 98c:	d65f03c0 	ret

0000000000000990 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 990:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 994:	d4000001 	svc	#0x0
 ret
 998:	d65f03c0 	ret

000000000000099c <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 99c:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 9a0:	d4000001 	svc	#0x0
 ret
 9a4:	d65f03c0 	ret

00000000000009a8 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 9a8:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 9ac:	d4000001 	svc	#0x0
 ret
 9b0:	d65f03c0 	ret

00000000000009b4 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 9b4:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 9b8:	d4000001 	svc	#0x0
 ret
 9bc:	d65f03c0 	ret

00000000000009c0 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 9c0:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 9c4:	d4000001 	svc	#0x0
 ret
 9c8:	d65f03c0 	ret

00000000000009cc <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 9cc:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 9d0:	d4000001 	svc	#0x0
 ret
 9d4:	d65f03c0 	ret

00000000000009d8 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 9d8:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 9dc:	d4000001 	svc	#0x0
 ret
 9e0:	d65f03c0 	ret

00000000000009e4 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 9e4:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 9e8:	d4000001 	svc	#0x0
 ret
 9ec:	d65f03c0 	ret

00000000000009f0 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 9f0:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 9f4:	d4000001 	svc	#0x0
 ret
 9f8:	d65f03c0 	ret

00000000000009fc <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 9fc:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 a00:	d4000001 	svc	#0x0
 ret
 a04:	d65f03c0 	ret

0000000000000a08 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 a08:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 a0c:	d4000001 	svc	#0x0
 ret
 a10:	d65f03c0 	ret

0000000000000a14 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 a14:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 a18:	d4000001 	svc	#0x0
 ret
 a1c:	d65f03c0 	ret

0000000000000a20 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 a20:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 a24:	d4000001 	svc	#0x0
 ret
 a28:	d65f03c0 	ret

0000000000000a2c <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 a2c:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 a30:	d4000001 	svc	#0x0
 ret
 a34:	d65f03c0 	ret

0000000000000a38 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 a38:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 a3c:	d4000001 	svc	#0x0
 ret
 a40:	d65f03c0 	ret

0000000000000a44 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 a44:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 a48:	d4000001 	svc	#0x0
 ret
 a4c:	d65f03c0 	ret

0000000000000a50 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 a50:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 a54:	d4000001 	svc	#0x0
 ret
 a58:	d65f03c0 	ret

0000000000000a5c <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 a5c:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 a60:	d4000001 	svc	#0x0
 ret
 a64:	d65f03c0 	ret

0000000000000a68 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 a68:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 a6c:	d4000001 	svc	#0x0
 ret
 a70:	d65f03c0 	ret

0000000000000a74 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 a74:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 a78:	d4000001 	svc	#0x0
 ret
 a7c:	d65f03c0 	ret

0000000000000a80 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 a80:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 a84:	d4000001 	svc	#0x0
 ret
 a88:	d65f03c0 	ret

0000000000000a8c <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 a8c:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 a90:	d4000001 	svc	#0x0
 ret
 a94:	d65f03c0 	ret

0000000000000a98 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 a98:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 a9c:	d4000001 	svc	#0x0
 ret
 aa0:	d65f03c0 	ret

0000000000000aa4 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 aa4:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 aa8:	d4000001 	svc	#0x0
 ret
 aac:	d65f03c0 	ret

0000000000000ab0 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 ab0:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 ab4:	d4000001 	svc	#0x0
 ret
 ab8:	d65f03c0 	ret

0000000000000abc <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 abc:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 ac0:	d4000001 	svc	#0x0
 ret
 ac4:	d65f03c0 	ret

0000000000000ac8 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 ac8:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 acc:	d4000001 	svc	#0x0
 ret
 ad0:	d65f03c0 	ret

0000000000000ad4 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 ad4:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 ad8:	d4000001 	svc	#0x0
 ret
 adc:	d65f03c0 	ret

0000000000000ae0 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 ae0:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 ae4:	d4000001 	svc	#0x0
 ret
 ae8:	d65f03c0 	ret

0000000000000aec <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 aec:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 af0:	d4000001 	svc	#0x0
 ret
 af4:	d65f03c0 	ret

0000000000000af8 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 af8:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 afc:	d4000001 	svc	#0x0
 ret
 b00:	d65f03c0 	ret

0000000000000b04 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 b04:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 b08:	d4000001 	svc	#0x0
 ret
 b0c:	d65f03c0 	ret

0000000000000b10 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 b10:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 b14:	d4000001 	svc	#0x0
 ret
 b18:	d65f03c0 	ret

0000000000000b1c <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 b1c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 b20:	52800022 	mov	w2, #0x1                   	// #1
{
 b24:	910003fd 	mov	x29, sp
 b28:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 b2c:	91007fe1 	add	x1, sp, #0x1f
 b30:	97ffff2f 	bl	7ec <write>
 b34:	7100041f 	cmp	w0, #0x1
}
 b38:	1a9f17e0 	cset	w0, eq	// eq = none
 b3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 b40:	d65f03c0 	ret

0000000000000b44 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 b44:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 b48:	910003fd 	mov	x29, sp
 b4c:	a90153f3 	stp	x19, x20, [sp, #16]
 b50:	a9025bf5 	stp	x21, x22, [sp, #32]
 b54:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 b58:	6a417c7f 	tst	w3, w1, lsr #31
 b5c:	54000300 	b.eq	bbc <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 b60:	4b0103e1 	neg	w1, w1
    neg = 1;
 b64:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 b68:	b0000003 	adrp	x3, 1000 <printf+0xd4>
 b6c:	91074063 	add	x3, x3, #0x1d0
 b70:	9100c3f5 	add	x21, sp, #0x30
 b74:	d2800000 	mov	x0, #0x0                   	// #0
 b78:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 b7c:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 b80:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 b84:	2a0403e1 	mov	w1, w4
 b88:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 b8c:	38666866 	ldrb	w6, [x3, x6]
 b90:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 b94:	91000400 	add	x0, x0, #0x1
 b98:	54ffff09 	b.ls	b78 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 b9c:	11000493 	add	w19, w4, #0x1
  if(neg)
 ba0:	34000085 	cbz	w5, bb0 <printint+0x6c>
    buf[i++] = '-';
 ba4:	528005a0 	mov	w0, #0x2d                  	// #45
 ba8:	38334aa0 	strb	w0, [x21, w19, uxtw]
 bac:	11000893 	add	w19, w4, #0x2
 bb0:	51000673 	sub	w19, w19, #0x1
 bb4:	52800014 	mov	w20, #0x0                   	// #0
 bb8:	14000008 	b	bd8 <printint+0x94>
  neg = 0;
 bbc:	52800005 	mov	w5, #0x0                   	// #0
 bc0:	17ffffea 	b	b68 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 bc4:	38736aa1 	ldrb	w1, [x21, x19]
 bc8:	2a1603e0 	mov	w0, w22
 bcc:	d1000673 	sub	x19, x19, #0x1
 bd0:	97ffffd3 	bl	b1c <putc>
 bd4:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 bd8:	3100067f 	cmn	w19, #0x1
 bdc:	54ffff41 	b.ne	bc4 <printint+0x80>  // b.any
  return written;
}
 be0:	a9425bf5 	ldp	x21, x22, [sp, #32]
 be4:	2a1403e0 	mov	w0, w20
 be8:	a94153f3 	ldp	x19, x20, [sp, #16]
 bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
 bf0:	d65f03c0 	ret

0000000000000bf4 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 bf4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 bf8:	910003fd 	mov	x29, sp
 bfc:	a90153f3 	stp	x19, x20, [sp, #16]
 c00:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 c04:	52800015 	mov	w21, #0x0                   	// #0
{
 c08:	a90363f7 	stp	x23, x24, [sp, #48]
 c0c:	2a0003f7 	mov	w23, w0
 c10:	a9046bf9 	stp	x25, x26, [sp, #64]
 c14:	aa0103f9 	mov	x25, x1

  state = 0;
 c18:	52800001 	mov	w1, #0x0                   	// #0
{
 c1c:	a90573fb 	stp	x27, x28, [sp, #80]
 c20:	a9406053 	ldp	x19, x24, [x2]
 c24:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 c28:	39400320 	ldrb	w0, [x25]
 c2c:	35000120 	cbnz	w0, c50 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 c30:	2a1503e0 	mov	w0, w21
 c34:	a94153f3 	ldp	x19, x20, [sp, #16]
 c38:	a9425bf5 	ldp	x21, x22, [sp, #32]
 c3c:	a94363f7 	ldp	x23, x24, [sp, #48]
 c40:	a9446bf9 	ldp	x25, x26, [sp, #64]
 c44:	a94573fb 	ldp	x27, x28, [sp, #80]
 c48:	a8c67bfd 	ldp	x29, x30, [sp], #96
 c4c:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 c50:	2a0003f6 	mov	w22, w0
    if(state == 0){
 c54:	35000101 	cbnz	w1, c74 <vprintf+0x80>
      if(c == '%'){
 c58:	7100941f 	cmp	w0, #0x25
 c5c:	54000ba0 	b.eq	dd0 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 c60:	2a1603e1 	mov	w1, w22
 c64:	2a1703e0 	mov	w0, w23
 c68:	97ffffad 	bl	b1c <putc>
 c6c:	0b0002b5 	add	w21, w21, w0
 c70:	14000057 	b	dcc <vprintf+0x1d8>
      if(c == 'd'){
 c74:	7101901f 	cmp	w0, #0x64
 c78:	540002a1 	b.ne	ccc <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 c7c:	37f80174 	tbnz	w20, #31, ca8 <vprintf+0xb4>
 c80:	91002e76 	add	x22, x19, #0xb
 c84:	2a1403fa 	mov	w26, w20
 c88:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c8c:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 c90:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 c94:	b9400261 	ldr	w1, [x19]
 c98:	2a1703e0 	mov	w0, w23
 c9c:	97ffffaa 	bl	b44 <printint>
        written += putc(fd, va_arg(ap, uint));
 ca0:	0b0002b5 	add	w21, w21, w0
 ca4:	14000048 	b	dc4 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 ca8:	1100229a 	add	w26, w20, #0x8
 cac:	7100035f 	cmp	w26, #0x0
 cb0:	5400008d 	b.le	cc0 <vprintf+0xcc>
 cb4:	91002e76 	add	x22, x19, #0xb
 cb8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cbc:	17fffff4 	b	c8c <vprintf+0x98>
 cc0:	aa1303f6 	mov	x22, x19
 cc4:	8b34c313 	add	x19, x24, w20, sxtw
 cc8:	17fffff1 	b	c8c <vprintf+0x98>
      } else if(c == 'l') {
 ccc:	7101b01f 	cmp	w0, #0x6c
 cd0:	54000201 	b.ne	d10 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 cd4:	37f800d4 	tbnz	w20, #31, cec <vprintf+0xf8>
 cd8:	91003e76 	add	x22, x19, #0xf
 cdc:	2a1403fa 	mov	w26, w20
 ce0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ce4:	52800003 	mov	w3, #0x0                   	// #0
 ce8:	17ffffea 	b	c90 <vprintf+0x9c>
 cec:	1100229a 	add	w26, w20, #0x8
 cf0:	7100035f 	cmp	w26, #0x0
 cf4:	5400008d 	b.le	d04 <vprintf+0x110>
 cf8:	91003e76 	add	x22, x19, #0xf
 cfc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d00:	17fffff9 	b	ce4 <vprintf+0xf0>
 d04:	aa1303f6 	mov	x22, x19
 d08:	8b34c313 	add	x19, x24, w20, sxtw
 d0c:	17fffff6 	b	ce4 <vprintf+0xf0>
      } else if(c == 'x') {
 d10:	7101e01f 	cmp	w0, #0x78
 d14:	54000221 	b.ne	d58 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 d18:	37f800f4 	tbnz	w20, #31, d34 <vprintf+0x140>
 d1c:	91002e76 	add	x22, x19, #0xb
 d20:	2a1403fa 	mov	w26, w20
 d24:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d28:	52800003 	mov	w3, #0x0                   	// #0
 d2c:	52800202 	mov	w2, #0x10                  	// #16
 d30:	17ffffd9 	b	c94 <vprintf+0xa0>
 d34:	1100229a 	add	w26, w20, #0x8
 d38:	7100035f 	cmp	w26, #0x0
 d3c:	5400008d 	b.le	d4c <vprintf+0x158>
 d40:	91002e76 	add	x22, x19, #0xb
 d44:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d48:	17fffff8 	b	d28 <vprintf+0x134>
 d4c:	aa1303f6 	mov	x22, x19
 d50:	8b34c313 	add	x19, x24, w20, sxtw
 d54:	17fffff5 	b	d28 <vprintf+0x134>
      } else if(c == 'p') {
 d58:	7101c01f 	cmp	w0, #0x70
 d5c:	54000521 	b.ne	e00 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 d60:	37f803f4 	tbnz	w20, #31, ddc <vprintf+0x1e8>
 d64:	91003e76 	add	x22, x19, #0xf
 d68:	2a1403fa 	mov	w26, w20
 d6c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 d70:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 d74:	52800601 	mov	w1, #0x30                  	// #48
 d78:	2a1703e0 	mov	w0, w23
 d7c:	97ffff68 	bl	b1c <putc>
 d80:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d84:	b000001c 	adrp	x28, 1000 <printf+0xd4>
 d88:	9107439c 	add	x28, x28, #0x1d0
  written += putc(fd, 'x');
 d8c:	2a1703e0 	mov	w0, w23
 d90:	52800f01 	mov	w1, #0x78                  	// #120
 d94:	97ffff62 	bl	b1c <putc>
 d98:	0b000273 	add	w19, w19, w0
 d9c:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 da0:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 da4:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 da8:	38606b81 	ldrb	w1, [x28, x0]
 dac:	2a1703e0 	mov	w0, w23
 db0:	97ffff5b 	bl	b1c <putc>
 db4:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 db8:	71000694 	subs	w20, w20, #0x1
 dbc:	54ffff21 	b.ne	da0 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 dc0:	0b1302b5 	add	w21, w21, w19
 dc4:	2a1a03f4 	mov	w20, w26
 dc8:	aa1603f3 	mov	x19, x22
      state = 0;
 dcc:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 dd0:	91000739 	add	x25, x25, #0x1
  state = 0;
 dd4:	2a1603e1 	mov	w1, w22
 dd8:	17ffff94 	b	c28 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 ddc:	1100229a 	add	w26, w20, #0x8
 de0:	7100035f 	cmp	w26, #0x0
 de4:	5400008d 	b.le	df4 <vprintf+0x200>
 de8:	91003e76 	add	x22, x19, #0xf
 dec:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 df0:	17ffffe0 	b	d70 <vprintf+0x17c>
 df4:	aa1303f6 	mov	x22, x19
 df8:	8b34c313 	add	x19, x24, w20, sxtw
 dfc:	17ffffdd 	b	d70 <vprintf+0x17c>
      } else if(c == 's'){
 e00:	7101cc1f 	cmp	w0, #0x73
 e04:	54000381 	b.ne	e74 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 e08:	37f80214 	tbnz	w20, #31, e48 <vprintf+0x254>
 e0c:	91003e61 	add	x1, x19, #0xf
 e10:	aa1303e0 	mov	x0, x19
 e14:	927df033 	and	x19, x1, #0xfffffffffffffff8
 e18:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 e1c:	b0000000 	adrp	x0, 1000 <printf+0xd4>
 e20:	91072400 	add	x0, x0, #0x1c9
 e24:	f10002df 	cmp	x22, #0x0
 e28:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 e2c:	394002c1 	ldrb	w1, [x22]
 e30:	34fffce1 	cbz	w1, dcc <vprintf+0x1d8>
          written += putc(fd, *s);
 e34:	2a1703e0 	mov	w0, w23
          s++;
 e38:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 e3c:	97ffff38 	bl	b1c <putc>
 e40:	0b0002b5 	add	w21, w21, w0
          s++;
 e44:	17fffffa 	b	e2c <vprintf+0x238>
        s = va_arg(ap, char*);
 e48:	11002281 	add	w1, w20, #0x8
 e4c:	7100003f 	cmp	w1, #0x0
 e50:	540000cd 	b.le	e68 <vprintf+0x274>
 e54:	91003e62 	add	x2, x19, #0xf
 e58:	aa1303e0 	mov	x0, x19
 e5c:	2a0103f4 	mov	w20, w1
 e60:	927df053 	and	x19, x2, #0xfffffffffffffff8
 e64:	17ffffed 	b	e18 <vprintf+0x224>
 e68:	8b34c300 	add	x0, x24, w20, sxtw
 e6c:	2a0103f4 	mov	w20, w1
 e70:	17ffffea 	b	e18 <vprintf+0x224>
      } else if(c == 'c'){
 e74:	71018c1f 	cmp	w0, #0x63
 e78:	54000241 	b.ne	ec0 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 e7c:	37f80114 	tbnz	w20, #31, e9c <vprintf+0x2a8>
 e80:	91002e76 	add	x22, x19, #0xb
 e84:	2a1403fa 	mov	w26, w20
 e88:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 e8c:	39400261 	ldrb	w1, [x19]
 e90:	2a1703e0 	mov	w0, w23
 e94:	97ffff22 	bl	b1c <putc>
 e98:	17ffff82 	b	ca0 <vprintf+0xac>
 e9c:	1100229a 	add	w26, w20, #0x8
 ea0:	7100035f 	cmp	w26, #0x0
 ea4:	5400008d 	b.le	eb4 <vprintf+0x2c0>
 ea8:	91002e76 	add	x22, x19, #0xb
 eac:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 eb0:	17fffff7 	b	e8c <vprintf+0x298>
 eb4:	aa1303f6 	mov	x22, x19
 eb8:	8b34c313 	add	x19, x24, w20, sxtw
 ebc:	17fffff4 	b	e8c <vprintf+0x298>
      } else if(c == '%'){
 ec0:	7100941f 	cmp	w0, #0x25
 ec4:	54ffece0 	b.eq	c60 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 ec8:	2a1703e0 	mov	w0, w23
 ecc:	528004a1 	mov	w1, #0x25                  	// #37
 ed0:	97ffff13 	bl	b1c <putc>
 ed4:	0b0002b5 	add	w21, w21, w0
 ed8:	17ffff62 	b	c60 <vprintf+0x6c>

0000000000000edc <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 edc:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 ee0:	910003fd 	mov	x29, sp
 ee4:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 ee8:	910203e2 	add	x2, sp, #0x80
 eec:	a9030be2 	stp	x2, x2, [sp, #48]
 ef0:	910143e2 	add	x2, sp, #0x50
 ef4:	f90023e2 	str	x2, [sp, #64]
 ef8:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 efc:	b9004be2 	str	w2, [sp, #72]
 f00:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 f04:	a9430fe2 	ldp	x2, x3, [sp, #48]
 f08:	a9010fe2 	stp	x2, x3, [sp, #16]
 f0c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 f10:	a9020fe2 	stp	x2, x3, [sp, #32]
 f14:	910043e2 	add	x2, sp, #0x10
{
 f18:	a90617e4 	stp	x4, x5, [sp, #96]
 f1c:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 f20:	97ffff35 	bl	bf4 <vprintf>
  va_end(ap);
  return result;
}
 f24:	a8c87bfd 	ldp	x29, x30, [sp], #128
 f28:	d65f03c0 	ret

0000000000000f2c <printf>:

int
printf(const char *fmt, ...)
{
 f2c:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 f30:	910003fd 	mov	x29, sp
 f34:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 f38:	910243e1 	add	x1, sp, #0x90
 f3c:	a90307e1 	stp	x1, x1, [sp, #48]
 f40:	910143e1 	add	x1, sp, #0x50
 f44:	f90023e1 	str	x1, [sp, #64]
 f48:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 f4c:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 f50:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 f54:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 f58:	52800020 	mov	w0, #0x1                   	// #1
{
 f5c:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 f60:	a9430fe2 	ldp	x2, x3, [sp, #48]
 f64:	a9010fe2 	stp	x2, x3, [sp, #16]
 f68:	a9440fe2 	ldp	x2, x3, [sp, #64]
 f6c:	a9020fe2 	stp	x2, x3, [sp, #32]
 f70:	910043e2 	add	x2, sp, #0x10
{
 f74:	a9079be5 	stp	x5, x6, [sp, #120]
 f78:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 f7c:	97ffff1e 	bl	bf4 <vprintf>
  va_end(ap);
  return result;
}
 f80:	a8c97bfd 	ldp	x29, x30, [sp], #144
 f84:	d65f03c0 	ret
