
user/_wc:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  printf("%d %d %d %s\n", l, w, c, name);
}

int
main(int argc, char *argv[])
{
   0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
   c:	a9025bf5 	stp	x21, x22, [sp, #32]
  int fd, i;

  if(argc <= 1){
  10:	7100041f 	cmp	w0, #0x1
  14:	540000ec 	b.gt	30 <main+0x30>
    wc(0, "");
  18:	90000001 	adrp	x1, 0 <main>
  1c:	9131a421 	add	x1, x1, #0xc69
  20:	52800000 	mov	w0, #0x0                   	// #0
  24:	94000018 	bl	84 <wc>
      exit(1);
    }
    wc(fd, argv[i]);
    close(fd);
  }
  exit(0);
  28:	52800000 	mov	w0, #0x0                   	// #0
  2c:	1400000e 	b	64 <main+0x64>
  30:	2a0003f4 	mov	w20, w0
  34:	aa0103f6 	mov	x22, x1
  if(argc <= 1){
  38:	d2800033 	mov	x19, #0x1                   	// #1
    if((fd = open(argv[i], 0)) < 0){
  3c:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
  40:	52800001 	mov	w1, #0x0                   	// #0
  44:	94000129 	bl	4e8 <open>
  48:	2a0003f5 	mov	w21, w0
      printf("wc: cannot open %s\n", argv[i]);
  4c:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    if((fd = open(argv[i], 0)) < 0){
  50:	36f800c0 	tbz	w0, #31, 68 <main+0x68>
      printf("wc: cannot open %s\n", argv[i]);
  54:	90000000 	adrp	x0, 0 <main>
  58:	9131dc00 	add	x0, x0, #0xc77
  5c:	940002e7 	bl	bf8 <printf>
      exit(1);
  60:	52800020 	mov	w0, #0x1                   	// #1
  64:	94000109 	bl	488 <exit>
    wc(fd, argv[i]);
  68:	94000007 	bl	84 <wc>
  for(i = 1; i < argc; i++){
  6c:	91000673 	add	x19, x19, #0x1
    close(fd);
  70:	2a1503e0 	mov	w0, w21
  74:	94000114 	bl	4c4 <close>
  for(i = 1; i < argc; i++){
  78:	6b13029f 	cmp	w20, w19
  7c:	54fffe0c 	b.gt	3c <main+0x3c>
  80:	17ffffea 	b	28 <main+0x28>

0000000000000084 <wc>:
{
  84:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  88:	910003fd 	mov	x29, sp
  8c:	a90153f3 	stp	x19, x20, [sp, #16]
  while((n = read(fd, buf, sizeof(buf))) > 0){
  90:	90000013 	adrp	x19, 0 <main>
  94:	91328e73 	add	x19, x19, #0xca3
{
  98:	a9046bf9 	stp	x25, x26, [sp, #64]
      if(strchr(" \r\t\n\v", buf[i]))
  9c:	9000001a 	adrp	x26, 0 <main>
  a0:	9131535a 	add	x26, x26, #0xc54
{
  a4:	a90573fb 	stp	x27, x28, [sp, #80]
  a8:	2a0003fb 	mov	w27, w0
  ac:	aa0103fc 	mov	x28, x1
  inword = 0;
  b0:	52800014 	mov	w20, #0x0                   	// #0
{
  b4:	a9025bf5 	stp	x21, x22, [sp, #32]
  l = w = c = 0;
  b8:	52800016 	mov	w22, #0x0                   	// #0
{
  bc:	a90363f7 	stp	x23, x24, [sp, #48]
  l = w = c = 0;
  c0:	52800018 	mov	w24, #0x0                   	// #0
  c4:	52800017 	mov	w23, #0x0                   	// #0
  while((n = read(fd, buf, sizeof(buf))) > 0){
  c8:	aa1303e1 	mov	x1, x19
  cc:	2a1b03e0 	mov	w0, w27
  d0:	52804002 	mov	w2, #0x200                 	// #512
  d4:	940000f6 	bl	4ac <read>
  d8:	2a0003f9 	mov	w25, w0
  dc:	7100001f 	cmp	w0, #0x0
  e0:	540000ec 	b.gt	fc <wc+0x78>
  if(n < 0){
  e4:	540002e0 	b.eq	140 <wc+0xbc>  // b.none
    printf("wc: read error\n");
  e8:	90000000 	adrp	x0, 0 <main>
  ec:	91316800 	add	x0, x0, #0xc5a
  f0:	940002c2 	bl	bf8 <printf>
    exit(1);
  f4:	52800020 	mov	w0, #0x1                   	// #1
  f8:	940000e4 	bl	488 <exit>
  while((n = read(fd, buf, sizeof(buf))) > 0){
  fc:	d2800015 	mov	x21, #0x0                   	// #0
      if(buf[i] == '\n')
 100:	38756a61 	ldrb	w1, [x19, x21]
      if(strchr(" \r\t\n\v", buf[i]))
 104:	aa1a03e0 	mov	x0, x26
        l++;
 108:	7100283f 	cmp	w1, #0xa
 10c:	1a9616d6 	cinc	w22, w22, eq	// eq = none
      if(strchr(" \r\t\n\v", buf[i]))
 110:	9400006c 	bl	2c0 <strchr>
 114:	b5000120 	cbnz	x0, 138 <wc+0xb4>
      else if(!inword){
 118:	7100029f 	cmp	w20, #0x0
        inword = 1;
 11c:	1a9716f7 	cinc	w23, w23, eq	// eq = none
 120:	1a9f1694 	csinc	w20, w20, wzr, ne	// ne = any
    for(i=0; i<n; i++){
 124:	910006b5 	add	x21, x21, #0x1
 128:	6b15033f 	cmp	w25, w21
 12c:	54fffeac 	b.gt	100 <wc+0x7c>
 130:	0b180338 	add	w24, w25, w24
 134:	17ffffe5 	b	c8 <wc+0x44>
        inword = 0;
 138:	52800014 	mov	w20, #0x0                   	// #0
 13c:	17fffffa 	b	124 <wc+0xa0>
}
 140:	a94153f3 	ldp	x19, x20, [sp, #16]
  printf("%d %d %d %s\n", l, w, c, name);
 144:	aa1c03e4 	mov	x4, x28
}
 148:	a9446bf9 	ldp	x25, x26, [sp, #64]
  printf("%d %d %d %s\n", l, w, c, name);
 14c:	2a1803e3 	mov	w3, w24
}
 150:	a94573fb 	ldp	x27, x28, [sp, #80]
  printf("%d %d %d %s\n", l, w, c, name);
 154:	2a1703e2 	mov	w2, w23
 158:	2a1603e1 	mov	w1, w22
 15c:	90000000 	adrp	x0, 0 <main>
 160:	9131a800 	add	x0, x0, #0xc6a
}
 164:	a9425bf5 	ldp	x21, x22, [sp, #32]
 168:	a94363f7 	ldp	x23, x24, [sp, #48]
 16c:	a8c67bfd 	ldp	x29, x30, [sp], #96
  printf("%d %d %d %s\n", l, w, c, name);
 170:	140002a2 	b	bf8 <printf>

0000000000000174 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 174:	d2800002 	mov	x2, #0x0                   	// #0
 178:	38626823 	ldrb	w3, [x1, x2]
 17c:	38226803 	strb	w3, [x0, x2]
 180:	91000442 	add	x2, x2, #0x1
 184:	35ffffa3 	cbnz	w3, 178 <strcpy+0x4>
    ;
  return os;
}
 188:	d65f03c0 	ret

000000000000018c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 18c:	d2800003 	mov	x3, #0x0                   	// #0
 190:	4b030044 	sub	w4, w2, w3
 194:	7100009f 	cmp	w4, #0x0
 198:	5400006d 	b.le	1a4 <strncpy+0x18>
 19c:	38636825 	ldrb	w5, [x1, x3]
 1a0:	350000e5 	cbnz	w5, 1bc <strncpy+0x30>
 1a4:	8b030003 	add	x3, x0, x3
 1a8:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 1ac:	4b010082 	sub	w2, w4, w1
 1b0:	7100005f 	cmp	w2, #0x0
 1b4:	540000ac 	b.gt	1c8 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 1b8:	d65f03c0 	ret
    *s++ = *t++;
 1bc:	38236805 	strb	w5, [x0, x3]
    n--;
 1c0:	91000463 	add	x3, x3, #0x1
 1c4:	17fffff3 	b	190 <strncpy+0x4>
    *s++ = 0;
 1c8:	3821687f 	strb	wzr, [x3, x1]
 1cc:	91000421 	add	x1, x1, #0x1
 1d0:	17fffff7 	b	1ac <strncpy+0x20>

00000000000001d4 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 1d4:	aa0003e2 	mov	x2, x0
 1d8:	39400043 	ldrb	w3, [x2]
 1dc:	aa0203e4 	mov	x4, x2
    s++;
 1e0:	91000442 	add	x2, x2, #0x1
  while(*s)
 1e4:	35ffffa3 	cbnz	w3, 1d8 <strcat+0x4>
 1e8:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 1ec:	38626823 	ldrb	w3, [x1, x2]
 1f0:	38226883 	strb	w3, [x4, x2]
 1f4:	91000442 	add	x2, x2, #0x1
 1f8:	35ffffa3 	cbnz	w3, 1ec <strcat+0x18>
    ;
  return os;
}
 1fc:	d65f03c0 	ret

0000000000000200 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 200:	d2800002 	mov	x2, #0x0                   	// #0
 204:	38626803 	ldrb	w3, [x0, x2]
 208:	38626824 	ldrb	w4, [x1, x2]
 20c:	34000083 	cbz	w3, 21c <strcmp+0x1c>
 210:	91000442 	add	x2, x2, #0x1
 214:	6b04007f 	cmp	w3, w4
 218:	54ffff60 	b.eq	204 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 21c:	4b040060 	sub	w0, w3, w4
 220:	d65f03c0 	ret

0000000000000224 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 224:	340001c2 	cbz	w2, 25c <strncmp+0x38>
 228:	39400003 	ldrb	w3, [x0]
 22c:	34000083 	cbz	w3, 23c <strncmp+0x18>
 230:	39400024 	ldrb	w4, [x1]
 234:	6b03009f 	cmp	w4, w3
 238:	540000a0 	b.eq	24c <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 23c:	39400000 	ldrb	w0, [x0]
 240:	39400021 	ldrb	w1, [x1]
 244:	4b010000 	sub	w0, w0, w1
}
 248:	d65f03c0 	ret
    n--, p++, q++;
 24c:	51000442 	sub	w2, w2, #0x1
 250:	91000400 	add	x0, x0, #0x1
 254:	91000421 	add	x1, x1, #0x1
 258:	17fffff3 	b	224 <strncmp>
    return 0;
 25c:	52800000 	mov	w0, #0x0                   	// #0
 260:	17fffffa 	b	248 <strncmp+0x24>

0000000000000264 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 264:	d1000402 	sub	x2, x0, #0x1
 268:	d2800001 	mov	x1, #0x0                   	// #0
 26c:	aa0103e0 	mov	x0, x1
 270:	91000421 	add	x1, x1, #0x1
 274:	38616843 	ldrb	w3, [x2, x1]
 278:	35ffffa3 	cbnz	w3, 26c <strlen+0x8>
    ;
  return n;
}
 27c:	d65f03c0 	ret

0000000000000280 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 280:	d1000403 	sub	x3, x0, #0x1
 284:	d2800002 	mov	x2, #0x0                   	// #0
 288:	2a0203e0 	mov	w0, w2
 28c:	6b02003f 	cmp	w1, w2
 290:	54000089 	b.ls	2a0 <strnlen+0x20>  // b.plast
 294:	91000442 	add	x2, x2, #0x1
 298:	38626864 	ldrb	w4, [x3, x2]
 29c:	35ffff64 	cbnz	w4, 288 <strnlen+0x8>
    n++;
  return n;
}
 2a0:	d65f03c0 	ret

00000000000002a4 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2a4:	d2800003 	mov	x3, #0x0                   	// #0
 2a8:	6b03005f 	cmp	w2, w3
 2ac:	54000048 	b.hi	2b4 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 2b0:	d65f03c0 	ret
    cdst[i] = c;
 2b4:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 2b8:	91000463 	add	x3, x3, #0x1
 2bc:	17fffffb 	b	2a8 <memset+0x4>

00000000000002c0 <strchr>:

char*
strchr(const char *s, char c)
{
 2c0:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 2c4:	39400002 	ldrb	w2, [x0]
 2c8:	35000062 	cbnz	w2, 2d4 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 2cc:	d2800000 	mov	x0, #0x0                   	// #0
}
 2d0:	d65f03c0 	ret
    if(*s == c)
 2d4:	6b01005f 	cmp	w2, w1
 2d8:	54ffffc0 	b.eq	2d0 <strchr+0x10>  // b.none
  for(; *s; s++)
 2dc:	91000400 	add	x0, x0, #0x1
 2e0:	17fffff9 	b	2c4 <strchr+0x4>

00000000000002e4 <gets>:

char*
gets(char *buf, int max)
{
 2e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 2e8:	910003fd 	mov	x29, sp
 2ec:	a90153f3 	stp	x19, x20, [sp, #16]
 2f0:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 2f4:	d2800014 	mov	x20, #0x0                   	// #0
{
 2f8:	f9001bf7 	str	x23, [sp, #48]
 2fc:	2a0103f7 	mov	w23, w1
 300:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 304:	11000695 	add	w21, w20, #0x1
 308:	2a1403f6 	mov	w22, w20
 30c:	6b1702bf 	cmp	w21, w23
 310:	540000ea 	b.ge	32c <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 314:	91013fe1 	add	x1, sp, #0x4f
 318:	52800022 	mov	w2, #0x1                   	// #1
 31c:	52800000 	mov	w0, #0x0                   	// #0
 320:	94000063 	bl	4ac <read>
    if(cc < 1)
 324:	7100001f 	cmp	w0, #0x0
 328:	5400012c 	b.gt	34c <gets+0x68>
  for(i=0; i+1 < max; ){
 32c:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 330:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 334:	aa1303e0 	mov	x0, x19
 338:	f9401bf7 	ldr	x23, [sp, #48]
 33c:	a94153f3 	ldp	x19, x20, [sp, #16]
 340:	a9425bf5 	ldp	x21, x22, [sp, #32]
 344:	a8c57bfd 	ldp	x29, x30, [sp], #80
 348:	d65f03c0 	ret
    buf[i++] = c;
 34c:	39413fe0 	ldrb	w0, [sp, #79]
 350:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 354:	91000694 	add	x20, x20, #0x1
 358:	7100281f 	cmp	w0, #0xa
 35c:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 360:	54fffd21 	b.ne	304 <gets+0x20>  // b.any
 364:	17fffff3 	b	330 <gets+0x4c>

0000000000000368 <stat>:

int
stat(const char *n, struct stat *st)
{
 368:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 36c:	910003fd 	mov	x29, sp
 370:	a90153f3 	stp	x19, x20, [sp, #16]
 374:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 378:	52800001 	mov	w1, #0x0                   	// #0
 37c:	9400005b 	bl	4e8 <open>
  if(fd < 0)
 380:	37f80160 	tbnz	w0, #31, 3ac <stat+0x44>
    return -1;
  r = fstat(fd, st);
 384:	aa1303e1 	mov	x1, x19
 388:	2a0003f4 	mov	w20, w0
 38c:	94000060 	bl	50c <fstat>
 390:	2a0003f3 	mov	w19, w0
  close(fd);
 394:	2a1403e0 	mov	w0, w20
 398:	9400004b 	bl	4c4 <close>
  return r;
}
 39c:	2a1303e0 	mov	w0, w19
 3a0:	a94153f3 	ldp	x19, x20, [sp, #16]
 3a4:	a8c27bfd 	ldp	x29, x30, [sp], #32
 3a8:	d65f03c0 	ret
    return -1;
 3ac:	12800013 	mov	w19, #0xffffffff            	// #-1
 3b0:	17fffffb 	b	39c <stat+0x34>

00000000000003b4 <atoi>:

int
atoi(const char *s)
{
 3b4:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 3b8:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 3bc:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 3c0:	39400043 	ldrb	w3, [x2]
 3c4:	5100c061 	sub	w1, w3, #0x30
 3c8:	12001c21 	and	w1, w1, #0xff
 3cc:	7100243f 	cmp	w1, #0x9
 3d0:	54000049 	b.ls	3d8 <atoi+0x24>  // b.plast
  return n;
}
 3d4:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 3d8:	1b040c01 	madd	w1, w0, w4, w3
 3dc:	91000442 	add	x2, x2, #0x1
 3e0:	5100c020 	sub	w0, w1, #0x30
 3e4:	17fffff7 	b	3c0 <atoi+0xc>

00000000000003e8 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 3e8:	eb01001f 	cmp	x0, x1
 3ec:	54000263 	b.cc	438 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 3f0:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 3f4:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 3f8:	d2800003 	mov	x3, #0x0                   	// #0
 3fc:	d1000463 	sub	x3, x3, #0x1
 400:	11000464 	add	w4, w3, #0x1
 404:	0b020084 	add	w4, w4, w2
 408:	7100009f 	cmp	w4, #0x0
 40c:	5400014d 	b.le	434 <memmove+0x4c>
      *--dst = *--src;
 410:	38636824 	ldrb	w4, [x1, x3]
 414:	382368a4 	strb	w4, [x5, x3]
 418:	17fffff9 	b	3fc <memmove+0x14>
      *dst++ = *src++;
 41c:	38636824 	ldrb	w4, [x1, x3]
 420:	38236804 	strb	w4, [x0, x3]
 424:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 428:	4b030044 	sub	w4, w2, w3
 42c:	7100009f 	cmp	w4, #0x0
 430:	54ffff6c 	b.gt	41c <memmove+0x34>
  }
  return vdst;
}
 434:	d65f03c0 	ret
 438:	d2800003 	mov	x3, #0x0                   	// #0
 43c:	17fffffb 	b	428 <memmove+0x40>

0000000000000440 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 440:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 444:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 448:	d2800004 	mov	x4, #0x0                   	// #0
 44c:	eb02009f 	cmp	x4, x2
 450:	54000061 	b.ne	45c <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 454:	52800000 	mov	w0, #0x0                   	// #0
 458:	14000007 	b	474 <memcmp+0x34>
    if (*p1 != *p2) {
 45c:	38646803 	ldrb	w3, [x0, x4]
 460:	91000484 	add	x4, x4, #0x1
 464:	38646825 	ldrb	w5, [x1, x4]
 468:	6b05007f 	cmp	w3, w5
 46c:	54ffff00 	b.eq	44c <memcmp+0xc>  // b.none
      return *p1 - *p2;
 470:	4b050060 	sub	w0, w3, w5
}
 474:	d65f03c0 	ret

0000000000000478 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 478:	17ffffdc 	b	3e8 <memmove>

000000000000047c <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 47c:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 480:	d4000001 	svc	#0x0
 ret
 484:	d65f03c0 	ret

0000000000000488 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 488:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 48c:	d4000001 	svc	#0x0
 ret
 490:	d65f03c0 	ret

0000000000000494 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 494:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 498:	d4000001 	svc	#0x0
 ret
 49c:	d65f03c0 	ret

00000000000004a0 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 4a0:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 4a4:	d4000001 	svc	#0x0
 ret
 4a8:	d65f03c0 	ret

00000000000004ac <read>:
.global read
read:
 mov x7, #SYS_read
 4ac:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 4b0:	d4000001 	svc	#0x0
 ret
 4b4:	d65f03c0 	ret

00000000000004b8 <write>:
.global write
write:
 mov x7, #SYS_write
 4b8:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 4bc:	d4000001 	svc	#0x0
 ret
 4c0:	d65f03c0 	ret

00000000000004c4 <close>:
.global close
close:
 mov x7, #SYS_close
 4c4:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 4c8:	d4000001 	svc	#0x0
 ret
 4cc:	d65f03c0 	ret

00000000000004d0 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 4d0:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 4d4:	d4000001 	svc	#0x0
 ret
 4d8:	d65f03c0 	ret

00000000000004dc <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 4dc:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 4e0:	d4000001 	svc	#0x0
 ret
 4e4:	d65f03c0 	ret

00000000000004e8 <open>:
.global open
open:
 mov x7, #SYS_open
 4e8:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 4ec:	d4000001 	svc	#0x0
 ret
 4f0:	d65f03c0 	ret

00000000000004f4 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 4f4:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 4f8:	d4000001 	svc	#0x0
 ret
 4fc:	d65f03c0 	ret

0000000000000500 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 500:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 504:	d4000001 	svc	#0x0
 ret
 508:	d65f03c0 	ret

000000000000050c <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 50c:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 510:	d4000001 	svc	#0x0
 ret
 514:	d65f03c0 	ret

0000000000000518 <link>:
.global link
link:
 mov x7, #SYS_link
 518:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 51c:	d4000001 	svc	#0x0
 ret
 520:	d65f03c0 	ret

0000000000000524 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 524:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 528:	d4000001 	svc	#0x0
 ret
 52c:	d65f03c0 	ret

0000000000000530 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 530:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 534:	d4000001 	svc	#0x0
 ret
 538:	d65f03c0 	ret

000000000000053c <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 53c:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 540:	d4000001 	svc	#0x0
 ret
 544:	d65f03c0 	ret

0000000000000548 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 548:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 54c:	d4000001 	svc	#0x0
 ret
 550:	d65f03c0 	ret

0000000000000554 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 554:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 558:	d4000001 	svc	#0x0
 ret
 55c:	d65f03c0 	ret

0000000000000560 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 560:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 564:	d4000001 	svc	#0x0
 ret
 568:	d65f03c0 	ret

000000000000056c <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 56c:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 570:	d4000001 	svc	#0x0
 ret
 574:	d65f03c0 	ret

0000000000000578 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 578:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 57c:	d4000001 	svc	#0x0
 ret
 580:	d65f03c0 	ret

0000000000000584 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 584:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 588:	d4000001 	svc	#0x0
 ret
 58c:	d65f03c0 	ret

0000000000000590 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 590:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 594:	d4000001 	svc	#0x0
 ret
 598:	d65f03c0 	ret

000000000000059c <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 59c:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 5a0:	d4000001 	svc	#0x0
 ret
 5a4:	d65f03c0 	ret

00000000000005a8 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 5a8:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 5ac:	d4000001 	svc	#0x0
 ret
 5b0:	d65f03c0 	ret

00000000000005b4 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 5b4:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 5b8:	d4000001 	svc	#0x0
 ret
 5bc:	d65f03c0 	ret

00000000000005c0 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 5c0:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 5c4:	d4000001 	svc	#0x0
 ret
 5c8:	d65f03c0 	ret

00000000000005cc <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 5cc:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 5d0:	d4000001 	svc	#0x0
 ret
 5d4:	d65f03c0 	ret

00000000000005d8 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 5d8:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 5dc:	d4000001 	svc	#0x0
 ret
 5e0:	d65f03c0 	ret

00000000000005e4 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 5e4:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 5e8:	d4000001 	svc	#0x0
 ret
 5ec:	d65f03c0 	ret

00000000000005f0 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 5f0:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 5f4:	d4000001 	svc	#0x0
 ret
 5f8:	d65f03c0 	ret

00000000000005fc <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 5fc:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 600:	d4000001 	svc	#0x0
 ret
 604:	d65f03c0 	ret

0000000000000608 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 608:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 60c:	d4000001 	svc	#0x0
 ret
 610:	d65f03c0 	ret

0000000000000614 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 614:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 618:	d4000001 	svc	#0x0
 ret
 61c:	d65f03c0 	ret

0000000000000620 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 620:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 624:	d4000001 	svc	#0x0
 ret
 628:	d65f03c0 	ret

000000000000062c <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 62c:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 630:	d4000001 	svc	#0x0
 ret
 634:	d65f03c0 	ret

0000000000000638 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 638:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 63c:	d4000001 	svc	#0x0
 ret
 640:	d65f03c0 	ret

0000000000000644 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 644:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 648:	d4000001 	svc	#0x0
 ret
 64c:	d65f03c0 	ret

0000000000000650 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 650:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 654:	d4000001 	svc	#0x0
 ret
 658:	d65f03c0 	ret

000000000000065c <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 65c:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 660:	d4000001 	svc	#0x0
 ret
 664:	d65f03c0 	ret

0000000000000668 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 668:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 66c:	d4000001 	svc	#0x0
 ret
 670:	d65f03c0 	ret

0000000000000674 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 674:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 678:	d4000001 	svc	#0x0
 ret
 67c:	d65f03c0 	ret

0000000000000680 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 680:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 684:	d4000001 	svc	#0x0
 ret
 688:	d65f03c0 	ret

000000000000068c <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 68c:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 690:	d4000001 	svc	#0x0
 ret
 694:	d65f03c0 	ret

0000000000000698 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 698:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 69c:	d4000001 	svc	#0x0
 ret
 6a0:	d65f03c0 	ret

00000000000006a4 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 6a4:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 6a8:	d4000001 	svc	#0x0
 ret
 6ac:	d65f03c0 	ret

00000000000006b0 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 6b0:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 6b4:	d4000001 	svc	#0x0
 ret
 6b8:	d65f03c0 	ret

00000000000006bc <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 6bc:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 6c0:	d4000001 	svc	#0x0
 ret
 6c4:	d65f03c0 	ret

00000000000006c8 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 6c8:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 6cc:	d4000001 	svc	#0x0
 ret
 6d0:	d65f03c0 	ret

00000000000006d4 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 6d4:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 6d8:	d4000001 	svc	#0x0
 ret
 6dc:	d65f03c0 	ret

00000000000006e0 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 6e0:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 6e4:	d4000001 	svc	#0x0
 ret
 6e8:	d65f03c0 	ret

00000000000006ec <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 6ec:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 6f0:	d4000001 	svc	#0x0
 ret
 6f4:	d65f03c0 	ret

00000000000006f8 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 6f8:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 6fc:	d4000001 	svc	#0x0
 ret
 700:	d65f03c0 	ret

0000000000000704 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 704:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 708:	d4000001 	svc	#0x0
 ret
 70c:	d65f03c0 	ret

0000000000000710 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 710:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 714:	d4000001 	svc	#0x0
 ret
 718:	d65f03c0 	ret

000000000000071c <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 71c:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 720:	d4000001 	svc	#0x0
 ret
 724:	d65f03c0 	ret

0000000000000728 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 728:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 72c:	d4000001 	svc	#0x0
 ret
 730:	d65f03c0 	ret

0000000000000734 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 734:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 738:	d4000001 	svc	#0x0
 ret
 73c:	d65f03c0 	ret

0000000000000740 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 740:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 744:	d4000001 	svc	#0x0
 ret
 748:	d65f03c0 	ret

000000000000074c <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 74c:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 750:	d4000001 	svc	#0x0
 ret
 754:	d65f03c0 	ret

0000000000000758 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 758:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 75c:	d4000001 	svc	#0x0
 ret
 760:	d65f03c0 	ret

0000000000000764 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 764:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 768:	d4000001 	svc	#0x0
 ret
 76c:	d65f03c0 	ret

0000000000000770 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 770:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 774:	d4000001 	svc	#0x0
 ret
 778:	d65f03c0 	ret

000000000000077c <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 77c:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 780:	d4000001 	svc	#0x0
 ret
 784:	d65f03c0 	ret

0000000000000788 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 788:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 78c:	d4000001 	svc	#0x0
 ret
 790:	d65f03c0 	ret

0000000000000794 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 794:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 798:	d4000001 	svc	#0x0
 ret
 79c:	d65f03c0 	ret

00000000000007a0 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 7a0:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 7a4:	d4000001 	svc	#0x0
 ret
 7a8:	d65f03c0 	ret

00000000000007ac <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 7ac:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 7b0:	d4000001 	svc	#0x0
 ret
 7b4:	d65f03c0 	ret

00000000000007b8 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 7b8:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 7bc:	d4000001 	svc	#0x0
 ret
 7c0:	d65f03c0 	ret

00000000000007c4 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 7c4:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 7c8:	d4000001 	svc	#0x0
 ret
 7cc:	d65f03c0 	ret

00000000000007d0 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 7d0:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 7d4:	d4000001 	svc	#0x0
 ret
 7d8:	d65f03c0 	ret

00000000000007dc <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 7dc:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 7e0:	d4000001 	svc	#0x0
 ret
 7e4:	d65f03c0 	ret

00000000000007e8 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 7e8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 7ec:	52800022 	mov	w2, #0x1                   	// #1
{
 7f0:	910003fd 	mov	x29, sp
 7f4:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 7f8:	91007fe1 	add	x1, sp, #0x1f
 7fc:	97ffff2f 	bl	4b8 <write>
 800:	7100041f 	cmp	w0, #0x1
}
 804:	1a9f17e0 	cset	w0, eq	// eq = none
 808:	a8c27bfd 	ldp	x29, x30, [sp], #32
 80c:	d65f03c0 	ret

0000000000000810 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 810:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 814:	910003fd 	mov	x29, sp
 818:	a90153f3 	stp	x19, x20, [sp, #16]
 81c:	a9025bf5 	stp	x21, x22, [sp, #32]
 820:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 824:	6a417c7f 	tst	w3, w1, lsr #31
 828:	54000300 	b.eq	888 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 82c:	4b0103e1 	neg	w1, w1
    neg = 1;
 830:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 834:	90000003 	adrp	x3, 0 <main>
 838:	91324863 	add	x3, x3, #0xc92
 83c:	9100c3f5 	add	x21, sp, #0x30
 840:	d2800000 	mov	x0, #0x0                   	// #0
 844:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 848:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 84c:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 850:	2a0403e1 	mov	w1, w4
 854:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 858:	38666866 	ldrb	w6, [x3, x6]
 85c:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 860:	91000400 	add	x0, x0, #0x1
 864:	54ffff09 	b.ls	844 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 868:	11000493 	add	w19, w4, #0x1
  if(neg)
 86c:	34000085 	cbz	w5, 87c <printint+0x6c>
    buf[i++] = '-';
 870:	528005a0 	mov	w0, #0x2d                  	// #45
 874:	38334aa0 	strb	w0, [x21, w19, uxtw]
 878:	11000893 	add	w19, w4, #0x2
 87c:	51000673 	sub	w19, w19, #0x1
 880:	52800014 	mov	w20, #0x0                   	// #0
 884:	14000008 	b	8a4 <printint+0x94>
  neg = 0;
 888:	52800005 	mov	w5, #0x0                   	// #0
 88c:	17ffffea 	b	834 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 890:	38736aa1 	ldrb	w1, [x21, x19]
 894:	2a1603e0 	mov	w0, w22
 898:	d1000673 	sub	x19, x19, #0x1
 89c:	97ffffd3 	bl	7e8 <putc>
 8a0:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 8a4:	3100067f 	cmn	w19, #0x1
 8a8:	54ffff41 	b.ne	890 <printint+0x80>  // b.any
  return written;
}
 8ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
 8b0:	2a1403e0 	mov	w0, w20
 8b4:	a94153f3 	ldp	x19, x20, [sp, #16]
 8b8:	a8c47bfd 	ldp	x29, x30, [sp], #64
 8bc:	d65f03c0 	ret

00000000000008c0 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 8c0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 8c4:	910003fd 	mov	x29, sp
 8c8:	a90153f3 	stp	x19, x20, [sp, #16]
 8cc:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 8d0:	52800015 	mov	w21, #0x0                   	// #0
{
 8d4:	a90363f7 	stp	x23, x24, [sp, #48]
 8d8:	2a0003f7 	mov	w23, w0
 8dc:	a9046bf9 	stp	x25, x26, [sp, #64]
 8e0:	aa0103f9 	mov	x25, x1

  state = 0;
 8e4:	52800001 	mov	w1, #0x0                   	// #0
{
 8e8:	a90573fb 	stp	x27, x28, [sp, #80]
 8ec:	a9406053 	ldp	x19, x24, [x2]
 8f0:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 8f4:	39400320 	ldrb	w0, [x25]
 8f8:	35000120 	cbnz	w0, 91c <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 8fc:	2a1503e0 	mov	w0, w21
 900:	a94153f3 	ldp	x19, x20, [sp, #16]
 904:	a9425bf5 	ldp	x21, x22, [sp, #32]
 908:	a94363f7 	ldp	x23, x24, [sp, #48]
 90c:	a9446bf9 	ldp	x25, x26, [sp, #64]
 910:	a94573fb 	ldp	x27, x28, [sp, #80]
 914:	a8c67bfd 	ldp	x29, x30, [sp], #96
 918:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 91c:	2a0003f6 	mov	w22, w0
    if(state == 0){
 920:	35000101 	cbnz	w1, 940 <vprintf+0x80>
      if(c == '%'){
 924:	7100941f 	cmp	w0, #0x25
 928:	54000ba0 	b.eq	a9c <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 92c:	2a1603e1 	mov	w1, w22
 930:	2a1703e0 	mov	w0, w23
 934:	97ffffad 	bl	7e8 <putc>
 938:	0b0002b5 	add	w21, w21, w0
 93c:	14000057 	b	a98 <vprintf+0x1d8>
      if(c == 'd'){
 940:	7101901f 	cmp	w0, #0x64
 944:	540002a1 	b.ne	998 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 948:	37f80174 	tbnz	w20, #31, 974 <vprintf+0xb4>
 94c:	91002e76 	add	x22, x19, #0xb
 950:	2a1403fa 	mov	w26, w20
 954:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 958:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 95c:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 960:	b9400261 	ldr	w1, [x19]
 964:	2a1703e0 	mov	w0, w23
 968:	97ffffaa 	bl	810 <printint>
        written += putc(fd, va_arg(ap, uint));
 96c:	0b0002b5 	add	w21, w21, w0
 970:	14000048 	b	a90 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 974:	1100229a 	add	w26, w20, #0x8
 978:	7100035f 	cmp	w26, #0x0
 97c:	5400008d 	b.le	98c <vprintf+0xcc>
 980:	91002e76 	add	x22, x19, #0xb
 984:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 988:	17fffff4 	b	958 <vprintf+0x98>
 98c:	aa1303f6 	mov	x22, x19
 990:	8b34c313 	add	x19, x24, w20, sxtw
 994:	17fffff1 	b	958 <vprintf+0x98>
      } else if(c == 'l') {
 998:	7101b01f 	cmp	w0, #0x6c
 99c:	54000201 	b.ne	9dc <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 9a0:	37f800d4 	tbnz	w20, #31, 9b8 <vprintf+0xf8>
 9a4:	91003e76 	add	x22, x19, #0xf
 9a8:	2a1403fa 	mov	w26, w20
 9ac:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9b0:	52800003 	mov	w3, #0x0                   	// #0
 9b4:	17ffffea 	b	95c <vprintf+0x9c>
 9b8:	1100229a 	add	w26, w20, #0x8
 9bc:	7100035f 	cmp	w26, #0x0
 9c0:	5400008d 	b.le	9d0 <vprintf+0x110>
 9c4:	91003e76 	add	x22, x19, #0xf
 9c8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9cc:	17fffff9 	b	9b0 <vprintf+0xf0>
 9d0:	aa1303f6 	mov	x22, x19
 9d4:	8b34c313 	add	x19, x24, w20, sxtw
 9d8:	17fffff6 	b	9b0 <vprintf+0xf0>
      } else if(c == 'x') {
 9dc:	7101e01f 	cmp	w0, #0x78
 9e0:	54000221 	b.ne	a24 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 9e4:	37f800f4 	tbnz	w20, #31, a00 <vprintf+0x140>
 9e8:	91002e76 	add	x22, x19, #0xb
 9ec:	2a1403fa 	mov	w26, w20
 9f0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9f4:	52800003 	mov	w3, #0x0                   	// #0
 9f8:	52800202 	mov	w2, #0x10                  	// #16
 9fc:	17ffffd9 	b	960 <vprintf+0xa0>
 a00:	1100229a 	add	w26, w20, #0x8
 a04:	7100035f 	cmp	w26, #0x0
 a08:	5400008d 	b.le	a18 <vprintf+0x158>
 a0c:	91002e76 	add	x22, x19, #0xb
 a10:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a14:	17fffff8 	b	9f4 <vprintf+0x134>
 a18:	aa1303f6 	mov	x22, x19
 a1c:	8b34c313 	add	x19, x24, w20, sxtw
 a20:	17fffff5 	b	9f4 <vprintf+0x134>
      } else if(c == 'p') {
 a24:	7101c01f 	cmp	w0, #0x70
 a28:	54000521 	b.ne	acc <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 a2c:	37f803f4 	tbnz	w20, #31, aa8 <vprintf+0x1e8>
 a30:	91003e76 	add	x22, x19, #0xf
 a34:	2a1403fa 	mov	w26, w20
 a38:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a3c:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 a40:	52800601 	mov	w1, #0x30                  	// #48
 a44:	2a1703e0 	mov	w0, w23
 a48:	97ffff68 	bl	7e8 <putc>
 a4c:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a50:	9000001c 	adrp	x28, 0 <main>
 a54:	91324b9c 	add	x28, x28, #0xc92
  written += putc(fd, 'x');
 a58:	2a1703e0 	mov	w0, w23
 a5c:	52800f01 	mov	w1, #0x78                  	// #120
 a60:	97ffff62 	bl	7e8 <putc>
 a64:	0b000273 	add	w19, w19, w0
 a68:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a6c:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 a70:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a74:	38606b81 	ldrb	w1, [x28, x0]
 a78:	2a1703e0 	mov	w0, w23
 a7c:	97ffff5b 	bl	7e8 <putc>
 a80:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 a84:	71000694 	subs	w20, w20, #0x1
 a88:	54ffff21 	b.ne	a6c <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 a8c:	0b1302b5 	add	w21, w21, w19
 a90:	2a1a03f4 	mov	w20, w26
 a94:	aa1603f3 	mov	x19, x22
      state = 0;
 a98:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 a9c:	91000739 	add	x25, x25, #0x1
  state = 0;
 aa0:	2a1603e1 	mov	w1, w22
 aa4:	17ffff94 	b	8f4 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 aa8:	1100229a 	add	w26, w20, #0x8
 aac:	7100035f 	cmp	w26, #0x0
 ab0:	5400008d 	b.le	ac0 <vprintf+0x200>
 ab4:	91003e76 	add	x22, x19, #0xf
 ab8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 abc:	17ffffe0 	b	a3c <vprintf+0x17c>
 ac0:	aa1303f6 	mov	x22, x19
 ac4:	8b34c313 	add	x19, x24, w20, sxtw
 ac8:	17ffffdd 	b	a3c <vprintf+0x17c>
      } else if(c == 's'){
 acc:	7101cc1f 	cmp	w0, #0x73
 ad0:	54000381 	b.ne	b40 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 ad4:	37f80214 	tbnz	w20, #31, b14 <vprintf+0x254>
 ad8:	91003e61 	add	x1, x19, #0xf
 adc:	aa1303e0 	mov	x0, x19
 ae0:	927df033 	and	x19, x1, #0xfffffffffffffff8
 ae4:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 ae8:	90000000 	adrp	x0, 0 <main>
 aec:	91322c00 	add	x0, x0, #0xc8b
 af0:	f10002df 	cmp	x22, #0x0
 af4:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 af8:	394002c1 	ldrb	w1, [x22]
 afc:	34fffce1 	cbz	w1, a98 <vprintf+0x1d8>
          written += putc(fd, *s);
 b00:	2a1703e0 	mov	w0, w23
          s++;
 b04:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 b08:	97ffff38 	bl	7e8 <putc>
 b0c:	0b0002b5 	add	w21, w21, w0
          s++;
 b10:	17fffffa 	b	af8 <vprintf+0x238>
        s = va_arg(ap, char*);
 b14:	11002281 	add	w1, w20, #0x8
 b18:	7100003f 	cmp	w1, #0x0
 b1c:	540000cd 	b.le	b34 <vprintf+0x274>
 b20:	91003e62 	add	x2, x19, #0xf
 b24:	aa1303e0 	mov	x0, x19
 b28:	2a0103f4 	mov	w20, w1
 b2c:	927df053 	and	x19, x2, #0xfffffffffffffff8
 b30:	17ffffed 	b	ae4 <vprintf+0x224>
 b34:	8b34c300 	add	x0, x24, w20, sxtw
 b38:	2a0103f4 	mov	w20, w1
 b3c:	17ffffea 	b	ae4 <vprintf+0x224>
      } else if(c == 'c'){
 b40:	71018c1f 	cmp	w0, #0x63
 b44:	54000241 	b.ne	b8c <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 b48:	37f80114 	tbnz	w20, #31, b68 <vprintf+0x2a8>
 b4c:	91002e76 	add	x22, x19, #0xb
 b50:	2a1403fa 	mov	w26, w20
 b54:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b58:	39400261 	ldrb	w1, [x19]
 b5c:	2a1703e0 	mov	w0, w23
 b60:	97ffff22 	bl	7e8 <putc>
 b64:	17ffff82 	b	96c <vprintf+0xac>
 b68:	1100229a 	add	w26, w20, #0x8
 b6c:	7100035f 	cmp	w26, #0x0
 b70:	5400008d 	b.le	b80 <vprintf+0x2c0>
 b74:	91002e76 	add	x22, x19, #0xb
 b78:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b7c:	17fffff7 	b	b58 <vprintf+0x298>
 b80:	aa1303f6 	mov	x22, x19
 b84:	8b34c313 	add	x19, x24, w20, sxtw
 b88:	17fffff4 	b	b58 <vprintf+0x298>
      } else if(c == '%'){
 b8c:	7100941f 	cmp	w0, #0x25
 b90:	54ffece0 	b.eq	92c <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 b94:	2a1703e0 	mov	w0, w23
 b98:	528004a1 	mov	w1, #0x25                  	// #37
 b9c:	97ffff13 	bl	7e8 <putc>
 ba0:	0b0002b5 	add	w21, w21, w0
 ba4:	17ffff62 	b	92c <vprintf+0x6c>

0000000000000ba8 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 ba8:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 bac:	910003fd 	mov	x29, sp
 bb0:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 bb4:	910203e2 	add	x2, sp, #0x80
 bb8:	a9030be2 	stp	x2, x2, [sp, #48]
 bbc:	910143e2 	add	x2, sp, #0x50
 bc0:	f90023e2 	str	x2, [sp, #64]
 bc4:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 bc8:	b9004be2 	str	w2, [sp, #72]
 bcc:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 bd0:	a9430fe2 	ldp	x2, x3, [sp, #48]
 bd4:	a9010fe2 	stp	x2, x3, [sp, #16]
 bd8:	a9440fe2 	ldp	x2, x3, [sp, #64]
 bdc:	a9020fe2 	stp	x2, x3, [sp, #32]
 be0:	910043e2 	add	x2, sp, #0x10
{
 be4:	a90617e4 	stp	x4, x5, [sp, #96]
 be8:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 bec:	97ffff35 	bl	8c0 <vprintf>
  va_end(ap);
  return result;
}
 bf0:	a8c87bfd 	ldp	x29, x30, [sp], #128
 bf4:	d65f03c0 	ret

0000000000000bf8 <printf>:

int
printf(const char *fmt, ...)
{
 bf8:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 bfc:	910003fd 	mov	x29, sp
 c00:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 c04:	910243e1 	add	x1, sp, #0x90
 c08:	a90307e1 	stp	x1, x1, [sp, #48]
 c0c:	910143e1 	add	x1, sp, #0x50
 c10:	f90023e1 	str	x1, [sp, #64]
 c14:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 c18:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 c1c:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 c20:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 c24:	52800020 	mov	w0, #0x1                   	// #1
{
 c28:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 c2c:	a9430fe2 	ldp	x2, x3, [sp, #48]
 c30:	a9010fe2 	stp	x2, x3, [sp, #16]
 c34:	a9440fe2 	ldp	x2, x3, [sp, #64]
 c38:	a9020fe2 	stp	x2, x3, [sp, #32]
 c3c:	910043e2 	add	x2, sp, #0x10
{
 c40:	a9079be5 	stp	x5, x6, [sp, #120]
 c44:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 c48:	97ffff1e 	bl	8c0 <vprintf>
  va_end(ap);
  return result;
}
 c4c:	a8c97bfd 	ldp	x29, x30, [sp], #144
 c50:	d65f03c0 	ret
