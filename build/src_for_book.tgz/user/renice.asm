
user/_renice:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
#include "user/user.h"
#include "user/schedutil.h"

int
main(int argc, char *argv[])
{
   0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
  int n, pid;
  struct sched_info si;

  if(argc != 3 || !parse_num(argv[1], &n) || !parse_num(argv[2], &pid)){
   c:	71000c1f 	cmp	w0, #0x3
  10:	54000141 	b.ne	38 <main+0x38>  // b.any
  14:	aa0103e7 	mov	x7, x1
  18:	910083e1 	add	x1, sp, #0x20
  1c:	f94004e0 	ldr	x0, [x7, #8]
  20:	94000025 	bl	b4 <parse_num>
  24:	340000a0 	cbz	w0, 38 <main+0x38>
  28:	f94008e0 	ldr	x0, [x7, #16]
  2c:	910093e1 	add	x1, sp, #0x24
  30:	94000021 	bl	b4 <parse_num>
  34:	350000e0 	cbnz	w0, 50 <main+0x50>
    fprintf(2, "usage: renice N PID\n");
  38:	90000001 	adrp	x1, 0 <main>
  3c:	9125f021 	add	x1, x1, #0x97c
  40:	52800040 	mov	w0, #0x2                   	// #2
  44:	94000223 	bl	8d0 <fprintf>
    exit(1);
  }
  if(sched_getinfo(pid, &si) < 0 || setnice(pid, n) < 0){
    fprintf(2, "renice: failed to set pid %d to nice %d\n", pid, n);
    exit(1);
  48:	52800020 	mov	w0, #0x1                   	// #1
  4c:	94000059 	bl	1b0 <exit>
  if(sched_getinfo(pid, &si) < 0 || setnice(pid, n) < 0){
  50:	b94027f3 	ldr	w19, [sp, #36]
  54:	9100a3e1 	add	x1, sp, #0x28
  58:	2a1303e0 	mov	w0, w19
  5c:	94000103 	bl	468 <sched_getinfo>
  60:	b94023f4 	ldr	w20, [sp, #32]
  64:	37f800a0 	tbnz	w0, #31, 78 <main+0x78>
  68:	2a1403e1 	mov	w1, w20
  6c:	2a1303e0 	mov	w0, w19
  70:	94000101 	bl	474 <setnice>
  74:	36f80100 	tbz	w0, #31, 94 <main+0x94>
    fprintf(2, "renice: failed to set pid %d to nice %d\n", pid, n);
  78:	2a1403e3 	mov	w3, w20
  7c:	2a1303e2 	mov	w2, w19
  80:	90000001 	adrp	x1, 0 <main>
  84:	91264421 	add	x1, x1, #0x991
  88:	52800040 	mov	w0, #0x2                   	// #2
  8c:	94000211 	bl	8d0 <fprintf>
  90:	17ffffee 	b	48 <main+0x48>
  }
  printf("%d (process ID) old priority %d, new priority %d\n", pid, si.nice, n);
  94:	b94037e2 	ldr	w2, [sp, #52]
  98:	2a1403e3 	mov	w3, w20
  9c:	2a1303e1 	mov	w1, w19
  a0:	90000000 	adrp	x0, 0 <main>
  a4:	9126e800 	add	x0, x0, #0x9ba
  a8:	9400021e 	bl	920 <printf>
  exit(0);
  ac:	52800000 	mov	w0, #0x0                   	// #0
  b0:	17ffffe7 	b	4c <main+0x4c>

00000000000000b4 <parse_num>:

// Parse decimal (optionally negative) or 0x-prefixed hex.  Returns 1 with
// *out set, or 0 on a malformed number.
static __attribute__((unused)) int
parse_num(const char *s, int *out)
{
  b4:	aa0003e2 	mov	x2, x0
  int neg = 0, v = 0, any = 0;

  if(*s == '-'){
  b8:	39400000 	ldrb	w0, [x0]
  bc:	7100b41f 	cmp	w0, #0x2d
  c0:	540002c1 	b.ne	118 <parse_num+0x64>  // b.any
    neg = 1;
    s++;
  c4:	91000442 	add	x2, x2, #0x1
    neg = 1;
  c8:	52800025 	mov	w5, #0x1                   	// #1
  }
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
  cc:	39400040 	ldrb	w0, [x2]
  d0:	7100c01f 	cmp	w0, #0x30
  d4:	540000c1 	b.ne	ec <parse_num+0x38>  // b.any
  d8:	39400440 	ldrb	w0, [x2, #1]
  dc:	121a7800 	and	w0, w0, #0xffffffdf
  e0:	12001c00 	and	w0, w0, #0xff
  e4:	7101601f 	cmp	w0, #0x58
  e8:	540001c0 	b.eq	120 <parse_num+0x6c>  // b.none
  ec:	52800000 	mov	w0, #0x0                   	// #0
  f0:	52800003 	mov	w3, #0x0                   	// #0
    }
  } else {
    for(; *s; s++, any = 1){
      if(*s < '0' || *s > '9')
        return 0;
      v = v * 10 + (*s - '0');
  f4:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
  f8:	39400044 	ldrb	w4, [x2]
  fc:	340001c4 	cbz	w4, 134 <parse_num+0x80>
      if(*s < '0' || *s > '9')
 100:	5100c084 	sub	w4, w4, #0x30
 104:	12001c80 	and	w0, w4, #0xff
 108:	7100241f 	cmp	w0, #0x9
 10c:	54000449 	b.ls	194 <parse_num+0xe0>  // b.plast
      else return 0;
 110:	52800000 	mov	w0, #0x0                   	// #0
  }
  if(!any)
    return 0;
  *out = neg ? -v : v;
  return 1;
}
 114:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
 118:	52800005 	mov	w5, #0x0                   	// #0
 11c:	17ffffec 	b	cc <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
 120:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
 124:	52800000 	mov	w0, #0x0                   	// #0
 128:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 12c:	39400044 	ldrb	w4, [x2]
 130:	350000c4 	cbnz	w4, 148 <parse_num+0x94>
  if(!any)
 134:	34ffff00 	cbz	w0, 114 <parse_num+0x60>
  *out = neg ? -v : v;
 138:	710000bf 	cmp	w5, #0x0
 13c:	5a830463 	cneg	w3, w3, ne	// ne = any
 140:	b9000023 	str	w3, [x1]
  return 1;
 144:	17fffff4 	b	114 <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 148:	5100c080 	sub	w0, w4, #0x30
 14c:	12001c06 	and	w6, w0, #0xff
 150:	710024df 	cmp	w6, #0x9
 154:	540000c9 	b.ls	16c <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 158:	51018480 	sub	w0, w4, #0x61
 15c:	12001c00 	and	w0, w0, #0xff
 160:	7100141f 	cmp	w0, #0x5
 164:	540000c8 	b.hi	17c <parse_num+0xc8>  // b.pmore
 168:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
 16c:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
 170:	91000442 	add	x2, x2, #0x1
 174:	52800020 	mov	w0, #0x1                   	// #1
 178:	17ffffed 	b	12c <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 17c:	51010480 	sub	w0, w4, #0x41
 180:	12001c00 	and	w0, w0, #0xff
 184:	7100141f 	cmp	w0, #0x5
 188:	54fffc48 	b.hi	110 <parse_num+0x5c>  // b.pmore
 18c:	5100dc80 	sub	w0, w4, #0x37
 190:	17fffff7 	b	16c <parse_num+0xb8>
      v = v * 10 + (*s - '0');
 194:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
 198:	91000442 	add	x2, x2, #0x1
 19c:	52800020 	mov	w0, #0x1                   	// #1
 1a0:	17ffffd6 	b	f8 <parse_num+0x44>

00000000000001a4 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 1a4:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 1a8:	d4000001 	svc	#0x0
 ret
 1ac:	d65f03c0 	ret

00000000000001b0 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 1b0:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 1b4:	d4000001 	svc	#0x0
 ret
 1b8:	d65f03c0 	ret

00000000000001bc <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 1bc:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 1c0:	d4000001 	svc	#0x0
 ret
 1c4:	d65f03c0 	ret

00000000000001c8 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 1c8:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 1cc:	d4000001 	svc	#0x0
 ret
 1d0:	d65f03c0 	ret

00000000000001d4 <read>:
.global read
read:
 mov x7, #SYS_read
 1d4:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 1d8:	d4000001 	svc	#0x0
 ret
 1dc:	d65f03c0 	ret

00000000000001e0 <write>:
.global write
write:
 mov x7, #SYS_write
 1e0:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 1e4:	d4000001 	svc	#0x0
 ret
 1e8:	d65f03c0 	ret

00000000000001ec <close>:
.global close
close:
 mov x7, #SYS_close
 1ec:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 1f0:	d4000001 	svc	#0x0
 ret
 1f4:	d65f03c0 	ret

00000000000001f8 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 1f8:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 1fc:	d4000001 	svc	#0x0
 ret
 200:	d65f03c0 	ret

0000000000000204 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 204:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 208:	d4000001 	svc	#0x0
 ret
 20c:	d65f03c0 	ret

0000000000000210 <open>:
.global open
open:
 mov x7, #SYS_open
 210:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 214:	d4000001 	svc	#0x0
 ret
 218:	d65f03c0 	ret

000000000000021c <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 21c:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 220:	d4000001 	svc	#0x0
 ret
 224:	d65f03c0 	ret

0000000000000228 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 228:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 22c:	d4000001 	svc	#0x0
 ret
 230:	d65f03c0 	ret

0000000000000234 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 234:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 238:	d4000001 	svc	#0x0
 ret
 23c:	d65f03c0 	ret

0000000000000240 <link>:
.global link
link:
 mov x7, #SYS_link
 240:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 244:	d4000001 	svc	#0x0
 ret
 248:	d65f03c0 	ret

000000000000024c <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 24c:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 250:	d4000001 	svc	#0x0
 ret
 254:	d65f03c0 	ret

0000000000000258 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 258:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 25c:	d4000001 	svc	#0x0
 ret
 260:	d65f03c0 	ret

0000000000000264 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 264:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 268:	d4000001 	svc	#0x0
 ret
 26c:	d65f03c0 	ret

0000000000000270 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 270:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 274:	d4000001 	svc	#0x0
 ret
 278:	d65f03c0 	ret

000000000000027c <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 27c:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 280:	d4000001 	svc	#0x0
 ret
 284:	d65f03c0 	ret

0000000000000288 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 288:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 28c:	d4000001 	svc	#0x0
 ret
 290:	d65f03c0 	ret

0000000000000294 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 294:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 298:	d4000001 	svc	#0x0
 ret
 29c:	d65f03c0 	ret

00000000000002a0 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 2a0:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 2a4:	d4000001 	svc	#0x0
 ret
 2a8:	d65f03c0 	ret

00000000000002ac <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 2ac:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 2b0:	d4000001 	svc	#0x0
 ret
 2b4:	d65f03c0 	ret

00000000000002b8 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 2b8:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 2bc:	d4000001 	svc	#0x0
 ret
 2c0:	d65f03c0 	ret

00000000000002c4 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 2c4:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 2c8:	d4000001 	svc	#0x0
 ret
 2cc:	d65f03c0 	ret

00000000000002d0 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 2d0:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 2d4:	d4000001 	svc	#0x0
 ret
 2d8:	d65f03c0 	ret

00000000000002dc <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 2dc:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 2e0:	d4000001 	svc	#0x0
 ret
 2e4:	d65f03c0 	ret

00000000000002e8 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 2e8:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 2ec:	d4000001 	svc	#0x0
 ret
 2f0:	d65f03c0 	ret

00000000000002f4 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 2f4:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 2f8:	d4000001 	svc	#0x0
 ret
 2fc:	d65f03c0 	ret

0000000000000300 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 300:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 304:	d4000001 	svc	#0x0
 ret
 308:	d65f03c0 	ret

000000000000030c <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 30c:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 310:	d4000001 	svc	#0x0
 ret
 314:	d65f03c0 	ret

0000000000000318 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 318:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 31c:	d4000001 	svc	#0x0
 ret
 320:	d65f03c0 	ret

0000000000000324 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 324:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 328:	d4000001 	svc	#0x0
 ret
 32c:	d65f03c0 	ret

0000000000000330 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 330:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 334:	d4000001 	svc	#0x0
 ret
 338:	d65f03c0 	ret

000000000000033c <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 33c:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 340:	d4000001 	svc	#0x0
 ret
 344:	d65f03c0 	ret

0000000000000348 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 348:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 34c:	d4000001 	svc	#0x0
 ret
 350:	d65f03c0 	ret

0000000000000354 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 354:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 358:	d4000001 	svc	#0x0
 ret
 35c:	d65f03c0 	ret

0000000000000360 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 360:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 364:	d4000001 	svc	#0x0
 ret
 368:	d65f03c0 	ret

000000000000036c <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 36c:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 370:	d4000001 	svc	#0x0
 ret
 374:	d65f03c0 	ret

0000000000000378 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 378:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 37c:	d4000001 	svc	#0x0
 ret
 380:	d65f03c0 	ret

0000000000000384 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 384:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 388:	d4000001 	svc	#0x0
 ret
 38c:	d65f03c0 	ret

0000000000000390 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 390:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 394:	d4000001 	svc	#0x0
 ret
 398:	d65f03c0 	ret

000000000000039c <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 39c:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 3a0:	d4000001 	svc	#0x0
 ret
 3a4:	d65f03c0 	ret

00000000000003a8 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 3a8:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 3ac:	d4000001 	svc	#0x0
 ret
 3b0:	d65f03c0 	ret

00000000000003b4 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 3b4:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 3b8:	d4000001 	svc	#0x0
 ret
 3bc:	d65f03c0 	ret

00000000000003c0 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 3c0:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 3c4:	d4000001 	svc	#0x0
 ret
 3c8:	d65f03c0 	ret

00000000000003cc <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 3cc:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 3d0:	d4000001 	svc	#0x0
 ret
 3d4:	d65f03c0 	ret

00000000000003d8 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 3d8:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 3dc:	d4000001 	svc	#0x0
 ret
 3e0:	d65f03c0 	ret

00000000000003e4 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 3e4:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 3e8:	d4000001 	svc	#0x0
 ret
 3ec:	d65f03c0 	ret

00000000000003f0 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 3f0:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 3f4:	d4000001 	svc	#0x0
 ret
 3f8:	d65f03c0 	ret

00000000000003fc <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 3fc:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 400:	d4000001 	svc	#0x0
 ret
 404:	d65f03c0 	ret

0000000000000408 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 408:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 40c:	d4000001 	svc	#0x0
 ret
 410:	d65f03c0 	ret

0000000000000414 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 414:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 418:	d4000001 	svc	#0x0
 ret
 41c:	d65f03c0 	ret

0000000000000420 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 420:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 424:	d4000001 	svc	#0x0
 ret
 428:	d65f03c0 	ret

000000000000042c <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 42c:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 430:	d4000001 	svc	#0x0
 ret
 434:	d65f03c0 	ret

0000000000000438 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 438:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 43c:	d4000001 	svc	#0x0
 ret
 440:	d65f03c0 	ret

0000000000000444 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 444:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 448:	d4000001 	svc	#0x0
 ret
 44c:	d65f03c0 	ret

0000000000000450 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 450:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 454:	d4000001 	svc	#0x0
 ret
 458:	d65f03c0 	ret

000000000000045c <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 45c:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 460:	d4000001 	svc	#0x0
 ret
 464:	d65f03c0 	ret

0000000000000468 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 468:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 46c:	d4000001 	svc	#0x0
 ret
 470:	d65f03c0 	ret

0000000000000474 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 474:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 478:	d4000001 	svc	#0x0
 ret
 47c:	d65f03c0 	ret

0000000000000480 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 480:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 484:	d4000001 	svc	#0x0
 ret
 488:	d65f03c0 	ret

000000000000048c <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 48c:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 490:	d4000001 	svc	#0x0
 ret
 494:	d65f03c0 	ret

0000000000000498 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 498:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 49c:	d4000001 	svc	#0x0
 ret
 4a0:	d65f03c0 	ret

00000000000004a4 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 4a4:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 4a8:	d4000001 	svc	#0x0
 ret
 4ac:	d65f03c0 	ret

00000000000004b0 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 4b0:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 4b4:	d4000001 	svc	#0x0
 ret
 4b8:	d65f03c0 	ret

00000000000004bc <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 4bc:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 4c0:	d4000001 	svc	#0x0
 ret
 4c4:	d65f03c0 	ret

00000000000004c8 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 4c8:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 4cc:	d4000001 	svc	#0x0
 ret
 4d0:	d65f03c0 	ret

00000000000004d4 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 4d4:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 4d8:	d4000001 	svc	#0x0
 ret
 4dc:	d65f03c0 	ret

00000000000004e0 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 4e0:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 4e4:	d4000001 	svc	#0x0
 ret
 4e8:	d65f03c0 	ret

00000000000004ec <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 4ec:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 4f0:	d4000001 	svc	#0x0
 ret
 4f4:	d65f03c0 	ret

00000000000004f8 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 4f8:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 4fc:	d4000001 	svc	#0x0
 ret
 500:	d65f03c0 	ret

0000000000000504 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 504:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 508:	d4000001 	svc	#0x0
 ret
 50c:	d65f03c0 	ret

0000000000000510 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 510:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 514:	52800022 	mov	w2, #0x1                   	// #1
{
 518:	910003fd 	mov	x29, sp
 51c:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 520:	91007fe1 	add	x1, sp, #0x1f
 524:	97ffff2f 	bl	1e0 <write>
 528:	7100041f 	cmp	w0, #0x1
}
 52c:	1a9f17e0 	cset	w0, eq	// eq = none
 530:	a8c27bfd 	ldp	x29, x30, [sp], #32
 534:	d65f03c0 	ret

0000000000000538 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 538:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 53c:	910003fd 	mov	x29, sp
 540:	a90153f3 	stp	x19, x20, [sp, #16]
 544:	a9025bf5 	stp	x21, x22, [sp, #32]
 548:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 54c:	6a417c7f 	tst	w3, w1, lsr #31
 550:	54000300 	b.eq	5b0 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 554:	4b0103e1 	neg	w1, w1
    neg = 1;
 558:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 55c:	90000003 	adrp	x3, 0 <main>
 560:	9127cc63 	add	x3, x3, #0x9f3
 564:	9100c3f5 	add	x21, sp, #0x30
 568:	d2800000 	mov	x0, #0x0                   	// #0
 56c:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 570:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 574:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 578:	2a0403e1 	mov	w1, w4
 57c:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 580:	38666866 	ldrb	w6, [x3, x6]
 584:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 588:	91000400 	add	x0, x0, #0x1
 58c:	54ffff09 	b.ls	56c <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 590:	11000493 	add	w19, w4, #0x1
  if(neg)
 594:	34000085 	cbz	w5, 5a4 <printint+0x6c>
    buf[i++] = '-';
 598:	528005a0 	mov	w0, #0x2d                  	// #45
 59c:	38334aa0 	strb	w0, [x21, w19, uxtw]
 5a0:	11000893 	add	w19, w4, #0x2
 5a4:	51000673 	sub	w19, w19, #0x1
 5a8:	52800014 	mov	w20, #0x0                   	// #0
 5ac:	14000008 	b	5cc <printint+0x94>
  neg = 0;
 5b0:	52800005 	mov	w5, #0x0                   	// #0
 5b4:	17ffffea 	b	55c <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 5b8:	38736aa1 	ldrb	w1, [x21, x19]
 5bc:	2a1603e0 	mov	w0, w22
 5c0:	d1000673 	sub	x19, x19, #0x1
 5c4:	97ffffd3 	bl	510 <putc>
 5c8:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 5cc:	3100067f 	cmn	w19, #0x1
 5d0:	54ffff41 	b.ne	5b8 <printint+0x80>  // b.any
  return written;
}
 5d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
 5d8:	2a1403e0 	mov	w0, w20
 5dc:	a94153f3 	ldp	x19, x20, [sp, #16]
 5e0:	a8c47bfd 	ldp	x29, x30, [sp], #64
 5e4:	d65f03c0 	ret

00000000000005e8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 5e8:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 5ec:	910003fd 	mov	x29, sp
 5f0:	a90153f3 	stp	x19, x20, [sp, #16]
 5f4:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 5f8:	52800015 	mov	w21, #0x0                   	// #0
{
 5fc:	a90363f7 	stp	x23, x24, [sp, #48]
 600:	2a0003f7 	mov	w23, w0
 604:	a9046bf9 	stp	x25, x26, [sp, #64]
 608:	aa0103f9 	mov	x25, x1

  state = 0;
 60c:	52800001 	mov	w1, #0x0                   	// #0
{
 610:	a90573fb 	stp	x27, x28, [sp, #80]
 614:	a9406053 	ldp	x19, x24, [x2]
 618:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 61c:	39400320 	ldrb	w0, [x25]
 620:	35000120 	cbnz	w0, 644 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 624:	2a1503e0 	mov	w0, w21
 628:	a94153f3 	ldp	x19, x20, [sp, #16]
 62c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 630:	a94363f7 	ldp	x23, x24, [sp, #48]
 634:	a9446bf9 	ldp	x25, x26, [sp, #64]
 638:	a94573fb 	ldp	x27, x28, [sp, #80]
 63c:	a8c67bfd 	ldp	x29, x30, [sp], #96
 640:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 644:	2a0003f6 	mov	w22, w0
    if(state == 0){
 648:	35000101 	cbnz	w1, 668 <vprintf+0x80>
      if(c == '%'){
 64c:	7100941f 	cmp	w0, #0x25
 650:	54000ba0 	b.eq	7c4 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 654:	2a1603e1 	mov	w1, w22
 658:	2a1703e0 	mov	w0, w23
 65c:	97ffffad 	bl	510 <putc>
 660:	0b0002b5 	add	w21, w21, w0
 664:	14000057 	b	7c0 <vprintf+0x1d8>
      if(c == 'd'){
 668:	7101901f 	cmp	w0, #0x64
 66c:	540002a1 	b.ne	6c0 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 670:	37f80174 	tbnz	w20, #31, 69c <vprintf+0xb4>
 674:	91002e76 	add	x22, x19, #0xb
 678:	2a1403fa 	mov	w26, w20
 67c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 680:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 684:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 688:	b9400261 	ldr	w1, [x19]
 68c:	2a1703e0 	mov	w0, w23
 690:	97ffffaa 	bl	538 <printint>
        written += putc(fd, va_arg(ap, uint));
 694:	0b0002b5 	add	w21, w21, w0
 698:	14000048 	b	7b8 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 69c:	1100229a 	add	w26, w20, #0x8
 6a0:	7100035f 	cmp	w26, #0x0
 6a4:	5400008d 	b.le	6b4 <vprintf+0xcc>
 6a8:	91002e76 	add	x22, x19, #0xb
 6ac:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6b0:	17fffff4 	b	680 <vprintf+0x98>
 6b4:	aa1303f6 	mov	x22, x19
 6b8:	8b34c313 	add	x19, x24, w20, sxtw
 6bc:	17fffff1 	b	680 <vprintf+0x98>
      } else if(c == 'l') {
 6c0:	7101b01f 	cmp	w0, #0x6c
 6c4:	54000201 	b.ne	704 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 6c8:	37f800d4 	tbnz	w20, #31, 6e0 <vprintf+0xf8>
 6cc:	91003e76 	add	x22, x19, #0xf
 6d0:	2a1403fa 	mov	w26, w20
 6d4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6d8:	52800003 	mov	w3, #0x0                   	// #0
 6dc:	17ffffea 	b	684 <vprintf+0x9c>
 6e0:	1100229a 	add	w26, w20, #0x8
 6e4:	7100035f 	cmp	w26, #0x0
 6e8:	5400008d 	b.le	6f8 <vprintf+0x110>
 6ec:	91003e76 	add	x22, x19, #0xf
 6f0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6f4:	17fffff9 	b	6d8 <vprintf+0xf0>
 6f8:	aa1303f6 	mov	x22, x19
 6fc:	8b34c313 	add	x19, x24, w20, sxtw
 700:	17fffff6 	b	6d8 <vprintf+0xf0>
      } else if(c == 'x') {
 704:	7101e01f 	cmp	w0, #0x78
 708:	54000221 	b.ne	74c <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 70c:	37f800f4 	tbnz	w20, #31, 728 <vprintf+0x140>
 710:	91002e76 	add	x22, x19, #0xb
 714:	2a1403fa 	mov	w26, w20
 718:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 71c:	52800003 	mov	w3, #0x0                   	// #0
 720:	52800202 	mov	w2, #0x10                  	// #16
 724:	17ffffd9 	b	688 <vprintf+0xa0>
 728:	1100229a 	add	w26, w20, #0x8
 72c:	7100035f 	cmp	w26, #0x0
 730:	5400008d 	b.le	740 <vprintf+0x158>
 734:	91002e76 	add	x22, x19, #0xb
 738:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 73c:	17fffff8 	b	71c <vprintf+0x134>
 740:	aa1303f6 	mov	x22, x19
 744:	8b34c313 	add	x19, x24, w20, sxtw
 748:	17fffff5 	b	71c <vprintf+0x134>
      } else if(c == 'p') {
 74c:	7101c01f 	cmp	w0, #0x70
 750:	54000521 	b.ne	7f4 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 754:	37f803f4 	tbnz	w20, #31, 7d0 <vprintf+0x1e8>
 758:	91003e76 	add	x22, x19, #0xf
 75c:	2a1403fa 	mov	w26, w20
 760:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 764:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 768:	52800601 	mov	w1, #0x30                  	// #48
 76c:	2a1703e0 	mov	w0, w23
 770:	97ffff68 	bl	510 <putc>
 774:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 778:	9000001c 	adrp	x28, 0 <main>
 77c:	9127cf9c 	add	x28, x28, #0x9f3
  written += putc(fd, 'x');
 780:	2a1703e0 	mov	w0, w23
 784:	52800f01 	mov	w1, #0x78                  	// #120
 788:	97ffff62 	bl	510 <putc>
 78c:	0b000273 	add	w19, w19, w0
 790:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 794:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 798:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 79c:	38606b81 	ldrb	w1, [x28, x0]
 7a0:	2a1703e0 	mov	w0, w23
 7a4:	97ffff5b 	bl	510 <putc>
 7a8:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7ac:	71000694 	subs	w20, w20, #0x1
 7b0:	54ffff21 	b.ne	794 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 7b4:	0b1302b5 	add	w21, w21, w19
 7b8:	2a1a03f4 	mov	w20, w26
 7bc:	aa1603f3 	mov	x19, x22
      state = 0;
 7c0:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 7c4:	91000739 	add	x25, x25, #0x1
  state = 0;
 7c8:	2a1603e1 	mov	w1, w22
 7cc:	17ffff94 	b	61c <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 7d0:	1100229a 	add	w26, w20, #0x8
 7d4:	7100035f 	cmp	w26, #0x0
 7d8:	5400008d 	b.le	7e8 <vprintf+0x200>
 7dc:	91003e76 	add	x22, x19, #0xf
 7e0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 7e4:	17ffffe0 	b	764 <vprintf+0x17c>
 7e8:	aa1303f6 	mov	x22, x19
 7ec:	8b34c313 	add	x19, x24, w20, sxtw
 7f0:	17ffffdd 	b	764 <vprintf+0x17c>
      } else if(c == 's'){
 7f4:	7101cc1f 	cmp	w0, #0x73
 7f8:	54000381 	b.ne	868 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 7fc:	37f80214 	tbnz	w20, #31, 83c <vprintf+0x254>
 800:	91003e61 	add	x1, x19, #0xf
 804:	aa1303e0 	mov	x0, x19
 808:	927df033 	and	x19, x1, #0xfffffffffffffff8
 80c:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 810:	90000000 	adrp	x0, 0 <main>
 814:	9127b000 	add	x0, x0, #0x9ec
 818:	f10002df 	cmp	x22, #0x0
 81c:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 820:	394002c1 	ldrb	w1, [x22]
 824:	34fffce1 	cbz	w1, 7c0 <vprintf+0x1d8>
          written += putc(fd, *s);
 828:	2a1703e0 	mov	w0, w23
          s++;
 82c:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 830:	97ffff38 	bl	510 <putc>
 834:	0b0002b5 	add	w21, w21, w0
          s++;
 838:	17fffffa 	b	820 <vprintf+0x238>
        s = va_arg(ap, char*);
 83c:	11002281 	add	w1, w20, #0x8
 840:	7100003f 	cmp	w1, #0x0
 844:	540000cd 	b.le	85c <vprintf+0x274>
 848:	91003e62 	add	x2, x19, #0xf
 84c:	aa1303e0 	mov	x0, x19
 850:	2a0103f4 	mov	w20, w1
 854:	927df053 	and	x19, x2, #0xfffffffffffffff8
 858:	17ffffed 	b	80c <vprintf+0x224>
 85c:	8b34c300 	add	x0, x24, w20, sxtw
 860:	2a0103f4 	mov	w20, w1
 864:	17ffffea 	b	80c <vprintf+0x224>
      } else if(c == 'c'){
 868:	71018c1f 	cmp	w0, #0x63
 86c:	54000241 	b.ne	8b4 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 870:	37f80114 	tbnz	w20, #31, 890 <vprintf+0x2a8>
 874:	91002e76 	add	x22, x19, #0xb
 878:	2a1403fa 	mov	w26, w20
 87c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 880:	39400261 	ldrb	w1, [x19]
 884:	2a1703e0 	mov	w0, w23
 888:	97ffff22 	bl	510 <putc>
 88c:	17ffff82 	b	694 <vprintf+0xac>
 890:	1100229a 	add	w26, w20, #0x8
 894:	7100035f 	cmp	w26, #0x0
 898:	5400008d 	b.le	8a8 <vprintf+0x2c0>
 89c:	91002e76 	add	x22, x19, #0xb
 8a0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8a4:	17fffff7 	b	880 <vprintf+0x298>
 8a8:	aa1303f6 	mov	x22, x19
 8ac:	8b34c313 	add	x19, x24, w20, sxtw
 8b0:	17fffff4 	b	880 <vprintf+0x298>
      } else if(c == '%'){
 8b4:	7100941f 	cmp	w0, #0x25
 8b8:	54ffece0 	b.eq	654 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 8bc:	2a1703e0 	mov	w0, w23
 8c0:	528004a1 	mov	w1, #0x25                  	// #37
 8c4:	97ffff13 	bl	510 <putc>
 8c8:	0b0002b5 	add	w21, w21, w0
 8cc:	17ffff62 	b	654 <vprintf+0x6c>

00000000000008d0 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 8d0:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 8d4:	910003fd 	mov	x29, sp
 8d8:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 8dc:	910203e2 	add	x2, sp, #0x80
 8e0:	a9030be2 	stp	x2, x2, [sp, #48]
 8e4:	910143e2 	add	x2, sp, #0x50
 8e8:	f90023e2 	str	x2, [sp, #64]
 8ec:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 8f0:	b9004be2 	str	w2, [sp, #72]
 8f4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 8f8:	a9430fe2 	ldp	x2, x3, [sp, #48]
 8fc:	a9010fe2 	stp	x2, x3, [sp, #16]
 900:	a9440fe2 	ldp	x2, x3, [sp, #64]
 904:	a9020fe2 	stp	x2, x3, [sp, #32]
 908:	910043e2 	add	x2, sp, #0x10
{
 90c:	a90617e4 	stp	x4, x5, [sp, #96]
 910:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 914:	97ffff35 	bl	5e8 <vprintf>
  va_end(ap);
  return result;
}
 918:	a8c87bfd 	ldp	x29, x30, [sp], #128
 91c:	d65f03c0 	ret

0000000000000920 <printf>:

int
printf(const char *fmt, ...)
{
 920:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 924:	910003fd 	mov	x29, sp
 928:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 92c:	910243e1 	add	x1, sp, #0x90
 930:	a90307e1 	stp	x1, x1, [sp, #48]
 934:	910143e1 	add	x1, sp, #0x50
 938:	f90023e1 	str	x1, [sp, #64]
 93c:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 940:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 944:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 948:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 94c:	52800020 	mov	w0, #0x1                   	// #1
{
 950:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 954:	a9430fe2 	ldp	x2, x3, [sp, #48]
 958:	a9010fe2 	stp	x2, x3, [sp, #16]
 95c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 960:	a9020fe2 	stp	x2, x3, [sp, #32]
 964:	910043e2 	add	x2, sp, #0x10
{
 968:	a9079be5 	stp	x5, x6, [sp, #120]
 96c:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 970:	97ffff1e 	bl	5e8 <vprintf>
  va_end(ap);
  return result;
}
 974:	a8c97bfd 	ldp	x29, x30, [sp], #144
 978:	d65f03c0 	ret
