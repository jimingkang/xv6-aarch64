
user/_tcc:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  return 0;
}

int
main(int argc, char **argv)
{
       0:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
       4:	910003fd 	mov	x29, sp
       8:	a90153f3 	stp	x19, x20, [sp, #16]
  char *in = 0, *out = "a.out";
       c:	b0000014 	adrp	x20, 1000 <stat+0x48>
      10:	91245694 	add	x20, x20, #0x915
{
      14:	a9025bf5 	stp	x21, x22, [sp, #32]
  int fd, n = 0, r, i;
  for(i = 1; i < argc; i++){
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
      18:	b0000016 	adrp	x22, 1000 <stat+0x48>
      1c:	91246ed6 	add	x22, x22, #0x91b
{
      20:	a90363f7 	stp	x23, x24, [sp, #48]
      24:	2a0003f8 	mov	w24, w0
      28:	aa0103f7 	mov	x23, x1
  for(i = 1; i < argc; i++){
      2c:	52800033 	mov	w19, #0x1                   	// #1
  char *in = 0, *out = "a.out";
      30:	d2800015 	mov	x21, #0x0                   	// #0
{
      34:	a9046bf9 	stp	x25, x26, [sp, #64]
  for(i = 1; i < argc; i++){
      38:	6b18027f 	cmp	w19, w24
      3c:	540001cb 	b.lt	74 <main+0x74>  // b.tstop
    else if(in == 0) in = argv[i];
    else { fprintf(2, "usage: tcc source.c [-o program]\n"); exit(1); }
  }
  if(in == 0){ fprintf(2, "usage: tcc source.c [-o program]\n"); exit(1); }
      40:	b40003b5 	cbz	x21, b4 <main+0xb4>
  fd = open(in, O_RDONLY);
      44:	aa1503e0 	mov	x0, x21
      48:	52800001 	mov	w1, #0x0                   	// #0
      4c:	9400043b 	bl	1138 <open>
      50:	2a0003f6 	mov	w22, w0
  if(fd < 0){ fprintf(2, "tcc: cannot open %s\n", in); exit(1); }
      54:	36f803a0 	tbz	w0, #31, c8 <main+0xc8>
      58:	b0000001 	adrp	x1, 1000 <stat+0x48>
      5c:	91250021 	add	x1, x1, #0x940
      60:	aa1503e2 	mov	x2, x21
      64:	52800040 	mov	w0, #0x2                   	// #2
      68:	940005e4 	bl	17f8 <fprintf>
      6c:	52800020 	mov	w0, #0x1                   	// #1
      70:	9400041a 	bl	10d8 <exit>
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
      74:	937d7e79 	sbfiz	x25, x19, #3, #32
      78:	8b33cefa 	add	x26, x23, w19, sxtw #3
      7c:	aa1603e1 	mov	x1, x22
      80:	f8796ae0 	ldr	x0, [x23, x25]
      84:	94000373 	bl	e50 <strcmp>
      88:	350000e0 	cbnz	w0, a4 <main+0xa4>
      8c:	11000660 	add	w0, w19, #0x1
      90:	6b18001f 	cmp	w0, w24
      94:	5400008a 	b.ge	a4 <main+0xa4>  // b.tcont
      98:	f9400754 	ldr	x20, [x26, #8]
  for(i = 1; i < argc; i++){
      9c:	11000413 	add	w19, w0, #0x1
      a0:	17ffffe6 	b	38 <main+0x38>
    else if(in == 0) in = argv[i];
      a4:	b5000095 	cbnz	x21, b4 <main+0xb4>
      a8:	f8796af5 	ldr	x21, [x23, x25]
      ac:	2a1303e0 	mov	w0, w19
      b0:	17fffffb 	b	9c <main+0x9c>
    else { fprintf(2, "usage: tcc source.c [-o program]\n"); exit(1); }
      b4:	b0000001 	adrp	x1, 1000 <stat+0x48>
      b8:	91247821 	add	x1, x1, #0x91e
  while(n < SRCMAX && (r = read(fd, source + n, SRCMAX - n)) > 0) n += r;
  close(fd);
  if(n == SRCMAX){ fprintf(2, "tcc: source is too large\n"); exit(1); }
      bc:	52800040 	mov	w0, #0x2                   	// #2
      c0:	940005ce 	bl	17f8 <fprintf>
      c4:	17ffffea 	b	6c <main+0x6c>
  while(n < SRCMAX && (r = read(fd, source + n, SRCMAX - n)) > 0) n += r;
      c8:	f0000035 	adrp	x21, 7000 <code+0x3c24>
      cc:	910f72b5 	add	x21, x21, #0x3dc
  int fd, n = 0, r, i;
      d0:	52800013 	mov	w19, #0x0                   	// #0
  while(n < SRCMAX && (r = read(fd, source + n, SRCMAX - n)) > 0) n += r;
      d4:	52880017 	mov	w23, #0x4000                	// #16384
      d8:	5287fff8 	mov	w24, #0x3fff                	// #16383
      dc:	4b1302e2 	sub	w2, w23, w19
      e0:	8b33c2a1 	add	x1, x21, w19, sxtw
      e4:	2a1603e0 	mov	w0, w22
      e8:	94000405 	bl	10fc <read>
      ec:	7100001f 	cmp	w0, #0x0
      f0:	5400008d 	b.le	100 <main+0x100>
      f4:	0b000273 	add	w19, w19, w0
      f8:	6b18027f 	cmp	w19, w24
      fc:	54ffff0d 	b.le	dc <main+0xdc>
  close(fd);
     100:	2a1603e0 	mov	w0, w22
     104:	94000404 	bl	1114 <close>
  if(n == SRCMAX){ fprintf(2, "tcc: source is too large\n"); exit(1); }
     108:	7140127f 	cmp	w19, #0x4, lsl #12
     10c:	54000081 	b.ne	11c <main+0x11c>  // b.any
     110:	b0000001 	adrp	x1, 1000 <stat+0x48>
     114:	91255421 	add	x1, x1, #0x955
     118:	17ffffe9 	b	bc <main+0xbc>
  source[n] = 0; cur = source;
     11c:	3833cabf 	strb	wzr, [x21, w19, sxtw]
     120:	b0000013 	adrp	x19, 1000 <stat+0x48>
     124:	912bc273 	add	x19, x19, #0xaf0
    if(word("main")) sawmain = 1;
     128:	b0000016 	adrp	x22, 1000 <stat+0x48>
     12c:	9125bed6 	add	x22, x22, #0x96f
  while(tok != T_EOF && tok != '{'){
     130:	52800f77 	mov	w23, #0x7b                  	// #123
  source[n] = 0; cur = source;
     134:	f9026a75 	str	x21, [x19, #1232]
  int sawmain = 0;
     138:	52800015 	mov	w21, #0x0                   	// #0
  next();
     13c:	940001e4 	bl	8cc <next>
  while(tok != T_EOF && tok != '{'){
     140:	b9400260 	ldr	w0, [x19]
     144:	7104001f 	cmp	w0, #0x100
     148:	7a571004 	ccmp	w0, w23, #0x4, ne	// ne = any
     14c:	540007c1 	b.ne	244 <main+0x244>  // b.any
  if(!sawmain){ error("expected main function"); return; }
     150:	35000855 	cbnz	w21, 258 <main+0x258>
     154:	b0000000 	adrp	x0, 1000 <stat+0x48>
     158:	9125d000 	add	x0, x0, #0x974
     15c:	94000188 	bl	77c <error>
  compile();
  if(failed || output(out) < 0) exit(1);
     160:	b944ca76 	ldr	w22, [x19, #1224]
     164:	35fff856 	cbnz	w22, 6c <main+0x6c>
  int fd, i, payload = ncode * 4 + nstrings;
     168:	b944ce60 	ldr	w0, [x19, #1228]
  memset(&eh, 0, sizeof(eh));
     16c:	52800802 	mov	w2, #0x40                  	// #64
  int fd, i, payload = ncode * 4 + nstrings;
     170:	b946e661 	ldr	w1, [x19, #1764]
     174:	0b000835 	add	w21, w1, w0, lsl #2
  memset(&eh, 0, sizeof(eh));
     178:	52800001 	mov	w1, #0x0                   	// #0
     17c:	910283e0 	add	x0, sp, #0xa0
     180:	9400035d 	bl	ef4 <memset>
  memset(&ph, 0, sizeof(ph));
     184:	52800702 	mov	w2, #0x38                  	// #56
     188:	52800001 	mov	w1, #0x0                   	// #0
     18c:	9101a3e0 	add	x0, sp, #0x68
     190:	94000359 	bl	ef4 <memset>
  eh.magic = ELF_MAGIC;
     194:	5288afe0 	mov	w0, #0x457f                	// #17791
     198:	72a8c980 	movk	w0, #0x464c, lsl #16
     19c:	b900a3e0 	str	w0, [sp, #160]
  eh.elf[0] = 2; eh.elf[1] = 1; eh.elf[2] = 1;
     1a0:	52802040 	mov	w0, #0x102                 	// #258
     1a4:	79014be0 	strh	w0, [sp, #164]
     1a8:	52800020 	mov	w0, #0x1                   	// #1
     1ac:	39029be0 	strb	w0, [sp, #166]
  eh.type = 2; eh.machine = 183; eh.version = 1;
     1b0:	1281ffa0 	mov	w0, #0xfffff002            	// #-4094
     1b4:	916dc400 	add	x0, x0, #0xb71, lsl #12
    int target = ncode * 4 + patches[i].off;
     1b8:	b944ce66 	ldr	w6, [x19, #1228]
  for(i = 0; i < npatch; i++){
     1bc:	b946ea65 	ldr	w5, [x19, #1768]
    code[patches[i].insn] = 0x10000001U | (immlo << 29) | (immhi << 5);
     1c0:	f0000002 	adrp	x2, 3000 <strings+0xc24>
     1c4:	910f7042 	add	x2, x2, #0x3dc
  eh.type = 2; eh.machine = 183; eh.version = 1;
     1c8:	a90b7fe0 	stp	x0, xzr, [sp, #176]
  eh.entry = 0; eh.phoff = sizeof(eh);
     1cc:	d2800800 	mov	x0, #0x40                  	// #64
     1d0:	f90063e0 	str	x0, [sp, #192]
  eh.ehsize = sizeof(eh); eh.phentsize = sizeof(ph); eh.phnum = 1;
     1d4:	114e0000 	add	w0, w0, #0x380, lsl #12
     1d8:	b900d7e0 	str	w0, [sp, #212]
     1dc:	52800020 	mov	w0, #0x1                   	// #1
     1e0:	7901b3e0 	strh	w0, [sp, #216]
  ph.type = ELF_PROG_LOAD;
     1e4:	d2800020 	mov	x0, #0x1                   	// #1
     1e8:	f2c000e0 	movk	x0, #0x7, lsl #32
     1ec:	f90037e0 	str	x0, [sp, #104]
  ph.off = sizeof(eh) + sizeof(ph);
     1f0:	d2800f00 	mov	x0, #0x78                  	// #120
     1f4:	911bb261 	add	x1, x19, #0x6ec
     1f8:	f9003be0 	str	x0, [sp, #112]
  ph.vaddr = 0; ph.paddr = 0; ph.filesz = payload; ph.memsz = payload; ph.align = 8;
     1fc:	93407ea0 	sxtw	x0, w21
    code[patches[i].insn] = 0x10000001U | (immlo << 29) | (immhi << 5);
     200:	52800027 	mov	w7, #0x1                   	// #1
     204:	72a20007 	movk	w7, #0x1000, lsl #16
  ph.vaddr = 0; ph.paddr = 0; ph.filesz = payload; ph.memsz = payload; ph.align = 8;
     208:	a907ffff 	stp	xzr, xzr, [sp, #120]
     20c:	a90883e0 	stp	x0, x0, [sp, #136]
     210:	d2800100 	mov	x0, #0x8                   	// #8
     214:	f9004fe0 	str	x0, [sp, #152]
  for(i = 0; i < npatch; i++){
     218:	6b0502df 	cmp	w22, w5
     21c:	54001ecb 	b.lt	5f4 <main+0x5f4>  // b.tstop
  fd = open(path, O_CREATE | O_TRUNC | O_WRONLY);
     220:	aa1403e0 	mov	x0, x20
     224:	5280c021 	mov	w1, #0x601                 	// #1537
     228:	940003c4 	bl	1138 <open>
     22c:	2a0003f5 	mov	w21, w0
  if(fd < 0){ fprintf(2, "tcc: cannot create %s\n", path); return -1; }
     230:	36f81f80 	tbz	w0, #31, 620 <main+0x620>
     234:	b0000001 	adrp	x1, 1000 <stat+0x48>
     238:	9129dc21 	add	x1, x1, #0xa77
     23c:	aa1403e2 	mov	x2, x20
     240:	17ffff89 	b	64 <main+0x64>
    if(word("main")) sawmain = 1;
     244:	aa1603e0 	mov	x0, x22
     248:	94000124 	bl	6d8 <word>
     24c:	2a0002b5 	orr	w21, w21, w0
    next();
     250:	9400019f 	bl	8cc <next>
     254:	17ffffbb 	b	140 <main+0x140>
  need('{', "expected '{'");
     258:	b0000001 	adrp	x1, 1000 <stat+0x48>
     25c:	91262c21 	add	x1, x1, #0x98b
  if(word("int")){
     260:	b0000016 	adrp	x22, 1000 <stat+0x48>
     264:	912662d6 	add	x22, x22, #0x998
  } else if(word("return")){
     268:	b0000017 	adrp	x23, 1000 <stat+0x48>
     26c:	91279af7 	add	x23, x23, #0x9e6
  need('{', "expected '{'");
     270:	52800f60 	mov	w0, #0x7b                  	// #123
     274:	94000248 	bl	b94 <need>
  emit(0xd10403ffU);                       // sub sp, sp, #256
     278:	52807fe0 	mov	w0, #0x3ff                 	// #1023
     27c:	72ba2080 	movk	w0, #0xd104, lsl #16
     280:	94000169 	bl	824 <emit>
  emit(0x910003fdU);                       // mov x29, sp
     284:	52807fa0 	mov	w0, #0x3fd                 	// #1021
     288:	72b22000 	movk	w0, #0x9100, lsl #16
     28c:	94000166 	bl	824 <emit>
  while(tok != '}' && tok != T_EOF && !failed) statement();
     290:	b9400260 	ldr	w0, [x19]
     294:	52802001 	mov	w1, #0x100                 	// #256
     298:	7101f41f 	cmp	w0, #0x7d
     29c:	7a411004 	ccmp	w0, w1, #0x4, ne	// ne = any
     2a0:	54000060 	b.eq	2ac <main+0x2ac>  // b.none
     2a4:	b944ca60 	ldr	w0, [x19, #1224]
     2a8:	34000200 	cbz	w0, 2e8 <main+0x2e8>
  need('}', "expected '}'");
     2ac:	52800fa0 	mov	w0, #0x7d                  	// #125
     2b0:	b0000001 	adrp	x1, 1000 <stat+0x48>
     2b4:	9129a821 	add	x1, x1, #0xa6a
     2b8:	94000237 	bl	b94 <need>
  if(!returned){ mov64(0, 0); mov64(7, 2); emit(0xd4000001U); }
     2bc:	b946e260 	ldr	w0, [x19, #1760]
     2c0:	35fff500 	cbnz	w0, 160 <main+0x160>
     2c4:	d2800001 	mov	x1, #0x0                   	// #0
     2c8:	94000165 	bl	85c <mov64>
     2cc:	d2800041 	mov	x1, #0x2                   	// #2
     2d0:	528000e0 	mov	w0, #0x7                   	// #7
     2d4:	94000162 	bl	85c <mov64>
     2d8:	52800020 	mov	w0, #0x1                   	// #1
     2dc:	72ba8000 	movk	w0, #0xd400, lsl #16
     2e0:	94000151 	bl	824 <emit>
     2e4:	17ffff9f 	b	160 <main+0x160>
  if(word("int")){
     2e8:	aa1603e0 	mov	x0, x22
     2ec:	940000fb 	bl	6d8 <word>
     2f0:	34000760 	cbz	w0, 3dc <main+0x3dc>
    next();
     2f4:	94000176 	bl	8cc <next>
    if(tok != T_ID){ error("expected variable name"); return; }
     2f8:	b9400260 	ldr	w0, [x19]
     2fc:	7104041f 	cmp	w0, #0x101
     300:	540000a0 	b.eq	314 <main+0x314>  // b.none
     304:	b0000000 	adrp	x0, 1000 <stat+0x48>
     308:	91267000 	add	x0, x0, #0x99c
  else error("unsupported statement");
     30c:	9400011c 	bl	77c <error>
     310:	17ffffe0 	b	290 <main+0x290>
    if(nvar >= NVAR){ error("too many variables"); return; }
     314:	b944c660 	ldr	w0, [x19, #1220]
     318:	71007c1f 	cmp	w0, #0x1f
     31c:	5400008d 	b.le	32c <main+0x32c>
     320:	b0000000 	adrp	x0, 1000 <stat+0x48>
     324:	9126cc00 	add	x0, x0, #0x9b3
     328:	17fffff9 	b	30c <main+0x30c>
    strcpy(name, ident); next();
     32c:	91001261 	add	x1, x19, #0x4
     330:	910283e0 	add	x0, sp, #0xa0
     334:	940002a4 	bl	dc4 <strcpy>
     338:	94000165 	bl	8cc <next>
    if(findvar(name) >= 0){ error("duplicate variable"); return; }
     33c:	910283e0 	add	x0, sp, #0xa0
     340:	940000f6 	bl	718 <findvar>
     344:	3100041f 	cmn	w0, #0x1
     348:	54000080 	b.eq	358 <main+0x358>  // b.none
     34c:	b0000000 	adrp	x0, 1000 <stat+0x48>
     350:	91271800 	add	x0, x0, #0x9c6
     354:	17ffffee 	b	30c <main+0x30c>
    strcpy(vars[nvar].name, name);
     358:	b944c662 	ldr	w2, [x19, #1220]
     35c:	91011278 	add	x24, x19, #0x44
     360:	52800480 	mov	w0, #0x24                  	// #36
     364:	910283e1 	add	x1, sp, #0xa0
     368:	9b206040 	smaddl	x0, w2, w0, x24
     36c:	94000296 	bl	dc4 <strcpy>
    vars[nvar].off = nvar * 8;
     370:	b944c660 	ldr	w0, [x19, #1220]
     374:	d2800481 	mov	x1, #0x24                  	// #36
     378:	93407c15 	sxtw	x21, w0
     37c:	531d7002 	lsl	w2, w0, #3
    v = nvar++;
     380:	11000400 	add	w0, w0, #0x1
     384:	b904c660 	str	w0, [x19, #1220]
    if(tok == '='){ next(); expr(); }
     388:	b9400260 	ldr	w0, [x19]
    vars[nvar].off = nvar * 8;
     38c:	9b0162a1 	madd	x1, x21, x1, x24
     390:	b9002022 	str	w2, [x1, #32]
    if(tok == '='){ next(); expr(); }
     394:	7100f41f 	cmp	w0, #0x3d
     398:	54000081 	b.ne	3a8 <main+0x3a8>  // b.any
     39c:	9400014c 	bl	8cc <next>
    need('=', "expected '='"); expr();
     3a0:	94000204 	bl	bb0 <expr>
     3a4:	14000004 	b	3b4 <main+0x3b4>
    else mov64(0, 0);
     3a8:	d2800001 	mov	x1, #0x0                   	// #0
     3ac:	52800000 	mov	w0, #0x0                   	// #0
     3b0:	9400012b 	bl	85c <mov64>
    emit(0xf9000000U | ((uint32)(vars[v].off / 8) << 10) | (29 << 5));
     3b4:	d2800480 	mov	x0, #0x24                  	// #36
     3b8:	52800101 	mov	w1, #0x8                   	// #8
     3bc:	9b004eb5 	madd	x21, x21, x0, x19
     3c0:	b94066a0 	ldr	w0, [x21, #100]
     3c4:	1ac10c00 	sdiv	w0, w0, w1
     3c8:	52807401 	mov	w1, #0x3a0                 	// #928
     3cc:	72bf2001 	movk	w1, #0xf900, lsl #16
     3d0:	2a002820 	orr	w0, w1, w0, lsl #10
     3d4:	94000114 	bl	824 <emit>
     3d8:	1400003a 	b	4c0 <main+0x4c0>
  } else if(word("return")){
     3dc:	aa1703e0 	mov	x0, x23
     3e0:	940000be 	bl	6d8 <word>
     3e4:	34000200 	cbz	w0, 424 <main+0x424>
    next(); expr(); need(';', "expected ';'");
     3e8:	94000139 	bl	8cc <next>
     3ec:	940001f1 	bl	bb0 <expr>
     3f0:	52800760 	mov	w0, #0x3b                  	// #59
     3f4:	b0000001 	adrp	x1, 1000 <stat+0x48>
     3f8:	91276421 	add	x1, x1, #0x9d9
     3fc:	940001e6 	bl	b94 <need>
    mov64(7, 2);                          // SYS_exit
     400:	d2800041 	mov	x1, #0x2                   	// #2
     404:	528000e0 	mov	w0, #0x7                   	// #7
     408:	94000115 	bl	85c <mov64>
    emit(0xd4000001U);
     40c:	52800020 	mov	w0, #0x1                   	// #1
     410:	72ba8000 	movk	w0, #0xd400, lsl #16
     414:	94000104 	bl	824 <emit>
    returned = 1;
     418:	52800020 	mov	w0, #0x1                   	// #1
     41c:	b906e260 	str	w0, [x19, #1760]
     420:	17ffff9c 	b	290 <main+0x290>
  } else if(word("printf") || word("puts")){
     424:	b0000000 	adrp	x0, 1000 <stat+0x48>
     428:	9127b400 	add	x0, x0, #0x9ed
     42c:	b0000015 	adrp	x21, 1000 <stat+0x48>
     430:	9127d2b5 	add	x21, x21, #0x9f4
     434:	940000a9 	bl	6d8 <word>
     438:	340004e0 	cbz	w0, 4d4 <main+0x4d4>
    int nl = word("puts");
     43c:	aa1503e0 	mov	x0, x21
     440:	940000a6 	bl	6d8 <word>
     444:	2a0003f5 	mov	w21, w0
    next(); need('(', "expected '('");
     448:	94000121 	bl	8cc <next>
     44c:	52800500 	mov	w0, #0x28                  	// #40
     450:	b0000001 	adrp	x1, 1000 <stat+0x48>
     454:	9127e421 	add	x1, x1, #0x9f9
     458:	940001cf 	bl	b94 <need>
    if(tok != T_STR){ error("only a string literal is supported here"); return; }
     45c:	b9400260 	ldr	w0, [x19]
     460:	71040c1f 	cmp	w0, #0x103
     464:	540005a1 	b.ne	518 <main+0x518>  // b.any
  int len = strlen(literal), off = nstrings;
     468:	91138261 	add	x1, x19, #0x4e0
     46c:	f9002fe1 	str	x1, [sp, #88]
     470:	aa0103e0 	mov	x0, x1
     474:	94000290 	bl	eb4 <strlen>
     478:	b946e67a 	ldr	w26, [x19, #1764]
     47c:	2a0003f8 	mov	w24, w0
  if(nstrings + len + newline > STRMAX || npatch >= NPATCH){
     480:	0b1a0000 	add	w0, w0, w26
     484:	0b150000 	add	w0, w0, w21
     488:	7140041f 	cmp	w0, #0x1, lsl #12
     48c:	540000ac 	b.gt	4a0 <main+0x4a0>
     490:	b946ea60 	ldr	w0, [x19, #1768]
     494:	f9402fe1 	ldr	x1, [sp, #88]
     498:	7100fc1f 	cmp	w0, #0x3f
     49c:	5400044d 	b.le	524 <main+0x524>
    error("too many string literals");
     4a0:	b0000000 	adrp	x0, 1000 <stat+0x48>
     4a4:	9128b800 	add	x0, x0, #0xa2e
     4a8:	940000b5 	bl	77c <error>
    emit_print(nl); next();
     4ac:	94000108 	bl	8cc <next>
    need(')', "expected ')'"); need(';', "expected ';'");
     4b0:	b0000001 	adrp	x1, 1000 <stat+0x48>
     4b4:	9123d021 	add	x1, x1, #0x8f4
     4b8:	52800520 	mov	w0, #0x29                  	// #41
     4bc:	940001b6 	bl	b94 <need>
    need(';', "expected ';'");
     4c0:	b0000001 	adrp	x1, 1000 <stat+0x48>
     4c4:	91276421 	add	x1, x1, #0x9d9
     4c8:	52800760 	mov	w0, #0x3b                  	// #59
     4cc:	940001b2 	bl	b94 <need>
     4d0:	17ffff70 	b	290 <main+0x290>
  } else if(word("printf") || word("puts")){
     4d4:	aa1503e0 	mov	x0, x21
     4d8:	94000080 	bl	6d8 <word>
     4dc:	35fffb00 	cbnz	w0, 43c <main+0x43c>
  } else if(tok == T_ID){
     4e0:	b9400260 	ldr	w0, [x19]
     4e4:	7104041f 	cmp	w0, #0x101
     4e8:	54000781 	b.ne	5d8 <main+0x5d8>  // b.any
    strcpy(name, ident); next();
     4ec:	91001261 	add	x1, x19, #0x4
     4f0:	910283e0 	add	x0, sp, #0xa0
     4f4:	94000234 	bl	dc4 <strcpy>
     4f8:	940000f5 	bl	8cc <next>
    v = findvar(name);
     4fc:	910283e0 	add	x0, sp, #0xa0
     500:	94000086 	bl	718 <findvar>
    if(v < 0){ error("unknown variable"); return; }
     504:	3100041f 	cmn	w0, #0x1
     508:	540005c1 	b.ne	5c0 <main+0x5c0>  // b.any
     50c:	b0000000 	adrp	x0, 1000 <stat+0x48>
     510:	91238c00 	add	x0, x0, #0x8e3
     514:	17ffff7e 	b	30c <main+0x30c>
    if(tok != T_STR){ error("only a string literal is supported here"); return; }
     518:	b0000000 	adrp	x0, 1000 <stat+0x48>
     51c:	91281800 	add	x0, x0, #0xa06
     520:	17ffff7b 	b	30c <main+0x30c>
  memmove(strings + nstrings, literal, len);
     524:	d0000019 	adrp	x25, 2000 <literal+0x30>
     528:	910f7339 	add	x25, x25, #0x3dc
     52c:	2a1803e2 	mov	w2, w24
     530:	8b3ac320 	add	x0, x25, w26, sxtw
     534:	940002c1 	bl	1038 <memmove>
  nstrings += len;
     538:	b946e660 	ldr	w0, [x19, #1764]
     53c:	0b000300 	add	w0, w24, w0
  if(newline) strings[nstrings++] = '\n';
     540:	35000375 	cbnz	w21, 5ac <main+0x5ac>
  nstrings += len;
     544:	b906e660 	str	w0, [x19, #1764]
  mov64(0, 1);                            // stdout
     548:	d2800021 	mov	x1, #0x1                   	// #1
     54c:	52800000 	mov	w0, #0x0                   	// #0
     550:	940000c3 	bl	85c <mov64>
  patches[npatch].insn = ncode;
     554:	b946ea61 	ldr	w1, [x19, #1768]
     558:	911bb260 	add	x0, x19, #0x6ec
     55c:	b944ce64 	ldr	w4, [x19, #1228]
     560:	8b21cc02 	add	x2, x0, w1, sxtw #3
     564:	937d7c23 	sbfiz	x3, x1, #3, #32
  patches[npatch++].off = off;
     568:	11000421 	add	w1, w1, #0x1
     56c:	b906ea61 	str	w1, [x19, #1768]
  patches[npatch].insn = ncode;
     570:	b8236804 	str	w4, [x0, x3]
  emit(0);                                // patched to adr x1, string
     574:	52800000 	mov	w0, #0x0                   	// #0
  patches[npatch++].off = off;
     578:	b900045a 	str	w26, [x2, #4]
  emit(0);                                // patched to adr x1, string
     57c:	940000aa 	bl	824 <emit>
  mov64(2, len + newline);
     580:	0b1802a1 	add	w1, w21, w24
     584:	52800040 	mov	w0, #0x2                   	// #2
     588:	93407c21 	sxtw	x1, w1
     58c:	940000b4 	bl	85c <mov64>
  mov64(7, 16);                           // SYS_write
     590:	d2800201 	mov	x1, #0x10                  	// #16
     594:	528000e0 	mov	w0, #0x7                   	// #7
     598:	940000b1 	bl	85c <mov64>
  emit(0xd4000001U);                      // svc #0
     59c:	52800020 	mov	w0, #0x1                   	// #1
     5a0:	72ba8000 	movk	w0, #0xd400, lsl #16
     5a4:	940000a0 	bl	824 <emit>
     5a8:	17ffffc1 	b	4ac <main+0x4ac>
  if(newline) strings[nstrings++] = '\n';
     5ac:	11000401 	add	w1, w0, #0x1
     5b0:	b906e661 	str	w1, [x19, #1764]
     5b4:	52800141 	mov	w1, #0xa                   	// #10
     5b8:	3820cb21 	strb	w1, [x25, w0, sxtw]
     5bc:	17ffffe3 	b	548 <main+0x548>
    emit(0xf9000000U | ((uint32)(vars[v].off / 8) << 10) | (29 << 5));
     5c0:	2a0003f5 	mov	w21, w0
    need('=', "expected '='"); expr();
     5c4:	b0000001 	adrp	x1, 1000 <stat+0x48>
     5c8:	91291c21 	add	x1, x1, #0xa47
     5cc:	528007a0 	mov	w0, #0x3d                  	// #61
     5d0:	94000171 	bl	b94 <need>
     5d4:	17ffff73 	b	3a0 <main+0x3a0>
  } else if(tok == ';') next();
     5d8:	7100ec1f 	cmp	w0, #0x3b
     5dc:	54000061 	b.ne	5e8 <main+0x5e8>  // b.any
     5e0:	940000bb 	bl	8cc <next>
     5e4:	17ffff2b 	b	290 <main+0x290>
  else error("unsupported statement");
     5e8:	b0000000 	adrp	x0, 1000 <stat+0x48>
     5ec:	91295000 	add	x0, x0, #0xa54
     5f0:	17ffff47 	b	30c <main+0x30c>
    int target = ncode * 4 + patches[i].off;
     5f4:	28c10c24 	ldp	w4, w3, [x1], #8
  for(i = 0; i < npatch; i++){
     5f8:	110006d6 	add	w22, w22, #0x1
    int target = ncode * 4 + patches[i].off;
     5fc:	0b060863 	add	w3, w3, w6, lsl #2
    int delta = target - at;
     600:	4b040863 	sub	w3, w3, w4, lsl #2
    uint32 immhi = ((uint32)(delta >> 2)) & 0x7ffff;
     604:	13027c60 	asr	w0, w3, #2
    code[patches[i].insn] = 0x10000001U | (immlo << 29) | (immhi << 5);
     608:	53030463 	ubfiz	w3, w3, #29, #2
     60c:	531b4800 	ubfiz	w0, w0, #5, #19
     610:	2a030000 	orr	w0, w0, w3
     614:	2a070000 	orr	w0, w0, w7
     618:	b824d840 	str	w0, [x2, w4, sxtw #2]
  for(i = 0; i < npatch; i++){
     61c:	17fffeff 	b	218 <main+0x218>
  if(writeall(fd, &eh, sizeof(eh)) < 0 || writeall(fd, &ph, sizeof(ph)) < 0 ||
     620:	910283e1 	add	x1, sp, #0xa0
     624:	52800802 	mov	w2, #0x40                  	// #64
     628:	94000068 	bl	7c8 <writeall>
     62c:	3100041f 	cmn	w0, #0x1
     630:	54000141 	b.ne	658 <main+0x658>  // b.any
    fprintf(2, "tcc: write failed\n"); close(fd); unlink(path); return -1;
     634:	b0000001 	adrp	x1, 1000 <stat+0x48>
     638:	912a3821 	add	x1, x1, #0xa8e
     63c:	52800040 	mov	w0, #0x2                   	// #2
     640:	9400046e 	bl	17f8 <fprintf>
     644:	2a1503e0 	mov	w0, w21
     648:	940002b3 	bl	1114 <close>
     64c:	aa1403e0 	mov	x0, x20
     650:	940002c0 	bl	1150 <unlink>
     654:	17fffe86 	b	6c <main+0x6c>
  if(writeall(fd, &eh, sizeof(eh)) < 0 || writeall(fd, &ph, sizeof(ph)) < 0 ||
     658:	9101a3e1 	add	x1, sp, #0x68
     65c:	2a1503e0 	mov	w0, w21
     660:	52800702 	mov	w2, #0x38                  	// #56
     664:	94000059 	bl	7c8 <writeall>
     668:	3100041f 	cmn	w0, #0x1
     66c:	54fffe40 	b.eq	634 <main+0x634>  // b.none
     writeall(fd, code, ncode * 4) < 0 || writeall(fd, strings, nstrings) < 0){
     670:	b944ce62 	ldr	w2, [x19, #1228]
     674:	f0000001 	adrp	x1, 3000 <strings+0xc24>
     678:	910f7021 	add	x1, x1, #0x3dc
     67c:	2a1503e0 	mov	w0, w21
     680:	531e7442 	lsl	w2, w2, #2
     684:	94000051 	bl	7c8 <writeall>
  if(writeall(fd, &eh, sizeof(eh)) < 0 || writeall(fd, &ph, sizeof(ph)) < 0 ||
     688:	3100041f 	cmn	w0, #0x1
     68c:	54fffd40 	b.eq	634 <main+0x634>  // b.none
     writeall(fd, code, ncode * 4) < 0 || writeall(fd, strings, nstrings) < 0){
     690:	b946e662 	ldr	w2, [x19, #1764]
     694:	d0000001 	adrp	x1, 2000 <literal+0x30>
     698:	910f7021 	add	x1, x1, #0x3dc
     69c:	2a1503e0 	mov	w0, w21
     6a0:	9400004a 	bl	7c8 <writeall>
     6a4:	3100041f 	cmn	w0, #0x1
     6a8:	54fffc60 	b.eq	634 <main+0x634>  // b.none
  close(fd);
     6ac:	2a1503e0 	mov	w0, w21
     6b0:	94000299 	bl	1114 <close>
  printf("tcc: wrote %s (%d bytes code, %d bytes data)\n", out, ncode*4, nstrings);
     6b4:	b946e663 	ldr	w3, [x19, #1764]
     6b8:	aa1403e1 	mov	x1, x20
     6bc:	b944ce62 	ldr	w2, [x19, #1228]
     6c0:	b0000000 	adrp	x0, 1000 <stat+0x48>
     6c4:	912a8400 	add	x0, x0, #0xaa1
     6c8:	531e7442 	lsl	w2, w2, #2
     6cc:	9400045f 	bl	1848 <printf>
  exit(0);
     6d0:	52800000 	mov	w0, #0x0                   	// #0
     6d4:	17fffe67 	b	70 <main+0x70>

00000000000006d8 <word>:
  return tok == T_ID && strcmp(ident, s) == 0;
     6d8:	b0000001 	adrp	x1, 1000 <stat+0x48>
     6dc:	912bc022 	add	x2, x1, #0xaf0
     6e0:	b94af021 	ldr	w1, [x1, #2800]
     6e4:	7104043f 	cmp	w1, #0x101
     6e8:	54000141 	b.ne	710 <word+0x38>  // b.any
{
     6ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
     6f0:	aa0003e1 	mov	x1, x0
  return tok == T_ID && strcmp(ident, s) == 0;
     6f4:	91001040 	add	x0, x2, #0x4
{
     6f8:	910003fd 	mov	x29, sp
  return tok == T_ID && strcmp(ident, s) == 0;
     6fc:	940001d5 	bl	e50 <strcmp>
     700:	7100001f 	cmp	w0, #0x0
     704:	1a9f17e0 	cset	w0, eq	// eq = none
}
     708:	a8c17bfd 	ldp	x29, x30, [sp], #16
     70c:	d65f03c0 	ret
  return tok == T_ID && strcmp(ident, s) == 0;
     710:	52800000 	mov	w0, #0x0                   	// #0
}
     714:	d65f03c0 	ret

0000000000000718 <findvar>:
{
     718:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     71c:	910003fd 	mov	x29, sp
     720:	a90153f3 	stp	x19, x20, [sp, #16]
     724:	b0000014 	adrp	x20, 1000 <stat+0x48>
     728:	912bc294 	add	x20, x20, #0xaf0
     72c:	a9025bf5 	stp	x21, x22, [sp, #32]
     730:	aa0003f6 	mov	x22, x0
     734:	91011295 	add	x21, x20, #0x44
  for(i = 0; i < nvar; i++)
     738:	52800013 	mov	w19, #0x0                   	// #0
     73c:	b944c680 	ldr	w0, [x20, #1220]
     740:	6b13001f 	cmp	w0, w19
     744:	540000ec 	b.gt	760 <findvar+0x48>
  return -1;
     748:	12800013 	mov	w19, #0xffffffff            	// #-1
}
     74c:	2a1303e0 	mov	w0, w19
     750:	a94153f3 	ldp	x19, x20, [sp, #16]
     754:	a9425bf5 	ldp	x21, x22, [sp, #32]
     758:	a8c37bfd 	ldp	x29, x30, [sp], #48
     75c:	d65f03c0 	ret
    if(strcmp(vars[i].name, name) == 0) return i;
     760:	aa1603e1 	mov	x1, x22
     764:	aa1503e0 	mov	x0, x21
     768:	940001ba 	bl	e50 <strcmp>
     76c:	34ffff00 	cbz	w0, 74c <findvar+0x34>
     770:	910092b5 	add	x21, x21, #0x24
  for(i = 0; i < nvar; i++)
     774:	11000673 	add	w19, w19, #0x1
     778:	17fffff1 	b	73c <findvar+0x24>

000000000000077c <error>:
{
     77c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     780:	910003fd 	mov	x29, sp
     784:	f9000bf3 	str	x19, [sp, #16]
  if(!failed)
     788:	b0000013 	adrp	x19, 1000 <stat+0x48>
     78c:	912bc273 	add	x19, x19, #0xaf0
     790:	b944ca61 	ldr	w1, [x19, #1224]
     794:	35000101 	cbnz	w1, 7b4 <error+0x38>
    fprintf(2, "tcc:%d: %s\n", line, s);
     798:	b0000002 	adrp	x2, 1000 <stat+0x48>
     79c:	b94ae842 	ldr	w2, [x2, #2792]
     7a0:	aa0003e3 	mov	x3, x0
     7a4:	b0000001 	adrp	x1, 1000 <stat+0x48>
     7a8:	91229021 	add	x1, x1, #0x8a4
     7ac:	52800040 	mov	w0, #0x2                   	// #2
     7b0:	94000412 	bl	17f8 <fprintf>
  failed = 1;
     7b4:	52800020 	mov	w0, #0x1                   	// #1
     7b8:	b904ca60 	str	w0, [x19, #1224]
}
     7bc:	f9400bf3 	ldr	x19, [sp, #16]
     7c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
     7c4:	d65f03c0 	ret

00000000000007c8 <writeall>:
{
     7c8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     7cc:	910003fd 	mov	x29, sp
     7d0:	f9000bf3 	str	x19, [sp, #16]
     7d4:	2a0003f3 	mov	w19, w0
  while(n > 0){
     7d8:	7100005f 	cmp	w2, #0x0
     7dc:	540000ac 	b.gt	7f0 <writeall+0x28>
  return 0;
     7e0:	52800000 	mov	w0, #0x0                   	// #0
}
     7e4:	f9400bf3 	ldr	x19, [sp, #16]
     7e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
     7ec:	d65f03c0 	ret
    m = write(fd, p, n);
     7f0:	2a1303e0 	mov	w0, w19
     7f4:	f90013e1 	str	x1, [sp, #32]
     7f8:	b9002fe2 	str	w2, [sp, #44]
     7fc:	94000243 	bl	1108 <write>
    if(m <= 0) return -1;
     800:	7100001f 	cmp	w0, #0x0
     804:	540000cd 	b.le	81c <writeall+0x54>
    p = (char*)p + m; n -= m;
     808:	f94013e1 	ldr	x1, [sp, #32]
     80c:	b9402fe2 	ldr	w2, [sp, #44]
     810:	8b204021 	add	x1, x1, w0, uxtw
     814:	4b000042 	sub	w2, w2, w0
     818:	17fffff0 	b	7d8 <writeall+0x10>
    if(m <= 0) return -1;
     81c:	12800000 	mov	w0, #0xffffffff            	// #-1
     820:	17fffff1 	b	7e4 <writeall+0x1c>

0000000000000824 <emit>:
  if(ncode >= CODEMAX) error("generated program is too large");
     824:	b0000001 	adrp	x1, 1000 <stat+0x48>
     828:	912bc021 	add	x1, x1, #0xaf0
     82c:	b944cc22 	ldr	w2, [x1, #1228]
     830:	713ffc5f 	cmp	w2, #0xfff
     834:	5400008d 	b.le	844 <emit+0x20>
     838:	b0000000 	adrp	x0, 1000 <stat+0x48>
     83c:	9122c000 	add	x0, x0, #0x8b0
     840:	17ffffcf 	b	77c <error>
  else code[ncode++] = insn;
     844:	11000443 	add	w3, w2, #0x1
     848:	b904cc23 	str	w3, [x1, #1228]
     84c:	f0000001 	adrp	x1, 3000 <strings+0xc24>
     850:	910f7021 	add	x1, x1, #0x3dc
     854:	b822d820 	str	w0, [x1, w2, sxtw #2]
}
     858:	d65f03c0 	ret

000000000000085c <mov64>:
{
     85c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     860:	910003fd 	mov	x29, sp
     864:	a90153f3 	stp	x19, x20, [sp, #16]
     868:	2a0003f4 	mov	w20, w0
  emit(0xd2800000U | ((uint32)(v & 0xffff) << 5) | rd); // MOVZ
     86c:	531b3c20 	ubfiz	w0, w1, #5, #16
{
     870:	f90013f5 	str	x21, [sp, #32]
     874:	aa0103f5 	mov	x21, x1
  emit(0xd2800000U | ((uint32)(v & 0xffff) << 5) | rd); // MOVZ
     878:	52ba5001 	mov	w1, #0xd2800000            	// #-763363328
     87c:	2a140000 	orr	w0, w0, w20
     880:	2a010000 	orr	w0, w0, w1
     884:	52800213 	mov	w19, #0x10                  	// #16
     888:	97ffffe7 	bl	824 <emit>
    if((v >> (hw * 16)) & 0xffff)
     88c:	9ad326a0 	lsr	x0, x21, x19
     890:	72003c1f 	tst	w0, #0xffff
     894:	540000e0 	b.eq	8b0 <mov64+0x54>  // b.none
           ((uint32)((v >> (hw * 16)) & 0xffff) << 5) | rd); // MOVK
     898:	52be5001 	mov	w1, #0xf2800000            	// #-226492416
     89c:	531b3c00 	ubfiz	w0, w0, #5, #16
     8a0:	2a134421 	orr	w1, w1, w19, lsl #17
     8a4:	2a140000 	orr	w0, w0, w20
      emit(0xf2800000U | ((uint32)hw << 21) |
     8a8:	2a010000 	orr	w0, w0, w1
     8ac:	97ffffde 	bl	824 <emit>
  for(hw = 1; hw < 4; hw++)
     8b0:	11004273 	add	w19, w19, #0x10
     8b4:	7101027f 	cmp	w19, #0x40
     8b8:	54fffea1 	b.ne	88c <mov64+0x30>  // b.any
}
     8bc:	f94013f5 	ldr	x21, [sp, #32]
     8c0:	a94153f3 	ldp	x19, x20, [sp, #16]
     8c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
     8c8:	d65f03c0 	ret

00000000000008cc <next>:
{
     8cc:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     8d0:	d284c006 	mov	x6, #0x2600                	// #9728
    if(*cur++ == '\n') line++;
     8d4:	b0000002 	adrp	x2, 1000 <stat+0x48>
     8d8:	912ba042 	add	x2, x2, #0xae8
{
     8dc:	910003fd 	mov	x29, sp
again:
     8e0:	52800003 	mov	w3, #0x0                   	// #0
{
     8e4:	a90153f3 	stp	x19, x20, [sp, #16]
     8e8:	f2c00026 	movk	x6, #0x1, lsl #32
     8ec:	f90013f5 	str	x21, [sp, #32]
     8f0:	b0000015 	adrp	x21, 1000 <stat+0x48>
     8f4:	912bc2b3 	add	x19, x21, #0xaf0
     8f8:	f9426a60 	ldr	x0, [x19, #1232]
    if(*cur++ == '\n') line++;
     8fc:	2a0303e4 	mov	w4, w3
  while(*cur == ' ' || *cur == '\t' || *cur == '\r' || *cur == '\n'){
     900:	39400001 	ldrb	w1, [x0]
     904:	7100803f 	cmp	w1, #0x20
     908:	54000208 	b.hi	948 <next+0x7c>  // b.pmore
     90c:	9ac124c5 	lsr	x5, x6, x1
     910:	120000a3 	and	w3, w5, #0x1
     914:	370000c5 	tbnz	w5, #0, 92c <next+0x60>
     918:	36000044 	tbz	w4, #0, 920 <next+0x54>
     91c:	f9026a60 	str	x0, [x19, #1232]
  if(*cur == 0){ tok = T_EOF; return; }
     920:	350005c1 	cbnz	w1, 9d8 <next+0x10c>
     924:	52802001 	mov	w1, #0x100                 	// #256
     928:	14000044 	b	a38 <next+0x16c>
    if(*cur++ == '\n') line++;
     92c:	91000400 	add	x0, x0, #0x1
     930:	7100283f 	cmp	w1, #0xa
     934:	54fffe41 	b.ne	8fc <next+0x30>  // b.any
     938:	b9400041 	ldr	w1, [x2]
     93c:	11000421 	add	w1, w1, #0x1
     940:	b9000041 	str	w1, [x2]
     944:	17ffffee 	b	8fc <next+0x30>
  if(cur[0] == '/' && cur[1] == '/'){
     948:	7100bc3f 	cmp	w1, #0x2f
     94c:	54fffe61 	b.ne	918 <next+0x4c>  // b.any
     950:	39400404 	ldrb	w4, [x0, #1]
     954:	7100bc9f 	cmp	w4, #0x2f
     958:	54000121 	b.ne	97c <next+0xb0>  // b.any
    while(*cur && *cur != '\n') cur++;
     95c:	91000801 	add	x1, x0, #0x2
     960:	aa0103e0 	mov	x0, x1
     964:	38401423 	ldrb	w3, [x1], #1
     968:	7100007f 	cmp	w3, #0x0
     96c:	7a4a1864 	ccmp	w3, #0xa, #0x4, ne	// ne = any
     970:	54ffff81 	b.ne	960 <next+0x94>  // b.any
again:
     974:	52800023 	mov	w3, #0x1                   	// #1
  while(*cur == ' ' || *cur == '\t' || *cur == '\r' || *cur == '\n'){
     978:	17ffffe1 	b	8fc <next+0x30>
  if(cur[0] == '/' && cur[1] == '*'){
     97c:	7100a89f 	cmp	w4, #0x2a
     980:	54000281 	b.ne	9d0 <next+0x104>  // b.any
    cur += 2;
     984:	91000800 	add	x0, x0, #0x2
    while(*cur && !(cur[0] == '*' && cur[1] == '/')){
     988:	39400001 	ldrb	w1, [x0]
     98c:	34ffff41 	cbz	w1, 974 <next+0xa8>
     990:	7100a83f 	cmp	w1, #0x2a
     994:	54000101 	b.ne	9b4 <next+0xe8>  // b.any
     998:	39400401 	ldrb	w1, [x0, #1]
     99c:	7100bc3f 	cmp	w1, #0x2f
     9a0:	54000061 	b.ne	9ac <next+0xe0>  // b.any
    if(*cur) cur += 2;
     9a4:	91000800 	add	x0, x0, #0x2
     9a8:	17fffff3 	b	974 <next+0xa8>
      if(*cur++ == '\n') line++;
     9ac:	91000400 	add	x0, x0, #0x1
     9b0:	17fffff6 	b	988 <next+0xbc>
     9b4:	91000400 	add	x0, x0, #0x1
     9b8:	7100283f 	cmp	w1, #0xa
     9bc:	54fffe61 	b.ne	988 <next+0xbc>  // b.any
     9c0:	b9400041 	ldr	w1, [x2]
     9c4:	11000421 	add	w1, w1, #0x1
     9c8:	b9000041 	str	w1, [x2]
     9cc:	17ffffef 	b	988 <next+0xbc>
     9d0:	34000043 	cbz	w3, 9d8 <next+0x10c>
     9d4:	f9026a60 	str	x0, [x19, #1232]
  return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
     9d8:	51010422 	sub	w2, w1, #0x41
     9dc:	12001c42 	and	w2, w2, #0xff
     9e0:	7100e45f 	cmp	w2, #0x39
     9e4:	54000348 	b.hi	a4c <next+0x180>  // b.pmore
     9e8:	92b78006 	mov	x6, #0xffffffff43ffffff    	// #-3154116609
     9ec:	f2e07fe6 	movk	x6, #0x3ff, lsl #48
     9f0:	9ac224c2 	lsr	x2, x6, x2
     9f4:	36000322 	tbz	w2, #0, a58 <next+0x18c>
     9f8:	f9426a63 	ldr	x3, [x19, #1232]
      if(i < (int)sizeof(ident)-1) ident[i++] = *cur;
     9fc:	91001267 	add	x7, x19, #0x4
     a00:	52800005 	mov	w5, #0x0                   	// #0
    for(i = 0; isalpha_(*cur) || isdigit_(*cur); cur++)
     a04:	52800001 	mov	w1, #0x0                   	// #0
     a08:	39400064 	ldrb	w4, [x3]
  return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
     a0c:	51010480 	sub	w0, w4, #0x41
     a10:	12001c00 	and	w0, w0, #0xff
     a14:	7100e41f 	cmp	w0, #0x39
     a18:	540004e8 	b.hi	ab4 <next+0x1e8>  // b.pmore
     a1c:	9ac024c0 	lsr	x0, x6, x0
     a20:	37000500 	tbnz	w0, #0, ac0 <next+0x1f4>
     a24:	34000045 	cbz	w5, a2c <next+0x160>
     a28:	f9026a63 	str	x3, [x19, #1232]
    ident[i] = 0;
     a2c:	91001273 	add	x19, x19, #0x4
     a30:	38214a7f 	strb	wzr, [x19, w1, uxtw]
    return;
     a34:	52802021 	mov	w1, #0x101                 	// #257
}
     a38:	a94153f3 	ldp	x19, x20, [sp, #16]
  if(*cur == 0){ tok = T_EOF; return; }
     a3c:	b90af2a1 	str	w1, [x21, #2800]
}
     a40:	f94013f5 	ldr	x21, [sp, #32]
     a44:	a8c37bfd 	ldp	x29, x30, [sp], #48
     a48:	d65f03c0 	ret
  return c >= '0' && c <= '9';
     a4c:	5100c022 	sub	w2, w1, #0x30
  if(isdigit_(*cur)){
     a50:	7100245f 	cmp	w2, #0x9
     a54:	54000449 	b.ls	adc <next+0x210>  // b.plast
    cur++;
     a58:	91000400 	add	x0, x0, #0x1
     a5c:	f9026a60 	str	x0, [x19, #1232]
  if(*cur == '"'){
     a60:	7100883f 	cmp	w1, #0x22
     a64:	54fffea1 	b.ne	a38 <next+0x16c>  // b.any
      if(i < (int)sizeof(literal)-1) literal[i++] = c;
     a68:	91138265 	add	x5, x19, #0x4e0
    for(i = 0; *cur && *cur != '"'; cur++){
     a6c:	52800002 	mov	w2, #0x0                   	// #0
     a70:	52800014 	mov	w20, #0x0                   	// #0
        else if(c == 't') c = '\t';
     a74:	52800124 	mov	w4, #0x9                   	// #9
    for(i = 0; *cur && *cur != '"'; cur++){
     a78:	39400001 	ldrb	w1, [x0]
     a7c:	7100883f 	cmp	w1, #0x22
     a80:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
     a84:	1a9f07e3 	cset	w3, ne	// ne = any
     a88:	54000501 	b.ne	b28 <next+0x25c>  // b.any
     a8c:	36000042 	tbz	w2, #0, a94 <next+0x1c8>
     a90:	f9026a60 	str	x0, [x19, #1232]
    if(*cur == '"') cur++;
     a94:	7100883f 	cmp	w1, #0x22
     a98:	54000761 	b.ne	b84 <next+0x2b8>  // b.any
     a9c:	91000400 	add	x0, x0, #0x1
     aa0:	f9026a60 	str	x0, [x19, #1232]
    literal[i] = 0;
     aa4:	91138273 	add	x19, x19, #0x4e0
    return;
     aa8:	52802061 	mov	w1, #0x103                 	// #259
    literal[i] = 0;
     aac:	38344a7f 	strb	wzr, [x19, w20, uxtw]
    return;
     ab0:	17ffffe2 	b	a38 <next+0x16c>
  return c >= '0' && c <= '9';
     ab4:	5100c080 	sub	w0, w4, #0x30
    for(i = 0; isalpha_(*cur) || isdigit_(*cur); cur++)
     ab8:	7100241f 	cmp	w0, #0x9
     abc:	54fffb48 	b.hi	a24 <next+0x158>  // b.pmore
      if(i < (int)sizeof(ident)-1) ident[i++] = *cur;
     ac0:	7100fc3f 	cmp	w1, #0x3f
     ac4:	54000060 	b.eq	ad0 <next+0x204>  // b.none
     ac8:	382148e4 	strb	w4, [x7, w1, uxtw]
     acc:	11000421 	add	w1, w1, #0x1
    for(i = 0; isalpha_(*cur) || isdigit_(*cur); cur++)
     ad0:	91000463 	add	x3, x3, #0x1
     ad4:	12000045 	and	w5, w2, #0x1
     ad8:	17ffffcc 	b	a08 <next+0x13c>
    while(isdigit_(*cur)) number = number * 10 + (*cur++ - '0');
     adc:	f9426a61 	ldr	x1, [x19, #1232]
     ae0:	d2800002 	mov	x2, #0x0                   	// #0
     ae4:	52800003 	mov	w3, #0x0                   	// #0
     ae8:	d2800144 	mov	x4, #0xa                   	// #10
     aec:	39400020 	ldrb	w0, [x1]
  return c >= '0' && c <= '9';
     af0:	5100c000 	sub	w0, w0, #0x30
    while(isdigit_(*cur)) number = number * 10 + (*cur++ - '0');
     af4:	7100241f 	cmp	w0, #0x9
     af8:	540000a9 	b.ls	b0c <next+0x240>  // b.plast
     afc:	35000103 	cbnz	w3, b1c <next+0x250>
    number = 0;
     b00:	f9026e7f 	str	xzr, [x19, #1240]
    return;
     b04:	52802041 	mov	w1, #0x102                 	// #258
     b08:	17ffffcc 	b	a38 <next+0x16c>
    while(isdigit_(*cur)) number = number * 10 + (*cur++ - '0');
     b0c:	9b040042 	madd	x2, x2, x4, x0
     b10:	91000421 	add	x1, x1, #0x1
     b14:	52800023 	mov	w3, #0x1                   	// #1
     b18:	17fffff5 	b	aec <next+0x220>
     b1c:	f9026a61 	str	x1, [x19, #1232]
     b20:	f9026e62 	str	x2, [x19, #1240]
     b24:	17fffff8 	b	b04 <next+0x238>
    for(i = 0; *cur && *cur != '"'; cur++){
     b28:	91000402 	add	x2, x0, #0x1
      if(c == '\\'){
     b2c:	7101703f 	cmp	w1, #0x5c
     b30:	540001e1 	b.ne	b6c <next+0x2a0>  // b.any
        c = *++cur;
     b34:	39400401 	ldrb	w1, [x0, #1]
        if(c == 'n') c = '\n';
     b38:	7101b83f 	cmp	w1, #0x6e
     b3c:	540001c0 	b.eq	b74 <next+0x2a8>  // b.none
        else if(c == 'r') c = '\r';
     b40:	7101c83f 	cmp	w1, #0x72
     b44:	540001c0 	b.eq	b7c <next+0x2b0>  // b.none
        else if(c == 't') c = '\t';
     b48:	7101d03f 	cmp	w1, #0x74
     b4c:	1a841021 	csel	w1, w1, w4, ne	// ne = any
      if(i < (int)sizeof(literal)-1) literal[i++] = c;
     b50:	7107fe9f 	cmp	w20, #0x1ff
     b54:	54000060 	b.eq	b60 <next+0x294>  // b.none
     b58:	383448a1 	strb	w1, [x5, w20, uxtw]
     b5c:	11000694 	add	w20, w20, #0x1
    for(i = 0; *cur && *cur != '"'; cur++){
     b60:	91000440 	add	x0, x2, #0x1
     b64:	2a0303e2 	mov	w2, w3
     b68:	17ffffc4 	b	a78 <next+0x1ac>
      if(c == '\\'){
     b6c:	aa0003e2 	mov	x2, x0
     b70:	17fffff8 	b	b50 <next+0x284>
        if(c == 'n') c = '\n';
     b74:	52800141 	mov	w1, #0xa                   	// #10
     b78:	17fffff6 	b	b50 <next+0x284>
        else if(c == 'r') c = '\r';
     b7c:	528001a1 	mov	w1, #0xd                   	// #13
     b80:	17fffff4 	b	b50 <next+0x284>
    else error("unterminated string");
     b84:	b0000000 	adrp	x0, 1000 <stat+0x48>
     b88:	91233c00 	add	x0, x0, #0x8cf
     b8c:	97fffefc 	bl	77c <error>
     b90:	17ffffc5 	b	aa4 <next+0x1d8>

0000000000000b94 <need>:
  if(tok != t) error(message);
     b94:	b0000002 	adrp	x2, 1000 <stat+0x48>
     b98:	b94af042 	ldr	w2, [x2, #2800]
     b9c:	6b00005f 	cmp	w2, w0
     ba0:	54000060 	b.eq	bac <need+0x18>  // b.none
     ba4:	aa0103e0 	mov	x0, x1
     ba8:	17fffef5 	b	77c <error>
  else next();
     bac:	17ffff48 	b	8cc <next>

0000000000000bb0 <expr>:
{
     bb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     bb4:	910003fd 	mov	x29, sp
     bb8:	a90153f3 	stp	x19, x20, [sp, #16]
    emit(op == '+' ? 0x8b000020U          // add x0, x1, x0
     bbc:	52800414 	mov	w20, #0x20                  	// #32
     bc0:	72b96014 	movk	w20, #0xcb00, lsl #16
  mul();
     bc4:	9400005d 	bl	d38 <mul>
  while(tok == '+' || tok == '-'){
     bc8:	b0000013 	adrp	x19, 1000 <stat+0x48>
     bcc:	b94af273 	ldr	w19, [x19, #2800]
     bd0:	528005a0 	mov	w0, #0x2d                  	// #45
     bd4:	7100ae7f 	cmp	w19, #0x2b
     bd8:	7a401264 	ccmp	w19, w0, #0x4, ne	// ne = any
     bdc:	54000080 	b.eq	bec <expr+0x3c>  // b.none
}
     be0:	a94153f3 	ldp	x19, x20, [sp, #16]
     be4:	a8c27bfd 	ldp	x29, x30, [sp], #32
     be8:	d65f03c0 	ret
    op = tok; next();
     bec:	97ffff38 	bl	8cc <next>
    emit(0xd10043ffU);
     bf0:	52887fe0 	mov	w0, #0x43ff                	// #17407
     bf4:	72ba2000 	movk	w0, #0xd100, lsl #16
     bf8:	97ffff0b 	bl	824 <emit>
    emit(0xf90003e0U);
     bfc:	52807c00 	mov	w0, #0x3e0                 	// #992
     c00:	72bf2000 	movk	w0, #0xf900, lsl #16
     c04:	97ffff08 	bl	824 <emit>
    mul();
     c08:	9400004c 	bl	d38 <mul>
    emit(0xf94003e1U);
     c0c:	52807c20 	mov	w0, #0x3e1                 	// #993
     c10:	72bf2800 	movk	w0, #0xf940, lsl #16
     c14:	97ffff04 	bl	824 <emit>
    emit(0x910043ffU);
     c18:	52887fe0 	mov	w0, #0x43ff                	// #17407
     c1c:	72b22000 	movk	w0, #0x9100, lsl #16
     c20:	97ffff01 	bl	824 <emit>
    emit(op == '+' ? 0x8b000020U          // add x0, x1, x0
     c24:	7100ae7f 	cmp	w19, #0x2b
     c28:	52800400 	mov	w0, #0x20                  	// #32
     c2c:	72b16000 	movk	w0, #0x8b00, lsl #16
     c30:	1a801280 	csel	w0, w20, w0, ne	// ne = any
     c34:	97fffefc 	bl	824 <emit>
     c38:	17ffffe4 	b	bc8 <expr+0x18>

0000000000000c3c <unary>:
{
     c3c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     c40:	910003fd 	mov	x29, sp
     c44:	a90153f3 	stp	x19, x20, [sp, #16]
  if(tok == '-'){
     c48:	b0000014 	adrp	x20, 1000 <stat+0x48>
     c4c:	b94af280 	ldr	w0, [x20, #2800]
     c50:	912bc293 	add	x19, x20, #0xaf0
     c54:	7100b41f 	cmp	w0, #0x2d
     c58:	54000101 	b.ne	c78 <unary+0x3c>  // b.any
    next(); unary();
     c5c:	97ffff1c 	bl	8cc <next>
     c60:	97fffff7 	bl	c3c <unary>
}
     c64:	a94153f3 	ldp	x19, x20, [sp, #16]
    emit(0xcb0003e0U);                    // sub x0, xzr, x0
     c68:	52807c00 	mov	w0, #0x3e0                 	// #992
     c6c:	72b96000 	movk	w0, #0xcb00, lsl #16
}
     c70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    emit(0xcb0003e0U);                    // sub x0, xzr, x0
     c74:	17fffeec 	b	824 <emit>
  } else if(tok == '+'){
     c78:	7100ac1f 	cmp	w0, #0x2b
     c7c:	54000061 	b.ne	c88 <unary+0x4c>  // b.any
    next(); unary();
     c80:	97ffff13 	bl	8cc <next>
     c84:	17fffff2 	b	c4c <unary+0x10>
  if(tok == T_NUM){
     c88:	7104081f 	cmp	w0, #0x102
     c8c:	540000e1 	b.ne	ca8 <unary+0x6c>  // b.any
    mov64(0, number);
     c90:	f9426e61 	ldr	x1, [x19, #1240]
     c94:	52800000 	mov	w0, #0x0                   	// #0
     c98:	97fffef1 	bl	85c <mov64>
}
     c9c:	a94153f3 	ldp	x19, x20, [sp, #16]
     ca0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    next();
     ca4:	17ffff0a 	b	8cc <next>
  } else if(tok == T_ID){
     ca8:	7104041f 	cmp	w0, #0x101
     cac:	54000281 	b.ne	cfc <unary+0xc0>  // b.any
    v = findvar(ident);
     cb0:	91001260 	add	x0, x19, #0x4
     cb4:	97fffe99 	bl	718 <findvar>
    if(v < 0) error("unknown variable");
     cb8:	3100041f 	cmn	w0, #0x1
     cbc:	540000a1 	b.ne	cd0 <unary+0x94>  // b.any
     cc0:	b0000000 	adrp	x0, 1000 <stat+0x48>
     cc4:	91238c00 	add	x0, x0, #0x8e3
     cc8:	97fffead 	bl	77c <error>
     ccc:	17fffff4 	b	c9c <unary+0x60>
    else emit(0xf9400000U | ((uint32)(vars[v].off / 8) << 10) | (29 << 5));
     cd0:	2a0003e0 	mov	w0, w0
     cd4:	d2800481 	mov	x1, #0x24                  	// #36
     cd8:	9b014c00 	madd	x0, x0, x1, x19
     cdc:	52800101 	mov	w1, #0x8                   	// #8
     ce0:	b9406400 	ldr	w0, [x0, #100]
     ce4:	1ac10c00 	sdiv	w0, w0, w1
     ce8:	52807401 	mov	w1, #0x3a0                 	// #928
     cec:	72bf2801 	movk	w1, #0xf940, lsl #16
     cf0:	2a002820 	orr	w0, w1, w0, lsl #10
     cf4:	97fffecc 	bl	824 <emit>
     cf8:	17ffffe9 	b	c9c <unary+0x60>
  } else if(tok == '('){
     cfc:	7100a01f 	cmp	w0, #0x28
     d00:	54000121 	b.ne	d24 <unary+0xe8>  // b.any
    next(); expr(); need(')', "expected ')'");
     d04:	97fffef2 	bl	8cc <next>
     d08:	97ffffaa 	bl	bb0 <expr>
}
     d0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    next(); expr(); need(')', "expected ')'");
     d10:	b0000001 	adrp	x1, 1000 <stat+0x48>
     d14:	9123d021 	add	x1, x1, #0x8f4
     d18:	52800520 	mov	w0, #0x29                  	// #41
}
     d1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    next(); expr(); need(')', "expected ')'");
     d20:	17ffff9d 	b	b94 <need>
}
     d24:	a94153f3 	ldp	x19, x20, [sp, #16]
    error("expected expression");
     d28:	b0000000 	adrp	x0, 1000 <stat+0x48>
     d2c:	91240400 	add	x0, x0, #0x901
}
     d30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    error("expected expression");
     d34:	17fffe92 	b	77c <error>

0000000000000d38 <mul>:
{
     d38:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     d3c:	910003fd 	mov	x29, sp
     d40:	a90153f3 	stp	x19, x20, [sp, #16]
    emit(op == '*' ? 0x9b007c20U          // mul x0, x1, x0
     d44:	52818414 	mov	w20, #0xc20                 	// #3104
     d48:	72b35814 	movk	w20, #0x9ac0, lsl #16
  unary();
     d4c:	97ffffbc 	bl	c3c <unary>
  while(tok == '*' || tok == '/'){
     d50:	b0000013 	adrp	x19, 1000 <stat+0x48>
     d54:	b94af273 	ldr	w19, [x19, #2800]
     d58:	528005e0 	mov	w0, #0x2f                  	// #47
     d5c:	7100aa7f 	cmp	w19, #0x2a
     d60:	7a401264 	ccmp	w19, w0, #0x4, ne	// ne = any
     d64:	54000080 	b.eq	d74 <mul+0x3c>  // b.none
}
     d68:	a94153f3 	ldp	x19, x20, [sp, #16]
     d6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
     d70:	d65f03c0 	ret
    op = tok; next();
     d74:	97fffed6 	bl	8cc <next>
    emit(0xd10043ffU);                    // sub sp, sp, #16
     d78:	52887fe0 	mov	w0, #0x43ff                	// #17407
     d7c:	72ba2000 	movk	w0, #0xd100, lsl #16
     d80:	97fffea9 	bl	824 <emit>
    emit(0xf90003e0U);                    // str x0, [sp]
     d84:	52807c00 	mov	w0, #0x3e0                 	// #992
     d88:	72bf2000 	movk	w0, #0xf900, lsl #16
     d8c:	97fffea6 	bl	824 <emit>
    unary();
     d90:	97ffffab 	bl	c3c <unary>
    emit(0xf94003e1U);                    // ldr x1, [sp]
     d94:	52807c20 	mov	w0, #0x3e1                 	// #993
     d98:	72bf2800 	movk	w0, #0xf940, lsl #16
     d9c:	97fffea2 	bl	824 <emit>
    emit(0x910043ffU);                    // add sp, sp, #16
     da0:	52887fe0 	mov	w0, #0x43ff                	// #17407
     da4:	72b22000 	movk	w0, #0x9100, lsl #16
     da8:	97fffe9f 	bl	824 <emit>
    emit(op == '*' ? 0x9b007c20U          // mul x0, x1, x0
     dac:	7100aa7f 	cmp	w19, #0x2a
     db0:	528f8400 	mov	w0, #0x7c20                	// #31776
     db4:	72b36000 	movk	w0, #0x9b00, lsl #16
     db8:	1a801280 	csel	w0, w20, w0, ne	// ne = any
     dbc:	97fffe9a 	bl	824 <emit>
     dc0:	17ffffe4 	b	d50 <mul+0x18>

0000000000000dc4 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     dc4:	d2800002 	mov	x2, #0x0                   	// #0
     dc8:	38626823 	ldrb	w3, [x1, x2]
     dcc:	38226803 	strb	w3, [x0, x2]
     dd0:	91000442 	add	x2, x2, #0x1
     dd4:	35ffffa3 	cbnz	w3, dc8 <strcpy+0x4>
    ;
  return os;
}
     dd8:	d65f03c0 	ret

0000000000000ddc <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
     ddc:	d2800003 	mov	x3, #0x0                   	// #0
     de0:	4b030044 	sub	w4, w2, w3
     de4:	7100009f 	cmp	w4, #0x0
     de8:	5400006d 	b.le	df4 <strncpy+0x18>
     dec:	38636825 	ldrb	w5, [x1, x3]
     df0:	350000e5 	cbnz	w5, e0c <strncpy+0x30>
     df4:	8b030003 	add	x3, x0, x3
     df8:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
     dfc:	4b010082 	sub	w2, w4, w1
     e00:	7100005f 	cmp	w2, #0x0
     e04:	540000ac 	b.gt	e18 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
     e08:	d65f03c0 	ret
    *s++ = *t++;
     e0c:	38236805 	strb	w5, [x0, x3]
    n--;
     e10:	91000463 	add	x3, x3, #0x1
     e14:	17fffff3 	b	de0 <strncpy+0x4>
    *s++ = 0;
     e18:	3821687f 	strb	wzr, [x3, x1]
     e1c:	91000421 	add	x1, x1, #0x1
     e20:	17fffff7 	b	dfc <strncpy+0x20>

0000000000000e24 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
     e24:	aa0003e2 	mov	x2, x0
     e28:	39400043 	ldrb	w3, [x2]
     e2c:	aa0203e4 	mov	x4, x2
    s++;
     e30:	91000442 	add	x2, x2, #0x1
  while(*s)
     e34:	35ffffa3 	cbnz	w3, e28 <strcat+0x4>
     e38:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
     e3c:	38626823 	ldrb	w3, [x1, x2]
     e40:	38226883 	strb	w3, [x4, x2]
     e44:	91000442 	add	x2, x2, #0x1
     e48:	35ffffa3 	cbnz	w3, e3c <strcat+0x18>
    ;
  return os;
}
     e4c:	d65f03c0 	ret

0000000000000e50 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
     e50:	d2800002 	mov	x2, #0x0                   	// #0
     e54:	38626803 	ldrb	w3, [x0, x2]
     e58:	38626824 	ldrb	w4, [x1, x2]
     e5c:	34000083 	cbz	w3, e6c <strcmp+0x1c>
     e60:	91000442 	add	x2, x2, #0x1
     e64:	6b04007f 	cmp	w3, w4
     e68:	54ffff60 	b.eq	e54 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
     e6c:	4b040060 	sub	w0, w3, w4
     e70:	d65f03c0 	ret

0000000000000e74 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
     e74:	340001c2 	cbz	w2, eac <strncmp+0x38>
     e78:	39400003 	ldrb	w3, [x0]
     e7c:	34000083 	cbz	w3, e8c <strncmp+0x18>
     e80:	39400024 	ldrb	w4, [x1]
     e84:	6b03009f 	cmp	w4, w3
     e88:	540000a0 	b.eq	e9c <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
     e8c:	39400000 	ldrb	w0, [x0]
     e90:	39400021 	ldrb	w1, [x1]
     e94:	4b010000 	sub	w0, w0, w1
}
     e98:	d65f03c0 	ret
    n--, p++, q++;
     e9c:	51000442 	sub	w2, w2, #0x1
     ea0:	91000400 	add	x0, x0, #0x1
     ea4:	91000421 	add	x1, x1, #0x1
     ea8:	17fffff3 	b	e74 <strncmp>
    return 0;
     eac:	52800000 	mov	w0, #0x0                   	// #0
     eb0:	17fffffa 	b	e98 <strncmp+0x24>

0000000000000eb4 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
     eb4:	d1000402 	sub	x2, x0, #0x1
     eb8:	d2800001 	mov	x1, #0x0                   	// #0
     ebc:	aa0103e0 	mov	x0, x1
     ec0:	91000421 	add	x1, x1, #0x1
     ec4:	38616843 	ldrb	w3, [x2, x1]
     ec8:	35ffffa3 	cbnz	w3, ebc <strlen+0x8>
    ;
  return n;
}
     ecc:	d65f03c0 	ret

0000000000000ed0 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
     ed0:	d1000403 	sub	x3, x0, #0x1
     ed4:	d2800002 	mov	x2, #0x0                   	// #0
     ed8:	2a0203e0 	mov	w0, w2
     edc:	6b02003f 	cmp	w1, w2
     ee0:	54000089 	b.ls	ef0 <strnlen+0x20>  // b.plast
     ee4:	91000442 	add	x2, x2, #0x1
     ee8:	38626864 	ldrb	w4, [x3, x2]
     eec:	35ffff64 	cbnz	w4, ed8 <strnlen+0x8>
    n++;
  return n;
}
     ef0:	d65f03c0 	ret

0000000000000ef4 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     ef4:	d2800003 	mov	x3, #0x0                   	// #0
     ef8:	6b03005f 	cmp	w2, w3
     efc:	54000048 	b.hi	f04 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
     f00:	d65f03c0 	ret
    cdst[i] = c;
     f04:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
     f08:	91000463 	add	x3, x3, #0x1
     f0c:	17fffffb 	b	ef8 <memset+0x4>

0000000000000f10 <strchr>:

char*
strchr(const char *s, char c)
{
     f10:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
     f14:	39400002 	ldrb	w2, [x0]
     f18:	35000062 	cbnz	w2, f24 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
     f1c:	d2800000 	mov	x0, #0x0                   	// #0
}
     f20:	d65f03c0 	ret
    if(*s == c)
     f24:	6b01005f 	cmp	w2, w1
     f28:	54ffffc0 	b.eq	f20 <strchr+0x10>  // b.none
  for(; *s; s++)
     f2c:	91000400 	add	x0, x0, #0x1
     f30:	17fffff9 	b	f14 <strchr+0x4>

0000000000000f34 <gets>:

char*
gets(char *buf, int max)
{
     f34:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     f38:	910003fd 	mov	x29, sp
     f3c:	a90153f3 	stp	x19, x20, [sp, #16]
     f40:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     f44:	d2800014 	mov	x20, #0x0                   	// #0
{
     f48:	f9001bf7 	str	x23, [sp, #48]
     f4c:	2a0103f7 	mov	w23, w1
     f50:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
     f54:	11000695 	add	w21, w20, #0x1
     f58:	2a1403f6 	mov	w22, w20
     f5c:	6b1702bf 	cmp	w21, w23
     f60:	540000ea 	b.ge	f7c <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
     f64:	91013fe1 	add	x1, sp, #0x4f
     f68:	52800022 	mov	w2, #0x1                   	// #1
     f6c:	52800000 	mov	w0, #0x0                   	// #0
     f70:	94000063 	bl	10fc <read>
    if(cc < 1)
     f74:	7100001f 	cmp	w0, #0x0
     f78:	5400012c 	b.gt	f9c <gets+0x68>
  for(i=0; i+1 < max; ){
     f7c:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
     f80:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
     f84:	aa1303e0 	mov	x0, x19
     f88:	f9401bf7 	ldr	x23, [sp, #48]
     f8c:	a94153f3 	ldp	x19, x20, [sp, #16]
     f90:	a9425bf5 	ldp	x21, x22, [sp, #32]
     f94:	a8c57bfd 	ldp	x29, x30, [sp], #80
     f98:	d65f03c0 	ret
    buf[i++] = c;
     f9c:	39413fe0 	ldrb	w0, [sp, #79]
     fa0:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
     fa4:	91000694 	add	x20, x20, #0x1
     fa8:	7100281f 	cmp	w0, #0xa
     fac:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
     fb0:	54fffd21 	b.ne	f54 <gets+0x20>  // b.any
     fb4:	17fffff3 	b	f80 <gets+0x4c>

0000000000000fb8 <stat>:

int
stat(const char *n, struct stat *st)
{
     fb8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     fbc:	910003fd 	mov	x29, sp
     fc0:	a90153f3 	stp	x19, x20, [sp, #16]
     fc4:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     fc8:	52800001 	mov	w1, #0x0                   	// #0
     fcc:	9400005b 	bl	1138 <open>
  if(fd < 0)
     fd0:	37f80160 	tbnz	w0, #31, ffc <stat+0x44>
    return -1;
  r = fstat(fd, st);
     fd4:	aa1303e1 	mov	x1, x19
     fd8:	2a0003f4 	mov	w20, w0
     fdc:	94000060 	bl	115c <fstat>
     fe0:	2a0003f3 	mov	w19, w0
  close(fd);
     fe4:	2a1403e0 	mov	w0, w20
     fe8:	9400004b 	bl	1114 <close>
  return r;
}
     fec:	2a1303e0 	mov	w0, w19
     ff0:	a94153f3 	ldp	x19, x20, [sp, #16]
     ff4:	a8c27bfd 	ldp	x29, x30, [sp], #32
     ff8:	d65f03c0 	ret
    return -1;
     ffc:	12800013 	mov	w19, #0xffffffff            	// #-1
    1000:	17fffffb 	b	fec <stat+0x34>

0000000000001004 <atoi>:

int
atoi(const char *s)
{
    1004:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
    1008:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
    100c:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
    1010:	39400043 	ldrb	w3, [x2]
    1014:	5100c061 	sub	w1, w3, #0x30
    1018:	12001c21 	and	w1, w1, #0xff
    101c:	7100243f 	cmp	w1, #0x9
    1020:	54000049 	b.ls	1028 <atoi+0x24>  // b.plast
  return n;
}
    1024:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
    1028:	1b040c01 	madd	w1, w0, w4, w3
    102c:	91000442 	add	x2, x2, #0x1
    1030:	5100c020 	sub	w0, w1, #0x30
    1034:	17fffff7 	b	1010 <atoi+0xc>

0000000000001038 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    1038:	eb01001f 	cmp	x0, x1
    103c:	54000263 	b.cc	1088 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
    1040:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
    1044:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
    1048:	d2800003 	mov	x3, #0x0                   	// #0
    104c:	d1000463 	sub	x3, x3, #0x1
    1050:	11000464 	add	w4, w3, #0x1
    1054:	0b020084 	add	w4, w4, w2
    1058:	7100009f 	cmp	w4, #0x0
    105c:	5400014d 	b.le	1084 <memmove+0x4c>
      *--dst = *--src;
    1060:	38636824 	ldrb	w4, [x1, x3]
    1064:	382368a4 	strb	w4, [x5, x3]
    1068:	17fffff9 	b	104c <memmove+0x14>
      *dst++ = *src++;
    106c:	38636824 	ldrb	w4, [x1, x3]
    1070:	38236804 	strb	w4, [x0, x3]
    1074:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
    1078:	4b030044 	sub	w4, w2, w3
    107c:	7100009f 	cmp	w4, #0x0
    1080:	54ffff6c 	b.gt	106c <memmove+0x34>
  }
  return vdst;
}
    1084:	d65f03c0 	ret
    1088:	d2800003 	mov	x3, #0x0                   	// #0
    108c:	17fffffb 	b	1078 <memmove+0x40>

0000000000001090 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    1090:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
    1094:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
    1098:	d2800004 	mov	x4, #0x0                   	// #0
    109c:	eb02009f 	cmp	x4, x2
    10a0:	54000061 	b.ne	10ac <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
    10a4:	52800000 	mov	w0, #0x0                   	// #0
    10a8:	14000007 	b	10c4 <memcmp+0x34>
    if (*p1 != *p2) {
    10ac:	38646803 	ldrb	w3, [x0, x4]
    10b0:	91000484 	add	x4, x4, #0x1
    10b4:	38646825 	ldrb	w5, [x1, x4]
    10b8:	6b05007f 	cmp	w3, w5
    10bc:	54ffff00 	b.eq	109c <memcmp+0xc>  // b.none
      return *p1 - *p2;
    10c0:	4b050060 	sub	w0, w3, w5
}
    10c4:	d65f03c0 	ret

00000000000010c8 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
    10c8:	17ffffdc 	b	1038 <memmove>

00000000000010cc <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
    10cc:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
    10d0:	d4000001 	svc	#0x0
 ret
    10d4:	d65f03c0 	ret

00000000000010d8 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
    10d8:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
    10dc:	d4000001 	svc	#0x0
 ret
    10e0:	d65f03c0 	ret

00000000000010e4 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
    10e4:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
    10e8:	d4000001 	svc	#0x0
 ret
    10ec:	d65f03c0 	ret

00000000000010f0 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
    10f0:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
    10f4:	d4000001 	svc	#0x0
 ret
    10f8:	d65f03c0 	ret

00000000000010fc <read>:
.global read
read:
 mov x7, #SYS_read
    10fc:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
    1100:	d4000001 	svc	#0x0
 ret
    1104:	d65f03c0 	ret

0000000000001108 <write>:
.global write
write:
 mov x7, #SYS_write
    1108:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
    110c:	d4000001 	svc	#0x0
 ret
    1110:	d65f03c0 	ret

0000000000001114 <close>:
.global close
close:
 mov x7, #SYS_close
    1114:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
    1118:	d4000001 	svc	#0x0
 ret
    111c:	d65f03c0 	ret

0000000000001120 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
    1120:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
    1124:	d4000001 	svc	#0x0
 ret
    1128:	d65f03c0 	ret

000000000000112c <exec>:
.global exec
exec:
 mov x7, #SYS_exec
    112c:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
    1130:	d4000001 	svc	#0x0
 ret
    1134:	d65f03c0 	ret

0000000000001138 <open>:
.global open
open:
 mov x7, #SYS_open
    1138:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
    113c:	d4000001 	svc	#0x0
 ret
    1140:	d65f03c0 	ret

0000000000001144 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
    1144:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
    1148:	d4000001 	svc	#0x0
 ret
    114c:	d65f03c0 	ret

0000000000001150 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
    1150:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
    1154:	d4000001 	svc	#0x0
 ret
    1158:	d65f03c0 	ret

000000000000115c <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
    115c:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
    1160:	d4000001 	svc	#0x0
 ret
    1164:	d65f03c0 	ret

0000000000001168 <link>:
.global link
link:
 mov x7, #SYS_link
    1168:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
    116c:	d4000001 	svc	#0x0
 ret
    1170:	d65f03c0 	ret

0000000000001174 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
    1174:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
    1178:	d4000001 	svc	#0x0
 ret
    117c:	d65f03c0 	ret

0000000000001180 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
    1180:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
    1184:	d4000001 	svc	#0x0
 ret
    1188:	d65f03c0 	ret

000000000000118c <dup>:
.global dup
dup:
 mov x7, #SYS_dup
    118c:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
    1190:	d4000001 	svc	#0x0
 ret
    1194:	d65f03c0 	ret

0000000000001198 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
    1198:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
    119c:	d4000001 	svc	#0x0
 ret
    11a0:	d65f03c0 	ret

00000000000011a4 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
    11a4:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
    11a8:	d4000001 	svc	#0x0
 ret
    11ac:	d65f03c0 	ret

00000000000011b0 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
    11b0:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
    11b4:	d4000001 	svc	#0x0
 ret
    11b8:	d65f03c0 	ret

00000000000011bc <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
    11bc:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
    11c0:	d4000001 	svc	#0x0
 ret
    11c4:	d65f03c0 	ret

00000000000011c8 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
    11c8:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
    11cc:	d4000001 	svc	#0x0
 ret
    11d0:	d65f03c0 	ret

00000000000011d4 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
    11d4:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
    11d8:	d4000001 	svc	#0x0
 ret
    11dc:	d65f03c0 	ret

00000000000011e0 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
    11e0:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
    11e4:	d4000001 	svc	#0x0
 ret
    11e8:	d65f03c0 	ret

00000000000011ec <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
    11ec:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
    11f0:	d4000001 	svc	#0x0
 ret
    11f4:	d65f03c0 	ret

00000000000011f8 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
    11f8:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
    11fc:	d4000001 	svc	#0x0
 ret
    1200:	d65f03c0 	ret

0000000000001204 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
    1204:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
    1208:	d4000001 	svc	#0x0
 ret
    120c:	d65f03c0 	ret

0000000000001210 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
    1210:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
    1214:	d4000001 	svc	#0x0
 ret
    1218:	d65f03c0 	ret

000000000000121c <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
    121c:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
    1220:	d4000001 	svc	#0x0
 ret
    1224:	d65f03c0 	ret

0000000000001228 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
    1228:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
    122c:	d4000001 	svc	#0x0
 ret
    1230:	d65f03c0 	ret

0000000000001234 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
    1234:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
    1238:	d4000001 	svc	#0x0
 ret
    123c:	d65f03c0 	ret

0000000000001240 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
    1240:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
    1244:	d4000001 	svc	#0x0
 ret
    1248:	d65f03c0 	ret

000000000000124c <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
    124c:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
    1250:	d4000001 	svc	#0x0
 ret
    1254:	d65f03c0 	ret

0000000000001258 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
    1258:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
    125c:	d4000001 	svc	#0x0
 ret
    1260:	d65f03c0 	ret

0000000000001264 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
    1264:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
    1268:	d4000001 	svc	#0x0
 ret
    126c:	d65f03c0 	ret

0000000000001270 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
    1270:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
    1274:	d4000001 	svc	#0x0
 ret
    1278:	d65f03c0 	ret

000000000000127c <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
    127c:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
    1280:	d4000001 	svc	#0x0
 ret
    1284:	d65f03c0 	ret

0000000000001288 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
    1288:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
    128c:	d4000001 	svc	#0x0
 ret
    1290:	d65f03c0 	ret

0000000000001294 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
    1294:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
    1298:	d4000001 	svc	#0x0
 ret
    129c:	d65f03c0 	ret

00000000000012a0 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
    12a0:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
    12a4:	d4000001 	svc	#0x0
 ret
    12a8:	d65f03c0 	ret

00000000000012ac <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
    12ac:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
    12b0:	d4000001 	svc	#0x0
 ret
    12b4:	d65f03c0 	ret

00000000000012b8 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
    12b8:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
    12bc:	d4000001 	svc	#0x0
 ret
    12c0:	d65f03c0 	ret

00000000000012c4 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
    12c4:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
    12c8:	d4000001 	svc	#0x0
 ret
    12cc:	d65f03c0 	ret

00000000000012d0 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
    12d0:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
    12d4:	d4000001 	svc	#0x0
 ret
    12d8:	d65f03c0 	ret

00000000000012dc <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
    12dc:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
    12e0:	d4000001 	svc	#0x0
 ret
    12e4:	d65f03c0 	ret

00000000000012e8 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
    12e8:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
    12ec:	d4000001 	svc	#0x0
 ret
    12f0:	d65f03c0 	ret

00000000000012f4 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
    12f4:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
    12f8:	d4000001 	svc	#0x0
 ret
    12fc:	d65f03c0 	ret

0000000000001300 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
    1300:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
    1304:	d4000001 	svc	#0x0
 ret
    1308:	d65f03c0 	ret

000000000000130c <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
    130c:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
    1310:	d4000001 	svc	#0x0
 ret
    1314:	d65f03c0 	ret

0000000000001318 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
    1318:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
    131c:	d4000001 	svc	#0x0
 ret
    1320:	d65f03c0 	ret

0000000000001324 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
    1324:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
    1328:	d4000001 	svc	#0x0
 ret
    132c:	d65f03c0 	ret

0000000000001330 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
    1330:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
    1334:	d4000001 	svc	#0x0
 ret
    1338:	d65f03c0 	ret

000000000000133c <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
    133c:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
    1340:	d4000001 	svc	#0x0
 ret
    1344:	d65f03c0 	ret

0000000000001348 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
    1348:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
    134c:	d4000001 	svc	#0x0
 ret
    1350:	d65f03c0 	ret

0000000000001354 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
    1354:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
    1358:	d4000001 	svc	#0x0
 ret
    135c:	d65f03c0 	ret

0000000000001360 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
    1360:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
    1364:	d4000001 	svc	#0x0
 ret
    1368:	d65f03c0 	ret

000000000000136c <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
    136c:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
    1370:	d4000001 	svc	#0x0
 ret
    1374:	d65f03c0 	ret

0000000000001378 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
    1378:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
    137c:	d4000001 	svc	#0x0
 ret
    1380:	d65f03c0 	ret

0000000000001384 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
    1384:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
    1388:	d4000001 	svc	#0x0
 ret
    138c:	d65f03c0 	ret

0000000000001390 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
    1390:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
    1394:	d4000001 	svc	#0x0
 ret
    1398:	d65f03c0 	ret

000000000000139c <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
    139c:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
    13a0:	d4000001 	svc	#0x0
 ret
    13a4:	d65f03c0 	ret

00000000000013a8 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
    13a8:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
    13ac:	d4000001 	svc	#0x0
 ret
    13b0:	d65f03c0 	ret

00000000000013b4 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
    13b4:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
    13b8:	d4000001 	svc	#0x0
 ret
    13bc:	d65f03c0 	ret

00000000000013c0 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
    13c0:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
    13c4:	d4000001 	svc	#0x0
 ret
    13c8:	d65f03c0 	ret

00000000000013cc <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
    13cc:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
    13d0:	d4000001 	svc	#0x0
 ret
    13d4:	d65f03c0 	ret

00000000000013d8 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
    13d8:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
    13dc:	d4000001 	svc	#0x0
 ret
    13e0:	d65f03c0 	ret

00000000000013e4 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
    13e4:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
    13e8:	d4000001 	svc	#0x0
 ret
    13ec:	d65f03c0 	ret

00000000000013f0 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
    13f0:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
    13f4:	d4000001 	svc	#0x0
 ret
    13f8:	d65f03c0 	ret

00000000000013fc <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
    13fc:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
    1400:	d4000001 	svc	#0x0
 ret
    1404:	d65f03c0 	ret

0000000000001408 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
    1408:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
    140c:	d4000001 	svc	#0x0
 ret
    1410:	d65f03c0 	ret

0000000000001414 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
    1414:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
    1418:	d4000001 	svc	#0x0
 ret
    141c:	d65f03c0 	ret

0000000000001420 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
    1420:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
    1424:	d4000001 	svc	#0x0
 ret
    1428:	d65f03c0 	ret

000000000000142c <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
    142c:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
    1430:	d4000001 	svc	#0x0
 ret
    1434:	d65f03c0 	ret

0000000000001438 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
    1438:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
    143c:	52800022 	mov	w2, #0x1                   	// #1
{
    1440:	910003fd 	mov	x29, sp
    1444:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
    1448:	91007fe1 	add	x1, sp, #0x1f
    144c:	97ffff2f 	bl	1108 <write>
    1450:	7100041f 	cmp	w0, #0x1
}
    1454:	1a9f17e0 	cset	w0, eq	// eq = none
    1458:	a8c27bfd 	ldp	x29, x30, [sp], #32
    145c:	d65f03c0 	ret

0000000000001460 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
    1460:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1464:	910003fd 	mov	x29, sp
    1468:	a90153f3 	stp	x19, x20, [sp, #16]
    146c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1470:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    1474:	6a417c7f 	tst	w3, w1, lsr #31
    1478:	54000300 	b.eq	14d8 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
    147c:	4b0103e1 	neg	w1, w1
    neg = 1;
    1480:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
    1484:	90000003 	adrp	x3, 1000 <stat+0x48>
    1488:	912b5863 	add	x3, x3, #0xad6
    148c:	9100c3f5 	add	x21, sp, #0x30
    1490:	d2800000 	mov	x0, #0x0                   	// #0
    1494:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
    1498:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
    149c:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
    14a0:	2a0403e1 	mov	w1, w4
    14a4:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
    14a8:	38666866 	ldrb	w6, [x3, x6]
    14ac:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
    14b0:	91000400 	add	x0, x0, #0x1
    14b4:	54ffff09 	b.ls	1494 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
    14b8:	11000493 	add	w19, w4, #0x1
  if(neg)
    14bc:	34000085 	cbz	w5, 14cc <printint+0x6c>
    buf[i++] = '-';
    14c0:	528005a0 	mov	w0, #0x2d                  	// #45
    14c4:	38334aa0 	strb	w0, [x21, w19, uxtw]
    14c8:	11000893 	add	w19, w4, #0x2
    14cc:	51000673 	sub	w19, w19, #0x1
    14d0:	52800014 	mov	w20, #0x0                   	// #0
    14d4:	14000008 	b	14f4 <printint+0x94>
  neg = 0;
    14d8:	52800005 	mov	w5, #0x0                   	// #0
    14dc:	17ffffea 	b	1484 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
    14e0:	38736aa1 	ldrb	w1, [x21, x19]
    14e4:	2a1603e0 	mov	w0, w22
    14e8:	d1000673 	sub	x19, x19, #0x1
    14ec:	97ffffd3 	bl	1438 <putc>
    14f0:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
    14f4:	3100067f 	cmn	w19, #0x1
    14f8:	54ffff41 	b.ne	14e0 <printint+0x80>  // b.any
  return written;
}
    14fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1500:	2a1403e0 	mov	w0, w20
    1504:	a94153f3 	ldp	x19, x20, [sp, #16]
    1508:	a8c47bfd 	ldp	x29, x30, [sp], #64
    150c:	d65f03c0 	ret

0000000000001510 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
    1510:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    1514:	910003fd 	mov	x29, sp
    1518:	a90153f3 	stp	x19, x20, [sp, #16]
    151c:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
    1520:	52800015 	mov	w21, #0x0                   	// #0
{
    1524:	a90363f7 	stp	x23, x24, [sp, #48]
    1528:	2a0003f7 	mov	w23, w0
    152c:	a9046bf9 	stp	x25, x26, [sp, #64]
    1530:	aa0103f9 	mov	x25, x1

  state = 0;
    1534:	52800001 	mov	w1, #0x0                   	// #0
{
    1538:	a90573fb 	stp	x27, x28, [sp, #80]
    153c:	a9406053 	ldp	x19, x24, [x2]
    1540:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
    1544:	39400320 	ldrb	w0, [x25]
    1548:	35000120 	cbnz	w0, 156c <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
    154c:	2a1503e0 	mov	w0, w21
    1550:	a94153f3 	ldp	x19, x20, [sp, #16]
    1554:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1558:	a94363f7 	ldp	x23, x24, [sp, #48]
    155c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    1560:	a94573fb 	ldp	x27, x28, [sp, #80]
    1564:	a8c67bfd 	ldp	x29, x30, [sp], #96
    1568:	d65f03c0 	ret
    c = fmt[i] & 0xff;
    156c:	2a0003f6 	mov	w22, w0
    if(state == 0){
    1570:	35000101 	cbnz	w1, 1590 <vprintf+0x80>
      if(c == '%'){
    1574:	7100941f 	cmp	w0, #0x25
    1578:	54000ba0 	b.eq	16ec <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
    157c:	2a1603e1 	mov	w1, w22
    1580:	2a1703e0 	mov	w0, w23
    1584:	97ffffad 	bl	1438 <putc>
    1588:	0b0002b5 	add	w21, w21, w0
    158c:	14000057 	b	16e8 <vprintf+0x1d8>
      if(c == 'd'){
    1590:	7101901f 	cmp	w0, #0x64
    1594:	540002a1 	b.ne	15e8 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
    1598:	37f80174 	tbnz	w20, #31, 15c4 <vprintf+0xb4>
    159c:	91002e76 	add	x22, x19, #0xb
    15a0:	2a1403fa 	mov	w26, w20
    15a4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    15a8:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    15ac:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
    15b0:	b9400261 	ldr	w1, [x19]
    15b4:	2a1703e0 	mov	w0, w23
    15b8:	97ffffaa 	bl	1460 <printint>
        written += putc(fd, va_arg(ap, uint));
    15bc:	0b0002b5 	add	w21, w21, w0
    15c0:	14000048 	b	16e0 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
    15c4:	1100229a 	add	w26, w20, #0x8
    15c8:	7100035f 	cmp	w26, #0x0
    15cc:	5400008d 	b.le	15dc <vprintf+0xcc>
    15d0:	91002e76 	add	x22, x19, #0xb
    15d4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    15d8:	17fffff4 	b	15a8 <vprintf+0x98>
    15dc:	aa1303f6 	mov	x22, x19
    15e0:	8b34c313 	add	x19, x24, w20, sxtw
    15e4:	17fffff1 	b	15a8 <vprintf+0x98>
      } else if(c == 'l') {
    15e8:	7101b01f 	cmp	w0, #0x6c
    15ec:	54000201 	b.ne	162c <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    15f0:	37f800d4 	tbnz	w20, #31, 1608 <vprintf+0xf8>
    15f4:	91003e76 	add	x22, x19, #0xf
    15f8:	2a1403fa 	mov	w26, w20
    15fc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1600:	52800003 	mov	w3, #0x0                   	// #0
    1604:	17ffffea 	b	15ac <vprintf+0x9c>
    1608:	1100229a 	add	w26, w20, #0x8
    160c:	7100035f 	cmp	w26, #0x0
    1610:	5400008d 	b.le	1620 <vprintf+0x110>
    1614:	91003e76 	add	x22, x19, #0xf
    1618:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    161c:	17fffff9 	b	1600 <vprintf+0xf0>
    1620:	aa1303f6 	mov	x22, x19
    1624:	8b34c313 	add	x19, x24, w20, sxtw
    1628:	17fffff6 	b	1600 <vprintf+0xf0>
      } else if(c == 'x') {
    162c:	7101e01f 	cmp	w0, #0x78
    1630:	54000221 	b.ne	1674 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
    1634:	37f800f4 	tbnz	w20, #31, 1650 <vprintf+0x140>
    1638:	91002e76 	add	x22, x19, #0xb
    163c:	2a1403fa 	mov	w26, w20
    1640:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1644:	52800003 	mov	w3, #0x0                   	// #0
    1648:	52800202 	mov	w2, #0x10                  	// #16
    164c:	17ffffd9 	b	15b0 <vprintf+0xa0>
    1650:	1100229a 	add	w26, w20, #0x8
    1654:	7100035f 	cmp	w26, #0x0
    1658:	5400008d 	b.le	1668 <vprintf+0x158>
    165c:	91002e76 	add	x22, x19, #0xb
    1660:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1664:	17fffff8 	b	1644 <vprintf+0x134>
    1668:	aa1303f6 	mov	x22, x19
    166c:	8b34c313 	add	x19, x24, w20, sxtw
    1670:	17fffff5 	b	1644 <vprintf+0x134>
      } else if(c == 'p') {
    1674:	7101c01f 	cmp	w0, #0x70
    1678:	54000521 	b.ne	171c <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    167c:	37f803f4 	tbnz	w20, #31, 16f8 <vprintf+0x1e8>
    1680:	91003e76 	add	x22, x19, #0xf
    1684:	2a1403fa 	mov	w26, w20
    1688:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    168c:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
    1690:	52800601 	mov	w1, #0x30                  	// #48
    1694:	2a1703e0 	mov	w0, w23
    1698:	97ffff68 	bl	1438 <putc>
    169c:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    16a0:	9000001c 	adrp	x28, 1000 <stat+0x48>
    16a4:	912b5b9c 	add	x28, x28, #0xad6
  written += putc(fd, 'x');
    16a8:	2a1703e0 	mov	w0, w23
    16ac:	52800f01 	mov	w1, #0x78                  	// #120
    16b0:	97ffff62 	bl	1438 <putc>
    16b4:	0b000273 	add	w19, w19, w0
    16b8:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    16bc:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    16c0:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    16c4:	38606b81 	ldrb	w1, [x28, x0]
    16c8:	2a1703e0 	mov	w0, w23
    16cc:	97ffff5b 	bl	1438 <putc>
    16d0:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    16d4:	71000694 	subs	w20, w20, #0x1
    16d8:	54ffff21 	b.ne	16bc <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    16dc:	0b1302b5 	add	w21, w21, w19
    16e0:	2a1a03f4 	mov	w20, w26
    16e4:	aa1603f3 	mov	x19, x22
      state = 0;
    16e8:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
    16ec:	91000739 	add	x25, x25, #0x1
  state = 0;
    16f0:	2a1603e1 	mov	w1, w22
    16f4:	17ffff94 	b	1544 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
    16f8:	1100229a 	add	w26, w20, #0x8
    16fc:	7100035f 	cmp	w26, #0x0
    1700:	5400008d 	b.le	1710 <vprintf+0x200>
    1704:	91003e76 	add	x22, x19, #0xf
    1708:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    170c:	17ffffe0 	b	168c <vprintf+0x17c>
    1710:	aa1303f6 	mov	x22, x19
    1714:	8b34c313 	add	x19, x24, w20, sxtw
    1718:	17ffffdd 	b	168c <vprintf+0x17c>
      } else if(c == 's'){
    171c:	7101cc1f 	cmp	w0, #0x73
    1720:	54000381 	b.ne	1790 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
    1724:	37f80214 	tbnz	w20, #31, 1764 <vprintf+0x254>
    1728:	91003e61 	add	x1, x19, #0xf
    172c:	aa1303e0 	mov	x0, x19
    1730:	927df033 	and	x19, x1, #0xfffffffffffffff8
    1734:	f9400016 	ldr	x22, [x0]
          s = "(null)";
    1738:	90000000 	adrp	x0, 1000 <stat+0x48>
    173c:	912b3c00 	add	x0, x0, #0xacf
    1740:	f10002df 	cmp	x22, #0x0
    1744:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
    1748:	394002c1 	ldrb	w1, [x22]
    174c:	34fffce1 	cbz	w1, 16e8 <vprintf+0x1d8>
          written += putc(fd, *s);
    1750:	2a1703e0 	mov	w0, w23
          s++;
    1754:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
    1758:	97ffff38 	bl	1438 <putc>
    175c:	0b0002b5 	add	w21, w21, w0
          s++;
    1760:	17fffffa 	b	1748 <vprintf+0x238>
        s = va_arg(ap, char*);
    1764:	11002281 	add	w1, w20, #0x8
    1768:	7100003f 	cmp	w1, #0x0
    176c:	540000cd 	b.le	1784 <vprintf+0x274>
    1770:	91003e62 	add	x2, x19, #0xf
    1774:	aa1303e0 	mov	x0, x19
    1778:	2a0103f4 	mov	w20, w1
    177c:	927df053 	and	x19, x2, #0xfffffffffffffff8
    1780:	17ffffed 	b	1734 <vprintf+0x224>
    1784:	8b34c300 	add	x0, x24, w20, sxtw
    1788:	2a0103f4 	mov	w20, w1
    178c:	17ffffea 	b	1734 <vprintf+0x224>
      } else if(c == 'c'){
    1790:	71018c1f 	cmp	w0, #0x63
    1794:	54000241 	b.ne	17dc <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
    1798:	37f80114 	tbnz	w20, #31, 17b8 <vprintf+0x2a8>
    179c:	91002e76 	add	x22, x19, #0xb
    17a0:	2a1403fa 	mov	w26, w20
    17a4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    17a8:	39400261 	ldrb	w1, [x19]
    17ac:	2a1703e0 	mov	w0, w23
    17b0:	97ffff22 	bl	1438 <putc>
    17b4:	17ffff82 	b	15bc <vprintf+0xac>
    17b8:	1100229a 	add	w26, w20, #0x8
    17bc:	7100035f 	cmp	w26, #0x0
    17c0:	5400008d 	b.le	17d0 <vprintf+0x2c0>
    17c4:	91002e76 	add	x22, x19, #0xb
    17c8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    17cc:	17fffff7 	b	17a8 <vprintf+0x298>
    17d0:	aa1303f6 	mov	x22, x19
    17d4:	8b34c313 	add	x19, x24, w20, sxtw
    17d8:	17fffff4 	b	17a8 <vprintf+0x298>
      } else if(c == '%'){
    17dc:	7100941f 	cmp	w0, #0x25
    17e0:	54ffece0 	b.eq	157c <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
    17e4:	2a1703e0 	mov	w0, w23
    17e8:	528004a1 	mov	w1, #0x25                  	// #37
    17ec:	97ffff13 	bl	1438 <putc>
    17f0:	0b0002b5 	add	w21, w21, w0
    17f4:	17ffff62 	b	157c <vprintf+0x6c>

00000000000017f8 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
    17f8:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    17fc:	910003fd 	mov	x29, sp
    1800:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
    1804:	910203e2 	add	x2, sp, #0x80
    1808:	a9030be2 	stp	x2, x2, [sp, #48]
    180c:	910143e2 	add	x2, sp, #0x50
    1810:	f90023e2 	str	x2, [sp, #64]
    1814:	128005e2 	mov	w2, #0xffffffd0            	// #-48
    1818:	b9004be2 	str	w2, [sp, #72]
    181c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
    1820:	a9430fe2 	ldp	x2, x3, [sp, #48]
    1824:	a9010fe2 	stp	x2, x3, [sp, #16]
    1828:	a9440fe2 	ldp	x2, x3, [sp, #64]
    182c:	a9020fe2 	stp	x2, x3, [sp, #32]
    1830:	910043e2 	add	x2, sp, #0x10
{
    1834:	a90617e4 	stp	x4, x5, [sp, #96]
    1838:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
    183c:	97ffff35 	bl	1510 <vprintf>
  va_end(ap);
  return result;
}
    1840:	a8c87bfd 	ldp	x29, x30, [sp], #128
    1844:	d65f03c0 	ret

0000000000001848 <printf>:

int
printf(const char *fmt, ...)
{
    1848:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    184c:	910003fd 	mov	x29, sp
    1850:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
    1854:	910243e1 	add	x1, sp, #0x90
    1858:	a90307e1 	stp	x1, x1, [sp, #48]
    185c:	910143e1 	add	x1, sp, #0x50
    1860:	f90023e1 	str	x1, [sp, #64]
    1864:	128006e1 	mov	w1, #0xffffffc8            	// #-56
    1868:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
    186c:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
    1870:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
    1874:	52800020 	mov	w0, #0x1                   	// #1
{
    1878:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
    187c:	a9430fe2 	ldp	x2, x3, [sp, #48]
    1880:	a9010fe2 	stp	x2, x3, [sp, #16]
    1884:	a9440fe2 	ldp	x2, x3, [sp, #64]
    1888:	a9020fe2 	stp	x2, x3, [sp, #32]
    188c:	910043e2 	add	x2, sp, #0x10
{
    1890:	a9079be5 	stp	x5, x6, [sp, #120]
    1894:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
    1898:	97ffff1e 	bl	1510 <vprintf>
  va_end(ap);
  return result;
}
    189c:	a8c97bfd 	ldp	x29, x30, [sp], #144
    18a0:	d65f03c0 	ret
