
user/_syncdemo:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
#include "user/user.h"
#include "user/sync.h"

int
main(void)
{
   0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
static inline int mutex_init(mutex_t *m) { return (*m = sync_create(SYNC_MUTEX, 1)) < 0 ? -1 : 0; }
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
static inline int mutex_destroy(mutex_t *m) { return sync_destroy(*m); }

static inline int sem_init(semaphore_t *s, int value) { return (*s = sync_create(SYNC_SEM, value)) < 0 ? -1 : 0; }
   4:	52800001 	mov	w1, #0x0                   	// #0
   8:	52800040 	mov	w0, #0x2                   	// #2
   c:	910003fd 	mov	x29, sp
  10:	a90153f3 	stp	x19, x20, [sp, #16]
  14:	a9025bf5 	stp	x21, x22, [sp, #32]
  18:	94000096 	bl	270 <sync_create>
  1c:	36f800c0 	tbz	w0, #31, 34 <main+0x34>
  katomic_t counter;
  int i, pid;

  if(sem_init(&done, 0) < 0 || event_init(&start, 0) < 0 ||
     katomic_init(&counter, 0) < 0){
    printf("syncdemo: create failed\n");
  20:	90000000 	adrp	x0, 0 <main>
  24:	9124a000 	add	x0, x0, #0x928
      katomic_fetch_add(&counter, 1);
      sem_post(&done);
      exit(0);
    }
    if(pid < 0){
      printf("syncdemo: fork failed\n");
  28:	94000229 	bl	8cc <printf>
      exit(1);
  2c:	52800020 	mov	w0, #0x1                   	// #1
  30:	1400001a 	b	98 <main+0x98>
  34:	2a0003f3 	mov	w19, w0
static inline int sem_post(semaphore_t *s) { return sync_signal(*s, 1); }
static inline int sem_post_n(semaphore_t *s, int n) { return sync_signal(*s, n); }
static inline int sem_destroy(semaphore_t *s) { return sync_destroy(*s); }

// Manual-reset event: notify wakes all present/future waiters until reset.
static inline int event_init(event_t *e, int signaled) { return (*e = sync_create(SYNC_EVENT, signaled)) < 0 ? -1 : 0; }
  38:	52800001 	mov	w1, #0x0                   	// #0
  3c:	52800060 	mov	w0, #0x3                   	// #3
  40:	9400008c 	bl	270 <sync_create>
  44:	2a0003f4 	mov	w20, w0
  48:	37fffec0 	tbnz	w0, #31, 20 <main+0x20>
static inline int event_notify(event_t *e) { return sync_signal(*e, 1); }
static inline int event_signal(event_t *e) { return sync_signal(*e, 1); }
static inline int event_reset(event_t *e) { return sync_reset(*e); }
static inline int event_destroy(event_t *e) { return sync_destroy(*e); }

static inline int katomic_init(katomic_t *a, int value) { return (*a = sync_create(SYNC_ATOMIC, value)) < 0 ? -1 : 0; }
  4c:	52800001 	mov	w1, #0x0                   	// #0
  50:	52800080 	mov	w0, #0x4                   	// #4
  54:	94000087 	bl	270 <sync_create>
  58:	2a0003f5 	mov	w21, w0
  5c:	37fffe20 	tbnz	w0, #31, 20 <main+0x20>
  60:	52800076 	mov	w22, #0x3                   	// #3
    pid = fork();
  64:	9400003b 	bl	150 <fork>
    if(pid == 0){
  68:	350001a0 	cbnz	w0, 9c <main+0x9c>
static inline int sem_wait(semaphore_t *s) { return sync_wait(*s); }
  6c:	2a1403e0 	mov	w0, w20
  70:	94000083 	bl	27c <sync_wait>
static inline int katomic_load(katomic_t *a) { return sync_atomic(*a, ATOMIC_LOAD, 0, 0); }
static inline int katomic_store(katomic_t *a, int value) { return sync_atomic(*a, ATOMIC_STORE, value, 0); }
static inline int katomic_fetch_add(katomic_t *a, int value) { return sync_atomic(*a, ATOMIC_FETCH_ADD, value, 0); }
  74:	52800003 	mov	w3, #0x0                   	// #0
  78:	52800022 	mov	w2, #0x1                   	// #1
  7c:	52800061 	mov	w1, #0x3                   	// #3
  80:	2a1503e0 	mov	w0, w21
  84:	94000087 	bl	2a0 <sync_atomic>
static inline int sem_post(semaphore_t *s) { return sync_signal(*s, 1); }
  88:	2a1303e0 	mov	w0, w19
  8c:	52800021 	mov	w1, #0x1                   	// #1
  90:	9400007e 	bl	288 <sync_signal>
      exit(0);
  94:	52800000 	mov	w0, #0x0                   	// #0
  98:	94000031 	bl	15c <exit>
    if(pid < 0){
  9c:	36f80080 	tbz	w0, #31, ac <main+0xac>
      printf("syncdemo: fork failed\n");
  a0:	90000000 	adrp	x0, 0 <main>
  a4:	91250400 	add	x0, x0, #0x941
  a8:	17ffffe0 	b	28 <main+0x28>
  for(i = 0; i < 3; i++){
  ac:	710006d6 	subs	w22, w22, #0x1
  b0:	54fffda1 	b.ne	64 <main+0x64>  // b.any
    }
  }

  printf("syncdemo: notify children\n");
  b4:	90000000 	adrp	x0, 0 <main>
  b8:	91256000 	add	x0, x0, #0x958
  bc:	94000204 	bl	8cc <printf>
  c0:	52800021 	mov	w1, #0x1                   	// #1
  c4:	2a1403e0 	mov	w0, w20
  c8:	94000070 	bl	288 <sync_signal>
static inline int sem_wait(semaphore_t *s) { return sync_wait(*s); }
  cc:	2a1303e0 	mov	w0, w19
  d0:	9400006b 	bl	27c <sync_wait>
  d4:	2a1303e0 	mov	w0, w19
  d8:	94000069 	bl	27c <sync_wait>
  dc:	2a1303e0 	mov	w0, w19
  e0:	94000067 	bl	27c <sync_wait>
static inline int katomic_load(katomic_t *a) { return sync_atomic(*a, ATOMIC_LOAD, 0, 0); }
  e4:	52800021 	mov	w1, #0x1                   	// #1
  e8:	52800003 	mov	w3, #0x0                   	// #0
  ec:	52800002 	mov	w2, #0x0                   	// #0
  f0:	2a1503e0 	mov	w0, w21
  f4:	9400006b 	bl	2a0 <sync_atomic>
  f8:	2a0003e1 	mov	w1, w0
  event_notify(&start);
  for(i = 0; i < 3; i++)
    sem_wait(&done);
  printf("syncdemo: atomic counter=%d (expected 3)\n",
  fc:	90000000 	adrp	x0, 0 <main>
 100:	9125cc00 	add	x0, x0, #0x973
 104:	940001f2 	bl	8cc <printf>
         katomic_load(&counter));
  for(i = 0; i < 3; i++)
    wait(0);
 108:	d2800000 	mov	x0, #0x0                   	// #0
 10c:	94000017 	bl	168 <wait>
 110:	d2800000 	mov	x0, #0x0                   	// #0
 114:	94000015 	bl	168 <wait>
 118:	d2800000 	mov	x0, #0x0                   	// #0
 11c:	94000013 	bl	168 <wait>
static inline int event_reset(event_t *e) { return sync_reset(*e); }
 120:	2a1403e0 	mov	w0, w20
 124:	9400005c 	bl	294 <sync_reset>
static inline int sem_destroy(semaphore_t *s) { return sync_destroy(*s); }
 128:	2a1403e0 	mov	w0, w20
 12c:	94000060 	bl	2ac <sync_destroy>
 130:	2a1303e0 	mov	w0, w19
 134:	9400005e 	bl	2ac <sync_destroy>
 138:	2a1503e0 	mov	w0, w21
 13c:	9400005c 	bl	2ac <sync_destroy>

  event_reset(&start);
  event_destroy(&start);
  sem_destroy(&done);
  katomic_destroy(&counter);
  printf("syncdemo: ok\n");
 140:	90000000 	adrp	x0, 0 <main>
 144:	91267400 	add	x0, x0, #0x99d
 148:	940001e1 	bl	8cc <printf>
  exit(0);
 14c:	17ffffd2 	b	94 <main+0x94>

0000000000000150 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 150:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 154:	d4000001 	svc	#0x0
 ret
 158:	d65f03c0 	ret

000000000000015c <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 15c:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 160:	d4000001 	svc	#0x0
 ret
 164:	d65f03c0 	ret

0000000000000168 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 168:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 16c:	d4000001 	svc	#0x0
 ret
 170:	d65f03c0 	ret

0000000000000174 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 174:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 178:	d4000001 	svc	#0x0
 ret
 17c:	d65f03c0 	ret

0000000000000180 <read>:
.global read
read:
 mov x7, #SYS_read
 180:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 184:	d4000001 	svc	#0x0
 ret
 188:	d65f03c0 	ret

000000000000018c <write>:
.global write
write:
 mov x7, #SYS_write
 18c:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 190:	d4000001 	svc	#0x0
 ret
 194:	d65f03c0 	ret

0000000000000198 <close>:
.global close
close:
 mov x7, #SYS_close
 198:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 19c:	d4000001 	svc	#0x0
 ret
 1a0:	d65f03c0 	ret

00000000000001a4 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 1a4:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 1a8:	d4000001 	svc	#0x0
 ret
 1ac:	d65f03c0 	ret

00000000000001b0 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 1b0:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 1b4:	d4000001 	svc	#0x0
 ret
 1b8:	d65f03c0 	ret

00000000000001bc <open>:
.global open
open:
 mov x7, #SYS_open
 1bc:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 1c0:	d4000001 	svc	#0x0
 ret
 1c4:	d65f03c0 	ret

00000000000001c8 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 1c8:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 1cc:	d4000001 	svc	#0x0
 ret
 1d0:	d65f03c0 	ret

00000000000001d4 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 1d4:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 1d8:	d4000001 	svc	#0x0
 ret
 1dc:	d65f03c0 	ret

00000000000001e0 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 1e0:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 1e4:	d4000001 	svc	#0x0
 ret
 1e8:	d65f03c0 	ret

00000000000001ec <link>:
.global link
link:
 mov x7, #SYS_link
 1ec:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 1f0:	d4000001 	svc	#0x0
 ret
 1f4:	d65f03c0 	ret

00000000000001f8 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 1f8:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 1fc:	d4000001 	svc	#0x0
 ret
 200:	d65f03c0 	ret

0000000000000204 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 204:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 208:	d4000001 	svc	#0x0
 ret
 20c:	d65f03c0 	ret

0000000000000210 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 210:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 214:	d4000001 	svc	#0x0
 ret
 218:	d65f03c0 	ret

000000000000021c <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 21c:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 220:	d4000001 	svc	#0x0
 ret
 224:	d65f03c0 	ret

0000000000000228 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 228:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 22c:	d4000001 	svc	#0x0
 ret
 230:	d65f03c0 	ret

0000000000000234 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 234:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 238:	d4000001 	svc	#0x0
 ret
 23c:	d65f03c0 	ret

0000000000000240 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 240:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 244:	d4000001 	svc	#0x0
 ret
 248:	d65f03c0 	ret

000000000000024c <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 24c:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 250:	d4000001 	svc	#0x0
 ret
 254:	d65f03c0 	ret

0000000000000258 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 258:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 25c:	d4000001 	svc	#0x0
 ret
 260:	d65f03c0 	ret

0000000000000264 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 264:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 268:	d4000001 	svc	#0x0
 ret
 26c:	d65f03c0 	ret

0000000000000270 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 270:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 274:	d4000001 	svc	#0x0
 ret
 278:	d65f03c0 	ret

000000000000027c <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 27c:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 280:	d4000001 	svc	#0x0
 ret
 284:	d65f03c0 	ret

0000000000000288 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 288:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 28c:	d4000001 	svc	#0x0
 ret
 290:	d65f03c0 	ret

0000000000000294 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 294:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 298:	d4000001 	svc	#0x0
 ret
 29c:	d65f03c0 	ret

00000000000002a0 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 2a0:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 2a4:	d4000001 	svc	#0x0
 ret
 2a8:	d65f03c0 	ret

00000000000002ac <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 2ac:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 2b0:	d4000001 	svc	#0x0
 ret
 2b4:	d65f03c0 	ret

00000000000002b8 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 2b8:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 2bc:	d4000001 	svc	#0x0
 ret
 2c0:	d65f03c0 	ret

00000000000002c4 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 2c4:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 2c8:	d4000001 	svc	#0x0
 ret
 2cc:	d65f03c0 	ret

00000000000002d0 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 2d0:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 2d4:	d4000001 	svc	#0x0
 ret
 2d8:	d65f03c0 	ret

00000000000002dc <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 2dc:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 2e0:	d4000001 	svc	#0x0
 ret
 2e4:	d65f03c0 	ret

00000000000002e8 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 2e8:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 2ec:	d4000001 	svc	#0x0
 ret
 2f0:	d65f03c0 	ret

00000000000002f4 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 2f4:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 2f8:	d4000001 	svc	#0x0
 ret
 2fc:	d65f03c0 	ret

0000000000000300 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 300:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 304:	d4000001 	svc	#0x0
 ret
 308:	d65f03c0 	ret

000000000000030c <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 30c:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 310:	d4000001 	svc	#0x0
 ret
 314:	d65f03c0 	ret

0000000000000318 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 318:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 31c:	d4000001 	svc	#0x0
 ret
 320:	d65f03c0 	ret

0000000000000324 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 324:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 328:	d4000001 	svc	#0x0
 ret
 32c:	d65f03c0 	ret

0000000000000330 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 330:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 334:	d4000001 	svc	#0x0
 ret
 338:	d65f03c0 	ret

000000000000033c <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 33c:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 340:	d4000001 	svc	#0x0
 ret
 344:	d65f03c0 	ret

0000000000000348 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 348:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 34c:	d4000001 	svc	#0x0
 ret
 350:	d65f03c0 	ret

0000000000000354 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 354:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 358:	d4000001 	svc	#0x0
 ret
 35c:	d65f03c0 	ret

0000000000000360 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 360:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 364:	d4000001 	svc	#0x0
 ret
 368:	d65f03c0 	ret

000000000000036c <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 36c:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 370:	d4000001 	svc	#0x0
 ret
 374:	d65f03c0 	ret

0000000000000378 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 378:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 37c:	d4000001 	svc	#0x0
 ret
 380:	d65f03c0 	ret

0000000000000384 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 384:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 388:	d4000001 	svc	#0x0
 ret
 38c:	d65f03c0 	ret

0000000000000390 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 390:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 394:	d4000001 	svc	#0x0
 ret
 398:	d65f03c0 	ret

000000000000039c <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 39c:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 3a0:	d4000001 	svc	#0x0
 ret
 3a4:	d65f03c0 	ret

00000000000003a8 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 3a8:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 3ac:	d4000001 	svc	#0x0
 ret
 3b0:	d65f03c0 	ret

00000000000003b4 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 3b4:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 3b8:	d4000001 	svc	#0x0
 ret
 3bc:	d65f03c0 	ret

00000000000003c0 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 3c0:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 3c4:	d4000001 	svc	#0x0
 ret
 3c8:	d65f03c0 	ret

00000000000003cc <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 3cc:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 3d0:	d4000001 	svc	#0x0
 ret
 3d4:	d65f03c0 	ret

00000000000003d8 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 3d8:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 3dc:	d4000001 	svc	#0x0
 ret
 3e0:	d65f03c0 	ret

00000000000003e4 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 3e4:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 3e8:	d4000001 	svc	#0x0
 ret
 3ec:	d65f03c0 	ret

00000000000003f0 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 3f0:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 3f4:	d4000001 	svc	#0x0
 ret
 3f8:	d65f03c0 	ret

00000000000003fc <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 3fc:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 400:	d4000001 	svc	#0x0
 ret
 404:	d65f03c0 	ret

0000000000000408 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 408:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 40c:	d4000001 	svc	#0x0
 ret
 410:	d65f03c0 	ret

0000000000000414 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 414:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 418:	d4000001 	svc	#0x0
 ret
 41c:	d65f03c0 	ret

0000000000000420 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 420:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 424:	d4000001 	svc	#0x0
 ret
 428:	d65f03c0 	ret

000000000000042c <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 42c:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 430:	d4000001 	svc	#0x0
 ret
 434:	d65f03c0 	ret

0000000000000438 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 438:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 43c:	d4000001 	svc	#0x0
 ret
 440:	d65f03c0 	ret

0000000000000444 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 444:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 448:	d4000001 	svc	#0x0
 ret
 44c:	d65f03c0 	ret

0000000000000450 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 450:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 454:	d4000001 	svc	#0x0
 ret
 458:	d65f03c0 	ret

000000000000045c <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 45c:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 460:	d4000001 	svc	#0x0
 ret
 464:	d65f03c0 	ret

0000000000000468 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 468:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 46c:	d4000001 	svc	#0x0
 ret
 470:	d65f03c0 	ret

0000000000000474 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 474:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 478:	d4000001 	svc	#0x0
 ret
 47c:	d65f03c0 	ret

0000000000000480 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 480:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 484:	d4000001 	svc	#0x0
 ret
 488:	d65f03c0 	ret

000000000000048c <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 48c:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 490:	d4000001 	svc	#0x0
 ret
 494:	d65f03c0 	ret

0000000000000498 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 498:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 49c:	d4000001 	svc	#0x0
 ret
 4a0:	d65f03c0 	ret

00000000000004a4 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 4a4:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 4a8:	d4000001 	svc	#0x0
 ret
 4ac:	d65f03c0 	ret

00000000000004b0 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 4b0:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 4b4:	d4000001 	svc	#0x0
 ret
 4b8:	d65f03c0 	ret

00000000000004bc <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 4bc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 4c0:	52800022 	mov	w2, #0x1                   	// #1
{
 4c4:	910003fd 	mov	x29, sp
 4c8:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 4cc:	91007fe1 	add	x1, sp, #0x1f
 4d0:	97ffff2f 	bl	18c <write>
 4d4:	7100041f 	cmp	w0, #0x1
}
 4d8:	1a9f17e0 	cset	w0, eq	// eq = none
 4dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
 4e0:	d65f03c0 	ret

00000000000004e4 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 4e4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 4e8:	910003fd 	mov	x29, sp
 4ec:	a90153f3 	stp	x19, x20, [sp, #16]
 4f0:	a9025bf5 	stp	x21, x22, [sp, #32]
 4f4:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4f8:	6a417c7f 	tst	w3, w1, lsr #31
 4fc:	54000300 	b.eq	55c <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 500:	4b0103e1 	neg	w1, w1
    neg = 1;
 504:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 508:	90000003 	adrp	x3, 0 <main>
 50c:	9126c863 	add	x3, x3, #0x9b2
 510:	9100c3f5 	add	x21, sp, #0x30
 514:	d2800000 	mov	x0, #0x0                   	// #0
 518:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 51c:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 520:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 524:	2a0403e1 	mov	w1, w4
 528:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 52c:	38666866 	ldrb	w6, [x3, x6]
 530:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 534:	91000400 	add	x0, x0, #0x1
 538:	54ffff09 	b.ls	518 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 53c:	11000493 	add	w19, w4, #0x1
  if(neg)
 540:	34000085 	cbz	w5, 550 <printint+0x6c>
    buf[i++] = '-';
 544:	528005a0 	mov	w0, #0x2d                  	// #45
 548:	38334aa0 	strb	w0, [x21, w19, uxtw]
 54c:	11000893 	add	w19, w4, #0x2
 550:	51000673 	sub	w19, w19, #0x1
 554:	52800014 	mov	w20, #0x0                   	// #0
 558:	14000008 	b	578 <printint+0x94>
  neg = 0;
 55c:	52800005 	mov	w5, #0x0                   	// #0
 560:	17ffffea 	b	508 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 564:	38736aa1 	ldrb	w1, [x21, x19]
 568:	2a1603e0 	mov	w0, w22
 56c:	d1000673 	sub	x19, x19, #0x1
 570:	97ffffd3 	bl	4bc <putc>
 574:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 578:	3100067f 	cmn	w19, #0x1
 57c:	54ffff41 	b.ne	564 <printint+0x80>  // b.any
  return written;
}
 580:	a9425bf5 	ldp	x21, x22, [sp, #32]
 584:	2a1403e0 	mov	w0, w20
 588:	a94153f3 	ldp	x19, x20, [sp, #16]
 58c:	a8c47bfd 	ldp	x29, x30, [sp], #64
 590:	d65f03c0 	ret

0000000000000594 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 594:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 598:	910003fd 	mov	x29, sp
 59c:	a90153f3 	stp	x19, x20, [sp, #16]
 5a0:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 5a4:	52800015 	mov	w21, #0x0                   	// #0
{
 5a8:	a90363f7 	stp	x23, x24, [sp, #48]
 5ac:	2a0003f7 	mov	w23, w0
 5b0:	a9046bf9 	stp	x25, x26, [sp, #64]
 5b4:	aa0103f9 	mov	x25, x1

  state = 0;
 5b8:	52800001 	mov	w1, #0x0                   	// #0
{
 5bc:	a90573fb 	stp	x27, x28, [sp, #80]
 5c0:	a9406053 	ldp	x19, x24, [x2]
 5c4:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 5c8:	39400320 	ldrb	w0, [x25]
 5cc:	35000120 	cbnz	w0, 5f0 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 5d0:	2a1503e0 	mov	w0, w21
 5d4:	a94153f3 	ldp	x19, x20, [sp, #16]
 5d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
 5dc:	a94363f7 	ldp	x23, x24, [sp, #48]
 5e0:	a9446bf9 	ldp	x25, x26, [sp, #64]
 5e4:	a94573fb 	ldp	x27, x28, [sp, #80]
 5e8:	a8c67bfd 	ldp	x29, x30, [sp], #96
 5ec:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 5f0:	2a0003f6 	mov	w22, w0
    if(state == 0){
 5f4:	35000101 	cbnz	w1, 614 <vprintf+0x80>
      if(c == '%'){
 5f8:	7100941f 	cmp	w0, #0x25
 5fc:	54000ba0 	b.eq	770 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 600:	2a1603e1 	mov	w1, w22
 604:	2a1703e0 	mov	w0, w23
 608:	97ffffad 	bl	4bc <putc>
 60c:	0b0002b5 	add	w21, w21, w0
 610:	14000057 	b	76c <vprintf+0x1d8>
      if(c == 'd'){
 614:	7101901f 	cmp	w0, #0x64
 618:	540002a1 	b.ne	66c <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 61c:	37f80174 	tbnz	w20, #31, 648 <vprintf+0xb4>
 620:	91002e76 	add	x22, x19, #0xb
 624:	2a1403fa 	mov	w26, w20
 628:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 62c:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 630:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 634:	b9400261 	ldr	w1, [x19]
 638:	2a1703e0 	mov	w0, w23
 63c:	97ffffaa 	bl	4e4 <printint>
        written += putc(fd, va_arg(ap, uint));
 640:	0b0002b5 	add	w21, w21, w0
 644:	14000048 	b	764 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 648:	1100229a 	add	w26, w20, #0x8
 64c:	7100035f 	cmp	w26, #0x0
 650:	5400008d 	b.le	660 <vprintf+0xcc>
 654:	91002e76 	add	x22, x19, #0xb
 658:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 65c:	17fffff4 	b	62c <vprintf+0x98>
 660:	aa1303f6 	mov	x22, x19
 664:	8b34c313 	add	x19, x24, w20, sxtw
 668:	17fffff1 	b	62c <vprintf+0x98>
      } else if(c == 'l') {
 66c:	7101b01f 	cmp	w0, #0x6c
 670:	54000201 	b.ne	6b0 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 674:	37f800d4 	tbnz	w20, #31, 68c <vprintf+0xf8>
 678:	91003e76 	add	x22, x19, #0xf
 67c:	2a1403fa 	mov	w26, w20
 680:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 684:	52800003 	mov	w3, #0x0                   	// #0
 688:	17ffffea 	b	630 <vprintf+0x9c>
 68c:	1100229a 	add	w26, w20, #0x8
 690:	7100035f 	cmp	w26, #0x0
 694:	5400008d 	b.le	6a4 <vprintf+0x110>
 698:	91003e76 	add	x22, x19, #0xf
 69c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6a0:	17fffff9 	b	684 <vprintf+0xf0>
 6a4:	aa1303f6 	mov	x22, x19
 6a8:	8b34c313 	add	x19, x24, w20, sxtw
 6ac:	17fffff6 	b	684 <vprintf+0xf0>
      } else if(c == 'x') {
 6b0:	7101e01f 	cmp	w0, #0x78
 6b4:	54000221 	b.ne	6f8 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 6b8:	37f800f4 	tbnz	w20, #31, 6d4 <vprintf+0x140>
 6bc:	91002e76 	add	x22, x19, #0xb
 6c0:	2a1403fa 	mov	w26, w20
 6c4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6c8:	52800003 	mov	w3, #0x0                   	// #0
 6cc:	52800202 	mov	w2, #0x10                  	// #16
 6d0:	17ffffd9 	b	634 <vprintf+0xa0>
 6d4:	1100229a 	add	w26, w20, #0x8
 6d8:	7100035f 	cmp	w26, #0x0
 6dc:	5400008d 	b.le	6ec <vprintf+0x158>
 6e0:	91002e76 	add	x22, x19, #0xb
 6e4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6e8:	17fffff8 	b	6c8 <vprintf+0x134>
 6ec:	aa1303f6 	mov	x22, x19
 6f0:	8b34c313 	add	x19, x24, w20, sxtw
 6f4:	17fffff5 	b	6c8 <vprintf+0x134>
      } else if(c == 'p') {
 6f8:	7101c01f 	cmp	w0, #0x70
 6fc:	54000521 	b.ne	7a0 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 700:	37f803f4 	tbnz	w20, #31, 77c <vprintf+0x1e8>
 704:	91003e76 	add	x22, x19, #0xf
 708:	2a1403fa 	mov	w26, w20
 70c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 710:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 714:	52800601 	mov	w1, #0x30                  	// #48
 718:	2a1703e0 	mov	w0, w23
 71c:	97ffff68 	bl	4bc <putc>
 720:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 724:	9000001c 	adrp	x28, 0 <main>
 728:	9126cb9c 	add	x28, x28, #0x9b2
  written += putc(fd, 'x');
 72c:	2a1703e0 	mov	w0, w23
 730:	52800f01 	mov	w1, #0x78                  	// #120
 734:	97ffff62 	bl	4bc <putc>
 738:	0b000273 	add	w19, w19, w0
 73c:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 740:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 744:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 748:	38606b81 	ldrb	w1, [x28, x0]
 74c:	2a1703e0 	mov	w0, w23
 750:	97ffff5b 	bl	4bc <putc>
 754:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 758:	71000694 	subs	w20, w20, #0x1
 75c:	54ffff21 	b.ne	740 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 760:	0b1302b5 	add	w21, w21, w19
 764:	2a1a03f4 	mov	w20, w26
 768:	aa1603f3 	mov	x19, x22
      state = 0;
 76c:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 770:	91000739 	add	x25, x25, #0x1
  state = 0;
 774:	2a1603e1 	mov	w1, w22
 778:	17ffff94 	b	5c8 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 77c:	1100229a 	add	w26, w20, #0x8
 780:	7100035f 	cmp	w26, #0x0
 784:	5400008d 	b.le	794 <vprintf+0x200>
 788:	91003e76 	add	x22, x19, #0xf
 78c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 790:	17ffffe0 	b	710 <vprintf+0x17c>
 794:	aa1303f6 	mov	x22, x19
 798:	8b34c313 	add	x19, x24, w20, sxtw
 79c:	17ffffdd 	b	710 <vprintf+0x17c>
      } else if(c == 's'){
 7a0:	7101cc1f 	cmp	w0, #0x73
 7a4:	54000381 	b.ne	814 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 7a8:	37f80214 	tbnz	w20, #31, 7e8 <vprintf+0x254>
 7ac:	91003e61 	add	x1, x19, #0xf
 7b0:	aa1303e0 	mov	x0, x19
 7b4:	927df033 	and	x19, x1, #0xfffffffffffffff8
 7b8:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 7bc:	90000000 	adrp	x0, 0 <main>
 7c0:	9126ac00 	add	x0, x0, #0x9ab
 7c4:	f10002df 	cmp	x22, #0x0
 7c8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 7cc:	394002c1 	ldrb	w1, [x22]
 7d0:	34fffce1 	cbz	w1, 76c <vprintf+0x1d8>
          written += putc(fd, *s);
 7d4:	2a1703e0 	mov	w0, w23
          s++;
 7d8:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 7dc:	97ffff38 	bl	4bc <putc>
 7e0:	0b0002b5 	add	w21, w21, w0
          s++;
 7e4:	17fffffa 	b	7cc <vprintf+0x238>
        s = va_arg(ap, char*);
 7e8:	11002281 	add	w1, w20, #0x8
 7ec:	7100003f 	cmp	w1, #0x0
 7f0:	540000cd 	b.le	808 <vprintf+0x274>
 7f4:	91003e62 	add	x2, x19, #0xf
 7f8:	aa1303e0 	mov	x0, x19
 7fc:	2a0103f4 	mov	w20, w1
 800:	927df053 	and	x19, x2, #0xfffffffffffffff8
 804:	17ffffed 	b	7b8 <vprintf+0x224>
 808:	8b34c300 	add	x0, x24, w20, sxtw
 80c:	2a0103f4 	mov	w20, w1
 810:	17ffffea 	b	7b8 <vprintf+0x224>
      } else if(c == 'c'){
 814:	71018c1f 	cmp	w0, #0x63
 818:	54000241 	b.ne	860 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 81c:	37f80114 	tbnz	w20, #31, 83c <vprintf+0x2a8>
 820:	91002e76 	add	x22, x19, #0xb
 824:	2a1403fa 	mov	w26, w20
 828:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 82c:	39400261 	ldrb	w1, [x19]
 830:	2a1703e0 	mov	w0, w23
 834:	97ffff22 	bl	4bc <putc>
 838:	17ffff82 	b	640 <vprintf+0xac>
 83c:	1100229a 	add	w26, w20, #0x8
 840:	7100035f 	cmp	w26, #0x0
 844:	5400008d 	b.le	854 <vprintf+0x2c0>
 848:	91002e76 	add	x22, x19, #0xb
 84c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 850:	17fffff7 	b	82c <vprintf+0x298>
 854:	aa1303f6 	mov	x22, x19
 858:	8b34c313 	add	x19, x24, w20, sxtw
 85c:	17fffff4 	b	82c <vprintf+0x298>
      } else if(c == '%'){
 860:	7100941f 	cmp	w0, #0x25
 864:	54ffece0 	b.eq	600 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 868:	2a1703e0 	mov	w0, w23
 86c:	528004a1 	mov	w1, #0x25                  	// #37
 870:	97ffff13 	bl	4bc <putc>
 874:	0b0002b5 	add	w21, w21, w0
 878:	17ffff62 	b	600 <vprintf+0x6c>

000000000000087c <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 87c:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 880:	910003fd 	mov	x29, sp
 884:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 888:	910203e2 	add	x2, sp, #0x80
 88c:	a9030be2 	stp	x2, x2, [sp, #48]
 890:	910143e2 	add	x2, sp, #0x50
 894:	f90023e2 	str	x2, [sp, #64]
 898:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 89c:	b9004be2 	str	w2, [sp, #72]
 8a0:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 8a4:	a9430fe2 	ldp	x2, x3, [sp, #48]
 8a8:	a9010fe2 	stp	x2, x3, [sp, #16]
 8ac:	a9440fe2 	ldp	x2, x3, [sp, #64]
 8b0:	a9020fe2 	stp	x2, x3, [sp, #32]
 8b4:	910043e2 	add	x2, sp, #0x10
{
 8b8:	a90617e4 	stp	x4, x5, [sp, #96]
 8bc:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 8c0:	97ffff35 	bl	594 <vprintf>
  va_end(ap);
  return result;
}
 8c4:	a8c87bfd 	ldp	x29, x30, [sp], #128
 8c8:	d65f03c0 	ret

00000000000008cc <printf>:

int
printf(const char *fmt, ...)
{
 8cc:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 8d0:	910003fd 	mov	x29, sp
 8d4:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 8d8:	910243e1 	add	x1, sp, #0x90
 8dc:	a90307e1 	stp	x1, x1, [sp, #48]
 8e0:	910143e1 	add	x1, sp, #0x50
 8e4:	f90023e1 	str	x1, [sp, #64]
 8e8:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 8ec:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 8f0:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 8f4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 8f8:	52800020 	mov	w0, #0x1                   	// #1
{
 8fc:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 900:	a9430fe2 	ldp	x2, x3, [sp, #48]
 904:	a9010fe2 	stp	x2, x3, [sp, #16]
 908:	a9440fe2 	ldp	x2, x3, [sp, #64]
 90c:	a9020fe2 	stp	x2, x3, [sp, #32]
 910:	910043e2 	add	x2, sp, #0x10
{
 914:	a9079be5 	stp	x5, x6, [sp, #120]
 918:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 91c:	97ffff1e 	bl	594 <vprintf>
  va_end(ap);
  return result;
}
 920:	a8c97bfd 	ldp	x29, x30, [sp], #144
 924:	d65f03c0 	ret
