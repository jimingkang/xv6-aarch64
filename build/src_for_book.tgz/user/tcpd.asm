
user/_tcpd:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:

// TCP byte-stream smoke test used before the SSH transport is enabled.
// From another machine: nc <wlan0-ip> 2222
int
main(int argc, char **argv)
{
   0:	a9a17bfd 	stp	x29, x30, [sp, #-496]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
   c:	a9025bf5 	stp	x21, x22, [sp, #32]
  10:	a90363f7 	stp	x23, x24, [sp, #48]
  14:	a9046bf9 	stp	x25, x26, [sp, #64]
  char buf[256];
  struct epoll_event event, events[8];
  int port = 2222, listener, epfd, n;
  if(argc > 1)
  18:	7100041f 	cmp	w0, #0x1
  1c:	540001ed 	b.le	58 <main+0x58>
    port = atoi(argv[1]);
  20:	f9400420 	ldr	x0, [x1, #8]
  24:	94000109 	bl	448 <atoi>
  28:	2a0003f4 	mov	w20, w0
  listener = socket_listen(port, 10);
  2c:	2a1403e0 	mov	w0, w20
  30:	52800141 	mov	w1, #0xa                   	// #10
  34:	940001ca 	bl	75c <socket_listen>
  38:	2a0003f3 	mov	w19, w0
  if(listener < 0){
  3c:	36f80120 	tbz	w0, #31, 60 <main+0x60>
    printf("tcpd: cannot listen on %d\n", port);
  40:	90000000 	adrp	x0, 0 <main>
  44:	9133a000 	add	x0, x0, #0xce8
  48:	2a1403e1 	mov	w1, w20
  4c:	94000310 	bl	c8c <printf>
    exit(1);
  }
  printf("tcpd: waiting on port %d\n", port);
  if(fcntl(listener, F_SETFL, O_NONBLOCK) < 0){
    printf("tcpd: cannot set listener non-blocking\n");
    exit(1);
  50:	52800020 	mov	w0, #0x1                   	// #1
  54:	94000132 	bl	51c <exit>
  int port = 2222, listener, epfd, n;
  58:	528115d4 	mov	w20, #0x8ae                 	// #2222
  5c:	17fffff4 	b	2c <main+0x2c>
  printf("tcpd: waiting on port %d\n", port);
  60:	2a1403e1 	mov	w1, w20
  64:	90000000 	adrp	x0, 0 <main>
  68:	91340c00 	add	x0, x0, #0xd03
  6c:	94000308 	bl	c8c <printf>
  if(fcntl(listener, F_SETFL, O_NONBLOCK) < 0){
  70:	2a1303e0 	mov	w0, w19
  74:	52810002 	mov	w2, #0x800                 	// #2048
  78:	52800081 	mov	w1, #0x4                   	// #4
  7c:	940001c7 	bl	798 <fcntl>
  80:	36f800a0 	tbz	w0, #31, 94 <main+0x94>
    printf("tcpd: cannot set listener non-blocking\n");
  84:	90000000 	adrp	x0, 0 <main>
  88:	91347400 	add	x0, x0, #0xd1d
  8c:	94000300 	bl	c8c <printf>
  90:	17fffff0 	b	50 <main+0x50>
  }
  epfd = epoll_create();
  94:	940001b8 	bl	774 <epoll_create>
  98:	2a0003f6 	mov	w22, w0
  if(epfd < 0){
  9c:	36f800e0 	tbz	w0, #31, b8 <main+0xb8>
    printf("tcpd: epoll_create failed\n");
  a0:	90000000 	adrp	x0, 0 <main>
  a4:	91351400 	add	x0, x0, #0xd45
  a8:	940002f9 	bl	c8c <printf>
        }
      }
    }
  }
  close(epfd);
  close(listener);
  ac:	2a1303e0 	mov	w0, w19
  b0:	9400012a 	bl	558 <close>
  exit(1);
  b4:	17ffffe7 	b	50 <main+0x50>
  event.events = EPOLLIN;
  b8:	52800034 	mov	w20, #0x1                   	// #1
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, listener, &event) < 0){
  bc:	910183e3 	add	x3, sp, #0x60
  c0:	2a1303e2 	mov	w2, w19
  c4:	2a1403e1 	mov	w1, w20
  event.events = EPOLLIN;
  c8:	b90063f4 	str	w20, [sp, #96]
  event.data.fd = listener;
  cc:	b9006bf3 	str	w19, [sp, #104]
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, listener, &event) < 0){
  d0:	940001ac 	bl	780 <epoll_ctl>
  d4:	37f805a0 	tbnz	w0, #31, 188 <main+0x188>
          printf("tcpd: client fd=%d disconnected\n", fd);
  d8:	90000017 	adrp	x23, 0 <main>
  dc:	91371ef7 	add	x23, x23, #0xdc7
        printf("tcpd: client connected listener-fd=%d connection-fd=%d\n",
  e0:	90000018 	adrp	x24, 0 <main>
  e4:	9135f718 	add	x24, x24, #0xd7d
    n = epoll_wait(epfd, events, 8, -1);
  e8:	9101c3e1 	add	x1, sp, #0x70
  ec:	2a1603e0 	mov	w0, w22
  f0:	12800003 	mov	w3, #0xffffffff            	// #-1
  f4:	52800102 	mov	w2, #0x8                   	// #8
  f8:	940001a5 	bl	78c <epoll_wait>
  fc:	2a0003fa 	mov	w26, w0
    if(n < 0)
 100:	37f807e0 	tbnz	w0, #31, 1fc <main+0x1fc>
 104:	9101c3f5 	add	x21, sp, #0x70
    for(int i = 0; i < n; i++){
 108:	52800019 	mov	w25, #0x0                   	// #0
 10c:	6b1a033f 	cmp	w25, w26
 110:	54fffec0 	b.eq	e8 <main+0xe8>  // b.none
      int fd = events[i].data.fd;
 114:	b9400ab4 	ldr	w20, [x21, #8]
      if(fd == listener){
 118:	6b14027f 	cmp	w19, w20
 11c:	540003c1 	b.ne	194 <main+0x194>  // b.any
        int connection = socket_accept(listener);
 120:	2a1303e0 	mov	w0, w19
 124:	94000191 	bl	768 <socket_accept>
 128:	2a0003f4 	mov	w20, w0
        if(connection < 0)
 12c:	37f80280 	tbnz	w0, #31, 17c <main+0x17c>
        printf("tcpd: client connected listener-fd=%d connection-fd=%d\n",
 130:	2a0003e2 	mov	w2, w0
 134:	2a1303e1 	mov	w1, w19
 138:	aa1803e0 	mov	x0, x24
 13c:	940002d4 	bl	c8c <printf>
        write(connection, "xv6 socket ready\n", 17);
 140:	52800222 	mov	w2, #0x11                  	// #17
 144:	2a1403e0 	mov	w0, w20
 148:	90000001 	adrp	x1, 0 <main>
 14c:	9136d421 	add	x1, x1, #0xdb5
 150:	940000ff 	bl	54c <write>
        event.data.fd = connection;
 154:	b9006bf4 	str	w20, [sp, #104]
        event.events = EPOLLIN;
 158:	52800021 	mov	w1, #0x1                   	// #1
        if(epoll_ctl(epfd, EPOLL_CTL_ADD, connection, &event) < 0)
 15c:	910183e3 	add	x3, sp, #0x60
 160:	2a1403e2 	mov	w2, w20
 164:	2a1603e0 	mov	w0, w22
        event.events = EPOLLIN;
 168:	b90063e1 	str	w1, [sp, #96]
        if(epoll_ctl(epfd, EPOLL_CTL_ADD, connection, &event) < 0)
 16c:	94000185 	bl	780 <epoll_ctl>
 170:	36f80060 	tbz	w0, #31, 17c <main+0x17c>
          close(connection);
 174:	2a1403e0 	mov	w0, w20
 178:	940000f8 	bl	558 <close>
    for(int i = 0; i < n; i++){
 17c:	11000739 	add	w25, w25, #0x1
 180:	910042b5 	add	x21, x21, #0x10
 184:	17ffffe2 	b	10c <main+0x10c>
    printf("tcpd: cannot watch listener\n");
 188:	90000000 	adrp	x0, 0 <main>
 18c:	91358000 	add	x0, x0, #0xd60
 190:	17ffffbf 	b	8c <main+0x8c>
        int got = read(fd, buf, sizeof(buf));
 194:	52802002 	mov	w2, #0x100                 	// #256
 198:	9103c3e1 	add	x1, sp, #0xf0
 19c:	2a1403e0 	mov	w0, w20
 1a0:	940000e8 	bl	540 <read>
 1a4:	2a0003e2 	mov	w2, w0
        if(got <= 0 || write(fd, buf, got) != got){
 1a8:	7100001f 	cmp	w0, #0x0
 1ac:	5400018c 	b.gt	1dc <main+0x1dc>
          epoll_ctl(epfd, EPOLL_CTL_DEL, fd, 0);
 1b0:	2a1403e2 	mov	w2, w20
 1b4:	d2800003 	mov	x3, #0x0                   	// #0
 1b8:	52800041 	mov	w1, #0x2                   	// #2
 1bc:	2a1603e0 	mov	w0, w22
 1c0:	94000170 	bl	780 <epoll_ctl>
          close(fd);
 1c4:	2a1403e0 	mov	w0, w20
 1c8:	940000e4 	bl	558 <close>
          printf("tcpd: client fd=%d disconnected\n", fd);
 1cc:	2a1403e1 	mov	w1, w20
 1d0:	aa1703e0 	mov	x0, x23
 1d4:	940002ae 	bl	c8c <printf>
 1d8:	17ffffe9 	b	17c <main+0x17c>
        if(got <= 0 || write(fd, buf, got) != got){
 1dc:	9103c3e1 	add	x1, sp, #0xf0
 1e0:	2a1403e0 	mov	w0, w20
 1e4:	b9005fe2 	str	w2, [sp, #92]
 1e8:	940000d9 	bl	54c <write>
 1ec:	b9405fe2 	ldr	w2, [sp, #92]
 1f0:	6b02001f 	cmp	w0, w2
 1f4:	54fffde1 	b.ne	1b0 <main+0x1b0>  // b.any
 1f8:	17ffffe1 	b	17c <main+0x17c>
  close(epfd);
 1fc:	2a1603e0 	mov	w0, w22
 200:	940000d6 	bl	558 <close>
 204:	17ffffaa 	b	ac <main+0xac>

0000000000000208 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 208:	d2800002 	mov	x2, #0x0                   	// #0
 20c:	38626823 	ldrb	w3, [x1, x2]
 210:	38226803 	strb	w3, [x0, x2]
 214:	91000442 	add	x2, x2, #0x1
 218:	35ffffa3 	cbnz	w3, 20c <strcpy+0x4>
    ;
  return os;
}
 21c:	d65f03c0 	ret

0000000000000220 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 220:	d2800003 	mov	x3, #0x0                   	// #0
 224:	4b030044 	sub	w4, w2, w3
 228:	7100009f 	cmp	w4, #0x0
 22c:	5400006d 	b.le	238 <strncpy+0x18>
 230:	38636825 	ldrb	w5, [x1, x3]
 234:	350000e5 	cbnz	w5, 250 <strncpy+0x30>
 238:	8b030003 	add	x3, x0, x3
 23c:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 240:	4b010082 	sub	w2, w4, w1
 244:	7100005f 	cmp	w2, #0x0
 248:	540000ac 	b.gt	25c <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 24c:	d65f03c0 	ret
    *s++ = *t++;
 250:	38236805 	strb	w5, [x0, x3]
    n--;
 254:	91000463 	add	x3, x3, #0x1
 258:	17fffff3 	b	224 <strncpy+0x4>
    *s++ = 0;
 25c:	3821687f 	strb	wzr, [x3, x1]
 260:	91000421 	add	x1, x1, #0x1
 264:	17fffff7 	b	240 <strncpy+0x20>

0000000000000268 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 268:	aa0003e2 	mov	x2, x0
 26c:	39400043 	ldrb	w3, [x2]
 270:	aa0203e4 	mov	x4, x2
    s++;
 274:	91000442 	add	x2, x2, #0x1
  while(*s)
 278:	35ffffa3 	cbnz	w3, 26c <strcat+0x4>
 27c:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 280:	38626823 	ldrb	w3, [x1, x2]
 284:	38226883 	strb	w3, [x4, x2]
 288:	91000442 	add	x2, x2, #0x1
 28c:	35ffffa3 	cbnz	w3, 280 <strcat+0x18>
    ;
  return os;
}
 290:	d65f03c0 	ret

0000000000000294 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 294:	d2800002 	mov	x2, #0x0                   	// #0
 298:	38626803 	ldrb	w3, [x0, x2]
 29c:	38626824 	ldrb	w4, [x1, x2]
 2a0:	34000083 	cbz	w3, 2b0 <strcmp+0x1c>
 2a4:	91000442 	add	x2, x2, #0x1
 2a8:	6b04007f 	cmp	w3, w4
 2ac:	54ffff60 	b.eq	298 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 2b0:	4b040060 	sub	w0, w3, w4
 2b4:	d65f03c0 	ret

00000000000002b8 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 2b8:	340001c2 	cbz	w2, 2f0 <strncmp+0x38>
 2bc:	39400003 	ldrb	w3, [x0]
 2c0:	34000083 	cbz	w3, 2d0 <strncmp+0x18>
 2c4:	39400024 	ldrb	w4, [x1]
 2c8:	6b03009f 	cmp	w4, w3
 2cc:	540000a0 	b.eq	2e0 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 2d0:	39400000 	ldrb	w0, [x0]
 2d4:	39400021 	ldrb	w1, [x1]
 2d8:	4b010000 	sub	w0, w0, w1
}
 2dc:	d65f03c0 	ret
    n--, p++, q++;
 2e0:	51000442 	sub	w2, w2, #0x1
 2e4:	91000400 	add	x0, x0, #0x1
 2e8:	91000421 	add	x1, x1, #0x1
 2ec:	17fffff3 	b	2b8 <strncmp>
    return 0;
 2f0:	52800000 	mov	w0, #0x0                   	// #0
 2f4:	17fffffa 	b	2dc <strncmp+0x24>

00000000000002f8 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 2f8:	d1000402 	sub	x2, x0, #0x1
 2fc:	d2800001 	mov	x1, #0x0                   	// #0
 300:	aa0103e0 	mov	x0, x1
 304:	91000421 	add	x1, x1, #0x1
 308:	38616843 	ldrb	w3, [x2, x1]
 30c:	35ffffa3 	cbnz	w3, 300 <strlen+0x8>
    ;
  return n;
}
 310:	d65f03c0 	ret

0000000000000314 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 314:	d1000403 	sub	x3, x0, #0x1
 318:	d2800002 	mov	x2, #0x0                   	// #0
 31c:	2a0203e0 	mov	w0, w2
 320:	6b02003f 	cmp	w1, w2
 324:	54000089 	b.ls	334 <strnlen+0x20>  // b.plast
 328:	91000442 	add	x2, x2, #0x1
 32c:	38626864 	ldrb	w4, [x3, x2]
 330:	35ffff64 	cbnz	w4, 31c <strnlen+0x8>
    n++;
  return n;
}
 334:	d65f03c0 	ret

0000000000000338 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 338:	d2800003 	mov	x3, #0x0                   	// #0
 33c:	6b03005f 	cmp	w2, w3
 340:	54000048 	b.hi	348 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 344:	d65f03c0 	ret
    cdst[i] = c;
 348:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 34c:	91000463 	add	x3, x3, #0x1
 350:	17fffffb 	b	33c <memset+0x4>

0000000000000354 <strchr>:

char*
strchr(const char *s, char c)
{
 354:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 358:	39400002 	ldrb	w2, [x0]
 35c:	35000062 	cbnz	w2, 368 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 360:	d2800000 	mov	x0, #0x0                   	// #0
}
 364:	d65f03c0 	ret
    if(*s == c)
 368:	6b01005f 	cmp	w2, w1
 36c:	54ffffc0 	b.eq	364 <strchr+0x10>  // b.none
  for(; *s; s++)
 370:	91000400 	add	x0, x0, #0x1
 374:	17fffff9 	b	358 <strchr+0x4>

0000000000000378 <gets>:

char*
gets(char *buf, int max)
{
 378:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 37c:	910003fd 	mov	x29, sp
 380:	a90153f3 	stp	x19, x20, [sp, #16]
 384:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 388:	d2800014 	mov	x20, #0x0                   	// #0
{
 38c:	f9001bf7 	str	x23, [sp, #48]
 390:	2a0103f7 	mov	w23, w1
 394:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 398:	11000695 	add	w21, w20, #0x1
 39c:	2a1403f6 	mov	w22, w20
 3a0:	6b1702bf 	cmp	w21, w23
 3a4:	540000ea 	b.ge	3c0 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 3a8:	91013fe1 	add	x1, sp, #0x4f
 3ac:	52800022 	mov	w2, #0x1                   	// #1
 3b0:	52800000 	mov	w0, #0x0                   	// #0
 3b4:	94000063 	bl	540 <read>
    if(cc < 1)
 3b8:	7100001f 	cmp	w0, #0x0
 3bc:	5400012c 	b.gt	3e0 <gets+0x68>
  for(i=0; i+1 < max; ){
 3c0:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 3c4:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 3c8:	aa1303e0 	mov	x0, x19
 3cc:	f9401bf7 	ldr	x23, [sp, #48]
 3d0:	a94153f3 	ldp	x19, x20, [sp, #16]
 3d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
 3d8:	a8c57bfd 	ldp	x29, x30, [sp], #80
 3dc:	d65f03c0 	ret
    buf[i++] = c;
 3e0:	39413fe0 	ldrb	w0, [sp, #79]
 3e4:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 3e8:	91000694 	add	x20, x20, #0x1
 3ec:	7100281f 	cmp	w0, #0xa
 3f0:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 3f4:	54fffd21 	b.ne	398 <gets+0x20>  // b.any
 3f8:	17fffff3 	b	3c4 <gets+0x4c>

00000000000003fc <stat>:

int
stat(const char *n, struct stat *st)
{
 3fc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 400:	910003fd 	mov	x29, sp
 404:	a90153f3 	stp	x19, x20, [sp, #16]
 408:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 40c:	52800001 	mov	w1, #0x0                   	// #0
 410:	9400005b 	bl	57c <open>
  if(fd < 0)
 414:	37f80160 	tbnz	w0, #31, 440 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 418:	aa1303e1 	mov	x1, x19
 41c:	2a0003f4 	mov	w20, w0
 420:	94000060 	bl	5a0 <fstat>
 424:	2a0003f3 	mov	w19, w0
  close(fd);
 428:	2a1403e0 	mov	w0, w20
 42c:	9400004b 	bl	558 <close>
  return r;
}
 430:	2a1303e0 	mov	w0, w19
 434:	a94153f3 	ldp	x19, x20, [sp, #16]
 438:	a8c27bfd 	ldp	x29, x30, [sp], #32
 43c:	d65f03c0 	ret
    return -1;
 440:	12800013 	mov	w19, #0xffffffff            	// #-1
 444:	17fffffb 	b	430 <stat+0x34>

0000000000000448 <atoi>:

int
atoi(const char *s)
{
 448:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 44c:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 450:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 454:	39400043 	ldrb	w3, [x2]
 458:	5100c061 	sub	w1, w3, #0x30
 45c:	12001c21 	and	w1, w1, #0xff
 460:	7100243f 	cmp	w1, #0x9
 464:	54000049 	b.ls	46c <atoi+0x24>  // b.plast
  return n;
}
 468:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 46c:	1b040c01 	madd	w1, w0, w4, w3
 470:	91000442 	add	x2, x2, #0x1
 474:	5100c020 	sub	w0, w1, #0x30
 478:	17fffff7 	b	454 <atoi+0xc>

000000000000047c <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 47c:	eb01001f 	cmp	x0, x1
 480:	54000263 	b.cc	4cc <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 484:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 488:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 48c:	d2800003 	mov	x3, #0x0                   	// #0
 490:	d1000463 	sub	x3, x3, #0x1
 494:	11000464 	add	w4, w3, #0x1
 498:	0b020084 	add	w4, w4, w2
 49c:	7100009f 	cmp	w4, #0x0
 4a0:	5400014d 	b.le	4c8 <memmove+0x4c>
      *--dst = *--src;
 4a4:	38636824 	ldrb	w4, [x1, x3]
 4a8:	382368a4 	strb	w4, [x5, x3]
 4ac:	17fffff9 	b	490 <memmove+0x14>
      *dst++ = *src++;
 4b0:	38636824 	ldrb	w4, [x1, x3]
 4b4:	38236804 	strb	w4, [x0, x3]
 4b8:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 4bc:	4b030044 	sub	w4, w2, w3
 4c0:	7100009f 	cmp	w4, #0x0
 4c4:	54ffff6c 	b.gt	4b0 <memmove+0x34>
  }
  return vdst;
}
 4c8:	d65f03c0 	ret
 4cc:	d2800003 	mov	x3, #0x0                   	// #0
 4d0:	17fffffb 	b	4bc <memmove+0x40>

00000000000004d4 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 4d4:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 4d8:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 4dc:	d2800004 	mov	x4, #0x0                   	// #0
 4e0:	eb02009f 	cmp	x4, x2
 4e4:	54000061 	b.ne	4f0 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 4e8:	52800000 	mov	w0, #0x0                   	// #0
 4ec:	14000007 	b	508 <memcmp+0x34>
    if (*p1 != *p2) {
 4f0:	38646803 	ldrb	w3, [x0, x4]
 4f4:	91000484 	add	x4, x4, #0x1
 4f8:	38646825 	ldrb	w5, [x1, x4]
 4fc:	6b05007f 	cmp	w3, w5
 500:	54ffff00 	b.eq	4e0 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 504:	4b050060 	sub	w0, w3, w5
}
 508:	d65f03c0 	ret

000000000000050c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 50c:	17ffffdc 	b	47c <memmove>

0000000000000510 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 510:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 514:	d4000001 	svc	#0x0
 ret
 518:	d65f03c0 	ret

000000000000051c <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 51c:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 520:	d4000001 	svc	#0x0
 ret
 524:	d65f03c0 	ret

0000000000000528 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 528:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 52c:	d4000001 	svc	#0x0
 ret
 530:	d65f03c0 	ret

0000000000000534 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 534:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 538:	d4000001 	svc	#0x0
 ret
 53c:	d65f03c0 	ret

0000000000000540 <read>:
.global read
read:
 mov x7, #SYS_read
 540:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 544:	d4000001 	svc	#0x0
 ret
 548:	d65f03c0 	ret

000000000000054c <write>:
.global write
write:
 mov x7, #SYS_write
 54c:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 550:	d4000001 	svc	#0x0
 ret
 554:	d65f03c0 	ret

0000000000000558 <close>:
.global close
close:
 mov x7, #SYS_close
 558:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 55c:	d4000001 	svc	#0x0
 ret
 560:	d65f03c0 	ret

0000000000000564 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 564:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 568:	d4000001 	svc	#0x0
 ret
 56c:	d65f03c0 	ret

0000000000000570 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 570:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 574:	d4000001 	svc	#0x0
 ret
 578:	d65f03c0 	ret

000000000000057c <open>:
.global open
open:
 mov x7, #SYS_open
 57c:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 580:	d4000001 	svc	#0x0
 ret
 584:	d65f03c0 	ret

0000000000000588 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 588:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 58c:	d4000001 	svc	#0x0
 ret
 590:	d65f03c0 	ret

0000000000000594 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 594:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 598:	d4000001 	svc	#0x0
 ret
 59c:	d65f03c0 	ret

00000000000005a0 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 5a0:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 5a4:	d4000001 	svc	#0x0
 ret
 5a8:	d65f03c0 	ret

00000000000005ac <link>:
.global link
link:
 mov x7, #SYS_link
 5ac:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 5b0:	d4000001 	svc	#0x0
 ret
 5b4:	d65f03c0 	ret

00000000000005b8 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 5b8:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 5bc:	d4000001 	svc	#0x0
 ret
 5c0:	d65f03c0 	ret

00000000000005c4 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 5c4:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 5c8:	d4000001 	svc	#0x0
 ret
 5cc:	d65f03c0 	ret

00000000000005d0 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 5d0:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 5d4:	d4000001 	svc	#0x0
 ret
 5d8:	d65f03c0 	ret

00000000000005dc <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 5dc:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 5e0:	d4000001 	svc	#0x0
 ret
 5e4:	d65f03c0 	ret

00000000000005e8 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 5e8:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 5ec:	d4000001 	svc	#0x0
 ret
 5f0:	d65f03c0 	ret

00000000000005f4 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 5f4:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 5f8:	d4000001 	svc	#0x0
 ret
 5fc:	d65f03c0 	ret

0000000000000600 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 600:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 604:	d4000001 	svc	#0x0
 ret
 608:	d65f03c0 	ret

000000000000060c <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 60c:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 610:	d4000001 	svc	#0x0
 ret
 614:	d65f03c0 	ret

0000000000000618 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 618:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 61c:	d4000001 	svc	#0x0
 ret
 620:	d65f03c0 	ret

0000000000000624 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 624:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 628:	d4000001 	svc	#0x0
 ret
 62c:	d65f03c0 	ret

0000000000000630 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 630:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 634:	d4000001 	svc	#0x0
 ret
 638:	d65f03c0 	ret

000000000000063c <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 63c:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 640:	d4000001 	svc	#0x0
 ret
 644:	d65f03c0 	ret

0000000000000648 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 648:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 64c:	d4000001 	svc	#0x0
 ret
 650:	d65f03c0 	ret

0000000000000654 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 654:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 658:	d4000001 	svc	#0x0
 ret
 65c:	d65f03c0 	ret

0000000000000660 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 660:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 664:	d4000001 	svc	#0x0
 ret
 668:	d65f03c0 	ret

000000000000066c <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 66c:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 670:	d4000001 	svc	#0x0
 ret
 674:	d65f03c0 	ret

0000000000000678 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 678:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 67c:	d4000001 	svc	#0x0
 ret
 680:	d65f03c0 	ret

0000000000000684 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 684:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 688:	d4000001 	svc	#0x0
 ret
 68c:	d65f03c0 	ret

0000000000000690 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 690:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 694:	d4000001 	svc	#0x0
 ret
 698:	d65f03c0 	ret

000000000000069c <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 69c:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 6a0:	d4000001 	svc	#0x0
 ret
 6a4:	d65f03c0 	ret

00000000000006a8 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 6a8:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 6ac:	d4000001 	svc	#0x0
 ret
 6b0:	d65f03c0 	ret

00000000000006b4 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 6b4:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 6b8:	d4000001 	svc	#0x0
 ret
 6bc:	d65f03c0 	ret

00000000000006c0 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 6c0:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 6c4:	d4000001 	svc	#0x0
 ret
 6c8:	d65f03c0 	ret

00000000000006cc <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 6cc:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 6d0:	d4000001 	svc	#0x0
 ret
 6d4:	d65f03c0 	ret

00000000000006d8 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 6d8:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 6dc:	d4000001 	svc	#0x0
 ret
 6e0:	d65f03c0 	ret

00000000000006e4 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 6e4:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 6e8:	d4000001 	svc	#0x0
 ret
 6ec:	d65f03c0 	ret

00000000000006f0 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 6f0:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 6f4:	d4000001 	svc	#0x0
 ret
 6f8:	d65f03c0 	ret

00000000000006fc <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 6fc:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 700:	d4000001 	svc	#0x0
 ret
 704:	d65f03c0 	ret

0000000000000708 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 708:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 70c:	d4000001 	svc	#0x0
 ret
 710:	d65f03c0 	ret

0000000000000714 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 714:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 718:	d4000001 	svc	#0x0
 ret
 71c:	d65f03c0 	ret

0000000000000720 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 720:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 724:	d4000001 	svc	#0x0
 ret
 728:	d65f03c0 	ret

000000000000072c <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 72c:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 730:	d4000001 	svc	#0x0
 ret
 734:	d65f03c0 	ret

0000000000000738 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 738:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 73c:	d4000001 	svc	#0x0
 ret
 740:	d65f03c0 	ret

0000000000000744 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 744:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 748:	d4000001 	svc	#0x0
 ret
 74c:	d65f03c0 	ret

0000000000000750 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 750:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 754:	d4000001 	svc	#0x0
 ret
 758:	d65f03c0 	ret

000000000000075c <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 75c:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 760:	d4000001 	svc	#0x0
 ret
 764:	d65f03c0 	ret

0000000000000768 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 768:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 76c:	d4000001 	svc	#0x0
 ret
 770:	d65f03c0 	ret

0000000000000774 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 774:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 778:	d4000001 	svc	#0x0
 ret
 77c:	d65f03c0 	ret

0000000000000780 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 780:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 784:	d4000001 	svc	#0x0
 ret
 788:	d65f03c0 	ret

000000000000078c <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 78c:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 790:	d4000001 	svc	#0x0
 ret
 794:	d65f03c0 	ret

0000000000000798 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 798:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 79c:	d4000001 	svc	#0x0
 ret
 7a0:	d65f03c0 	ret

00000000000007a4 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 7a4:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 7a8:	d4000001 	svc	#0x0
 ret
 7ac:	d65f03c0 	ret

00000000000007b0 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 7b0:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 7b4:	d4000001 	svc	#0x0
 ret
 7b8:	d65f03c0 	ret

00000000000007bc <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 7bc:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 7c0:	d4000001 	svc	#0x0
 ret
 7c4:	d65f03c0 	ret

00000000000007c8 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 7c8:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 7cc:	d4000001 	svc	#0x0
 ret
 7d0:	d65f03c0 	ret

00000000000007d4 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 7d4:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 7d8:	d4000001 	svc	#0x0
 ret
 7dc:	d65f03c0 	ret

00000000000007e0 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 7e0:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 7e4:	d4000001 	svc	#0x0
 ret
 7e8:	d65f03c0 	ret

00000000000007ec <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 7ec:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 7f0:	d4000001 	svc	#0x0
 ret
 7f4:	d65f03c0 	ret

00000000000007f8 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 7f8:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 7fc:	d4000001 	svc	#0x0
 ret
 800:	d65f03c0 	ret

0000000000000804 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 804:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 808:	d4000001 	svc	#0x0
 ret
 80c:	d65f03c0 	ret

0000000000000810 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 810:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 814:	d4000001 	svc	#0x0
 ret
 818:	d65f03c0 	ret

000000000000081c <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 81c:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 820:	d4000001 	svc	#0x0
 ret
 824:	d65f03c0 	ret

0000000000000828 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 828:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 82c:	d4000001 	svc	#0x0
 ret
 830:	d65f03c0 	ret

0000000000000834 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 834:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 838:	d4000001 	svc	#0x0
 ret
 83c:	d65f03c0 	ret

0000000000000840 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 840:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 844:	d4000001 	svc	#0x0
 ret
 848:	d65f03c0 	ret

000000000000084c <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 84c:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 850:	d4000001 	svc	#0x0
 ret
 854:	d65f03c0 	ret

0000000000000858 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 858:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 85c:	d4000001 	svc	#0x0
 ret
 860:	d65f03c0 	ret

0000000000000864 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 864:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 868:	d4000001 	svc	#0x0
 ret
 86c:	d65f03c0 	ret

0000000000000870 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 870:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 874:	d4000001 	svc	#0x0
 ret
 878:	d65f03c0 	ret

000000000000087c <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 87c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 880:	52800022 	mov	w2, #0x1                   	// #1
{
 884:	910003fd 	mov	x29, sp
 888:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 88c:	91007fe1 	add	x1, sp, #0x1f
 890:	97ffff2f 	bl	54c <write>
 894:	7100041f 	cmp	w0, #0x1
}
 898:	1a9f17e0 	cset	w0, eq	// eq = none
 89c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 8a0:	d65f03c0 	ret

00000000000008a4 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 8a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 8a8:	910003fd 	mov	x29, sp
 8ac:	a90153f3 	stp	x19, x20, [sp, #16]
 8b0:	a9025bf5 	stp	x21, x22, [sp, #32]
 8b4:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 8b8:	6a417c7f 	tst	w3, w1, lsr #31
 8bc:	54000300 	b.eq	91c <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 8c0:	4b0103e1 	neg	w1, w1
    neg = 1;
 8c4:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 8c8:	90000003 	adrp	x3, 0 <main>
 8cc:	9137bc63 	add	x3, x3, #0xdef
 8d0:	9100c3f5 	add	x21, sp, #0x30
 8d4:	d2800000 	mov	x0, #0x0                   	// #0
 8d8:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 8dc:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 8e0:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 8e4:	2a0403e1 	mov	w1, w4
 8e8:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 8ec:	38666866 	ldrb	w6, [x3, x6]
 8f0:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 8f4:	91000400 	add	x0, x0, #0x1
 8f8:	54ffff09 	b.ls	8d8 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 8fc:	11000493 	add	w19, w4, #0x1
  if(neg)
 900:	34000085 	cbz	w5, 910 <printint+0x6c>
    buf[i++] = '-';
 904:	528005a0 	mov	w0, #0x2d                  	// #45
 908:	38334aa0 	strb	w0, [x21, w19, uxtw]
 90c:	11000893 	add	w19, w4, #0x2
 910:	51000673 	sub	w19, w19, #0x1
 914:	52800014 	mov	w20, #0x0                   	// #0
 918:	14000008 	b	938 <printint+0x94>
  neg = 0;
 91c:	52800005 	mov	w5, #0x0                   	// #0
 920:	17ffffea 	b	8c8 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 924:	38736aa1 	ldrb	w1, [x21, x19]
 928:	2a1603e0 	mov	w0, w22
 92c:	d1000673 	sub	x19, x19, #0x1
 930:	97ffffd3 	bl	87c <putc>
 934:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 938:	3100067f 	cmn	w19, #0x1
 93c:	54ffff41 	b.ne	924 <printint+0x80>  // b.any
  return written;
}
 940:	a9425bf5 	ldp	x21, x22, [sp, #32]
 944:	2a1403e0 	mov	w0, w20
 948:	a94153f3 	ldp	x19, x20, [sp, #16]
 94c:	a8c47bfd 	ldp	x29, x30, [sp], #64
 950:	d65f03c0 	ret

0000000000000954 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 954:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 958:	910003fd 	mov	x29, sp
 95c:	a90153f3 	stp	x19, x20, [sp, #16]
 960:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 964:	52800015 	mov	w21, #0x0                   	// #0
{
 968:	a90363f7 	stp	x23, x24, [sp, #48]
 96c:	2a0003f7 	mov	w23, w0
 970:	a9046bf9 	stp	x25, x26, [sp, #64]
 974:	aa0103f9 	mov	x25, x1

  state = 0;
 978:	52800001 	mov	w1, #0x0                   	// #0
{
 97c:	a90573fb 	stp	x27, x28, [sp, #80]
 980:	a9406053 	ldp	x19, x24, [x2]
 984:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 988:	39400320 	ldrb	w0, [x25]
 98c:	35000120 	cbnz	w0, 9b0 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 990:	2a1503e0 	mov	w0, w21
 994:	a94153f3 	ldp	x19, x20, [sp, #16]
 998:	a9425bf5 	ldp	x21, x22, [sp, #32]
 99c:	a94363f7 	ldp	x23, x24, [sp, #48]
 9a0:	a9446bf9 	ldp	x25, x26, [sp, #64]
 9a4:	a94573fb 	ldp	x27, x28, [sp, #80]
 9a8:	a8c67bfd 	ldp	x29, x30, [sp], #96
 9ac:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 9b0:	2a0003f6 	mov	w22, w0
    if(state == 0){
 9b4:	35000101 	cbnz	w1, 9d4 <vprintf+0x80>
      if(c == '%'){
 9b8:	7100941f 	cmp	w0, #0x25
 9bc:	54000ba0 	b.eq	b30 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 9c0:	2a1603e1 	mov	w1, w22
 9c4:	2a1703e0 	mov	w0, w23
 9c8:	97ffffad 	bl	87c <putc>
 9cc:	0b0002b5 	add	w21, w21, w0
 9d0:	14000057 	b	b2c <vprintf+0x1d8>
      if(c == 'd'){
 9d4:	7101901f 	cmp	w0, #0x64
 9d8:	540002a1 	b.ne	a2c <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 9dc:	37f80174 	tbnz	w20, #31, a08 <vprintf+0xb4>
 9e0:	91002e76 	add	x22, x19, #0xb
 9e4:	2a1403fa 	mov	w26, w20
 9e8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9ec:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 9f0:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 9f4:	b9400261 	ldr	w1, [x19]
 9f8:	2a1703e0 	mov	w0, w23
 9fc:	97ffffaa 	bl	8a4 <printint>
        written += putc(fd, va_arg(ap, uint));
 a00:	0b0002b5 	add	w21, w21, w0
 a04:	14000048 	b	b24 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 a08:	1100229a 	add	w26, w20, #0x8
 a0c:	7100035f 	cmp	w26, #0x0
 a10:	5400008d 	b.le	a20 <vprintf+0xcc>
 a14:	91002e76 	add	x22, x19, #0xb
 a18:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a1c:	17fffff4 	b	9ec <vprintf+0x98>
 a20:	aa1303f6 	mov	x22, x19
 a24:	8b34c313 	add	x19, x24, w20, sxtw
 a28:	17fffff1 	b	9ec <vprintf+0x98>
      } else if(c == 'l') {
 a2c:	7101b01f 	cmp	w0, #0x6c
 a30:	54000201 	b.ne	a70 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 a34:	37f800d4 	tbnz	w20, #31, a4c <vprintf+0xf8>
 a38:	91003e76 	add	x22, x19, #0xf
 a3c:	2a1403fa 	mov	w26, w20
 a40:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a44:	52800003 	mov	w3, #0x0                   	// #0
 a48:	17ffffea 	b	9f0 <vprintf+0x9c>
 a4c:	1100229a 	add	w26, w20, #0x8
 a50:	7100035f 	cmp	w26, #0x0
 a54:	5400008d 	b.le	a64 <vprintf+0x110>
 a58:	91003e76 	add	x22, x19, #0xf
 a5c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a60:	17fffff9 	b	a44 <vprintf+0xf0>
 a64:	aa1303f6 	mov	x22, x19
 a68:	8b34c313 	add	x19, x24, w20, sxtw
 a6c:	17fffff6 	b	a44 <vprintf+0xf0>
      } else if(c == 'x') {
 a70:	7101e01f 	cmp	w0, #0x78
 a74:	54000221 	b.ne	ab8 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 a78:	37f800f4 	tbnz	w20, #31, a94 <vprintf+0x140>
 a7c:	91002e76 	add	x22, x19, #0xb
 a80:	2a1403fa 	mov	w26, w20
 a84:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a88:	52800003 	mov	w3, #0x0                   	// #0
 a8c:	52800202 	mov	w2, #0x10                  	// #16
 a90:	17ffffd9 	b	9f4 <vprintf+0xa0>
 a94:	1100229a 	add	w26, w20, #0x8
 a98:	7100035f 	cmp	w26, #0x0
 a9c:	5400008d 	b.le	aac <vprintf+0x158>
 aa0:	91002e76 	add	x22, x19, #0xb
 aa4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 aa8:	17fffff8 	b	a88 <vprintf+0x134>
 aac:	aa1303f6 	mov	x22, x19
 ab0:	8b34c313 	add	x19, x24, w20, sxtw
 ab4:	17fffff5 	b	a88 <vprintf+0x134>
      } else if(c == 'p') {
 ab8:	7101c01f 	cmp	w0, #0x70
 abc:	54000521 	b.ne	b60 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 ac0:	37f803f4 	tbnz	w20, #31, b3c <vprintf+0x1e8>
 ac4:	91003e76 	add	x22, x19, #0xf
 ac8:	2a1403fa 	mov	w26, w20
 acc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ad0:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 ad4:	52800601 	mov	w1, #0x30                  	// #48
 ad8:	2a1703e0 	mov	w0, w23
 adc:	97ffff68 	bl	87c <putc>
 ae0:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 ae4:	9000001c 	adrp	x28, 0 <main>
 ae8:	9137bf9c 	add	x28, x28, #0xdef
  written += putc(fd, 'x');
 aec:	2a1703e0 	mov	w0, w23
 af0:	52800f01 	mov	w1, #0x78                  	// #120
 af4:	97ffff62 	bl	87c <putc>
 af8:	0b000273 	add	w19, w19, w0
 afc:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b00:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 b04:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b08:	38606b81 	ldrb	w1, [x28, x0]
 b0c:	2a1703e0 	mov	w0, w23
 b10:	97ffff5b 	bl	87c <putc>
 b14:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 b18:	71000694 	subs	w20, w20, #0x1
 b1c:	54ffff21 	b.ne	b00 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 b20:	0b1302b5 	add	w21, w21, w19
 b24:	2a1a03f4 	mov	w20, w26
 b28:	aa1603f3 	mov	x19, x22
      state = 0;
 b2c:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 b30:	91000739 	add	x25, x25, #0x1
  state = 0;
 b34:	2a1603e1 	mov	w1, w22
 b38:	17ffff94 	b	988 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 b3c:	1100229a 	add	w26, w20, #0x8
 b40:	7100035f 	cmp	w26, #0x0
 b44:	5400008d 	b.le	b54 <vprintf+0x200>
 b48:	91003e76 	add	x22, x19, #0xf
 b4c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b50:	17ffffe0 	b	ad0 <vprintf+0x17c>
 b54:	aa1303f6 	mov	x22, x19
 b58:	8b34c313 	add	x19, x24, w20, sxtw
 b5c:	17ffffdd 	b	ad0 <vprintf+0x17c>
      } else if(c == 's'){
 b60:	7101cc1f 	cmp	w0, #0x73
 b64:	54000381 	b.ne	bd4 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 b68:	37f80214 	tbnz	w20, #31, ba8 <vprintf+0x254>
 b6c:	91003e61 	add	x1, x19, #0xf
 b70:	aa1303e0 	mov	x0, x19
 b74:	927df033 	and	x19, x1, #0xfffffffffffffff8
 b78:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 b7c:	90000000 	adrp	x0, 0 <main>
 b80:	9137a000 	add	x0, x0, #0xde8
 b84:	f10002df 	cmp	x22, #0x0
 b88:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 b8c:	394002c1 	ldrb	w1, [x22]
 b90:	34fffce1 	cbz	w1, b2c <vprintf+0x1d8>
          written += putc(fd, *s);
 b94:	2a1703e0 	mov	w0, w23
          s++;
 b98:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 b9c:	97ffff38 	bl	87c <putc>
 ba0:	0b0002b5 	add	w21, w21, w0
          s++;
 ba4:	17fffffa 	b	b8c <vprintf+0x238>
        s = va_arg(ap, char*);
 ba8:	11002281 	add	w1, w20, #0x8
 bac:	7100003f 	cmp	w1, #0x0
 bb0:	540000cd 	b.le	bc8 <vprintf+0x274>
 bb4:	91003e62 	add	x2, x19, #0xf
 bb8:	aa1303e0 	mov	x0, x19
 bbc:	2a0103f4 	mov	w20, w1
 bc0:	927df053 	and	x19, x2, #0xfffffffffffffff8
 bc4:	17ffffed 	b	b78 <vprintf+0x224>
 bc8:	8b34c300 	add	x0, x24, w20, sxtw
 bcc:	2a0103f4 	mov	w20, w1
 bd0:	17ffffea 	b	b78 <vprintf+0x224>
      } else if(c == 'c'){
 bd4:	71018c1f 	cmp	w0, #0x63
 bd8:	54000241 	b.ne	c20 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 bdc:	37f80114 	tbnz	w20, #31, bfc <vprintf+0x2a8>
 be0:	91002e76 	add	x22, x19, #0xb
 be4:	2a1403fa 	mov	w26, w20
 be8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 bec:	39400261 	ldrb	w1, [x19]
 bf0:	2a1703e0 	mov	w0, w23
 bf4:	97ffff22 	bl	87c <putc>
 bf8:	17ffff82 	b	a00 <vprintf+0xac>
 bfc:	1100229a 	add	w26, w20, #0x8
 c00:	7100035f 	cmp	w26, #0x0
 c04:	5400008d 	b.le	c14 <vprintf+0x2c0>
 c08:	91002e76 	add	x22, x19, #0xb
 c0c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c10:	17fffff7 	b	bec <vprintf+0x298>
 c14:	aa1303f6 	mov	x22, x19
 c18:	8b34c313 	add	x19, x24, w20, sxtw
 c1c:	17fffff4 	b	bec <vprintf+0x298>
      } else if(c == '%'){
 c20:	7100941f 	cmp	w0, #0x25
 c24:	54ffece0 	b.eq	9c0 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 c28:	2a1703e0 	mov	w0, w23
 c2c:	528004a1 	mov	w1, #0x25                  	// #37
 c30:	97ffff13 	bl	87c <putc>
 c34:	0b0002b5 	add	w21, w21, w0
 c38:	17ffff62 	b	9c0 <vprintf+0x6c>

0000000000000c3c <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 c3c:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 c40:	910003fd 	mov	x29, sp
 c44:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 c48:	910203e2 	add	x2, sp, #0x80
 c4c:	a9030be2 	stp	x2, x2, [sp, #48]
 c50:	910143e2 	add	x2, sp, #0x50
 c54:	f90023e2 	str	x2, [sp, #64]
 c58:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 c5c:	b9004be2 	str	w2, [sp, #72]
 c60:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 c64:	a9430fe2 	ldp	x2, x3, [sp, #48]
 c68:	a9010fe2 	stp	x2, x3, [sp, #16]
 c6c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 c70:	a9020fe2 	stp	x2, x3, [sp, #32]
 c74:	910043e2 	add	x2, sp, #0x10
{
 c78:	a90617e4 	stp	x4, x5, [sp, #96]
 c7c:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 c80:	97ffff35 	bl	954 <vprintf>
  va_end(ap);
  return result;
}
 c84:	a8c87bfd 	ldp	x29, x30, [sp], #128
 c88:	d65f03c0 	ret

0000000000000c8c <printf>:

int
printf(const char *fmt, ...)
{
 c8c:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 c90:	910003fd 	mov	x29, sp
 c94:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 c98:	910243e1 	add	x1, sp, #0x90
 c9c:	a90307e1 	stp	x1, x1, [sp, #48]
 ca0:	910143e1 	add	x1, sp, #0x50
 ca4:	f90023e1 	str	x1, [sp, #64]
 ca8:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 cac:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 cb0:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 cb4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 cb8:	52800020 	mov	w0, #0x1                   	// #1
{
 cbc:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 cc0:	a9430fe2 	ldp	x2, x3, [sp, #48]
 cc4:	a9010fe2 	stp	x2, x3, [sp, #16]
 cc8:	a9440fe2 	ldp	x2, x3, [sp, #64]
 ccc:	a9020fe2 	stp	x2, x3, [sp, #32]
 cd0:	910043e2 	add	x2, sp, #0x10
{
 cd4:	a9079be5 	stp	x5, x6, [sp, #120]
 cd8:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 cdc:	97ffff1e 	bl	954 <vprintf>
  va_end(ap);
  return result;
}
 ce0:	a8c97bfd 	ldp	x29, x30, [sp], #144
 ce4:	d65f03c0 	ret
