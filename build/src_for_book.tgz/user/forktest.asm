
user/_forktest:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  print("dynamic fork test OK\n");
}

int
main(void)
{
   0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   4:	910003fd 	mov	x29, sp
  forktest();
   8:	9400000c 	bl	38 <forktest>
  exit(0);
   c:	52800000 	mov	w0, #0x0                   	// #0
  10:	940000f9 	bl	3f4 <exit>

0000000000000014 <print>:
{
  14:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  18:	910003fd 	mov	x29, sp
  1c:	f9000fe0 	str	x0, [sp, #24]
  write(1, s, strlen(s));
  20:	9400006c 	bl	1d0 <strlen>
  24:	f9400fe1 	ldr	x1, [sp, #24]
  28:	2a0003e2 	mov	w2, w0
}
  2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
  write(1, s, strlen(s));
  30:	52800020 	mov	w0, #0x1                   	// #1
  34:	140000fc 	b	424 <write>

0000000000000038 <forktest>:
{
  38:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  print("fork test\n");
  3c:	90000000 	adrp	x0, 0 <main>
  40:	911d5000 	add	x0, x0, #0x754
{
  44:	910003fd 	mov	x29, sp
  48:	a90153f3 	stp	x19, x20, [sp, #16]
  for(n=0; n<N; n++){
  4c:	52800013 	mov	w19, #0x0                   	// #0
  print("fork test\n");
  50:	97fffff1 	bl	14 <print>
    pid = fork();
  54:	940000e5 	bl	3e8 <fork>
    if(pid < 0)
  58:	37f800c0 	tbnz	w0, #31, 70 <forktest+0x38>
    if(pid == 0)
  5c:	35000040 	cbnz	w0, 64 <forktest+0x2c>
      exit(1);
  60:	940000e5 	bl	3f4 <exit>
  for(n=0; n<N; n++){
  64:	11000673 	add	w19, w19, #0x1
  68:	7102027f 	cmp	w19, #0x80
  6c:	54ffff41 	b.ne	54 <forktest+0x1c>  // b.any
  for(; n > 0; n--){
  70:	2a1303f4 	mov	w20, w19
    if(wait(0) < 0){
  74:	d2800000 	mov	x0, #0x0                   	// #0
  for(; n > 0; n--){
  78:	350000f4 	cbnz	w20, 94 <forktest+0x5c>
  if(wait(0) != -1){
  7c:	940000e1 	bl	400 <wait>
  80:	3100041f 	cmn	w0, #0x1
  84:	540001a0 	b.eq	b8 <forktest+0x80>  // b.none
    print("wait got too many\n");
  88:	90000000 	adrp	x0, 0 <main>
  8c:	911dcc00 	add	x0, x0, #0x773
  90:	14000005 	b	a4 <forktest+0x6c>
    if(wait(0) < 0){
  94:	940000db 	bl	400 <wait>
  98:	36f800c0 	tbz	w0, #31, b0 <forktest+0x78>
      print("wait stopped early\n");
  9c:	90000000 	adrp	x0, 0 <main>
  a0:	911d7c00 	add	x0, x0, #0x75f
  a4:	97ffffdc 	bl	14 <print>
      exit(1);
  a8:	52800020 	mov	w0, #0x1                   	// #1
  ac:	17ffffed 	b	60 <forktest+0x28>
  for(; n > 0; n--){
  b0:	51000694 	sub	w20, w20, #0x1
  b4:	17fffff0 	b	74 <forktest+0x3c>
  if(created <= OLD_NPROC){
  b8:	7101027f 	cmp	w19, #0x40
  bc:	5400008c 	b.gt	cc <forktest+0x94>
    print("fork stopped at old static limit\n");
  c0:	90000000 	adrp	x0, 0 <main>
  c4:	911e1800 	add	x0, x0, #0x786
  c8:	17fffff7 	b	a4 <forktest+0x6c>
}
  cc:	a94153f3 	ldp	x19, x20, [sp, #16]
  print("dynamic fork test OK\n");
  d0:	90000000 	adrp	x0, 0 <main>
  d4:	911ea000 	add	x0, x0, #0x7a8
}
  d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
  print("dynamic fork test OK\n");
  dc:	17ffffce 	b	14 <print>

00000000000000e0 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  e0:	d2800002 	mov	x2, #0x0                   	// #0
  e4:	38626823 	ldrb	w3, [x1, x2]
  e8:	38226803 	strb	w3, [x0, x2]
  ec:	91000442 	add	x2, x2, #0x1
  f0:	35ffffa3 	cbnz	w3, e4 <strcpy+0x4>
    ;
  return os;
}
  f4:	d65f03c0 	ret

00000000000000f8 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
  f8:	d2800003 	mov	x3, #0x0                   	// #0
  fc:	4b030044 	sub	w4, w2, w3
 100:	7100009f 	cmp	w4, #0x0
 104:	5400006d 	b.le	110 <strncpy+0x18>
 108:	38636825 	ldrb	w5, [x1, x3]
 10c:	350000e5 	cbnz	w5, 128 <strncpy+0x30>
 110:	8b030003 	add	x3, x0, x3
 114:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 118:	4b010082 	sub	w2, w4, w1
 11c:	7100005f 	cmp	w2, #0x0
 120:	540000ac 	b.gt	134 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 124:	d65f03c0 	ret
    *s++ = *t++;
 128:	38236805 	strb	w5, [x0, x3]
    n--;
 12c:	91000463 	add	x3, x3, #0x1
 130:	17fffff3 	b	fc <strncpy+0x4>
    *s++ = 0;
 134:	3821687f 	strb	wzr, [x3, x1]
 138:	91000421 	add	x1, x1, #0x1
 13c:	17fffff7 	b	118 <strncpy+0x20>

0000000000000140 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 140:	aa0003e2 	mov	x2, x0
 144:	39400043 	ldrb	w3, [x2]
 148:	aa0203e4 	mov	x4, x2
    s++;
 14c:	91000442 	add	x2, x2, #0x1
  while(*s)
 150:	35ffffa3 	cbnz	w3, 144 <strcat+0x4>
 154:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 158:	38626823 	ldrb	w3, [x1, x2]
 15c:	38226883 	strb	w3, [x4, x2]
 160:	91000442 	add	x2, x2, #0x1
 164:	35ffffa3 	cbnz	w3, 158 <strcat+0x18>
    ;
  return os;
}
 168:	d65f03c0 	ret

000000000000016c <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 16c:	d2800002 	mov	x2, #0x0                   	// #0
 170:	38626803 	ldrb	w3, [x0, x2]
 174:	38626824 	ldrb	w4, [x1, x2]
 178:	34000083 	cbz	w3, 188 <strcmp+0x1c>
 17c:	91000442 	add	x2, x2, #0x1
 180:	6b04007f 	cmp	w3, w4
 184:	54ffff60 	b.eq	170 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 188:	4b040060 	sub	w0, w3, w4
 18c:	d65f03c0 	ret

0000000000000190 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 190:	340001c2 	cbz	w2, 1c8 <strncmp+0x38>
 194:	39400003 	ldrb	w3, [x0]
 198:	34000083 	cbz	w3, 1a8 <strncmp+0x18>
 19c:	39400024 	ldrb	w4, [x1]
 1a0:	6b03009f 	cmp	w4, w3
 1a4:	540000a0 	b.eq	1b8 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 1a8:	39400000 	ldrb	w0, [x0]
 1ac:	39400021 	ldrb	w1, [x1]
 1b0:	4b010000 	sub	w0, w0, w1
}
 1b4:	d65f03c0 	ret
    n--, p++, q++;
 1b8:	51000442 	sub	w2, w2, #0x1
 1bc:	91000400 	add	x0, x0, #0x1
 1c0:	91000421 	add	x1, x1, #0x1
 1c4:	17fffff3 	b	190 <strncmp>
    return 0;
 1c8:	52800000 	mov	w0, #0x0                   	// #0
 1cc:	17fffffa 	b	1b4 <strncmp+0x24>

00000000000001d0 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 1d0:	d1000402 	sub	x2, x0, #0x1
 1d4:	d2800001 	mov	x1, #0x0                   	// #0
 1d8:	aa0103e0 	mov	x0, x1
 1dc:	91000421 	add	x1, x1, #0x1
 1e0:	38616843 	ldrb	w3, [x2, x1]
 1e4:	35ffffa3 	cbnz	w3, 1d8 <strlen+0x8>
    ;
  return n;
}
 1e8:	d65f03c0 	ret

00000000000001ec <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 1ec:	d1000403 	sub	x3, x0, #0x1
 1f0:	d2800002 	mov	x2, #0x0                   	// #0
 1f4:	2a0203e0 	mov	w0, w2
 1f8:	6b02003f 	cmp	w1, w2
 1fc:	54000089 	b.ls	20c <strnlen+0x20>  // b.plast
 200:	91000442 	add	x2, x2, #0x1
 204:	38626864 	ldrb	w4, [x3, x2]
 208:	35ffff64 	cbnz	w4, 1f4 <strnlen+0x8>
    n++;
  return n;
}
 20c:	d65f03c0 	ret

0000000000000210 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 210:	d2800003 	mov	x3, #0x0                   	// #0
 214:	6b03005f 	cmp	w2, w3
 218:	54000048 	b.hi	220 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 21c:	d65f03c0 	ret
    cdst[i] = c;
 220:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 224:	91000463 	add	x3, x3, #0x1
 228:	17fffffb 	b	214 <memset+0x4>

000000000000022c <strchr>:

char*
strchr(const char *s, char c)
{
 22c:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 230:	39400002 	ldrb	w2, [x0]
 234:	35000062 	cbnz	w2, 240 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 238:	d2800000 	mov	x0, #0x0                   	// #0
}
 23c:	d65f03c0 	ret
    if(*s == c)
 240:	6b01005f 	cmp	w2, w1
 244:	54ffffc0 	b.eq	23c <strchr+0x10>  // b.none
  for(; *s; s++)
 248:	91000400 	add	x0, x0, #0x1
 24c:	17fffff9 	b	230 <strchr+0x4>

0000000000000250 <gets>:

char*
gets(char *buf, int max)
{
 250:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 254:	910003fd 	mov	x29, sp
 258:	a90153f3 	stp	x19, x20, [sp, #16]
 25c:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 260:	d2800014 	mov	x20, #0x0                   	// #0
{
 264:	f9001bf7 	str	x23, [sp, #48]
 268:	2a0103f7 	mov	w23, w1
 26c:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 270:	11000695 	add	w21, w20, #0x1
 274:	2a1403f6 	mov	w22, w20
 278:	6b1702bf 	cmp	w21, w23
 27c:	540000ea 	b.ge	298 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 280:	91013fe1 	add	x1, sp, #0x4f
 284:	52800022 	mov	w2, #0x1                   	// #1
 288:	52800000 	mov	w0, #0x0                   	// #0
 28c:	94000063 	bl	418 <read>
    if(cc < 1)
 290:	7100001f 	cmp	w0, #0x0
 294:	5400012c 	b.gt	2b8 <gets+0x68>
  for(i=0; i+1 < max; ){
 298:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 29c:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 2a0:	aa1303e0 	mov	x0, x19
 2a4:	f9401bf7 	ldr	x23, [sp, #48]
 2a8:	a94153f3 	ldp	x19, x20, [sp, #16]
 2ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
 2b0:	a8c57bfd 	ldp	x29, x30, [sp], #80
 2b4:	d65f03c0 	ret
    buf[i++] = c;
 2b8:	39413fe0 	ldrb	w0, [sp, #79]
 2bc:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 2c0:	91000694 	add	x20, x20, #0x1
 2c4:	7100281f 	cmp	w0, #0xa
 2c8:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 2cc:	54fffd21 	b.ne	270 <gets+0x20>  // b.any
 2d0:	17fffff3 	b	29c <gets+0x4c>

00000000000002d4 <stat>:

int
stat(const char *n, struct stat *st)
{
 2d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 2d8:	910003fd 	mov	x29, sp
 2dc:	a90153f3 	stp	x19, x20, [sp, #16]
 2e0:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2e4:	52800001 	mov	w1, #0x0                   	// #0
 2e8:	9400005b 	bl	454 <open>
  if(fd < 0)
 2ec:	37f80160 	tbnz	w0, #31, 318 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 2f0:	aa1303e1 	mov	x1, x19
 2f4:	2a0003f4 	mov	w20, w0
 2f8:	94000060 	bl	478 <fstat>
 2fc:	2a0003f3 	mov	w19, w0
  close(fd);
 300:	2a1403e0 	mov	w0, w20
 304:	9400004b 	bl	430 <close>
  return r;
}
 308:	2a1303e0 	mov	w0, w19
 30c:	a94153f3 	ldp	x19, x20, [sp, #16]
 310:	a8c27bfd 	ldp	x29, x30, [sp], #32
 314:	d65f03c0 	ret
    return -1;
 318:	12800013 	mov	w19, #0xffffffff            	// #-1
 31c:	17fffffb 	b	308 <stat+0x34>

0000000000000320 <atoi>:

int
atoi(const char *s)
{
 320:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 324:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 328:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 32c:	39400043 	ldrb	w3, [x2]
 330:	5100c061 	sub	w1, w3, #0x30
 334:	12001c21 	and	w1, w1, #0xff
 338:	7100243f 	cmp	w1, #0x9
 33c:	54000049 	b.ls	344 <atoi+0x24>  // b.plast
  return n;
}
 340:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 344:	1b040c01 	madd	w1, w0, w4, w3
 348:	91000442 	add	x2, x2, #0x1
 34c:	5100c020 	sub	w0, w1, #0x30
 350:	17fffff7 	b	32c <atoi+0xc>

0000000000000354 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 354:	eb01001f 	cmp	x0, x1
 358:	54000263 	b.cc	3a4 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 35c:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 360:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 364:	d2800003 	mov	x3, #0x0                   	// #0
 368:	d1000463 	sub	x3, x3, #0x1
 36c:	11000464 	add	w4, w3, #0x1
 370:	0b020084 	add	w4, w4, w2
 374:	7100009f 	cmp	w4, #0x0
 378:	5400014d 	b.le	3a0 <memmove+0x4c>
      *--dst = *--src;
 37c:	38636824 	ldrb	w4, [x1, x3]
 380:	382368a4 	strb	w4, [x5, x3]
 384:	17fffff9 	b	368 <memmove+0x14>
      *dst++ = *src++;
 388:	38636824 	ldrb	w4, [x1, x3]
 38c:	38236804 	strb	w4, [x0, x3]
 390:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 394:	4b030044 	sub	w4, w2, w3
 398:	7100009f 	cmp	w4, #0x0
 39c:	54ffff6c 	b.gt	388 <memmove+0x34>
  }
  return vdst;
}
 3a0:	d65f03c0 	ret
 3a4:	d2800003 	mov	x3, #0x0                   	// #0
 3a8:	17fffffb 	b	394 <memmove+0x40>

00000000000003ac <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3ac:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 3b0:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 3b4:	d2800004 	mov	x4, #0x0                   	// #0
 3b8:	eb02009f 	cmp	x4, x2
 3bc:	54000061 	b.ne	3c8 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 3c0:	52800000 	mov	w0, #0x0                   	// #0
 3c4:	14000007 	b	3e0 <memcmp+0x34>
    if (*p1 != *p2) {
 3c8:	38646803 	ldrb	w3, [x0, x4]
 3cc:	91000484 	add	x4, x4, #0x1
 3d0:	38646825 	ldrb	w5, [x1, x4]
 3d4:	6b05007f 	cmp	w3, w5
 3d8:	54ffff00 	b.eq	3b8 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 3dc:	4b050060 	sub	w0, w3, w5
}
 3e0:	d65f03c0 	ret

00000000000003e4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 3e4:	17ffffdc 	b	354 <memmove>

00000000000003e8 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 3e8:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 3ec:	d4000001 	svc	#0x0
 ret
 3f0:	d65f03c0 	ret

00000000000003f4 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 3f4:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 3f8:	d4000001 	svc	#0x0
 ret
 3fc:	d65f03c0 	ret

0000000000000400 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 400:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 404:	d4000001 	svc	#0x0
 ret
 408:	d65f03c0 	ret

000000000000040c <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 40c:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 410:	d4000001 	svc	#0x0
 ret
 414:	d65f03c0 	ret

0000000000000418 <read>:
.global read
read:
 mov x7, #SYS_read
 418:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 41c:	d4000001 	svc	#0x0
 ret
 420:	d65f03c0 	ret

0000000000000424 <write>:
.global write
write:
 mov x7, #SYS_write
 424:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 428:	d4000001 	svc	#0x0
 ret
 42c:	d65f03c0 	ret

0000000000000430 <close>:
.global close
close:
 mov x7, #SYS_close
 430:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 434:	d4000001 	svc	#0x0
 ret
 438:	d65f03c0 	ret

000000000000043c <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 43c:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 440:	d4000001 	svc	#0x0
 ret
 444:	d65f03c0 	ret

0000000000000448 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 448:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 44c:	d4000001 	svc	#0x0
 ret
 450:	d65f03c0 	ret

0000000000000454 <open>:
.global open
open:
 mov x7, #SYS_open
 454:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 458:	d4000001 	svc	#0x0
 ret
 45c:	d65f03c0 	ret

0000000000000460 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 460:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 464:	d4000001 	svc	#0x0
 ret
 468:	d65f03c0 	ret

000000000000046c <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 46c:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 470:	d4000001 	svc	#0x0
 ret
 474:	d65f03c0 	ret

0000000000000478 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 478:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 47c:	d4000001 	svc	#0x0
 ret
 480:	d65f03c0 	ret

0000000000000484 <link>:
.global link
link:
 mov x7, #SYS_link
 484:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 488:	d4000001 	svc	#0x0
 ret
 48c:	d65f03c0 	ret

0000000000000490 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 490:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 494:	d4000001 	svc	#0x0
 ret
 498:	d65f03c0 	ret

000000000000049c <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 49c:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 4a0:	d4000001 	svc	#0x0
 ret
 4a4:	d65f03c0 	ret

00000000000004a8 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 4a8:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 4ac:	d4000001 	svc	#0x0
 ret
 4b0:	d65f03c0 	ret

00000000000004b4 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 4b4:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 4b8:	d4000001 	svc	#0x0
 ret
 4bc:	d65f03c0 	ret

00000000000004c0 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 4c0:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 4c4:	d4000001 	svc	#0x0
 ret
 4c8:	d65f03c0 	ret

00000000000004cc <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 4cc:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 4d0:	d4000001 	svc	#0x0
 ret
 4d4:	d65f03c0 	ret

00000000000004d8 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 4d8:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 4dc:	d4000001 	svc	#0x0
 ret
 4e0:	d65f03c0 	ret

00000000000004e4 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 4e4:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 4e8:	d4000001 	svc	#0x0
 ret
 4ec:	d65f03c0 	ret

00000000000004f0 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 4f0:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 4f4:	d4000001 	svc	#0x0
 ret
 4f8:	d65f03c0 	ret

00000000000004fc <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 4fc:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 500:	d4000001 	svc	#0x0
 ret
 504:	d65f03c0 	ret

0000000000000508 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 508:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 50c:	d4000001 	svc	#0x0
 ret
 510:	d65f03c0 	ret

0000000000000514 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 514:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 518:	d4000001 	svc	#0x0
 ret
 51c:	d65f03c0 	ret

0000000000000520 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 520:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 524:	d4000001 	svc	#0x0
 ret
 528:	d65f03c0 	ret

000000000000052c <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 52c:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 530:	d4000001 	svc	#0x0
 ret
 534:	d65f03c0 	ret

0000000000000538 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 538:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 53c:	d4000001 	svc	#0x0
 ret
 540:	d65f03c0 	ret

0000000000000544 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 544:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 548:	d4000001 	svc	#0x0
 ret
 54c:	d65f03c0 	ret

0000000000000550 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 550:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 554:	d4000001 	svc	#0x0
 ret
 558:	d65f03c0 	ret

000000000000055c <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 55c:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 560:	d4000001 	svc	#0x0
 ret
 564:	d65f03c0 	ret

0000000000000568 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 568:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 56c:	d4000001 	svc	#0x0
 ret
 570:	d65f03c0 	ret

0000000000000574 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 574:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 578:	d4000001 	svc	#0x0
 ret
 57c:	d65f03c0 	ret

0000000000000580 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 580:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 584:	d4000001 	svc	#0x0
 ret
 588:	d65f03c0 	ret

000000000000058c <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 58c:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 590:	d4000001 	svc	#0x0
 ret
 594:	d65f03c0 	ret

0000000000000598 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 598:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 59c:	d4000001 	svc	#0x0
 ret
 5a0:	d65f03c0 	ret

00000000000005a4 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 5a4:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 5a8:	d4000001 	svc	#0x0
 ret
 5ac:	d65f03c0 	ret

00000000000005b0 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 5b0:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 5b4:	d4000001 	svc	#0x0
 ret
 5b8:	d65f03c0 	ret

00000000000005bc <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 5bc:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 5c0:	d4000001 	svc	#0x0
 ret
 5c4:	d65f03c0 	ret

00000000000005c8 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 5c8:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 5cc:	d4000001 	svc	#0x0
 ret
 5d0:	d65f03c0 	ret

00000000000005d4 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 5d4:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 5d8:	d4000001 	svc	#0x0
 ret
 5dc:	d65f03c0 	ret

00000000000005e0 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 5e0:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 5e4:	d4000001 	svc	#0x0
 ret
 5e8:	d65f03c0 	ret

00000000000005ec <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 5ec:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 5f0:	d4000001 	svc	#0x0
 ret
 5f4:	d65f03c0 	ret

00000000000005f8 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 5f8:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 5fc:	d4000001 	svc	#0x0
 ret
 600:	d65f03c0 	ret

0000000000000604 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 604:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 608:	d4000001 	svc	#0x0
 ret
 60c:	d65f03c0 	ret

0000000000000610 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 610:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 614:	d4000001 	svc	#0x0
 ret
 618:	d65f03c0 	ret

000000000000061c <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 61c:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 620:	d4000001 	svc	#0x0
 ret
 624:	d65f03c0 	ret

0000000000000628 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 628:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 62c:	d4000001 	svc	#0x0
 ret
 630:	d65f03c0 	ret

0000000000000634 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 634:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 638:	d4000001 	svc	#0x0
 ret
 63c:	d65f03c0 	ret

0000000000000640 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 640:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 644:	d4000001 	svc	#0x0
 ret
 648:	d65f03c0 	ret

000000000000064c <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 64c:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 650:	d4000001 	svc	#0x0
 ret
 654:	d65f03c0 	ret

0000000000000658 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 658:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 65c:	d4000001 	svc	#0x0
 ret
 660:	d65f03c0 	ret

0000000000000664 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 664:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 668:	d4000001 	svc	#0x0
 ret
 66c:	d65f03c0 	ret

0000000000000670 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 670:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 674:	d4000001 	svc	#0x0
 ret
 678:	d65f03c0 	ret

000000000000067c <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 67c:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 680:	d4000001 	svc	#0x0
 ret
 684:	d65f03c0 	ret

0000000000000688 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 688:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 68c:	d4000001 	svc	#0x0
 ret
 690:	d65f03c0 	ret

0000000000000694 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 694:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 698:	d4000001 	svc	#0x0
 ret
 69c:	d65f03c0 	ret

00000000000006a0 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 6a0:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 6a4:	d4000001 	svc	#0x0
 ret
 6a8:	d65f03c0 	ret

00000000000006ac <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 6ac:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 6b0:	d4000001 	svc	#0x0
 ret
 6b4:	d65f03c0 	ret

00000000000006b8 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 6b8:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 6bc:	d4000001 	svc	#0x0
 ret
 6c0:	d65f03c0 	ret

00000000000006c4 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 6c4:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 6c8:	d4000001 	svc	#0x0
 ret
 6cc:	d65f03c0 	ret

00000000000006d0 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 6d0:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 6d4:	d4000001 	svc	#0x0
 ret
 6d8:	d65f03c0 	ret

00000000000006dc <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 6dc:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 6e0:	d4000001 	svc	#0x0
 ret
 6e4:	d65f03c0 	ret

00000000000006e8 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 6e8:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 6ec:	d4000001 	svc	#0x0
 ret
 6f0:	d65f03c0 	ret

00000000000006f4 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 6f4:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 6f8:	d4000001 	svc	#0x0
 ret
 6fc:	d65f03c0 	ret

0000000000000700 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 700:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 704:	d4000001 	svc	#0x0
 ret
 708:	d65f03c0 	ret

000000000000070c <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 70c:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 710:	d4000001 	svc	#0x0
 ret
 714:	d65f03c0 	ret

0000000000000718 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 718:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 71c:	d4000001 	svc	#0x0
 ret
 720:	d65f03c0 	ret

0000000000000724 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 724:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 728:	d4000001 	svc	#0x0
 ret
 72c:	d65f03c0 	ret

0000000000000730 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 730:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 734:	d4000001 	svc	#0x0
 ret
 738:	d65f03c0 	ret

000000000000073c <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 73c:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 740:	d4000001 	svc	#0x0
 ret
 744:	d65f03c0 	ret

0000000000000748 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 748:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 74c:	d4000001 	svc	#0x0
 ret
 750:	d65f03c0 	ret
