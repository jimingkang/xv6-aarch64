
user/_grep:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  }
}

int
main(int argc, char *argv[])
{
   0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
   c:	a9025bf5 	stp	x21, x22, [sp, #32]
  int fd, i;
  char *pattern;

  if(argc <= 1){
  10:	7100041f 	cmp	w0, #0x1
  14:	540000ec 	b.gt	30 <main+0x30>
    fprintf(2, "usage: grep pattern [file ...]\n");
  18:	90000001 	adrp	x1, 0 <main>
  1c:	91366021 	add	x1, x1, #0xd98
  20:	52800040 	mov	w0, #0x2                   	// #2
  24:	94000332 	bl	cec <fprintf>
  }

  for(i = 2; i < argc; i++){
    if((fd = open(argv[i], 0)) < 0){
      printf("grep: cannot open %s\n", argv[i]);
      exit(1);
  28:	52800020 	mov	w0, #0x1                   	// #1
  2c:	1400000a 	b	54 <main+0x54>
  pattern = argv[1];
  30:	f9400436 	ldr	x22, [x1, #8]
  34:	2a0003f4 	mov	w20, w0
  38:	aa0103f5 	mov	x21, x1
  if(argc <= 2){
  3c:	7100081f 	cmp	w0, #0x2
  40:	540000c1 	b.ne	58 <main+0x58>  // b.any
    grep(pattern, 0);
  44:	aa1603e0 	mov	x0, x22
  48:	52800001 	mov	w1, #0x0                   	// #0
  4c:	94000062 	bl	1d4 <grep>
    exit(0);
  50:	52800000 	mov	w0, #0x0                   	// #0
  54:	9400015e 	bl	5cc <exit>
  if(argc <= 2){
  58:	d2800053 	mov	x19, #0x2                   	// #2
    if((fd = open(argv[i], 0)) < 0){
  5c:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
  60:	52800001 	mov	w1, #0x0                   	// #0
  64:	94000172 	bl	62c <open>
  68:	2a0003e1 	mov	w1, w0
  6c:	36f800c0 	tbz	w0, #31, 84 <main+0x84>
      printf("grep: cannot open %s\n", argv[i]);
  70:	f8735aa1 	ldr	x1, [x21, w19, uxtw #3]
  74:	90000000 	adrp	x0, 0 <main>
  78:	9136e000 	add	x0, x0, #0xdb8
  7c:	94000330 	bl	d3c <printf>
  80:	17ffffea 	b	28 <main+0x28>
    }
    grep(pattern, fd);
  84:	aa1603e0 	mov	x0, x22
  88:	b9003fe1 	str	w1, [sp, #60]
  8c:	94000052 	bl	1d4 <grep>
  for(i = 2; i < argc; i++){
  90:	91000673 	add	x19, x19, #0x1
    close(fd);
  94:	b9403fe0 	ldr	w0, [sp, #60]
  98:	9400015c 	bl	608 <close>
  for(i = 2; i < argc; i++){
  9c:	6b13029f 	cmp	w20, w19
  a0:	54fffdec 	b.gt	5c <main+0x5c>
  a4:	17ffffeb 	b	50 <main+0x50>

00000000000000a8 <matchstar>:
  return 0;
}

// matchstar: search for c*re at beginning of text
int matchstar(int c, char *re, char *text)
{
  a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  ac:	910003fd 	mov	x29, sp
  b0:	a90153f3 	stp	x19, x20, [sp, #16]
  b4:	2a0003f3 	mov	w19, w0
  b8:	aa0203f4 	mov	x20, x2
  bc:	f90013f5 	str	x21, [sp, #32]
  c0:	aa0103f5 	mov	x21, x1
  do{  // a * matches zero or more instances
    if(matchhere(re, text))
  c4:	aa1403e1 	mov	x1, x20
  c8:	aa1503e0 	mov	x0, x21
  cc:	94000010 	bl	10c <matchhere>
  d0:	350001a0 	cbnz	w0, 104 <matchstar+0x5c>
      return 1;
  }while(*text!='\0' && (*text++==c || c=='.'));
  d4:	39400282 	ldrb	w2, [x20]
  d8:	340000a2 	cbz	w2, ec <matchstar+0x44>
  dc:	6b13005f 	cmp	w2, w19
  e0:	540000e0 	b.eq	fc <matchstar+0x54>  // b.none
  e4:	7100ba7f 	cmp	w19, #0x2e
  e8:	540000a0 	b.eq	fc <matchstar+0x54>  // b.none
  return 0;
}
  ec:	f94013f5 	ldr	x21, [sp, #32]
  f0:	a94153f3 	ldp	x19, x20, [sp, #16]
  f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
  f8:	d65f03c0 	ret
  }while(*text!='\0' && (*text++==c || c=='.'));
  fc:	91000694 	add	x20, x20, #0x1
 100:	17fffff1 	b	c4 <matchstar+0x1c>
      return 1;
 104:	52800020 	mov	w0, #0x1                   	// #1
 108:	17fffff9 	b	ec <matchstar+0x44>

000000000000010c <matchhere>:
{
 10c:	aa0003e3 	mov	x3, x0
 110:	aa0103e2 	mov	x2, x1
  if(re[0] == '\0')
 114:	39400060 	ldrb	w0, [x3]
 118:	34000300 	cbz	w0, 178 <matchhere+0x6c>
  if(re[1] == '*')
 11c:	39400461 	ldrb	w1, [x3, #1]
 120:	7100a83f 	cmp	w1, #0x2a
 124:	54000061 	b.ne	130 <matchhere+0x24>  // b.any
    return matchstar(re[0], re+2, text);
 128:	91000861 	add	x1, x3, #0x2
 12c:	17ffffdf 	b	a8 <matchstar>
  if(re[0] == '$' && re[1] == '\0')
 130:	7100901f 	cmp	w0, #0x24
 134:	540000c1 	b.ne	14c <matchhere+0x40>  // b.any
 138:	350000a1 	cbnz	w1, 14c <matchhere+0x40>
    return *text == '\0';
 13c:	39400040 	ldrb	w0, [x2]
 140:	7100001f 	cmp	w0, #0x0
 144:	1a9f17e0 	cset	w0, eq	// eq = none
}
 148:	d65f03c0 	ret
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
 14c:	39400041 	ldrb	w1, [x2]
 150:	34000101 	cbz	w1, 170 <matchhere+0x64>
 154:	7100b81f 	cmp	w0, #0x2e
 158:	54000060 	b.eq	164 <matchhere+0x58>  // b.none
 15c:	6b01001f 	cmp	w0, w1
 160:	54000081 	b.ne	170 <matchhere+0x64>  // b.any
    return matchhere(re+1, text+1);
 164:	91000463 	add	x3, x3, #0x1
 168:	91000442 	add	x2, x2, #0x1
 16c:	17ffffea 	b	114 <matchhere+0x8>
  return 0;
 170:	52800000 	mov	w0, #0x0                   	// #0
 174:	17fffff5 	b	148 <matchhere+0x3c>
    return 1;
 178:	52800020 	mov	w0, #0x1                   	// #1
 17c:	17fffff3 	b	148 <matchhere+0x3c>

0000000000000180 <match>:
{
 180:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 184:	910003fd 	mov	x29, sp
 188:	a90153f3 	stp	x19, x20, [sp, #16]
 18c:	aa0003f4 	mov	x20, x0
  if(re[0] == '^')
 190:	39400000 	ldrb	w0, [x0]
 194:	7101781f 	cmp	w0, #0x5e
 198:	540000a1 	b.ne	1ac <match+0x2c>  // b.any
    return matchhere(re+1, text);
 19c:	91000680 	add	x0, x20, #0x1
}
 1a0:	a94153f3 	ldp	x19, x20, [sp, #16]
 1a4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    return matchhere(re+1, text);
 1a8:	17ffffd9 	b	10c <matchhere>
 1ac:	aa0103f3 	mov	x19, x1
    if(matchhere(re, text))
 1b0:	aa1303e1 	mov	x1, x19
 1b4:	aa1403e0 	mov	x0, x20
 1b8:	97ffffd5 	bl	10c <matchhere>
 1bc:	35000060 	cbnz	w0, 1c8 <match+0x48>
  }while(*text++ != '\0');
 1c0:	38401661 	ldrb	w1, [x19], #1
 1c4:	35ffff61 	cbnz	w1, 1b0 <match+0x30>
}
 1c8:	a94153f3 	ldp	x19, x20, [sp, #16]
 1cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
 1d0:	d65f03c0 	ret

00000000000001d4 <grep>:
{
 1d4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 1d8:	910003fd 	mov	x29, sp
 1dc:	a90153f3 	stp	x19, x20, [sp, #16]
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 1e0:	90000014 	adrp	x20, 0 <main>
 1e4:	91379a94 	add	x20, x20, #0xde6
{
 1e8:	a90363f7 	stp	x23, x24, [sp, #48]
 1ec:	2a0103f8 	mov	w24, w1
  m = 0;
 1f0:	52800013 	mov	w19, #0x0                   	// #0
{
 1f4:	f9002bfb 	str	x27, [sp, #80]
 1f8:	aa0003fb 	mov	x27, x0
 1fc:	a9025bf5 	stp	x21, x22, [sp, #32]
 200:	a9046bf9 	stp	x25, x26, [sp, #64]
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 204:	52807ff9 	mov	w25, #0x3ff                 	// #1023
    while((q = strchr(p, '\n')) != 0){
 208:	5280015a 	mov	w26, #0xa                   	// #10
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 20c:	4b130322 	sub	w2, w25, w19
 210:	8b33c281 	add	x1, x20, w19, sxtw
 214:	2a1803e0 	mov	w0, w24
 218:	940000f6 	bl	5f0 <read>
 21c:	7100001f 	cmp	w0, #0x0
 220:	5400010c 	b.gt	240 <grep+0x6c>
}
 224:	f9402bfb 	ldr	x27, [sp, #80]
 228:	a94153f3 	ldp	x19, x20, [sp, #16]
 22c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 230:	a94363f7 	ldp	x23, x24, [sp, #48]
 234:	a9446bf9 	ldp	x25, x26, [sp, #64]
 238:	a8c67bfd 	ldp	x29, x30, [sp], #96
 23c:	d65f03c0 	ret
    m += n;
 240:	0b000273 	add	w19, w19, w0
    p = buf;
 244:	aa1403f5 	mov	x21, x20
    buf[m] = '\0';
 248:	3833ca9f 	strb	wzr, [x20, w19, sxtw]
    while((q = strchr(p, '\n')) != 0){
 24c:	aa1503e0 	mov	x0, x21
 250:	52800141 	mov	w1, #0xa                   	// #10
 254:	9400006c 	bl	404 <strchr>
 258:	aa0003f6 	mov	x22, x0
 25c:	b5000140 	cbnz	x0, 284 <grep+0xb0>
    if(m > 0){
 260:	7100027f 	cmp	w19, #0x0
 264:	54fffd4d 	b.le	20c <grep+0x38>
      m -= p - buf;
 268:	cb1402a0 	sub	x0, x21, x20
      memmove(buf, p, m);
 26c:	aa1503e1 	mov	x1, x21
      m -= p - buf;
 270:	4b000273 	sub	w19, w19, w0
      memmove(buf, p, m);
 274:	aa1403e0 	mov	x0, x20
 278:	2a1303e2 	mov	w2, w19
 27c:	940000ac 	bl	52c <memmove>
 280:	17ffffe3 	b	20c <grep+0x38>
      *q = 0;
 284:	aa1603f7 	mov	x23, x22
      if(match(pattern, p)){
 288:	aa1503e1 	mov	x1, x21
 28c:	aa1b03e0 	mov	x0, x27
      *q = 0;
 290:	380016ff 	strb	wzr, [x23], #1
      if(match(pattern, p)){
 294:	97ffffbb 	bl	180 <match>
 298:	340000c0 	cbz	w0, 2b0 <grep+0xdc>
        *q = '\n';
 29c:	390002da 	strb	w26, [x22]
        write(1, p, q+1 - p);
 2a0:	4b1502e2 	sub	w2, w23, w21
 2a4:	aa1503e1 	mov	x1, x21
 2a8:	52800020 	mov	w0, #0x1                   	// #1
 2ac:	940000d4 	bl	5fc <write>
      p = q+1;
 2b0:	aa1703f5 	mov	x21, x23
 2b4:	17ffffe6 	b	24c <grep+0x78>

00000000000002b8 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 2b8:	d2800002 	mov	x2, #0x0                   	// #0
 2bc:	38626823 	ldrb	w3, [x1, x2]
 2c0:	38226803 	strb	w3, [x0, x2]
 2c4:	91000442 	add	x2, x2, #0x1
 2c8:	35ffffa3 	cbnz	w3, 2bc <strcpy+0x4>
    ;
  return os;
}
 2cc:	d65f03c0 	ret

00000000000002d0 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 2d0:	d2800003 	mov	x3, #0x0                   	// #0
 2d4:	4b030044 	sub	w4, w2, w3
 2d8:	7100009f 	cmp	w4, #0x0
 2dc:	5400006d 	b.le	2e8 <strncpy+0x18>
 2e0:	38636825 	ldrb	w5, [x1, x3]
 2e4:	350000e5 	cbnz	w5, 300 <strncpy+0x30>
 2e8:	8b030003 	add	x3, x0, x3
 2ec:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 2f0:	4b010082 	sub	w2, w4, w1
 2f4:	7100005f 	cmp	w2, #0x0
 2f8:	540000ac 	b.gt	30c <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 2fc:	d65f03c0 	ret
    *s++ = *t++;
 300:	38236805 	strb	w5, [x0, x3]
    n--;
 304:	91000463 	add	x3, x3, #0x1
 308:	17fffff3 	b	2d4 <strncpy+0x4>
    *s++ = 0;
 30c:	3821687f 	strb	wzr, [x3, x1]
 310:	91000421 	add	x1, x1, #0x1
 314:	17fffff7 	b	2f0 <strncpy+0x20>

0000000000000318 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 318:	aa0003e2 	mov	x2, x0
 31c:	39400043 	ldrb	w3, [x2]
 320:	aa0203e4 	mov	x4, x2
    s++;
 324:	91000442 	add	x2, x2, #0x1
  while(*s)
 328:	35ffffa3 	cbnz	w3, 31c <strcat+0x4>
 32c:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 330:	38626823 	ldrb	w3, [x1, x2]
 334:	38226883 	strb	w3, [x4, x2]
 338:	91000442 	add	x2, x2, #0x1
 33c:	35ffffa3 	cbnz	w3, 330 <strcat+0x18>
    ;
  return os;
}
 340:	d65f03c0 	ret

0000000000000344 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 344:	d2800002 	mov	x2, #0x0                   	// #0
 348:	38626803 	ldrb	w3, [x0, x2]
 34c:	38626824 	ldrb	w4, [x1, x2]
 350:	34000083 	cbz	w3, 360 <strcmp+0x1c>
 354:	91000442 	add	x2, x2, #0x1
 358:	6b04007f 	cmp	w3, w4
 35c:	54ffff60 	b.eq	348 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 360:	4b040060 	sub	w0, w3, w4
 364:	d65f03c0 	ret

0000000000000368 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 368:	340001c2 	cbz	w2, 3a0 <strncmp+0x38>
 36c:	39400003 	ldrb	w3, [x0]
 370:	34000083 	cbz	w3, 380 <strncmp+0x18>
 374:	39400024 	ldrb	w4, [x1]
 378:	6b03009f 	cmp	w4, w3
 37c:	540000a0 	b.eq	390 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 380:	39400000 	ldrb	w0, [x0]
 384:	39400021 	ldrb	w1, [x1]
 388:	4b010000 	sub	w0, w0, w1
}
 38c:	d65f03c0 	ret
    n--, p++, q++;
 390:	51000442 	sub	w2, w2, #0x1
 394:	91000400 	add	x0, x0, #0x1
 398:	91000421 	add	x1, x1, #0x1
 39c:	17fffff3 	b	368 <strncmp>
    return 0;
 3a0:	52800000 	mov	w0, #0x0                   	// #0
 3a4:	17fffffa 	b	38c <strncmp+0x24>

00000000000003a8 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 3a8:	d1000402 	sub	x2, x0, #0x1
 3ac:	d2800001 	mov	x1, #0x0                   	// #0
 3b0:	aa0103e0 	mov	x0, x1
 3b4:	91000421 	add	x1, x1, #0x1
 3b8:	38616843 	ldrb	w3, [x2, x1]
 3bc:	35ffffa3 	cbnz	w3, 3b0 <strlen+0x8>
    ;
  return n;
}
 3c0:	d65f03c0 	ret

00000000000003c4 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 3c4:	d1000403 	sub	x3, x0, #0x1
 3c8:	d2800002 	mov	x2, #0x0                   	// #0
 3cc:	2a0203e0 	mov	w0, w2
 3d0:	6b02003f 	cmp	w1, w2
 3d4:	54000089 	b.ls	3e4 <strnlen+0x20>  // b.plast
 3d8:	91000442 	add	x2, x2, #0x1
 3dc:	38626864 	ldrb	w4, [x3, x2]
 3e0:	35ffff64 	cbnz	w4, 3cc <strnlen+0x8>
    n++;
  return n;
}
 3e4:	d65f03c0 	ret

00000000000003e8 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 3e8:	d2800003 	mov	x3, #0x0                   	// #0
 3ec:	6b03005f 	cmp	w2, w3
 3f0:	54000048 	b.hi	3f8 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 3f4:	d65f03c0 	ret
    cdst[i] = c;
 3f8:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 3fc:	91000463 	add	x3, x3, #0x1
 400:	17fffffb 	b	3ec <memset+0x4>

0000000000000404 <strchr>:

char*
strchr(const char *s, char c)
{
 404:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 408:	39400002 	ldrb	w2, [x0]
 40c:	35000062 	cbnz	w2, 418 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 410:	d2800000 	mov	x0, #0x0                   	// #0
}
 414:	d65f03c0 	ret
    if(*s == c)
 418:	6b01005f 	cmp	w2, w1
 41c:	54ffffc0 	b.eq	414 <strchr+0x10>  // b.none
  for(; *s; s++)
 420:	91000400 	add	x0, x0, #0x1
 424:	17fffff9 	b	408 <strchr+0x4>

0000000000000428 <gets>:

char*
gets(char *buf, int max)
{
 428:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 42c:	910003fd 	mov	x29, sp
 430:	a90153f3 	stp	x19, x20, [sp, #16]
 434:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 438:	d2800014 	mov	x20, #0x0                   	// #0
{
 43c:	f9001bf7 	str	x23, [sp, #48]
 440:	2a0103f7 	mov	w23, w1
 444:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 448:	11000695 	add	w21, w20, #0x1
 44c:	2a1403f6 	mov	w22, w20
 450:	6b1702bf 	cmp	w21, w23
 454:	540000ea 	b.ge	470 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 458:	91013fe1 	add	x1, sp, #0x4f
 45c:	52800022 	mov	w2, #0x1                   	// #1
 460:	52800000 	mov	w0, #0x0                   	// #0
 464:	94000063 	bl	5f0 <read>
    if(cc < 1)
 468:	7100001f 	cmp	w0, #0x0
 46c:	5400012c 	b.gt	490 <gets+0x68>
  for(i=0; i+1 < max; ){
 470:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 474:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 478:	aa1303e0 	mov	x0, x19
 47c:	f9401bf7 	ldr	x23, [sp, #48]
 480:	a94153f3 	ldp	x19, x20, [sp, #16]
 484:	a9425bf5 	ldp	x21, x22, [sp, #32]
 488:	a8c57bfd 	ldp	x29, x30, [sp], #80
 48c:	d65f03c0 	ret
    buf[i++] = c;
 490:	39413fe0 	ldrb	w0, [sp, #79]
 494:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 498:	91000694 	add	x20, x20, #0x1
 49c:	7100281f 	cmp	w0, #0xa
 4a0:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 4a4:	54fffd21 	b.ne	448 <gets+0x20>  // b.any
 4a8:	17fffff3 	b	474 <gets+0x4c>

00000000000004ac <stat>:

int
stat(const char *n, struct stat *st)
{
 4ac:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 4b0:	910003fd 	mov	x29, sp
 4b4:	a90153f3 	stp	x19, x20, [sp, #16]
 4b8:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 4bc:	52800001 	mov	w1, #0x0                   	// #0
 4c0:	9400005b 	bl	62c <open>
  if(fd < 0)
 4c4:	37f80160 	tbnz	w0, #31, 4f0 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 4c8:	aa1303e1 	mov	x1, x19
 4cc:	2a0003f4 	mov	w20, w0
 4d0:	94000060 	bl	650 <fstat>
 4d4:	2a0003f3 	mov	w19, w0
  close(fd);
 4d8:	2a1403e0 	mov	w0, w20
 4dc:	9400004b 	bl	608 <close>
  return r;
}
 4e0:	2a1303e0 	mov	w0, w19
 4e4:	a94153f3 	ldp	x19, x20, [sp, #16]
 4e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
 4ec:	d65f03c0 	ret
    return -1;
 4f0:	12800013 	mov	w19, #0xffffffff            	// #-1
 4f4:	17fffffb 	b	4e0 <stat+0x34>

00000000000004f8 <atoi>:

int
atoi(const char *s)
{
 4f8:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 4fc:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 500:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 504:	39400043 	ldrb	w3, [x2]
 508:	5100c061 	sub	w1, w3, #0x30
 50c:	12001c21 	and	w1, w1, #0xff
 510:	7100243f 	cmp	w1, #0x9
 514:	54000049 	b.ls	51c <atoi+0x24>  // b.plast
  return n;
}
 518:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 51c:	1b040c01 	madd	w1, w0, w4, w3
 520:	91000442 	add	x2, x2, #0x1
 524:	5100c020 	sub	w0, w1, #0x30
 528:	17fffff7 	b	504 <atoi+0xc>

000000000000052c <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 52c:	eb01001f 	cmp	x0, x1
 530:	54000263 	b.cc	57c <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 534:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 538:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 53c:	d2800003 	mov	x3, #0x0                   	// #0
 540:	d1000463 	sub	x3, x3, #0x1
 544:	11000464 	add	w4, w3, #0x1
 548:	0b020084 	add	w4, w4, w2
 54c:	7100009f 	cmp	w4, #0x0
 550:	5400014d 	b.le	578 <memmove+0x4c>
      *--dst = *--src;
 554:	38636824 	ldrb	w4, [x1, x3]
 558:	382368a4 	strb	w4, [x5, x3]
 55c:	17fffff9 	b	540 <memmove+0x14>
      *dst++ = *src++;
 560:	38636824 	ldrb	w4, [x1, x3]
 564:	38236804 	strb	w4, [x0, x3]
 568:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 56c:	4b030044 	sub	w4, w2, w3
 570:	7100009f 	cmp	w4, #0x0
 574:	54ffff6c 	b.gt	560 <memmove+0x34>
  }
  return vdst;
}
 578:	d65f03c0 	ret
 57c:	d2800003 	mov	x3, #0x0                   	// #0
 580:	17fffffb 	b	56c <memmove+0x40>

0000000000000584 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 584:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 588:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 58c:	d2800004 	mov	x4, #0x0                   	// #0
 590:	eb02009f 	cmp	x4, x2
 594:	54000061 	b.ne	5a0 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 598:	52800000 	mov	w0, #0x0                   	// #0
 59c:	14000007 	b	5b8 <memcmp+0x34>
    if (*p1 != *p2) {
 5a0:	38646803 	ldrb	w3, [x0, x4]
 5a4:	91000484 	add	x4, x4, #0x1
 5a8:	38646825 	ldrb	w5, [x1, x4]
 5ac:	6b05007f 	cmp	w3, w5
 5b0:	54ffff00 	b.eq	590 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 5b4:	4b050060 	sub	w0, w3, w5
}
 5b8:	d65f03c0 	ret

00000000000005bc <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 5bc:	17ffffdc 	b	52c <memmove>

00000000000005c0 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 5c0:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 5c4:	d4000001 	svc	#0x0
 ret
 5c8:	d65f03c0 	ret

00000000000005cc <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 5cc:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 5d0:	d4000001 	svc	#0x0
 ret
 5d4:	d65f03c0 	ret

00000000000005d8 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 5d8:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 5dc:	d4000001 	svc	#0x0
 ret
 5e0:	d65f03c0 	ret

00000000000005e4 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 5e4:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 5e8:	d4000001 	svc	#0x0
 ret
 5ec:	d65f03c0 	ret

00000000000005f0 <read>:
.global read
read:
 mov x7, #SYS_read
 5f0:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 5f4:	d4000001 	svc	#0x0
 ret
 5f8:	d65f03c0 	ret

00000000000005fc <write>:
.global write
write:
 mov x7, #SYS_write
 5fc:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 600:	d4000001 	svc	#0x0
 ret
 604:	d65f03c0 	ret

0000000000000608 <close>:
.global close
close:
 mov x7, #SYS_close
 608:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 60c:	d4000001 	svc	#0x0
 ret
 610:	d65f03c0 	ret

0000000000000614 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 614:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 618:	d4000001 	svc	#0x0
 ret
 61c:	d65f03c0 	ret

0000000000000620 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 620:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 624:	d4000001 	svc	#0x0
 ret
 628:	d65f03c0 	ret

000000000000062c <open>:
.global open
open:
 mov x7, #SYS_open
 62c:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 630:	d4000001 	svc	#0x0
 ret
 634:	d65f03c0 	ret

0000000000000638 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 638:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 63c:	d4000001 	svc	#0x0
 ret
 640:	d65f03c0 	ret

0000000000000644 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 644:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 648:	d4000001 	svc	#0x0
 ret
 64c:	d65f03c0 	ret

0000000000000650 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 650:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 654:	d4000001 	svc	#0x0
 ret
 658:	d65f03c0 	ret

000000000000065c <link>:
.global link
link:
 mov x7, #SYS_link
 65c:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 660:	d4000001 	svc	#0x0
 ret
 664:	d65f03c0 	ret

0000000000000668 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 668:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 66c:	d4000001 	svc	#0x0
 ret
 670:	d65f03c0 	ret

0000000000000674 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 674:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 678:	d4000001 	svc	#0x0
 ret
 67c:	d65f03c0 	ret

0000000000000680 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 680:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 684:	d4000001 	svc	#0x0
 ret
 688:	d65f03c0 	ret

000000000000068c <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 68c:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 690:	d4000001 	svc	#0x0
 ret
 694:	d65f03c0 	ret

0000000000000698 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 698:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 69c:	d4000001 	svc	#0x0
 ret
 6a0:	d65f03c0 	ret

00000000000006a4 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 6a4:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 6a8:	d4000001 	svc	#0x0
 ret
 6ac:	d65f03c0 	ret

00000000000006b0 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 6b0:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 6b4:	d4000001 	svc	#0x0
 ret
 6b8:	d65f03c0 	ret

00000000000006bc <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 6bc:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 6c0:	d4000001 	svc	#0x0
 ret
 6c4:	d65f03c0 	ret

00000000000006c8 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 6c8:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 6cc:	d4000001 	svc	#0x0
 ret
 6d0:	d65f03c0 	ret

00000000000006d4 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 6d4:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 6d8:	d4000001 	svc	#0x0
 ret
 6dc:	d65f03c0 	ret

00000000000006e0 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 6e0:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 6e4:	d4000001 	svc	#0x0
 ret
 6e8:	d65f03c0 	ret

00000000000006ec <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 6ec:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 6f0:	d4000001 	svc	#0x0
 ret
 6f4:	d65f03c0 	ret

00000000000006f8 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 6f8:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 6fc:	d4000001 	svc	#0x0
 ret
 700:	d65f03c0 	ret

0000000000000704 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 704:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 708:	d4000001 	svc	#0x0
 ret
 70c:	d65f03c0 	ret

0000000000000710 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 710:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 714:	d4000001 	svc	#0x0
 ret
 718:	d65f03c0 	ret

000000000000071c <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 71c:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 720:	d4000001 	svc	#0x0
 ret
 724:	d65f03c0 	ret

0000000000000728 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 728:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 72c:	d4000001 	svc	#0x0
 ret
 730:	d65f03c0 	ret

0000000000000734 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 734:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 738:	d4000001 	svc	#0x0
 ret
 73c:	d65f03c0 	ret

0000000000000740 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 740:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 744:	d4000001 	svc	#0x0
 ret
 748:	d65f03c0 	ret

000000000000074c <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 74c:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 750:	d4000001 	svc	#0x0
 ret
 754:	d65f03c0 	ret

0000000000000758 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 758:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 75c:	d4000001 	svc	#0x0
 ret
 760:	d65f03c0 	ret

0000000000000764 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 764:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 768:	d4000001 	svc	#0x0
 ret
 76c:	d65f03c0 	ret

0000000000000770 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 770:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 774:	d4000001 	svc	#0x0
 ret
 778:	d65f03c0 	ret

000000000000077c <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 77c:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 780:	d4000001 	svc	#0x0
 ret
 784:	d65f03c0 	ret

0000000000000788 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 788:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 78c:	d4000001 	svc	#0x0
 ret
 790:	d65f03c0 	ret

0000000000000794 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 794:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 798:	d4000001 	svc	#0x0
 ret
 79c:	d65f03c0 	ret

00000000000007a0 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 7a0:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 7a4:	d4000001 	svc	#0x0
 ret
 7a8:	d65f03c0 	ret

00000000000007ac <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 7ac:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 7b0:	d4000001 	svc	#0x0
 ret
 7b4:	d65f03c0 	ret

00000000000007b8 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 7b8:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 7bc:	d4000001 	svc	#0x0
 ret
 7c0:	d65f03c0 	ret

00000000000007c4 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 7c4:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 7c8:	d4000001 	svc	#0x0
 ret
 7cc:	d65f03c0 	ret

00000000000007d0 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 7d0:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 7d4:	d4000001 	svc	#0x0
 ret
 7d8:	d65f03c0 	ret

00000000000007dc <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 7dc:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 7e0:	d4000001 	svc	#0x0
 ret
 7e4:	d65f03c0 	ret

00000000000007e8 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 7e8:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 7ec:	d4000001 	svc	#0x0
 ret
 7f0:	d65f03c0 	ret

00000000000007f4 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 7f4:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 7f8:	d4000001 	svc	#0x0
 ret
 7fc:	d65f03c0 	ret

0000000000000800 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 800:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 804:	d4000001 	svc	#0x0
 ret
 808:	d65f03c0 	ret

000000000000080c <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 80c:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 810:	d4000001 	svc	#0x0
 ret
 814:	d65f03c0 	ret

0000000000000818 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 818:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 81c:	d4000001 	svc	#0x0
 ret
 820:	d65f03c0 	ret

0000000000000824 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 824:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 828:	d4000001 	svc	#0x0
 ret
 82c:	d65f03c0 	ret

0000000000000830 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 830:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 834:	d4000001 	svc	#0x0
 ret
 838:	d65f03c0 	ret

000000000000083c <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 83c:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 840:	d4000001 	svc	#0x0
 ret
 844:	d65f03c0 	ret

0000000000000848 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 848:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 84c:	d4000001 	svc	#0x0
 ret
 850:	d65f03c0 	ret

0000000000000854 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 854:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 858:	d4000001 	svc	#0x0
 ret
 85c:	d65f03c0 	ret

0000000000000860 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 860:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 864:	d4000001 	svc	#0x0
 ret
 868:	d65f03c0 	ret

000000000000086c <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 86c:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 870:	d4000001 	svc	#0x0
 ret
 874:	d65f03c0 	ret

0000000000000878 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 878:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 87c:	d4000001 	svc	#0x0
 ret
 880:	d65f03c0 	ret

0000000000000884 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 884:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 888:	d4000001 	svc	#0x0
 ret
 88c:	d65f03c0 	ret

0000000000000890 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 890:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 894:	d4000001 	svc	#0x0
 ret
 898:	d65f03c0 	ret

000000000000089c <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 89c:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 8a0:	d4000001 	svc	#0x0
 ret
 8a4:	d65f03c0 	ret

00000000000008a8 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 8a8:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 8ac:	d4000001 	svc	#0x0
 ret
 8b0:	d65f03c0 	ret

00000000000008b4 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 8b4:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 8b8:	d4000001 	svc	#0x0
 ret
 8bc:	d65f03c0 	ret

00000000000008c0 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 8c0:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 8c4:	d4000001 	svc	#0x0
 ret
 8c8:	d65f03c0 	ret

00000000000008cc <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 8cc:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 8d0:	d4000001 	svc	#0x0
 ret
 8d4:	d65f03c0 	ret

00000000000008d8 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 8d8:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 8dc:	d4000001 	svc	#0x0
 ret
 8e0:	d65f03c0 	ret

00000000000008e4 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 8e4:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 8e8:	d4000001 	svc	#0x0
 ret
 8ec:	d65f03c0 	ret

00000000000008f0 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 8f0:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 8f4:	d4000001 	svc	#0x0
 ret
 8f8:	d65f03c0 	ret

00000000000008fc <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 8fc:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 900:	d4000001 	svc	#0x0
 ret
 904:	d65f03c0 	ret

0000000000000908 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 908:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 90c:	d4000001 	svc	#0x0
 ret
 910:	d65f03c0 	ret

0000000000000914 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 914:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 918:	d4000001 	svc	#0x0
 ret
 91c:	d65f03c0 	ret

0000000000000920 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 920:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 924:	d4000001 	svc	#0x0
 ret
 928:	d65f03c0 	ret

000000000000092c <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 92c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 930:	52800022 	mov	w2, #0x1                   	// #1
{
 934:	910003fd 	mov	x29, sp
 938:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 93c:	91007fe1 	add	x1, sp, #0x1f
 940:	97ffff2f 	bl	5fc <write>
 944:	7100041f 	cmp	w0, #0x1
}
 948:	1a9f17e0 	cset	w0, eq	// eq = none
 94c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 950:	d65f03c0 	ret

0000000000000954 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 954:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 958:	910003fd 	mov	x29, sp
 95c:	a90153f3 	stp	x19, x20, [sp, #16]
 960:	a9025bf5 	stp	x21, x22, [sp, #32]
 964:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 968:	6a417c7f 	tst	w3, w1, lsr #31
 96c:	54000300 	b.eq	9cc <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 970:	4b0103e1 	neg	w1, w1
    neg = 1;
 974:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 978:	90000003 	adrp	x3, 0 <main>
 97c:	91375463 	add	x3, x3, #0xdd5
 980:	9100c3f5 	add	x21, sp, #0x30
 984:	d2800000 	mov	x0, #0x0                   	// #0
 988:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 98c:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 990:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 994:	2a0403e1 	mov	w1, w4
 998:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 99c:	38666866 	ldrb	w6, [x3, x6]
 9a0:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 9a4:	91000400 	add	x0, x0, #0x1
 9a8:	54ffff09 	b.ls	988 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 9ac:	11000493 	add	w19, w4, #0x1
  if(neg)
 9b0:	34000085 	cbz	w5, 9c0 <printint+0x6c>
    buf[i++] = '-';
 9b4:	528005a0 	mov	w0, #0x2d                  	// #45
 9b8:	38334aa0 	strb	w0, [x21, w19, uxtw]
 9bc:	11000893 	add	w19, w4, #0x2
 9c0:	51000673 	sub	w19, w19, #0x1
 9c4:	52800014 	mov	w20, #0x0                   	// #0
 9c8:	14000008 	b	9e8 <printint+0x94>
  neg = 0;
 9cc:	52800005 	mov	w5, #0x0                   	// #0
 9d0:	17ffffea 	b	978 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 9d4:	38736aa1 	ldrb	w1, [x21, x19]
 9d8:	2a1603e0 	mov	w0, w22
 9dc:	d1000673 	sub	x19, x19, #0x1
 9e0:	97ffffd3 	bl	92c <putc>
 9e4:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 9e8:	3100067f 	cmn	w19, #0x1
 9ec:	54ffff41 	b.ne	9d4 <printint+0x80>  // b.any
  return written;
}
 9f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
 9f4:	2a1403e0 	mov	w0, w20
 9f8:	a94153f3 	ldp	x19, x20, [sp, #16]
 9fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
 a00:	d65f03c0 	ret

0000000000000a04 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 a04:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 a08:	910003fd 	mov	x29, sp
 a0c:	a90153f3 	stp	x19, x20, [sp, #16]
 a10:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 a14:	52800015 	mov	w21, #0x0                   	// #0
{
 a18:	a90363f7 	stp	x23, x24, [sp, #48]
 a1c:	2a0003f7 	mov	w23, w0
 a20:	a9046bf9 	stp	x25, x26, [sp, #64]
 a24:	aa0103f9 	mov	x25, x1

  state = 0;
 a28:	52800001 	mov	w1, #0x0                   	// #0
{
 a2c:	a90573fb 	stp	x27, x28, [sp, #80]
 a30:	a9406053 	ldp	x19, x24, [x2]
 a34:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 a38:	39400320 	ldrb	w0, [x25]
 a3c:	35000120 	cbnz	w0, a60 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 a40:	2a1503e0 	mov	w0, w21
 a44:	a94153f3 	ldp	x19, x20, [sp, #16]
 a48:	a9425bf5 	ldp	x21, x22, [sp, #32]
 a4c:	a94363f7 	ldp	x23, x24, [sp, #48]
 a50:	a9446bf9 	ldp	x25, x26, [sp, #64]
 a54:	a94573fb 	ldp	x27, x28, [sp, #80]
 a58:	a8c67bfd 	ldp	x29, x30, [sp], #96
 a5c:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 a60:	2a0003f6 	mov	w22, w0
    if(state == 0){
 a64:	35000101 	cbnz	w1, a84 <vprintf+0x80>
      if(c == '%'){
 a68:	7100941f 	cmp	w0, #0x25
 a6c:	54000ba0 	b.eq	be0 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 a70:	2a1603e1 	mov	w1, w22
 a74:	2a1703e0 	mov	w0, w23
 a78:	97ffffad 	bl	92c <putc>
 a7c:	0b0002b5 	add	w21, w21, w0
 a80:	14000057 	b	bdc <vprintf+0x1d8>
      if(c == 'd'){
 a84:	7101901f 	cmp	w0, #0x64
 a88:	540002a1 	b.ne	adc <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 a8c:	37f80174 	tbnz	w20, #31, ab8 <vprintf+0xb4>
 a90:	91002e76 	add	x22, x19, #0xb
 a94:	2a1403fa 	mov	w26, w20
 a98:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a9c:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 aa0:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 aa4:	b9400261 	ldr	w1, [x19]
 aa8:	2a1703e0 	mov	w0, w23
 aac:	97ffffaa 	bl	954 <printint>
        written += putc(fd, va_arg(ap, uint));
 ab0:	0b0002b5 	add	w21, w21, w0
 ab4:	14000048 	b	bd4 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 ab8:	1100229a 	add	w26, w20, #0x8
 abc:	7100035f 	cmp	w26, #0x0
 ac0:	5400008d 	b.le	ad0 <vprintf+0xcc>
 ac4:	91002e76 	add	x22, x19, #0xb
 ac8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 acc:	17fffff4 	b	a9c <vprintf+0x98>
 ad0:	aa1303f6 	mov	x22, x19
 ad4:	8b34c313 	add	x19, x24, w20, sxtw
 ad8:	17fffff1 	b	a9c <vprintf+0x98>
      } else if(c == 'l') {
 adc:	7101b01f 	cmp	w0, #0x6c
 ae0:	54000201 	b.ne	b20 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 ae4:	37f800d4 	tbnz	w20, #31, afc <vprintf+0xf8>
 ae8:	91003e76 	add	x22, x19, #0xf
 aec:	2a1403fa 	mov	w26, w20
 af0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 af4:	52800003 	mov	w3, #0x0                   	// #0
 af8:	17ffffea 	b	aa0 <vprintf+0x9c>
 afc:	1100229a 	add	w26, w20, #0x8
 b00:	7100035f 	cmp	w26, #0x0
 b04:	5400008d 	b.le	b14 <vprintf+0x110>
 b08:	91003e76 	add	x22, x19, #0xf
 b0c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b10:	17fffff9 	b	af4 <vprintf+0xf0>
 b14:	aa1303f6 	mov	x22, x19
 b18:	8b34c313 	add	x19, x24, w20, sxtw
 b1c:	17fffff6 	b	af4 <vprintf+0xf0>
      } else if(c == 'x') {
 b20:	7101e01f 	cmp	w0, #0x78
 b24:	54000221 	b.ne	b68 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 b28:	37f800f4 	tbnz	w20, #31, b44 <vprintf+0x140>
 b2c:	91002e76 	add	x22, x19, #0xb
 b30:	2a1403fa 	mov	w26, w20
 b34:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b38:	52800003 	mov	w3, #0x0                   	// #0
 b3c:	52800202 	mov	w2, #0x10                  	// #16
 b40:	17ffffd9 	b	aa4 <vprintf+0xa0>
 b44:	1100229a 	add	w26, w20, #0x8
 b48:	7100035f 	cmp	w26, #0x0
 b4c:	5400008d 	b.le	b5c <vprintf+0x158>
 b50:	91002e76 	add	x22, x19, #0xb
 b54:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b58:	17fffff8 	b	b38 <vprintf+0x134>
 b5c:	aa1303f6 	mov	x22, x19
 b60:	8b34c313 	add	x19, x24, w20, sxtw
 b64:	17fffff5 	b	b38 <vprintf+0x134>
      } else if(c == 'p') {
 b68:	7101c01f 	cmp	w0, #0x70
 b6c:	54000521 	b.ne	c10 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 b70:	37f803f4 	tbnz	w20, #31, bec <vprintf+0x1e8>
 b74:	91003e76 	add	x22, x19, #0xf
 b78:	2a1403fa 	mov	w26, w20
 b7c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b80:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 b84:	52800601 	mov	w1, #0x30                  	// #48
 b88:	2a1703e0 	mov	w0, w23
 b8c:	97ffff68 	bl	92c <putc>
 b90:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b94:	9000001c 	adrp	x28, 0 <main>
 b98:	9137579c 	add	x28, x28, #0xdd5
  written += putc(fd, 'x');
 b9c:	2a1703e0 	mov	w0, w23
 ba0:	52800f01 	mov	w1, #0x78                  	// #120
 ba4:	97ffff62 	bl	92c <putc>
 ba8:	0b000273 	add	w19, w19, w0
 bac:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 bb0:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 bb4:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 bb8:	38606b81 	ldrb	w1, [x28, x0]
 bbc:	2a1703e0 	mov	w0, w23
 bc0:	97ffff5b 	bl	92c <putc>
 bc4:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 bc8:	71000694 	subs	w20, w20, #0x1
 bcc:	54ffff21 	b.ne	bb0 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 bd0:	0b1302b5 	add	w21, w21, w19
 bd4:	2a1a03f4 	mov	w20, w26
 bd8:	aa1603f3 	mov	x19, x22
      state = 0;
 bdc:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 be0:	91000739 	add	x25, x25, #0x1
  state = 0;
 be4:	2a1603e1 	mov	w1, w22
 be8:	17ffff94 	b	a38 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 bec:	1100229a 	add	w26, w20, #0x8
 bf0:	7100035f 	cmp	w26, #0x0
 bf4:	5400008d 	b.le	c04 <vprintf+0x200>
 bf8:	91003e76 	add	x22, x19, #0xf
 bfc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c00:	17ffffe0 	b	b80 <vprintf+0x17c>
 c04:	aa1303f6 	mov	x22, x19
 c08:	8b34c313 	add	x19, x24, w20, sxtw
 c0c:	17ffffdd 	b	b80 <vprintf+0x17c>
      } else if(c == 's'){
 c10:	7101cc1f 	cmp	w0, #0x73
 c14:	54000381 	b.ne	c84 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 c18:	37f80214 	tbnz	w20, #31, c58 <vprintf+0x254>
 c1c:	91003e61 	add	x1, x19, #0xf
 c20:	aa1303e0 	mov	x0, x19
 c24:	927df033 	and	x19, x1, #0xfffffffffffffff8
 c28:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 c2c:	90000000 	adrp	x0, 0 <main>
 c30:	91373800 	add	x0, x0, #0xdce
 c34:	f10002df 	cmp	x22, #0x0
 c38:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 c3c:	394002c1 	ldrb	w1, [x22]
 c40:	34fffce1 	cbz	w1, bdc <vprintf+0x1d8>
          written += putc(fd, *s);
 c44:	2a1703e0 	mov	w0, w23
          s++;
 c48:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 c4c:	97ffff38 	bl	92c <putc>
 c50:	0b0002b5 	add	w21, w21, w0
          s++;
 c54:	17fffffa 	b	c3c <vprintf+0x238>
        s = va_arg(ap, char*);
 c58:	11002281 	add	w1, w20, #0x8
 c5c:	7100003f 	cmp	w1, #0x0
 c60:	540000cd 	b.le	c78 <vprintf+0x274>
 c64:	91003e62 	add	x2, x19, #0xf
 c68:	aa1303e0 	mov	x0, x19
 c6c:	2a0103f4 	mov	w20, w1
 c70:	927df053 	and	x19, x2, #0xfffffffffffffff8
 c74:	17ffffed 	b	c28 <vprintf+0x224>
 c78:	8b34c300 	add	x0, x24, w20, sxtw
 c7c:	2a0103f4 	mov	w20, w1
 c80:	17ffffea 	b	c28 <vprintf+0x224>
      } else if(c == 'c'){
 c84:	71018c1f 	cmp	w0, #0x63
 c88:	54000241 	b.ne	cd0 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 c8c:	37f80114 	tbnz	w20, #31, cac <vprintf+0x2a8>
 c90:	91002e76 	add	x22, x19, #0xb
 c94:	2a1403fa 	mov	w26, w20
 c98:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c9c:	39400261 	ldrb	w1, [x19]
 ca0:	2a1703e0 	mov	w0, w23
 ca4:	97ffff22 	bl	92c <putc>
 ca8:	17ffff82 	b	ab0 <vprintf+0xac>
 cac:	1100229a 	add	w26, w20, #0x8
 cb0:	7100035f 	cmp	w26, #0x0
 cb4:	5400008d 	b.le	cc4 <vprintf+0x2c0>
 cb8:	91002e76 	add	x22, x19, #0xb
 cbc:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 cc0:	17fffff7 	b	c9c <vprintf+0x298>
 cc4:	aa1303f6 	mov	x22, x19
 cc8:	8b34c313 	add	x19, x24, w20, sxtw
 ccc:	17fffff4 	b	c9c <vprintf+0x298>
      } else if(c == '%'){
 cd0:	7100941f 	cmp	w0, #0x25
 cd4:	54ffece0 	b.eq	a70 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 cd8:	2a1703e0 	mov	w0, w23
 cdc:	528004a1 	mov	w1, #0x25                  	// #37
 ce0:	97ffff13 	bl	92c <putc>
 ce4:	0b0002b5 	add	w21, w21, w0
 ce8:	17ffff62 	b	a70 <vprintf+0x6c>

0000000000000cec <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 cec:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 cf0:	910003fd 	mov	x29, sp
 cf4:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 cf8:	910203e2 	add	x2, sp, #0x80
 cfc:	a9030be2 	stp	x2, x2, [sp, #48]
 d00:	910143e2 	add	x2, sp, #0x50
 d04:	f90023e2 	str	x2, [sp, #64]
 d08:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 d0c:	b9004be2 	str	w2, [sp, #72]
 d10:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 d14:	a9430fe2 	ldp	x2, x3, [sp, #48]
 d18:	a9010fe2 	stp	x2, x3, [sp, #16]
 d1c:	a9440fe2 	ldp	x2, x3, [sp, #64]
 d20:	a9020fe2 	stp	x2, x3, [sp, #32]
 d24:	910043e2 	add	x2, sp, #0x10
{
 d28:	a90617e4 	stp	x4, x5, [sp, #96]
 d2c:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 d30:	97ffff35 	bl	a04 <vprintf>
  va_end(ap);
  return result;
}
 d34:	a8c87bfd 	ldp	x29, x30, [sp], #128
 d38:	d65f03c0 	ret

0000000000000d3c <printf>:

int
printf(const char *fmt, ...)
{
 d3c:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 d40:	910003fd 	mov	x29, sp
 d44:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 d48:	910243e1 	add	x1, sp, #0x90
 d4c:	a90307e1 	stp	x1, x1, [sp, #48]
 d50:	910143e1 	add	x1, sp, #0x50
 d54:	f90023e1 	str	x1, [sp, #64]
 d58:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 d5c:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 d60:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 d64:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 d68:	52800020 	mov	w0, #0x1                   	// #1
{
 d6c:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 d70:	a9430fe2 	ldp	x2, x3, [sp, #48]
 d74:	a9010fe2 	stp	x2, x3, [sp, #16]
 d78:	a9440fe2 	ldp	x2, x3, [sp, #64]
 d7c:	a9020fe2 	stp	x2, x3, [sp, #32]
 d80:	910043e2 	add	x2, sp, #0x10
{
 d84:	a9079be5 	stp	x5, x6, [sp, #120]
 d88:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 d8c:	97ffff1e 	bl	a04 <vprintf>
  va_end(ap);
  return result;
}
 d90:	a8c97bfd 	ldp	x29, x30, [sp], #144
 d94:	d65f03c0 	ret
