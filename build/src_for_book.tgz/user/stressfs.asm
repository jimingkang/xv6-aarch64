
user/_stressfs:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/fs.h"
#include "kernel/fcntl.h"

int
main(int argc, char *argv[])
{
   0:	d108c3ff 	sub	sp, sp, #0x230
  int fd, i;
  char path[] = "stressfs0";
   4:	90000000 	adrp	x0, 0 <main>
   8:	91300c00 	add	x0, x0, #0xc03
{
   c:	a9007bfd 	stp	x29, x30, [sp]
  10:	910003fd 	mov	x29, sp
  char path[] = "stressfs0";
  14:	f9400001 	ldr	x1, [x0]
{
  18:	a90153f3 	stp	x19, x20, [sp, #16]
  char path[] = "stressfs0";
  1c:	79401000 	ldrh	w0, [x0, #8]
  20:	f90013e1 	str	x1, [sp, #32]
  char data[512];

  printf("stressfs starting\n");
  memset(data, 'a', sizeof(data));

  for(i = 0; i < 4; i++)
  24:	52800013 	mov	w19, #0x0                   	// #0
  char path[] = "stressfs0";
  28:	790053e0 	strh	w0, [sp, #40]
  printf("stressfs starting\n");
  2c:	90000000 	adrp	x0, 0 <main>
  30:	912f8000 	add	x0, x0, #0xbe0
  34:	940002d4 	bl	b84 <printf>
  memset(data, 'a', sizeof(data));
  38:	9100c3e0 	add	x0, sp, #0x30
  3c:	52804002 	mov	w2, #0x200                 	// #512
  40:	52800c21 	mov	w1, #0x61                  	// #97
  44:	9400007b 	bl	230 <memset>
    if(fork() > 0)
  48:	940000f0 	bl	408 <fork>
  4c:	7100001f 	cmp	w0, #0x0
  50:	5400008c 	b.gt	60 <main+0x60>
  for(i = 0; i < 4; i++)
  54:	11000673 	add	w19, w19, #0x1
  58:	7100127f 	cmp	w19, #0x4
  5c:	54ffff61 	b.ne	48 <main+0x48>  // b.any
      break;

  printf("write %d\n", i);
  60:	2a1303e1 	mov	w1, w19
  64:	90000000 	adrp	x0, 0 <main>
  68:	912fcc00 	add	x0, x0, #0xbf3
  6c:	940002c6 	bl	b84 <printf>

  path[8] += i;
  70:	3940a3e0 	ldrb	w0, [sp, #40]
  fd = open(path, O_CREATE | O_RDWR);
  74:	52804041 	mov	w1, #0x202                 	// #514
  path[8] += i;
  78:	0b000273 	add	w19, w19, w0
  fd = open(path, O_CREATE | O_RDWR);
  7c:	910083e0 	add	x0, sp, #0x20
  path[8] += i;
  80:	3900a3f3 	strb	w19, [sp, #40]
  fd = open(path, O_CREATE | O_RDWR);
  84:	940000fc 	bl	474 <open>
  88:	2a0003f4 	mov	w20, w0
  8c:	52800293 	mov	w19, #0x14                  	// #20
  for(i = 0; i < 20; i++)
//    printf(fd, "%d\n", i);
    write(fd, data, sizeof(data));
  90:	9100c3e1 	add	x1, sp, #0x30
  94:	2a1403e0 	mov	w0, w20
  98:	52804002 	mov	w2, #0x200                 	// #512
  9c:	940000ea 	bl	444 <write>
  for(i = 0; i < 20; i++)
  a0:	71000673 	subs	w19, w19, #0x1
  a4:	54ffff61 	b.ne	90 <main+0x90>  // b.any
  close(fd);
  a8:	2a1403e0 	mov	w0, w20
  ac:	940000e9 	bl	450 <close>

  printf("read\n");
  b0:	90000000 	adrp	x0, 0 <main>
  b4:	912ff400 	add	x0, x0, #0xbfd
  b8:	940002b3 	bl	b84 <printf>

  fd = open(path, O_RDONLY);
  bc:	52800293 	mov	w19, #0x14                  	// #20
  c0:	910083e0 	add	x0, sp, #0x20
  c4:	52800001 	mov	w1, #0x0                   	// #0
  c8:	940000eb 	bl	474 <open>
  cc:	2a0003f4 	mov	w20, w0
  for (i = 0; i < 20; i++)
    read(fd, data, sizeof(data));
  d0:	9100c3e1 	add	x1, sp, #0x30
  d4:	2a1403e0 	mov	w0, w20
  d8:	52804002 	mov	w2, #0x200                 	// #512
  dc:	940000d7 	bl	438 <read>
  for (i = 0; i < 20; i++)
  e0:	71000673 	subs	w19, w19, #0x1
  e4:	54ffff61 	b.ne	d0 <main+0xd0>  // b.any
  close(fd);
  e8:	2a1403e0 	mov	w0, w20
  ec:	940000d9 	bl	450 <close>

  wait(0);
  f0:	d2800000 	mov	x0, #0x0                   	// #0
  f4:	940000cb 	bl	420 <wait>

  exit(0);
  f8:	52800000 	mov	w0, #0x0                   	// #0
  fc:	940000c6 	bl	414 <exit>

0000000000000100 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 100:	d2800002 	mov	x2, #0x0                   	// #0
 104:	38626823 	ldrb	w3, [x1, x2]
 108:	38226803 	strb	w3, [x0, x2]
 10c:	91000442 	add	x2, x2, #0x1
 110:	35ffffa3 	cbnz	w3, 104 <strcpy+0x4>
    ;
  return os;
}
 114:	d65f03c0 	ret

0000000000000118 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 118:	d2800003 	mov	x3, #0x0                   	// #0
 11c:	4b030044 	sub	w4, w2, w3
 120:	7100009f 	cmp	w4, #0x0
 124:	5400006d 	b.le	130 <strncpy+0x18>
 128:	38636825 	ldrb	w5, [x1, x3]
 12c:	350000e5 	cbnz	w5, 148 <strncpy+0x30>
 130:	8b030003 	add	x3, x0, x3
 134:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 138:	4b010082 	sub	w2, w4, w1
 13c:	7100005f 	cmp	w2, #0x0
 140:	540000ac 	b.gt	154 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 144:	d65f03c0 	ret
    *s++ = *t++;
 148:	38236805 	strb	w5, [x0, x3]
    n--;
 14c:	91000463 	add	x3, x3, #0x1
 150:	17fffff3 	b	11c <strncpy+0x4>
    *s++ = 0;
 154:	3821687f 	strb	wzr, [x3, x1]
 158:	91000421 	add	x1, x1, #0x1
 15c:	17fffff7 	b	138 <strncpy+0x20>

0000000000000160 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 160:	aa0003e2 	mov	x2, x0
 164:	39400043 	ldrb	w3, [x2]
 168:	aa0203e4 	mov	x4, x2
    s++;
 16c:	91000442 	add	x2, x2, #0x1
  while(*s)
 170:	35ffffa3 	cbnz	w3, 164 <strcat+0x4>
 174:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 178:	38626823 	ldrb	w3, [x1, x2]
 17c:	38226883 	strb	w3, [x4, x2]
 180:	91000442 	add	x2, x2, #0x1
 184:	35ffffa3 	cbnz	w3, 178 <strcat+0x18>
    ;
  return os;
}
 188:	d65f03c0 	ret

000000000000018c <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 18c:	d2800002 	mov	x2, #0x0                   	// #0
 190:	38626803 	ldrb	w3, [x0, x2]
 194:	38626824 	ldrb	w4, [x1, x2]
 198:	34000083 	cbz	w3, 1a8 <strcmp+0x1c>
 19c:	91000442 	add	x2, x2, #0x1
 1a0:	6b04007f 	cmp	w3, w4
 1a4:	54ffff60 	b.eq	190 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 1a8:	4b040060 	sub	w0, w3, w4
 1ac:	d65f03c0 	ret

00000000000001b0 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 1b0:	340001c2 	cbz	w2, 1e8 <strncmp+0x38>
 1b4:	39400003 	ldrb	w3, [x0]
 1b8:	34000083 	cbz	w3, 1c8 <strncmp+0x18>
 1bc:	39400024 	ldrb	w4, [x1]
 1c0:	6b03009f 	cmp	w4, w3
 1c4:	540000a0 	b.eq	1d8 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 1c8:	39400000 	ldrb	w0, [x0]
 1cc:	39400021 	ldrb	w1, [x1]
 1d0:	4b010000 	sub	w0, w0, w1
}
 1d4:	d65f03c0 	ret
    n--, p++, q++;
 1d8:	51000442 	sub	w2, w2, #0x1
 1dc:	91000400 	add	x0, x0, #0x1
 1e0:	91000421 	add	x1, x1, #0x1
 1e4:	17fffff3 	b	1b0 <strncmp>
    return 0;
 1e8:	52800000 	mov	w0, #0x0                   	// #0
 1ec:	17fffffa 	b	1d4 <strncmp+0x24>

00000000000001f0 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 1f0:	d1000402 	sub	x2, x0, #0x1
 1f4:	d2800001 	mov	x1, #0x0                   	// #0
 1f8:	aa0103e0 	mov	x0, x1
 1fc:	91000421 	add	x1, x1, #0x1
 200:	38616843 	ldrb	w3, [x2, x1]
 204:	35ffffa3 	cbnz	w3, 1f8 <strlen+0x8>
    ;
  return n;
}
 208:	d65f03c0 	ret

000000000000020c <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 20c:	d1000403 	sub	x3, x0, #0x1
 210:	d2800002 	mov	x2, #0x0                   	// #0
 214:	2a0203e0 	mov	w0, w2
 218:	6b02003f 	cmp	w1, w2
 21c:	54000089 	b.ls	22c <strnlen+0x20>  // b.plast
 220:	91000442 	add	x2, x2, #0x1
 224:	38626864 	ldrb	w4, [x3, x2]
 228:	35ffff64 	cbnz	w4, 214 <strnlen+0x8>
    n++;
  return n;
}
 22c:	d65f03c0 	ret

0000000000000230 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 230:	d2800003 	mov	x3, #0x0                   	// #0
 234:	6b03005f 	cmp	w2, w3
 238:	54000048 	b.hi	240 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 23c:	d65f03c0 	ret
    cdst[i] = c;
 240:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 244:	91000463 	add	x3, x3, #0x1
 248:	17fffffb 	b	234 <memset+0x4>

000000000000024c <strchr>:

char*
strchr(const char *s, char c)
{
 24c:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 250:	39400002 	ldrb	w2, [x0]
 254:	35000062 	cbnz	w2, 260 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 258:	d2800000 	mov	x0, #0x0                   	// #0
}
 25c:	d65f03c0 	ret
    if(*s == c)
 260:	6b01005f 	cmp	w2, w1
 264:	54ffffc0 	b.eq	25c <strchr+0x10>  // b.none
  for(; *s; s++)
 268:	91000400 	add	x0, x0, #0x1
 26c:	17fffff9 	b	250 <strchr+0x4>

0000000000000270 <gets>:

char*
gets(char *buf, int max)
{
 270:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 274:	910003fd 	mov	x29, sp
 278:	a90153f3 	stp	x19, x20, [sp, #16]
 27c:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 280:	d2800014 	mov	x20, #0x0                   	// #0
{
 284:	f9001bf7 	str	x23, [sp, #48]
 288:	2a0103f7 	mov	w23, w1
 28c:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 290:	11000695 	add	w21, w20, #0x1
 294:	2a1403f6 	mov	w22, w20
 298:	6b1702bf 	cmp	w21, w23
 29c:	540000ea 	b.ge	2b8 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 2a0:	91013fe1 	add	x1, sp, #0x4f
 2a4:	52800022 	mov	w2, #0x1                   	// #1
 2a8:	52800000 	mov	w0, #0x0                   	// #0
 2ac:	94000063 	bl	438 <read>
    if(cc < 1)
 2b0:	7100001f 	cmp	w0, #0x0
 2b4:	5400012c 	b.gt	2d8 <gets+0x68>
  for(i=0; i+1 < max; ){
 2b8:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 2bc:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 2c0:	aa1303e0 	mov	x0, x19
 2c4:	f9401bf7 	ldr	x23, [sp, #48]
 2c8:	a94153f3 	ldp	x19, x20, [sp, #16]
 2cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
 2d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
 2d4:	d65f03c0 	ret
    buf[i++] = c;
 2d8:	39413fe0 	ldrb	w0, [sp, #79]
 2dc:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 2e0:	91000694 	add	x20, x20, #0x1
 2e4:	7100281f 	cmp	w0, #0xa
 2e8:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 2ec:	54fffd21 	b.ne	290 <gets+0x20>  // b.any
 2f0:	17fffff3 	b	2bc <gets+0x4c>

00000000000002f4 <stat>:

int
stat(const char *n, struct stat *st)
{
 2f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 2f8:	910003fd 	mov	x29, sp
 2fc:	a90153f3 	stp	x19, x20, [sp, #16]
 300:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 304:	52800001 	mov	w1, #0x0                   	// #0
 308:	9400005b 	bl	474 <open>
  if(fd < 0)
 30c:	37f80160 	tbnz	w0, #31, 338 <stat+0x44>
    return -1;
  r = fstat(fd, st);
 310:	aa1303e1 	mov	x1, x19
 314:	2a0003f4 	mov	w20, w0
 318:	94000060 	bl	498 <fstat>
 31c:	2a0003f3 	mov	w19, w0
  close(fd);
 320:	2a1403e0 	mov	w0, w20
 324:	9400004b 	bl	450 <close>
  return r;
}
 328:	2a1303e0 	mov	w0, w19
 32c:	a94153f3 	ldp	x19, x20, [sp, #16]
 330:	a8c27bfd 	ldp	x29, x30, [sp], #32
 334:	d65f03c0 	ret
    return -1;
 338:	12800013 	mov	w19, #0xffffffff            	// #-1
 33c:	17fffffb 	b	328 <stat+0x34>

0000000000000340 <atoi>:

int
atoi(const char *s)
{
 340:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 344:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 348:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 34c:	39400043 	ldrb	w3, [x2]
 350:	5100c061 	sub	w1, w3, #0x30
 354:	12001c21 	and	w1, w1, #0xff
 358:	7100243f 	cmp	w1, #0x9
 35c:	54000049 	b.ls	364 <atoi+0x24>  // b.plast
  return n;
}
 360:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 364:	1b040c01 	madd	w1, w0, w4, w3
 368:	91000442 	add	x2, x2, #0x1
 36c:	5100c020 	sub	w0, w1, #0x30
 370:	17fffff7 	b	34c <atoi+0xc>

0000000000000374 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 374:	eb01001f 	cmp	x0, x1
 378:	54000263 	b.cc	3c4 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 37c:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 380:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 384:	d2800003 	mov	x3, #0x0                   	// #0
 388:	d1000463 	sub	x3, x3, #0x1
 38c:	11000464 	add	w4, w3, #0x1
 390:	0b020084 	add	w4, w4, w2
 394:	7100009f 	cmp	w4, #0x0
 398:	5400014d 	b.le	3c0 <memmove+0x4c>
      *--dst = *--src;
 39c:	38636824 	ldrb	w4, [x1, x3]
 3a0:	382368a4 	strb	w4, [x5, x3]
 3a4:	17fffff9 	b	388 <memmove+0x14>
      *dst++ = *src++;
 3a8:	38636824 	ldrb	w4, [x1, x3]
 3ac:	38236804 	strb	w4, [x0, x3]
 3b0:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 3b4:	4b030044 	sub	w4, w2, w3
 3b8:	7100009f 	cmp	w4, #0x0
 3bc:	54ffff6c 	b.gt	3a8 <memmove+0x34>
  }
  return vdst;
}
 3c0:	d65f03c0 	ret
 3c4:	d2800003 	mov	x3, #0x0                   	// #0
 3c8:	17fffffb 	b	3b4 <memmove+0x40>

00000000000003cc <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3cc:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 3d0:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 3d4:	d2800004 	mov	x4, #0x0                   	// #0
 3d8:	eb02009f 	cmp	x4, x2
 3dc:	54000061 	b.ne	3e8 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 3e0:	52800000 	mov	w0, #0x0                   	// #0
 3e4:	14000007 	b	400 <memcmp+0x34>
    if (*p1 != *p2) {
 3e8:	38646803 	ldrb	w3, [x0, x4]
 3ec:	91000484 	add	x4, x4, #0x1
 3f0:	38646825 	ldrb	w5, [x1, x4]
 3f4:	6b05007f 	cmp	w3, w5
 3f8:	54ffff00 	b.eq	3d8 <memcmp+0xc>  // b.none
      return *p1 - *p2;
 3fc:	4b050060 	sub	w0, w3, w5
}
 400:	d65f03c0 	ret

0000000000000404 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 404:	17ffffdc 	b	374 <memmove>

0000000000000408 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 408:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 40c:	d4000001 	svc	#0x0
 ret
 410:	d65f03c0 	ret

0000000000000414 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 414:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 418:	d4000001 	svc	#0x0
 ret
 41c:	d65f03c0 	ret

0000000000000420 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 420:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 424:	d4000001 	svc	#0x0
 ret
 428:	d65f03c0 	ret

000000000000042c <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 42c:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 430:	d4000001 	svc	#0x0
 ret
 434:	d65f03c0 	ret

0000000000000438 <read>:
.global read
read:
 mov x7, #SYS_read
 438:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 43c:	d4000001 	svc	#0x0
 ret
 440:	d65f03c0 	ret

0000000000000444 <write>:
.global write
write:
 mov x7, #SYS_write
 444:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 448:	d4000001 	svc	#0x0
 ret
 44c:	d65f03c0 	ret

0000000000000450 <close>:
.global close
close:
 mov x7, #SYS_close
 450:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 454:	d4000001 	svc	#0x0
 ret
 458:	d65f03c0 	ret

000000000000045c <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 45c:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 460:	d4000001 	svc	#0x0
 ret
 464:	d65f03c0 	ret

0000000000000468 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 468:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 46c:	d4000001 	svc	#0x0
 ret
 470:	d65f03c0 	ret

0000000000000474 <open>:
.global open
open:
 mov x7, #SYS_open
 474:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 478:	d4000001 	svc	#0x0
 ret
 47c:	d65f03c0 	ret

0000000000000480 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 480:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 484:	d4000001 	svc	#0x0
 ret
 488:	d65f03c0 	ret

000000000000048c <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 48c:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 490:	d4000001 	svc	#0x0
 ret
 494:	d65f03c0 	ret

0000000000000498 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 498:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 49c:	d4000001 	svc	#0x0
 ret
 4a0:	d65f03c0 	ret

00000000000004a4 <link>:
.global link
link:
 mov x7, #SYS_link
 4a4:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 4a8:	d4000001 	svc	#0x0
 ret
 4ac:	d65f03c0 	ret

00000000000004b0 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 4b0:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 4b4:	d4000001 	svc	#0x0
 ret
 4b8:	d65f03c0 	ret

00000000000004bc <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 4bc:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 4c0:	d4000001 	svc	#0x0
 ret
 4c4:	d65f03c0 	ret

00000000000004c8 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 4c8:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 4cc:	d4000001 	svc	#0x0
 ret
 4d0:	d65f03c0 	ret

00000000000004d4 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 4d4:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 4d8:	d4000001 	svc	#0x0
 ret
 4dc:	d65f03c0 	ret

00000000000004e0 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 4e0:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 4e4:	d4000001 	svc	#0x0
 ret
 4e8:	d65f03c0 	ret

00000000000004ec <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 4ec:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 4f0:	d4000001 	svc	#0x0
 ret
 4f4:	d65f03c0 	ret

00000000000004f8 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 4f8:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 4fc:	d4000001 	svc	#0x0
 ret
 500:	d65f03c0 	ret

0000000000000504 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 504:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 508:	d4000001 	svc	#0x0
 ret
 50c:	d65f03c0 	ret

0000000000000510 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 510:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 514:	d4000001 	svc	#0x0
 ret
 518:	d65f03c0 	ret

000000000000051c <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 51c:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 520:	d4000001 	svc	#0x0
 ret
 524:	d65f03c0 	ret

0000000000000528 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 528:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 52c:	d4000001 	svc	#0x0
 ret
 530:	d65f03c0 	ret

0000000000000534 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 534:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 538:	d4000001 	svc	#0x0
 ret
 53c:	d65f03c0 	ret

0000000000000540 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 540:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 544:	d4000001 	svc	#0x0
 ret
 548:	d65f03c0 	ret

000000000000054c <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 54c:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 550:	d4000001 	svc	#0x0
 ret
 554:	d65f03c0 	ret

0000000000000558 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 558:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 55c:	d4000001 	svc	#0x0
 ret
 560:	d65f03c0 	ret

0000000000000564 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 564:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 568:	d4000001 	svc	#0x0
 ret
 56c:	d65f03c0 	ret

0000000000000570 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 570:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 574:	d4000001 	svc	#0x0
 ret
 578:	d65f03c0 	ret

000000000000057c <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 57c:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 580:	d4000001 	svc	#0x0
 ret
 584:	d65f03c0 	ret

0000000000000588 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 588:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 58c:	d4000001 	svc	#0x0
 ret
 590:	d65f03c0 	ret

0000000000000594 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 594:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 598:	d4000001 	svc	#0x0
 ret
 59c:	d65f03c0 	ret

00000000000005a0 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 5a0:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 5a4:	d4000001 	svc	#0x0
 ret
 5a8:	d65f03c0 	ret

00000000000005ac <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 5ac:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 5b0:	d4000001 	svc	#0x0
 ret
 5b4:	d65f03c0 	ret

00000000000005b8 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 5b8:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 5bc:	d4000001 	svc	#0x0
 ret
 5c0:	d65f03c0 	ret

00000000000005c4 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 5c4:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 5c8:	d4000001 	svc	#0x0
 ret
 5cc:	d65f03c0 	ret

00000000000005d0 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 5d0:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 5d4:	d4000001 	svc	#0x0
 ret
 5d8:	d65f03c0 	ret

00000000000005dc <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 5dc:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 5e0:	d4000001 	svc	#0x0
 ret
 5e4:	d65f03c0 	ret

00000000000005e8 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 5e8:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 5ec:	d4000001 	svc	#0x0
 ret
 5f0:	d65f03c0 	ret

00000000000005f4 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 5f4:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 5f8:	d4000001 	svc	#0x0
 ret
 5fc:	d65f03c0 	ret

0000000000000600 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 600:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 604:	d4000001 	svc	#0x0
 ret
 608:	d65f03c0 	ret

000000000000060c <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 60c:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 610:	d4000001 	svc	#0x0
 ret
 614:	d65f03c0 	ret

0000000000000618 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 618:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 61c:	d4000001 	svc	#0x0
 ret
 620:	d65f03c0 	ret

0000000000000624 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 624:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 628:	d4000001 	svc	#0x0
 ret
 62c:	d65f03c0 	ret

0000000000000630 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 630:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 634:	d4000001 	svc	#0x0
 ret
 638:	d65f03c0 	ret

000000000000063c <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 63c:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 640:	d4000001 	svc	#0x0
 ret
 644:	d65f03c0 	ret

0000000000000648 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 648:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 64c:	d4000001 	svc	#0x0
 ret
 650:	d65f03c0 	ret

0000000000000654 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 654:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 658:	d4000001 	svc	#0x0
 ret
 65c:	d65f03c0 	ret

0000000000000660 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 660:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 664:	d4000001 	svc	#0x0
 ret
 668:	d65f03c0 	ret

000000000000066c <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 66c:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 670:	d4000001 	svc	#0x0
 ret
 674:	d65f03c0 	ret

0000000000000678 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 678:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 67c:	d4000001 	svc	#0x0
 ret
 680:	d65f03c0 	ret

0000000000000684 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 684:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 688:	d4000001 	svc	#0x0
 ret
 68c:	d65f03c0 	ret

0000000000000690 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 690:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 694:	d4000001 	svc	#0x0
 ret
 698:	d65f03c0 	ret

000000000000069c <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 69c:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 6a0:	d4000001 	svc	#0x0
 ret
 6a4:	d65f03c0 	ret

00000000000006a8 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 6a8:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 6ac:	d4000001 	svc	#0x0
 ret
 6b0:	d65f03c0 	ret

00000000000006b4 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 6b4:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 6b8:	d4000001 	svc	#0x0
 ret
 6bc:	d65f03c0 	ret

00000000000006c0 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 6c0:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 6c4:	d4000001 	svc	#0x0
 ret
 6c8:	d65f03c0 	ret

00000000000006cc <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 6cc:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 6d0:	d4000001 	svc	#0x0
 ret
 6d4:	d65f03c0 	ret

00000000000006d8 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 6d8:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 6dc:	d4000001 	svc	#0x0
 ret
 6e0:	d65f03c0 	ret

00000000000006e4 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 6e4:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 6e8:	d4000001 	svc	#0x0
 ret
 6ec:	d65f03c0 	ret

00000000000006f0 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 6f0:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 6f4:	d4000001 	svc	#0x0
 ret
 6f8:	d65f03c0 	ret

00000000000006fc <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 6fc:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 700:	d4000001 	svc	#0x0
 ret
 704:	d65f03c0 	ret

0000000000000708 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 708:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 70c:	d4000001 	svc	#0x0
 ret
 710:	d65f03c0 	ret

0000000000000714 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 714:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 718:	d4000001 	svc	#0x0
 ret
 71c:	d65f03c0 	ret

0000000000000720 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 720:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 724:	d4000001 	svc	#0x0
 ret
 728:	d65f03c0 	ret

000000000000072c <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 72c:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 730:	d4000001 	svc	#0x0
 ret
 734:	d65f03c0 	ret

0000000000000738 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 738:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 73c:	d4000001 	svc	#0x0
 ret
 740:	d65f03c0 	ret

0000000000000744 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 744:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 748:	d4000001 	svc	#0x0
 ret
 74c:	d65f03c0 	ret

0000000000000750 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 750:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 754:	d4000001 	svc	#0x0
 ret
 758:	d65f03c0 	ret

000000000000075c <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 75c:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 760:	d4000001 	svc	#0x0
 ret
 764:	d65f03c0 	ret

0000000000000768 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 768:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 76c:	d4000001 	svc	#0x0
 ret
 770:	d65f03c0 	ret

0000000000000774 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 778:	52800022 	mov	w2, #0x1                   	// #1
{
 77c:	910003fd 	mov	x29, sp
 780:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 784:	91007fe1 	add	x1, sp, #0x1f
 788:	97ffff2f 	bl	444 <write>
 78c:	7100041f 	cmp	w0, #0x1
}
 790:	1a9f17e0 	cset	w0, eq	// eq = none
 794:	a8c27bfd 	ldp	x29, x30, [sp], #32
 798:	d65f03c0 	ret

000000000000079c <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 79c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 7a0:	910003fd 	mov	x29, sp
 7a4:	a90153f3 	stp	x19, x20, [sp, #16]
 7a8:	a9025bf5 	stp	x21, x22, [sp, #32]
 7ac:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 7b0:	6a417c7f 	tst	w3, w1, lsr #31
 7b4:	54000300 	b.eq	814 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 7b8:	4b0103e1 	neg	w1, w1
    neg = 1;
 7bc:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 7c0:	90000003 	adrp	x3, 0 <main>
 7c4:	91305063 	add	x3, x3, #0xc14
 7c8:	9100c3f5 	add	x21, sp, #0x30
 7cc:	d2800000 	mov	x0, #0x0                   	// #0
 7d0:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 7d4:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 7d8:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 7dc:	2a0403e1 	mov	w1, w4
 7e0:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 7e4:	38666866 	ldrb	w6, [x3, x6]
 7e8:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 7ec:	91000400 	add	x0, x0, #0x1
 7f0:	54ffff09 	b.ls	7d0 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 7f4:	11000493 	add	w19, w4, #0x1
  if(neg)
 7f8:	34000085 	cbz	w5, 808 <printint+0x6c>
    buf[i++] = '-';
 7fc:	528005a0 	mov	w0, #0x2d                  	// #45
 800:	38334aa0 	strb	w0, [x21, w19, uxtw]
 804:	11000893 	add	w19, w4, #0x2
 808:	51000673 	sub	w19, w19, #0x1
 80c:	52800014 	mov	w20, #0x0                   	// #0
 810:	14000008 	b	830 <printint+0x94>
  neg = 0;
 814:	52800005 	mov	w5, #0x0                   	// #0
 818:	17ffffea 	b	7c0 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 81c:	38736aa1 	ldrb	w1, [x21, x19]
 820:	2a1603e0 	mov	w0, w22
 824:	d1000673 	sub	x19, x19, #0x1
 828:	97ffffd3 	bl	774 <putc>
 82c:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 830:	3100067f 	cmn	w19, #0x1
 834:	54ffff41 	b.ne	81c <printint+0x80>  // b.any
  return written;
}
 838:	a9425bf5 	ldp	x21, x22, [sp, #32]
 83c:	2a1403e0 	mov	w0, w20
 840:	a94153f3 	ldp	x19, x20, [sp, #16]
 844:	a8c47bfd 	ldp	x29, x30, [sp], #64
 848:	d65f03c0 	ret

000000000000084c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 84c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 850:	910003fd 	mov	x29, sp
 854:	a90153f3 	stp	x19, x20, [sp, #16]
 858:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 85c:	52800015 	mov	w21, #0x0                   	// #0
{
 860:	a90363f7 	stp	x23, x24, [sp, #48]
 864:	2a0003f7 	mov	w23, w0
 868:	a9046bf9 	stp	x25, x26, [sp, #64]
 86c:	aa0103f9 	mov	x25, x1

  state = 0;
 870:	52800001 	mov	w1, #0x0                   	// #0
{
 874:	a90573fb 	stp	x27, x28, [sp, #80]
 878:	a9406053 	ldp	x19, x24, [x2]
 87c:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 880:	39400320 	ldrb	w0, [x25]
 884:	35000120 	cbnz	w0, 8a8 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 888:	2a1503e0 	mov	w0, w21
 88c:	a94153f3 	ldp	x19, x20, [sp, #16]
 890:	a9425bf5 	ldp	x21, x22, [sp, #32]
 894:	a94363f7 	ldp	x23, x24, [sp, #48]
 898:	a9446bf9 	ldp	x25, x26, [sp, #64]
 89c:	a94573fb 	ldp	x27, x28, [sp, #80]
 8a0:	a8c67bfd 	ldp	x29, x30, [sp], #96
 8a4:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 8a8:	2a0003f6 	mov	w22, w0
    if(state == 0){
 8ac:	35000101 	cbnz	w1, 8cc <vprintf+0x80>
      if(c == '%'){
 8b0:	7100941f 	cmp	w0, #0x25
 8b4:	54000ba0 	b.eq	a28 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 8b8:	2a1603e1 	mov	w1, w22
 8bc:	2a1703e0 	mov	w0, w23
 8c0:	97ffffad 	bl	774 <putc>
 8c4:	0b0002b5 	add	w21, w21, w0
 8c8:	14000057 	b	a24 <vprintf+0x1d8>
      if(c == 'd'){
 8cc:	7101901f 	cmp	w0, #0x64
 8d0:	540002a1 	b.ne	924 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 8d4:	37f80174 	tbnz	w20, #31, 900 <vprintf+0xb4>
 8d8:	91002e76 	add	x22, x19, #0xb
 8dc:	2a1403fa 	mov	w26, w20
 8e0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8e4:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 8e8:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 8ec:	b9400261 	ldr	w1, [x19]
 8f0:	2a1703e0 	mov	w0, w23
 8f4:	97ffffaa 	bl	79c <printint>
        written += putc(fd, va_arg(ap, uint));
 8f8:	0b0002b5 	add	w21, w21, w0
 8fc:	14000048 	b	a1c <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 900:	1100229a 	add	w26, w20, #0x8
 904:	7100035f 	cmp	w26, #0x0
 908:	5400008d 	b.le	918 <vprintf+0xcc>
 90c:	91002e76 	add	x22, x19, #0xb
 910:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 914:	17fffff4 	b	8e4 <vprintf+0x98>
 918:	aa1303f6 	mov	x22, x19
 91c:	8b34c313 	add	x19, x24, w20, sxtw
 920:	17fffff1 	b	8e4 <vprintf+0x98>
      } else if(c == 'l') {
 924:	7101b01f 	cmp	w0, #0x6c
 928:	54000201 	b.ne	968 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 92c:	37f800d4 	tbnz	w20, #31, 944 <vprintf+0xf8>
 930:	91003e76 	add	x22, x19, #0xf
 934:	2a1403fa 	mov	w26, w20
 938:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 93c:	52800003 	mov	w3, #0x0                   	// #0
 940:	17ffffea 	b	8e8 <vprintf+0x9c>
 944:	1100229a 	add	w26, w20, #0x8
 948:	7100035f 	cmp	w26, #0x0
 94c:	5400008d 	b.le	95c <vprintf+0x110>
 950:	91003e76 	add	x22, x19, #0xf
 954:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 958:	17fffff9 	b	93c <vprintf+0xf0>
 95c:	aa1303f6 	mov	x22, x19
 960:	8b34c313 	add	x19, x24, w20, sxtw
 964:	17fffff6 	b	93c <vprintf+0xf0>
      } else if(c == 'x') {
 968:	7101e01f 	cmp	w0, #0x78
 96c:	54000221 	b.ne	9b0 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 970:	37f800f4 	tbnz	w20, #31, 98c <vprintf+0x140>
 974:	91002e76 	add	x22, x19, #0xb
 978:	2a1403fa 	mov	w26, w20
 97c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 980:	52800003 	mov	w3, #0x0                   	// #0
 984:	52800202 	mov	w2, #0x10                  	// #16
 988:	17ffffd9 	b	8ec <vprintf+0xa0>
 98c:	1100229a 	add	w26, w20, #0x8
 990:	7100035f 	cmp	w26, #0x0
 994:	5400008d 	b.le	9a4 <vprintf+0x158>
 998:	91002e76 	add	x22, x19, #0xb
 99c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9a0:	17fffff8 	b	980 <vprintf+0x134>
 9a4:	aa1303f6 	mov	x22, x19
 9a8:	8b34c313 	add	x19, x24, w20, sxtw
 9ac:	17fffff5 	b	980 <vprintf+0x134>
      } else if(c == 'p') {
 9b0:	7101c01f 	cmp	w0, #0x70
 9b4:	54000521 	b.ne	a58 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 9b8:	37f803f4 	tbnz	w20, #31, a34 <vprintf+0x1e8>
 9bc:	91003e76 	add	x22, x19, #0xf
 9c0:	2a1403fa 	mov	w26, w20
 9c4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 9c8:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 9cc:	52800601 	mov	w1, #0x30                  	// #48
 9d0:	2a1703e0 	mov	w0, w23
 9d4:	97ffff68 	bl	774 <putc>
 9d8:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 9dc:	9000001c 	adrp	x28, 0 <main>
 9e0:	9130539c 	add	x28, x28, #0xc14
  written += putc(fd, 'x');
 9e4:	2a1703e0 	mov	w0, w23
 9e8:	52800f01 	mov	w1, #0x78                  	// #120
 9ec:	97ffff62 	bl	774 <putc>
 9f0:	0b000273 	add	w19, w19, w0
 9f4:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 9f8:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 9fc:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a00:	38606b81 	ldrb	w1, [x28, x0]
 a04:	2a1703e0 	mov	w0, w23
 a08:	97ffff5b 	bl	774 <putc>
 a0c:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 a10:	71000694 	subs	w20, w20, #0x1
 a14:	54ffff21 	b.ne	9f8 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 a18:	0b1302b5 	add	w21, w21, w19
 a1c:	2a1a03f4 	mov	w20, w26
 a20:	aa1603f3 	mov	x19, x22
      state = 0;
 a24:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 a28:	91000739 	add	x25, x25, #0x1
  state = 0;
 a2c:	2a1603e1 	mov	w1, w22
 a30:	17ffff94 	b	880 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 a34:	1100229a 	add	w26, w20, #0x8
 a38:	7100035f 	cmp	w26, #0x0
 a3c:	5400008d 	b.le	a4c <vprintf+0x200>
 a40:	91003e76 	add	x22, x19, #0xf
 a44:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a48:	17ffffe0 	b	9c8 <vprintf+0x17c>
 a4c:	aa1303f6 	mov	x22, x19
 a50:	8b34c313 	add	x19, x24, w20, sxtw
 a54:	17ffffdd 	b	9c8 <vprintf+0x17c>
      } else if(c == 's'){
 a58:	7101cc1f 	cmp	w0, #0x73
 a5c:	54000381 	b.ne	acc <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 a60:	37f80214 	tbnz	w20, #31, aa0 <vprintf+0x254>
 a64:	91003e61 	add	x1, x19, #0xf
 a68:	aa1303e0 	mov	x0, x19
 a6c:	927df033 	and	x19, x1, #0xfffffffffffffff8
 a70:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 a74:	90000000 	adrp	x0, 0 <main>
 a78:	91303400 	add	x0, x0, #0xc0d
 a7c:	f10002df 	cmp	x22, #0x0
 a80:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 a84:	394002c1 	ldrb	w1, [x22]
 a88:	34fffce1 	cbz	w1, a24 <vprintf+0x1d8>
          written += putc(fd, *s);
 a8c:	2a1703e0 	mov	w0, w23
          s++;
 a90:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 a94:	97ffff38 	bl	774 <putc>
 a98:	0b0002b5 	add	w21, w21, w0
          s++;
 a9c:	17fffffa 	b	a84 <vprintf+0x238>
        s = va_arg(ap, char*);
 aa0:	11002281 	add	w1, w20, #0x8
 aa4:	7100003f 	cmp	w1, #0x0
 aa8:	540000cd 	b.le	ac0 <vprintf+0x274>
 aac:	91003e62 	add	x2, x19, #0xf
 ab0:	aa1303e0 	mov	x0, x19
 ab4:	2a0103f4 	mov	w20, w1
 ab8:	927df053 	and	x19, x2, #0xfffffffffffffff8
 abc:	17ffffed 	b	a70 <vprintf+0x224>
 ac0:	8b34c300 	add	x0, x24, w20, sxtw
 ac4:	2a0103f4 	mov	w20, w1
 ac8:	17ffffea 	b	a70 <vprintf+0x224>
      } else if(c == 'c'){
 acc:	71018c1f 	cmp	w0, #0x63
 ad0:	54000241 	b.ne	b18 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 ad4:	37f80114 	tbnz	w20, #31, af4 <vprintf+0x2a8>
 ad8:	91002e76 	add	x22, x19, #0xb
 adc:	2a1403fa 	mov	w26, w20
 ae0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ae4:	39400261 	ldrb	w1, [x19]
 ae8:	2a1703e0 	mov	w0, w23
 aec:	97ffff22 	bl	774 <putc>
 af0:	17ffff82 	b	8f8 <vprintf+0xac>
 af4:	1100229a 	add	w26, w20, #0x8
 af8:	7100035f 	cmp	w26, #0x0
 afc:	5400008d 	b.le	b0c <vprintf+0x2c0>
 b00:	91002e76 	add	x22, x19, #0xb
 b04:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b08:	17fffff7 	b	ae4 <vprintf+0x298>
 b0c:	aa1303f6 	mov	x22, x19
 b10:	8b34c313 	add	x19, x24, w20, sxtw
 b14:	17fffff4 	b	ae4 <vprintf+0x298>
      } else if(c == '%'){
 b18:	7100941f 	cmp	w0, #0x25
 b1c:	54ffece0 	b.eq	8b8 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 b20:	2a1703e0 	mov	w0, w23
 b24:	528004a1 	mov	w1, #0x25                  	// #37
 b28:	97ffff13 	bl	774 <putc>
 b2c:	0b0002b5 	add	w21, w21, w0
 b30:	17ffff62 	b	8b8 <vprintf+0x6c>

0000000000000b34 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 b34:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 b38:	910003fd 	mov	x29, sp
 b3c:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 b40:	910203e2 	add	x2, sp, #0x80
 b44:	a9030be2 	stp	x2, x2, [sp, #48]
 b48:	910143e2 	add	x2, sp, #0x50
 b4c:	f90023e2 	str	x2, [sp, #64]
 b50:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 b54:	b9004be2 	str	w2, [sp, #72]
 b58:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 b5c:	a9430fe2 	ldp	x2, x3, [sp, #48]
 b60:	a9010fe2 	stp	x2, x3, [sp, #16]
 b64:	a9440fe2 	ldp	x2, x3, [sp, #64]
 b68:	a9020fe2 	stp	x2, x3, [sp, #32]
 b6c:	910043e2 	add	x2, sp, #0x10
{
 b70:	a90617e4 	stp	x4, x5, [sp, #96]
 b74:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 b78:	97ffff35 	bl	84c <vprintf>
  va_end(ap);
  return result;
}
 b7c:	a8c87bfd 	ldp	x29, x30, [sp], #128
 b80:	d65f03c0 	ret

0000000000000b84 <printf>:

int
printf(const char *fmt, ...)
{
 b84:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 b88:	910003fd 	mov	x29, sp
 b8c:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 b90:	910243e1 	add	x1, sp, #0x90
 b94:	a90307e1 	stp	x1, x1, [sp, #48]
 b98:	910143e1 	add	x1, sp, #0x50
 b9c:	f90023e1 	str	x1, [sp, #64]
 ba0:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 ba4:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 ba8:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 bac:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 bb0:	52800020 	mov	w0, #0x1                   	// #1
{
 bb4:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 bb8:	a9430fe2 	ldp	x2, x3, [sp, #48]
 bbc:	a9010fe2 	stp	x2, x3, [sp, #16]
 bc0:	a9440fe2 	ldp	x2, x3, [sp, #64]
 bc4:	a9020fe2 	stp	x2, x3, [sp, #32]
 bc8:	910043e2 	add	x2, sp, #0x10
{
 bcc:	a9079be5 	stp	x5, x6, [sp, #120]
 bd0:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 bd4:	97ffff1e 	bl	84c <vprintf>
  va_end(ap);
  return result;
}
 bd8:	a8c97bfd 	ldp	x29, x30, [sp], #144
 bdc:	d65f03c0 	ret
