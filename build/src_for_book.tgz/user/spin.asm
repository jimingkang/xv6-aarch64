
user/_spin:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
#include "user/user.h"
#include "user/schedutil.h"

int
main(int argc, char *argv[])
{
   0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
   4:	910003fd 	mov	x29, sp
   8:	a90153f3 	stp	x19, x20, [sp, #16]
   c:	a9025bf5 	stp	x21, x22, [sp, #32]
  int secs = 5;
  struct sched_info si;

  if(argc > 2 || (argc == 2 && !parse_num(argv[1], &secs))){
  10:	7100081f 	cmp	w0, #0x2
  14:	54000d6c 	b.gt	1c0 <main+0x1c0>
  18:	54000e01 	b.ne	1d8 <main+0x1d8>  // b.any
  1c:	f9400420 	ldr	x0, [x1, #8]
static __attribute__((unused)) int
parse_num(const char *s, int *out)
{
  int neg = 0, v = 0, any = 0;

  if(*s == '-'){
  20:	39400001 	ldrb	w1, [x0]
  24:	7100b43f 	cmp	w1, #0x2d
  28:	54000821 	b.ne	12c <main+0x12c>  // b.any
    neg = 1;
    s++;
  2c:	91000400 	add	x0, x0, #0x1
    neg = 1;
  30:	52800023 	mov	w3, #0x1                   	// #1
  }
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
  34:	39400001 	ldrb	w1, [x0]
  38:	7100c03f 	cmp	w1, #0x30
  3c:	54000ba1 	b.ne	1b0 <main+0x1b0>  // b.any
  40:	39400401 	ldrb	w1, [x0, #1]
  44:	121a7821 	and	w1, w1, #0xffffffdf
  48:	12001c21 	and	w1, w1, #0xff
  4c:	7101603f 	cmp	w1, #0x58
  50:	54000b01 	b.ne	1b0 <main+0x1b0>  // b.any
    for(s += 2; *s; s++, any = 1){
  54:	91000800 	add	x0, x0, #0x2
  int neg = 0, v = 0, any = 0;
  58:	52800002 	mov	w2, #0x0                   	// #0
  5c:	52800013 	mov	w19, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
  60:	39400001 	ldrb	w1, [x0]
  64:	35000681 	cbnz	w1, 134 <main+0x134>
      if(*s < '0' || *s > '9')
        return 0;
      v = v * 10 + (*s - '0');
    }
  }
  if(!any)
  68:	34000ac2 	cbz	w2, 1c0 <main+0x1c0>
    return 0;
  *out = neg ? -v : v;
  6c:	7100007f 	cmp	w3, #0x0
  70:	5a930673 	cneg	w19, w19, ne	// ne = any
    fprintf(2, "usage: spin [SECONDS]\n");
    exit(1);
  }
  uint64 start = clock_us(), end = start + (uint64)secs * 1000000;
  74:	9400011b 	bl	4e0 <clock_us>
  78:	aa0003f4 	mov	x20, x0
  7c:	52884800 	mov	w0, #0x4240                	// #16960
  80:	72a001e0 	movk	w0, #0xf, lsl #16
  84:	9b205273 	smaddl	x19, w19, w0, x20
  while(clock_us() < end)
  88:	94000116 	bl	4e0 <clock_us>
  8c:	eb13001f 	cmp	x0, x19
  90:	54ffffc3 	b.cc	88 <main+0x88>  // b.lo, b.ul, b.last
    ;
  sched_getinfo(0, &si);
  94:	910123e1 	add	x1, sp, #0x48
  98:	52800000 	mov	w0, #0x0                   	// #0
  9c:	94000105 	bl	4b0 <sched_getinfo>
  uint64 done = clock_us();
  a0:	94000110 	bl	4e0 <clock_us>
  a4:	aa0003f5 	mov	x21, x0
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
  a8:	294907f6 	ldp	w22, w1, [sp, #72]
}

static __attribute__((unused)) const char *
policy_name(int policy)
{
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
  ac:	7100043f 	cmp	w1, #0x1
  b0:	54000980 	b.eq	1e0 <main+0x1e0>  // b.none
  if(policy == SCHED_RR) return "SCHED_RR";
  return "SCHED_OTHER";
  b4:	7100083f 	cmp	w1, #0x2
  b8:	90000000 	adrp	x0, 0 <main>
  bc:	91273c00 	add	x0, x0, #0x9cf
  c0:	90000013 	adrp	x19, 0 <main>
  c4:	91276e73 	add	x19, x19, #0x9db
  c8:	9a800273 	csel	x19, x19, x0, eq	// eq = none
  cc:	b94053e3 	ldr	w3, [sp, #80]
  d0:	b9003fe3 	str	w3, [sp, #60]
  d4:	94000106 	bl	4ec <getcpu>
  d8:	2a0003e4 	mov	w4, w0
         si.pid, policy_name(si.policy), si.priority, getcpu(),
         (int)(si.run_ticks * SCHED_TICK_MS), (int)(start / 1000 % 100000),
         (int)(done / 1000 % 100000));
  dc:	d2807d00 	mov	x0, #0x3e8                 	// #1000
  e0:	d290d402 	mov	x2, #0x86a0                	// #34464
  e4:	f2a00022 	movk	x2, #0x1, lsl #16
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
  e8:	52800145 	mov	w5, #0xa                   	// #10
         (int)(done / 1000 % 100000));
  ec:	9ac00ab5 	udiv	x21, x21, x0
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
  f0:	b9403fe3 	ldr	w3, [sp, #60]
  f4:	f94037e1 	ldr	x1, [sp, #104]
         (int)(si.run_ticks * SCHED_TICK_MS), (int)(start / 1000 % 100000),
  f8:	9ac00a94 	udiv	x20, x20, x0
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
  fc:	90000000 	adrp	x0, 0 <main>
 100:	9127ec00 	add	x0, x0, #0x9fb
         (int)(done / 1000 % 100000));
 104:	9ac20aa7 	udiv	x7, x21, x2
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
 108:	1b017ca5 	mul	w5, w5, w1
 10c:	2a1603e1 	mov	w1, w22
         (int)(si.run_ticks * SCHED_TICK_MS), (int)(start / 1000 % 100000),
 110:	9ac20a86 	udiv	x6, x20, x2
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
 114:	1b02d4e7 	msub	w7, w7, w2, w21
 118:	1b02d0c6 	msub	w6, w6, w2, w20
 11c:	aa1303e2 	mov	x2, x19
 120:	94000212 	bl	968 <printf>
  exit(0);
 124:	52800000 	mov	w0, #0x0                   	// #0
 128:	1400002b 	b	1d4 <main+0x1d4>
  int neg = 0, v = 0, any = 0;
 12c:	52800003 	mov	w3, #0x0                   	// #0
 130:	17ffffc1 	b	34 <main+0x34>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 134:	5100c022 	sub	w2, w1, #0x30
 138:	12001c44 	and	w4, w2, #0xff
 13c:	7100249f 	cmp	w4, #0x9
 140:	540000c8 	b.hi	158 <main+0x158>  // b.pmore
 144:	2a0203e1 	mov	w1, w2
      v = v * 16 + d;
 148:	0b131033 	add	w19, w1, w19, lsl #4
    for(s += 2; *s; s++, any = 1){
 14c:	91000400 	add	x0, x0, #0x1
 150:	52800022 	mov	w2, #0x1                   	// #1
 154:	17ffffc3 	b	60 <main+0x60>
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 158:	51018422 	sub	w2, w1, #0x61
 15c:	12001c42 	and	w2, w2, #0xff
 160:	7100145f 	cmp	w2, #0x5
 164:	54000068 	b.hi	170 <main+0x170>  // b.pmore
 168:	51015c21 	sub	w1, w1, #0x57
 16c:	17fffff7 	b	148 <main+0x148>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 170:	51010422 	sub	w2, w1, #0x41
 174:	12001c42 	and	w2, w2, #0xff
 178:	7100145f 	cmp	w2, #0x5
 17c:	54000228 	b.hi	1c0 <main+0x1c0>  // b.pmore
 180:	5100dc21 	sub	w1, w1, #0x37
 184:	17fffff1 	b	148 <main+0x148>
      if(*s < '0' || *s > '9')
 188:	5100c021 	sub	w1, w1, #0x30
 18c:	12001c22 	and	w2, w1, #0xff
 190:	7100245f 	cmp	w2, #0x9
 194:	54000168 	b.hi	1c0 <main+0x1c0>  // b.pmore
      v = v * 10 + (*s - '0');
 198:	1b040673 	madd	w19, w19, w4, w1
    for(; *s; s++, any = 1){
 19c:	91000400 	add	x0, x0, #0x1
 1a0:	52800022 	mov	w2, #0x1                   	// #1
 1a4:	39400001 	ldrb	w1, [x0]
 1a8:	35ffff01 	cbnz	w1, 188 <main+0x188>
 1ac:	17ffffaf 	b	68 <main+0x68>
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 1b0:	52800002 	mov	w2, #0x0                   	// #0
 1b4:	52800013 	mov	w19, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 1b8:	52800144 	mov	w4, #0xa                   	// #10
 1bc:	17fffffa 	b	1a4 <main+0x1a4>
    fprintf(2, "usage: spin [SECONDS]\n");
 1c0:	90000001 	adrp	x1, 0 <main>
 1c4:	91279021 	add	x1, x1, #0x9e4
 1c8:	52800040 	mov	w0, #0x2                   	// #2
 1cc:	940001d3 	bl	918 <fprintf>
    exit(1);
 1d0:	52800020 	mov	w0, #0x1                   	// #1
  exit(0);
 1d4:	94000009 	bl	1f8 <exit>
  int secs = 5;
 1d8:	528000b3 	mov	w19, #0x5                   	// #5
 1dc:	17ffffa6 	b	74 <main+0x74>
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 1e0:	90000013 	adrp	x19, 0 <main>
 1e4:	91271273 	add	x19, x19, #0x9c4
 1e8:	17ffffb9 	b	cc <main+0xcc>

00000000000001ec <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 1ec:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 1f0:	d4000001 	svc	#0x0
 ret
 1f4:	d65f03c0 	ret

00000000000001f8 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 1f8:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 1fc:	d4000001 	svc	#0x0
 ret
 200:	d65f03c0 	ret

0000000000000204 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 204:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 208:	d4000001 	svc	#0x0
 ret
 20c:	d65f03c0 	ret

0000000000000210 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 210:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 214:	d4000001 	svc	#0x0
 ret
 218:	d65f03c0 	ret

000000000000021c <read>:
.global read
read:
 mov x7, #SYS_read
 21c:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 220:	d4000001 	svc	#0x0
 ret
 224:	d65f03c0 	ret

0000000000000228 <write>:
.global write
write:
 mov x7, #SYS_write
 228:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 22c:	d4000001 	svc	#0x0
 ret
 230:	d65f03c0 	ret

0000000000000234 <close>:
.global close
close:
 mov x7, #SYS_close
 234:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 238:	d4000001 	svc	#0x0
 ret
 23c:	d65f03c0 	ret

0000000000000240 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 240:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 244:	d4000001 	svc	#0x0
 ret
 248:	d65f03c0 	ret

000000000000024c <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 24c:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 250:	d4000001 	svc	#0x0
 ret
 254:	d65f03c0 	ret

0000000000000258 <open>:
.global open
open:
 mov x7, #SYS_open
 258:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 25c:	d4000001 	svc	#0x0
 ret
 260:	d65f03c0 	ret

0000000000000264 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 264:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 268:	d4000001 	svc	#0x0
 ret
 26c:	d65f03c0 	ret

0000000000000270 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 270:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 274:	d4000001 	svc	#0x0
 ret
 278:	d65f03c0 	ret

000000000000027c <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 27c:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 280:	d4000001 	svc	#0x0
 ret
 284:	d65f03c0 	ret

0000000000000288 <link>:
.global link
link:
 mov x7, #SYS_link
 288:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 28c:	d4000001 	svc	#0x0
 ret
 290:	d65f03c0 	ret

0000000000000294 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 294:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 298:	d4000001 	svc	#0x0
 ret
 29c:	d65f03c0 	ret

00000000000002a0 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 2a0:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 2a4:	d4000001 	svc	#0x0
 ret
 2a8:	d65f03c0 	ret

00000000000002ac <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 2ac:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 2b0:	d4000001 	svc	#0x0
 ret
 2b4:	d65f03c0 	ret

00000000000002b8 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 2b8:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 2bc:	d4000001 	svc	#0x0
 ret
 2c0:	d65f03c0 	ret

00000000000002c4 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 2c4:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 2c8:	d4000001 	svc	#0x0
 ret
 2cc:	d65f03c0 	ret

00000000000002d0 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 2d0:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 2d4:	d4000001 	svc	#0x0
 ret
 2d8:	d65f03c0 	ret

00000000000002dc <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 2dc:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 2e0:	d4000001 	svc	#0x0
 ret
 2e4:	d65f03c0 	ret

00000000000002e8 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 2e8:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 2ec:	d4000001 	svc	#0x0
 ret
 2f0:	d65f03c0 	ret

00000000000002f4 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 2f4:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 2f8:	d4000001 	svc	#0x0
 ret
 2fc:	d65f03c0 	ret

0000000000000300 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 300:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 304:	d4000001 	svc	#0x0
 ret
 308:	d65f03c0 	ret

000000000000030c <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 30c:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 310:	d4000001 	svc	#0x0
 ret
 314:	d65f03c0 	ret

0000000000000318 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 318:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 31c:	d4000001 	svc	#0x0
 ret
 320:	d65f03c0 	ret

0000000000000324 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 324:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 328:	d4000001 	svc	#0x0
 ret
 32c:	d65f03c0 	ret

0000000000000330 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 330:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 334:	d4000001 	svc	#0x0
 ret
 338:	d65f03c0 	ret

000000000000033c <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 33c:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 340:	d4000001 	svc	#0x0
 ret
 344:	d65f03c0 	ret

0000000000000348 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 348:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 34c:	d4000001 	svc	#0x0
 ret
 350:	d65f03c0 	ret

0000000000000354 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 354:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 358:	d4000001 	svc	#0x0
 ret
 35c:	d65f03c0 	ret

0000000000000360 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 360:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 364:	d4000001 	svc	#0x0
 ret
 368:	d65f03c0 	ret

000000000000036c <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 36c:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 370:	d4000001 	svc	#0x0
 ret
 374:	d65f03c0 	ret

0000000000000378 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 378:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 37c:	d4000001 	svc	#0x0
 ret
 380:	d65f03c0 	ret

0000000000000384 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 384:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 388:	d4000001 	svc	#0x0
 ret
 38c:	d65f03c0 	ret

0000000000000390 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 390:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 394:	d4000001 	svc	#0x0
 ret
 398:	d65f03c0 	ret

000000000000039c <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 39c:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 3a0:	d4000001 	svc	#0x0
 ret
 3a4:	d65f03c0 	ret

00000000000003a8 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 3a8:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 3ac:	d4000001 	svc	#0x0
 ret
 3b0:	d65f03c0 	ret

00000000000003b4 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 3b4:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 3b8:	d4000001 	svc	#0x0
 ret
 3bc:	d65f03c0 	ret

00000000000003c0 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 3c0:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 3c4:	d4000001 	svc	#0x0
 ret
 3c8:	d65f03c0 	ret

00000000000003cc <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 3cc:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 3d0:	d4000001 	svc	#0x0
 ret
 3d4:	d65f03c0 	ret

00000000000003d8 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 3d8:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 3dc:	d4000001 	svc	#0x0
 ret
 3e0:	d65f03c0 	ret

00000000000003e4 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 3e4:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 3e8:	d4000001 	svc	#0x0
 ret
 3ec:	d65f03c0 	ret

00000000000003f0 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 3f0:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 3f4:	d4000001 	svc	#0x0
 ret
 3f8:	d65f03c0 	ret

00000000000003fc <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 3fc:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 400:	d4000001 	svc	#0x0
 ret
 404:	d65f03c0 	ret

0000000000000408 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 408:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 40c:	d4000001 	svc	#0x0
 ret
 410:	d65f03c0 	ret

0000000000000414 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 414:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 418:	d4000001 	svc	#0x0
 ret
 41c:	d65f03c0 	ret

0000000000000420 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 420:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 424:	d4000001 	svc	#0x0
 ret
 428:	d65f03c0 	ret

000000000000042c <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 42c:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 430:	d4000001 	svc	#0x0
 ret
 434:	d65f03c0 	ret

0000000000000438 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 438:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 43c:	d4000001 	svc	#0x0
 ret
 440:	d65f03c0 	ret

0000000000000444 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 444:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 448:	d4000001 	svc	#0x0
 ret
 44c:	d65f03c0 	ret

0000000000000450 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 450:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 454:	d4000001 	svc	#0x0
 ret
 458:	d65f03c0 	ret

000000000000045c <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 45c:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 460:	d4000001 	svc	#0x0
 ret
 464:	d65f03c0 	ret

0000000000000468 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 468:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 46c:	d4000001 	svc	#0x0
 ret
 470:	d65f03c0 	ret

0000000000000474 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 474:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 478:	d4000001 	svc	#0x0
 ret
 47c:	d65f03c0 	ret

0000000000000480 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 480:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 484:	d4000001 	svc	#0x0
 ret
 488:	d65f03c0 	ret

000000000000048c <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 48c:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 490:	d4000001 	svc	#0x0
 ret
 494:	d65f03c0 	ret

0000000000000498 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 498:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 49c:	d4000001 	svc	#0x0
 ret
 4a0:	d65f03c0 	ret

00000000000004a4 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 4a4:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 4a8:	d4000001 	svc	#0x0
 ret
 4ac:	d65f03c0 	ret

00000000000004b0 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 4b0:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 4b4:	d4000001 	svc	#0x0
 ret
 4b8:	d65f03c0 	ret

00000000000004bc <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 4bc:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 4c0:	d4000001 	svc	#0x0
 ret
 4c4:	d65f03c0 	ret

00000000000004c8 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 4c8:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 4cc:	d4000001 	svc	#0x0
 ret
 4d0:	d65f03c0 	ret

00000000000004d4 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 4d4:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 4d8:	d4000001 	svc	#0x0
 ret
 4dc:	d65f03c0 	ret

00000000000004e0 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 4e0:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 4e4:	d4000001 	svc	#0x0
 ret
 4e8:	d65f03c0 	ret

00000000000004ec <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 4ec:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 4f0:	d4000001 	svc	#0x0
 ret
 4f4:	d65f03c0 	ret

00000000000004f8 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 4f8:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 4fc:	d4000001 	svc	#0x0
 ret
 500:	d65f03c0 	ret

0000000000000504 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 504:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 508:	d4000001 	svc	#0x0
 ret
 50c:	d65f03c0 	ret

0000000000000510 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 510:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 514:	d4000001 	svc	#0x0
 ret
 518:	d65f03c0 	ret

000000000000051c <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 51c:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 520:	d4000001 	svc	#0x0
 ret
 524:	d65f03c0 	ret

0000000000000528 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 528:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 52c:	d4000001 	svc	#0x0
 ret
 530:	d65f03c0 	ret

0000000000000534 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 534:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 538:	d4000001 	svc	#0x0
 ret
 53c:	d65f03c0 	ret

0000000000000540 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 540:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 544:	d4000001 	svc	#0x0
 ret
 548:	d65f03c0 	ret

000000000000054c <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 54c:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 550:	d4000001 	svc	#0x0
 ret
 554:	d65f03c0 	ret

0000000000000558 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 558:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 55c:	52800022 	mov	w2, #0x1                   	// #1
{
 560:	910003fd 	mov	x29, sp
 564:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 568:	91007fe1 	add	x1, sp, #0x1f
 56c:	97ffff2f 	bl	228 <write>
 570:	7100041f 	cmp	w0, #0x1
}
 574:	1a9f17e0 	cset	w0, eq	// eq = none
 578:	a8c27bfd 	ldp	x29, x30, [sp], #32
 57c:	d65f03c0 	ret

0000000000000580 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 580:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 584:	910003fd 	mov	x29, sp
 588:	a90153f3 	stp	x19, x20, [sp, #16]
 58c:	a9025bf5 	stp	x21, x22, [sp, #32]
 590:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 594:	6a417c7f 	tst	w3, w1, lsr #31
 598:	54000300 	b.eq	5f8 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 59c:	4b0103e1 	neg	w1, w1
    neg = 1;
 5a0:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 5a4:	90000003 	adrp	x3, 0 <main>
 5a8:	9128fc63 	add	x3, x3, #0xa3f
 5ac:	9100c3f5 	add	x21, sp, #0x30
 5b0:	d2800000 	mov	x0, #0x0                   	// #0
 5b4:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 5b8:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 5bc:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 5c0:	2a0403e1 	mov	w1, w4
 5c4:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 5c8:	38666866 	ldrb	w6, [x3, x6]
 5cc:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 5d0:	91000400 	add	x0, x0, #0x1
 5d4:	54ffff09 	b.ls	5b4 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 5d8:	11000493 	add	w19, w4, #0x1
  if(neg)
 5dc:	34000085 	cbz	w5, 5ec <printint+0x6c>
    buf[i++] = '-';
 5e0:	528005a0 	mov	w0, #0x2d                  	// #45
 5e4:	38334aa0 	strb	w0, [x21, w19, uxtw]
 5e8:	11000893 	add	w19, w4, #0x2
 5ec:	51000673 	sub	w19, w19, #0x1
 5f0:	52800014 	mov	w20, #0x0                   	// #0
 5f4:	14000008 	b	614 <printint+0x94>
  neg = 0;
 5f8:	52800005 	mov	w5, #0x0                   	// #0
 5fc:	17ffffea 	b	5a4 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 600:	38736aa1 	ldrb	w1, [x21, x19]
 604:	2a1603e0 	mov	w0, w22
 608:	d1000673 	sub	x19, x19, #0x1
 60c:	97ffffd3 	bl	558 <putc>
 610:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 614:	3100067f 	cmn	w19, #0x1
 618:	54ffff41 	b.ne	600 <printint+0x80>  // b.any
  return written;
}
 61c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 620:	2a1403e0 	mov	w0, w20
 624:	a94153f3 	ldp	x19, x20, [sp, #16]
 628:	a8c47bfd 	ldp	x29, x30, [sp], #64
 62c:	d65f03c0 	ret

0000000000000630 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 630:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 634:	910003fd 	mov	x29, sp
 638:	a90153f3 	stp	x19, x20, [sp, #16]
 63c:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 640:	52800015 	mov	w21, #0x0                   	// #0
{
 644:	a90363f7 	stp	x23, x24, [sp, #48]
 648:	2a0003f7 	mov	w23, w0
 64c:	a9046bf9 	stp	x25, x26, [sp, #64]
 650:	aa0103f9 	mov	x25, x1

  state = 0;
 654:	52800001 	mov	w1, #0x0                   	// #0
{
 658:	a90573fb 	stp	x27, x28, [sp, #80]
 65c:	a9406053 	ldp	x19, x24, [x2]
 660:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 664:	39400320 	ldrb	w0, [x25]
 668:	35000120 	cbnz	w0, 68c <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 66c:	2a1503e0 	mov	w0, w21
 670:	a94153f3 	ldp	x19, x20, [sp, #16]
 674:	a9425bf5 	ldp	x21, x22, [sp, #32]
 678:	a94363f7 	ldp	x23, x24, [sp, #48]
 67c:	a9446bf9 	ldp	x25, x26, [sp, #64]
 680:	a94573fb 	ldp	x27, x28, [sp, #80]
 684:	a8c67bfd 	ldp	x29, x30, [sp], #96
 688:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 68c:	2a0003f6 	mov	w22, w0
    if(state == 0){
 690:	35000101 	cbnz	w1, 6b0 <vprintf+0x80>
      if(c == '%'){
 694:	7100941f 	cmp	w0, #0x25
 698:	54000ba0 	b.eq	80c <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 69c:	2a1603e1 	mov	w1, w22
 6a0:	2a1703e0 	mov	w0, w23
 6a4:	97ffffad 	bl	558 <putc>
 6a8:	0b0002b5 	add	w21, w21, w0
 6ac:	14000057 	b	808 <vprintf+0x1d8>
      if(c == 'd'){
 6b0:	7101901f 	cmp	w0, #0x64
 6b4:	540002a1 	b.ne	708 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 6b8:	37f80174 	tbnz	w20, #31, 6e4 <vprintf+0xb4>
 6bc:	91002e76 	add	x22, x19, #0xb
 6c0:	2a1403fa 	mov	w26, w20
 6c4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6c8:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 6cc:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 6d0:	b9400261 	ldr	w1, [x19]
 6d4:	2a1703e0 	mov	w0, w23
 6d8:	97ffffaa 	bl	580 <printint>
        written += putc(fd, va_arg(ap, uint));
 6dc:	0b0002b5 	add	w21, w21, w0
 6e0:	14000048 	b	800 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 6e4:	1100229a 	add	w26, w20, #0x8
 6e8:	7100035f 	cmp	w26, #0x0
 6ec:	5400008d 	b.le	6fc <vprintf+0xcc>
 6f0:	91002e76 	add	x22, x19, #0xb
 6f4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 6f8:	17fffff4 	b	6c8 <vprintf+0x98>
 6fc:	aa1303f6 	mov	x22, x19
 700:	8b34c313 	add	x19, x24, w20, sxtw
 704:	17fffff1 	b	6c8 <vprintf+0x98>
      } else if(c == 'l') {
 708:	7101b01f 	cmp	w0, #0x6c
 70c:	54000201 	b.ne	74c <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 710:	37f800d4 	tbnz	w20, #31, 728 <vprintf+0xf8>
 714:	91003e76 	add	x22, x19, #0xf
 718:	2a1403fa 	mov	w26, w20
 71c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 720:	52800003 	mov	w3, #0x0                   	// #0
 724:	17ffffea 	b	6cc <vprintf+0x9c>
 728:	1100229a 	add	w26, w20, #0x8
 72c:	7100035f 	cmp	w26, #0x0
 730:	5400008d 	b.le	740 <vprintf+0x110>
 734:	91003e76 	add	x22, x19, #0xf
 738:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 73c:	17fffff9 	b	720 <vprintf+0xf0>
 740:	aa1303f6 	mov	x22, x19
 744:	8b34c313 	add	x19, x24, w20, sxtw
 748:	17fffff6 	b	720 <vprintf+0xf0>
      } else if(c == 'x') {
 74c:	7101e01f 	cmp	w0, #0x78
 750:	54000221 	b.ne	794 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 754:	37f800f4 	tbnz	w20, #31, 770 <vprintf+0x140>
 758:	91002e76 	add	x22, x19, #0xb
 75c:	2a1403fa 	mov	w26, w20
 760:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 764:	52800003 	mov	w3, #0x0                   	// #0
 768:	52800202 	mov	w2, #0x10                  	// #16
 76c:	17ffffd9 	b	6d0 <vprintf+0xa0>
 770:	1100229a 	add	w26, w20, #0x8
 774:	7100035f 	cmp	w26, #0x0
 778:	5400008d 	b.le	788 <vprintf+0x158>
 77c:	91002e76 	add	x22, x19, #0xb
 780:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 784:	17fffff8 	b	764 <vprintf+0x134>
 788:	aa1303f6 	mov	x22, x19
 78c:	8b34c313 	add	x19, x24, w20, sxtw
 790:	17fffff5 	b	764 <vprintf+0x134>
      } else if(c == 'p') {
 794:	7101c01f 	cmp	w0, #0x70
 798:	54000521 	b.ne	83c <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 79c:	37f803f4 	tbnz	w20, #31, 818 <vprintf+0x1e8>
 7a0:	91003e76 	add	x22, x19, #0xf
 7a4:	2a1403fa 	mov	w26, w20
 7a8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 7ac:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 7b0:	52800601 	mov	w1, #0x30                  	// #48
 7b4:	2a1703e0 	mov	w0, w23
 7b8:	97ffff68 	bl	558 <putc>
 7bc:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7c0:	9000001c 	adrp	x28, 0 <main>
 7c4:	9128ff9c 	add	x28, x28, #0xa3f
  written += putc(fd, 'x');
 7c8:	2a1703e0 	mov	w0, w23
 7cc:	52800f01 	mov	w1, #0x78                  	// #120
 7d0:	97ffff62 	bl	558 <putc>
 7d4:	0b000273 	add	w19, w19, w0
 7d8:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7dc:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7e0:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7e4:	38606b81 	ldrb	w1, [x28, x0]
 7e8:	2a1703e0 	mov	w0, w23
 7ec:	97ffff5b 	bl	558 <putc>
 7f0:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7f4:	71000694 	subs	w20, w20, #0x1
 7f8:	54ffff21 	b.ne	7dc <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 7fc:	0b1302b5 	add	w21, w21, w19
 800:	2a1a03f4 	mov	w20, w26
 804:	aa1603f3 	mov	x19, x22
      state = 0;
 808:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 80c:	91000739 	add	x25, x25, #0x1
  state = 0;
 810:	2a1603e1 	mov	w1, w22
 814:	17ffff94 	b	664 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 818:	1100229a 	add	w26, w20, #0x8
 81c:	7100035f 	cmp	w26, #0x0
 820:	5400008d 	b.le	830 <vprintf+0x200>
 824:	91003e76 	add	x22, x19, #0xf
 828:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 82c:	17ffffe0 	b	7ac <vprintf+0x17c>
 830:	aa1303f6 	mov	x22, x19
 834:	8b34c313 	add	x19, x24, w20, sxtw
 838:	17ffffdd 	b	7ac <vprintf+0x17c>
      } else if(c == 's'){
 83c:	7101cc1f 	cmp	w0, #0x73
 840:	54000381 	b.ne	8b0 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 844:	37f80214 	tbnz	w20, #31, 884 <vprintf+0x254>
 848:	91003e61 	add	x1, x19, #0xf
 84c:	aa1303e0 	mov	x0, x19
 850:	927df033 	and	x19, x1, #0xfffffffffffffff8
 854:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 858:	90000000 	adrp	x0, 0 <main>
 85c:	9128e000 	add	x0, x0, #0xa38
 860:	f10002df 	cmp	x22, #0x0
 864:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 868:	394002c1 	ldrb	w1, [x22]
 86c:	34fffce1 	cbz	w1, 808 <vprintf+0x1d8>
          written += putc(fd, *s);
 870:	2a1703e0 	mov	w0, w23
          s++;
 874:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 878:	97ffff38 	bl	558 <putc>
 87c:	0b0002b5 	add	w21, w21, w0
          s++;
 880:	17fffffa 	b	868 <vprintf+0x238>
        s = va_arg(ap, char*);
 884:	11002281 	add	w1, w20, #0x8
 888:	7100003f 	cmp	w1, #0x0
 88c:	540000cd 	b.le	8a4 <vprintf+0x274>
 890:	91003e62 	add	x2, x19, #0xf
 894:	aa1303e0 	mov	x0, x19
 898:	2a0103f4 	mov	w20, w1
 89c:	927df053 	and	x19, x2, #0xfffffffffffffff8
 8a0:	17ffffed 	b	854 <vprintf+0x224>
 8a4:	8b34c300 	add	x0, x24, w20, sxtw
 8a8:	2a0103f4 	mov	w20, w1
 8ac:	17ffffea 	b	854 <vprintf+0x224>
      } else if(c == 'c'){
 8b0:	71018c1f 	cmp	w0, #0x63
 8b4:	54000241 	b.ne	8fc <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 8b8:	37f80114 	tbnz	w20, #31, 8d8 <vprintf+0x2a8>
 8bc:	91002e76 	add	x22, x19, #0xb
 8c0:	2a1403fa 	mov	w26, w20
 8c4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8c8:	39400261 	ldrb	w1, [x19]
 8cc:	2a1703e0 	mov	w0, w23
 8d0:	97ffff22 	bl	558 <putc>
 8d4:	17ffff82 	b	6dc <vprintf+0xac>
 8d8:	1100229a 	add	w26, w20, #0x8
 8dc:	7100035f 	cmp	w26, #0x0
 8e0:	5400008d 	b.le	8f0 <vprintf+0x2c0>
 8e4:	91002e76 	add	x22, x19, #0xb
 8e8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 8ec:	17fffff7 	b	8c8 <vprintf+0x298>
 8f0:	aa1303f6 	mov	x22, x19
 8f4:	8b34c313 	add	x19, x24, w20, sxtw
 8f8:	17fffff4 	b	8c8 <vprintf+0x298>
      } else if(c == '%'){
 8fc:	7100941f 	cmp	w0, #0x25
 900:	54ffece0 	b.eq	69c <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 904:	2a1703e0 	mov	w0, w23
 908:	528004a1 	mov	w1, #0x25                  	// #37
 90c:	97ffff13 	bl	558 <putc>
 910:	0b0002b5 	add	w21, w21, w0
 914:	17ffff62 	b	69c <vprintf+0x6c>

0000000000000918 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 918:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 91c:	910003fd 	mov	x29, sp
 920:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 924:	910203e2 	add	x2, sp, #0x80
 928:	a9030be2 	stp	x2, x2, [sp, #48]
 92c:	910143e2 	add	x2, sp, #0x50
 930:	f90023e2 	str	x2, [sp, #64]
 934:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 938:	b9004be2 	str	w2, [sp, #72]
 93c:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 940:	a9430fe2 	ldp	x2, x3, [sp, #48]
 944:	a9010fe2 	stp	x2, x3, [sp, #16]
 948:	a9440fe2 	ldp	x2, x3, [sp, #64]
 94c:	a9020fe2 	stp	x2, x3, [sp, #32]
 950:	910043e2 	add	x2, sp, #0x10
{
 954:	a90617e4 	stp	x4, x5, [sp, #96]
 958:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 95c:	97ffff35 	bl	630 <vprintf>
  va_end(ap);
  return result;
}
 960:	a8c87bfd 	ldp	x29, x30, [sp], #128
 964:	d65f03c0 	ret

0000000000000968 <printf>:

int
printf(const char *fmt, ...)
{
 968:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 96c:	910003fd 	mov	x29, sp
 970:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 974:	910243e1 	add	x1, sp, #0x90
 978:	a90307e1 	stp	x1, x1, [sp, #48]
 97c:	910143e1 	add	x1, sp, #0x50
 980:	f90023e1 	str	x1, [sp, #64]
 984:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 988:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 98c:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 990:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 994:	52800020 	mov	w0, #0x1                   	// #1
{
 998:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 99c:	a9430fe2 	ldp	x2, x3, [sp, #48]
 9a0:	a9010fe2 	stp	x2, x3, [sp, #16]
 9a4:	a9440fe2 	ldp	x2, x3, [sp, #64]
 9a8:	a9020fe2 	stp	x2, x3, [sp, #32]
 9ac:	910043e2 	add	x2, sp, #0x10
{
 9b0:	a9079be5 	stp	x5, x6, [sp, #120]
 9b4:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 9b8:	97ffff1e 	bl	630 <vprintf>
  va_end(ap);
  return result;
}
 9bc:	a8c97bfd 	ldp	x29, x30, [sp], #144
 9c0:	d65f03c0 	ret
