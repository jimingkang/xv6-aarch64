
user/_usertests:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  }
}

int
main(int argc, char *argv[])
{
       0:	d11083ff 	sub	sp, sp, #0x420
       4:	a9007bfd 	stp	x29, x30, [sp]
       8:	910003fd 	mov	x29, sp
       c:	a90153f3 	stp	x19, x20, [sp, #16]
      10:	2a0003f3 	mov	w19, w0
      14:	a9025bf5 	stp	x21, x22, [sp, #32]
      18:	f9001bf7 	str	x23, [sp, #48]
  int continuous = 0;
  char *justone = 0;

  if(argc == 2 && strcmp(argv[1], "-c") == 0){
      1c:	7100081f 	cmp	w0, #0x2
      20:	540000e0 	b.eq	3c <main+0x3c>  // b.none
    continuous = 1;
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    continuous = 2;
  } else if(argc == 2 && argv[1][0] != '-'){
    justone = argv[1];
  } else if(argc > 1){
      24:	7100041f 	cmp	w0, #0x1
      28:	5400064d 	b.le	f0 <main+0xf0>
    printf("Usage: usertests [-c] [testname]\n");
      2c:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
      30:	912d6000 	add	x0, x0, #0xb58
        fail = 1;
    }
  }

  if(fail){
    printf("SOME TESTS FAILED\n");
      34:	9400135e 	bl	4dac <printf>
    exit(1);
      38:	1400002c 	b	e8 <main+0xe8>
      3c:	aa0103f4 	mov	x20, x1
  if(argc == 2 && strcmp(argv[1], "-c") == 0){
      40:	d0000021 	adrp	x1, 6000 <malloc+0x10e4>
      44:	912de821 	add	x1, x1, #0xb7a
      48:	f9400680 	ldr	x0, [x20, #8]
      4c:	940010da 	bl	43b4 <strcmp>
      50:	34000540 	cbz	w0, f8 <main+0xf8>
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
      54:	f9400680 	ldr	x0, [x20, #8]
      58:	d0000021 	adrp	x1, 6000 <malloc+0x10e4>
      5c:	912df421 	add	x1, x1, #0xb7d
      60:	940010d5 	bl	43b4 <strcmp>
      64:	34000500 	cbz	w0, 104 <main+0x104>
  } else if(argc == 2 && argv[1][0] != '-'){
      68:	f9400694 	ldr	x20, [x20, #8]
      6c:	39400280 	ldrb	w0, [x20]
      70:	7100b41f 	cmp	w0, #0x2d
      74:	54fffdc0 	b.eq	2c <main+0x2c>  // b.none
  int continuous = 0;
      78:	52800013 	mov	w19, #0x0                   	// #0
  } tests[] = {
      7c:	d0000021 	adrp	x1, 6000 <malloc+0x10e4>
      80:	91380021 	add	x1, x1, #0xe00
      84:	91014021 	add	x1, x1, #0x50
      88:	910103e0 	add	x0, sp, #0x40
      8c:	d2807c02 	mov	x2, #0x3e0                 	// #992
      90:	94001167 	bl	462c <memcpy>
  if(continuous){
      94:	34000473 	cbz	w19, 120 <main+0x120>
        printf("SOME TESTS FAILED\n");
      98:	d0000035 	adrp	x21, 6000 <malloc+0x10e4>
      9c:	912ef6b5 	add	x21, x21, #0xbbd
        printf("FAILED -- lost %d free pages\n", free0 - free1);
      a0:	d0000036 	adrp	x22, 6000 <malloc+0x10e4>
      a4:	912e7ed6 	add	x22, x22, #0xb9f
    printf("continuous usertests starting\n");
      a8:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
      ac:	912e0000 	add	x0, x0, #0xb80
      b0:	9400133f 	bl	4dac <printf>
      int free0 = countfree();
      b4:	9400103d 	bl	41a8 <countfree>
      for (struct test *t = tests; t->s != 0; t++) {
      b8:	910103f4 	add	x20, sp, #0x40
      int free0 = countfree();
      bc:	2a0003f7 	mov	w23, w0
      for (struct test *t = tests; t->s != 0; t++) {
      c0:	f9400681 	ldr	x1, [x20, #8]
      c4:	b5000241 	cbnz	x1, 10c <main+0x10c>
      int free1 = countfree();
      c8:	94001038 	bl	41a8 <countfree>
      if(free1 < free0){
      cc:	6b0002ff 	cmp	w23, w0
      d0:	54ffff2d 	b.le	b4 <main+0xb4>
        printf("FAILED -- lost %d free pages\n", free0 - free1);
      d4:	4b0002e1 	sub	w1, w23, w0
      d8:	aa1603e0 	mov	x0, x22
      dc:	94001334 	bl	4dac <printf>
        if(continuous != 2)
      e0:	71000a7f 	cmp	w19, #0x2
      e4:	54fffe80 	b.eq	b4 <main+0xb4>  // b.none
  } else if((free1 = countfree()) < free0){
    printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    exit(1);
      e8:	52800020 	mov	w0, #0x1                   	// #1
  } else {
    printf("ALL TESTS PASSED\n");
    exit(0);
      ec:	94001154 	bl	463c <exit>
  char *justone = 0;
      f0:	d2800014 	mov	x20, #0x0                   	// #0
      f4:	17ffffe1 	b	78 <main+0x78>
      f8:	d2800014 	mov	x20, #0x0                   	// #0
    continuous = 1;
      fc:	52800033 	mov	w19, #0x1                   	// #1
     100:	17ffffdf 	b	7c <main+0x7c>
  char *justone = 0;
     104:	d2800014 	mov	x20, #0x0                   	// #0
     108:	17ffffdd 	b	7c <main+0x7c>
        if(!run(t->f, t->s)){
     10c:	f9400280 	ldr	x0, [x20]
     110:	94001062 	bl	4298 <run>
     114:	34000540 	cbz	w0, 1bc <main+0x1bc>
      for (struct test *t = tests; t->s != 0; t++) {
     118:	91004294 	add	x20, x20, #0x10
     11c:	17ffffe9 	b	c0 <main+0xc0>
  printf("usertests starting\n");
     120:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
     124:	912e2c00 	add	x0, x0, #0xb8b
     128:	94001321 	bl	4dac <printf>
  for (struct test *t = tests; t->s != 0; t++) {
     12c:	910103f5 	add	x21, sp, #0x40
  int free0 = countfree();
     130:	9400101e 	bl	41a8 <countfree>
     134:	2a0003f7 	mov	w23, w0
  for (struct test *t = tests; t->s != 0; t++) {
     138:	f94006b6 	ldr	x22, [x21, #8]
     13c:	b50000b6 	cbnz	x22, 150 <main+0x150>
  if(fail){
     140:	34000233 	cbz	w19, 184 <main+0x184>
    printf("SOME TESTS FAILED\n");
     144:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
     148:	912ef400 	add	x0, x0, #0xbbd
     14c:	17ffffba 	b	34 <main+0x34>
    if((justone == 0) || strcmp(t->s, justone) == 0) {
     150:	b5000114 	cbnz	x20, 170 <main+0x170>
      if(!run(t->f, t->s))
     154:	f94002a0 	ldr	x0, [x21]
     158:	aa1603e1 	mov	x1, x22
     15c:	9400104f 	bl	4298 <run>
     160:	52000000 	eor	w0, w0, #0x1
     164:	2a000273 	orr	w19, w19, w0
  for (struct test *t = tests; t->s != 0; t++) {
     168:	910042b5 	add	x21, x21, #0x10
     16c:	17fffff3 	b	138 <main+0x138>
    if((justone == 0) || strcmp(t->s, justone) == 0) {
     170:	aa1403e1 	mov	x1, x20
     174:	aa1603e0 	mov	x0, x22
     178:	9400108f 	bl	43b4 <strcmp>
     17c:	34fffec0 	cbz	w0, 154 <main+0x154>
     180:	17fffffa 	b	168 <main+0x168>
  } else if((free1 = countfree()) < free0){
     184:	94001009 	bl	41a8 <countfree>
     188:	2a0003e1 	mov	w1, w0
     18c:	6b0002ff 	cmp	w23, w0
     190:	540000cd 	b.le	1a8 <main+0x1a8>
    printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
     194:	2a1703e2 	mov	w2, w23
     198:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
     19c:	912f4000 	add	x0, x0, #0xbd0
     1a0:	94001303 	bl	4dac <printf>
     1a4:	17ffffd1 	b	e8 <main+0xe8>
    printf("ALL TESTS PASSED\n");
     1a8:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
     1ac:	912ffc00 	add	x0, x0, #0xbff
     1b0:	940012ff 	bl	4dac <printf>
    exit(0);
     1b4:	52800000 	mov	w0, #0x0                   	// #0
     1b8:	17ffffcd 	b	ec <main+0xec>
        printf("SOME TESTS FAILED\n");
     1bc:	aa1503e0 	mov	x0, x21
     1c0:	940012fb 	bl	4dac <printf>
        if(continuous != 2)
     1c4:	71000a7f 	cmp	w19, #0x2
     1c8:	54fff800 	b.eq	c8 <main+0xc8>  // b.none
     1cc:	17ffffc7 	b	e8 <main+0xe8>

00000000000001d0 <copyinstr1>:
{
     1d0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
     1d4:	d2b00000 	mov	x0, #0x80000000            	// #2147483648
{
     1d8:	910003fd 	mov	x29, sp
     1dc:	f90013f5 	str	x21, [sp, #32]
    uint64 addr = addrs[ai];
     1e0:	9100c3f5 	add	x21, sp, #0x30
{
     1e4:	a90153f3 	stp	x19, x20, [sp, #16]
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
     1e8:	d2800013 	mov	x19, #0x0                   	// #0
     1ec:	f9001be0 	str	x0, [sp, #48]
     1f0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
     1f4:	f9001fe0 	str	x0, [sp, #56]
    uint64 addr = addrs[ai];
     1f8:	f8737ab4 	ldr	x20, [x21, x19, lsl #3]
    int fd = open((char *)addr, O_CREATE|O_WRONLY);
     1fc:	52804021 	mov	w1, #0x201                 	// #513
     200:	aa1403e0 	mov	x0, x20
     204:	94001126 	bl	469c <open>
     208:	2a0003e2 	mov	w2, w0
    if(fd >= 0){
     20c:	37f80120 	tbnz	w0, #31, 230 <copyinstr1+0x60>
      printf("open(%p) returned %d, not -1\n", addr, fd);
     210:	aa1403e1 	mov	x1, x20
     214:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     218:	91008000 	add	x0, x0, #0x20
     21c:	940012e4 	bl	4dac <printf>
      exit(1);
     220:	52800020 	mov	w0, #0x1                   	// #1
     224:	94001106 	bl	463c <exit>
  for(int ai = 0; ai < 2; ai++){
     228:	d2800033 	mov	x19, #0x1                   	// #1
     22c:	17fffff3 	b	1f8 <copyinstr1+0x28>
     230:	b4ffffd3 	cbz	x19, 228 <copyinstr1+0x58>
}
     234:	f94013f5 	ldr	x21, [sp, #32]
     238:	a94153f3 	ldp	x19, x20, [sp, #16]
     23c:	a8c47bfd 	ldp	x29, x30, [sp], #64
     240:	d65f03c0 	ret

0000000000000244 <truncate2>:
{
     244:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     248:	910003fd 	mov	x29, sp
     24c:	a90153f3 	stp	x19, x20, [sp, #16]
     250:	a9025bf5 	stp	x21, x22, [sp, #32]
     254:	aa0003f5 	mov	x21, x0
  unlink("truncfile");
     258:	b0000033 	adrp	x19, 5000 <malloc+0xe4>
     25c:	9100fa60 	add	x0, x19, #0x3e
     260:	94001115 	bl	46b4 <unlink>
  int fd1 = open("truncfile", O_CREATE|O_TRUNC|O_WRONLY);
     264:	5280c021 	mov	w1, #0x601                 	// #1537
     268:	9100fa60 	add	x0, x19, #0x3e
     26c:	9400110c 	bl	469c <open>
     270:	2a0003f4 	mov	w20, w0
  write(fd1, "abcd", 4);
     274:	52800082 	mov	w2, #0x4                   	// #4
     278:	b0000021 	adrp	x1, 5000 <malloc+0xe4>
     27c:	91012021 	add	x1, x1, #0x48
     280:	940010fb 	bl	466c <write>
  int fd2 = open("truncfile", O_TRUNC|O_WRONLY);
     284:	52808021 	mov	w1, #0x401                 	// #1025
     288:	9100fa60 	add	x0, x19, #0x3e
     28c:	94001104 	bl	469c <open>
     290:	2a0003f6 	mov	w22, w0
  int n = write(fd1, "x", 1);
     294:	d0000021 	adrp	x1, 6000 <malloc+0x10e4>
     298:	9106f021 	add	x1, x1, #0x1bc
     29c:	2a1403e0 	mov	w0, w20
     2a0:	52800022 	mov	w2, #0x1                   	// #1
     2a4:	940010f2 	bl	466c <write>
  if(n != -1){
     2a8:	3100041f 	cmn	w0, #0x1
     2ac:	54000100 	b.eq	2cc <truncate2+0x88>  // b.none
     2b0:	2a0003e2 	mov	w2, w0
    printf("%s: write returned %d, expected -1\n", s, n);
     2b4:	aa1503e1 	mov	x1, x21
     2b8:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     2bc:	91013400 	add	x0, x0, #0x4d
     2c0:	940012bb 	bl	4dac <printf>
    exit(1);
     2c4:	52800020 	mov	w0, #0x1                   	// #1
     2c8:	940010dd 	bl	463c <exit>
  unlink("truncfile");
     2cc:	9100fa60 	add	x0, x19, #0x3e
     2d0:	940010f9 	bl	46b4 <unlink>
  close(fd1);
     2d4:	2a1403e0 	mov	w0, w20
     2d8:	940010e8 	bl	4678 <close>
  close(fd2);
     2dc:	2a1603e0 	mov	w0, w22
}
     2e0:	a94153f3 	ldp	x19, x20, [sp, #16]
     2e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
     2e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
  close(fd2);
     2ec:	140010e3 	b	4678 <close>

00000000000002f0 <createtest>:
{
     2f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  name[0] = 'a';
     2f4:	52800c20 	mov	w0, #0x61                  	// #97
{
     2f8:	910003fd 	mov	x29, sp
     2fc:	f9000bf3 	str	x19, [sp, #16]
  name[2] = '\0';
     300:	52800613 	mov	w19, #0x30                  	// #48
  name[0] = 'a';
     304:	3900a3e0 	strb	w0, [sp, #40]
  name[2] = '\0';
     308:	3900abff 	strb	wzr, [sp, #42]
    fd = open(name, O_CREATE|O_RDWR);
     30c:	52804041 	mov	w1, #0x202                 	// #514
    name[1] = '0' + i;
     310:	3900a7f3 	strb	w19, [sp, #41]
  for(i = 0; i < N; i++){
     314:	11000673 	add	w19, w19, #0x1
    fd = open(name, O_CREATE|O_RDWR);
     318:	9100a3e0 	add	x0, sp, #0x28
  for(i = 0; i < N; i++){
     31c:	12001e73 	and	w19, w19, #0xff
    fd = open(name, O_CREATE|O_RDWR);
     320:	940010df 	bl	469c <open>
    close(fd);
     324:	940010d5 	bl	4678 <close>
  for(i = 0; i < N; i++){
     328:	7101927f 	cmp	w19, #0x64
     32c:	54ffff01 	b.ne	30c <createtest+0x1c>  // b.any
  name[0] = 'a';
     330:	52800c20 	mov	w0, #0x61                  	// #97
  name[2] = '\0';
     334:	52800613 	mov	w19, #0x30                  	// #48
  name[0] = 'a';
     338:	3900a3e0 	strb	w0, [sp, #40]
  name[2] = '\0';
     33c:	3900abff 	strb	wzr, [sp, #42]
    name[1] = '0' + i;
     340:	3900a7f3 	strb	w19, [sp, #41]
  for(i = 0; i < N; i++){
     344:	11000673 	add	w19, w19, #0x1
    unlink(name);
     348:	9100a3e0 	add	x0, sp, #0x28
  for(i = 0; i < N; i++){
     34c:	12001e73 	and	w19, w19, #0xff
    unlink(name);
     350:	940010d9 	bl	46b4 <unlink>
  for(i = 0; i < N; i++){
     354:	7101927f 	cmp	w19, #0x64
     358:	54ffff41 	b.ne	340 <createtest+0x50>  // b.any
}
     35c:	f9400bf3 	ldr	x19, [sp, #16]
     360:	a8c37bfd 	ldp	x29, x30, [sp], #48
     364:	d65f03c0 	ret

0000000000000368 <bigwrite>:
{
     368:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     36c:	910003fd 	mov	x29, sp
     370:	a9025bf5 	stp	x21, x22, [sp, #32]
      int cc = write(fd, buf, sz);
     374:	d0000056 	adrp	x22, a000 <uninit+0x1cb7>
     378:	912966d6 	add	x22, x22, #0xa59
{
     37c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     380:	52803e73 	mov	w19, #0x1f3                 	// #499
  unlink("bigwrite");
     384:	b0000034 	adrp	x20, 5000 <malloc+0xe4>
     388:	9101c694 	add	x20, x20, #0x71
{
     38c:	a90363f7 	stp	x23, x24, [sp, #48]
     390:	aa0003f7 	mov	x23, x0
  unlink("bigwrite");
     394:	aa1403e0 	mov	x0, x20
     398:	940010c7 	bl	46b4 <unlink>
    fd = open("bigwrite", O_CREATE | O_RDWR);
     39c:	aa1403e0 	mov	x0, x20
     3a0:	52804041 	mov	w1, #0x202                 	// #514
     3a4:	940010be 	bl	469c <open>
     3a8:	2a0003f5 	mov	w21, w0
    if(fd < 0){
     3ac:	36f800e0 	tbz	w0, #31, 3c8 <bigwrite+0x60>
      printf("%s: cannot create bigwrite\n", s);
     3b0:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     3b4:	9101e800 	add	x0, x0, #0x7a
     3b8:	aa1703e1 	mov	x1, x23
     3bc:	9400127c 	bl	4dac <printf>
        exit(1);
     3c0:	52800020 	mov	w0, #0x1                   	// #1
     3c4:	9400109e 	bl	463c <exit>
    if(fd < 0){
     3c8:	52800058 	mov	w24, #0x2                   	// #2
      int cc = write(fd, buf, sz);
     3cc:	2a1303e2 	mov	w2, w19
     3d0:	aa1603e1 	mov	x1, x22
     3d4:	2a1503e0 	mov	w0, w21
     3d8:	940010a5 	bl	466c <write>
     3dc:	2a0003e3 	mov	w3, w0
      if(cc != sz){
     3e0:	6b13001f 	cmp	w0, w19
     3e4:	54000120 	b.eq	408 <bigwrite+0xa0>  // b.none
        printf("%s: write(%d) ret %d\n", s, sz, cc);
     3e8:	2a1303e2 	mov	w2, w19
     3ec:	aa1703e1 	mov	x1, x23
     3f0:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     3f4:	91025800 	add	x0, x0, #0x96
     3f8:	9400126d 	bl	4dac <printf>
     3fc:	17fffff1 	b	3c0 <bigwrite+0x58>
    for(i = 0; i < 2; i++){
     400:	52800038 	mov	w24, #0x1                   	// #1
     404:	17fffff2 	b	3cc <bigwrite+0x64>
     408:	7100071f 	cmp	w24, #0x1
     40c:	54ffffa1 	b.ne	400 <bigwrite+0x98>  // b.any
    close(fd);
     410:	2a1503e0 	mov	w0, w21
     414:	94001099 	bl	4678 <close>
    unlink("bigwrite");
     418:	aa1403e0 	mov	x0, x20
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     41c:	11075e73 	add	w19, w19, #0x1d7
    unlink("bigwrite");
     420:	940010a5 	bl	46b4 <unlink>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     424:	52863920 	mov	w0, #0x31c9                	// #12745
     428:	6b00027f 	cmp	w19, w0
     42c:	54fffb81 	b.ne	39c <bigwrite+0x34>  // b.any
}
     430:	a94153f3 	ldp	x19, x20, [sp, #16]
     434:	a9425bf5 	ldp	x21, x22, [sp, #32]
     438:	a94363f7 	ldp	x23, x24, [sp, #48]
     43c:	a8c47bfd 	ldp	x29, x30, [sp], #64
     440:	d65f03c0 	ret

0000000000000444 <copyin>:
{
     444:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
     448:	d2b00000 	mov	x0, #0x80000000            	// #2147483648
{
     44c:	910003fd 	mov	x29, sp
     450:	a90153f3 	stp	x19, x20, [sp, #16]
    int fd = open("copyin1", O_CREATE|O_WRONLY);
     454:	b0000034 	adrp	x20, 5000 <malloc+0xe4>
     458:	9102b294 	add	x20, x20, #0xac
{
     45c:	f9001bf7 	str	x23, [sp, #48]
    uint64 addr = addrs[ai];
     460:	910143f7 	add	x23, sp, #0x50
{
     464:	a9025bf5 	stp	x21, x22, [sp, #32]
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
     468:	d2800015 	mov	x21, #0x0                   	// #0
     46c:	f9002be0 	str	x0, [sp, #80]
     470:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
     474:	f9002fe0 	str	x0, [sp, #88]
    uint64 addr = addrs[ai];
     478:	f8757af3 	ldr	x19, [x23, x21, lsl #3]
    int fd = open("copyin1", O_CREATE|O_WRONLY);
     47c:	aa1403e0 	mov	x0, x20
     480:	52804021 	mov	w1, #0x201                 	// #513
     484:	94001086 	bl	469c <open>
     488:	2a0003f6 	mov	w22, w0
    if(fd < 0){
     48c:	36f800e0 	tbz	w0, #31, 4a8 <copyin+0x64>
      printf("open(copyin1) failed\n");
     490:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     494:	9102d000 	add	x0, x0, #0xb4
      printf("pipe() failed\n");
     498:	94001245 	bl	4dac <printf>
      exit(1);
     49c:	1400000c 	b	4cc <copyin+0x88>
  for(int ai = 0; ai < 2; ai++){
     4a0:	d2800035 	mov	x21, #0x1                   	// #1
     4a4:	17fffff5 	b	478 <copyin+0x34>
    int n = write(fd, (void*)addr, 8192);
     4a8:	52840002 	mov	w2, #0x2000                	// #8192
     4ac:	aa1303e1 	mov	x1, x19
     4b0:	9400106f 	bl	466c <write>
     4b4:	2a0003e2 	mov	w2, w0
    if(n >= 0){
     4b8:	37f800e0 	tbnz	w0, #31, 4d4 <copyin+0x90>
      printf("write(fd, %p, 8192) returned %d, not -1\n", addr, n);
     4bc:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     4c0:	91032800 	add	x0, x0, #0xca
     4c4:	aa1303e1 	mov	x1, x19
     4c8:	94001239 	bl	4dac <printf>
      exit(1);
     4cc:	52800020 	mov	w0, #0x1                   	// #1
     4d0:	9400105b 	bl	463c <exit>
    close(fd);
     4d4:	2a1603e0 	mov	w0, w22
     4d8:	94001068 	bl	4678 <close>
    unlink("copyin1");
     4dc:	aa1403e0 	mov	x0, x20
     4e0:	94001075 	bl	46b4 <unlink>
    n = write(1, (char*)addr, 8192);
     4e4:	52840002 	mov	w2, #0x2000                	// #8192
     4e8:	aa1303e1 	mov	x1, x19
     4ec:	52800020 	mov	w0, #0x1                   	// #1
     4f0:	9400105f 	bl	466c <write>
     4f4:	2a0003e2 	mov	w2, w0
    if(n > 0){
     4f8:	7100001f 	cmp	w0, #0x0
     4fc:	5400008d 	b.le	50c <copyin+0xc8>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", addr, n);
     500:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     504:	9103cc00 	add	x0, x0, #0xf3
     508:	17ffffef 	b	4c4 <copyin+0x80>
    if(pipe(fds) < 0){
     50c:	910123e0 	add	x0, sp, #0x48
     510:	94001051 	bl	4654 <pipe>
     514:	36f80080 	tbz	w0, #31, 524 <copyin+0xe0>
      printf("pipe() failed\n");
     518:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     51c:	911af800 	add	x0, x0, #0x6be
     520:	17ffffde 	b	498 <copyin+0x54>
    n = write(fds[1], (char*)addr, 8192);
     524:	b9404fe0 	ldr	w0, [sp, #76]
     528:	52840002 	mov	w2, #0x2000                	// #8192
     52c:	aa1303e1 	mov	x1, x19
     530:	9400104f 	bl	466c <write>
     534:	2a0003e2 	mov	w2, w0
    if(n > 0){
     538:	7100001f 	cmp	w0, #0x0
     53c:	5400008d 	b.le	54c <copyin+0x108>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", addr, n);
     540:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     544:	91048000 	add	x0, x0, #0x120
     548:	17ffffdf 	b	4c4 <copyin+0x80>
    close(fds[0]);
     54c:	b9404be0 	ldr	w0, [sp, #72]
     550:	9400104a 	bl	4678 <close>
    close(fds[1]);
     554:	b9404fe0 	ldr	w0, [sp, #76]
     558:	94001048 	bl	4678 <close>
  for(int ai = 0; ai < 2; ai++){
     55c:	b4fffa35 	cbz	x21, 4a0 <copyin+0x5c>
}
     560:	f9401bf7 	ldr	x23, [sp, #48]
     564:	a94153f3 	ldp	x19, x20, [sp, #16]
     568:	a9425bf5 	ldp	x21, x22, [sp, #32]
     56c:	a8c67bfd 	ldp	x29, x30, [sp], #96
     570:	d65f03c0 	ret

0000000000000574 <copyout>:
{
     574:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
     578:	d2b00000 	mov	x0, #0x80000000            	// #2147483648
{
     57c:	910003fd 	mov	x29, sp
     580:	a9025bf5 	stp	x21, x22, [sp, #32]
    int fd = open("README", 0);
     584:	b0000035 	adrp	x21, 5000 <malloc+0xe4>
     588:	910542b5 	add	x21, x21, #0x150
    n = write(fds[1], "x", 1);
     58c:	d0000036 	adrp	x22, 6000 <malloc+0x10e4>
     590:	9106f2d6 	add	x22, x22, #0x1bc
{
     594:	a90363f7 	stp	x23, x24, [sp, #48]
    uint64 addr = addrs[ai];
     598:	910143f8 	add	x24, sp, #0x50
{
     59c:	a90153f3 	stp	x19, x20, [sp, #16]
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
     5a0:	d2800014 	mov	x20, #0x0                   	// #0
     5a4:	f9002be0 	str	x0, [sp, #80]
     5a8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
     5ac:	f9002fe0 	str	x0, [sp, #88]
    uint64 addr = addrs[ai];
     5b0:	f8747b13 	ldr	x19, [x24, x20, lsl #3]
    int fd = open("README", 0);
     5b4:	aa1503e0 	mov	x0, x21
     5b8:	52800001 	mov	w1, #0x0                   	// #0
     5bc:	94001038 	bl	469c <open>
     5c0:	2a0003f7 	mov	w23, w0
    if(fd < 0){
     5c4:	36f800e0 	tbz	w0, #31, 5e0 <copyout+0x6c>
      printf("open(README) failed\n");
     5c8:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     5cc:	91055c00 	add	x0, x0, #0x157
      printf("pipe write failed\n");
     5d0:	940011f7 	bl	4dac <printf>
      exit(1);
     5d4:	1400000d 	b	608 <copyout+0x94>
  for(int ai = 0; ai < 2; ai++){
     5d8:	d2800034 	mov	x20, #0x1                   	// #1
     5dc:	17fffff5 	b	5b0 <copyout+0x3c>
    int n = read(fd, (void*)addr, 8192);
     5e0:	52840002 	mov	w2, #0x2000                	// #8192
     5e4:	aa1303e1 	mov	x1, x19
     5e8:	9400101e 	bl	4660 <read>
     5ec:	2a0003e2 	mov	w2, w0
    if(n > 0){
     5f0:	7100001f 	cmp	w0, #0x0
     5f4:	540000ed 	b.le	610 <copyout+0x9c>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", addr, n);
     5f8:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     5fc:	9105b000 	add	x0, x0, #0x16c
     600:	aa1303e1 	mov	x1, x19
     604:	940011ea 	bl	4dac <printf>
      exit(1);
     608:	52800020 	mov	w0, #0x1                   	// #1
     60c:	9400100c 	bl	463c <exit>
    close(fd);
     610:	2a1703e0 	mov	w0, w23
     614:	94001019 	bl	4678 <close>
    if(pipe(fds) < 0){
     618:	910123e0 	add	x0, sp, #0x48
     61c:	9400100e 	bl	4654 <pipe>
     620:	36f80080 	tbz	w0, #31, 630 <copyout+0xbc>
      printf("pipe() failed\n");
     624:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     628:	911af800 	add	x0, x0, #0x6be
     62c:	17ffffe9 	b	5d0 <copyout+0x5c>
    n = write(fds[1], "x", 1);
     630:	b9404fe0 	ldr	w0, [sp, #76]
     634:	aa1603e1 	mov	x1, x22
     638:	52800022 	mov	w2, #0x1                   	// #1
     63c:	9400100c 	bl	466c <write>
    if(n != 1){
     640:	7100041f 	cmp	w0, #0x1
     644:	54000080 	b.eq	654 <copyout+0xe0>  // b.none
      printf("pipe write failed\n");
     648:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     64c:	91066400 	add	x0, x0, #0x199
     650:	17ffffe0 	b	5d0 <copyout+0x5c>
    n = read(fds[0], (void*)addr, 8192);
     654:	b9404be0 	ldr	w0, [sp, #72]
     658:	52840002 	mov	w2, #0x2000                	// #8192
     65c:	aa1303e1 	mov	x1, x19
     660:	94001000 	bl	4660 <read>
     664:	2a0003e2 	mov	w2, w0
    if(n > 0){
     668:	7100001f 	cmp	w0, #0x0
     66c:	5400008d 	b.le	67c <copyout+0x108>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", addr, n);
     670:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     674:	9106b000 	add	x0, x0, #0x1ac
     678:	17ffffe2 	b	600 <copyout+0x8c>
    close(fds[0]);
     67c:	b9404be0 	ldr	w0, [sp, #72]
     680:	94000ffe 	bl	4678 <close>
    close(fds[1]);
     684:	b9404fe0 	ldr	w0, [sp, #76]
     688:	94000ffc 	bl	4678 <close>
  for(int ai = 0; ai < 2; ai++){
     68c:	b4fffa74 	cbz	x20, 5d8 <copyout+0x64>
}
     690:	a94153f3 	ldp	x19, x20, [sp, #16]
     694:	a9425bf5 	ldp	x21, x22, [sp, #32]
     698:	a94363f7 	ldp	x23, x24, [sp, #48]
     69c:	a8c67bfd 	ldp	x29, x30, [sp], #96
     6a0:	d65f03c0 	ret

00000000000006a4 <truncate1>:
{
     6a4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
     6a8:	910003fd 	mov	x29, sp
     6ac:	a90153f3 	stp	x19, x20, [sp, #16]
     6b0:	aa0003f4 	mov	x20, x0
  unlink("truncfile");
     6b4:	b0000033 	adrp	x19, 5000 <malloc+0xe4>
     6b8:	9100fa60 	add	x0, x19, #0x3e
{
     6bc:	a9025bf5 	stp	x21, x22, [sp, #32]
     6c0:	a90363f7 	stp	x23, x24, [sp, #48]
  unlink("truncfile");
     6c4:	94000ffc 	bl	46b4 <unlink>
  int fd1 = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
     6c8:	5280c021 	mov	w1, #0x601                 	// #1537
     6cc:	9100fa60 	add	x0, x19, #0x3e
     6d0:	94000ff3 	bl	469c <open>
  write(fd1, "abcd", 4);
     6d4:	b0000021 	adrp	x1, 5000 <malloc+0xe4>
     6d8:	91012021 	add	x1, x1, #0x48
     6dc:	52800082 	mov	w2, #0x4                   	// #4
  int fd1 = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
     6e0:	2a0003f5 	mov	w21, w0
  write(fd1, "abcd", 4);
     6e4:	94000fe2 	bl	466c <write>
  close(fd1);
     6e8:	2a1503e0 	mov	w0, w21
     6ec:	94000fe3 	bl	4678 <close>
  int fd2 = open("truncfile", O_RDONLY);
     6f0:	52800001 	mov	w1, #0x0                   	// #0
     6f4:	9100fa60 	add	x0, x19, #0x3e
     6f8:	94000fe9 	bl	469c <open>
     6fc:	2a0003f5 	mov	w21, w0
  int n = read(fd2, buf, sizeof(buf));
     700:	910103e1 	add	x1, sp, #0x40
     704:	52800402 	mov	w2, #0x20                  	// #32
     708:	94000fd6 	bl	4660 <read>
  if(n != 4){
     70c:	7100101f 	cmp	w0, #0x4
     710:	54000100 	b.eq	730 <truncate1+0x8c>  // b.none
     714:	2a0003e2 	mov	w2, w0
    printf("%s: read %d bytes, wanted 4\n", s, n);
     718:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     71c:	91076c00 	add	x0, x0, #0x1db
    printf("%s: read %d bytes, wanted 0\n", s, n);
     720:	aa1403e1 	mov	x1, x20
     724:	940011a2 	bl	4dac <printf>
    exit(1);
     728:	52800020 	mov	w0, #0x1                   	// #1
     72c:	94000fc4 	bl	463c <exit>
  fd1 = open("truncfile", O_WRONLY|O_TRUNC);
     730:	52808021 	mov	w1, #0x401                 	// #1025
     734:	9100fa60 	add	x0, x19, #0x3e
     738:	94000fd9 	bl	469c <open>
     73c:	2a0003f7 	mov	w23, w0
  int fd3 = open("truncfile", O_RDONLY);
     740:	52800001 	mov	w1, #0x0                   	// #0
     744:	9100fa60 	add	x0, x19, #0x3e
     748:	94000fd5 	bl	469c <open>
     74c:	2a0003f6 	mov	w22, w0
  n = read(fd3, buf, sizeof(buf));
     750:	910103e1 	add	x1, sp, #0x40
     754:	52800402 	mov	w2, #0x20                  	// #32
     758:	94000fc2 	bl	4660 <read>
     75c:	2a0003f8 	mov	w24, w0
  if(n != 0){
     760:	34000120 	cbz	w0, 784 <truncate1+0xe0>
    printf("aaa fd3=%d\n", fd3);
     764:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     768:	9107e000 	add	x0, x0, #0x1f8
     76c:	2a1603e1 	mov	w1, w22
     770:	9400118f 	bl	4dac <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     774:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     778:	91081000 	add	x0, x0, #0x204
     77c:	2a1803e2 	mov	w2, w24
     780:	17ffffe8 	b	720 <truncate1+0x7c>
  n = read(fd2, buf, sizeof(buf));
     784:	910103e1 	add	x1, sp, #0x40
     788:	2a1503e0 	mov	w0, w21
     78c:	52800402 	mov	w2, #0x20                  	// #32
     790:	94000fb4 	bl	4660 <read>
     794:	2a0003f8 	mov	w24, w0
  if(n != 0){
     798:	340000a0 	cbz	w0, 7ac <truncate1+0x108>
    printf("bbb fd2=%d\n", fd2);
     79c:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     7a0:	91088400 	add	x0, x0, #0x221
     7a4:	2a1503e1 	mov	w1, w21
     7a8:	17fffff2 	b	770 <truncate1+0xcc>
  write(fd1, "abcdef", 6);
     7ac:	528000c2 	mov	w2, #0x6                   	// #6
     7b0:	2a1703e0 	mov	w0, w23
     7b4:	b0000021 	adrp	x1, 5000 <malloc+0xe4>
     7b8:	9108b421 	add	x1, x1, #0x22d
     7bc:	94000fac 	bl	466c <write>
  n = read(fd3, buf, sizeof(buf));
     7c0:	52800402 	mov	w2, #0x20                  	// #32
     7c4:	910103e1 	add	x1, sp, #0x40
     7c8:	2a1603e0 	mov	w0, w22
     7cc:	94000fa5 	bl	4660 <read>
     7d0:	2a0003e2 	mov	w2, w0
  if(n != 6){
     7d4:	7100181f 	cmp	w0, #0x6
     7d8:	54000080 	b.eq	7e8 <truncate1+0x144>  // b.none
    printf("%s: read %d bytes, wanted 6\n", s, n);
     7dc:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     7e0:	9108d000 	add	x0, x0, #0x234
     7e4:	17ffffcf 	b	720 <truncate1+0x7c>
  n = read(fd2, buf, sizeof(buf));
     7e8:	52800402 	mov	w2, #0x20                  	// #32
     7ec:	910103e1 	add	x1, sp, #0x40
     7f0:	2a1503e0 	mov	w0, w21
     7f4:	94000f9b 	bl	4660 <read>
     7f8:	2a0003e2 	mov	w2, w0
  if(n != 2){
     7fc:	7100081f 	cmp	w0, #0x2
     800:	54000080 	b.eq	810 <truncate1+0x16c>  // b.none
    printf("%s: read %d bytes, wanted 2\n", s, n);
     804:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     808:	91094400 	add	x0, x0, #0x251
     80c:	17ffffc5 	b	720 <truncate1+0x7c>
  unlink("truncfile");
     810:	9100fa60 	add	x0, x19, #0x3e
     814:	94000fa8 	bl	46b4 <unlink>
  close(fd1);
     818:	2a1703e0 	mov	w0, w23
     81c:	94000f97 	bl	4678 <close>
  close(fd2);
     820:	2a1503e0 	mov	w0, w21
     824:	94000f95 	bl	4678 <close>
  close(fd3);
     828:	2a1603e0 	mov	w0, w22
     82c:	94000f93 	bl	4678 <close>
}
     830:	a94153f3 	ldp	x19, x20, [sp, #16]
     834:	a9425bf5 	ldp	x21, x22, [sp, #32]
     838:	a94363f7 	ldp	x23, x24, [sp, #48]
     83c:	a8c67bfd 	ldp	x29, x30, [sp], #96
     840:	d65f03c0 	ret

0000000000000844 <writetest>:
{
     844:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  fd = open("small", O_CREATE|O_RDWR);
     848:	52804041 	mov	w1, #0x202                 	// #514
{
     84c:	910003fd 	mov	x29, sp
     850:	a90153f3 	stp	x19, x20, [sp, #16]
  fd = open("small", O_CREATE|O_RDWR);
     854:	b0000034 	adrp	x20, 5000 <malloc+0xe4>
     858:	9109ba94 	add	x20, x20, #0x26e
{
     85c:	aa0003f3 	mov	x19, x0
  fd = open("small", O_CREATE|O_RDWR);
     860:	aa1403e0 	mov	x0, x20
{
     864:	a9025bf5 	stp	x21, x22, [sp, #32]
     868:	a90363f7 	stp	x23, x24, [sp, #48]
  fd = open("small", O_CREATE|O_RDWR);
     86c:	94000f8c 	bl	469c <open>
  if(fd < 0){
     870:	37f80280 	tbnz	w0, #31, 8c0 <writetest+0x7c>
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
     874:	b0000037 	adrp	x23, 5000 <malloc+0xe4>
     878:	910a52f7 	add	x23, x23, #0x294
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
     87c:	b0000038 	adrp	x24, 5000 <malloc+0xe4>
     880:	910b1f18 	add	x24, x24, #0x2c7
     884:	2a0003f6 	mov	w22, w0
     888:	52800015 	mov	w21, #0x0                   	// #0
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
     88c:	aa1703e1 	mov	x1, x23
     890:	2a1603e0 	mov	w0, w22
     894:	52800142 	mov	w2, #0xa                   	// #10
     898:	94000f75 	bl	466c <write>
     89c:	7100281f 	cmp	w0, #0xa
     8a0:	540001a0 	b.eq	8d4 <writetest+0x90>  // b.none
      printf("%s: error: write aa %d new file failed\n", s, i);
     8a4:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     8a8:	910a7c00 	add	x0, x0, #0x29f
     8ac:	2a1503e2 	mov	w2, w21
     8b0:	aa1303e1 	mov	x1, x19
     8b4:	9400113e 	bl	4dac <printf>
      exit(1);
     8b8:	52800020 	mov	w0, #0x1                   	// #1
     8bc:	94000f60 	bl	463c <exit>
    printf("%s: error: creat small failed!\n", s);
     8c0:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     8c4:	9109d000 	add	x0, x0, #0x274
    printf("%s: unlink small failed\n", s);
     8c8:	aa1303e1 	mov	x1, x19
     8cc:	94001138 	bl	4dac <printf>
    exit(1);
     8d0:	17fffffa 	b	8b8 <writetest+0x74>
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
     8d4:	2a0003e2 	mov	w2, w0
     8d8:	aa1803e1 	mov	x1, x24
     8dc:	2a1603e0 	mov	w0, w22
     8e0:	94000f63 	bl	466c <write>
     8e4:	7100281f 	cmp	w0, #0xa
     8e8:	54000080 	b.eq	8f8 <writetest+0xb4>  // b.none
      printf("%s: error: write bb %d new file failed\n", s, i);
     8ec:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     8f0:	910b4800 	add	x0, x0, #0x2d2
     8f4:	17ffffee 	b	8ac <writetest+0x68>
  for(i = 0; i < N; i++){
     8f8:	110006b5 	add	w21, w21, #0x1
     8fc:	710192bf 	cmp	w21, #0x64
     900:	54fffc61 	b.ne	88c <writetest+0x48>  // b.any
  close(fd);
     904:	2a1603e0 	mov	w0, w22
     908:	94000f5c 	bl	4678 <close>
  fd = open("small", O_RDONLY);
     90c:	aa1403e0 	mov	x0, x20
     910:	52800001 	mov	w1, #0x0                   	// #0
     914:	94000f62 	bl	469c <open>
     918:	2a0003f5 	mov	w21, w0
  if(fd < 0){
     91c:	36f80080 	tbz	w0, #31, 92c <writetest+0xe8>
    printf("%s: error: open small failed!\n", s);
     920:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     924:	910be800 	add	x0, x0, #0x2fa
     928:	17ffffe8 	b	8c8 <writetest+0x84>
  i = read(fd, buf, N*SZ*2);
     92c:	d0000041 	adrp	x1, a000 <uninit+0x1cb7>
     930:	91296421 	add	x1, x1, #0xa59
     934:	5280fa02 	mov	w2, #0x7d0                 	// #2000
     938:	94000f4a 	bl	4660 <read>
  if(i != N*SZ*2){
     93c:	711f401f 	cmp	w0, #0x7d0
     940:	54000080 	b.eq	950 <writetest+0x10c>  // b.none
    printf("%s: read failed\n", s);
     944:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     948:	910c6400 	add	x0, x0, #0x319
     94c:	17ffffdf 	b	8c8 <writetest+0x84>
  close(fd);
     950:	2a1503e0 	mov	w0, w21
     954:	94000f49 	bl	4678 <close>
  if(unlink("small") < 0){
     958:	aa1403e0 	mov	x0, x20
     95c:	94000f56 	bl	46b4 <unlink>
     960:	36f80080 	tbz	w0, #31, 970 <writetest+0x12c>
    printf("%s: unlink small failed\n", s);
     964:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     968:	910ca800 	add	x0, x0, #0x32a
     96c:	17ffffd7 	b	8c8 <writetest+0x84>
}
     970:	a94153f3 	ldp	x19, x20, [sp, #16]
     974:	a9425bf5 	ldp	x21, x22, [sp, #32]
     978:	a94363f7 	ldp	x23, x24, [sp, #48]
     97c:	a8c47bfd 	ldp	x29, x30, [sp], #64
     980:	d65f03c0 	ret

0000000000000984 <unlinkread>:
{
     984:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  fd = open("unlinkread", O_CREATE | O_RDWR);
     988:	52804041 	mov	w1, #0x202                 	// #514
{
     98c:	910003fd 	mov	x29, sp
     990:	a90153f3 	stp	x19, x20, [sp, #16]
     994:	aa0003f4 	mov	x20, x0
  fd = open("unlinkread", O_CREATE | O_RDWR);
     998:	b0000033 	adrp	x19, 5000 <malloc+0xe4>
     99c:	910d0e60 	add	x0, x19, #0x343
{
     9a0:	a9025bf5 	stp	x21, x22, [sp, #32]
     9a4:	f9001bf7 	str	x23, [sp, #48]
  fd = open("unlinkread", O_CREATE | O_RDWR);
     9a8:	94000f3d 	bl	469c <open>
  if(fd < 0){
     9ac:	36f800e0 	tbz	w0, #31, 9c8 <unlinkread+0x44>
    printf("%s: create unlinkread failed\n", s);
     9b0:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     9b4:	910d3800 	add	x0, x0, #0x34e
    printf("%s: open unlinkread failed\n", s);
     9b8:	aa1403e1 	mov	x1, x20
     9bc:	940010fc 	bl	4dac <printf>
    exit(1);
     9c0:	52800020 	mov	w0, #0x1                   	// #1
     9c4:	94000f1e 	bl	463c <exit>
  write(fd, "hello", SZ);
     9c8:	b0000021 	adrp	x1, 5000 <malloc+0xe4>
     9cc:	910db021 	add	x1, x1, #0x36c
     9d0:	528000a2 	mov	w2, #0x5                   	// #5
     9d4:	2a0003f5 	mov	w21, w0
     9d8:	94000f25 	bl	466c <write>
  close(fd);
     9dc:	2a1503e0 	mov	w0, w21
     9e0:	94000f26 	bl	4678 <close>
  fd = open("unlinkread", O_RDWR);
     9e4:	910d0e60 	add	x0, x19, #0x343
     9e8:	52800041 	mov	w1, #0x2                   	// #2
     9ec:	94000f2c 	bl	469c <open>
     9f0:	2a0003f5 	mov	w21, w0
  if(fd < 0){
     9f4:	36f80080 	tbz	w0, #31, a04 <unlinkread+0x80>
    printf("%s: open unlinkread failed\n", s);
     9f8:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     9fc:	910dc800 	add	x0, x0, #0x372
     a00:	17ffffee 	b	9b8 <unlinkread+0x34>
  if(unlink("unlinkread") != 0){
     a04:	910d0e60 	add	x0, x19, #0x343
     a08:	94000f2b 	bl	46b4 <unlink>
     a0c:	34000080 	cbz	w0, a1c <unlinkread+0x98>
    printf("%s: unlink unlinkread failed\n", s);
     a10:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     a14:	910e3800 	add	x0, x0, #0x38e
     a18:	17ffffe8 	b	9b8 <unlinkread+0x34>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
     a1c:	52804041 	mov	w1, #0x202                 	// #514
     a20:	910d0e60 	add	x0, x19, #0x343
     a24:	94000f1e 	bl	469c <open>
     a28:	2a0003f6 	mov	w22, w0
  write(fd1, "yyy", 3);
     a2c:	b0000021 	adrp	x1, 5000 <malloc+0xe4>
     a30:	910eb021 	add	x1, x1, #0x3ac
     a34:	52800062 	mov	w2, #0x3                   	// #3
     a38:	94000f0d 	bl	466c <write>
  close(fd1);
     a3c:	2a1603e0 	mov	w0, w22
  if(read(fd, buf, sizeof(buf)) != SZ){
     a40:	d0000057 	adrp	x23, a000 <uninit+0x1cb7>
  close(fd1);
     a44:	94000f0d 	bl	4678 <close>
  if(read(fd, buf, sizeof(buf)) != SZ){
     a48:	912966e1 	add	x1, x23, #0xa59
     a4c:	2a1503e0 	mov	w0, w21
     a50:	52860002 	mov	w2, #0x3000                	// #12288
     a54:	94000f03 	bl	4660 <read>
     a58:	7100141f 	cmp	w0, #0x5
     a5c:	54000080 	b.eq	a6c <unlinkread+0xe8>  // b.none
    printf("%s: unlinkread read failed", s);
     a60:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     a64:	910ec000 	add	x0, x0, #0x3b0
     a68:	17ffffd4 	b	9b8 <unlinkread+0x34>
  if(buf[0] != 'h'){
     a6c:	396966e0 	ldrb	w0, [x23, #2649]
     a70:	7101a01f 	cmp	w0, #0x68
     a74:	54000080 	b.eq	a84 <unlinkread+0x100>  // b.none
    printf("%s: unlinkread wrong data\n", s);
     a78:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     a7c:	910f2c00 	add	x0, x0, #0x3cb
     a80:	17ffffce 	b	9b8 <unlinkread+0x34>
  if(write(fd, buf, 10) != 10){
     a84:	912966e1 	add	x1, x23, #0xa59
     a88:	2a1503e0 	mov	w0, w21
     a8c:	52800142 	mov	w2, #0xa                   	// #10
     a90:	94000ef7 	bl	466c <write>
     a94:	7100281f 	cmp	w0, #0xa
     a98:	54000080 	b.eq	aa8 <unlinkread+0x124>  // b.none
    printf("%s: unlinkread write failed\n", s);
     a9c:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     aa0:	910f9800 	add	x0, x0, #0x3e6
     aa4:	17ffffc5 	b	9b8 <unlinkread+0x34>
  close(fd);
     aa8:	2a1503e0 	mov	w0, w21
     aac:	94000ef3 	bl	4678 <close>
}
     ab0:	f9401bf7 	ldr	x23, [sp, #48]
  unlink("unlinkread");
     ab4:	910d0e60 	add	x0, x19, #0x343
}
     ab8:	a9425bf5 	ldp	x21, x22, [sp, #32]
     abc:	a94153f3 	ldp	x19, x20, [sp, #16]
     ac0:	a8c47bfd 	ldp	x29, x30, [sp], #64
  unlink("unlinkread");
     ac4:	14000efc 	b	46b4 <unlink>

0000000000000ac8 <linktest>:
{
     ac8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     acc:	910003fd 	mov	x29, sp
     ad0:	a90153f3 	stp	x19, x20, [sp, #16]
     ad4:	aa0003f3 	mov	x19, x0
  unlink("lf1");
     ad8:	b0000034 	adrp	x20, 5000 <malloc+0xe4>
     adc:	91100e80 	add	x0, x20, #0x403
{
     ae0:	a9025bf5 	stp	x21, x22, [sp, #32]
  unlink("lf1");
     ae4:	94000ef4 	bl	46b4 <unlink>
  unlink("lf2");
     ae8:	b0000035 	adrp	x21, 5000 <malloc+0xe4>
     aec:	91101ea0 	add	x0, x21, #0x407
     af0:	94000ef1 	bl	46b4 <unlink>
  fd = open("lf1", O_CREATE|O_RDWR);
     af4:	91100e80 	add	x0, x20, #0x403
     af8:	52804041 	mov	w1, #0x202                 	// #514
     afc:	94000ee8 	bl	469c <open>
  if(fd < 0){
     b00:	36f800e0 	tbz	w0, #31, b1c <linktest+0x54>
    printf("%s: create lf1 failed\n", s);
     b04:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     b08:	91102c00 	add	x0, x0, #0x40b
    printf("%s: write lf1 failed\n", s);
     b0c:	aa1303e1 	mov	x1, x19
     b10:	940010a7 	bl	4dac <printf>
    exit(1);
     b14:	52800020 	mov	w0, #0x1                   	// #1
     b18:	94000ec9 	bl	463c <exit>
  if(write(fd, "hello", SZ) != SZ){
     b1c:	b0000021 	adrp	x1, 5000 <malloc+0xe4>
     b20:	910db021 	add	x1, x1, #0x36c
     b24:	2a0003f6 	mov	w22, w0
     b28:	528000a2 	mov	w2, #0x5                   	// #5
     b2c:	94000ed0 	bl	466c <write>
     b30:	7100141f 	cmp	w0, #0x5
     b34:	54000080 	b.eq	b44 <linktest+0x7c>  // b.none
    printf("%s: write lf1 failed\n", s);
     b38:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     b3c:	91108800 	add	x0, x0, #0x422
     b40:	17fffff3 	b	b0c <linktest+0x44>
  close(fd);
     b44:	2a1603e0 	mov	w0, w22
     b48:	94000ecc 	bl	4678 <close>
  if(link("lf1", "lf2") < 0){
     b4c:	91101ea1 	add	x1, x21, #0x407
     b50:	91100e80 	add	x0, x20, #0x403
     b54:	94000ede 	bl	46cc <link>
     b58:	36f80080 	tbz	w0, #31, b68 <linktest+0xa0>
    printf("%s: link lf1 lf2 failed\n", s);
     b5c:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     b60:	9110e000 	add	x0, x0, #0x438
     b64:	17ffffea 	b	b0c <linktest+0x44>
  unlink("lf1");
     b68:	91100e80 	add	x0, x20, #0x403
     b6c:	94000ed2 	bl	46b4 <unlink>
  if(open("lf1", 0) >= 0){
     b70:	91100e80 	add	x0, x20, #0x403
     b74:	52800001 	mov	w1, #0x0                   	// #0
     b78:	94000ec9 	bl	469c <open>
     b7c:	37f80080 	tbnz	w0, #31, b8c <linktest+0xc4>
    printf("%s: unlinked lf1 but it is still there!\n", s);
     b80:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     b84:	91114400 	add	x0, x0, #0x451
     b88:	17ffffe1 	b	b0c <linktest+0x44>
  fd = open("lf2", 0);
     b8c:	91101ea0 	add	x0, x21, #0x407
     b90:	52800001 	mov	w1, #0x0                   	// #0
     b94:	94000ec2 	bl	469c <open>
     b98:	2a0003f6 	mov	w22, w0
  if(fd < 0){
     b9c:	36f80080 	tbz	w0, #31, bac <linktest+0xe4>
    printf("%s: open lf2 failed\n", s);
     ba0:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     ba4:	9111e800 	add	x0, x0, #0x47a
     ba8:	17ffffd9 	b	b0c <linktest+0x44>
  if(read(fd, buf, sizeof(buf)) != SZ){
     bac:	d0000041 	adrp	x1, a000 <uninit+0x1cb7>
     bb0:	91296421 	add	x1, x1, #0xa59
     bb4:	52860002 	mov	w2, #0x3000                	// #12288
     bb8:	94000eaa 	bl	4660 <read>
     bbc:	7100141f 	cmp	w0, #0x5
     bc0:	54000080 	b.eq	bd0 <linktest+0x108>  // b.none
    printf("%s: read lf2 failed\n", s);
     bc4:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     bc8:	91123c00 	add	x0, x0, #0x48f
     bcc:	17ffffd0 	b	b0c <linktest+0x44>
  close(fd);
     bd0:	2a1603e0 	mov	w0, w22
     bd4:	94000ea9 	bl	4678 <close>
  if(link("lf2", "lf2") >= 0){
     bd8:	91101ea1 	add	x1, x21, #0x407
     bdc:	91101ea0 	add	x0, x21, #0x407
     be0:	94000ebb 	bl	46cc <link>
     be4:	37f80080 	tbnz	w0, #31, bf4 <linktest+0x12c>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
     be8:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     bec:	91129000 	add	x0, x0, #0x4a4
     bf0:	17ffffc7 	b	b0c <linktest+0x44>
  unlink("lf2");
     bf4:	91101ea0 	add	x0, x21, #0x407
     bf8:	94000eaf 	bl	46b4 <unlink>
  if(link("lf2", "lf1") >= 0){
     bfc:	91100e81 	add	x1, x20, #0x403
     c00:	91101ea0 	add	x0, x21, #0x407
     c04:	94000eb2 	bl	46cc <link>
     c08:	37f80080 	tbnz	w0, #31, c18 <linktest+0x150>
    printf("%s: link non-existent succeeded! oops\n", s);
     c0c:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     c10:	91131800 	add	x0, x0, #0x4c6
     c14:	17ffffbe 	b	b0c <linktest+0x44>
  if(link(".", "lf1") >= 0){
     c18:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
     c1c:	91024000 	add	x0, x0, #0x90
     c20:	91100e81 	add	x1, x20, #0x403
     c24:	94000eaa 	bl	46cc <link>
     c28:	37f80080 	tbnz	w0, #31, c38 <linktest+0x170>
    printf("%s: link . lf1 succeeded! oops\n", s);
     c2c:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     c30:	9113b400 	add	x0, x0, #0x4ed
     c34:	17ffffb6 	b	b0c <linktest+0x44>
}
     c38:	a94153f3 	ldp	x19, x20, [sp, #16]
     c3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
     c40:	a8c37bfd 	ldp	x29, x30, [sp], #48
     c44:	d65f03c0 	ret

0000000000000c48 <pgbug>:
{
     c48:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  exec((char*)0xeaeb0b5b00002f5e, argv);
     c4c:	d285ebc0 	mov	x0, #0x2f5e                	// #12126
     c50:	f2c16b60 	movk	x0, #0xb5b, lsl #32
     c54:	f2fd5d60 	movk	x0, #0xeaeb, lsl #48
{
     c58:	910003fd 	mov	x29, sp
  exec((char*)0xeaeb0b5b00002f5e, argv);
     c5c:	910063e1 	add	x1, sp, #0x18
  argv[0] = 0;
     c60:	f9000fff 	str	xzr, [sp, #24]
  exec((char*)0xeaeb0b5b00002f5e, argv);
     c64:	94000e8b 	bl	4690 <exec>
  pipe((int*)0xeaeb0b5b00002f5e);
     c68:	d285ebc0 	mov	x0, #0x2f5e                	// #12126
     c6c:	f2c16b60 	movk	x0, #0xb5b, lsl #32
     c70:	f2fd5d60 	movk	x0, #0xeaeb, lsl #48
     c74:	94000e78 	bl	4654 <pipe>
  exit(0);
     c78:	52800000 	mov	w0, #0x0                   	// #0
     c7c:	94000e70 	bl	463c <exit>

0000000000000c80 <badarg>:
{
     c80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
     c84:	910003fd 	mov	x29, sp
     c88:	a90153f3 	stp	x19, x20, [sp, #16]
    exec("/bin/echo", argv);
     c8c:	b0000034 	adrp	x20, 5000 <malloc+0xe4>
     c90:	91143694 	add	x20, x20, #0x50d
{
     c94:	52986a13 	mov	w19, #0xc350                	// #50000
     c98:	f90013f5 	str	x21, [sp, #32]
    argv[0] = (char*)0xffffffff;
     c9c:	b2407ff5 	mov	x21, #0xffffffff            	// #4294967295
    exec("/bin/echo", argv);
     ca0:	9100c3e1 	add	x1, sp, #0x30
     ca4:	aa1403e0 	mov	x0, x20
    argv[0] = (char*)0xffffffff;
     ca8:	a9037ff5 	stp	x21, xzr, [sp, #48]
    exec("/bin/echo", argv);
     cac:	94000e79 	bl	4690 <exec>
  for(int i = 0; i < 50000; i++){
     cb0:	71000673 	subs	w19, w19, #0x1
     cb4:	54ffff61 	b.ne	ca0 <badarg+0x20>  // b.any
  exit(0);
     cb8:	52800000 	mov	w0, #0x0                   	// #0
     cbc:	94000e60 	bl	463c <exit>

0000000000000cc0 <copyinstr2>:
{
     cc0:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
     cc4:	d2800000 	mov	x0, #0x0                   	// #0
    b[i] = 'x';
     cc8:	52800f01 	mov	w1, #0x78                  	// #120
{
     ccc:	910003fd 	mov	x29, sp
    b[i] = 'x';
     cd0:	910163e2 	add	x2, sp, #0x58
     cd4:	38206841 	strb	w1, [x2, x0]
  for(int i = 0; i < MAXPATH; i++)
     cd8:	91000400 	add	x0, x0, #0x1
     cdc:	f102001f 	cmp	x0, #0x80
     ce0:	54ffff81 	b.ne	cd0 <copyinstr2+0x10>  // b.any
  int ret = unlink(b);
     ce4:	aa0203e0 	mov	x0, x2
  b[MAXPATH] = '\0';
     ce8:	390363ff 	strb	wzr, [sp, #216]
  int ret = unlink(b);
     cec:	94000e72 	bl	46b4 <unlink>
     cf0:	2a0003e2 	mov	w2, w0
  if(ret != -1){
     cf4:	3100041f 	cmn	w0, #0x1
     cf8:	540000e0 	b.eq	d14 <copyinstr2+0x54>  // b.none
    printf("unlink(%s) returned %d, not -1\n", b, ret);
     cfc:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     d00:	91145c00 	add	x0, x0, #0x517
    printf("open(%s) returned %d, not -1\n", b, fd);
     d04:	910163e1 	add	x1, sp, #0x58
     d08:	94001029 	bl	4dac <printf>
    exit(1);
     d0c:	52800020 	mov	w0, #0x1                   	// #1
     d10:	94000e4b 	bl	463c <exit>
  int fd = open(b, O_CREATE | O_WRONLY);
     d14:	910163e0 	add	x0, sp, #0x58
     d18:	52804021 	mov	w1, #0x201                 	// #513
     d1c:	94000e60 	bl	469c <open>
     d20:	2a0003e2 	mov	w2, w0
  if(fd != -1){
     d24:	3100041f 	cmn	w0, #0x1
     d28:	54000080 	b.eq	d38 <copyinstr2+0x78>  // b.none
    printf("open(%s) returned %d, not -1\n", b, fd);
     d2c:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     d30:	9114dc00 	add	x0, x0, #0x537
     d34:	17fffff4 	b	d04 <copyinstr2+0x44>
  ret = link(b, b);
     d38:	910163e1 	add	x1, sp, #0x58
     d3c:	aa0103e0 	mov	x0, x1
     d40:	94000e63 	bl	46cc <link>
     d44:	2a0003e2 	mov	w2, w0
  if(ret != -1){
     d48:	3100041f 	cmn	w0, #0x1
     d4c:	54000100 	b.eq	d6c <copyinstr2+0xac>  // b.none
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
     d50:	2a0203e3 	mov	w3, w2
     d54:	910163e2 	add	x2, sp, #0x58
     d58:	aa0203e1 	mov	x1, x2
     d5c:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     d60:	91155400 	add	x0, x0, #0x555
     d64:	94001012 	bl	4dac <printf>
    exit(1);
     d68:	17ffffe9 	b	d0c <copyinstr2+0x4c>
  char *args[] = { "xx", 0 };
     d6c:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
     d70:	9106ec00 	add	x0, x0, #0x1bb
  ret = exec(b, args);
     d74:	9100a3e1 	add	x1, sp, #0x28
     d78:	b9001fe2 	str	w2, [sp, #28]
  char *args[] = { "xx", 0 };
     d7c:	a902ffe0 	stp	x0, xzr, [sp, #40]
  ret = exec(b, args);
     d80:	910163e0 	add	x0, sp, #0x58
     d84:	94000e43 	bl	4690 <exec>
  if(ret != -1){
     d88:	b9401fe2 	ldr	w2, [sp, #28]
     d8c:	3100041f 	cmn	w0, #0x1
     d90:	54000080 	b.eq	da0 <copyinstr2+0xe0>  // b.none
    printf("exec(%s) returned %d, not -1\n", b, fd);
     d94:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     d98:	9115dc00 	add	x0, x0, #0x577
     d9c:	17ffffda 	b	d04 <copyinstr2+0x44>
  int pid = fork();
     da0:	94000e24 	bl	4630 <fork>
  if(pid < 0){
     da4:	36f800a0 	tbz	w0, #31, db8 <copyinstr2+0xf8>
    printf("fork failed\n");
     da8:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     dac:	9117b400 	add	x0, x0, #0x5ed
    printf("exec(echo, BIG) succeeded, should have failed\n");
     db0:	94000fff 	bl	4dac <printf>
    exit(1);
     db4:	17ffffd6 	b	d0c <copyinstr2+0x4c>
  if(pid == 0){
     db8:	350003c0 	cbnz	w0, e30 <copyinstr2+0x170>
      big[i] = 'x';
     dbc:	f0000020 	adrp	x0, 7000 <malloc+0x20e4>
     dc0:	910d2000 	add	x0, x0, #0x348
  if(pid == 0){
     dc4:	d2800001 	mov	x1, #0x0                   	// #0
      big[i] = 'x';
     dc8:	52800f02 	mov	w2, #0x78                  	// #120
     dcc:	38216802 	strb	w2, [x0, x1]
    for(int i = 0; i < PGSIZE; i++)
     dd0:	91000421 	add	x1, x1, #0x1
     dd4:	f140043f 	cmp	x1, #0x1, lsl #12
     dd8:	54ffffa1 	b.ne	dcc <copyinstr2+0x10c>  // b.any
    big[PGSIZE] = '\0';
     ddc:	91400400 	add	x0, x0, #0x1, lsl #12
     de0:	3900001f 	strb	wzr, [x0]
    char *args2[] = { big, big, big, 0 };
     de4:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
     de8:	91380000 	add	x0, x0, #0xe00
     dec:	a9400c02 	ldp	x2, x3, [x0]
     df0:	a9038fe2 	stp	x2, x3, [sp, #56]
     df4:	a9410400 	ldp	x0, x1, [x0, #16]
     df8:	a90487e0 	stp	x0, x1, [sp, #72]
    ret = exec("/bin/echo", args2);
     dfc:	9100e3e1 	add	x1, sp, #0x38
     e00:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     e04:	91143400 	add	x0, x0, #0x50d
     e08:	94000e22 	bl	4690 <exec>
    if(ret != -1){
     e0c:	3100041f 	cmn	w0, #0x1
     e10:	540000c0 	b.eq	e28 <copyinstr2+0x168>  // b.none
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
     e14:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     e18:	91165400 	add	x0, x0, #0x595
     e1c:	12800001 	mov	w1, #0xffffffff            	// #-1
     e20:	94000fe3 	bl	4dac <printf>
      exit(1);
     e24:	17ffffba 	b	d0c <copyinstr2+0x4c>
    exit(747); // OK
     e28:	52805d60 	mov	w0, #0x2eb                 	// #747
     e2c:	17ffffb9 	b	d10 <copyinstr2+0x50>
  wait(&st);
     e30:	9100e3e0 	add	x0, sp, #0x38
  int st = 0;
     e34:	b9003bff 	str	wzr, [sp, #56]
  wait(&st);
     e38:	94000e04 	bl	4648 <wait>
  if(st != 747){
     e3c:	b9403be0 	ldr	w0, [sp, #56]
     e40:	710bac1f 	cmp	w0, #0x2eb
     e44:	54000080 	b.eq	e54 <copyinstr2+0x194>  // b.none
    printf("exec(echo, BIG) succeeded, should have failed\n");
     e48:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     e4c:	9116e800 	add	x0, x0, #0x5ba
     e50:	17ffffd8 	b	db0 <copyinstr2+0xf0>
}
     e54:	a8ce7bfd 	ldp	x29, x30, [sp], #224
     e58:	d65f03c0 	ret

0000000000000e5c <truncate3>:
{
     e5c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
     e60:	5280c021 	mov	w1, #0x601                 	// #1537
{
     e64:	910003fd 	mov	x29, sp
     e68:	a90153f3 	stp	x19, x20, [sp, #16]
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
     e6c:	b0000033 	adrp	x19, 5000 <malloc+0xe4>
     e70:	9100fa73 	add	x19, x19, #0x3e
{
     e74:	aa0003f4 	mov	x20, x0
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
     e78:	aa1303e0 	mov	x0, x19
{
     e7c:	a9025bf5 	stp	x21, x22, [sp, #32]
     e80:	f9001bf7 	str	x23, [sp, #48]
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
     e84:	94000e06 	bl	469c <open>
     e88:	94000dfc 	bl	4678 <close>
  pid = fork();
     e8c:	94000de9 	bl	4630 <fork>
  if(pid < 0){
     e90:	36f800e0 	tbz	w0, #31, eac <truncate3+0x50>
    printf("%s: fork failed\n", s);
     e94:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     e98:	9117a400 	add	x0, x0, #0x5e9
        printf("%s: open failed\n", s);
     e9c:	aa1403e1 	mov	x1, x20
     ea0:	94000fc3 	bl	4dac <printf>
        exit(1);
     ea4:	52800020 	mov	w0, #0x1                   	// #1
     ea8:	94000de5 	bl	463c <exit>
  if(pid == 0){
     eac:	350004c0 	cbnz	w0, f44 <truncate3+0xe8>
      int n = write(fd, "1234567890", 10);
     eb0:	b0000036 	adrp	x22, 5000 <malloc+0xe4>
     eb4:	91182ed6 	add	x22, x22, #0x60b
  if(pid == 0){
     eb8:	52800c95 	mov	w21, #0x64                  	// #100
      int fd = open("truncfile", O_WRONLY);
     ebc:	aa1303e0 	mov	x0, x19
     ec0:	52800021 	mov	w1, #0x1                   	// #1
     ec4:	94000df6 	bl	469c <open>
     ec8:	2a0003f7 	mov	w23, w0
      if(fd < 0){
     ecc:	36f80080 	tbz	w0, #31, edc <truncate3+0x80>
        printf("%s: open failed\n", s);
     ed0:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     ed4:	9117e800 	add	x0, x0, #0x5fa
     ed8:	17fffff1 	b	e9c <truncate3+0x40>
      int n = write(fd, "1234567890", 10);
     edc:	52800142 	mov	w2, #0xa                   	// #10
     ee0:	aa1603e1 	mov	x1, x22
     ee4:	94000de2 	bl	466c <write>
     ee8:	2a0003e2 	mov	w2, w0
      if(n != 10){
     eec:	7100281f 	cmp	w0, #0xa
     ef0:	540000c0 	b.eq	f08 <truncate3+0xac>  // b.none
        printf("%s: write got %d, expected 10\n", s, n);
     ef4:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     ef8:	91185800 	add	x0, x0, #0x616
      printf("%s: write got %d, expected 3\n", s, n);
     efc:	aa1403e1 	mov	x1, x20
     f00:	94000fab 	bl	4dac <printf>
      exit(1);
     f04:	17ffffe8 	b	ea4 <truncate3+0x48>
      close(fd);
     f08:	2a1703e0 	mov	w0, w23
     f0c:	94000ddb 	bl	4678 <close>
      fd = open("truncfile", O_RDONLY);
     f10:	52800001 	mov	w1, #0x0                   	// #0
     f14:	aa1303e0 	mov	x0, x19
     f18:	94000de1 	bl	469c <open>
     f1c:	2a0003f7 	mov	w23, w0
      read(fd, buf, sizeof(buf));
     f20:	910103e1 	add	x1, sp, #0x40
     f24:	52800402 	mov	w2, #0x20                  	// #32
     f28:	94000dce 	bl	4660 <read>
      close(fd);
     f2c:	2a1703e0 	mov	w0, w23
     f30:	94000dd2 	bl	4678 <close>
    for(int i = 0; i < 100; i++){
     f34:	710006b5 	subs	w21, w21, #0x1
     f38:	54fffc21 	b.ne	ebc <truncate3+0x60>  // b.any
    exit(0);
     f3c:	52800000 	mov	w0, #0x0                   	// #0
     f40:	17ffffda 	b	ea8 <truncate3+0x4c>
    int n = write(fd, "xxx", 3);
     f44:	b0000036 	adrp	x22, 5000 <malloc+0xe4>
     f48:	9118d6d6 	add	x22, x22, #0x635
  if(pid == 0){
     f4c:	528012d5 	mov	w21, #0x96                  	// #150
    int fd = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
     f50:	aa1303e0 	mov	x0, x19
     f54:	5280c021 	mov	w1, #0x601                 	// #1537
     f58:	94000dd1 	bl	469c <open>
     f5c:	2a0003f7 	mov	w23, w0
    if(fd < 0){
     f60:	37fffb80 	tbnz	w0, #31, ed0 <truncate3+0x74>
    int n = write(fd, "xxx", 3);
     f64:	52800062 	mov	w2, #0x3                   	// #3
     f68:	aa1603e1 	mov	x1, x22
     f6c:	94000dc0 	bl	466c <write>
     f70:	2a0003e2 	mov	w2, w0
    if(n != 3){
     f74:	71000c1f 	cmp	w0, #0x3
     f78:	54000080 	b.eq	f88 <truncate3+0x12c>  // b.none
      printf("%s: write got %d, expected 3\n", s, n);
     f7c:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     f80:	9118e400 	add	x0, x0, #0x639
     f84:	17ffffde 	b	efc <truncate3+0xa0>
    close(fd);
     f88:	2a1703e0 	mov	w0, w23
     f8c:	94000dbb 	bl	4678 <close>
  for(int i = 0; i < 150; i++){
     f90:	710006b5 	subs	w21, w21, #0x1
     f94:	54fffde1 	b.ne	f50 <truncate3+0xf4>  // b.any
  wait(&xstatus);
     f98:	910103e0 	add	x0, sp, #0x40
     f9c:	94000dab 	bl	4648 <wait>
  unlink("truncfile");
     fa0:	aa1303e0 	mov	x0, x19
     fa4:	94000dc4 	bl	46b4 <unlink>
  exit(xstatus);
     fa8:	b94043e0 	ldr	w0, [sp, #64]
     fac:	17ffffbf 	b	ea8 <truncate3+0x4c>

0000000000000fb0 <exectest>:
{
     fb0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     fb4:	910003fd 	mov	x29, sp
     fb8:	a90153f3 	stp	x19, x20, [sp, #16]
     fbc:	aa0003f3 	mov	x19, x0
  char *echoargv[] = { "echo", "OK", 0 };
     fc0:	d0000020 	adrp	x0, 6000 <malloc+0x10e4>
     fc4:	91380000 	add	x0, x0, #0xe00
  unlink("echo-ok");
     fc8:	b0000034 	adrp	x20, 5000 <malloc+0xe4>
     fcc:	91195e94 	add	x20, x20, #0x657
{
     fd0:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *echoargv[] = { "echo", "OK", 0 };
     fd4:	a9420c02 	ldp	x2, x3, [x0, #32]
     fd8:	a9038fe2 	stp	x2, x3, [sp, #56]
     fdc:	f9401800 	ldr	x0, [x0, #48]
     fe0:	f90027e0 	str	x0, [sp, #72]
  unlink("echo-ok");
     fe4:	aa1403e0 	mov	x0, x20
     fe8:	94000db3 	bl	46b4 <unlink>
  pid = fork();
     fec:	94000d91 	bl	4630 <fork>
  if(pid < 0) {
     ff0:	36f800e0 	tbz	w0, #31, 100c <exectest+0x5c>
     printf("%s: fork failed\n", s);
     ff4:	b0000020 	adrp	x0, 5000 <malloc+0xe4>
     ff8:	9117a400 	add	x0, x0, #0x5e9
      printf("%s: create failed\n", s);
     ffc:	aa1303e1 	mov	x1, x19
    1000:	94000f6b 	bl	4dac <printf>
      exit(1);
    1004:	52800020 	mov	w0, #0x1                   	// #1
    1008:	94000d8d 	bl	463c <exit>
    100c:	2a0003f5 	mov	w21, w0
  if(pid == 0) {
    1010:	350002e0 	cbnz	w0, 106c <exectest+0xbc>
    close(1);
    1014:	52800020 	mov	w0, #0x1                   	// #1
    1018:	94000d98 	bl	4678 <close>
    fd = open("echo-ok", O_CREATE|O_WRONLY);
    101c:	aa1403e0 	mov	x0, x20
    1020:	52804021 	mov	w1, #0x201                 	// #513
    1024:	94000d9e 	bl	469c <open>
    if(fd < 0) {
    1028:	36f80080 	tbz	w0, #31, 1038 <exectest+0x88>
      printf("%s: create failed\n", s);
    102c:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1030:	91197c00 	add	x0, x0, #0x65f
    1034:	17fffff2 	b	ffc <exectest+0x4c>
    if(fd != 1) {
    1038:	7100041f 	cmp	w0, #0x1
    103c:	54000080 	b.eq	104c <exectest+0x9c>  // b.none
      printf("%s: wrong fd\n", s);
    1040:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1044:	9119c800 	add	x0, x0, #0x672
    1048:	17ffffed 	b	ffc <exectest+0x4c>
    if(exec("/bin/echo", echoargv) < 0){
    104c:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1050:	91143400 	add	x0, x0, #0x50d
    1054:	9100e3e1 	add	x1, sp, #0x38
    1058:	94000d8e 	bl	4690 <exec>
    105c:	36f80080 	tbz	w0, #31, 106c <exectest+0xbc>
      printf("%s: exec echo failed\n", s);
    1060:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1064:	911a0000 	add	x0, x0, #0x680
    1068:	17ffffe5 	b	ffc <exectest+0x4c>
  if (wait(&xstatus) != pid) {
    106c:	9100d3e0 	add	x0, sp, #0x34
    1070:	94000d76 	bl	4648 <wait>
    1074:	6b15001f 	cmp	w0, w21
    1078:	540000a0 	b.eq	108c <exectest+0xdc>  // b.none
    printf("%s: wait failed!\n", s);
    107c:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1080:	911a5800 	add	x0, x0, #0x696
    1084:	aa1303e1 	mov	x1, x19
    1088:	94000f49 	bl	4dac <printf>
  if(xstatus != 0)
    108c:	b94037e0 	ldr	w0, [sp, #52]
    1090:	35fffbc0 	cbnz	w0, 1008 <exectest+0x58>
  fd = open("echo-ok", O_RDONLY);
    1094:	aa1403e0 	mov	x0, x20
    1098:	52800001 	mov	w1, #0x0                   	// #0
    109c:	94000d80 	bl	469c <open>
  if(fd < 0) {
    10a0:	36f80080 	tbz	w0, #31, 10b0 <exectest+0x100>
    printf("%s: open failed\n", s);
    10a4:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    10a8:	9117e800 	add	x0, x0, #0x5fa
    10ac:	17ffffd4 	b	ffc <exectest+0x4c>
  if (read(fd, buf, 2) != 2) {
    10b0:	9100c3e1 	add	x1, sp, #0x30
    10b4:	52800042 	mov	w2, #0x2                   	// #2
    10b8:	94000d6a 	bl	4660 <read>
    10bc:	7100081f 	cmp	w0, #0x2
    10c0:	54000080 	b.eq	10d0 <exectest+0x120>  // b.none
    printf("%s: read failed\n", s);
    10c4:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    10c8:	910c6400 	add	x0, x0, #0x319
    10cc:	17ffffcc 	b	ffc <exectest+0x4c>
  unlink("echo-ok");
    10d0:	aa1403e0 	mov	x0, x20
    10d4:	94000d78 	bl	46b4 <unlink>
  if(buf[0] == 'O' && buf[1] == 'K')
    10d8:	3940c3e0 	ldrb	w0, [sp, #48]
    10dc:	71013c1f 	cmp	w0, #0x4f
    10e0:	540000c1 	b.ne	10f8 <exectest+0x148>  // b.any
    10e4:	3940c7e0 	ldrb	w0, [sp, #49]
    10e8:	71012c1f 	cmp	w0, #0x4b
    10ec:	54000061 	b.ne	10f8 <exectest+0x148>  // b.any
    exit(0);
    10f0:	52800000 	mov	w0, #0x0                   	// #0
    10f4:	17ffffc5 	b	1008 <exectest+0x58>
    printf("%s: wrong output\n", s);
    10f8:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    10fc:	911aa000 	add	x0, x0, #0x6a8
    1100:	17ffffbf 	b	ffc <exectest+0x4c>

0000000000001104 <pipe1>:
{
    1104:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    1108:	910003fd 	mov	x29, sp
    110c:	a90153f3 	stp	x19, x20, [sp, #16]
    1110:	a9025bf5 	stp	x21, x22, [sp, #32]
    1114:	aa0003f6 	mov	x22, x0
  if(pipe(fds) != 0){
    1118:	910123e0 	add	x0, sp, #0x48
{
    111c:	f9001bf7 	str	x23, [sp, #48]
  if(pipe(fds) != 0){
    1120:	94000d4d 	bl	4654 <pipe>
    1124:	340000e0 	cbz	w0, 1140 <pipe1+0x3c>
    printf("%s: pipe() failed\n", s);
    1128:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    112c:	911ae800 	add	x0, x0, #0x6ba
        printf("%s: pipe1 oops 1\n", s);
    1130:	aa1603e1 	mov	x1, x22
    1134:	94000f1e 	bl	4dac <printf>
        exit(1);
    1138:	52800020 	mov	w0, #0x1                   	// #1
    113c:	94000d40 	bl	463c <exit>
    1140:	2a0003f3 	mov	w19, w0
  pid = fork();
    1144:	b0000055 	adrp	x21, a000 <uninit+0x1cb7>
    1148:	912966b5 	add	x21, x21, #0xa59
    114c:	94000d39 	bl	4630 <fork>
    1150:	2a0003f4 	mov	w20, w0
  if(pid == 0){
    1154:	7100001f 	cmp	w0, #0x0
    1158:	350002e0 	cbnz	w0, 11b4 <pipe1+0xb0>
    close(fds[0]);
    115c:	b9404be0 	ldr	w0, [sp, #72]
    for(n = 0; n < N; n++){
    1160:	528285b3 	mov	w19, #0x142d                	// #5165
    close(fds[0]);
    1164:	94000d45 	bl	4678 <close>
{
    1168:	d2800002 	mov	x2, #0x0                   	// #0
        buf[i] = seq++;
    116c:	0b020280 	add	w0, w20, w2
    1170:	38226aa0 	strb	w0, [x21, x2]
      for(i = 0; i < SZ; i++)
    1174:	91000442 	add	x2, x2, #0x1
    1178:	f110245f 	cmp	x2, #0x409
    117c:	54ffff81 	b.ne	116c <pipe1+0x68>  // b.any
      if(write(fds[1], buf, SZ) != SZ){
    1180:	b9404fe0 	ldr	w0, [sp, #76]
    1184:	aa1503e1 	mov	x1, x21
    1188:	94000d39 	bl	466c <write>
    118c:	7110241f 	cmp	w0, #0x409
    1190:	54000080 	b.eq	11a0 <pipe1+0x9c>  // b.none
        printf("%s: pipe1 oops 1\n", s);
    1194:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1198:	911b3400 	add	x0, x0, #0x6cd
    119c:	17ffffe5 	b	1130 <pipe1+0x2c>
    11a0:	11102694 	add	w20, w20, #0x409
    for(n = 0; n < N; n++){
    11a4:	6b13029f 	cmp	w20, w19
    11a8:	54fffe01 	b.ne	1168 <pipe1+0x64>  // b.any
    exit(0);
    11ac:	52800000 	mov	w0, #0x0                   	// #0
    11b0:	17ffffe3 	b	113c <pipe1+0x38>
  } else if(pid > 0){
    11b4:	5400062d 	b.le	1278 <pipe1+0x174>
    close(fds[1]);
    11b8:	b9404fe0 	ldr	w0, [sp, #76]
    total = 0;
    11bc:	52800017 	mov	w23, #0x0                   	// #0
    cc = 1;
    11c0:	52800034 	mov	w20, #0x1                   	// #1
    close(fds[1]);
    11c4:	94000d2d 	bl	4678 <close>
    while((n = read(fds[0], buf, cc)) > 0){
    11c8:	b9404be0 	ldr	w0, [sp, #72]
    11cc:	2a1403e2 	mov	w2, w20
    11d0:	aa1503e1 	mov	x1, x21
    11d4:	94000d23 	bl	4660 <read>
    11d8:	7100001f 	cmp	w0, #0x0
    11dc:	5400012c 	b.gt	1200 <pipe1+0xfc>
    if(total != N * SZ){
    11e0:	528285a0 	mov	w0, #0x142d                	// #5165
    11e4:	6b0002ff 	cmp	w23, w0
    11e8:	540003c0 	b.eq	1260 <pipe1+0x15c>  // b.none
      printf("%s: pipe1 oops 3 total %d\n", total);
    11ec:	2a1703e1 	mov	w1, w23
    11f0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    11f4:	911bc400 	add	x0, x0, #0x6f1
    11f8:	94000eed 	bl	4dac <printf>
      exit(1);
    11fc:	17ffffcf 	b	1138 <pipe1+0x34>
    1200:	aa1503e1 	mov	x1, x21
    1204:	0b000262 	add	w2, w19, w0
        if((buf[i] & 0xff) != (seq++ & 0xff)){
    1208:	39400023 	ldrb	w3, [x1]
    120c:	6b33007f 	cmp	w3, w19, uxtb
    1210:	54000140 	b.eq	1238 <pipe1+0x134>  // b.none
          printf("%s: pipe1 oops 2\n", s);
    1214:	aa1603e1 	mov	x1, x22
    1218:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    121c:	911b7c00 	add	x0, x0, #0x6df
    1220:	94000ee3 	bl	4dac <printf>
}
    1224:	f9401bf7 	ldr	x23, [sp, #48]
    1228:	a94153f3 	ldp	x19, x20, [sp, #16]
    122c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1230:	a8c57bfd 	ldp	x29, x30, [sp], #80
    1234:	d65f03c0 	ret
        if((buf[i] & 0xff) != (seq++ & 0xff)){
    1238:	11000673 	add	w19, w19, #0x1
      for(i = 0; i < n; i++){
    123c:	91000421 	add	x1, x1, #0x1
    1240:	6b02027f 	cmp	w19, w2
    1244:	54fffe21 	b.ne	1208 <pipe1+0x104>  // b.any
      cc = cc * 2;
    1248:	531f7a94 	lsl	w20, w20, #1
      total += n;
    124c:	0b0002f7 	add	w23, w23, w0
      if(cc > sizeof(buf))
    1250:	71400e9f 	cmp	w20, #0x3, lsl #12
    1254:	52860000 	mov	w0, #0x3000                	// #12288
    1258:	1a80d294 	csel	w20, w20, w0, le
    125c:	17ffffdb 	b	11c8 <pipe1+0xc4>
    close(fds[0]);
    1260:	b9404be0 	ldr	w0, [sp, #72]
    1264:	94000d05 	bl	4678 <close>
    wait(&xstatus);
    1268:	910113e0 	add	x0, sp, #0x44
    126c:	94000cf7 	bl	4648 <wait>
    exit(xstatus);
    1270:	b94047e0 	ldr	w0, [sp, #68]
    1274:	17ffffb2 	b	113c <pipe1+0x38>
    printf("%s: fork() failed\n", s);
    1278:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    127c:	911c3000 	add	x0, x0, #0x70c
    1280:	17ffffac 	b	1130 <pipe1+0x2c>

0000000000001284 <exitwait>:
{
    1284:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1288:	910003fd 	mov	x29, sp
    128c:	a90153f3 	stp	x19, x20, [sp, #16]
    1290:	aa0003f4 	mov	x20, x0
  for(i = 0; i < 100; i++){
    1294:	52800013 	mov	w19, #0x0                   	// #0
{
    1298:	f90013f5 	str	x21, [sp, #32]
    pid = fork();
    129c:	94000ce5 	bl	4630 <fork>
    12a0:	2a0003f5 	mov	w21, w0
    if(pid < 0){
    12a4:	36f800e0 	tbz	w0, #31, 12c0 <exitwait+0x3c>
      printf("%s: fork failed\n", s);
    12a8:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    12ac:	9117a400 	add	x0, x0, #0x5e9
        printf("%s: wait wrong pid\n", s);
    12b0:	aa1403e1 	mov	x1, x20
    12b4:	94000ebe 	bl	4dac <printf>
        exit(1);
    12b8:	52800020 	mov	w0, #0x1                   	// #1
    12bc:	94000ce0 	bl	463c <exit>
    if(pid){
    12c0:	340002a0 	cbz	w0, 1314 <exitwait+0x90>
      if(wait(&xstate) != pid){
    12c4:	9100f3e0 	add	x0, sp, #0x3c
    12c8:	94000ce0 	bl	4648 <wait>
    12cc:	6b15001f 	cmp	w0, w21
    12d0:	54000080 	b.eq	12e0 <exitwait+0x5c>  // b.none
        printf("%s: wait wrong pid\n", s);
    12d4:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    12d8:	911c7c00 	add	x0, x0, #0x71f
    12dc:	17fffff5 	b	12b0 <exitwait+0x2c>
      if(i != xstate) {
    12e0:	b9403fe0 	ldr	w0, [sp, #60]
    12e4:	6b13001f 	cmp	w0, w19
    12e8:	54000080 	b.eq	12f8 <exitwait+0x74>  // b.none
        printf("%s: wait wrong exit status\n", s);
    12ec:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    12f0:	911ccc00 	add	x0, x0, #0x733
    12f4:	17ffffef 	b	12b0 <exitwait+0x2c>
  for(i = 0; i < 100; i++){
    12f8:	11000673 	add	w19, w19, #0x1
    12fc:	7101927f 	cmp	w19, #0x64
    1300:	54fffce1 	b.ne	129c <exitwait+0x18>  // b.any
}
    1304:	f94013f5 	ldr	x21, [sp, #32]
    1308:	a94153f3 	ldp	x19, x20, [sp, #16]
    130c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1310:	d65f03c0 	ret
      exit(i);
    1314:	2a1303e0 	mov	w0, w19
    1318:	17ffffe9 	b	12bc <exitwait+0x38>

000000000000131c <twochildren>:
{
    131c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1320:	910003fd 	mov	x29, sp
    1324:	a90153f3 	stp	x19, x20, [sp, #16]
    1328:	aa0003f4 	mov	x20, x0
    132c:	52807d13 	mov	w19, #0x3e8                 	// #1000
    int pid1 = fork();
    1330:	94000cc0 	bl	4630 <fork>
    if(pid1 < 0){
    1334:	36f800e0 	tbz	w0, #31, 1350 <twochildren+0x34>
      printf("%s: fork failed\n", s);
    1338:	aa1403e1 	mov	x1, x20
    133c:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1340:	9117a400 	add	x0, x0, #0x5e9
    1344:	94000e9a 	bl	4dac <printf>
      exit(1);
    1348:	52800020 	mov	w0, #0x1                   	// #1
      exit(0);
    134c:	94000cbc 	bl	463c <exit>
    if(pid1 == 0){
    1350:	35000060 	cbnz	w0, 135c <twochildren+0x40>
      exit(0);
    1354:	52800000 	mov	w0, #0x0                   	// #0
    1358:	17fffffd 	b	134c <twochildren+0x30>
      int pid2 = fork();
    135c:	94000cb5 	bl	4630 <fork>
      if(pid2 < 0){
    1360:	37fffec0 	tbnz	w0, #31, 1338 <twochildren+0x1c>
      if(pid2 == 0){
    1364:	34ffff80 	cbz	w0, 1354 <twochildren+0x38>
        wait(0);
    1368:	d2800000 	mov	x0, #0x0                   	// #0
    136c:	94000cb7 	bl	4648 <wait>
        wait(0);
    1370:	d2800000 	mov	x0, #0x0                   	// #0
    1374:	94000cb5 	bl	4648 <wait>
  for(int i = 0; i < 1000; i++){
    1378:	71000673 	subs	w19, w19, #0x1
    137c:	54fffda1 	b.ne	1330 <twochildren+0x14>  // b.any
}
    1380:	a94153f3 	ldp	x19, x20, [sp, #16]
    1384:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1388:	d65f03c0 	ret

000000000000138c <forkfork>:
{
    138c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1390:	910003fd 	mov	x29, sp
    1394:	f9000bf3 	str	x19, [sp, #16]
    1398:	aa0003f3 	mov	x19, x0
    int pid = fork();
    139c:	94000ca5 	bl	4630 <fork>
    if(pid < 0){
    13a0:	37f80180 	tbnz	w0, #31, 13d0 <forkfork+0x44>
    if(pid == 0){
    13a4:	34000200 	cbz	w0, 13e4 <forkfork+0x58>
    int pid = fork();
    13a8:	94000ca2 	bl	4630 <fork>
    if(pid < 0){
    13ac:	37f80120 	tbnz	w0, #31, 13d0 <forkfork+0x44>
    if(pid == 0){
    13b0:	340001a0 	cbz	w0, 13e4 <forkfork+0x58>
    wait(&xstatus);
    13b4:	9100b3e0 	add	x0, sp, #0x2c
    13b8:	94000ca4 	bl	4648 <wait>
    if(xstatus != 0) {
    13bc:	b9402fe0 	ldr	w0, [sp, #44]
    13c0:	340002c0 	cbz	w0, 1418 <forkfork+0x8c>
      printf("%s: fork in child failed", s);
    13c4:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    13c8:	911d7c00 	add	x0, x0, #0x75f
    13cc:	14000003 	b	13d8 <forkfork+0x4c>
      printf("%s: fork failed", s);
    13d0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    13d4:	911d3c00 	add	x0, x0, #0x74f
      printf("%s: fork in child failed", s);
    13d8:	aa1303e1 	mov	x1, x19
    13dc:	94000e74 	bl	4dac <printf>
    13e0:	14000004 	b	13f0 <forkfork+0x64>
{
    13e4:	52801913 	mov	w19, #0xc8                  	// #200
        int pid1 = fork();
    13e8:	94000c92 	bl	4630 <fork>
        if(pid1 < 0){
    13ec:	36f80060 	tbz	w0, #31, 13f8 <forkfork+0x6c>
      exit(1);
    13f0:	52800020 	mov	w0, #0x1                   	// #1
    13f4:	14000003 	b	1400 <forkfork+0x74>
        if(pid1 == 0){
    13f8:	35000060 	cbnz	w0, 1404 <forkfork+0x78>
          exit(0);
    13fc:	52800000 	mov	w0, #0x0                   	// #0
      exit(1);
    1400:	94000c8f 	bl	463c <exit>
        wait(0);
    1404:	d2800000 	mov	x0, #0x0                   	// #0
    1408:	94000c90 	bl	4648 <wait>
      for(int j = 0; j < 200; j++){
    140c:	71000673 	subs	w19, w19, #0x1
    1410:	54fffec1 	b.ne	13e8 <forkfork+0x5c>  // b.any
    1414:	17fffffa 	b	13fc <forkfork+0x70>
    wait(&xstatus);
    1418:	9100b3e0 	add	x0, sp, #0x2c
    141c:	94000c8b 	bl	4648 <wait>
    if(xstatus != 0) {
    1420:	b9402fe0 	ldr	w0, [sp, #44]
    1424:	35fffd00 	cbnz	w0, 13c4 <forkfork+0x38>
}
    1428:	f9400bf3 	ldr	x19, [sp, #16]
    142c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1430:	d65f03c0 	ret

0000000000001434 <reparent2>:
{
    1434:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1438:	910003fd 	mov	x29, sp
    143c:	f9000bf3 	str	x19, [sp, #16]
    1440:	52806413 	mov	w19, #0x320                 	// #800
    int pid1 = fork();
    1444:	94000c7b 	bl	4630 <fork>
    if(pid1 < 0){
    1448:	36f800c0 	tbz	w0, #31, 1460 <reparent2+0x2c>
      printf("fork failed\n");
    144c:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1450:	9117b400 	add	x0, x0, #0x5ed
    1454:	94000e56 	bl	4dac <printf>
      exit(1);
    1458:	52800020 	mov	w0, #0x1                   	// #1
      exit(0);
    145c:	94000c78 	bl	463c <exit>
    if(pid1 == 0){
    1460:	350000a0 	cbnz	w0, 1474 <reparent2+0x40>
      fork();
    1464:	94000c73 	bl	4630 <fork>
      fork();
    1468:	94000c72 	bl	4630 <fork>
      exit(0);
    146c:	52800000 	mov	w0, #0x0                   	// #0
    1470:	17fffffb 	b	145c <reparent2+0x28>
    wait(0);
    1474:	d2800000 	mov	x0, #0x0                   	// #0
    1478:	94000c74 	bl	4648 <wait>
  for(int i = 0; i < 800; i++){
    147c:	71000673 	subs	w19, w19, #0x1
    1480:	54fffe21 	b.ne	1444 <reparent2+0x10>  // b.any
    1484:	17fffffa 	b	146c <reparent2+0x38>

0000000000001488 <createdelete>:
{
    1488:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    148c:	910003fd 	mov	x29, sp
    1490:	a9025bf5 	stp	x21, x22, [sp, #32]
    1494:	aa0003f5 	mov	x21, x0
    1498:	a90153f3 	stp	x19, x20, [sp, #16]
  for(pi = 0; pi < NCHILD; pi++){
    149c:	52800014 	mov	w20, #0x0                   	// #0
{
    14a0:	f9001bf7 	str	x23, [sp, #48]
    pid = fork();
    14a4:	94000c63 	bl	4630 <fork>
    14a8:	2a0003f3 	mov	w19, w0
    if(pid < 0){
    14ac:	36f800e0 	tbz	w0, #31, 14c8 <createdelete+0x40>
      printf("fork failed\n", s);
    14b0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    14b4:	9117b400 	add	x0, x0, #0x5ed
          printf("%s: create failed\n", s);
    14b8:	aa1503e1 	mov	x1, x21
    14bc:	94000e3c 	bl	4dac <printf>
          exit(1);
    14c0:	52800020 	mov	w0, #0x1                   	// #1
    14c4:	94000c5e 	bl	463c <exit>
    if(pid == 0){
    14c8:	35000460 	cbnz	w0, 1554 <createdelete+0xcc>
      name[0] = 'p' + pi;
    14cc:	1101c294 	add	w20, w20, #0x70
    14d0:	390143f4 	strb	w20, [sp, #80]
      name[2] = '\0';
    14d4:	39014bff 	strb	wzr, [sp, #82]
        name[1] = '0' + i;
    14d8:	1100c260 	add	w0, w19, #0x30
        fd = open(name, O_CREATE | O_RDWR);
    14dc:	52804041 	mov	w1, #0x202                 	// #514
        name[1] = '0' + i;
    14e0:	390147e0 	strb	w0, [sp, #81]
        fd = open(name, O_CREATE | O_RDWR);
    14e4:	910143e0 	add	x0, sp, #0x50
    14e8:	94000c6d 	bl	469c <open>
        if(fd < 0){
    14ec:	36f80080 	tbz	w0, #31, 14fc <createdelete+0x74>
          printf("%s: create failed\n", s);
    14f0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    14f4:	91197c00 	add	x0, x0, #0x65f
    14f8:	17fffff0 	b	14b8 <createdelete+0x30>
        close(fd);
    14fc:	94000c5f 	bl	4678 <close>
        if(i > 0 && (i % 2 ) == 0){
    1500:	34000273 	cbz	w19, 154c <createdelete+0xc4>
    1504:	11000674 	add	w20, w19, #0x1
    1508:	37000193 	tbnz	w19, #0, 1538 <createdelete+0xb0>
          name[1] = '0' + (i / 2);
    150c:	13017e73 	asr	w19, w19, #1
          if(unlink(name) < 0){
    1510:	910143e0 	add	x0, sp, #0x50
          name[1] = '0' + (i / 2);
    1514:	1100c273 	add	w19, w19, #0x30
    1518:	390147f3 	strb	w19, [sp, #81]
          if(unlink(name) < 0){
    151c:	94000c66 	bl	46b4 <unlink>
    1520:	36f80080 	tbz	w0, #31, 1530 <createdelete+0xa8>
            printf("%s: unlink failed\n", s);
    1524:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1528:	911de000 	add	x0, x0, #0x778
    152c:	17ffffe3 	b	14b8 <createdelete+0x30>
      for(i = 0; i < N; i++){
    1530:	2a1403f3 	mov	w19, w20
    1534:	17ffffe9 	b	14d8 <createdelete+0x50>
    1538:	2a1403f3 	mov	w19, w20
    153c:	7100529f 	cmp	w20, #0x14
    1540:	54fffcc1 	b.ne	14d8 <createdelete+0x50>  // b.any
      exit(0);
    1544:	52800000 	mov	w0, #0x0                   	// #0
    1548:	17ffffdf 	b	14c4 <createdelete+0x3c>
      for(i = 0; i < N; i++){
    154c:	52800033 	mov	w19, #0x1                   	// #1
    1550:	17ffffe2 	b	14d8 <createdelete+0x50>
  for(pi = 0; pi < NCHILD; pi++){
    1554:	11000694 	add	w20, w20, #0x1
    1558:	7100129f 	cmp	w20, #0x4
    155c:	54fffa41 	b.ne	14a4 <createdelete+0x1c>  // b.any
    wait(&xstatus);
    1560:	910133e0 	add	x0, sp, #0x4c
    1564:	94000c39 	bl	4648 <wait>
    if(xstatus != 0)
    1568:	b9404ff3 	ldr	w19, [sp, #76]
    156c:	35fffab3 	cbnz	w19, 14c0 <createdelete+0x38>
  for(pi = 0; pi < NCHILD; pi++){
    1570:	71000694 	subs	w20, w20, #0x1
    1574:	54ffff61 	b.ne	1560 <createdelete+0xd8>  // b.any
  name[0] = name[1] = name[2] = 0;
    1578:	39014bff 	strb	wzr, [sp, #82]
      if((i == 0 || i >= N/2) && fd < 0){
    157c:	7100027f 	cmp	w19, #0x0
      name[1] = '0' + i;
    1580:	1100c277 	add	w23, w19, #0x30
      if((i == 0 || i >= N/2) && fd < 0){
    1584:	7a491a60 	ccmp	w19, #0x9, #0x0, ne	// ne = any
    1588:	52800e14 	mov	w20, #0x70                  	// #112
    158c:	1a9fd7f6 	cset	w22, gt
      fd = open(name, 0);
    1590:	910143e0 	add	x0, sp, #0x50
    1594:	52800001 	mov	w1, #0x0                   	// #0
      name[0] = 'p' + pi;
    1598:	390143f4 	strb	w20, [sp, #80]
      name[1] = '0' + i;
    159c:	390147f7 	strb	w23, [sp, #81]
      fd = open(name, 0);
    15a0:	94000c3f 	bl	469c <open>
      if((i == 0 || i >= N/2) && fd < 0){
    15a4:	34000116 	cbz	w22, 15c4 <createdelete+0x13c>
    15a8:	36f80160 	tbz	w0, #31, 15d4 <createdelete+0x14c>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    15ac:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    15b0:	911e2c00 	add	x0, x0, #0x78b
        printf("%s: oops createdelete %s did exist\n", s, name);
    15b4:	910143e2 	add	x2, sp, #0x50
    15b8:	aa1503e1 	mov	x1, x21
    15bc:	94000dfc 	bl	4dac <printf>
        exit(1);
    15c0:	17ffffc0 	b	14c0 <createdelete+0x38>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    15c4:	37f800a0 	tbnz	w0, #31, 15d8 <createdelete+0x150>
        printf("%s: oops createdelete %s did exist\n", s, name);
    15c8:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    15cc:	911ec800 	add	x0, x0, #0x7b2
    15d0:	17fffff9 	b	15b4 <createdelete+0x12c>
        close(fd);
    15d4:	94000c29 	bl	4678 <close>
    for(pi = 0; pi < NCHILD; pi++){
    15d8:	11000694 	add	w20, w20, #0x1
    15dc:	12001e94 	and	w20, w20, #0xff
    15e0:	7101d29f 	cmp	w20, #0x74
    15e4:	54fffd61 	b.ne	1590 <createdelete+0x108>  // b.any
  for(i = 0; i < N; i++){
    15e8:	11000673 	add	w19, w19, #0x1
    15ec:	7100527f 	cmp	w19, #0x14
    15f0:	54fffc61 	b.ne	157c <createdelete+0xf4>  // b.any
    15f4:	52800e13 	mov	w19, #0x70                  	// #112
      name[1] = '0' + i;
    15f8:	51010275 	sub	w21, w19, #0x40
    15fc:	52800094 	mov	w20, #0x4                   	// #4
      unlink(name);
    1600:	910143e0 	add	x0, sp, #0x50
      name[0] = 'p' + i;
    1604:	390143f3 	strb	w19, [sp, #80]
      name[1] = '0' + i;
    1608:	390147f5 	strb	w21, [sp, #81]
      unlink(name);
    160c:	94000c2a 	bl	46b4 <unlink>
    for(pi = 0; pi < NCHILD; pi++){
    1610:	71000694 	subs	w20, w20, #0x1
    1614:	54ffff61 	b.ne	1600 <createdelete+0x178>  // b.any
  for(i = 0; i < N; i++){
    1618:	11000673 	add	w19, w19, #0x1
    161c:	12001e73 	and	w19, w19, #0xff
    1620:	7102127f 	cmp	w19, #0x84
    1624:	54fffea1 	b.ne	15f8 <createdelete+0x170>  // b.any
}
    1628:	f9401bf7 	ldr	x23, [sp, #48]
    162c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1630:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1634:	a8c77bfd 	ldp	x29, x30, [sp], #112
    1638:	d65f03c0 	ret

000000000000163c <linkunlink>:
{
    163c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    1640:	910003fd 	mov	x29, sp
    1644:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("x");
    1648:	b0000034 	adrp	x20, 6000 <malloc+0x10e4>
    164c:	9106f294 	add	x20, x20, #0x1bc
{
    1650:	aa0003f3 	mov	x19, x0
  unlink("x");
    1654:	aa1403e0 	mov	x0, x20
{
    1658:	a9025bf5 	stp	x21, x22, [sp, #32]
    165c:	a90363f7 	stp	x23, x24, [sp, #48]
    1660:	a9046bf9 	stp	x25, x26, [sp, #64]
  unlink("x");
    1664:	94000c14 	bl	46b4 <unlink>
  pid = fork();
    1668:	94000bf2 	bl	4630 <fork>
  if(pid < 0){
    166c:	36f800e0 	tbz	w0, #31, 1688 <linkunlink+0x4c>
    printf("%s: fork failed\n", s);
    1670:	aa1303e1 	mov	x1, x19
    1674:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1678:	9117a400 	add	x0, x0, #0x5e9
    167c:	94000dcc 	bl	4dac <printf>
    exit(1);
    1680:	52800020 	mov	w0, #0x1                   	// #1
    exit(0);
    1684:	94000bee 	bl	463c <exit>
    1688:	7100001f 	cmp	w0, #0x0
  unsigned int x = (pid ? 1 : 97);
    168c:	52800c33 	mov	w19, #0x61                  	// #97
      link("cat", "x");
    1690:	90000037 	adrp	x23, 5000 <malloc+0xe4>
    1694:	911f5af7 	add	x23, x23, #0x7d6
    1698:	2a0003f5 	mov	w21, w0
  unsigned int x = (pid ? 1 : 97);
    169c:	1a9f0673 	csinc	w19, w19, wzr, eq	// eq = none
    x = x * 1103515245 + 12345;
    16a0:	5289cdb8 	mov	w24, #0x4e6d                	// #20077
    16a4:	72a838d8 	movk	w24, #0x41c6, lsl #16
  unsigned int x = (pid ? 1 : 97);
    16a8:	52800c96 	mov	w22, #0x64                  	// #100
    x = x * 1103515245 + 12345;
    16ac:	52860739 	mov	w25, #0x3039                	// #12345
    if((x % 3) == 0){
    16b0:	5280007a 	mov	w26, #0x3                   	// #3
    x = x * 1103515245 + 12345;
    16b4:	1b186673 	madd	w19, w19, w24, w25
    if((x % 3) == 0){
    16b8:	1ada0a62 	udiv	w2, w19, w26
    16bc:	0b020442 	add	w2, w2, w2, lsl #1
    16c0:	6b020262 	subs	w2, w19, w2
    16c4:	540001e1 	b.ne	1700 <linkunlink+0xc4>  // b.any
      close(open("x", O_RDWR | O_CREATE));
    16c8:	52804041 	mov	w1, #0x202                 	// #514
    16cc:	aa1403e0 	mov	x0, x20
    16d0:	94000bf3 	bl	469c <open>
    16d4:	94000be9 	bl	4678 <close>
  for(i = 0; i < 100; i++){
    16d8:	710006d6 	subs	w22, w22, #0x1
    16dc:	54fffec1 	b.ne	16b4 <linkunlink+0x78>  // b.any
  if(pid)
    16e0:	34000235 	cbz	w21, 1724 <linkunlink+0xe8>
}
    16e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    wait(0);
    16e8:	d2800000 	mov	x0, #0x0                   	// #0
}
    16ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    16f0:	a94363f7 	ldp	x23, x24, [sp, #48]
    16f4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    16f8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    wait(0);
    16fc:	14000bd3 	b	4648 <wait>
    } else if((x % 3) == 1){
    1700:	7100045f 	cmp	w2, #0x1
    1704:	540000a1 	b.ne	1718 <linkunlink+0xdc>  // b.any
      link("cat", "x");
    1708:	aa1403e1 	mov	x1, x20
    170c:	aa1703e0 	mov	x0, x23
    1710:	94000bef 	bl	46cc <link>
    1714:	17fffff1 	b	16d8 <linkunlink+0x9c>
      unlink("x");
    1718:	aa1403e0 	mov	x0, x20
    171c:	94000be6 	bl	46b4 <unlink>
    1720:	17ffffee 	b	16d8 <linkunlink+0x9c>
    exit(0);
    1724:	52800000 	mov	w0, #0x0                   	// #0
    1728:	17ffffd7 	b	1684 <linkunlink+0x48>

000000000000172c <manywrites>:
{
    172c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    1730:	910003fd 	mov	x29, sp
    1734:	a90363f7 	stp	x23, x24, [sp, #48]
    1738:	aa0003f8 	mov	x24, x0
    173c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(int ci = 0; ci < nchildren; ci++){
    1740:	52800013 	mov	w19, #0x0                   	// #0
{
    1744:	a9025bf5 	stp	x21, x22, [sp, #32]
    1748:	f90023f9 	str	x25, [sp, #64]
    int pid = fork();
    174c:	94000bb9 	bl	4630 <fork>
    1750:	2a0003f5 	mov	w21, w0
    if(pid < 0){
    1754:	36f800c0 	tbz	w0, #31, 176c <manywrites+0x40>
      printf("fork failed\n");
    1758:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    175c:	9117b400 	add	x0, x0, #0x5ed
    1760:	94000d93 	bl	4dac <printf>
            exit(1);
    1764:	52800020 	mov	w0, #0x1                   	// #1
    1768:	94000bb5 	bl	463c <exit>
    if(pid == 0){
    176c:	35000600 	cbnz	w0, 182c <manywrites+0x100>
          int cc = write(fd, buf, sz);
    1770:	b0000057 	adrp	x23, a000 <uninit+0x1cb7>
    1774:	912966f7 	add	x23, x23, #0xa59
      name[0] = 'b';
    1778:	52800c40 	mov	w0, #0x62                  	// #98
      unlink(name);
    177c:	528003d6 	mov	w22, #0x1e                  	// #30
      name[0] = 'b';
    1780:	390163e0 	strb	w0, [sp, #88]
      name[1] = 'a' + ci;
    1784:	11018660 	add	w0, w19, #0x61
    1788:	390167e0 	strb	w0, [sp, #89]
      unlink(name);
    178c:	910163e0 	add	x0, sp, #0x58
      name[2] = '\0';
    1790:	39016bff 	strb	wzr, [sp, #90]
      unlink(name);
    1794:	94000bc8 	bl	46b4 <unlink>
        for(int i = 0; i < ci+1; i++){
    1798:	2a1503f4 	mov	w20, w21
          int fd = open(name, O_CREATE | O_RDWR);
    179c:	910163e0 	add	x0, sp, #0x58
    17a0:	52804041 	mov	w1, #0x202                 	// #514
    17a4:	94000bbe 	bl	469c <open>
    17a8:	2a0003f9 	mov	w25, w0
          if(fd < 0){
    17ac:	36f800e0 	tbz	w0, #31, 17c8 <manywrites+0x9c>
            printf("%s: cannot create %s\n", s, name);
    17b0:	910163e2 	add	x2, sp, #0x58
    17b4:	aa1803e1 	mov	x1, x24
    17b8:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    17bc:	911f6800 	add	x0, x0, #0x7da
    17c0:	94000d7b 	bl	4dac <printf>
    17c4:	17ffffe8 	b	1764 <manywrites+0x38>
          int cc = write(fd, buf, sz);
    17c8:	aa1703e1 	mov	x1, x23
    17cc:	52860002 	mov	w2, #0x3000                	// #12288
    17d0:	94000ba7 	bl	466c <write>
    17d4:	2a0003e3 	mov	w3, w0
          if(cc != sz){
    17d8:	71400c1f 	cmp	w0, #0x3, lsl #12
    17dc:	540000e0 	b.eq	17f8 <manywrites+0xcc>  // b.none
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    17e0:	aa1803e1 	mov	x1, x24
    17e4:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    17e8:	91025800 	add	x0, x0, #0x96
    17ec:	52860002 	mov	w2, #0x3000                	// #12288
    17f0:	94000d6f 	bl	4dac <printf>
            exit(1);
    17f4:	17ffffdc 	b	1764 <manywrites+0x38>
          close(fd);
    17f8:	2a1903e0 	mov	w0, w25
        for(int i = 0; i < ci+1; i++){
    17fc:	11000694 	add	w20, w20, #0x1
          close(fd);
    1800:	94000b9e 	bl	4678 <close>
        for(int i = 0; i < ci+1; i++){
    1804:	6b13029f 	cmp	w20, w19
    1808:	54fffcad 	b.le	179c <manywrites+0x70>
        unlink(name);
    180c:	910163e0 	add	x0, sp, #0x58
    1810:	94000ba9 	bl	46b4 <unlink>
      for(int iters = 0; iters < howmany; iters++){
    1814:	710006d6 	subs	w22, w22, #0x1
    1818:	54fffc01 	b.ne	1798 <manywrites+0x6c>  // b.any
      unlink(name);
    181c:	910163e0 	add	x0, sp, #0x58
    1820:	94000ba5 	bl	46b4 <unlink>
      exit(0);
    1824:	52800000 	mov	w0, #0x0                   	// #0
    1828:	17ffffd0 	b	1768 <manywrites+0x3c>
  for(int ci = 0; ci < nchildren; ci++){
    182c:	11000673 	add	w19, w19, #0x1
    1830:	7100127f 	cmp	w19, #0x4
    1834:	54fff8c1 	b.ne	174c <manywrites+0x20>  // b.any
    wait(&st);
    1838:	910163e0 	add	x0, sp, #0x58
    int st = 0;
    183c:	b9005bff 	str	wzr, [sp, #88]
    wait(&st);
    1840:	94000b82 	bl	4648 <wait>
    if(st != 0)
    1844:	b9405be0 	ldr	w0, [sp, #88]
    1848:	35fff900 	cbnz	w0, 1768 <manywrites+0x3c>
  for(int ci = 0; ci < nchildren; ci++){
    184c:	71000673 	subs	w19, w19, #0x1
    1850:	54ffff41 	b.ne	1838 <manywrites+0x10c>  // b.any
    1854:	17ffffc5 	b	1768 <manywrites+0x3c>

0000000000001858 <forktest>:
{
    1858:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    185c:	910003fd 	mov	x29, sp
    1860:	a90153f3 	stp	x19, x20, [sp, #16]
    1864:	aa0003f4 	mov	x20, x0
  for(n=0; n<N; n++){
    1868:	52800013 	mov	w19, #0x0                   	// #0
    pid = fork();
    186c:	94000b71 	bl	4630 <fork>
    if(pid < 0)
    1870:	37f80300 	tbnz	w0, #31, 18d0 <forktest+0x78>
    if(pid == 0)
    1874:	35000040 	cbnz	w0, 187c <forktest+0x24>
    exit(1);
    1878:	94000b71 	bl	463c <exit>
  for(n=0; n<N; n++){
    187c:	11000673 	add	w19, w19, #0x1
    1880:	710fa27f 	cmp	w19, #0x3e8
    1884:	54ffff41 	b.ne	186c <forktest+0x14>  // b.any
    printf("%s: fork claimed to work 1000 times!\n", s);
    1888:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    188c:	9120d000 	add	x0, x0, #0x834
    1890:	14000013 	b	18dc <forktest+0x84>
    if(wait(0) < 0){
    1894:	d2800000 	mov	x0, #0x0                   	// #0
    1898:	94000b6c 	bl	4648 <wait>
    189c:	36f80080 	tbz	w0, #31, 18ac <forktest+0x54>
      printf("%s: wait stopped early\n", s);
    18a0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    18a4:	91201400 	add	x0, x0, #0x805
    18a8:	1400000d 	b	18dc <forktest+0x84>
  for(; n > 0; n--){
    18ac:	71000673 	subs	w19, w19, #0x1
    18b0:	54ffff21 	b.ne	1894 <forktest+0x3c>  // b.any
  if(wait(0) != -1){
    18b4:	d2800000 	mov	x0, #0x0                   	// #0
    18b8:	94000b64 	bl	4648 <wait>
    18bc:	3100041f 	cmn	w0, #0x1
    18c0:	54000160 	b.eq	18ec <forktest+0x94>  // b.none
    printf("%s: wait got too many\n", s);
    18c4:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    18c8:	91207400 	add	x0, x0, #0x81d
    18cc:	14000004 	b	18dc <forktest+0x84>
  if (n == 0) {
    18d0:	35fffe33 	cbnz	w19, 1894 <forktest+0x3c>
    printf("%s: no fork at all!\n", s);
    18d4:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    18d8:	911fc000 	add	x0, x0, #0x7f0
    18dc:	aa1403e1 	mov	x1, x20
    18e0:	94000d33 	bl	4dac <printf>
    exit(1);
    18e4:	52800020 	mov	w0, #0x1                   	// #1
    18e8:	17ffffe4 	b	1878 <forktest+0x20>
}
    18ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    18f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    18f4:	d65f03c0 	ret

00000000000018f8 <kernmem>:
{
    18f8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    18fc:	910003fd 	mov	x29, sp
    1900:	a90153f3 	stp	x19, x20, [sp, #16]
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1904:	b25963f3 	mov	x19, #0xffffff8000000000    	// #-549755813888
{
    1908:	aa0003f4 	mov	x20, x0
    190c:	f90013f5 	str	x21, [sp, #32]
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1910:	9147a275 	add	x21, x19, #0x1e8, lsl #12
    1914:	911202b5 	add	x21, x21, #0x480
    pid = fork();
    1918:	94000b46 	bl	4630 <fork>
    if(pid < 0){
    191c:	36f800e0 	tbz	w0, #31, 1938 <kernmem+0x40>
      printf("%s: fork failed\n", s);
    1920:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1924:	9117a400 	add	x0, x0, #0x5e9
    1928:	aa1403e1 	mov	x1, x20
    192c:	94000d20 	bl	4dac <printf>
      exit(1);
    1930:	52800020 	mov	w0, #0x1                   	// #1
    1934:	94000b42 	bl	463c <exit>
    if(pid == 0){
    1938:	35000100 	cbnz	w0, 1958 <kernmem+0x60>
      printf("%s: oops could read %x = %x\n", s, a, *a);
    193c:	39400263 	ldrb	w3, [x19]
    1940:	aa1303e2 	mov	x2, x19
    1944:	aa1403e1 	mov	x1, x20
    1948:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    194c:	91216800 	add	x0, x0, #0x85a
    1950:	94000d17 	bl	4dac <printf>
    1954:	17fffff7 	b	1930 <kernmem+0x38>
    wait(&xstatus);
    1958:	9100f3e0 	add	x0, sp, #0x3c
    195c:	94000b3b 	bl	4648 <wait>
    if(xstatus != -1)  // did kernel kill child?
    1960:	b9403fe0 	ldr	w0, [sp, #60]
    1964:	3100041f 	cmn	w0, #0x1
    1968:	54fffe41 	b.ne	1930 <kernmem+0x38>  // b.any
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    196c:	d2986a00 	mov	x0, #0xc350                	// #50000
    1970:	8b000273 	add	x19, x19, x0
    1974:	eb15027f 	cmp	x19, x21
    1978:	54fffd01 	b.ne	1918 <kernmem+0x20>  // b.any
}
    197c:	f94013f5 	ldr	x21, [sp, #32]
    1980:	a94153f3 	ldp	x19, x20, [sp, #16]
    1984:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1988:	d65f03c0 	ret

000000000000198c <MAXVAplus>:
{
    198c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1990:	910003fd 	mov	x29, sp
    1994:	f9000bf3 	str	x19, [sp, #16]
    1998:	aa0003f3 	mov	x19, x0
  volatile uint64 a = MAXVA;
    199c:	b25a67e0 	mov	x0, #0xffffffc000000000    	// #-274877906944
  for( ; a != 0; a <<= 1){
    19a0:	f90017e0 	str	x0, [sp, #40]
    19a4:	f94017e0 	ldr	x0, [sp, #40]
    19a8:	b5000080 	cbnz	x0, 19b8 <MAXVAplus+0x2c>
}
    19ac:	f9400bf3 	ldr	x19, [sp, #16]
    19b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    19b4:	d65f03c0 	ret
    pid = fork();
    19b8:	94000b1e 	bl	4630 <fork>
    if(pid < 0){
    19bc:	36f800e0 	tbz	w0, #31, 19d8 <MAXVAplus+0x4c>
      printf("%s: fork failed\n", s);
    19c0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    19c4:	9117a400 	add	x0, x0, #0x5e9
    19c8:	aa1303e1 	mov	x1, x19
    19cc:	94000cf8 	bl	4dac <printf>
      exit(1);
    19d0:	52800020 	mov	w0, #0x1                   	// #1
    19d4:	94000b1a 	bl	463c <exit>
    if(pid == 0){
    19d8:	35000140 	cbnz	w0, 1a00 <MAXVAplus+0x74>
      *(char*)a = 99;
    19dc:	f94017e0 	ldr	x0, [sp, #40]
    19e0:	52800c61 	mov	w1, #0x63                  	// #99
      printf("%s: oops wrote %x\n", s, a);
    19e4:	f94017e2 	ldr	x2, [sp, #40]
      *(char*)a = 99;
    19e8:	39000001 	strb	w1, [x0]
      printf("%s: oops wrote %x\n", s, a);
    19ec:	aa1303e1 	mov	x1, x19
    19f0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    19f4:	9121dc00 	add	x0, x0, #0x877
    19f8:	94000ced 	bl	4dac <printf>
    19fc:	17fffff5 	b	19d0 <MAXVAplus+0x44>
    wait(&xstatus);
    1a00:	910093e0 	add	x0, sp, #0x24
    1a04:	94000b11 	bl	4648 <wait>
    if(xstatus != -1)  // did kernel kill child?
    1a08:	b94027e0 	ldr	w0, [sp, #36]
    1a0c:	3100041f 	cmn	w0, #0x1
    1a10:	54fffe01 	b.ne	19d0 <MAXVAplus+0x44>  // b.any
  for( ; a != 0; a <<= 1){
    1a14:	f94017e0 	ldr	x0, [sp, #40]
    1a18:	d37ff800 	lsl	x0, x0, #1
    1a1c:	17ffffe1 	b	19a0 <MAXVAplus+0x14>

0000000000001a20 <bigargtest>:
{
    1a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1a24:	910003fd 	mov	x29, sp
    1a28:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("bigarg-ok");
    1a2c:	90000033 	adrp	x19, 5000 <malloc+0xe4>
    1a30:	91222a73 	add	x19, x19, #0x88a
{
    1a34:	aa0003f4 	mov	x20, x0
  unlink("bigarg-ok");
    1a38:	aa1303e0 	mov	x0, x19
    1a3c:	94000b1e 	bl	46b4 <unlink>
  pid = fork();
    1a40:	94000afc 	bl	4630 <fork>
  if(pid == 0){
    1a44:	35000280 	cbnz	w0, 1a94 <bigargtest+0x74>
      args[i] = "bigargs test: failed\n                                                                                                                                                                                                       ";
    1a48:	d0000021 	adrp	x1, 7000 <malloc+0x20e4>
    1a4c:	91092021 	add	x1, x1, #0x248
    1a50:	90000022 	adrp	x2, 5000 <malloc+0xe4>
    1a54:	91225042 	add	x2, x2, #0x894
    1a58:	d2800000 	mov	x0, #0x0                   	// #0
    1a5c:	f8207822 	str	x2, [x1, x0, lsl #3]
    for(i = 0; i < MAXARG-1; i++)
    1a60:	91000400 	add	x0, x0, #0x1
    1a64:	f1007c1f 	cmp	x0, #0x1f
    1a68:	54ffffa1 	b.ne	1a5c <bigargtest+0x3c>  // b.any
    exec("/bin/echo", args);
    1a6c:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1a70:	91143400 	add	x0, x0, #0x50d
    args[MAXARG-1] = 0;
    1a74:	f9007c3f 	str	xzr, [x1, #248]
    exec("/bin/echo", args);
    1a78:	94000b06 	bl	4690 <exec>
    fd = open("bigarg-ok", O_CREATE);
    1a7c:	52804001 	mov	w1, #0x200                 	// #512
    1a80:	aa1303e0 	mov	x0, x19
    1a84:	94000b06 	bl	469c <open>
    close(fd);
    1a88:	94000afc 	bl	4678 <close>
    exit(0);
    1a8c:	52800000 	mov	w0, #0x0                   	// #0
    exit(1);
    1a90:	94000aeb 	bl	463c <exit>
  } else if(pid < 0){
    1a94:	36f800e0 	tbz	w0, #31, 1ab0 <bigargtest+0x90>
    printf("%s: bigargtest: fork failed\n", s);
    1a98:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1a9c:	9125c400 	add	x0, x0, #0x971
    1aa0:	aa1403e1 	mov	x1, x20
    1aa4:	94000cc2 	bl	4dac <printf>
    exit(1);
    1aa8:	52800020 	mov	w0, #0x1                   	// #1
    1aac:	17fffff9 	b	1a90 <bigargtest+0x70>
  wait(&xstatus);
    1ab0:	9100b3e0 	add	x0, sp, #0x2c
    1ab4:	94000ae5 	bl	4648 <wait>
  if(xstatus != 0)
    1ab8:	b9402fe0 	ldr	w0, [sp, #44]
    1abc:	35fffea0 	cbnz	w0, 1a90 <bigargtest+0x70>
  fd = open("bigarg-ok", 0);
    1ac0:	aa1303e0 	mov	x0, x19
    1ac4:	52800001 	mov	w1, #0x0                   	// #0
    1ac8:	94000af5 	bl	469c <open>
  if(fd < 0){
    1acc:	36f80080 	tbz	w0, #31, 1adc <bigargtest+0xbc>
    printf("%s: bigarg test failed!\n", s);
    1ad0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1ad4:	91263800 	add	x0, x0, #0x98e
    1ad8:	17fffff2 	b	1aa0 <bigargtest+0x80>
  close(fd);
    1adc:	94000ae7 	bl	4678 <close>
}
    1ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ae4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1ae8:	d65f03c0 	ret

0000000000001aec <stacktest>:
{
    1aec:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1af0:	910003fd 	mov	x29, sp
    1af4:	f9000fe0 	str	x0, [sp, #24]
  pid = fork();
    1af8:	94000ace 	bl	4630 <fork>
  if(pid == 0) {
    1afc:	f9400fe1 	ldr	x1, [sp, #24]
    1b00:	35000120 	cbnz	w0, 1b24 <stacktest+0x38>

static inline uint64
r_sp()
{
  uint64 x;
  asm volatile("mov %0, sp" : "=r" (x) );
    1b04:	910003e2 	mov	x2, sp
    printf("%s: stacktest: read below stack %p\n", s, *sp);
    1b08:	d1400442 	sub	x2, x2, #0x1, lsl #12
    1b0c:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1b10:	91269c00 	add	x0, x0, #0x9a7
    1b14:	39400042 	ldrb	w2, [x2]
    1b18:	94000ca5 	bl	4dac <printf>
    exit(1);
    1b1c:	52800020 	mov	w0, #0x1                   	// #1
    1b20:	94000ac7 	bl	463c <exit>
  } else if(pid < 0){
    1b24:	36f800a0 	tbz	w0, #31, 1b38 <stacktest+0x4c>
    printf("%s: fork failed\n", s);
    1b28:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1b2c:	9117a400 	add	x0, x0, #0x5e9
    1b30:	94000c9f 	bl	4dac <printf>
    1b34:	17fffffa 	b	1b1c <stacktest+0x30>
  wait(&xstatus);
    1b38:	9100b3e0 	add	x0, sp, #0x2c
    1b3c:	94000ac3 	bl	4648 <wait>
  if(xstatus == -1)  // kernel killed child?
    1b40:	b9402fe0 	ldr	w0, [sp, #44]
    1b44:	3100041f 	cmn	w0, #0x1
    1b48:	54fffec1 	b.ne	1b20 <stacktest+0x34>  // b.any
    exit(0);
    1b4c:	52800000 	mov	w0, #0x0                   	// #0
    1b50:	17fffff4 	b	1b20 <stacktest+0x34>

0000000000001b54 <copyinstr3>:
{
    1b54:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  sbrk(8192);
    1b58:	52840000 	mov	w0, #0x2000                	// #8192
{
    1b5c:	910003fd 	mov	x29, sp
    1b60:	a90153f3 	stp	x19, x20, [sp, #16]
  sbrk(8192);
    1b64:	94000ae9 	bl	4708 <sbrk>
  uint64 top = (uint64) sbrk(0);
    1b68:	52800000 	mov	w0, #0x0                   	// #0
    1b6c:	94000ae7 	bl	4708 <sbrk>
  if((top % PGSIZE) != 0){
    1b70:	f2402c00 	ands	x0, x0, #0xfff
    1b74:	54000080 	b.eq	1b84 <copyinstr3+0x30>  // b.none
    sbrk(PGSIZE - (top % PGSIZE));
    1b78:	52820001 	mov	w1, #0x1000                	// #4096
    1b7c:	4b000020 	sub	w0, w1, w0
    1b80:	94000ae2 	bl	4708 <sbrk>
  top = (uint64) sbrk(0);
    1b84:	52800000 	mov	w0, #0x0                   	// #0
    1b88:	94000ae0 	bl	4708 <sbrk>
  if(top % PGSIZE){
    1b8c:	f2402c1f 	tst	x0, #0xfff
    1b90:	540000c0 	b.eq	1ba8 <copyinstr3+0x54>  // b.none
    printf("oops\n");
    1b94:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1b98:	91141c00 	add	x0, x0, #0x507
    1b9c:	94000c84 	bl	4dac <printf>
    exit(1);
    1ba0:	52800020 	mov	w0, #0x1                   	// #1
    1ba4:	94000aa6 	bl	463c <exit>
  *b = 'x';
    1ba8:	52800f01 	mov	w1, #0x78                  	// #120
    1bac:	381ff001 	sturb	w1, [x0, #-1]
  char *b = (char *) (top - 1);
    1bb0:	d1000413 	sub	x19, x0, #0x1
  int ret = unlink(b);
    1bb4:	aa1303e0 	mov	x0, x19
    1bb8:	94000abf 	bl	46b4 <unlink>
    1bbc:	2a0003e2 	mov	w2, w0
  if(ret != -1){
    1bc0:	3100041f 	cmn	w0, #0x1
    1bc4:	540000c0 	b.eq	1bdc <copyinstr3+0x88>  // b.none
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1bc8:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1bcc:	91145c00 	add	x0, x0, #0x517
    1bd0:	aa1303e1 	mov	x1, x19
    1bd4:	94000c76 	bl	4dac <printf>
    1bd8:	17fffff2 	b	1ba0 <copyinstr3+0x4c>
  int fd = open(b, O_CREATE | O_WRONLY);
    1bdc:	aa1303e0 	mov	x0, x19
    1be0:	52804021 	mov	w1, #0x201                 	// #513
    1be4:	94000aae 	bl	469c <open>
    1be8:	2a0003e2 	mov	w2, w0
  if(fd != -1){
    1bec:	3100041f 	cmn	w0, #0x1
    1bf0:	54000080 	b.eq	1c00 <copyinstr3+0xac>  // b.none
    printf("open(%s) returned %d, not -1\n", b, fd);
    1bf4:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1bf8:	9114dc00 	add	x0, x0, #0x537
    1bfc:	17fffff5 	b	1bd0 <copyinstr3+0x7c>
  ret = link(b, b);
    1c00:	aa1303e1 	mov	x1, x19
    1c04:	aa1303e0 	mov	x0, x19
    1c08:	94000ab1 	bl	46cc <link>
    1c0c:	2a0003f4 	mov	w20, w0
  if(ret != -1){
    1c10:	3100041f 	cmn	w0, #0x1
    1c14:	54000100 	b.eq	1c34 <copyinstr3+0xe0>  // b.none
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    1c18:	2a1403e3 	mov	w3, w20
    1c1c:	aa1303e2 	mov	x2, x19
    1c20:	aa1303e1 	mov	x1, x19
    1c24:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1c28:	91155400 	add	x0, x0, #0x555
    1c2c:	94000c60 	bl	4dac <printf>
    exit(1);
    1c30:	17ffffdc 	b	1ba0 <copyinstr3+0x4c>
  char *args[] = { "xx", 0 };
    1c34:	b0000020 	adrp	x0, 6000 <malloc+0x10e4>
    1c38:	9106ec00 	add	x0, x0, #0x1bb
  ret = exec(b, args);
    1c3c:	910083e1 	add	x1, sp, #0x20
  char *args[] = { "xx", 0 };
    1c40:	a9027fe0 	stp	x0, xzr, [sp, #32]
  ret = exec(b, args);
    1c44:	aa1303e0 	mov	x0, x19
    1c48:	94000a92 	bl	4690 <exec>
  if(ret != -1){
    1c4c:	3100041f 	cmn	w0, #0x1
    1c50:	540000a0 	b.eq	1c64 <copyinstr3+0x110>  // b.none
    printf("exec(%s) returned %d, not -1\n", b, fd);
    1c54:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1c58:	9115dc00 	add	x0, x0, #0x577
    1c5c:	2a1403e2 	mov	w2, w20
    1c60:	17ffffdc 	b	1bd0 <copyinstr3+0x7c>
}
    1c64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c6c:	d65f03c0 	ret

0000000000001c70 <rwsbrk>:
{
    1c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  uint64 a = (uint64) sbrk(8192);
    1c74:	52840000 	mov	w0, #0x2000                	// #8192
{
    1c78:	910003fd 	mov	x29, sp
    1c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    1c80:	f90013f5 	str	x21, [sp, #32]
  uint64 a = (uint64) sbrk(8192);
    1c84:	94000aa1 	bl	4708 <sbrk>
  if(a == 0xffffffffffffffffLL) {
    1c88:	b100041f 	cmn	x0, #0x1
    1c8c:	540000c1 	b.ne	1ca4 <rwsbrk+0x34>  // b.any
    printf("sbrk(rwsbrk) failed\n");
    1c90:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1c94:	91272c00 	add	x0, x0, #0x9cb
    printf("sbrk(rwsbrk) shrink failed\n");
    1c98:	94000c45 	bl	4dac <printf>
    exit(1);
    1c9c:	52800020 	mov	w0, #0x1                   	// #1
    1ca0:	94000a67 	bl	463c <exit>
    1ca4:	aa0003f3 	mov	x19, x0
  if ((uint64) sbrk(-8192) ==  0xffffffffffffffffLL) {
    1ca8:	1283ffe0 	mov	w0, #0xffffe000            	// #-8192
    1cac:	94000a97 	bl	4708 <sbrk>
    1cb0:	b100041f 	cmn	x0, #0x1
    1cb4:	54000081 	b.ne	1cc4 <rwsbrk+0x54>  // b.any
    printf("sbrk(rwsbrk) shrink failed\n");
    1cb8:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1cbc:	91278000 	add	x0, x0, #0x9e0
    1cc0:	17fffff6 	b	1c98 <rwsbrk+0x28>
  fd = open("rwsbrk", O_CREATE|O_WRONLY);
    1cc4:	90000034 	adrp	x20, 5000 <malloc+0xe4>
    1cc8:	9127f294 	add	x20, x20, #0x9fc
    1ccc:	aa1403e0 	mov	x0, x20
    1cd0:	52804021 	mov	w1, #0x201                 	// #513
    1cd4:	94000a72 	bl	469c <open>
    1cd8:	2a0003f5 	mov	w21, w0
  if(fd < 0){
    1cdc:	36f80080 	tbz	w0, #31, 1cec <rwsbrk+0x7c>
    printf("open(rwsbrk) failed\n");
    1ce0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1ce4:	91280c00 	add	x0, x0, #0xa03
    1ce8:	17ffffec 	b	1c98 <rwsbrk+0x28>
  n = write(fd, (void*)(a+4096), 1024);
    1cec:	52808002 	mov	w2, #0x400                 	// #1024
    1cf0:	91400673 	add	x19, x19, #0x1, lsl #12
    1cf4:	aa1303e1 	mov	x1, x19
    1cf8:	94000a5d 	bl	466c <write>
    1cfc:	2a0003e2 	mov	w2, w0
  if(n >= 0){
    1d00:	37f800c0 	tbnz	w0, #31, 1d18 <rwsbrk+0xa8>
    printf("write(fd, %p, 1024) returned %d, not -1\n", a+4096, n);
    1d04:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1d08:	91286000 	add	x0, x0, #0xa18
    printf("read(fd, %p, 10) returned %d, not -1\n", a+4096, n);
    1d0c:	aa1303e1 	mov	x1, x19
    1d10:	94000c27 	bl	4dac <printf>
    exit(1);
    1d14:	17ffffe2 	b	1c9c <rwsbrk+0x2c>
  close(fd);
    1d18:	2a1503e0 	mov	w0, w21
    1d1c:	94000a57 	bl	4678 <close>
  unlink("rwsbrk");
    1d20:	aa1403e0 	mov	x0, x20
    1d24:	94000a64 	bl	46b4 <unlink>
  fd = open("README", O_RDONLY);
    1d28:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1d2c:	91054000 	add	x0, x0, #0x150
    1d30:	52800001 	mov	w1, #0x0                   	// #0
    1d34:	94000a5a 	bl	469c <open>
    1d38:	2a0003f4 	mov	w20, w0
  if(fd < 0){
    1d3c:	37fffd20 	tbnz	w0, #31, 1ce0 <rwsbrk+0x70>
  n = read(fd, (void*)(a+4096), 10);
    1d40:	52800142 	mov	w2, #0xa                   	// #10
    1d44:	aa1303e1 	mov	x1, x19
    1d48:	94000a46 	bl	4660 <read>
    1d4c:	2a0003e2 	mov	w2, w0
  if(n >= 0){
    1d50:	37f80080 	tbnz	w0, #31, 1d60 <rwsbrk+0xf0>
    printf("read(fd, %p, 10) returned %d, not -1\n", a+4096, n);
    1d54:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1d58:	91290400 	add	x0, x0, #0xa41
    1d5c:	17ffffec 	b	1d0c <rwsbrk+0x9c>
  close(fd);
    1d60:	2a1403e0 	mov	w0, w20
    1d64:	94000a45 	bl	4678 <close>
  exit(0);
    1d68:	52800000 	mov	w0, #0x0                   	// #0
    1d6c:	17ffffcd 	b	1ca0 <rwsbrk+0x30>

0000000000001d70 <sbrkbasic>:
{
    1d70:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    1d74:	910003fd 	mov	x29, sp
    1d78:	a90153f3 	stp	x19, x20, [sp, #16]
    1d7c:	aa0003f4 	mov	x20, x0
    1d80:	a9025bf5 	stp	x21, x22, [sp, #32]
  pid = fork();
    1d84:	94000a2b 	bl	4630 <fork>
  if(pid < 0){
    1d88:	36f800c0 	tbz	w0, #31, 1da0 <sbrkbasic+0x30>
    printf("fork failed in sbrkbasic\n");
    1d8c:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1d90:	91299c00 	add	x0, x0, #0xa67
    1d94:	94000c06 	bl	4dac <printf>
    exit(1);
    1d98:	52800020 	mov	w0, #0x1                   	// #1
    1d9c:	14000007 	b	1db8 <sbrkbasic+0x48>
  if(pid == 0){
    1da0:	350001e0 	cbnz	w0, 1ddc <sbrkbasic+0x6c>
    a = sbrk(TOOMUCH);
    1da4:	52a80000 	mov	w0, #0x40000000            	// #1073741824
    1da8:	94000a58 	bl	4708 <sbrk>
    if(a == (char*)0xffffffffffffffffL){
    1dac:	b100041f 	cmn	x0, #0x1
    1db0:	54000061 	b.ne	1dbc <sbrkbasic+0x4c>  // b.any
      exit(0);
    1db4:	52800000 	mov	w0, #0x0                   	// #0
    1db8:	94000a21 	bl	463c <exit>
    if(a == (char*)0xffffffffffffffffL){
    1dbc:	d2800001 	mov	x1, #0x0                   	// #0
      *b = 99;
    1dc0:	52800c63 	mov	w3, #0x63                  	// #99
    for(b = a; b < a+TOOMUCH; b += 4096){
    1dc4:	d2a80002 	mov	x2, #0x40000000            	// #1073741824
      *b = 99;
    1dc8:	38216803 	strb	w3, [x0, x1]
    for(b = a; b < a+TOOMUCH; b += 4096){
    1dcc:	91400421 	add	x1, x1, #0x1, lsl #12
    1dd0:	eb02003f 	cmp	x1, x2
    1dd4:	54ffffa1 	b.ne	1dc8 <sbrkbasic+0x58>  // b.any
    1dd8:	17fffff0 	b	1d98 <sbrkbasic+0x28>
  wait(&xstatus);
    1ddc:	910133e0 	add	x0, sp, #0x4c
    1de0:	94000a1a 	bl	4648 <wait>
  if(xstatus == 1){
    1de4:	b9404ff3 	ldr	w19, [sp, #76]
    1de8:	7100067f 	cmp	w19, #0x1
    1dec:	540000c1 	b.ne	1e04 <sbrkbasic+0x94>  // b.any
    printf("%s: too much memory allocated!\n", s);
    1df0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1df4:	912a0400 	add	x0, x0, #0xa81
    printf("%s: sbrk test failed post-fork\n", s);
    1df8:	aa1403e1 	mov	x1, x20
    1dfc:	94000bec 	bl	4dac <printf>
    1e00:	17ffffe6 	b	1d98 <sbrkbasic+0x28>
  a = sbrk(0);
    1e04:	52800000 	mov	w0, #0x0                   	// #0
    1e08:	94000a40 	bl	4708 <sbrk>
    1e0c:	aa0003f3 	mov	x19, x0
  for(i = 0; i < 5000; i++){
    1e10:	52800002 	mov	w2, #0x0                   	// #0
    *b = 1;
    1e14:	52800036 	mov	w22, #0x1                   	// #1
  for(i = 0; i < 5000; i++){
    1e18:	52827115 	mov	w21, #0x1388                	// #5000
    b = sbrk(1);
    1e1c:	52800020 	mov	w0, #0x1                   	// #1
    1e20:	b9003fe2 	str	w2, [sp, #60]
    1e24:	94000a39 	bl	4708 <sbrk>
    1e28:	aa0003e4 	mov	x4, x0
    if(b != a){
    1e2c:	b9403fe2 	ldr	w2, [sp, #60]
    1e30:	eb13001f 	cmp	x0, x19
    1e34:	54000120 	b.eq	1e58 <sbrkbasic+0xe8>  // b.none
      printf("%s: sbrk test failed %d %x %x\n", s, i, a, b);
    1e38:	aa1303e3 	mov	x3, x19
    1e3c:	aa1403e1 	mov	x1, x20
    1e40:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1e44:	912a8400 	add	x0, x0, #0xaa1
    1e48:	94000bd9 	bl	4dac <printf>
      exit(1);
    1e4c:	17ffffd3 	b	1d98 <sbrkbasic+0x28>
  for(i = 0; i < 5000; i++){
    1e50:	aa0003f3 	mov	x19, x0
    1e54:	17fffff2 	b	1e1c <sbrkbasic+0xac>
    *b = 1;
    1e58:	aa1303e0 	mov	x0, x19
  for(i = 0; i < 5000; i++){
    1e5c:	11000442 	add	w2, w2, #0x1
    *b = 1;
    1e60:	38001416 	strb	w22, [x0], #1
  for(i = 0; i < 5000; i++){
    1e64:	6b15005f 	cmp	w2, w21
    1e68:	54ffff41 	b.ne	1e50 <sbrkbasic+0xe0>  // b.any
  pid = fork();
    1e6c:	940009f1 	bl	4630 <fork>
    1e70:	2a0003f5 	mov	w21, w0
  if(pid < 0){
    1e74:	36f80080 	tbz	w0, #31, 1e84 <sbrkbasic+0x114>
    printf("%s: sbrk test fork failed\n", s);
    1e78:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1e7c:	912b0000 	add	x0, x0, #0xac0
    1e80:	17ffffde 	b	1df8 <sbrkbasic+0x88>
  c = sbrk(1);
    1e84:	52800020 	mov	w0, #0x1                   	// #1
  if(c != a + 1){
    1e88:	91000a73 	add	x19, x19, #0x2
  c = sbrk(1);
    1e8c:	94000a1f 	bl	4708 <sbrk>
  c = sbrk(1);
    1e90:	52800020 	mov	w0, #0x1                   	// #1
    1e94:	94000a1d 	bl	4708 <sbrk>
  if(c != a + 1){
    1e98:	eb13001f 	cmp	x0, x19
    1e9c:	54000080 	b.eq	1eac <sbrkbasic+0x13c>  // b.none
    printf("%s: sbrk test failed post-fork\n", s);
    1ea0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1ea4:	912b6c00 	add	x0, x0, #0xadb
    1ea8:	17ffffd4 	b	1df8 <sbrkbasic+0x88>
  if(pid == 0)
    1eac:	34fff855 	cbz	w21, 1db4 <sbrkbasic+0x44>
  wait(&xstatus);
    1eb0:	910133e0 	add	x0, sp, #0x4c
    1eb4:	940009e5 	bl	4648 <wait>
  exit(xstatus);
    1eb8:	b9404fe0 	ldr	w0, [sp, #76]
    1ebc:	17ffffbf 	b	1db8 <sbrkbasic+0x48>

0000000000001ec0 <sbrkmuch>:
{
    1ec0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1ec4:	910003fd 	mov	x29, sp
    1ec8:	a90153f3 	stp	x19, x20, [sp, #16]
    1ecc:	aa0003f4 	mov	x20, x0
  oldbrk = sbrk(0);
    1ed0:	52800000 	mov	w0, #0x0                   	// #0
{
    1ed4:	a9025bf5 	stp	x21, x22, [sp, #32]
    1ed8:	f9001bf7 	str	x23, [sp, #48]
  oldbrk = sbrk(0);
    1edc:	94000a0b 	bl	4708 <sbrk>
    1ee0:	aa0003f7 	mov	x23, x0
  a = sbrk(0);
    1ee4:	52800000 	mov	w0, #0x0                   	// #0
    1ee8:	94000a08 	bl	4708 <sbrk>
    1eec:	aa0003f3 	mov	x19, x0
  p = sbrk(amt);
    1ef0:	d2a0c800 	mov	x0, #0x6400000             	// #104857600
    1ef4:	4b130000 	sub	w0, w0, w19
    1ef8:	94000a04 	bl	4708 <sbrk>
  if (p != a) {
    1efc:	eb00027f 	cmp	x19, x0
    1f00:	540000e0 	b.eq	1f1c <sbrkmuch+0x5c>  // b.none
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n", s);
    1f04:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1f08:	912bec00 	add	x0, x0, #0xafb
    printf("%s: sbrk could not deallocate\n", s);
    1f0c:	aa1403e1 	mov	x1, x20
    1f10:	94000ba7 	bl	4dac <printf>
    exit(1);
    1f14:	52800020 	mov	w0, #0x1                   	// #1
    1f18:	940009c9 	bl	463c <exit>
  char *eee = sbrk(0);
    1f1c:	52800000 	mov	w0, #0x0                   	// #0
    1f20:	940009fa 	bl	4708 <sbrk>
    *pp = 1;
    1f24:	52800021 	mov	w1, #0x1                   	// #1
  for(char *pp = a; pp < eee; pp += 4096)
    1f28:	eb00027f 	cmp	x19, x0
    1f2c:	540001c3 	b.cc	1f64 <sbrkmuch+0xa4>  // b.lo, b.ul, b.last
  *lastaddr = 99;
    1f30:	12bf3815 	mov	w21, #0x63fffff             	// #104857599
    1f34:	52800c60 	mov	w0, #0x63                  	// #99
    1f38:	390002a0 	strb	w0, [x21]
  a = sbrk(0);
    1f3c:	52800000 	mov	w0, #0x0                   	// #0
    1f40:	940009f2 	bl	4708 <sbrk>
    1f44:	aa0003f3 	mov	x19, x0
  c = sbrk(-PGSIZE);
    1f48:	1281ffe0 	mov	w0, #0xfffff000            	// #-4096
    1f4c:	940009ef 	bl	4708 <sbrk>
  if(c == (char*)0xffffffffffffffffL){
    1f50:	b100041f 	cmn	x0, #0x1
    1f54:	540000e1 	b.ne	1f70 <sbrkmuch+0xb0>  // b.any
    printf("%s: sbrk could not deallocate\n", s);
    1f58:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1f5c:	912cf400 	add	x0, x0, #0xb3d
    1f60:	17ffffeb 	b	1f0c <sbrkmuch+0x4c>
    *pp = 1;
    1f64:	39000261 	strb	w1, [x19]
  for(char *pp = a; pp < eee; pp += 4096)
    1f68:	91400673 	add	x19, x19, #0x1, lsl #12
    1f6c:	17ffffef 	b	1f28 <sbrkmuch+0x68>
  c = sbrk(0);
    1f70:	52800000 	mov	w0, #0x0                   	// #0
    1f74:	940009e5 	bl	4708 <sbrk>
    1f78:	aa0003e3 	mov	x3, x0
  if(c != a - PGSIZE){
    1f7c:	d1400660 	sub	x0, x19, #0x1, lsl #12
    1f80:	eb00007f 	cmp	x3, x0
    1f84:	540000e0 	b.eq	1fa0 <sbrkmuch+0xe0>  // b.none
    printf("%s: sbrk deallocation produced wrong address, a %x c %x\n", s, a, c);
    1f88:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1f8c:	912d7000 	add	x0, x0, #0xb5c
    printf("%s: sbrk downsize failed, a %x c %x\n", s, a, c);
    1f90:	aa1303e2 	mov	x2, x19
    1f94:	aa1403e1 	mov	x1, x20
    1f98:	94000b85 	bl	4dac <printf>
    exit(1);
    1f9c:	17ffffde 	b	1f14 <sbrkmuch+0x54>
  a = sbrk(0);
    1fa0:	52800000 	mov	w0, #0x0                   	// #0
    1fa4:	940009d9 	bl	4708 <sbrk>
    1fa8:	aa0003f3 	mov	x19, x0
  c = sbrk(PGSIZE);
    1fac:	52820000 	mov	w0, #0x1000                	// #4096
    1fb0:	940009d6 	bl	4708 <sbrk>
    1fb4:	aa0003f6 	mov	x22, x0
  if(c != a || sbrk(0) != a + PGSIZE){
    1fb8:	eb00027f 	cmp	x19, x0
    1fbc:	540000a0 	b.eq	1fd0 <sbrkmuch+0x110>  // b.none
    printf("%s: sbrk re-allocation failed, a %x c %x\n", s, a, c);
    1fc0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1fc4:	912e5400 	add	x0, x0, #0xb95
    1fc8:	aa1603e3 	mov	x3, x22
    1fcc:	17fffff1 	b	1f90 <sbrkmuch+0xd0>
  if(c != a || sbrk(0) != a + PGSIZE){
    1fd0:	52800000 	mov	w0, #0x0                   	// #0
    1fd4:	940009cd 	bl	4708 <sbrk>
    1fd8:	91400661 	add	x1, x19, #0x1, lsl #12
    1fdc:	eb01001f 	cmp	x0, x1
    1fe0:	54ffff01 	b.ne	1fc0 <sbrkmuch+0x100>  // b.any
  if(*lastaddr == 99){
    1fe4:	394002a0 	ldrb	w0, [x21]
    1fe8:	71018c1f 	cmp	w0, #0x63
    1fec:	54000081 	b.ne	1ffc <sbrkmuch+0x13c>  // b.any
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    1ff0:	90000020 	adrp	x0, 5000 <malloc+0xe4>
    1ff4:	912efc00 	add	x0, x0, #0xbbf
    1ff8:	17ffffc5 	b	1f0c <sbrkmuch+0x4c>
  a = sbrk(0);
    1ffc:	52800000 	mov	w0, #0x0                   	// #0
    2000:	940009c2 	bl	4708 <sbrk>
    2004:	aa0003f3 	mov	x19, x0
  c = sbrk(-(sbrk(0) - oldbrk));
    2008:	52800000 	mov	w0, #0x0                   	// #0
    200c:	940009bf 	bl	4708 <sbrk>
    2010:	4b0002e0 	sub	w0, w23, w0
    2014:	940009bd 	bl	4708 <sbrk>
    2018:	aa0003e3 	mov	x3, x0
  if(c != a){
    201c:	eb00027f 	cmp	x19, x0
    2020:	54000080 	b.eq	2030 <sbrkmuch+0x170>  // b.none
    printf("%s: sbrk downsize failed, a %x c %x\n", s, a, c);
    2024:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2028:	912fc000 	add	x0, x0, #0xbf0
    202c:	17ffffd9 	b	1f90 <sbrkmuch+0xd0>
}
    2030:	f9401bf7 	ldr	x23, [sp, #48]
    2034:	a94153f3 	ldp	x19, x20, [sp, #16]
    2038:	a9425bf5 	ldp	x21, x22, [sp, #32]
    203c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2040:	d65f03c0 	ret

0000000000002044 <sbrkarg>:
{
    2044:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2048:	910003fd 	mov	x29, sp
    204c:	a90153f3 	stp	x19, x20, [sp, #16]
    2050:	aa0003f4 	mov	x20, x0
  a = sbrk(PGSIZE);
    2054:	52820000 	mov	w0, #0x1000                	// #4096
{
    2058:	a9025bf5 	stp	x21, x22, [sp, #32]
  a = sbrk(PGSIZE);
    205c:	940009ab 	bl	4708 <sbrk>
  fd = open("sbrk", O_CREATE|O_WRONLY);
    2060:	52804021 	mov	w1, #0x201                 	// #513
    2064:	f0000013 	adrp	x19, 5000 <malloc+0xe4>
  a = sbrk(PGSIZE);
    2068:	aa0003f6 	mov	x22, x0
  fd = open("sbrk", O_CREATE|O_WRONLY);
    206c:	9127fa60 	add	x0, x19, #0x9fe
    2070:	9400098b 	bl	469c <open>
    2074:	2a0003f5 	mov	w21, w0
  unlink("sbrk");
    2078:	9127fa60 	add	x0, x19, #0x9fe
    207c:	9400098e 	bl	46b4 <unlink>
  if(fd < 0)  {
    2080:	36f800f5 	tbz	w21, #31, 209c <sbrkarg+0x58>
    printf("%s: open sbrk failed\n", s);
    2084:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2088:	91305400 	add	x0, x0, #0xc15
    printf("%s: write sbrk failed\n", s);
    208c:	aa1403e1 	mov	x1, x20
    2090:	94000b47 	bl	4dac <printf>
    exit(1);
    2094:	52800020 	mov	w0, #0x1                   	// #1
    2098:	94000969 	bl	463c <exit>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    209c:	aa1603e1 	mov	x1, x22
    20a0:	2a1503e0 	mov	w0, w21
    20a4:	52820002 	mov	w2, #0x1000                	// #4096
    20a8:	94000971 	bl	466c <write>
    20ac:	36f80080 	tbz	w0, #31, 20bc <sbrkarg+0x78>
    printf("%s: write sbrk failed\n", s);
    20b0:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    20b4:	9130ac00 	add	x0, x0, #0xc2b
    20b8:	17fffff5 	b	208c <sbrkarg+0x48>
  close(fd);
    20bc:	2a1503e0 	mov	w0, w21
    20c0:	9400096e 	bl	4678 <close>
  a = sbrk(PGSIZE);
    20c4:	52820000 	mov	w0, #0x1000                	// #4096
    20c8:	94000990 	bl	4708 <sbrk>
  if(pipe((int *) a) != 0){
    20cc:	94000962 	bl	4654 <pipe>
    20d0:	34000080 	cbz	w0, 20e0 <sbrkarg+0x9c>
    printf("%s: pipe() failed\n", s);
    20d4:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    20d8:	911ae800 	add	x0, x0, #0x6ba
    20dc:	17ffffec 	b	208c <sbrkarg+0x48>
}
    20e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    20e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    20e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    20ec:	d65f03c0 	ret

00000000000020f0 <sbrkbugs>:
{
    20f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    20f4:	910003fd 	mov	x29, sp
  int pid = fork();
    20f8:	9400094e 	bl	4630 <fork>
  if(pid < 0){
    20fc:	36f800c0 	tbz	w0, #31, 2114 <sbrkbugs+0x24>
    printf("fork failed\n");
    2100:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2104:	9117b400 	add	x0, x0, #0x5ed
    2108:	94000b29 	bl	4dac <printf>
    exit(1);
    210c:	52800020 	mov	w0, #0x1                   	// #1
    exit(0);
    2110:	9400094b 	bl	463c <exit>
  if(pid == 0){
    2114:	350000c0 	cbnz	w0, 212c <sbrkbugs+0x3c>
    int sz = (uint64) sbrk(0);
    2118:	9400097c 	bl	4708 <sbrk>
    sbrk(-sz);
    211c:	4b0003e0 	neg	w0, w0
    2120:	9400097a 	bl	4708 <sbrk>
    exit(0);
    2124:	52800000 	mov	w0, #0x0                   	// #0
    2128:	17fffffa 	b	2110 <sbrkbugs+0x20>
  wait(0);
    212c:	d2800000 	mov	x0, #0x0                   	// #0
    2130:	94000946 	bl	4648 <wait>
  pid = fork();
    2134:	9400093f 	bl	4630 <fork>
  if(pid < 0){
    2138:	37fffe40 	tbnz	w0, #31, 2100 <sbrkbugs+0x10>
  if(pid == 0){
    213c:	350000a0 	cbnz	w0, 2150 <sbrkbugs+0x60>
    int sz = (uint64) sbrk(0);
    2140:	94000972 	bl	4708 <sbrk>
    sbrk(-(sz - 3500));
    2144:	5281b581 	mov	w1, #0xdac                 	// #3500
    2148:	4b000020 	sub	w0, w1, w0
    214c:	17fffff5 	b	2120 <sbrkbugs+0x30>
  wait(0);
    2150:	d2800000 	mov	x0, #0x0                   	// #0
    2154:	9400093d 	bl	4648 <wait>
  pid = fork();
    2158:	94000936 	bl	4630 <fork>
  if(pid < 0){
    215c:	37fffd20 	tbnz	w0, #31, 2100 <sbrkbugs+0x10>
  if(pid == 0){
    2160:	350000e0 	cbnz	w0, 217c <sbrkbugs+0x8c>
    sbrk((10*4096 + 2048) - (uint64)sbrk(0));
    2164:	94000969 	bl	4708 <sbrk>
    2168:	52950001 	mov	w1, #0xa800                	// #43008
    216c:	4b000020 	sub	w0, w1, w0
    2170:	94000966 	bl	4708 <sbrk>
    sbrk(-10);
    2174:	12800120 	mov	w0, #0xfffffff6            	// #-10
    2178:	17ffffea 	b	2120 <sbrkbugs+0x30>
  wait(0);
    217c:	d2800000 	mov	x0, #0x0                   	// #0
    2180:	94000932 	bl	4648 <wait>
  exit(0);
    2184:	17ffffe8 	b	2124 <sbrkbugs+0x34>

0000000000002188 <sbrklast>:
{
    2188:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  uint64 top = (uint64) sbrk(0);
    218c:	52800000 	mov	w0, #0x0                   	// #0
{
    2190:	910003fd 	mov	x29, sp
    2194:	a90153f3 	stp	x19, x20, [sp, #16]
    2198:	f90013f5 	str	x21, [sp, #32]
  uint64 top = (uint64) sbrk(0);
    219c:	9400095b 	bl	4708 <sbrk>
  if((top % 4096) != 0)
    21a0:	f2402c00 	ands	x0, x0, #0xfff
    21a4:	54000080 	b.eq	21b4 <sbrklast+0x2c>  // b.none
    sbrk(4096 - (top % 4096));
    21a8:	52820001 	mov	w1, #0x1000                	// #4096
    21ac:	4b000020 	sub	w0, w1, w0
    21b0:	94000956 	bl	4708 <sbrk>
  sbrk(4096);
    21b4:	52820000 	mov	w0, #0x1000                	// #4096
    21b8:	94000954 	bl	4708 <sbrk>
  sbrk(10);
    21bc:	52800140 	mov	w0, #0xa                   	// #10
    21c0:	94000952 	bl	4708 <sbrk>
  sbrk(-20);
    21c4:	12800260 	mov	w0, #0xffffffec            	// #-20
    21c8:	94000950 	bl	4708 <sbrk>
  top = (uint64) sbrk(0);
    21cc:	52800000 	mov	w0, #0x0                   	// #0
    21d0:	9400094e 	bl	4708 <sbrk>
    21d4:	aa0003f3 	mov	x19, x0
  p[0] = 'x';
    21d8:	52800f00 	mov	w0, #0x78                  	// #120
  int fd = open(p, O_RDWR|O_CREATE);
    21dc:	52804041 	mov	w1, #0x202                 	// #514
  p[0] = 'x';
    21e0:	781c0260 	sturh	w0, [x19, #-64]
  int fd = open(p, O_RDWR|O_CREATE);
    21e4:	d1010260 	sub	x0, x19, #0x40
    21e8:	9400092d 	bl	469c <open>
    21ec:	2a0003f5 	mov	w21, w0
  write(fd, p, 1);
    21f0:	d1010261 	sub	x1, x19, #0x40
    21f4:	52800022 	mov	w2, #0x1                   	// #1
    21f8:	9400091d 	bl	466c <write>
  close(fd);
    21fc:	2a1503e0 	mov	w0, w21
    2200:	9400091e 	bl	4678 <close>
  fd = open(p, O_RDWR);
    2204:	52800041 	mov	w1, #0x2                   	// #2
    2208:	d1010260 	sub	x0, x19, #0x40
    220c:	94000924 	bl	469c <open>
  p[0] = '\0';
    2210:	381c027f 	sturb	wzr, [x19, #-64]
  read(fd, p, 1);
    2214:	d1010261 	sub	x1, x19, #0x40
    2218:	52800022 	mov	w2, #0x1                   	// #1
    221c:	94000911 	bl	4660 <read>
  if(p[0] != 'x')
    2220:	385c0260 	ldurb	w0, [x19, #-64]
    2224:	7101e01f 	cmp	w0, #0x78
    2228:	54000060 	b.eq	2234 <sbrklast+0xac>  // b.none
    exit(1);
    222c:	52800020 	mov	w0, #0x1                   	// #1
    2230:	94000903 	bl	463c <exit>
}
    2234:	f94013f5 	ldr	x21, [sp, #32]
    2238:	a94153f3 	ldp	x19, x20, [sp, #16]
    223c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2240:	d65f03c0 	ret

0000000000002244 <sbrk8000>:
{
    2244:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  sbrk(0x80000004);
    2248:	52800080 	mov	w0, #0x4                   	// #4
    224c:	72b00000 	movk	w0, #0x8000, lsl #16
{
    2250:	910003fd 	mov	x29, sp
  sbrk(0x80000004);
    2254:	9400092d 	bl	4708 <sbrk>
  volatile char *top = sbrk(0);
    2258:	52800000 	mov	w0, #0x0                   	// #0
    225c:	9400092b 	bl	4708 <sbrk>
  *(top-1) = *(top-1) + 1;
    2260:	385ff001 	ldurb	w1, [x0, #-1]
    2264:	11000421 	add	w1, w1, #0x1
    2268:	381ff001 	sturb	w1, [x0, #-1]
}
    226c:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2270:	d65f03c0 	ret

0000000000002274 <execout>:
{
    2274:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2278:	910003fd 	mov	x29, sp
    227c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(int avail = 0; avail < 15; avail++){
    2280:	52800014 	mov	w20, #0x0                   	// #0
{
    2284:	f90013f5 	str	x21, [sp, #32]
    int pid = fork();
    2288:	940008ea 	bl	4630 <fork>
    228c:	2a0003f3 	mov	w19, w0
    if(pid < 0){
    2290:	36f800c0 	tbz	w0, #31, 22a8 <execout+0x34>
      printf("fork failed\n");
    2294:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2298:	9117b400 	add	x0, x0, #0x5ed
    229c:	94000ac4 	bl	4dac <printf>
      exit(1);
    22a0:	52800020 	mov	w0, #0x1                   	// #1
      exit(0);
    22a4:	940008e6 	bl	463c <exit>
    } else if(pid == 0){
    22a8:	35000360 	cbnz	w0, 2314 <execout+0xa0>
        *(char*)(a + 4096 - 1) = 1;
    22ac:	52800035 	mov	w21, #0x1                   	// #1
        uint64 a = (uint64) sbrk(4096);
    22b0:	52820000 	mov	w0, #0x1000                	// #4096
    22b4:	94000915 	bl	4708 <sbrk>
        if(a == 0xffffffffffffffffLL)
    22b8:	b100041f 	cmn	x0, #0x1
    22bc:	540000c0 	b.eq	22d4 <execout+0x60>  // b.none
        *(char*)(a + 4096 - 1) = 1;
    22c0:	393ffc15 	strb	w21, [x0, #4095]
      while(1){
    22c4:	17fffffb 	b	22b0 <execout+0x3c>
      for(int i = 0; i < avail; i++)
    22c8:	11000673 	add	w19, w19, #0x1
        sbrk(-4096);
    22cc:	1281ffe0 	mov	w0, #0xfffff000            	// #-4096
    22d0:	9400090e 	bl	4708 <sbrk>
      for(int i = 0; i < avail; i++)
    22d4:	6b14027f 	cmp	w19, w20
    22d8:	54ffff81 	b.ne	22c8 <execout+0x54>  // b.any
      close(1);
    22dc:	52800020 	mov	w0, #0x1                   	// #1
    22e0:	940008e6 	bl	4678 <close>
      char *args[] = { "echo", "x", 0 };
    22e4:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    22e8:	91380000 	add	x0, x0, #0xe00
      exec("/bin/echo", args);
    22ec:	9100e3e1 	add	x1, sp, #0x38
      char *args[] = { "echo", "x", 0 };
    22f0:	a9438c02 	ldp	x2, x3, [x0, #56]
    22f4:	a9038fe2 	stp	x2, x3, [sp, #56]
    22f8:	f9402400 	ldr	x0, [x0, #72]
    22fc:	f90027e0 	str	x0, [sp, #72]
      exec("/bin/echo", args);
    2300:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2304:	91143400 	add	x0, x0, #0x50d
    2308:	940008e2 	bl	4690 <exec>
      exit(0);
    230c:	52800000 	mov	w0, #0x0                   	// #0
    2310:	17ffffe5 	b	22a4 <execout+0x30>
      wait((int*)0);
    2314:	d2800000 	mov	x0, #0x0                   	// #0
  for(int avail = 0; avail < 15; avail++){
    2318:	11000694 	add	w20, w20, #0x1
      wait((int*)0);
    231c:	940008cb 	bl	4648 <wait>
  for(int avail = 0; avail < 15; avail++){
    2320:	71003e9f 	cmp	w20, #0xf
    2324:	54fffb21 	b.ne	2288 <execout+0x14>  // b.any
    2328:	17fffff9 	b	230c <execout+0x98>

000000000000232c <fourteen>:
{
    232c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2330:	910003fd 	mov	x29, sp
    2334:	a90153f3 	stp	x19, x20, [sp, #16]
    2338:	aa0003f3 	mov	x19, x0
  if(mkdir("12345678901234") != 0){
    233c:	f0000014 	adrp	x20, 5000 <malloc+0xe4>
    2340:	91351280 	add	x0, x20, #0xd44
{
    2344:	a9025bf5 	stp	x21, x22, [sp, #32]
    2348:	a90363f7 	stp	x23, x24, [sp, #48]
    234c:	f90023f9 	str	x25, [sp, #64]
  if(mkdir("12345678901234") != 0){
    2350:	940008e2 	bl	46d8 <mkdir>
    2354:	340000e0 	cbz	w0, 2370 <fourteen+0x44>
    printf("%s: mkdir 12345678901234 failed\n", s);
    2358:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    235c:	91310800 	add	x0, x0, #0xc42
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    2360:	aa1303e1 	mov	x1, x19
    2364:	94000a92 	bl	4dac <printf>
    exit(1);
    2368:	52800020 	mov	w0, #0x1                   	// #1
    236c:	940008b4 	bl	463c <exit>
  if(mkdir("12345678901234/123456789012345") != 0){
    2370:	f0000015 	adrp	x21, 5000 <malloc+0xe4>
    2374:	91318ea0 	add	x0, x21, #0xc63
    2378:	940008d8 	bl	46d8 <mkdir>
    237c:	34000080 	cbz	w0, 238c <fourteen+0x60>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    2380:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2384:	91320800 	add	x0, x0, #0xc82
    2388:	17fffff6 	b	2360 <fourteen+0x34>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    238c:	f0000016 	adrp	x22, 5000 <malloc+0xe4>
    2390:	52804001 	mov	w1, #0x200                 	// #512
    2394:	9132cec0 	add	x0, x22, #0xcb3
    2398:	940008c1 	bl	469c <open>
  if(fd < 0){
    239c:	36f80080 	tbz	w0, #31, 23ac <fourteen+0x80>
    printf("%s: create 123456789012345/123456789012345/123456789012345 failed\n", s);
    23a0:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    23a4:	91338c00 	add	x0, x0, #0xce3
    23a8:	17ffffee 	b	2360 <fourteen+0x34>
  close(fd);
    23ac:	940008b3 	bl	4678 <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    23b0:	f0000017 	adrp	x23, 5000 <malloc+0xe4>
    23b4:	52800001 	mov	w1, #0x0                   	// #0
    23b8:	91349ae0 	add	x0, x23, #0xd26
    23bc:	940008b8 	bl	469c <open>
  if(fd < 0){
    23c0:	36f80080 	tbz	w0, #31, 23d0 <fourteen+0xa4>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    23c4:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    23c8:	91354c00 	add	x0, x0, #0xd53
    23cc:	17ffffe5 	b	2360 <fourteen+0x34>
  close(fd);
    23d0:	940008aa 	bl	4678 <close>
  if(mkdir("12345678901234/12345678901234") == 0){
    23d4:	f0000018 	adrp	x24, 5000 <malloc+0xe4>
    23d8:	9134d700 	add	x0, x24, #0xd35
    23dc:	940008bf 	bl	46d8 <mkdir>
    23e0:	35000080 	cbnz	w0, 23f0 <fourteen+0xc4>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    23e4:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    23e8:	91364400 	add	x0, x0, #0xd91
    23ec:	17ffffdd 	b	2360 <fourteen+0x34>
  if(mkdir("123456789012345/12345678901234") == 0){
    23f0:	f0000019 	adrp	x25, 5000 <malloc+0xe4>
    23f4:	91371720 	add	x0, x25, #0xdc5
    23f8:	940008b8 	bl	46d8 <mkdir>
    23fc:	35000080 	cbnz	w0, 240c <fourteen+0xe0>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    2400:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2404:	91379000 	add	x0, x0, #0xde4
    2408:	17ffffd6 	b	2360 <fourteen+0x34>
  unlink("123456789012345/12345678901234");
    240c:	91371720 	add	x0, x25, #0xdc5
    2410:	940008a9 	bl	46b4 <unlink>
  unlink("12345678901234/12345678901234");
    2414:	9134d700 	add	x0, x24, #0xd35
    2418:	940008a7 	bl	46b4 <unlink>
  unlink("12345678901234/12345678901234/12345678901234");
    241c:	91349ae0 	add	x0, x23, #0xd26
    2420:	940008a5 	bl	46b4 <unlink>
  unlink("123456789012345/123456789012345/123456789012345");
    2424:	9132cec0 	add	x0, x22, #0xcb3
    2428:	940008a3 	bl	46b4 <unlink>
  unlink("12345678901234/123456789012345");
    242c:	91318ea0 	add	x0, x21, #0xc63
    2430:	940008a1 	bl	46b4 <unlink>
}
    2434:	f94023f9 	ldr	x25, [sp, #64]
  unlink("12345678901234");
    2438:	91351280 	add	x0, x20, #0xd44
}
    243c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2440:	a94153f3 	ldp	x19, x20, [sp, #16]
    2444:	a94363f7 	ldp	x23, x24, [sp, #48]
    2448:	a8c57bfd 	ldp	x29, x30, [sp], #80
  unlink("12345678901234");
    244c:	1400089a 	b	46b4 <unlink>

0000000000002450 <iputtest>:
{
    2450:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2454:	910003fd 	mov	x29, sp
    2458:	a90153f3 	stp	x19, x20, [sp, #16]
    245c:	aa0003f3 	mov	x19, x0
  if(mkdir("iputdir") < 0){
    2460:	f0000014 	adrp	x20, 5000 <malloc+0xe4>
    2464:	91392280 	add	x0, x20, #0xe48
    2468:	9400089c 	bl	46d8 <mkdir>
    246c:	36f800e0 	tbz	w0, #31, 2488 <iputtest+0x38>
    printf("%s: mkdir failed\n", s);
    2470:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2474:	91386400 	add	x0, x0, #0xe19
    printf("%s: chdir iputdir failed\n", s);
    2478:	aa1303e1 	mov	x1, x19
    247c:	94000a4c 	bl	4dac <printf>
    exit(1);
    2480:	52800020 	mov	w0, #0x1                   	// #1
    2484:	9400086e 	bl	463c <exit>
  if(chdir("iputdir") < 0){
    2488:	91392280 	add	x0, x20, #0xe48
    248c:	94000896 	bl	46e4 <chdir>
    2490:	36f80080 	tbz	w0, #31, 24a0 <iputtest+0x50>
    printf("%s: chdir iputdir failed\n", s);
    2494:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2498:	9138ac00 	add	x0, x0, #0xe2b
    249c:	17fffff7 	b	2478 <iputtest+0x28>
  if(unlink("../iputdir") < 0){
    24a0:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    24a4:	91391400 	add	x0, x0, #0xe45
    24a8:	94000883 	bl	46b4 <unlink>
    24ac:	36f80080 	tbz	w0, #31, 24bc <iputtest+0x6c>
    printf("%s: unlink ../iputdir failed\n", s);
    24b0:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    24b4:	91394000 	add	x0, x0, #0xe50
    24b8:	17fffff0 	b	2478 <iputtest+0x28>
  if(chdir("/") < 0){
    24bc:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    24c0:	9139b800 	add	x0, x0, #0xe6e
    24c4:	94000888 	bl	46e4 <chdir>
    24c8:	36f80080 	tbz	w0, #31, 24d8 <iputtest+0x88>
    printf("%s: chdir / failed\n", s);
    24cc:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    24d0:	9139c000 	add	x0, x0, #0xe70
    24d4:	17ffffe9 	b	2478 <iputtest+0x28>
}
    24d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    24dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    24e0:	d65f03c0 	ret

00000000000024e4 <exitiputtest>:
{
    24e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    24e8:	910003fd 	mov	x29, sp
    24ec:	a90153f3 	stp	x19, x20, [sp, #16]
    24f0:	aa0003f3 	mov	x19, x0
  pid = fork();
    24f4:	9400084f 	bl	4630 <fork>
  if(pid < 0){
    24f8:	36f800e0 	tbz	w0, #31, 2514 <exitiputtest+0x30>
    printf("%s: fork failed\n", s);
    24fc:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2500:	9117a400 	add	x0, x0, #0x5e9
      printf("%s: mkdir failed\n", s);
    2504:	aa1303e1 	mov	x1, x19
    2508:	94000a29 	bl	4dac <printf>
      exit(1);
    250c:	52800020 	mov	w0, #0x1                   	// #1
    2510:	9400084b 	bl	463c <exit>
  if(pid == 0){
    2514:	350002e0 	cbnz	w0, 2570 <exitiputtest+0x8c>
    if(mkdir("iputdir") < 0){
    2518:	f0000014 	adrp	x20, 5000 <malloc+0xe4>
    251c:	91392280 	add	x0, x20, #0xe48
    2520:	9400086e 	bl	46d8 <mkdir>
    2524:	36f80080 	tbz	w0, #31, 2534 <exitiputtest+0x50>
      printf("%s: mkdir failed\n", s);
    2528:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    252c:	91386400 	add	x0, x0, #0xe19
    2530:	17fffff5 	b	2504 <exitiputtest+0x20>
    if(chdir("iputdir") < 0){
    2534:	91392280 	add	x0, x20, #0xe48
    2538:	9400086b 	bl	46e4 <chdir>
    253c:	36f80080 	tbz	w0, #31, 254c <exitiputtest+0x68>
      printf("%s: child chdir failed\n", s);
    2540:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2544:	913a1000 	add	x0, x0, #0xe84
    2548:	17ffffef 	b	2504 <exitiputtest+0x20>
    if(unlink("../iputdir") < 0){
    254c:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2550:	91391400 	add	x0, x0, #0xe45
    2554:	94000858 	bl	46b4 <unlink>
    2558:	36f80080 	tbz	w0, #31, 2568 <exitiputtest+0x84>
      printf("%s: unlink ../iputdir failed\n", s);
    255c:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2560:	91394000 	add	x0, x0, #0xe50
    2564:	17ffffe8 	b	2504 <exitiputtest+0x20>
    exit(0);
    2568:	52800000 	mov	w0, #0x0                   	// #0
    256c:	17ffffe9 	b	2510 <exitiputtest+0x2c>
  wait(&xstatus);
    2570:	9100b3e0 	add	x0, sp, #0x2c
    2574:	94000835 	bl	4648 <wait>
  exit(xstatus);
    2578:	b9402fe0 	ldr	w0, [sp, #44]
    257c:	17ffffe5 	b	2510 <exitiputtest+0x2c>

0000000000002580 <dirtest>:
{
    2580:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2584:	910003fd 	mov	x29, sp
    2588:	a90153f3 	stp	x19, x20, [sp, #16]
    258c:	aa0003f4 	mov	x20, x0
  if(mkdir("dir0") < 0){
    2590:	f0000013 	adrp	x19, 5000 <malloc+0xe4>
    2594:	913a7260 	add	x0, x19, #0xe9c
    2598:	94000850 	bl	46d8 <mkdir>
    259c:	36f800e0 	tbz	w0, #31, 25b8 <dirtest+0x38>
    printf("%s: mkdir failed\n", s);
    25a0:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    25a4:	91386400 	add	x0, x0, #0xe19
    printf("%s: chdir dir0 failed\n", s);
    25a8:	aa1403e1 	mov	x1, x20
    25ac:	94000a00 	bl	4dac <printf>
    exit(1);
    25b0:	52800020 	mov	w0, #0x1                   	// #1
    25b4:	94000822 	bl	463c <exit>
  if(chdir("dir0") < 0){
    25b8:	913a7260 	add	x0, x19, #0xe9c
    25bc:	9400084a 	bl	46e4 <chdir>
    25c0:	36f80080 	tbz	w0, #31, 25d0 <dirtest+0x50>
    printf("%s: chdir dir0 failed\n", s);
    25c4:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    25c8:	913a8400 	add	x0, x0, #0xea1
    25cc:	17fffff7 	b	25a8 <dirtest+0x28>
  if(chdir("..") < 0){
    25d0:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    25d4:	91023c00 	add	x0, x0, #0x8f
    25d8:	94000843 	bl	46e4 <chdir>
    25dc:	36f80080 	tbz	w0, #31, 25ec <dirtest+0x6c>
    printf("%s: chdir .. failed\n", s);
    25e0:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    25e4:	913ae000 	add	x0, x0, #0xeb8
    25e8:	17fffff0 	b	25a8 <dirtest+0x28>
  if(unlink("dir0") < 0){
    25ec:	913a7260 	add	x0, x19, #0xe9c
    25f0:	94000831 	bl	46b4 <unlink>
    25f4:	36f80080 	tbz	w0, #31, 2604 <dirtest+0x84>
    printf("%s: unlink dir0 failed\n", s);
    25f8:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    25fc:	913b3400 	add	x0, x0, #0xecd
    2600:	17ffffea 	b	25a8 <dirtest+0x28>
}
    2604:	a94153f3 	ldp	x19, x20, [sp, #16]
    2608:	a8c27bfd 	ldp	x29, x30, [sp], #32
    260c:	d65f03c0 	ret

0000000000002610 <subdir>:
{
    2610:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2614:	910003fd 	mov	x29, sp
    2618:	a90153f3 	stp	x19, x20, [sp, #16]
    261c:	aa0003f3 	mov	x19, x0
    2620:	a9025bf5 	stp	x21, x22, [sp, #32]
  unlink("ff");
    2624:	f0000015 	adrp	x21, 5000 <malloc+0xe4>
    2628:	913e42a0 	add	x0, x21, #0xf90
{
    262c:	a90363f7 	stp	x23, x24, [sp, #48]
    2630:	f90023f9 	str	x25, [sp, #64]
  unlink("ff");
    2634:	94000820 	bl	46b4 <unlink>
  if(mkdir("dd") != 0){
    2638:	90000034 	adrp	x20, 6000 <malloc+0x10e4>
    263c:	91022a80 	add	x0, x20, #0x8a
    2640:	94000826 	bl	46d8 <mkdir>
    2644:	340000e0 	cbz	w0, 2660 <subdir+0x50>
    printf("%s: mkdir dd failed\n", s);
    2648:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    264c:	913b9400 	add	x0, x0, #0xee5
    printf("%s: create dd/ff failed\n", s);
    2650:	aa1303e1 	mov	x1, x19
    2654:	940009d6 	bl	4dac <printf>
    exit(1);
    2658:	52800020 	mov	w0, #0x1                   	// #1
    265c:	940007f8 	bl	463c <exit>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    2660:	f0000017 	adrp	x23, 5000 <malloc+0xe4>
    2664:	52804041 	mov	w1, #0x202                 	// #514
    2668:	913d8ae0 	add	x0, x23, #0xf62
    266c:	9400080c 	bl	469c <open>
    2670:	2a0003f6 	mov	w22, w0
  if(fd < 0){
    2674:	36f80080 	tbz	w0, #31, 2684 <subdir+0x74>
    printf("%s: create dd/ff failed\n", s);
    2678:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    267c:	913be800 	add	x0, x0, #0xefa
    2680:	17fffff4 	b	2650 <subdir+0x40>
  write(fd, "ff", 2);
    2684:	913e42a1 	add	x1, x21, #0xf90
    2688:	52800042 	mov	w2, #0x2                   	// #2
    268c:	940007f8 	bl	466c <write>
  close(fd);
    2690:	2a1603e0 	mov	w0, w22
    2694:	940007f9 	bl	4678 <close>
  if(unlink("dd") >= 0){
    2698:	91022a80 	add	x0, x20, #0x8a
    269c:	94000806 	bl	46b4 <unlink>
    26a0:	37f80080 	tbnz	w0, #31, 26b0 <subdir+0xa0>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    26a4:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    26a8:	913c4c00 	add	x0, x0, #0xf13
    26ac:	17ffffe9 	b	2650 <subdir+0x40>
  if(mkdir("/dd/dd") != 0){
    26b0:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    26b4:	913cf400 	add	x0, x0, #0xf3d
    26b8:	94000808 	bl	46d8 <mkdir>
    26bc:	34000080 	cbz	w0, 26cc <subdir+0xbc>
    printf("subdir mkdir dd/dd failed\n", s);
    26c0:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    26c4:	913d1000 	add	x0, x0, #0xf44
    26c8:	17ffffe2 	b	2650 <subdir+0x40>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    26cc:	f0000016 	adrp	x22, 5000 <malloc+0xe4>
    26d0:	52804041 	mov	w1, #0x202                 	// #514
    26d4:	913d7ec0 	add	x0, x22, #0xf5f
    26d8:	940007f1 	bl	469c <open>
    26dc:	2a0003f5 	mov	w21, w0
  if(fd < 0){
    26e0:	36f80080 	tbz	w0, #31, 26f0 <subdir+0xe0>
    printf("%s: create dd/dd/ff failed\n", s);
    26e4:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    26e8:	913da000 	add	x0, x0, #0xf68
    26ec:	17ffffd9 	b	2650 <subdir+0x40>
  write(fd, "FF", 2);
    26f0:	f0000001 	adrp	x1, 5000 <malloc+0xe4>
    26f4:	913e1021 	add	x1, x1, #0xf84
    26f8:	52800042 	mov	w2, #0x2                   	// #2
    26fc:	940007dc 	bl	466c <write>
  close(fd);
    2700:	2a1503e0 	mov	w0, w21
    2704:	940007dd 	bl	4678 <close>
  fd = open("dd/dd/../ff", 0);
    2708:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    270c:	913e1c00 	add	x0, x0, #0xf87
    2710:	52800001 	mov	w1, #0x0                   	// #0
    2714:	940007e2 	bl	469c <open>
    2718:	2a0003f5 	mov	w21, w0
  if(fd < 0){
    271c:	36f80080 	tbz	w0, #31, 272c <subdir+0x11c>
    printf("%s: open dd/dd/../ff failed\n", s);
    2720:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2724:	913e4c00 	add	x0, x0, #0xf93
    2728:	17ffffca 	b	2650 <subdir+0x40>
  cc = read(fd, buf, sizeof(buf));
    272c:	90000058 	adrp	x24, a000 <uninit+0x1cb7>
    2730:	91296719 	add	x25, x24, #0xa59
    2734:	aa1903e1 	mov	x1, x25
    2738:	52860002 	mov	w2, #0x3000                	// #12288
    273c:	940007c9 	bl	4660 <read>
  if(cc != 2 || buf[0] != 'f'){
    2740:	7100081f 	cmp	w0, #0x2
    2744:	54000081 	b.ne	2754 <subdir+0x144>  // b.any
    2748:	39696700 	ldrb	w0, [x24, #2649]
    274c:	7101981f 	cmp	w0, #0x66
    2750:	54000080 	b.eq	2760 <subdir+0x150>  // b.none
    printf("%s: dd/dd/../ff wrong content\n", s);
    2754:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2758:	913ec000 	add	x0, x0, #0xfb0
    275c:	17ffffbd 	b	2650 <subdir+0x40>
  close(fd);
    2760:	2a1503e0 	mov	w0, w21
    2764:	940007c5 	bl	4678 <close>
  if(link("dd/dd/ff", "dd/dd/ffff") != 0){
    2768:	f0000015 	adrp	x21, 5000 <malloc+0xe4>
    276c:	913f3ea1 	add	x1, x21, #0xfcf
    2770:	913d7ec0 	add	x0, x22, #0xf5f
    2774:	940007d6 	bl	46cc <link>
    2778:	34000080 	cbz	w0, 2788 <subdir+0x178>
    printf("link dd/dd/ff dd/dd/ffff failed\n", s);
    277c:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2780:	913f6800 	add	x0, x0, #0xfda
    2784:	17ffffb3 	b	2650 <subdir+0x40>
  if(unlink("dd/dd/ff") != 0){
    2788:	913d7ec0 	add	x0, x22, #0xf5f
    278c:	940007ca 	bl	46b4 <unlink>
    2790:	34000080 	cbz	w0, 27a0 <subdir+0x190>
    printf("%s: unlink dd/dd/ff failed\n", s);
    2794:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2798:	913fec00 	add	x0, x0, #0xffb
    279c:	17ffffad 	b	2650 <subdir+0x40>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    27a0:	913d7ec0 	add	x0, x22, #0xf5f
    27a4:	52800001 	mov	w1, #0x0                   	// #0
    27a8:	940007bd 	bl	469c <open>
    27ac:	37f80080 	tbnz	w0, #31, 27bc <subdir+0x1ac>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    27b0:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    27b4:	91005c00 	add	x0, x0, #0x17
    27b8:	17ffffa6 	b	2650 <subdir+0x40>
  if(chdir("dd") != 0){
    27bc:	91022a80 	add	x0, x20, #0x8a
    27c0:	940007c9 	bl	46e4 <chdir>
    27c4:	34000080 	cbz	w0, 27d4 <subdir+0x1c4>
    printf("%s: chdir dd failed\n", s);
    27c8:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    27cc:	9100fc00 	add	x0, x0, #0x3f
    27d0:	17ffffa0 	b	2650 <subdir+0x40>
  if(chdir("dd/../../dd") != 0){
    27d4:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    27d8:	91015000 	add	x0, x0, #0x54
    27dc:	940007c2 	bl	46e4 <chdir>
    27e0:	34000080 	cbz	w0, 27f0 <subdir+0x1e0>
    printf("%s: chdir dd/../../dd failed\n", s);
    27e4:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    27e8:	91018000 	add	x0, x0, #0x60
    27ec:	17ffff99 	b	2650 <subdir+0x40>
  if(chdir("dd/../../../dd") != 0){
    27f0:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    27f4:	9101f800 	add	x0, x0, #0x7e
    27f8:	940007bb 	bl	46e4 <chdir>
    27fc:	34000080 	cbz	w0, 280c <subdir+0x1fc>
    printf("chdir dd/../../dd failed\n", s);
    2800:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2804:	91019000 	add	x0, x0, #0x64
    2808:	17ffff92 	b	2650 <subdir+0x40>
  if(chdir("./..") != 0){
    280c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2810:	91023400 	add	x0, x0, #0x8d
    2814:	940007b4 	bl	46e4 <chdir>
    2818:	34000080 	cbz	w0, 2828 <subdir+0x218>
    printf("%s: chdir ./.. failed\n", s);
    281c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2820:	91024800 	add	x0, x0, #0x92
    2824:	17ffff8b 	b	2650 <subdir+0x40>
  fd = open("dd/dd/ffff", 0);
    2828:	913f3ea0 	add	x0, x21, #0xfcf
    282c:	52800001 	mov	w1, #0x0                   	// #0
    2830:	9400079b 	bl	469c <open>
    2834:	2a0003f8 	mov	w24, w0
  if(fd < 0){
    2838:	36f80080 	tbz	w0, #31, 2848 <subdir+0x238>
    printf("%s: open dd/dd/ffff failed\n", s);
    283c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2840:	9102a400 	add	x0, x0, #0xa9
    2844:	17ffff83 	b	2650 <subdir+0x40>
  if(read(fd, buf, sizeof(buf)) != 2){
    2848:	aa1903e1 	mov	x1, x25
    284c:	52860002 	mov	w2, #0x3000                	// #12288
    2850:	94000784 	bl	4660 <read>
    2854:	7100081f 	cmp	w0, #0x2
    2858:	54000080 	b.eq	2868 <subdir+0x258>  // b.none
    printf("%s: read dd/dd/ffff wrong len\n", s);
    285c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2860:	91031400 	add	x0, x0, #0xc5
    2864:	17ffff7b 	b	2650 <subdir+0x40>
  close(fd);
    2868:	2a1803e0 	mov	w0, w24
    286c:	94000783 	bl	4678 <close>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    2870:	913d7ec0 	add	x0, x22, #0xf5f
    2874:	52800001 	mov	w1, #0x0                   	// #0
    2878:	94000789 	bl	469c <open>
    287c:	37f80080 	tbnz	w0, #31, 288c <subdir+0x27c>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    2880:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2884:	91039000 	add	x0, x0, #0xe4
    2888:	17ffff72 	b	2650 <subdir+0x40>
  if(open("dd/ff/ff", O_CREATE|O_RDWR) >= 0){
    288c:	90000036 	adrp	x22, 6000 <malloc+0x10e4>
    2890:	52804041 	mov	w1, #0x202                 	// #514
    2894:	910436c0 	add	x0, x22, #0x10d
    2898:	94000781 	bl	469c <open>
    289c:	37f80080 	tbnz	w0, #31, 28ac <subdir+0x29c>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    28a0:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    28a4:	91045800 	add	x0, x0, #0x116
    28a8:	17ffff6a 	b	2650 <subdir+0x40>
  if(open("dd/xx/ff", O_CREATE|O_RDWR) >= 0){
    28ac:	90000038 	adrp	x24, 6000 <malloc+0x10e4>
    28b0:	52804041 	mov	w1, #0x202                 	// #514
    28b4:	9104db00 	add	x0, x24, #0x136
    28b8:	94000779 	bl	469c <open>
    28bc:	37f80080 	tbnz	w0, #31, 28cc <subdir+0x2bc>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    28c0:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    28c4:	9104fc00 	add	x0, x0, #0x13f
    28c8:	17ffff62 	b	2650 <subdir+0x40>
  if(open("dd", O_CREATE) >= 0){
    28cc:	91022a80 	add	x0, x20, #0x8a
    28d0:	52804001 	mov	w1, #0x200                 	// #512
    28d4:	94000772 	bl	469c <open>
    28d8:	37f80080 	tbnz	w0, #31, 28e8 <subdir+0x2d8>
    printf("%s: create dd succeeded!\n", s);
    28dc:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    28e0:	91057c00 	add	x0, x0, #0x15f
    28e4:	17ffff5b 	b	2650 <subdir+0x40>
  if(open("dd", O_RDWR) >= 0){
    28e8:	91022a80 	add	x0, x20, #0x8a
    28ec:	52800041 	mov	w1, #0x2                   	// #2
    28f0:	9400076b 	bl	469c <open>
    28f4:	37f80080 	tbnz	w0, #31, 2904 <subdir+0x2f4>
    printf("%s: open dd rdwr succeeded!\n", s);
    28f8:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    28fc:	9105e400 	add	x0, x0, #0x179
    2900:	17ffff54 	b	2650 <subdir+0x40>
  if(open("dd", O_WRONLY) >= 0){
    2904:	91022a80 	add	x0, x20, #0x8a
    2908:	52800021 	mov	w1, #0x1                   	// #1
    290c:	94000764 	bl	469c <open>
    2910:	37f80080 	tbnz	w0, #31, 2920 <subdir+0x310>
    printf("%s: open dd wronly succeeded!\n", s);
    2914:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2918:	91065800 	add	x0, x0, #0x196
    291c:	17ffff4d 	b	2650 <subdir+0x40>
  if(link("dd/ff/ff", "dd/dd/xx") == 0){
    2920:	90000034 	adrp	x20, 6000 <malloc+0x10e4>
    2924:	9106d681 	add	x1, x20, #0x1b5
    2928:	910436c0 	add	x0, x22, #0x10d
    292c:	94000768 	bl	46cc <link>
    2930:	35000080 	cbnz	w0, 2940 <subdir+0x330>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    2934:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2938:	9106f800 	add	x0, x0, #0x1be
    293c:	17ffff45 	b	2650 <subdir+0x40>
  if(link("dd/xx/ff", "dd/dd/xx") == 0){
    2940:	9106d681 	add	x1, x20, #0x1b5
    2944:	9104db00 	add	x0, x24, #0x136
    2948:	94000761 	bl	46cc <link>
    294c:	35000080 	cbnz	w0, 295c <subdir+0x34c>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    2950:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2954:	91079400 	add	x0, x0, #0x1e5
    2958:	17ffff3e 	b	2650 <subdir+0x40>
  if(link("dd/ff", "dd/dd/ffff") == 0){
    295c:	913f3ea1 	add	x1, x21, #0xfcf
    2960:	913d8ae0 	add	x0, x23, #0xf62
    2964:	9400075a 	bl	46cc <link>
    2968:	35000080 	cbnz	w0, 2978 <subdir+0x368>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    296c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2970:	91083000 	add	x0, x0, #0x20c
    2974:	17ffff37 	b	2650 <subdir+0x40>
  if(mkdir("dd/ff/ff") == 0){
    2978:	910436c0 	add	x0, x22, #0x10d
    297c:	94000757 	bl	46d8 <mkdir>
    2980:	35000080 	cbnz	w0, 2990 <subdir+0x380>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    2984:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2988:	9108c800 	add	x0, x0, #0x232
    298c:	17ffff31 	b	2650 <subdir+0x40>
  if(mkdir("dd/xx/ff") == 0){
    2990:	9104db00 	add	x0, x24, #0x136
    2994:	94000751 	bl	46d8 <mkdir>
    2998:	35000080 	cbnz	w0, 29a8 <subdir+0x398>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    299c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    29a0:	91094400 	add	x0, x0, #0x251
    29a4:	17ffff2b 	b	2650 <subdir+0x40>
  if(mkdir("dd/dd/ffff") == 0){
    29a8:	913f3ea0 	add	x0, x21, #0xfcf
    29ac:	9400074b 	bl	46d8 <mkdir>
    29b0:	35000080 	cbnz	w0, 29c0 <subdir+0x3b0>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    29b4:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    29b8:	9109c000 	add	x0, x0, #0x270
    29bc:	17ffff25 	b	2650 <subdir+0x40>
  if(unlink("dd/xx/ff") == 0){
    29c0:	9104db00 	add	x0, x24, #0x136
    29c4:	9400073c 	bl	46b4 <unlink>
    29c8:	35000080 	cbnz	w0, 29d8 <subdir+0x3c8>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    29cc:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    29d0:	910a4400 	add	x0, x0, #0x291
    29d4:	17ffff1f 	b	2650 <subdir+0x40>
  if(unlink("dd/ff/ff") == 0){
    29d8:	910436c0 	add	x0, x22, #0x10d
    29dc:	94000736 	bl	46b4 <unlink>
    29e0:	35000080 	cbnz	w0, 29f0 <subdir+0x3e0>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    29e4:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    29e8:	910ac400 	add	x0, x0, #0x2b1
    29ec:	17ffff19 	b	2650 <subdir+0x40>
  if(chdir("dd/ff") == 0){
    29f0:	913d8ae0 	add	x0, x23, #0xf62
    29f4:	9400073c 	bl	46e4 <chdir>
    29f8:	35000080 	cbnz	w0, 2a08 <subdir+0x3f8>
    printf("%s: chdir dd/ff succeeded!\n", s);
    29fc:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2a00:	910b4400 	add	x0, x0, #0x2d1
    2a04:	17ffff13 	b	2650 <subdir+0x40>
  if(chdir("dd/xx") == 0){
    2a08:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2a0c:	9106e000 	add	x0, x0, #0x1b8
    2a10:	94000735 	bl	46e4 <chdir>
    2a14:	35000080 	cbnz	w0, 2a24 <subdir+0x414>
    printf("%s: chdir dd/xx succeeded!\n", s);
    2a18:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2a1c:	910bb400 	add	x0, x0, #0x2ed
    2a20:	17ffff0c 	b	2650 <subdir+0x40>
  if(unlink("dd/dd/ffff") != 0){
    2a24:	913f3ea0 	add	x0, x21, #0xfcf
    2a28:	94000723 	bl	46b4 <unlink>
    2a2c:	35ffeb40 	cbnz	w0, 2794 <subdir+0x184>
  if(unlink("dd/ff") != 0){
    2a30:	913d8ae0 	add	x0, x23, #0xf62
    2a34:	94000720 	bl	46b4 <unlink>
    2a38:	34000080 	cbz	w0, 2a48 <subdir+0x438>
    printf("%s: unlink dd/ff failed\n", s);
    2a3c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2a40:	910c2400 	add	x0, x0, #0x309
    2a44:	17ffff03 	b	2650 <subdir+0x40>
  if(unlink("dd") == 0){
    2a48:	90000034 	adrp	x20, 6000 <malloc+0x10e4>
    2a4c:	91022a80 	add	x0, x20, #0x8a
    2a50:	94000719 	bl	46b4 <unlink>
    2a54:	35000080 	cbnz	w0, 2a64 <subdir+0x454>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    2a58:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2a5c:	910c8800 	add	x0, x0, #0x322
    2a60:	17fffefc 	b	2650 <subdir+0x40>
  if(unlink("dd/dd") < 0){
    2a64:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2a68:	913cf800 	add	x0, x0, #0xf3e
    2a6c:	94000712 	bl	46b4 <unlink>
    2a70:	36f80080 	tbz	w0, #31, 2a80 <subdir+0x470>
    printf("%s: unlink dd/dd failed\n", s);
    2a74:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2a78:	910d1800 	add	x0, x0, #0x346
    2a7c:	17fffef5 	b	2650 <subdir+0x40>
  if(unlink("dd") < 0){
    2a80:	91022a80 	add	x0, x20, #0x8a
    2a84:	9400070c 	bl	46b4 <unlink>
    2a88:	36f80080 	tbz	w0, #31, 2a98 <subdir+0x488>
    printf("%s: unlink dd failed\n", s);
    2a8c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2a90:	910d7c00 	add	x0, x0, #0x35f
    2a94:	17fffeef 	b	2650 <subdir+0x40>
}
    2a98:	f94023f9 	ldr	x25, [sp, #64]
    2a9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2aa0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2aa4:	a94363f7 	ldp	x23, x24, [sp, #48]
    2aa8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2aac:	d65f03c0 	ret

0000000000002ab0 <rmdot>:
{
    2ab0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ab4:	910003fd 	mov	x29, sp
    2ab8:	a90153f3 	stp	x19, x20, [sp, #16]
    2abc:	aa0003f3 	mov	x19, x0
  if(mkdir("dots") != 0){
    2ac0:	90000034 	adrp	x20, 6000 <malloc+0x10e4>
    2ac4:	910dd680 	add	x0, x20, #0x375
    2ac8:	94000704 	bl	46d8 <mkdir>
    2acc:	340000e0 	cbz	w0, 2ae8 <rmdot+0x38>
    printf("%s: mkdir dots failed\n", s);
    2ad0:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2ad4:	910de800 	add	x0, x0, #0x37a
    printf("%s: chdir dots failed\n", s);
    2ad8:	aa1303e1 	mov	x1, x19
    2adc:	940008b4 	bl	4dac <printf>
    exit(1);
    2ae0:	52800020 	mov	w0, #0x1                   	// #1
    2ae4:	940006d6 	bl	463c <exit>
  if(chdir("dots") != 0){
    2ae8:	910dd680 	add	x0, x20, #0x375
    2aec:	940006fe 	bl	46e4 <chdir>
    2af0:	34000080 	cbz	w0, 2b00 <rmdot+0x50>
    printf("%s: chdir dots failed\n", s);
    2af4:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2af8:	910e4400 	add	x0, x0, #0x391
    2afc:	17fffff7 	b	2ad8 <rmdot+0x28>
  if(unlink(".") == 0){
    2b00:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b04:	91024000 	add	x0, x0, #0x90
    2b08:	940006eb 	bl	46b4 <unlink>
    2b0c:	35000080 	cbnz	w0, 2b1c <rmdot+0x6c>
    printf("%s: rm . worked!\n", s);
    2b10:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b14:	910ea000 	add	x0, x0, #0x3a8
    2b18:	17fffff0 	b	2ad8 <rmdot+0x28>
  if(unlink("..") == 0){
    2b1c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b20:	91023c00 	add	x0, x0, #0x8f
    2b24:	940006e4 	bl	46b4 <unlink>
    2b28:	35000080 	cbnz	w0, 2b38 <rmdot+0x88>
    printf("%s: rm .. worked!\n", s);
    2b2c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b30:	910ee800 	add	x0, x0, #0x3ba
    2b34:	17ffffe9 	b	2ad8 <rmdot+0x28>
  if(chdir("/") != 0){
    2b38:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2b3c:	9139b800 	add	x0, x0, #0xe6e
    2b40:	940006e9 	bl	46e4 <chdir>
    2b44:	34000080 	cbz	w0, 2b54 <rmdot+0xa4>
    printf("%s: chdir / failed\n", s);
    2b48:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2b4c:	9139c000 	add	x0, x0, #0xe70
    2b50:	17ffffe2 	b	2ad8 <rmdot+0x28>
  if(unlink("dots/.") == 0){
    2b54:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b58:	910f3400 	add	x0, x0, #0x3cd
    2b5c:	940006d6 	bl	46b4 <unlink>
    2b60:	35000080 	cbnz	w0, 2b70 <rmdot+0xc0>
    printf("%s: unlink dots/. worked!\n", s);
    2b64:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b68:	910f5000 	add	x0, x0, #0x3d4
    2b6c:	17ffffdb 	b	2ad8 <rmdot+0x28>
  if(unlink("dots/..") == 0){
    2b70:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b74:	910fbc00 	add	x0, x0, #0x3ef
    2b78:	940006cf 	bl	46b4 <unlink>
    2b7c:	35000080 	cbnz	w0, 2b8c <rmdot+0xdc>
    printf("%s: unlink dots/.. worked!\n", s);
    2b80:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b84:	910fdc00 	add	x0, x0, #0x3f7
    2b88:	17ffffd4 	b	2ad8 <rmdot+0x28>
  if(unlink("dots") != 0){
    2b8c:	910dd680 	add	x0, x20, #0x375
    2b90:	940006c9 	bl	46b4 <unlink>
    2b94:	34000080 	cbz	w0, 2ba4 <rmdot+0xf4>
    printf("%s: unlink dots failed!\n", s);
    2b98:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2b9c:	91104c00 	add	x0, x0, #0x413
    2ba0:	17ffffce 	b	2ad8 <rmdot+0x28>
}
    2ba4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ba8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2bac:	d65f03c0 	ret

0000000000002bb0 <dirfile>:
{
    2bb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  fd = open("dirfile", O_CREATE);
    2bb4:	52804001 	mov	w1, #0x200                 	// #512
{
    2bb8:	910003fd 	mov	x29, sp
    2bbc:	a90153f3 	stp	x19, x20, [sp, #16]
    2bc0:	aa0003f3 	mov	x19, x0
    2bc4:	f90013f5 	str	x21, [sp, #32]
  fd = open("dirfile", O_CREATE);
    2bc8:	90000035 	adrp	x21, 6000 <malloc+0x10e4>
    2bcc:	9110b2a0 	add	x0, x21, #0x42c
    2bd0:	940006b3 	bl	469c <open>
  if(fd < 0){
    2bd4:	36f800e0 	tbz	w0, #31, 2bf0 <dirfile+0x40>
    printf("%s: create dirfile failed\n", s);
    2bd8:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2bdc:	9110d000 	add	x0, x0, #0x434
    printf("%s: chdir dirfile succeeded!\n", s);
    2be0:	aa1303e1 	mov	x1, x19
    2be4:	94000872 	bl	4dac <printf>
    exit(1);
    2be8:	52800020 	mov	w0, #0x1                   	// #1
    2bec:	94000694 	bl	463c <exit>
  close(fd);
    2bf0:	940006a2 	bl	4678 <close>
  if(chdir("dirfile") == 0){
    2bf4:	9110b2a0 	add	x0, x21, #0x42c
    2bf8:	940006bb 	bl	46e4 <chdir>
    2bfc:	35000080 	cbnz	w0, 2c0c <dirfile+0x5c>
    printf("%s: chdir dirfile succeeded!\n", s);
    2c00:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2c04:	91113c00 	add	x0, x0, #0x44f
    2c08:	17fffff6 	b	2be0 <dirfile+0x30>
  fd = open("dirfile/xx", 0);
    2c0c:	90000034 	adrp	x20, 6000 <malloc+0x10e4>
    2c10:	52800001 	mov	w1, #0x0                   	// #0
    2c14:	9111b680 	add	x0, x20, #0x46d
    2c18:	940006a1 	bl	469c <open>
  if(fd >= 0){
    2c1c:	37f80080 	tbnz	w0, #31, 2c2c <dirfile+0x7c>
    printf("%s: create dirfile/xx succeeded!\n", s);
    2c20:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2c24:	9111e000 	add	x0, x0, #0x478
    2c28:	17ffffee 	b	2be0 <dirfile+0x30>
  fd = open("dirfile/xx", O_CREATE);
    2c2c:	9111b680 	add	x0, x20, #0x46d
    2c30:	52804001 	mov	w1, #0x200                 	// #512
    2c34:	9400069a 	bl	469c <open>
  if(fd >= 0){
    2c38:	36ffff40 	tbz	w0, #31, 2c20 <dirfile+0x70>
  if(mkdir("dirfile/xx") == 0){
    2c3c:	9111b680 	add	x0, x20, #0x46d
    2c40:	940006a6 	bl	46d8 <mkdir>
    2c44:	35000080 	cbnz	w0, 2c54 <dirfile+0xa4>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    2c48:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2c4c:	91126800 	add	x0, x0, #0x49a
    2c50:	17ffffe4 	b	2be0 <dirfile+0x30>
  if(unlink("dirfile/xx") == 0){
    2c54:	9111b680 	add	x0, x20, #0x46d
    2c58:	94000697 	bl	46b4 <unlink>
    2c5c:	35000080 	cbnz	w0, 2c6c <dirfile+0xbc>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    2c60:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2c64:	9112ec00 	add	x0, x0, #0x4bb
    2c68:	17ffffde 	b	2be0 <dirfile+0x30>
  if(link("README", "dirfile/xx") == 0){
    2c6c:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2c70:	91054000 	add	x0, x0, #0x150
    2c74:	9111b681 	add	x1, x20, #0x46d
    2c78:	94000695 	bl	46cc <link>
    2c7c:	35000080 	cbnz	w0, 2c8c <dirfile+0xdc>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    2c80:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2c84:	91137400 	add	x0, x0, #0x4dd
    2c88:	17ffffd6 	b	2be0 <dirfile+0x30>
  if(unlink("dirfile") != 0){
    2c8c:	9110b2a0 	add	x0, x21, #0x42c
    2c90:	94000689 	bl	46b4 <unlink>
    2c94:	34000080 	cbz	w0, 2ca4 <dirfile+0xf4>
    printf("%s: unlink dirfile failed!\n", s);
    2c98:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2c9c:	91140000 	add	x0, x0, #0x500
    2ca0:	17ffffd0 	b	2be0 <dirfile+0x30>
  fd = open(".", O_RDWR);
    2ca4:	90000034 	adrp	x20, 6000 <malloc+0x10e4>
    2ca8:	52800041 	mov	w1, #0x2                   	// #2
    2cac:	91024280 	add	x0, x20, #0x90
    2cb0:	9400067b 	bl	469c <open>
  if(fd >= 0){
    2cb4:	37f80080 	tbnz	w0, #31, 2cc4 <dirfile+0x114>
    printf("%s: open . for writing succeeded!\n", s);
    2cb8:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2cbc:	91147000 	add	x0, x0, #0x51c
    2cc0:	17ffffc8 	b	2be0 <dirfile+0x30>
  fd = open(".", 0);
    2cc4:	91024280 	add	x0, x20, #0x90
    2cc8:	52800001 	mov	w1, #0x0                   	// #0
    2ccc:	94000674 	bl	469c <open>
    2cd0:	2a0003f4 	mov	w20, w0
  if(write(fd, "x", 1) > 0){
    2cd4:	90000021 	adrp	x1, 6000 <malloc+0x10e4>
    2cd8:	9106f021 	add	x1, x1, #0x1bc
    2cdc:	52800022 	mov	w2, #0x1                   	// #1
    2ce0:	94000663 	bl	466c <write>
    2ce4:	7100001f 	cmp	w0, #0x0
    2ce8:	5400008d 	b.le	2cf8 <dirfile+0x148>
    printf("%s: write . succeeded!\n", s);
    2cec:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2cf0:	9114fc00 	add	x0, x0, #0x53f
    2cf4:	17ffffbb 	b	2be0 <dirfile+0x30>
}
    2cf8:	f94013f5 	ldr	x21, [sp, #32]
  close(fd);
    2cfc:	2a1403e0 	mov	w0, w20
}
    2d00:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d04:	a8c37bfd 	ldp	x29, x30, [sp], #48
  close(fd);
    2d08:	1400065c 	b	4678 <close>

0000000000002d0c <iref>:
{
    2d0c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2d10:	910003fd 	mov	x29, sp
    2d14:	a90153f3 	stp	x19, x20, [sp, #16]
    if(mkdir("irefd") != 0){
    2d18:	90000033 	adrp	x19, 6000 <malloc+0x10e4>
    2d1c:	91155e73 	add	x19, x19, #0x557
    mkdir("");
    2d20:	90000034 	adrp	x20, 6000 <malloc+0x10e4>
    2d24:	911a7294 	add	x20, x20, #0x69c
{
    2d28:	a90363f7 	stp	x23, x24, [sp, #48]
    link("README", "");
    2d2c:	f0000017 	adrp	x23, 5000 <malloc+0xe4>
    2d30:	910542f7 	add	x23, x23, #0x150
{
    2d34:	aa0003f8 	mov	x24, x0
    2d38:	a9025bf5 	stp	x21, x22, [sp, #32]
    2d3c:	52800676 	mov	w22, #0x33                  	// #51
    if(mkdir("irefd") != 0){
    2d40:	aa1303e0 	mov	x0, x19
    2d44:	94000665 	bl	46d8 <mkdir>
    2d48:	340000e0 	cbz	w0, 2d64 <iref+0x58>
      printf("%s: mkdir irefd failed\n", s);
    2d4c:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2d50:	91157400 	add	x0, x0, #0x55d
      printf("%s: chdir irefd failed\n", s);
    2d54:	aa1803e1 	mov	x1, x24
    2d58:	94000815 	bl	4dac <printf>
      exit(1);
    2d5c:	52800020 	mov	w0, #0x1                   	// #1
    2d60:	94000637 	bl	463c <exit>
    if(chdir("irefd") != 0){
    2d64:	aa1303e0 	mov	x0, x19
    2d68:	9400065f 	bl	46e4 <chdir>
    2d6c:	34000080 	cbz	w0, 2d7c <iref+0x70>
      printf("%s: chdir irefd failed\n", s);
    2d70:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2d74:	9115d400 	add	x0, x0, #0x575
    2d78:	17fffff7 	b	2d54 <iref+0x48>
    mkdir("");
    2d7c:	aa1403e0 	mov	x0, x20
    2d80:	94000656 	bl	46d8 <mkdir>
    link("README", "");
    2d84:	aa1403e1 	mov	x1, x20
    2d88:	aa1703e0 	mov	x0, x23
    2d8c:	94000650 	bl	46cc <link>
    fd = open("", O_CREATE);
    2d90:	aa1403e0 	mov	x0, x20
    2d94:	52804001 	mov	w1, #0x200                 	// #512
    2d98:	94000641 	bl	469c <open>
    if(fd >= 0)
    2d9c:	37f80040 	tbnz	w0, #31, 2da4 <iref+0x98>
      close(fd);
    2da0:	94000636 	bl	4678 <close>
    fd = open("xx", O_CREATE);
    2da4:	90000035 	adrp	x21, 6000 <malloc+0x10e4>
    2da8:	9106eeb5 	add	x21, x21, #0x1bb
    2dac:	aa1503e0 	mov	x0, x21
    2db0:	52804001 	mov	w1, #0x200                 	// #512
    2db4:	9400063a 	bl	469c <open>
    if(fd >= 0)
    2db8:	37f80040 	tbnz	w0, #31, 2dc0 <iref+0xb4>
      close(fd);
    2dbc:	9400062f 	bl	4678 <close>
    unlink("xx");
    2dc0:	aa1503e0 	mov	x0, x21
    2dc4:	9400063c 	bl	46b4 <unlink>
  for(i = 0; i < NINODE + 1; i++){
    2dc8:	710006d6 	subs	w22, w22, #0x1
    2dcc:	54fffba1 	b.ne	2d40 <iref+0x34>  // b.any
    chdir("..");
    2dd0:	90000035 	adrp	x21, 6000 <malloc+0x10e4>
    2dd4:	91023eb5 	add	x21, x21, #0x8f
  for(i = 0; i < NINODE + 1; i++){
    2dd8:	52800674 	mov	w20, #0x33                  	// #51
    chdir("..");
    2ddc:	aa1503e0 	mov	x0, x21
    2de0:	94000641 	bl	46e4 <chdir>
    unlink("irefd");
    2de4:	aa1303e0 	mov	x0, x19
    2de8:	94000633 	bl	46b4 <unlink>
  for(i = 0; i < NINODE + 1; i++){
    2dec:	71000694 	subs	w20, w20, #0x1
    2df0:	54ffff61 	b.ne	2ddc <iref+0xd0>  // b.any
}
    2df4:	a94153f3 	ldp	x19, x20, [sp, #16]
  chdir("/");
    2df8:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2dfc:	9139b800 	add	x0, x0, #0xe6e
}
    2e00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e04:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e08:	a8c47bfd 	ldp	x29, x30, [sp], #64
  chdir("/");
    2e0c:	14000636 	b	46e4 <chdir>

0000000000002e10 <openiputtest>:
{
    2e10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e14:	910003fd 	mov	x29, sp
    2e18:	a90153f3 	stp	x19, x20, [sp, #16]
  if(mkdir("oidir") < 0){
    2e1c:	90000033 	adrp	x19, 6000 <malloc+0x10e4>
    2e20:	91163673 	add	x19, x19, #0x58d
{
    2e24:	aa0003f4 	mov	x20, x0
  if(mkdir("oidir") < 0){
    2e28:	aa1303e0 	mov	x0, x19
    2e2c:	9400062b 	bl	46d8 <mkdir>
    2e30:	36f800e0 	tbz	w0, #31, 2e4c <openiputtest+0x3c>
    printf("%s: mkdir oidir failed\n", s);
    2e34:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2e38:	91164c00 	add	x0, x0, #0x593
    printf("%s: fork failed\n", s);
    2e3c:	aa1403e1 	mov	x1, x20
    2e40:	940007db 	bl	4dac <printf>
    exit(1);
    2e44:	52800020 	mov	w0, #0x1                   	// #1
    2e48:	940005fd 	bl	463c <exit>
  pid = fork();
    2e4c:	940005f9 	bl	4630 <fork>
  if(pid < 0){
    2e50:	36f80080 	tbz	w0, #31, 2e60 <openiputtest+0x50>
    printf("%s: fork failed\n", s);
    2e54:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2e58:	9117a400 	add	x0, x0, #0x5e9
    2e5c:	17fffff8 	b	2e3c <openiputtest+0x2c>
  if(pid == 0){
    2e60:	35000140 	cbnz	w0, 2e88 <openiputtest+0x78>
    int fd = open("oidir", O_RDWR);
    2e64:	aa1303e0 	mov	x0, x19
    2e68:	52800041 	mov	w1, #0x2                   	// #2
    2e6c:	9400060c 	bl	469c <open>
    if(fd >= 0){
    2e70:	37f80080 	tbnz	w0, #31, 2e80 <openiputtest+0x70>
      printf("%s: open directory for write succeeded\n", s);
    2e74:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2e78:	9116ac00 	add	x0, x0, #0x5ab
    2e7c:	17fffff0 	b	2e3c <openiputtest+0x2c>
    exit(0);
    2e80:	52800000 	mov	w0, #0x0                   	// #0
    2e84:	17fffff1 	b	2e48 <openiputtest+0x38>
  sleep_ticks(1);
    2e88:	52800020 	mov	w0, #0x1                   	// #1
    2e8c:	94000622 	bl	4714 <sleep_ticks>
  if(unlink("oidir") != 0){
    2e90:	aa1303e0 	mov	x0, x19
    2e94:	94000608 	bl	46b4 <unlink>
    2e98:	34000080 	cbz	w0, 2ea8 <openiputtest+0x98>
    printf("%s: unlink failed\n", s);
    2e9c:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2ea0:	911de000 	add	x0, x0, #0x778
    2ea4:	17ffffe6 	b	2e3c <openiputtest+0x2c>
  wait(&xstatus);
    2ea8:	9100b3e0 	add	x0, sp, #0x2c
    2eac:	940005e7 	bl	4648 <wait>
  exit(xstatus);
    2eb0:	b9402fe0 	ldr	w0, [sp, #44]
    2eb4:	17ffffe5 	b	2e48 <openiputtest+0x38>

0000000000002eb8 <forkforkfork>:
{
    2eb8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ebc:	910003fd 	mov	x29, sp
    2ec0:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("stopforking");
    2ec4:	90000033 	adrp	x19, 6000 <malloc+0x10e4>
    2ec8:	91174e73 	add	x19, x19, #0x5d3
{
    2ecc:	aa0003f4 	mov	x20, x0
  unlink("stopforking");
    2ed0:	aa1303e0 	mov	x0, x19
    2ed4:	940005f8 	bl	46b4 <unlink>
  int pid = fork();
    2ed8:	940005d6 	bl	4630 <fork>
  if(pid < 0){
    2edc:	36f800e0 	tbz	w0, #31, 2ef8 <forkforkfork+0x40>
    printf("%s: fork failed", s);
    2ee0:	aa1403e1 	mov	x1, x20
    2ee4:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2ee8:	911d3c00 	add	x0, x0, #0x74f
    2eec:	940007b0 	bl	4dac <printf>
    exit(1);
    2ef0:	52800020 	mov	w0, #0x1                   	// #1
        exit(0);
    2ef4:	940005d2 	bl	463c <exit>
  if(pid == 0){
    2ef8:	350001c0 	cbnz	w0, 2f30 <forkforkfork+0x78>
      int fd = open("stopforking", 0);
    2efc:	aa1303e0 	mov	x0, x19
    2f00:	52800001 	mov	w1, #0x0                   	// #0
    2f04:	940005e6 	bl	469c <open>
      if(fd >= 0){
    2f08:	37f80060 	tbnz	w0, #31, 2f14 <forkforkfork+0x5c>
        exit(0);
    2f0c:	52800000 	mov	w0, #0x0                   	// #0
    2f10:	17fffff9 	b	2ef4 <forkforkfork+0x3c>
      if(fork() < 0){
    2f14:	940005c7 	bl	4630 <fork>
    2f18:	36ffff20 	tbz	w0, #31, 2efc <forkforkfork+0x44>
        close(open("stopforking", O_CREATE|O_RDWR));
    2f1c:	52804041 	mov	w1, #0x202                 	// #514
    2f20:	aa1303e0 	mov	x0, x19
    2f24:	940005de 	bl	469c <open>
    2f28:	940005d4 	bl	4678 <close>
    2f2c:	17fffff4 	b	2efc <forkforkfork+0x44>
  sleep_ticks(20); // two seconds
    2f30:	52800280 	mov	w0, #0x14                  	// #20
    2f34:	940005f8 	bl	4714 <sleep_ticks>
  close(open("stopforking", O_CREATE|O_RDWR));
    2f38:	52804041 	mov	w1, #0x202                 	// #514
    2f3c:	aa1303e0 	mov	x0, x19
    2f40:	940005d7 	bl	469c <open>
    2f44:	940005cd 	bl	4678 <close>
  wait(0);
    2f48:	d2800000 	mov	x0, #0x0                   	// #0
    2f4c:	940005bf 	bl	4648 <wait>
}
    2f50:	a94153f3 	ldp	x19, x20, [sp, #16]
  sleep_ticks(10); // one second
    2f54:	52800140 	mov	w0, #0xa                   	// #10
}
    2f58:	a8c27bfd 	ldp	x29, x30, [sp], #32
  sleep_ticks(10); // one second
    2f5c:	140005ee 	b	4714 <sleep_ticks>

0000000000002f60 <killstatus>:
{
    2f60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f64:	910003fd 	mov	x29, sp
    2f68:	f90013f5 	str	x21, [sp, #32]
    2f6c:	aa0003f5 	mov	x21, x0
    2f70:	a90153f3 	stp	x19, x20, [sp, #16]
    2f74:	52800c93 	mov	w19, #0x64                  	// #100
    int pid1 = fork();
    2f78:	940005ae 	bl	4630 <fork>
    2f7c:	2a0003f4 	mov	w20, w0
    if(pid1 < 0){
    2f80:	36f800e0 	tbz	w0, #31, 2f9c <killstatus+0x3c>
      printf("%s: fork failed\n", s);
    2f84:	f0000000 	adrp	x0, 5000 <malloc+0xe4>
    2f88:	9117a400 	add	x0, x0, #0x5e9
       printf("%s: status should be -1\n", s);
    2f8c:	aa1503e1 	mov	x1, x21
    2f90:	94000787 	bl	4dac <printf>
       exit(1);
    2f94:	52800020 	mov	w0, #0x1                   	// #1
    2f98:	940005a9 	bl	463c <exit>
    if(pid1 == 0){
    2f9c:	35000060 	cbnz	w0, 2fa8 <killstatus+0x48>
        getpid();
    2fa0:	940005d7 	bl	46fc <getpid>
      while(1) {
    2fa4:	17ffffff 	b	2fa0 <killstatus+0x40>
    sleep_ticks(1);
    2fa8:	52800020 	mov	w0, #0x1                   	// #1
    2fac:	940005da 	bl	4714 <sleep_ticks>
    kill(pid1);
    2fb0:	2a1403e0 	mov	w0, w20
    2fb4:	940005b4 	bl	4684 <kill>
    wait(&xst);
    2fb8:	9100f3e0 	add	x0, sp, #0x3c
    2fbc:	940005a3 	bl	4648 <wait>
    if(xst != -1) {
    2fc0:	b9403fe0 	ldr	w0, [sp, #60]
    2fc4:	3100041f 	cmn	w0, #0x1
    2fc8:	54000080 	b.eq	2fd8 <killstatus+0x78>  // b.none
       printf("%s: status should be -1\n", s);
    2fcc:	90000020 	adrp	x0, 6000 <malloc+0x10e4>
    2fd0:	91177c00 	add	x0, x0, #0x5df
    2fd4:	17ffffee 	b	2f8c <killstatus+0x2c>
  for(int i = 0; i < 100; i++){
    2fd8:	71000673 	subs	w19, w19, #0x1
    2fdc:	54fffce1 	b.ne	2f78 <killstatus+0x18>  // b.any
  exit(0);
    2fe0:	52800000 	mov	w0, #0x0                   	// #0
    2fe4:	17ffffed 	b	2f98 <killstatus+0x38>

0000000000002fe8 <preempt>:
{
    2fe8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2fec:	910003fd 	mov	x29, sp
    2ff0:	a90153f3 	stp	x19, x20, [sp, #16]
    2ff4:	aa0003f3 	mov	x19, x0
    2ff8:	a9025bf5 	stp	x21, x22, [sp, #32]
  pid1 = fork();
    2ffc:	9400058d 	bl	4630 <fork>
  if(pid1 < 0) {
    3000:	36f800e0 	tbz	w0, #31, 301c <preempt+0x34>
    printf("%s: fork failed", s);
    3004:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3008:	911d3c00 	add	x0, x0, #0x74f
    printf("%s: fork failed\n", s);
    300c:	aa1303e1 	mov	x1, x19
    3010:	94000767 	bl	4dac <printf>
    exit(1);
    3014:	52800020 	mov	w0, #0x1                   	// #1
    3018:	94000589 	bl	463c <exit>
    301c:	2a0003f6 	mov	w22, w0
  if(pid1 == 0)
    3020:	35000040 	cbnz	w0, 3028 <preempt+0x40>
    for(;;)
    3024:	14000000 	b	3024 <preempt+0x3c>
  pid2 = fork();
    3028:	94000582 	bl	4630 <fork>
    302c:	2a0003f5 	mov	w21, w0
  if(pid2 < 0) {
    3030:	36f80080 	tbz	w0, #31, 3040 <preempt+0x58>
    printf("%s: fork failed\n", s);
    3034:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3038:	9117a400 	add	x0, x0, #0x5e9
    303c:	17fffff4 	b	300c <preempt+0x24>
  if(pid2 == 0)
    3040:	35000040 	cbnz	w0, 3048 <preempt+0x60>
    for(;;)
    3044:	14000000 	b	3044 <preempt+0x5c>
  pipe(pfds);
    3048:	9100e3e0 	add	x0, sp, #0x38
    304c:	94000582 	bl	4654 <pipe>
  pid3 = fork();
    3050:	94000578 	bl	4630 <fork>
    3054:	2a0003f4 	mov	w20, w0
  if(pid3 < 0) {
    3058:	37fffee0 	tbnz	w0, #31, 3034 <preempt+0x4c>
  if(pid3 == 0){
    305c:	35000220 	cbnz	w0, 30a0 <preempt+0xb8>
    close(pfds[0]);
    3060:	b9403be0 	ldr	w0, [sp, #56]
    3064:	94000585 	bl	4678 <close>
    if(write(pfds[1], "x", 1) != 1)
    3068:	b9403fe0 	ldr	w0, [sp, #60]
    306c:	f0000001 	adrp	x1, 6000 <malloc+0x10e4>
    3070:	9106f021 	add	x1, x1, #0x1bc
    3074:	52800022 	mov	w2, #0x1                   	// #1
    3078:	9400057d 	bl	466c <write>
    307c:	7100041f 	cmp	w0, #0x1
    3080:	540000a0 	b.eq	3094 <preempt+0xac>  // b.none
      printf("%s: preempt write error", s);
    3084:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3088:	9117e000 	add	x0, x0, #0x5f8
    308c:	aa1303e1 	mov	x1, x19
    3090:	94000747 	bl	4dac <printf>
    close(pfds[1]);
    3094:	b9403fe0 	ldr	w0, [sp, #60]
    3098:	94000578 	bl	4678 <close>
    for(;;)
    309c:	14000000 	b	309c <preempt+0xb4>
  close(pfds[1]);
    30a0:	b9403fe0 	ldr	w0, [sp, #60]
    30a4:	94000575 	bl	4678 <close>
  if(read(pfds[0], buf, sizeof(buf)) != 1){
    30a8:	b9403be0 	ldr	w0, [sp, #56]
    30ac:	f0000021 	adrp	x1, a000 <uninit+0x1cb7>
    30b0:	91296421 	add	x1, x1, #0xa59
    30b4:	52860002 	mov	w2, #0x3000                	// #12288
    30b8:	9400056a 	bl	4660 <read>
    30bc:	7100041f 	cmp	w0, #0x1
    30c0:	54000120 	b.eq	30e4 <preempt+0xfc>  // b.none
    printf("%s: preempt read error", s);
    30c4:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    30c8:	91184000 	add	x0, x0, #0x610
    30cc:	aa1303e1 	mov	x1, x19
    30d0:	94000737 	bl	4dac <printf>
}
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30dc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    30e0:	d65f03c0 	ret
  close(pfds[0]);
    30e4:	b9403be0 	ldr	w0, [sp, #56]
    30e8:	94000564 	bl	4678 <close>
  printf("kill... ");
    30ec:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    30f0:	91189c00 	add	x0, x0, #0x627
    30f4:	9400072e 	bl	4dac <printf>
  kill(pid1);
    30f8:	2a1603e0 	mov	w0, w22
    30fc:	94000562 	bl	4684 <kill>
  kill(pid2);
    3100:	2a1503e0 	mov	w0, w21
    3104:	94000560 	bl	4684 <kill>
  kill(pid3);
    3108:	2a1403e0 	mov	w0, w20
    310c:	9400055e 	bl	4684 <kill>
  printf("wait... ");
    3110:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3114:	9118c000 	add	x0, x0, #0x630
    3118:	94000725 	bl	4dac <printf>
  wait(0);
    311c:	d2800000 	mov	x0, #0x0                   	// #0
    3120:	9400054a 	bl	4648 <wait>
  wait(0);
    3124:	d2800000 	mov	x0, #0x0                   	// #0
    3128:	94000548 	bl	4648 <wait>
  wait(0);
    312c:	d2800000 	mov	x0, #0x0                   	// #0
    3130:	94000546 	bl	4648 <wait>
    3134:	17ffffe8 	b	30d4 <preempt+0xec>

0000000000003138 <reparent>:
{
    3138:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    313c:	910003fd 	mov	x29, sp
    3140:	a90153f3 	stp	x19, x20, [sp, #16]
  int master_pid = getpid();
    3144:	52801913 	mov	w19, #0xc8                  	// #200
{
    3148:	a9025bf5 	stp	x21, x22, [sp, #32]
    314c:	aa0003f5 	mov	x21, x0
  int master_pid = getpid();
    3150:	9400056b 	bl	46fc <getpid>
    3154:	2a0003f6 	mov	w22, w0
    int pid = fork();
    3158:	94000536 	bl	4630 <fork>
    315c:	2a0003f4 	mov	w20, w0
    if(pid < 0){
    3160:	36f800e0 	tbz	w0, #31, 317c <reparent+0x44>
      printf("%s: fork failed\n", s);
    3164:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3168:	9117a400 	add	x0, x0, #0x5e9
        printf("%s: wait wrong pid\n", s);
    316c:	aa1503e1 	mov	x1, x21
    3170:	9400070f 	bl	4dac <printf>
        exit(1);
    3174:	52800020 	mov	w0, #0x1                   	// #1
    3178:	94000531 	bl	463c <exit>
    if(pid){
    317c:	34000100 	cbz	w0, 319c <reparent+0x64>
      if(wait(0) != pid){
    3180:	d2800000 	mov	x0, #0x0                   	// #0
    3184:	94000531 	bl	4648 <wait>
    3188:	6b14001f 	cmp	w0, w20
    318c:	54000120 	b.eq	31b0 <reparent+0x78>  // b.none
        printf("%s: wait wrong pid\n", s);
    3190:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3194:	911c7c00 	add	x0, x0, #0x71f
    3198:	17fffff5 	b	316c <reparent+0x34>
      int pid2 = fork();
    319c:	94000525 	bl	4630 <fork>
      if(pid2 < 0){
    31a0:	36f800c0 	tbz	w0, #31, 31b8 <reparent+0x80>
        kill(master_pid);
    31a4:	2a1603e0 	mov	w0, w22
    31a8:	94000537 	bl	4684 <kill>
        exit(1);
    31ac:	17fffff2 	b	3174 <reparent+0x3c>
  for(int i = 0; i < 200; i++){
    31b0:	71000673 	subs	w19, w19, #0x1
    31b4:	54fffd21 	b.ne	3158 <reparent+0x20>  // b.any
      exit(0);
    31b8:	52800000 	mov	w0, #0x0                   	// #0
    31bc:	17ffffef 	b	3178 <reparent+0x40>

00000000000031c0 <sbrkfail>:
{
    31c0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    31c4:	910003fd 	mov	x29, sp
    31c8:	a90153f3 	stp	x19, x20, [sp, #16]
    31cc:	aa0003f3 	mov	x19, x0
  if(pipe(fds) != 0){
    31d0:	910103e0 	add	x0, sp, #0x40
{
    31d4:	a9025bf5 	stp	x21, x22, [sp, #32]
  if(pipe(fds) != 0){
    31d8:	9400051f 	bl	4654 <pipe>
    31dc:	35000240 	cbnz	w0, 3224 <sbrkfail+0x64>
    if((pids[i] = fork()) == 0){
    31e0:	910123f5 	add	x21, sp, #0x48
    31e4:	d2800014 	mov	x20, #0x0                   	// #0
    31e8:	94000512 	bl	4630 <fork>
    31ec:	b8347aa0 	str	w0, [x21, x20, lsl #2]
    31f0:	35000260 	cbnz	w0, 323c <sbrkfail+0x7c>
      sbrk(BIG - (uint64)sbrk(0));
    31f4:	94000545 	bl	4708 <sbrk>
    31f8:	52a0c801 	mov	w1, #0x6400000             	// #104857600
    31fc:	4b000020 	sub	w0, w1, w0
    3200:	94000542 	bl	4708 <sbrk>
      write(fds[1], "x", 1);
    3204:	b94047e0 	ldr	w0, [sp, #68]
    3208:	f0000001 	adrp	x1, 6000 <malloc+0x10e4>
    320c:	9106f021 	add	x1, x1, #0x1bc
    3210:	52800022 	mov	w2, #0x1                   	// #1
    3214:	94000516 	bl	466c <write>
      for(;;) sleep_ticks(1000);
    3218:	52807d00 	mov	w0, #0x3e8                 	// #1000
    321c:	9400053e 	bl	4714 <sleep_ticks>
    3220:	17fffffe 	b	3218 <sbrkfail+0x58>
    printf("%s: pipe() failed\n", s);
    3224:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3228:	911ae800 	add	x0, x0, #0x6ba
    printf("%s: failed sbrk leaked memory\n", s);
    322c:	aa1303e1 	mov	x1, x19
    3230:	940006df 	bl	4dac <printf>
    exit(1);
    3234:	52800020 	mov	w0, #0x1                   	// #1
    3238:	94000501 	bl	463c <exit>
    if(pids[i] != -1)
    323c:	3100041f 	cmn	w0, #0x1
    3240:	540000a0 	b.eq	3254 <sbrkfail+0x94>  // b.none
      read(fds[0], &scratch, 1);
    3244:	b94043e0 	ldr	w0, [sp, #64]
    3248:	9100efe1 	add	x1, sp, #0x3b
    324c:	52800022 	mov	w2, #0x1                   	// #1
    3250:	94000504 	bl	4660 <read>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3254:	91000694 	add	x20, x20, #0x1
    3258:	f1002a9f 	cmp	x20, #0xa
    325c:	54fffc61 	b.ne	31e8 <sbrkfail+0x28>  // b.any
  c = sbrk(PGSIZE);
    3260:	52820000 	mov	w0, #0x1000                	// #4096
    3264:	94000529 	bl	4708 <sbrk>
    3268:	aa0003f6 	mov	x22, x0
    326c:	d2800014 	mov	x20, #0x0                   	// #0
    if(pids[i] == -1)
    3270:	b8747aa0 	ldr	w0, [x21, x20, lsl #2]
    3274:	3100041f 	cmn	w0, #0x1
    3278:	54000080 	b.eq	3288 <sbrkfail+0xc8>  // b.none
    kill(pids[i]);
    327c:	94000502 	bl	4684 <kill>
    wait(0);
    3280:	d2800000 	mov	x0, #0x0                   	// #0
    3284:	940004f1 	bl	4648 <wait>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3288:	91000694 	add	x20, x20, #0x1
    328c:	f1002a9f 	cmp	x20, #0xa
    3290:	54ffff01 	b.ne	3270 <sbrkfail+0xb0>  // b.any
  if(c == (char*)0xffffffffffffffffL){
    3294:	b10006df 	cmn	x22, #0x1
    3298:	54000081 	b.ne	32a8 <sbrkfail+0xe8>  // b.any
    printf("%s: failed sbrk leaked memory\n", s);
    329c:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    32a0:	9118e400 	add	x0, x0, #0x639
    32a4:	17ffffe2 	b	322c <sbrkfail+0x6c>
  pid = fork();
    32a8:	940004e2 	bl	4630 <fork>
    32ac:	2a0003f5 	mov	w21, w0
  if(pid < 0){
    32b0:	36f80080 	tbz	w0, #31, 32c0 <sbrkfail+0x100>
    printf("%s: fork failed\n", s);
    32b4:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    32b8:	9117a400 	add	x0, x0, #0x5e9
    32bc:	17ffffdc 	b	322c <sbrkfail+0x6c>
  if(pid == 0){
    32c0:	35000240 	cbnz	w0, 3308 <sbrkfail+0x148>
    a = sbrk(0);
    32c4:	94000511 	bl	4708 <sbrk>
    32c8:	aa0003f4 	mov	x20, x0
    sbrk(10*BIG);
    32cc:	52a7d000 	mov	w0, #0x3e800000            	// #1048576000
    32d0:	9400050e 	bl	4708 <sbrk>
    32d4:	d2800000 	mov	x0, #0x0                   	// #0
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    32d8:	d2a7d001 	mov	x1, #0x3e800000            	// #1048576000
      n += *(a+i);
    32dc:	38606a83 	ldrb	w3, [x20, x0]
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    32e0:	91400400 	add	x0, x0, #0x1, lsl #12
      n += *(a+i);
    32e4:	0b0302b5 	add	w21, w21, w3
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    32e8:	eb01001f 	cmp	x0, x1
    32ec:	54ffff81 	b.ne	32dc <sbrkfail+0x11c>  // b.any
    printf("%s: allocate a lot of memory succeeded %d\n", s, n);
    32f0:	2a1503e2 	mov	w2, w21
    32f4:	aa1303e1 	mov	x1, x19
    32f8:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    32fc:	91196000 	add	x0, x0, #0x658
    3300:	940006ab 	bl	4dac <printf>
    exit(1);
    3304:	17ffffcc 	b	3234 <sbrkfail+0x74>
  wait(&xstatus);
    3308:	9100f3e0 	add	x0, sp, #0x3c
    330c:	940004cf 	bl	4648 <wait>
  if(xstatus != -1 && xstatus != 2)
    3310:	b9403fe0 	ldr	w0, [sp, #60]
    3314:	7100081f 	cmp	w0, #0x2
    3318:	3a411804 	ccmn	w0, #0x1, #0x4, ne	// ne = any
    331c:	54fff8c1 	b.ne	3234 <sbrkfail+0x74>  // b.any
}
    3320:	a94153f3 	ldp	x19, x20, [sp, #16]
    3324:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3328:	a8c77bfd 	ldp	x29, x30, [sp], #112
    332c:	d65f03c0 	ret

0000000000003330 <mem>:
{
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	aa0003f4 	mov	x20, x0
    3340:	f90013f5 	str	x21, [sp, #32]
  if((pid = fork()) == 0){
    3344:	940004bb 	bl	4630 <fork>
    3348:	340002c0 	cbz	w0, 33a0 <mem+0x70>
    wait(&xstatus);
    334c:	9100f3e0 	add	x0, sp, #0x3c
    3350:	940004be 	bl	4648 <wait>
    if(xstatus == -1){
    3354:	b9403fe0 	ldr	w0, [sp, #60]
    3358:	3100041f 	cmn	w0, #0x1
    335c:	54000201 	b.ne	339c <mem+0x6c>  // b.any
    3360:	14000018 	b	33c0 <mem+0x90>
      *(char**)m2 = m1;
    3364:	f9000013 	str	x19, [x0]
      m1 = m2;
    3368:	aa0003f3 	mov	x19, x0
    while((m2 = malloc(10001)) != 0){
    336c:	5284e220 	mov	w0, #0x2711                	// #10001
    3370:	940006eb 	bl	4f1c <malloc>
    3374:	b5ffff80 	cbnz	x0, 3364 <mem+0x34>
    while(m1){
    3378:	b5000193 	cbnz	x19, 33a8 <mem+0x78>
    m1 = malloc(1024*20);
    337c:	528a0000 	mov	w0, #0x5000                	// #20480
    3380:	940006e7 	bl	4f1c <malloc>
    if(m1 == 0){
    3384:	b50001c0 	cbnz	x0, 33bc <mem+0x8c>
      printf("couldn't allocate mem?!!\n", s);
    3388:	aa1403e1 	mov	x1, x20
    338c:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3390:	911a0c00 	add	x0, x0, #0x683
    3394:	94000686 	bl	4dac <printf>
      exit(1);
    3398:	52800020 	mov	w0, #0x1                   	// #1
    exit(0);
    339c:	940004a8 	bl	463c <exit>
    m1 = 0;
    33a0:	d2800013 	mov	x19, #0x0                   	// #0
    33a4:	17fffff2 	b	336c <mem+0x3c>
      m2 = *(char**)m1;
    33a8:	f9400275 	ldr	x21, [x19]
      free(m1);
    33ac:	aa1303e0 	mov	x0, x19
    33b0:	940006cc 	bl	4ee0 <free>
      m1 = m2;
    33b4:	aa1503f3 	mov	x19, x21
    33b8:	17fffff0 	b	3378 <mem+0x48>
    free(m1);
    33bc:	940006c9 	bl	4ee0 <free>
    exit(0);
    33c0:	52800000 	mov	w0, #0x0                   	// #0
    33c4:	17fffff6 	b	339c <mem+0x6c>

00000000000033c8 <sharedfd>:
{
    33c8:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    33cc:	910003fd 	mov	x29, sp
    33d0:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("sharedfd");
    33d4:	f0000013 	adrp	x19, 6000 <malloc+0x10e4>
    33d8:	911a7673 	add	x19, x19, #0x69d
{
    33dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    33e0:	aa0003f5 	mov	x21, x0
  unlink("sharedfd");
    33e4:	aa1303e0 	mov	x0, x19
{
    33e8:	a90363f7 	stp	x23, x24, [sp, #48]
  unlink("sharedfd");
    33ec:	940004b2 	bl	46b4 <unlink>
  fd = open("sharedfd", O_CREATE|O_RDWR);
    33f0:	aa1303e0 	mov	x0, x19
    33f4:	52804041 	mov	w1, #0x202                 	// #514
    33f8:	940004a9 	bl	469c <open>
  if(fd < 0){
    33fc:	36f800e0 	tbz	w0, #31, 3418 <sharedfd+0x50>
    printf("%s: cannot open sharedfd for writing", s);
    3400:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3404:	911a9800 	add	x0, x0, #0x6a6
      printf("%s: write sharedfd failed\n", s);
    3408:	aa1503e1 	mov	x1, x21
    340c:	94000668 	bl	4dac <printf>
      exit(1);
    3410:	52800020 	mov	w0, #0x1                   	// #1
    3414:	9400048a 	bl	463c <exit>
    3418:	2a0003f7 	mov	w23, w0
  pid = fork();
    341c:	94000485 	bl	4630 <fork>
  memset(buf, pid==0?'c':'p', sizeof(buf));
    3420:	7100001f 	cmp	w0, #0x0
    3424:	52807d14 	mov	w20, #0x3e8                 	// #1000
  pid = fork();
    3428:	2a0003f8 	mov	w24, w0
  memset(buf, pid==0?'c':'p', sizeof(buf));
    342c:	910143f6 	add	x22, sp, #0x50
    3430:	52800c60 	mov	w0, #0x63                  	// #99
    3434:	52800142 	mov	w2, #0xa                   	// #10
    3438:	52800e01 	mov	w1, #0x70                  	// #112
    343c:	1a801021 	csel	w1, w1, w0, ne	// ne = any
    3440:	aa1603e0 	mov	x0, x22
    3444:	94000405 	bl	4458 <memset>
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)){
    3448:	aa1603e1 	mov	x1, x22
    344c:	2a1703e0 	mov	w0, w23
    3450:	52800142 	mov	w2, #0xa                   	// #10
    3454:	94000486 	bl	466c <write>
    3458:	7100281f 	cmp	w0, #0xa
    345c:	54000080 	b.eq	346c <sharedfd+0xa4>  // b.none
      printf("%s: write sharedfd failed\n", s);
    3460:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3464:	911b2c00 	add	x0, x0, #0x6cb
    3468:	17ffffe8 	b	3408 <sharedfd+0x40>
  for(i = 0; i < N; i++){
    346c:	71000694 	subs	w20, w20, #0x1
    3470:	54fffec1 	b.ne	3448 <sharedfd+0x80>  // b.any
  if(pid == 0) {
    3474:	35000078 	cbnz	w24, 3480 <sharedfd+0xb8>
    exit(0);
    3478:	52800000 	mov	w0, #0x0                   	// #0
    347c:	17ffffe6 	b	3414 <sharedfd+0x4c>
    wait(&xstatus);
    3480:	910133e0 	add	x0, sp, #0x4c
    3484:	94000471 	bl	4648 <wait>
    if(xstatus != 0)
    3488:	b9404ff4 	ldr	w20, [sp, #76]
    348c:	34000074 	cbz	w20, 3498 <sharedfd+0xd0>
      exit(xstatus);
    3490:	2a1403e0 	mov	w0, w20
    3494:	17ffffe0 	b	3414 <sharedfd+0x4c>
  close(fd);
    3498:	2a1703e0 	mov	w0, w23
    349c:	94000477 	bl	4678 <close>
  fd = open("sharedfd", 0);
    34a0:	aa1303e0 	mov	x0, x19
    34a4:	52800001 	mov	w1, #0x0                   	// #0
    34a8:	9400047d 	bl	469c <open>
    34ac:	2a0003f8 	mov	w24, w0
  if(fd < 0){
    34b0:	36f80400 	tbz	w0, #31, 3530 <sharedfd+0x168>
    printf("%s: cannot open sharedfd for reading\n", s);
    34b4:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    34b8:	911b9800 	add	x0, x0, #0x6e6
    34bc:	17ffffd3 	b	3408 <sharedfd+0x40>
  while((n = read(fd, buf, sizeof(buf))) > 0){
    34c0:	d2800000 	mov	x0, #0x0                   	// #0
      if(buf[i] == 'c')
    34c4:	38606ac1 	ldrb	w1, [x22, x0]
    34c8:	71018c3f 	cmp	w1, #0x63
    34cc:	540002c1 	b.ne	3524 <sharedfd+0x15c>  // b.any
        nc++;
    34d0:	11000694 	add	w20, w20, #0x1
    for(i = 0; i < sizeof(buf); i++){
    34d4:	91000400 	add	x0, x0, #0x1
    34d8:	f100281f 	cmp	x0, #0xa
    34dc:	54ffff41 	b.ne	34c4 <sharedfd+0xfc>  // b.any
  while((n = read(fd, buf, sizeof(buf))) > 0){
    34e0:	aa1603e1 	mov	x1, x22
    34e4:	2a1803e0 	mov	w0, w24
    34e8:	52800142 	mov	w2, #0xa                   	// #10
    34ec:	9400045d 	bl	4660 <read>
    34f0:	7100001f 	cmp	w0, #0x0
    34f4:	54fffe6c 	b.gt	34c0 <sharedfd+0xf8>
  close(fd);
    34f8:	2a1803e0 	mov	w0, w24
    34fc:	9400045f 	bl	4678 <close>
  unlink("sharedfd");
    3500:	aa1303e0 	mov	x0, x19
    3504:	9400046c 	bl	46b4 <unlink>
  if(nc == N*SZ && np == N*SZ){
    3508:	5284e200 	mov	w0, #0x2710                	// #10000
    350c:	6b00029f 	cmp	w20, w0
    3510:	7a4002e0 	ccmp	w23, w0, #0x0, eq	// eq = none
    3514:	54fffb20 	b.eq	3478 <sharedfd+0xb0>  // b.none
    printf("%s: nc/np test fails\n", s);
    3518:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    351c:	911c3000 	add	x0, x0, #0x70c
    3520:	17ffffba 	b	3408 <sharedfd+0x40>
        np++;
    3524:	7101c03f 	cmp	w1, #0x70
    3528:	1a9716f7 	cinc	w23, w23, eq	// eq = none
    352c:	17ffffea 	b	34d4 <sharedfd+0x10c>
  nc = np = 0;
    3530:	52800017 	mov	w23, #0x0                   	// #0
    3534:	17ffffeb 	b	34e0 <sharedfd+0x118>

0000000000003538 <fourfiles>:
{
    3538:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    353c:	910003fd 	mov	x29, sp
    3540:	a9025bf5 	stp	x21, x22, [sp, #32]
    3544:	aa0003f6 	mov	x22, x0
  char *names[] = { "f0", "f1", "f2", "f3" };
    3548:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    354c:	911c8800 	add	x0, x0, #0x722
    3550:	f9003be0 	str	x0, [sp, #112]
    3554:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3558:	91101000 	add	x0, x0, #0x404
{
    355c:	a90363f7 	stp	x23, x24, [sp, #48]
    fname = names[pi];
    3560:	9101c3f8 	add	x24, sp, #0x70
  char *names[] = { "f0", "f1", "f2", "f3" };
    3564:	f9003fe0 	str	x0, [sp, #120]
    3568:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    356c:	91102000 	add	x0, x0, #0x408
{
    3570:	a90153f3 	stp	x19, x20, [sp, #16]
  char *names[] = { "f0", "f1", "f2", "f3" };
    3574:	d2800013 	mov	x19, #0x0                   	// #0
{
    3578:	a9046bf9 	stp	x25, x26, [sp, #64]
    357c:	f9002bfb 	str	x27, [sp, #80]
  char *names[] = { "f0", "f1", "f2", "f3" };
    3580:	f90043e0 	str	x0, [sp, #128]
    3584:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3588:	911c9400 	add	x0, x0, #0x725
    358c:	f90047e0 	str	x0, [sp, #136]
    fname = names[pi];
    3590:	f8737b14 	ldr	x20, [x24, x19, lsl #3]
    unlink(fname);
    3594:	aa1403e0 	mov	x0, x20
    3598:	94000447 	bl	46b4 <unlink>
    pid = fork();
    359c:	94000425 	bl	4630 <fork>
    if(pid < 0){
    35a0:	36f800e0 	tbz	w0, #31, 35bc <fourfiles+0x84>
      printf("fork failed\n", s);
    35a4:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    35a8:	9117b400 	add	x0, x0, #0x5ed
        printf("create failed\n", s);
    35ac:	aa1603e1 	mov	x1, x22
    35b0:	940005ff 	bl	4dac <printf>
        exit(1);
    35b4:	52800020 	mov	w0, #0x1                   	// #1
    35b8:	94000421 	bl	463c <exit>
    if(pid == 0){
    35bc:	350003e0 	cbnz	w0, 3638 <fourfiles+0x100>
      fd = open(fname, O_CREATE | O_RDWR);
    35c0:	aa1403e0 	mov	x0, x20
    35c4:	52804041 	mov	w1, #0x202                 	// #514
    35c8:	94000435 	bl	469c <open>
    35cc:	2a0003f5 	mov	w21, w0
      if(fd < 0){
    35d0:	36f80080 	tbz	w0, #31, 35e0 <fourfiles+0xa8>
        printf("create failed\n", s);
    35d4:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    35d8:	91198c00 	add	x0, x0, #0x663
    35dc:	17fffff4 	b	35ac <fourfiles+0x74>
      memset(buf, '0'+pi, SZ);
    35e0:	1100c261 	add	w1, w19, #0x30
    35e4:	52800193 	mov	w19, #0xc                   	// #12
    35e8:	f0000034 	adrp	x20, a000 <uninit+0x1cb7>
    35ec:	91296694 	add	x20, x20, #0xa59
    35f0:	aa1403e0 	mov	x0, x20
    35f4:	52803e82 	mov	w2, #0x1f4                 	// #500
    35f8:	94000398 	bl	4458 <memset>
        if((n = write(fd, buf, SZ)) != SZ){
    35fc:	aa1403e1 	mov	x1, x20
    3600:	2a1503e0 	mov	w0, w21
    3604:	52803e82 	mov	w2, #0x1f4                 	// #500
    3608:	94000419 	bl	466c <write>
    360c:	2a0003e1 	mov	w1, w0
    3610:	7107d01f 	cmp	w0, #0x1f4
    3614:	540000a0 	b.eq	3628 <fourfiles+0xf0>  // b.none
          printf("write failed %d\n", n);
    3618:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    361c:	911ca000 	add	x0, x0, #0x728
      printf("wrong length %d\n", total);
    3620:	940005e3 	bl	4dac <printf>
      exit(1);
    3624:	17ffffe4 	b	35b4 <fourfiles+0x7c>
      for(i = 0; i < N; i++){
    3628:	71000673 	subs	w19, w19, #0x1
    362c:	54fffe81 	b.ne	35fc <fourfiles+0xc4>  // b.any
      exit(0);
    3630:	52800000 	mov	w0, #0x0                   	// #0
    3634:	17ffffe1 	b	35b8 <fourfiles+0x80>
  for(pi = 0; pi < NCHILD; pi++){
    3638:	91000673 	add	x19, x19, #0x1
    363c:	f100127f 	cmp	x19, #0x4
    3640:	54fffa81 	b.ne	3590 <fourfiles+0x58>  // b.any
    wait(&xstatus);
    3644:	9101b3e0 	add	x0, sp, #0x6c
    3648:	94000400 	bl	4648 <wait>
    if(xstatus != 0)
    364c:	b9406fe0 	ldr	w0, [sp, #108]
    3650:	35fffb40 	cbnz	w0, 35b8 <fourfiles+0x80>
  for(pi = 0; pi < NCHILD; pi++){
    3654:	71000673 	subs	w19, w19, #0x1
    3658:	54ffff61 	b.ne	3644 <fourfiles+0x10c>  // b.any
    while((n = read(fd, buf, sizeof(buf))) > 0){
    365c:	f0000034 	adrp	x20, a000 <uninit+0x1cb7>
    3660:	91296694 	add	x20, x20, #0xa59
  for(pi = 0; pi < NCHILD; pi++){
    3664:	d2800013 	mov	x19, #0x0                   	// #0
    if(total != N*SZ){
    3668:	5282ee1a 	mov	w26, #0x1770                	// #6000
    fname = names[i];
    366c:	f8737b17 	ldr	x23, [x24, x19, lsl #3]
    fd = open(fname, 0);
    3670:	52800001 	mov	w1, #0x0                   	// #0
        if(buf[j] != '0'+i){
    3674:	1100c27b 	add	w27, w19, #0x30
    total = 0;
    3678:	52800015 	mov	w21, #0x0                   	// #0
    fd = open(fname, 0);
    367c:	aa1703e0 	mov	x0, x23
    3680:	94000407 	bl	469c <open>
    3684:	2a0003f9 	mov	w25, w0
    while((n = read(fd, buf, sizeof(buf))) > 0){
    3688:	aa1403e1 	mov	x1, x20
    368c:	2a1903e0 	mov	w0, w25
    3690:	52860002 	mov	w2, #0x3000                	// #12288
    3694:	940003f3 	bl	4660 <read>
    3698:	7100001f 	cmp	w0, #0x0
    369c:	5400012c 	b.gt	36c0 <fourfiles+0x188>
    close(fd);
    36a0:	2a1903e0 	mov	w0, w25
    36a4:	940003f5 	bl	4678 <close>
    if(total != N*SZ){
    36a8:	6b1a02bf 	cmp	w21, w26
    36ac:	54000220 	b.eq	36f0 <fourfiles+0x1b8>  // b.none
      printf("wrong length %d\n", total);
    36b0:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    36b4:	911d1400 	add	x0, x0, #0x745
    36b8:	2a1503e1 	mov	w1, w21
    36bc:	17ffffd9 	b	3620 <fourfiles+0xe8>
    while((n = read(fd, buf, sizeof(buf))) > 0){
    36c0:	d2800001 	mov	x1, #0x0                   	// #0
        if(buf[j] != '0'+i){
    36c4:	38616a82 	ldrb	w2, [x20, x1]
    36c8:	6b1b005f 	cmp	w2, w27
    36cc:	54000080 	b.eq	36dc <fourfiles+0x1a4>  // b.none
          printf("wrong char\n", s);
    36d0:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    36d4:	911ce400 	add	x0, x0, #0x739
    36d8:	17ffffb5 	b	35ac <fourfiles+0x74>
      for(j = 0; j < n; j++){
    36dc:	91000421 	add	x1, x1, #0x1
    36e0:	6b01001f 	cmp	w0, w1
    36e4:	54ffff0c 	b.gt	36c4 <fourfiles+0x18c>
      total += n;
    36e8:	0b0002b5 	add	w21, w21, w0
    36ec:	17ffffe7 	b	3688 <fourfiles+0x150>
    unlink(fname);
    36f0:	aa1703e0 	mov	x0, x23
  for(i = 0; i < NCHILD; i++){
    36f4:	91000673 	add	x19, x19, #0x1
    unlink(fname);
    36f8:	940003ef 	bl	46b4 <unlink>
  for(i = 0; i < NCHILD; i++){
    36fc:	f100127f 	cmp	x19, #0x4
    3700:	54fffb61 	b.ne	366c <fourfiles+0x134>  // b.any
}
    3704:	f9402bfb 	ldr	x27, [sp, #80]
    3708:	a94153f3 	ldp	x19, x20, [sp, #16]
    370c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3710:	a94363f7 	ldp	x23, x24, [sp, #48]
    3714:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3718:	a8c97bfd 	ldp	x29, x30, [sp], #144
    371c:	d65f03c0 	ret

0000000000003720 <concreate>:
{
    3720:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    3724:	910003fd 	mov	x29, sp
    3728:	a9025bf5 	stp	x21, x22, [sp, #32]
      link("C0", file);
    372c:	f0000016 	adrp	x22, 6000 <malloc+0x10e4>
    3730:	911d5ad6 	add	x22, x22, #0x756
{
    3734:	aa0003f5 	mov	x21, x0
  file[0] = 'C';
    3738:	52800860 	mov	w0, #0x43                  	// #67
{
    373c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(i = 0; i < N; i++){
    3740:	52800013 	mov	w19, #0x0                   	// #0
{
    3744:	a90363f7 	stp	x23, x24, [sp, #48]
      link("C0", file);
    3748:	528000b7 	mov	w23, #0x5                   	// #5
  file[0] = 'C';
    374c:	390103e0 	strb	w0, [sp, #64]
  file[2] = '\0';
    3750:	39010bff 	strb	wzr, [sp, #66]
    file[1] = '0' + i;
    3754:	1100c260 	add	w0, w19, #0x30
    3758:	390107e0 	strb	w0, [sp, #65]
    unlink(file);
    375c:	910103e0 	add	x0, sp, #0x40
    3760:	940003d5 	bl	46b4 <unlink>
    pid = fork();
    3764:	940003b3 	bl	4630 <fork>
    3768:	2a0003f4 	mov	w20, w0
    if(pid && (i % 3) == 1){
    376c:	34000220 	cbz	w0, 37b0 <concreate+0x90>
    3770:	52800061 	mov	w1, #0x3                   	// #3
    3774:	1ac10e61 	sdiv	w1, w19, w1
    3778:	0b010421 	add	w1, w1, w1, lsl #1
    377c:	4b010261 	sub	w1, w19, w1
    3780:	7100043f 	cmp	w1, #0x1
    3784:	540002c1 	b.ne	37dc <concreate+0xbc>  // b.any
      link("C0", file);
    3788:	910103e1 	add	x1, sp, #0x40
    378c:	aa1603e0 	mov	x0, x22
    3790:	940003cf 	bl	46cc <link>
      wait(&xstatus);
    3794:	9101a3f8 	add	x24, sp, #0x68
    3798:	aa1803e0 	mov	x0, x24
    379c:	940003ab 	bl	4648 <wait>
      if(xstatus != 0)
    37a0:	b9406bf4 	ldr	w20, [sp, #104]
    37a4:	34000354 	cbz	w20, 380c <concreate+0xec>
      exit(1);
    37a8:	52800020 	mov	w0, #0x1                   	// #1
    37ac:	1400000b 	b	37d8 <concreate+0xb8>
      link("C0", file);
    37b0:	1ad70e61 	sdiv	w1, w19, w23
    37b4:	0b010821 	add	w1, w1, w1, lsl #2
    37b8:	4b010261 	sub	w1, w19, w1
    } else if(pid == 0 && (i % 5) == 1){
    37bc:	7100043f 	cmp	w1, #0x1
    37c0:	540000e1 	b.ne	37dc <concreate+0xbc>  // b.any
      link("C0", file);
    37c4:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    37c8:	911d5800 	add	x0, x0, #0x756
    37cc:	910103e1 	add	x1, sp, #0x40
    37d0:	940003bf 	bl	46cc <link>
      exit(0);
    37d4:	52800000 	mov	w0, #0x0                   	// #0
    37d8:	94000399 	bl	463c <exit>
      fd = open(file, O_CREATE | O_RDWR);
    37dc:	910103e0 	add	x0, sp, #0x40
    37e0:	52804041 	mov	w1, #0x202                 	// #514
    37e4:	940003ae 	bl	469c <open>
      if(fd < 0){
    37e8:	36f800c0 	tbz	w0, #31, 3800 <concreate+0xe0>
        printf("concreate create %s failed\n", file);
    37ec:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    37f0:	911d6400 	add	x0, x0, #0x759
    37f4:	910103e1 	add	x1, sp, #0x40
      printf("%s: fork failed\n", s);
    37f8:	9400056d 	bl	4dac <printf>
    37fc:	17ffffeb 	b	37a8 <concreate+0x88>
      close(fd);
    3800:	9400039e 	bl	4678 <close>
    if(pid == 0) {
    3804:	35fffc94 	cbnz	w20, 3794 <concreate+0x74>
    3808:	17fffff3 	b	37d4 <concreate+0xb4>
  for(i = 0; i < N; i++){
    380c:	11000673 	add	w19, w19, #0x1
    3810:	7100a27f 	cmp	w19, #0x28
    3814:	54fffa01 	b.ne	3754 <concreate+0x34>  // b.any
  memset(fa, 0, sizeof(fa));
    3818:	2a1303e2 	mov	w2, w19
    381c:	52800001 	mov	w1, #0x0                   	// #0
    3820:	aa1803e0 	mov	x0, x24
    3824:	9400030d 	bl	4458 <memset>
  fd = open(".", 0);
    3828:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    382c:	91024000 	add	x0, x0, #0x90
    3830:	52800001 	mov	w1, #0x0                   	// #0
    3834:	9400039a 	bl	469c <open>
    3838:	2a0003f6 	mov	w22, w0
  n = 0;
    383c:	52800013 	mov	w19, #0x0                   	// #0
      fa[i] = 1;
    3840:	52800037 	mov	w23, #0x1                   	// #1
  while(read(fd, &de, sizeof(de)) > 0){
    3844:	910123e1 	add	x1, sp, #0x48
    3848:	2a1603e0 	mov	w0, w22
    384c:	52800402 	mov	w2, #0x20                  	// #32
    3850:	94000384 	bl	4660 <read>
    3854:	7100001f 	cmp	w0, #0x0
    3858:	540001cc 	b.gt	3890 <concreate+0x170>
  close(fd);
    385c:	2a1603e0 	mov	w0, w22
    3860:	94000386 	bl	4678 <close>
  if(n != N){
    3864:	7100a27f 	cmp	w19, #0x28
    3868:	54000481 	b.ne	38f8 <concreate+0x1d8>  // b.any
    if(((i % 3) == 0 && pid == 0) ||
    386c:	52800076 	mov	w22, #0x3                   	// #3
    file[1] = '0' + i;
    3870:	1100c280 	add	w0, w20, #0x30
    3874:	390107e0 	strb	w0, [sp, #65]
    pid = fork();
    3878:	9400036e 	bl	4630 <fork>
    387c:	2a0003f3 	mov	w19, w0
    if(pid < 0){
    3880:	36f80440 	tbz	w0, #31, 3908 <concreate+0x1e8>
      printf("%s: fork failed\n", s);
    3884:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3888:	9117a400 	add	x0, x0, #0x5e9
    388c:	1400001d 	b	3900 <concreate+0x1e0>
    if(de.inum == 0)
    3890:	794093e0 	ldrh	w0, [sp, #72]
    3894:	34fffd80 	cbz	w0, 3844 <concreate+0x124>
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    3898:	39412be0 	ldrb	w0, [sp, #74]
    389c:	71010c1f 	cmp	w0, #0x43
    38a0:	54fffd21 	b.ne	3844 <concreate+0x124>  // b.any
    38a4:	394133e0 	ldrb	w0, [sp, #76]
    38a8:	35fffce0 	cbnz	w0, 3844 <concreate+0x124>
      i = de.name[1] - '0';
    38ac:	39412fe0 	ldrb	w0, [sp, #75]
    38b0:	5100c000 	sub	w0, w0, #0x30
      if(i < 0 || i >= sizeof(fa)){
    38b4:	71009c1f 	cmp	w0, #0x27
    38b8:	540000e9 	b.ls	38d4 <concreate+0x1b4>  // b.plast
        printf("%s: concreate weird file %s\n", s, de.name);
    38bc:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    38c0:	911dd400 	add	x0, x0, #0x775
        printf("%s: concreate duplicate file %s\n", s, de.name);
    38c4:	91012be2 	add	x2, sp, #0x4a
    38c8:	aa1503e1 	mov	x1, x21
    38cc:	94000538 	bl	4dac <printf>
        exit(1);
    38d0:	17ffffb6 	b	37a8 <concreate+0x88>
      if(fa[i]){
    38d4:	2a0003e1 	mov	w1, w0
    38d8:	38604b00 	ldrb	w0, [x24, w0, uxtw]
    38dc:	34000080 	cbz	w0, 38ec <concreate+0x1cc>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    38e0:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    38e4:	911e4800 	add	x0, x0, #0x792
    38e8:	17fffff7 	b	38c4 <concreate+0x1a4>
      n++;
    38ec:	11000673 	add	w19, w19, #0x1
      fa[i] = 1;
    38f0:	38216b17 	strb	w23, [x24, x1]
      n++;
    38f4:	17ffffd4 	b	3844 <concreate+0x124>
    printf("%s: concreate not enough files in directory listing\n", s);
    38f8:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    38fc:	911ecc00 	add	x0, x0, #0x7b3
      printf("%s: fork failed\n", s);
    3900:	aa1503e1 	mov	x1, x21
    3904:	17ffffbd 	b	37f8 <concreate+0xd8>
    if(((i % 3) == 0 && pid == 0) ||
    3908:	1ad60a80 	udiv	w0, w20, w22
    390c:	0b000400 	add	w0, w0, w0, lsl #1
    3910:	4b000280 	sub	w0, w20, w0
    3914:	2a130001 	orr	w1, w0, w19
    3918:	34000081 	cbz	w1, 3928 <concreate+0x208>
    391c:	7100041f 	cmp	w0, #0x1
    3920:	540004a1 	b.ne	39b4 <concreate+0x294>  // b.any
       ((i % 3) == 1 && pid != 0)){
    3924:	34000493 	cbz	w19, 39b4 <concreate+0x294>
      close(open(file, 0));
    3928:	52800001 	mov	w1, #0x0                   	// #0
    392c:	910103e0 	add	x0, sp, #0x40
    3930:	9400035b 	bl	469c <open>
    3934:	94000351 	bl	4678 <close>
      close(open(file, 0));
    3938:	52800001 	mov	w1, #0x0                   	// #0
    393c:	910103e0 	add	x0, sp, #0x40
    3940:	94000357 	bl	469c <open>
    3944:	9400034d 	bl	4678 <close>
      close(open(file, 0));
    3948:	52800001 	mov	w1, #0x0                   	// #0
    394c:	910103e0 	add	x0, sp, #0x40
    3950:	94000353 	bl	469c <open>
    3954:	94000349 	bl	4678 <close>
      close(open(file, 0));
    3958:	52800001 	mov	w1, #0x0                   	// #0
    395c:	910103e0 	add	x0, sp, #0x40
    3960:	9400034f 	bl	469c <open>
    3964:	94000345 	bl	4678 <close>
      close(open(file, 0));
    3968:	52800001 	mov	w1, #0x0                   	// #0
    396c:	910103e0 	add	x0, sp, #0x40
    3970:	9400034b 	bl	469c <open>
    3974:	94000341 	bl	4678 <close>
      close(open(file, 0));
    3978:	52800001 	mov	w1, #0x0                   	// #0
    397c:	910103e0 	add	x0, sp, #0x40
    3980:	94000347 	bl	469c <open>
    3984:	9400033d 	bl	4678 <close>
    if(pid == 0)
    3988:	34fff273 	cbz	w19, 37d4 <concreate+0xb4>
      wait(0);
    398c:	d2800000 	mov	x0, #0x0                   	// #0
  for(i = 0; i < N; i++){
    3990:	11000694 	add	w20, w20, #0x1
      wait(0);
    3994:	9400032d 	bl	4648 <wait>
  for(i = 0; i < N; i++){
    3998:	7100a29f 	cmp	w20, #0x28
    399c:	54fff6a1 	b.ne	3870 <concreate+0x150>  // b.any
}
    39a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    39a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    39a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    39ac:	a8c97bfd 	ldp	x29, x30, [sp], #144
    39b0:	d65f03c0 	ret
      unlink(file);
    39b4:	910103e0 	add	x0, sp, #0x40
    39b8:	9400033f 	bl	46b4 <unlink>
      unlink(file);
    39bc:	910103e0 	add	x0, sp, #0x40
    39c0:	9400033d 	bl	46b4 <unlink>
      unlink(file);
    39c4:	910103e0 	add	x0, sp, #0x40
    39c8:	9400033b 	bl	46b4 <unlink>
      unlink(file);
    39cc:	910103e0 	add	x0, sp, #0x40
    39d0:	94000339 	bl	46b4 <unlink>
      unlink(file);
    39d4:	910103e0 	add	x0, sp, #0x40
    39d8:	94000337 	bl	46b4 <unlink>
      unlink(file);
    39dc:	910103e0 	add	x0, sp, #0x40
    39e0:	94000335 	bl	46b4 <unlink>
    39e4:	17ffffe9 	b	3988 <concreate+0x268>

00000000000039e8 <bigfile>:
{
    39e8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    39ec:	910003fd 	mov	x29, sp
    39f0:	a9025bf5 	stp	x21, x22, [sp, #32]
  unlink("bigfile.dat");
    39f4:	f0000015 	adrp	x21, 6000 <malloc+0x10e4>
    39f8:	911fa2b5 	add	x21, x21, #0x7e8
{
    39fc:	a90153f3 	stp	x19, x20, [sp, #16]
    3a00:	aa0003f3 	mov	x19, x0
  unlink("bigfile.dat");
    3a04:	aa1503e0 	mov	x0, x21
{
    3a08:	f9001bf7 	str	x23, [sp, #48]
  unlink("bigfile.dat");
    3a0c:	9400032a 	bl	46b4 <unlink>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    3a10:	aa1503e0 	mov	x0, x21
    3a14:	52804041 	mov	w1, #0x202                 	// #514
    3a18:	94000321 	bl	469c <open>
  if(fd < 0){
    3a1c:	37f80240 	tbnz	w0, #31, 3a64 <bigfile+0x7c>
    memset(buf, i, SZ);
    3a20:	f0000034 	adrp	x20, a000 <uninit+0x1cb7>
    3a24:	91296694 	add	x20, x20, #0xa59
    3a28:	2a0003f7 	mov	w23, w0
    3a2c:	52800016 	mov	w22, #0x0                   	// #0
    3a30:	2a1603e1 	mov	w1, w22
    3a34:	52804b02 	mov	w2, #0x258                 	// #600
    3a38:	aa1403e0 	mov	x0, x20
    3a3c:	94000287 	bl	4458 <memset>
    if(write(fd, buf, SZ) != SZ){
    3a40:	aa1403e1 	mov	x1, x20
    3a44:	2a1703e0 	mov	w0, w23
    3a48:	52804b02 	mov	w2, #0x258                 	// #600
    3a4c:	94000308 	bl	466c <write>
    3a50:	7109601f 	cmp	w0, #0x258
    3a54:	54000140 	b.eq	3a7c <bigfile+0x94>  // b.none
      printf("%s: write bigfile failed\n", s);
    3a58:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3a5c:	91203800 	add	x0, x0, #0x80e
    3a60:	14000003 	b	3a6c <bigfile+0x84>
    printf("%s: cannot create bigfile", s);
    3a64:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3a68:	911fd000 	add	x0, x0, #0x7f4
      printf("%s: write bigfile failed\n", s);
    3a6c:	aa1303e1 	mov	x1, x19
    3a70:	940004cf 	bl	4dac <printf>
      exit(1);
    3a74:	52800020 	mov	w0, #0x1                   	// #1
    3a78:	940002f1 	bl	463c <exit>
  for(i = 0; i < N; i++){
    3a7c:	110006d6 	add	w22, w22, #0x1
    3a80:	710052df 	cmp	w22, #0x14
    3a84:	54fffd61 	b.ne	3a30 <bigfile+0x48>  // b.any
  close(fd);
    3a88:	2a1703e0 	mov	w0, w23
    3a8c:	940002fb 	bl	4678 <close>
  fd = open("bigfile.dat", 0);
    3a90:	aa1503e0 	mov	x0, x21
    3a94:	52800001 	mov	w1, #0x0                   	// #0
  for(i = 0; ; i++){
    3a98:	52800016 	mov	w22, #0x0                   	// #0
  fd = open("bigfile.dat", 0);
    3a9c:	94000300 	bl	469c <open>
    3aa0:	2a0003f7 	mov	w23, w0
  if(fd < 0){
    3aa4:	36f80280 	tbz	w0, #31, 3af4 <bigfile+0x10c>
    printf("%s: cannot open bigfile\n", s);
    3aa8:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3aac:	9120a000 	add	x0, x0, #0x828
    3ab0:	17ffffef 	b	3a6c <bigfile+0x84>
    if(cc == 0)
    3ab4:	34000300 	cbz	w0, 3b14 <bigfile+0x12c>
    if(cc != SZ/2){
    3ab8:	7104b01f 	cmp	w0, #0x12c
    3abc:	54000080 	b.eq	3acc <bigfile+0xe4>  // b.none
      printf("%s: short read bigfile\n", s);
    3ac0:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3ac4:	91216800 	add	x0, x0, #0x85a
    3ac8:	17ffffe9 	b	3a6c <bigfile+0x84>
    if(buf[0] != i/2 || buf[SZ/2-1] != i/2){
    3acc:	39400280 	ldrb	w0, [x20]
    3ad0:	6b96041f 	cmp	w0, w22, asr #1
    3ad4:	54000080 	b.eq	3ae4 <bigfile+0xfc>  // b.none
      printf("%s: read bigfile wrong data\n", s);
    3ad8:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3adc:	9121c800 	add	x0, x0, #0x872
    3ae0:	17ffffe3 	b	3a6c <bigfile+0x84>
    if(buf[0] != i/2 || buf[SZ/2-1] != i/2){
    3ae4:	3944ae81 	ldrb	w1, [x20, #299]
    3ae8:	6b01001f 	cmp	w0, w1
    3aec:	54ffff61 	b.ne	3ad8 <bigfile+0xf0>  // b.any
  for(i = 0; ; i++){
    3af0:	110006d6 	add	w22, w22, #0x1
    cc = read(fd, buf, SZ/2);
    3af4:	aa1403e1 	mov	x1, x20
    3af8:	2a1703e0 	mov	w0, w23
    3afc:	52802582 	mov	w2, #0x12c                 	// #300
    3b00:	940002d8 	bl	4660 <read>
    if(cc < 0){
    3b04:	36fffd80 	tbz	w0, #31, 3ab4 <bigfile+0xcc>
      printf("%s: read bigfile failed\n", s);
    3b08:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3b0c:	91210400 	add	x0, x0, #0x841
    3b10:	17ffffd7 	b	3a6c <bigfile+0x84>
  close(fd);
    3b14:	2a1703e0 	mov	w0, w23
    3b18:	940002d8 	bl	4678 <close>
  if(total != N*SZ){
    3b1c:	52802580 	mov	w0, #0x12c                 	// #300
    3b20:	1b007ed6 	mul	w22, w22, w0
    3b24:	5285dc00 	mov	w0, #0x2ee0                	// #12000
    3b28:	6b0002df 	cmp	w22, w0
    3b2c:	54000080 	b.eq	3b3c <bigfile+0x154>  // b.none
    printf("%s: read bigfile wrong total\n", s);
    3b30:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3b34:	91223c00 	add	x0, x0, #0x88f
    3b38:	17ffffcd 	b	3a6c <bigfile+0x84>
}
    3b3c:	f9401bf7 	ldr	x23, [sp, #48]
  unlink("bigfile.dat");
    3b40:	aa1503e0 	mov	x0, x21
}
    3b44:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b48:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3b4c:	a8c47bfd 	ldp	x29, x30, [sp], #64
  unlink("bigfile.dat");
    3b50:	140002d9 	b	46b4 <unlink>

0000000000003b54 <bsstest>:
    if(uninit[i] != '\0'){
    3b54:	b0000023 	adrp	x3, 8000 <big.0+0xcb8>
    3b58:	910d2463 	add	x3, x3, #0x349
{
    3b5c:	d2800002 	mov	x2, #0x0                   	// #0
  for(i = 0; i < sizeof(uninit); i++){
    3b60:	d284e201 	mov	x1, #0x2710                	// #10000
    if(uninit[i] != '\0'){
    3b64:	38626864 	ldrb	w4, [x3, x2]
    3b68:	34000124 	cbz	w4, 3b8c <bsstest+0x38>
{
    3b6c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b70:	aa0003e1 	mov	x1, x0
      printf("%s: bss test failed\n", s);
    3b74:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3b78:	9122b400 	add	x0, x0, #0x8ad
{
    3b7c:	910003fd 	mov	x29, sp
      printf("%s: bss test failed\n", s);
    3b80:	9400048b 	bl	4dac <printf>
      exit(1);
    3b84:	52800020 	mov	w0, #0x1                   	// #1
    3b88:	940002ad 	bl	463c <exit>
  for(i = 0; i < sizeof(uninit); i++){
    3b8c:	91000442 	add	x2, x2, #0x1
    3b90:	eb01005f 	cmp	x2, x1
    3b94:	54fffe81 	b.ne	3b64 <bsstest+0x10>  // b.any
    3b98:	d65f03c0 	ret

0000000000003b9c <opentest>:
{
    3b9c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  fd = open("echo", 0);
    3ba0:	52800001 	mov	w1, #0x0                   	// #0
{
    3ba4:	910003fd 	mov	x29, sp
    3ba8:	f9000bf3 	str	x19, [sp, #16]
    3bac:	aa0003f3 	mov	x19, x0
  fd = open("echo", 0);
    3bb0:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3bb4:	91144800 	add	x0, x0, #0x512
    3bb8:	940002b9 	bl	469c <open>
  if(fd < 0){
    3bbc:	36f800e0 	tbz	w0, #31, 3bd8 <opentest+0x3c>
    printf("%s: open echo failed!\n", s);
    3bc0:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3bc4:	91230800 	add	x0, x0, #0x8c2
    printf("%s: open doesnotexist succeeded!\n", s);
    3bc8:	aa1303e1 	mov	x1, x19
    3bcc:	94000478 	bl	4dac <printf>
    exit(1);
    3bd0:	52800020 	mov	w0, #0x1                   	// #1
    3bd4:	9400029a 	bl	463c <exit>
  close(fd);
    3bd8:	940002a8 	bl	4678 <close>
  fd = open("doesnotexist", 0);
    3bdc:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3be0:	91236400 	add	x0, x0, #0x8d9
    3be4:	52800001 	mov	w1, #0x0                   	// #0
    3be8:	940002ad 	bl	469c <open>
  if(fd >= 0){
    3bec:	37f80080 	tbnz	w0, #31, 3bfc <opentest+0x60>
    printf("%s: open doesnotexist succeeded!\n", s);
    3bf0:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3bf4:	91239800 	add	x0, x0, #0x8e6
    3bf8:	17fffff4 	b	3bc8 <opentest+0x2c>
}
    3bfc:	f9400bf3 	ldr	x19, [sp, #16]
    3c00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c04:	d65f03c0 	ret

0000000000003c08 <bigdir>:
{
    3c08:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3c0c:	910003fd 	mov	x29, sp
    3c10:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("bd");
    3c14:	f0000014 	adrp	x20, 6000 <malloc+0x10e4>
    3c18:	91242294 	add	x20, x20, #0x908
{
    3c1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3c20:	aa0003f6 	mov	x22, x0
  unlink("bd");
    3c24:	aa1403e0 	mov	x0, x20
{
    3c28:	f9001bf7 	str	x23, [sp, #48]
  unlink("bd");
    3c2c:	940002a2 	bl	46b4 <unlink>
  fd = open("bd", O_CREATE);
    3c30:	aa1403e0 	mov	x0, x20
    3c34:	52804001 	mov	w1, #0x200                 	// #512
    3c38:	94000299 	bl	469c <open>
  if(fd < 0){
    3c3c:	36f800c0 	tbz	w0, #31, 3c54 <bigdir+0x4c>
    printf("%s: bigdir create failed\n", s);
    3c40:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3c44:	91242c00 	add	x0, x0, #0x90b
      printf("%s: bigdir unlink failed", s);
    3c48:	aa1603e1 	mov	x1, x22
    3c4c:	94000458 	bl	4dac <printf>
      exit(1);
    3c50:	14000016 	b	3ca8 <bigdir+0xa0>
  for(i = 0; i < N; i++){
    3c54:	52800015 	mov	w21, #0x0                   	// #0
    name[0] = 'x';
    3c58:	52800f17 	mov	w23, #0x78                  	// #120
  close(fd);
    3c5c:	94000287 	bl	4678 <close>
    name[1] = '0' + (i / 64);
    3c60:	13067ea0 	asr	w0, w21, #6
    if(link("bd", name) != 0){
    3c64:	910103e1 	add	x1, sp, #0x40
    name[1] = '0' + (i / 64);
    3c68:	1100c000 	add	w0, w0, #0x30
    3c6c:	390107e0 	strb	w0, [sp, #65]
    name[2] = '0' + (i % 64);
    3c70:	120016a0 	and	w0, w21, #0x3f
    name[0] = 'x';
    3c74:	390103f7 	strb	w23, [sp, #64]
    name[2] = '0' + (i % 64);
    3c78:	1100c000 	add	w0, w0, #0x30
    3c7c:	39010be0 	strb	w0, [sp, #66]
    if(link("bd", name) != 0){
    3c80:	aa1403e0 	mov	x0, x20
    name[3] = '\0';
    3c84:	39010fff 	strb	wzr, [sp, #67]
    if(link("bd", name) != 0){
    3c88:	94000291 	bl	46cc <link>
    3c8c:	2a0003f3 	mov	w19, w0
    3c90:	34000100 	cbz	w0, 3cb0 <bigdir+0xa8>
      printf("%s: bigdir link(bd, %s) failed\n", s, name);
    3c94:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3c98:	91249400 	add	x0, x0, #0x925
    3c9c:	910103e2 	add	x2, sp, #0x40
    3ca0:	aa1603e1 	mov	x1, x22
    3ca4:	94000442 	bl	4dac <printf>
      exit(1);
    3ca8:	52800020 	mov	w0, #0x1                   	// #1
    3cac:	94000264 	bl	463c <exit>
  for(i = 0; i < N; i++){
    3cb0:	110006b5 	add	w21, w21, #0x1
    3cb4:	7107d2bf 	cmp	w21, #0x1f4
    3cb8:	54fffd41 	b.ne	3c60 <bigdir+0x58>  // b.any
  unlink("bd");
    3cbc:	aa1403e0 	mov	x0, x20
    name[0] = 'x';
    3cc0:	52800f14 	mov	w20, #0x78                  	// #120
  unlink("bd");
    3cc4:	9400027c 	bl	46b4 <unlink>
    name[1] = '0' + (i / 64);
    3cc8:	13067e60 	asr	w0, w19, #6
    name[0] = 'x';
    3ccc:	390103f4 	strb	w20, [sp, #64]
    name[1] = '0' + (i / 64);
    3cd0:	1100c000 	add	w0, w0, #0x30
    3cd4:	390107e0 	strb	w0, [sp, #65]
    name[2] = '0' + (i % 64);
    3cd8:	12001660 	and	w0, w19, #0x3f
    name[3] = '\0';
    3cdc:	39010fff 	strb	wzr, [sp, #67]
    name[2] = '0' + (i % 64);
    3ce0:	1100c000 	add	w0, w0, #0x30
    3ce4:	39010be0 	strb	w0, [sp, #66]
    if(unlink(name) != 0){
    3ce8:	910103e0 	add	x0, sp, #0x40
    3cec:	94000272 	bl	46b4 <unlink>
    3cf0:	34000080 	cbz	w0, 3d00 <bigdir+0xf8>
      printf("%s: bigdir unlink failed", s);
    3cf4:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3cf8:	91251400 	add	x0, x0, #0x945
    3cfc:	17ffffd3 	b	3c48 <bigdir+0x40>
  for(i = 0; i < N; i++){
    3d00:	11000673 	add	w19, w19, #0x1
    3d04:	7107d27f 	cmp	w19, #0x1f4
    3d08:	54fffe01 	b.ne	3cc8 <bigdir+0xc0>  // b.any
}
    3d0c:	f9401bf7 	ldr	x23, [sp, #48]
    3d10:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d14:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3d18:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3d1c:	d65f03c0 	ret

0000000000003d20 <validatetest>:
{
    3d20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d24:	910003fd 	mov	x29, sp
    3d28:	a90153f3 	stp	x19, x20, [sp, #16]
    if(link("nosuchfile", (char*)p) != -1){
    3d2c:	f0000013 	adrp	x19, 6000 <malloc+0x10e4>
    3d30:	91257a73 	add	x19, x19, #0x95e
{
    3d34:	f90013f5 	str	x21, [sp, #32]
    3d38:	aa0003f5 	mov	x21, x0
  for(p = 0; p <= (uint)hi; p += PGSIZE){
    3d3c:	d2800014 	mov	x20, #0x0                   	// #0
    if(link("nosuchfile", (char*)p) != -1){
    3d40:	aa1403e1 	mov	x1, x20
    3d44:	aa1303e0 	mov	x0, x19
    3d48:	94000261 	bl	46cc <link>
    3d4c:	3100041f 	cmn	w0, #0x1
    3d50:	540000e0 	b.eq	3d6c <validatetest+0x4c>  // b.none
      printf("%s: link should not succeed\n", s);
    3d54:	aa1503e1 	mov	x1, x21
    3d58:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3d5c:	9125a400 	add	x0, x0, #0x969
    3d60:	94000413 	bl	4dac <printf>
      exit(1);
    3d64:	52800020 	mov	w0, #0x1                   	// #1
    3d68:	94000235 	bl	463c <exit>
  for(p = 0; p <= (uint)hi; p += PGSIZE){
    3d6c:	91400694 	add	x20, x20, #0x1, lsl #12
    3d70:	f144529f 	cmp	x20, #0x114, lsl #12
    3d74:	54fffe61 	b.ne	3d40 <validatetest+0x20>  // b.any
}
    3d78:	f94013f5 	ldr	x21, [sp, #32]
    3d7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3d84:	d65f03c0 	ret

0000000000003d88 <argptest>:
{
    3d88:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  fd = open("init", O_RDONLY);
    3d8c:	52800001 	mov	w1, #0x0                   	// #0
{
    3d90:	910003fd 	mov	x29, sp
    3d94:	a90153f3 	stp	x19, x20, [sp, #16]
    3d98:	aa0003f4 	mov	x20, x0
  fd = open("init", O_RDONLY);
    3d9c:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3da0:	91261800 	add	x0, x0, #0x986
    3da4:	9400023e 	bl	469c <open>
  if (fd < 0) {
    3da8:	36f800e0 	tbz	w0, #31, 3dc4 <argptest+0x3c>
    printf("%s: open failed\n", s);
    3dac:	aa1403e1 	mov	x1, x20
    3db0:	d0000000 	adrp	x0, 5000 <malloc+0xe4>
    3db4:	9117e800 	add	x0, x0, #0x5fa
    3db8:	940003fd 	bl	4dac <printf>
    exit(1);
    3dbc:	52800020 	mov	w0, #0x1                   	// #1
    3dc0:	9400021f 	bl	463c <exit>
    3dc4:	2a0003f3 	mov	w19, w0
  read(fd, sbrk(0) - 1, -1);
    3dc8:	52800000 	mov	w0, #0x0                   	// #0
    3dcc:	9400024f 	bl	4708 <sbrk>
    3dd0:	d1000401 	sub	x1, x0, #0x1
    3dd4:	12800002 	mov	w2, #0xffffffff            	// #-1
    3dd8:	2a1303e0 	mov	w0, w19
    3ddc:	94000221 	bl	4660 <read>
  close(fd);
    3de0:	2a1303e0 	mov	w0, w19
}
    3de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de8:	a8c27bfd 	ldp	x29, x30, [sp], #32
  close(fd);
    3dec:	14000223 	b	4678 <close>

0000000000003df0 <writebig>:
{
    3df0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  fd = open("big", O_CREATE|O_RDWR);
    3df4:	52804041 	mov	w1, #0x202                 	// #514
{
    3df8:	910003fd 	mov	x29, sp
    3dfc:	a9025bf5 	stp	x21, x22, [sp, #32]
  fd = open("big", O_CREATE|O_RDWR);
    3e00:	f0000016 	adrp	x22, 6000 <malloc+0x10e4>
    3e04:	912816d6 	add	x22, x22, #0xa05
{
    3e08:	a90153f3 	stp	x19, x20, [sp, #16]
    3e0c:	aa0003f3 	mov	x19, x0
  fd = open("big", O_CREATE|O_RDWR);
    3e10:	aa1603e0 	mov	x0, x22
{
    3e14:	f9001bf7 	str	x23, [sp, #48]
  fd = open("big", O_CREATE|O_RDWR);
    3e18:	94000221 	bl	469c <open>
  if(fd < 0){
    3e1c:	37f80260 	tbnz	w0, #31, 3e68 <writebig+0x78>
    ((int*)buf)[0] = i;
    3e20:	f0000035 	adrp	x21, a000 <uninit+0x1cb7>
    3e24:	912966b5 	add	x21, x21, #0xa59
    3e28:	2a0003f7 	mov	w23, w0
    3e2c:	52800014 	mov	w20, #0x0                   	// #0
    if(write(fd, buf, BSIZE) != BSIZE){
    3e30:	aa1503e1 	mov	x1, x21
    3e34:	2a1703e0 	mov	w0, w23
    3e38:	52808002 	mov	w2, #0x400                 	// #1024
    ((int*)buf)[0] = i;
    3e3c:	b90002b4 	str	w20, [x21]
    if(write(fd, buf, BSIZE) != BSIZE){
    3e40:	9400020b 	bl	466c <write>
    3e44:	7110001f 	cmp	w0, #0x400
    3e48:	540001a0 	b.eq	3e7c <writebig+0x8c>  // b.none
      printf("%s: error: write big file failed\n", s, i);
    3e4c:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3e50:	9126a400 	add	x0, x0, #0x9a9
    3e54:	2a1403e2 	mov	w2, w20
    3e58:	aa1303e1 	mov	x1, x19
    3e5c:	940003d4 	bl	4dac <printf>
      exit(1);
    3e60:	52800020 	mov	w0, #0x1                   	// #1
    3e64:	940001f6 	bl	463c <exit>
    printf("%s: error: creat big failed!\n", s);
    3e68:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3e6c:	91262c00 	add	x0, x0, #0x98b
    printf("%s: unlink big failed\n", s);
    3e70:	aa1303e1 	mov	x1, x19
    3e74:	940003ce 	bl	4dac <printf>
    exit(1);
    3e78:	17fffffa 	b	3e60 <writebig+0x70>
  for(i = 0; i < MAXFILE; i++){
    3e7c:	11000694 	add	w20, w20, #0x1
    3e80:	7104329f 	cmp	w20, #0x10c
    3e84:	54fffd61 	b.ne	3e30 <writebig+0x40>  // b.any
  close(fd);
    3e88:	2a1703e0 	mov	w0, w23
    3e8c:	940001fb 	bl	4678 <close>
  fd = open("big", O_RDONLY);
    3e90:	aa1603e0 	mov	x0, x22
    3e94:	52800001 	mov	w1, #0x0                   	// #0
  n = 0;
    3e98:	52800014 	mov	w20, #0x0                   	// #0
  fd = open("big", O_RDONLY);
    3e9c:	94000200 	bl	469c <open>
    3ea0:	2a0003f7 	mov	w23, w0
  if(fd < 0){
    3ea4:	36f80260 	tbz	w0, #31, 3ef0 <writebig+0x100>
    printf("%s: error: open big failed!\n", s);
    3ea8:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3eac:	91272c00 	add	x0, x0, #0x9cb
    3eb0:	17fffff0 	b	3e70 <writebig+0x80>
    } else if(i != BSIZE){
    3eb4:	7110001f 	cmp	w0, #0x400
    3eb8:	54000080 	b.eq	3ec8 <writebig+0xd8>  // b.none
      printf("%s: read failed %d\n", s, i);
    3ebc:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3ec0:	91282400 	add	x0, x0, #0xa09
    3ec4:	17ffffe5 	b	3e58 <writebig+0x68>
    if(((int*)buf)[0] != n){
    3ec8:	b94002a3 	ldr	w3, [x21]
    3ecc:	6b14007f 	cmp	w3, w20
    3ed0:	540000e0 	b.eq	3eec <writebig+0xfc>  // b.none
      printf("%s: read content of block %d is %d\n", s,
    3ed4:	2a1403e2 	mov	w2, w20
    3ed8:	aa1303e1 	mov	x1, x19
    3edc:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3ee0:	91287400 	add	x0, x0, #0xa1d
    3ee4:	940003b2 	bl	4dac <printf>
      exit(1);
    3ee8:	17ffffde 	b	3e60 <writebig+0x70>
    n++;
    3eec:	11000694 	add	w20, w20, #0x1
    i = read(fd, buf, BSIZE);
    3ef0:	52808002 	mov	w2, #0x400                 	// #1024
    3ef4:	aa1503e1 	mov	x1, x21
    3ef8:	2a1703e0 	mov	w0, w23
    3efc:	940001d9 	bl	4660 <read>
    3f00:	2a0003e2 	mov	w2, w0
    if(i == 0){
    3f04:	35fffd80 	cbnz	w0, 3eb4 <writebig+0xc4>
      if(n == MAXFILE - 1){
    3f08:	71042e9f 	cmp	w20, #0x10b
    3f0c:	54000081 	b.ne	3f1c <writebig+0x12c>  // b.any
        printf("%s: read only %d blocks from big", s, n);
    3f10:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3f14:	9127a000 	add	x0, x0, #0x9e8
    3f18:	17ffffcf 	b	3e54 <writebig+0x64>
  close(fd);
    3f1c:	2a1703e0 	mov	w0, w23
    3f20:	940001d6 	bl	4678 <close>
  if(unlink("big") < 0){
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	940001e3 	bl	46b4 <unlink>
    3f2c:	36f80080 	tbz	w0, #31, 3f3c <writebig+0x14c>
    printf("%s: unlink big failed\n", s);
    3f30:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3f34:	91290400 	add	x0, x0, #0xa41
    3f38:	17ffffce 	b	3e70 <writebig+0x80>
}
    3f3c:	f9401bf7 	ldr	x23, [sp, #48]
    3f40:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f44:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f48:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3f4c:	d65f03c0 	ret

0000000000003f50 <fsfull>:
{
    3f50:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
  printf("fsfull test\n");
    3f54:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3f58:	91296000 	add	x0, x0, #0xa58
{
    3f5c:	910003fd 	mov	x29, sp
    3f60:	a9025bf5 	stp	x21, x22, [sp, #32]
    printf("writing %s\n", name);
    3f64:	f0000016 	adrp	x22, 6000 <malloc+0x10e4>
    3f68:	912996d6 	add	x22, x22, #0xa65
    name[3] = '0' + (nfiles % 100) / 10;
    3f6c:	52800155 	mov	w21, #0xa                   	// #10
{
    3f70:	a90153f3 	stp	x19, x20, [sp, #16]
  for(nfiles = 0; ; nfiles++){
    3f74:	52800013 	mov	w19, #0x0                   	// #0
    name[2] = '0' + (nfiles % 1000) / 100;
    3f78:	52800c94 	mov	w20, #0x64                  	// #100
{
    3f7c:	a90363f7 	stp	x23, x24, [sp, #48]
    name[0] = 'f';
    3f80:	52800cd8 	mov	w24, #0x66                  	// #102
    name[1] = '0' + nfiles / 1000;
    3f84:	52807d17 	mov	w23, #0x3e8                 	// #1000
{
    3f88:	a9046bf9 	stp	x25, x26, [sp, #64]
  printf("fsfull test\n");
    3f8c:	94000388 	bl	4dac <printf>
    name[1] = '0' + nfiles / 1000;
    3f90:	1ad70a61 	udiv	w1, w19, w23
    name[0] = 'f';
    3f94:	390143f8 	strb	w24, [sp, #80]
    name[5] = '\0';
    3f98:	390157ff 	strb	wzr, [sp, #85]
    name[1] = '0' + nfiles / 1000;
    3f9c:	1100c020 	add	w0, w1, #0x30
    3fa0:	390147e0 	strb	w0, [sp, #81]
    name[3] = '0' + (nfiles % 100) / 10;
    3fa4:	1ad40a60 	udiv	w0, w19, w20
    name[2] = '0' + (nfiles % 1000) / 100;
    3fa8:	1b17cc21 	msub	w1, w1, w23, w19
    3fac:	1ad40821 	udiv	w1, w1, w20
    name[3] = '0' + (nfiles % 100) / 10;
    3fb0:	1b14cc00 	msub	w0, w0, w20, w19
    3fb4:	1ad50800 	udiv	w0, w0, w21
    name[2] = '0' + (nfiles % 1000) / 100;
    3fb8:	1100c021 	add	w1, w1, #0x30
    3fbc:	39014be1 	strb	w1, [sp, #82]
    printf("writing %s\n", name);
    3fc0:	910143e1 	add	x1, sp, #0x50
    name[3] = '0' + (nfiles % 100) / 10;
    3fc4:	1100c000 	add	w0, w0, #0x30
    3fc8:	39014fe0 	strb	w0, [sp, #83]
    name[4] = '0' + (nfiles % 10);
    3fcc:	1ad50a60 	udiv	w0, w19, w21
    3fd0:	1b15cc00 	msub	w0, w0, w21, w19
    3fd4:	1100c000 	add	w0, w0, #0x30
    3fd8:	390153e0 	strb	w0, [sp, #84]
    printf("writing %s\n", name);
    3fdc:	aa1603e0 	mov	x0, x22
    3fe0:	94000373 	bl	4dac <printf>
    int fd = open(name, O_CREATE|O_RDWR);
    3fe4:	910143e0 	add	x0, sp, #0x50
    3fe8:	52804041 	mov	w1, #0x202                 	// #514
    3fec:	940001ac 	bl	469c <open>
    3ff0:	2a0003fa 	mov	w26, w0
    if(fd < 0){
    3ff4:	36f80500 	tbz	w0, #31, 4094 <fsfull+0x144>
      printf("open %s failed\n", name);
    3ff8:	f0000000 	adrp	x0, 6000 <malloc+0x10e4>
    3ffc:	9129c400 	add	x0, x0, #0xa71
    4000:	910143e1 	add	x1, sp, #0x50
    4004:	9400036a 	bl	4dac <printf>
    name[0] = 'f';
    4008:	52800cd7 	mov	w23, #0x66                  	// #102
    name[1] = '0' + nfiles / 1000;
    400c:	52807d16 	mov	w22, #0x3e8                 	// #1000
    name[2] = '0' + (nfiles % 1000) / 100;
    4010:	52800c95 	mov	w21, #0x64                  	// #100
    name[3] = '0' + (nfiles % 100) / 10;
    4014:	52800154 	mov	w20, #0xa                   	// #10
    name[1] = '0' + nfiles / 1000;
    4018:	1ad60a60 	udiv	w0, w19, w22
    name[0] = 'f';
    401c:	390143f7 	strb	w23, [sp, #80]
    name[5] = '\0';
    4020:	390157ff 	strb	wzr, [sp, #85]
    name[1] = '0' + nfiles / 1000;
    4024:	1100c001 	add	w1, w0, #0x30
    name[2] = '0' + (nfiles % 1000) / 100;
    4028:	1b16cc00 	msub	w0, w0, w22, w19
    name[1] = '0' + nfiles / 1000;
    402c:	390147e1 	strb	w1, [sp, #81]
    name[2] = '0' + (nfiles % 1000) / 100;
    4030:	1ad50800 	udiv	w0, w0, w21
    4034:	1100c000 	add	w0, w0, #0x30
    4038:	39014be0 	strb	w0, [sp, #82]
    name[3] = '0' + (nfiles % 100) / 10;
    403c:	1ad50a60 	udiv	w0, w19, w21
    4040:	1b15cc00 	msub	w0, w0, w21, w19
    4044:	1ad40800 	udiv	w0, w0, w20
    4048:	1100c000 	add	w0, w0, #0x30
    404c:	39014fe0 	strb	w0, [sp, #83]
    name[4] = '0' + (nfiles % 10);
    4050:	1ad40a60 	udiv	w0, w19, w20
    4054:	1b14cc00 	msub	w0, w0, w20, w19
    nfiles--;
    4058:	51000673 	sub	w19, w19, #0x1
    name[4] = '0' + (nfiles % 10);
    405c:	1100c000 	add	w0, w0, #0x30
    4060:	390153e0 	strb	w0, [sp, #84]
    unlink(name);
    4064:	910143e0 	add	x0, sp, #0x50
    4068:	94000193 	bl	46b4 <unlink>
  while(nfiles >= 0){
    406c:	3100067f 	cmn	w19, #0x1
    4070:	54fffd41 	b.ne	4018 <fsfull+0xc8>  // b.any
}
    4074:	a94153f3 	ldp	x19, x20, [sp, #16]
  printf("fsfull test finished\n");
    4078:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    407c:	912a4400 	add	x0, x0, #0xa91
}
    4080:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4084:	a94363f7 	ldp	x23, x24, [sp, #48]
    4088:	a9446bf9 	ldp	x25, x26, [sp, #64]
    408c:	a8c97bfd 	ldp	x29, x30, [sp], #144
  printf("fsfull test finished\n");
    4090:	14000347 	b	4dac <printf>
      int cc = write(fd, buf, BSIZE);
    4094:	d0000021 	adrp	x1, a000 <uninit+0x1cb7>
    4098:	91296421 	add	x1, x1, #0xa59
    int total = 0;
    409c:	52800019 	mov	w25, #0x0                   	// #0
      int cc = write(fd, buf, BSIZE);
    40a0:	2a1a03e0 	mov	w0, w26
    40a4:	52808002 	mov	w2, #0x400                 	// #1024
    40a8:	94000171 	bl	466c <write>
      if(cc < BSIZE)
    40ac:	710ffc1f 	cmp	w0, #0x3ff
    40b0:	540000ad 	b.le	40c4 <fsfull+0x174>
      total += cc;
    40b4:	0b000339 	add	w25, w25, w0
    while(1){
    40b8:	d0000020 	adrp	x0, a000 <uninit+0x1cb7>
    40bc:	91296401 	add	x1, x0, #0xa59
    40c0:	17fffff8 	b	40a0 <fsfull+0x150>
    printf("wrote %d bytes\n", total);
    40c4:	2a1903e1 	mov	w1, w25
    40c8:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    40cc:	912a0400 	add	x0, x0, #0xa81
    40d0:	94000337 	bl	4dac <printf>
    close(fd);
    40d4:	2a1a03e0 	mov	w0, w26
    40d8:	94000168 	bl	4678 <close>
    if(total == 0)
    40dc:	34fff979 	cbz	w25, 4008 <fsfull+0xb8>
  for(nfiles = 0; ; nfiles++){
    40e0:	11000673 	add	w19, w19, #0x1
    40e4:	17ffffab 	b	3f90 <fsfull+0x40>

00000000000040e8 <badwrite>:
{
    40e8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40ec:	910003fd 	mov	x29, sp
    40f0:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("junk");
    40f4:	d0000013 	adrp	x19, 6000 <malloc+0x10e4>
    40f8:	912a9e73 	add	x19, x19, #0xaa7
    40fc:	aa1303e0 	mov	x0, x19
    4100:	52804b14 	mov	w20, #0x258                 	// #600
{
    4104:	f90013f5 	str	x21, [sp, #32]
  unlink("junk");
    4108:	9400016b 	bl	46b4 <unlink>
    int fd = open("junk", O_CREATE|O_WRONLY);
    410c:	aa1303e0 	mov	x0, x19
    4110:	52804021 	mov	w1, #0x201                 	// #513
    4114:	94000162 	bl	469c <open>
    4118:	2a0003f5 	mov	w21, w0
    if(fd < 0){
    411c:	36f800c0 	tbz	w0, #31, 4134 <badwrite+0x4c>
      printf("open junk failed\n");
    4120:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    4124:	912ab000 	add	x0, x0, #0xaac
    printf("write failed\n");
    4128:	94000321 	bl	4dac <printf>
    exit(1);
    412c:	52800020 	mov	w0, #0x1                   	// #1
    4130:	94000143 	bl	463c <exit>
    write(fd, (char*)0xffffffffffL, 1);
    4134:	52800022 	mov	w2, #0x1                   	// #1
    4138:	b2409fe1 	mov	x1, #0xffffffffff          	// #1099511627775
    413c:	9400014c 	bl	466c <write>
    close(fd);
    4140:	2a1503e0 	mov	w0, w21
    4144:	9400014d 	bl	4678 <close>
    unlink("junk");
    4148:	aa1303e0 	mov	x0, x19
    414c:	9400015a 	bl	46b4 <unlink>
  for(int i = 0; i < assumed_free; i++){
    4150:	71000694 	subs	w20, w20, #0x1
    4154:	54fffdc1 	b.ne	410c <badwrite+0x24>  // b.any
  int fd = open("junk", O_CREATE|O_WRONLY);
    4158:	aa1303e0 	mov	x0, x19
    415c:	52804021 	mov	w1, #0x201                 	// #513
    4160:	9400014f 	bl	469c <open>
    4164:	2a0003f4 	mov	w20, w0
  if(fd < 0){
    4168:	37fffdc0 	tbnz	w0, #31, 4120 <badwrite+0x38>
  if(write(fd, "x", 1) != 1){
    416c:	d0000001 	adrp	x1, 6000 <malloc+0x10e4>
    4170:	9106f021 	add	x1, x1, #0x1bc
    4174:	52800022 	mov	w2, #0x1                   	// #1
    4178:	9400013d 	bl	466c <write>
    417c:	7100041f 	cmp	w0, #0x1
    4180:	54000080 	b.eq	4190 <badwrite+0xa8>  // b.none
    printf("write failed\n");
    4184:	b0000000 	adrp	x0, 5000 <malloc+0xe4>
    4188:	910fd400 	add	x0, x0, #0x3f5
    418c:	17ffffe7 	b	4128 <badwrite+0x40>
  close(fd);
    4190:	2a1403e0 	mov	w0, w20
    4194:	94000139 	bl	4678 <close>
  unlink("junk");
    4198:	aa1303e0 	mov	x0, x19
    419c:	94000146 	bl	46b4 <unlink>
  exit(0);
    41a0:	52800000 	mov	w0, #0x0                   	// #0
    41a4:	17ffffe3 	b	4130 <badwrite+0x48>

00000000000041a8 <countfree>:
{
    41a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    41ac:	910003fd 	mov	x29, sp
  if(pipe(fds) < 0){
    41b0:	9100a3e0 	add	x0, sp, #0x28
{
    41b4:	a90153f3 	stp	x19, x20, [sp, #16]
  if(pipe(fds) < 0){
    41b8:	94000127 	bl	4654 <pipe>
    41bc:	36f800c0 	tbz	w0, #31, 41d4 <countfree+0x2c>
    printf("pipe() failed in countfree()\n");
    41c0:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    41c4:	912af800 	add	x0, x0, #0xabe
    printf("fork failed in countfree()\n");
    41c8:	940002f9 	bl	4dac <printf>
    exit(1);
    41cc:	52800020 	mov	w0, #0x1                   	// #1
    41d0:	9400011b 	bl	463c <exit>
  int pid = fork();
    41d4:	94000117 	bl	4630 <fork>
  if(pid < 0){
    41d8:	36f80080 	tbz	w0, #31, 41e8 <countfree+0x40>
    printf("fork failed in countfree()\n");
    41dc:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    41e0:	912b7000 	add	x0, x0, #0xadc
    41e4:	17fffff9 	b	41c8 <countfree+0x20>
  if(pid == 0){
    41e8:	350002c0 	cbnz	w0, 4240 <countfree+0x98>
    close(fds[0]);
    41ec:	b9402be0 	ldr	w0, [sp, #40]
      if(write(fds[1], "x", 1) != 1){
    41f0:	d0000013 	adrp	x19, 6000 <malloc+0x10e4>
    41f4:	9106f273 	add	x19, x19, #0x1bc
      *(char *)(a + 4096 - 1) = 1;
    41f8:	52800034 	mov	w20, #0x1                   	// #1
    close(fds[0]);
    41fc:	9400011f 	bl	4678 <close>
      uint64 a = (uint64) sbrk(4096);
    4200:	52820000 	mov	w0, #0x1000                	// #4096
    4204:	94000141 	bl	4708 <sbrk>
      if(a == 0xffffffffffffffff){
    4208:	b100041f 	cmn	x0, #0x1
    420c:	54000160 	b.eq	4238 <countfree+0x90>  // b.none
      *(char *)(a + 4096 - 1) = 1;
    4210:	393ffc14 	strb	w20, [x0, #4095]
      if(write(fds[1], "x", 1) != 1){
    4214:	aa1303e1 	mov	x1, x19
    4218:	52800022 	mov	w2, #0x1                   	// #1
    421c:	b9402fe0 	ldr	w0, [sp, #44]
    4220:	94000113 	bl	466c <write>
    4224:	7100041f 	cmp	w0, #0x1
    4228:	54fffec0 	b.eq	4200 <countfree+0x58>  // b.none
        printf("write() failed in countfree()\n");
    422c:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    4230:	912be000 	add	x0, x0, #0xaf8
    4234:	17ffffe5 	b	41c8 <countfree+0x20>
    exit(0);
    4238:	52800000 	mov	w0, #0x0                   	// #0
    423c:	17ffffe5 	b	41d0 <countfree+0x28>
  close(fds[1]);
    4240:	b9402fe0 	ldr	w0, [sp, #44]
  int n = 0;
    4244:	52800013 	mov	w19, #0x0                   	// #0
  close(fds[1]);
    4248:	9400010c 	bl	4678 <close>
    int cc = read(fds[0], &c, 1);
    424c:	b9402be0 	ldr	w0, [sp, #40]
    4250:	91009fe1 	add	x1, sp, #0x27
    4254:	52800022 	mov	w2, #0x1                   	// #1
    4258:	94000102 	bl	4660 <read>
    if(cc < 0){
    425c:	36f80080 	tbz	w0, #31, 426c <countfree+0xc4>
      printf("read() failed in countfree()\n");
    4260:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    4264:	912c5c00 	add	x0, x0, #0xb17
    4268:	17ffffd8 	b	41c8 <countfree+0x20>
    if(cc == 0)
    426c:	34000060 	cbz	w0, 4278 <countfree+0xd0>
    n += 1;
    4270:	11000673 	add	w19, w19, #0x1
  while(1){
    4274:	17fffff6 	b	424c <countfree+0xa4>
  close(fds[0]);
    4278:	b9402be0 	ldr	w0, [sp, #40]
    427c:	940000ff 	bl	4678 <close>
  wait((int*)0);
    4280:	d2800000 	mov	x0, #0x0                   	// #0
    4284:	940000f1 	bl	4648 <wait>
}
    4288:	2a1303e0 	mov	w0, w19
    428c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4290:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4294:	d65f03c0 	ret

0000000000004298 <run>:
run(void f(char *), char *s) {
    4298:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    429c:	910003fd 	mov	x29, sp
    42a0:	a90153f3 	stp	x19, x20, [sp, #16]
    42a4:	aa0003f3 	mov	x19, x0
    42a8:	aa0103f4 	mov	x20, x1
  printf("test %s: ", s);
    42ac:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    42b0:	912cd400 	add	x0, x0, #0xb35
    42b4:	940002be 	bl	4dac <printf>
  if((pid = fork()) < 0) {
    42b8:	940000de 	bl	4630 <fork>
    42bc:	36f800c0 	tbz	w0, #31, 42d4 <run+0x3c>
    printf("runtest: fork error\n");
    42c0:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    42c4:	912cfc00 	add	x0, x0, #0xb3f
    42c8:	940002b9 	bl	4dac <printf>
    exit(1);
    42cc:	52800020 	mov	w0, #0x1                   	// #1
    exit(0);
    42d0:	940000db 	bl	463c <exit>
  if(pid == 0) {
    42d4:	350000a0 	cbnz	w0, 42e8 <run+0x50>
    f(s);
    42d8:	aa1403e0 	mov	x0, x20
    42dc:	d63f0260 	blr	x19
    exit(0);
    42e0:	52800000 	mov	w0, #0x0                   	// #0
    42e4:	17fffffb 	b	42d0 <run+0x38>
    wait(&xstatus);
    42e8:	9100b3e0 	add	x0, sp, #0x2c
    42ec:	940000d7 	bl	4648 <wait>
    if(xstatus != 0) 
    42f0:	b9402fe0 	ldr	w0, [sp, #44]
    42f4:	34000140 	cbz	w0, 431c <run+0x84>
      printf("FAILED\n");
    42f8:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    42fc:	912f2000 	add	x0, x0, #0xbc8
      printf("OK\n");
    4300:	940002ab 	bl	4dac <printf>
    return xstatus == 0;
    4304:	b9402fe0 	ldr	w0, [sp, #44]
}
    4308:	a94153f3 	ldp	x19, x20, [sp, #16]
    return xstatus == 0;
    430c:	7100001f 	cmp	w0, #0x0
}
    4310:	1a9f17e0 	cset	w0, eq	// eq = none
    4314:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4318:	d65f03c0 	ret
      printf("OK\n");
    431c:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    4320:	912d5000 	add	x0, x0, #0xb54
    4324:	17fffff7 	b	4300 <run+0x68>

0000000000004328 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
    4328:	d2800002 	mov	x2, #0x0                   	// #0
    432c:	38626823 	ldrb	w3, [x1, x2]
    4330:	38226803 	strb	w3, [x0, x2]
    4334:	91000442 	add	x2, x2, #0x1
    4338:	35ffffa3 	cbnz	w3, 432c <strcpy+0x4>
    ;
  return os;
}
    433c:	d65f03c0 	ret

0000000000004340 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
    4340:	d2800003 	mov	x3, #0x0                   	// #0
    4344:	4b030044 	sub	w4, w2, w3
    4348:	7100009f 	cmp	w4, #0x0
    434c:	5400006d 	b.le	4358 <strncpy+0x18>
    4350:	38636825 	ldrb	w5, [x1, x3]
    4354:	350000e5 	cbnz	w5, 4370 <strncpy+0x30>
    4358:	8b030003 	add	x3, x0, x3
    435c:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
    4360:	4b010082 	sub	w2, w4, w1
    4364:	7100005f 	cmp	w2, #0x0
    4368:	540000ac 	b.gt	437c <strncpy+0x3c>
    *s++ = 0;
  return os;
}
    436c:	d65f03c0 	ret
    *s++ = *t++;
    4370:	38236805 	strb	w5, [x0, x3]
    n--;
    4374:	91000463 	add	x3, x3, #0x1
    4378:	17fffff3 	b	4344 <strncpy+0x4>
    *s++ = 0;
    437c:	3821687f 	strb	wzr, [x3, x1]
    4380:	91000421 	add	x1, x1, #0x1
    4384:	17fffff7 	b	4360 <strncpy+0x20>

0000000000004388 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
    4388:	aa0003e2 	mov	x2, x0
    438c:	39400043 	ldrb	w3, [x2]
    4390:	aa0203e4 	mov	x4, x2
    s++;
    4394:	91000442 	add	x2, x2, #0x1
  while(*s)
    4398:	35ffffa3 	cbnz	w3, 438c <strcat+0x4>
    439c:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
    43a0:	38626823 	ldrb	w3, [x1, x2]
    43a4:	38226883 	strb	w3, [x4, x2]
    43a8:	91000442 	add	x2, x2, #0x1
    43ac:	35ffffa3 	cbnz	w3, 43a0 <strcat+0x18>
    ;
  return os;
}
    43b0:	d65f03c0 	ret

00000000000043b4 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
    43b4:	d2800002 	mov	x2, #0x0                   	// #0
    43b8:	38626803 	ldrb	w3, [x0, x2]
    43bc:	38626824 	ldrb	w4, [x1, x2]
    43c0:	34000083 	cbz	w3, 43d0 <strcmp+0x1c>
    43c4:	91000442 	add	x2, x2, #0x1
    43c8:	6b04007f 	cmp	w3, w4
    43cc:	54ffff60 	b.eq	43b8 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
    43d0:	4b040060 	sub	w0, w3, w4
    43d4:	d65f03c0 	ret

00000000000043d8 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
    43d8:	340001c2 	cbz	w2, 4410 <strncmp+0x38>
    43dc:	39400003 	ldrb	w3, [x0]
    43e0:	34000083 	cbz	w3, 43f0 <strncmp+0x18>
    43e4:	39400024 	ldrb	w4, [x1]
    43e8:	6b03009f 	cmp	w4, w3
    43ec:	540000a0 	b.eq	4400 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
    43f0:	39400000 	ldrb	w0, [x0]
    43f4:	39400021 	ldrb	w1, [x1]
    43f8:	4b010000 	sub	w0, w0, w1
}
    43fc:	d65f03c0 	ret
    n--, p++, q++;
    4400:	51000442 	sub	w2, w2, #0x1
    4404:	91000400 	add	x0, x0, #0x1
    4408:	91000421 	add	x1, x1, #0x1
    440c:	17fffff3 	b	43d8 <strncmp>
    return 0;
    4410:	52800000 	mov	w0, #0x0                   	// #0
    4414:	17fffffa 	b	43fc <strncmp+0x24>

0000000000004418 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
    4418:	d1000402 	sub	x2, x0, #0x1
    441c:	d2800001 	mov	x1, #0x0                   	// #0
    4420:	aa0103e0 	mov	x0, x1
    4424:	91000421 	add	x1, x1, #0x1
    4428:	38616843 	ldrb	w3, [x2, x1]
    442c:	35ffffa3 	cbnz	w3, 4420 <strlen+0x8>
    ;
  return n;
}
    4430:	d65f03c0 	ret

0000000000004434 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
    4434:	d1000403 	sub	x3, x0, #0x1
    4438:	d2800002 	mov	x2, #0x0                   	// #0
    443c:	2a0203e0 	mov	w0, w2
    4440:	6b02003f 	cmp	w1, w2
    4444:	54000089 	b.ls	4454 <strnlen+0x20>  // b.plast
    4448:	91000442 	add	x2, x2, #0x1
    444c:	38626864 	ldrb	w4, [x3, x2]
    4450:	35ffff64 	cbnz	w4, 443c <strnlen+0x8>
    n++;
  return n;
}
    4454:	d65f03c0 	ret

0000000000004458 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    4458:	d2800003 	mov	x3, #0x0                   	// #0
    445c:	6b03005f 	cmp	w2, w3
    4460:	54000048 	b.hi	4468 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
    4464:	d65f03c0 	ret
    cdst[i] = c;
    4468:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
    446c:	91000463 	add	x3, x3, #0x1
    4470:	17fffffb 	b	445c <memset+0x4>

0000000000004474 <strchr>:

char*
strchr(const char *s, char c)
{
    4474:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
    4478:	39400002 	ldrb	w2, [x0]
    447c:	35000062 	cbnz	w2, 4488 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
    4480:	d2800000 	mov	x0, #0x0                   	// #0
}
    4484:	d65f03c0 	ret
    if(*s == c)
    4488:	6b01005f 	cmp	w2, w1
    448c:	54ffffc0 	b.eq	4484 <strchr+0x10>  // b.none
  for(; *s; s++)
    4490:	91000400 	add	x0, x0, #0x1
    4494:	17fffff9 	b	4478 <strchr+0x4>

0000000000004498 <gets>:

char*
gets(char *buf, int max)
{
    4498:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    449c:	910003fd 	mov	x29, sp
    44a0:	a90153f3 	stp	x19, x20, [sp, #16]
    44a4:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    44a8:	d2800014 	mov	x20, #0x0                   	// #0
{
    44ac:	f9001bf7 	str	x23, [sp, #48]
    44b0:	2a0103f7 	mov	w23, w1
    44b4:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
    44b8:	11000695 	add	w21, w20, #0x1
    44bc:	2a1403f6 	mov	w22, w20
    44c0:	6b1702bf 	cmp	w21, w23
    44c4:	540000ea 	b.ge	44e0 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
    44c8:	91013fe1 	add	x1, sp, #0x4f
    44cc:	52800022 	mov	w2, #0x1                   	// #1
    44d0:	52800000 	mov	w0, #0x0                   	// #0
    44d4:	94000063 	bl	4660 <read>
    if(cc < 1)
    44d8:	7100001f 	cmp	w0, #0x0
    44dc:	5400012c 	b.gt	4500 <gets+0x68>
  for(i=0; i+1 < max; ){
    44e0:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
    44e4:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
    44e8:	aa1303e0 	mov	x0, x19
    44ec:	f9401bf7 	ldr	x23, [sp, #48]
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44fc:	d65f03c0 	ret
    buf[i++] = c;
    4500:	39413fe0 	ldrb	w0, [sp, #79]
    4504:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
    4508:	91000694 	add	x20, x20, #0x1
    450c:	7100281f 	cmp	w0, #0xa
    4510:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
    4514:	54fffd21 	b.ne	44b8 <gets+0x20>  // b.any
    4518:	17fffff3 	b	44e4 <gets+0x4c>

000000000000451c <stat>:

int
stat(const char *n, struct stat *st)
{
    451c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4520:	910003fd 	mov	x29, sp
    4524:	a90153f3 	stp	x19, x20, [sp, #16]
    4528:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    452c:	52800001 	mov	w1, #0x0                   	// #0
    4530:	9400005b 	bl	469c <open>
  if(fd < 0)
    4534:	37f80160 	tbnz	w0, #31, 4560 <stat+0x44>
    return -1;
  r = fstat(fd, st);
    4538:	aa1303e1 	mov	x1, x19
    453c:	2a0003f4 	mov	w20, w0
    4540:	94000060 	bl	46c0 <fstat>
    4544:	2a0003f3 	mov	w19, w0
  close(fd);
    4548:	2a1403e0 	mov	w0, w20
    454c:	9400004b 	bl	4678 <close>
  return r;
}
    4550:	2a1303e0 	mov	w0, w19
    4554:	a94153f3 	ldp	x19, x20, [sp, #16]
    4558:	a8c27bfd 	ldp	x29, x30, [sp], #32
    455c:	d65f03c0 	ret
    return -1;
    4560:	12800013 	mov	w19, #0xffffffff            	// #-1
    4564:	17fffffb 	b	4550 <stat+0x34>

0000000000004568 <atoi>:

int
atoi(const char *s)
{
    4568:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
    456c:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
    4570:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
    4574:	39400043 	ldrb	w3, [x2]
    4578:	5100c061 	sub	w1, w3, #0x30
    457c:	12001c21 	and	w1, w1, #0xff
    4580:	7100243f 	cmp	w1, #0x9
    4584:	54000049 	b.ls	458c <atoi+0x24>  // b.plast
  return n;
}
    4588:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
    458c:	1b040c01 	madd	w1, w0, w4, w3
    4590:	91000442 	add	x2, x2, #0x1
    4594:	5100c020 	sub	w0, w1, #0x30
    4598:	17fffff7 	b	4574 <atoi+0xc>

000000000000459c <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    459c:	eb01001f 	cmp	x0, x1
    45a0:	54000263 	b.cc	45ec <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
    45a4:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
    45a8:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
    45ac:	d2800003 	mov	x3, #0x0                   	// #0
    45b0:	d1000463 	sub	x3, x3, #0x1
    45b4:	11000464 	add	w4, w3, #0x1
    45b8:	0b020084 	add	w4, w4, w2
    45bc:	7100009f 	cmp	w4, #0x0
    45c0:	5400014d 	b.le	45e8 <memmove+0x4c>
      *--dst = *--src;
    45c4:	38636824 	ldrb	w4, [x1, x3]
    45c8:	382368a4 	strb	w4, [x5, x3]
    45cc:	17fffff9 	b	45b0 <memmove+0x14>
      *dst++ = *src++;
    45d0:	38636824 	ldrb	w4, [x1, x3]
    45d4:	38236804 	strb	w4, [x0, x3]
    45d8:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
    45dc:	4b030044 	sub	w4, w2, w3
    45e0:	7100009f 	cmp	w4, #0x0
    45e4:	54ffff6c 	b.gt	45d0 <memmove+0x34>
  }
  return vdst;
}
    45e8:	d65f03c0 	ret
    45ec:	d2800003 	mov	x3, #0x0                   	// #0
    45f0:	17fffffb 	b	45dc <memmove+0x40>

00000000000045f4 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    45f4:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
    45f8:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
    45fc:	d2800004 	mov	x4, #0x0                   	// #0
    4600:	eb02009f 	cmp	x4, x2
    4604:	54000061 	b.ne	4610 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
    4608:	52800000 	mov	w0, #0x0                   	// #0
    460c:	14000007 	b	4628 <memcmp+0x34>
    if (*p1 != *p2) {
    4610:	38646803 	ldrb	w3, [x0, x4]
    4614:	91000484 	add	x4, x4, #0x1
    4618:	38646825 	ldrb	w5, [x1, x4]
    461c:	6b05007f 	cmp	w3, w5
    4620:	54ffff00 	b.eq	4600 <memcmp+0xc>  // b.none
      return *p1 - *p2;
    4624:	4b050060 	sub	w0, w3, w5
}
    4628:	d65f03c0 	ret

000000000000462c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
    462c:	17ffffdc 	b	459c <memmove>

0000000000004630 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
    4630:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
    4634:	d4000001 	svc	#0x0
 ret
    4638:	d65f03c0 	ret

000000000000463c <exit>:
.global exit
exit:
 mov x7, #SYS_exit
    463c:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
    4640:	d4000001 	svc	#0x0
 ret
    4644:	d65f03c0 	ret

0000000000004648 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
    4648:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
    464c:	d4000001 	svc	#0x0
 ret
    4650:	d65f03c0 	ret

0000000000004654 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
    4654:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
    4658:	d4000001 	svc	#0x0
 ret
    465c:	d65f03c0 	ret

0000000000004660 <read>:
.global read
read:
 mov x7, #SYS_read
    4660:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
    4664:	d4000001 	svc	#0x0
 ret
    4668:	d65f03c0 	ret

000000000000466c <write>:
.global write
write:
 mov x7, #SYS_write
    466c:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
    4670:	d4000001 	svc	#0x0
 ret
    4674:	d65f03c0 	ret

0000000000004678 <close>:
.global close
close:
 mov x7, #SYS_close
    4678:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
    467c:	d4000001 	svc	#0x0
 ret
    4680:	d65f03c0 	ret

0000000000004684 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
    4684:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
    4688:	d4000001 	svc	#0x0
 ret
    468c:	d65f03c0 	ret

0000000000004690 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
    4690:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
    4694:	d4000001 	svc	#0x0
 ret
    4698:	d65f03c0 	ret

000000000000469c <open>:
.global open
open:
 mov x7, #SYS_open
    469c:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
    46a0:	d4000001 	svc	#0x0
 ret
    46a4:	d65f03c0 	ret

00000000000046a8 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
    46a8:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
    46ac:	d4000001 	svc	#0x0
 ret
    46b0:	d65f03c0 	ret

00000000000046b4 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
    46b4:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
    46b8:	d4000001 	svc	#0x0
 ret
    46bc:	d65f03c0 	ret

00000000000046c0 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
    46c0:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
    46c4:	d4000001 	svc	#0x0
 ret
    46c8:	d65f03c0 	ret

00000000000046cc <link>:
.global link
link:
 mov x7, #SYS_link
    46cc:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
    46d0:	d4000001 	svc	#0x0
 ret
    46d4:	d65f03c0 	ret

00000000000046d8 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
    46d8:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
    46dc:	d4000001 	svc	#0x0
 ret
    46e0:	d65f03c0 	ret

00000000000046e4 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
    46e4:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
    46e8:	d4000001 	svc	#0x0
 ret
    46ec:	d65f03c0 	ret

00000000000046f0 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
    46f0:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
    46f4:	d4000001 	svc	#0x0
 ret
    46f8:	d65f03c0 	ret

00000000000046fc <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
    46fc:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
    4700:	d4000001 	svc	#0x0
 ret
    4704:	d65f03c0 	ret

0000000000004708 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
    4708:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
    470c:	d4000001 	svc	#0x0
 ret
    4710:	d65f03c0 	ret

0000000000004714 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
    4714:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
    4718:	d4000001 	svc	#0x0
 ret
    471c:	d65f03c0 	ret

0000000000004720 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
    4720:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
    4724:	d4000001 	svc	#0x0
 ret
    4728:	d65f03c0 	ret

000000000000472c <ps>:
.global ps
ps:
 mov x7, #SYS_ps
    472c:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
    4730:	d4000001 	svc	#0x0
 ret
    4734:	d65f03c0 	ret

0000000000004738 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
    4738:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
    473c:	d4000001 	svc	#0x0
 ret
    4740:	d65f03c0 	ret

0000000000004744 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
    4744:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
    4748:	d4000001 	svc	#0x0
 ret
    474c:	d65f03c0 	ret

0000000000004750 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
    4750:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
    4754:	d4000001 	svc	#0x0
 ret
    4758:	d65f03c0 	ret

000000000000475c <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
    475c:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
    4760:	d4000001 	svc	#0x0
 ret
    4764:	d65f03c0 	ret

0000000000004768 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
    4768:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
    476c:	d4000001 	svc	#0x0
 ret
    4770:	d65f03c0 	ret

0000000000004774 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
    4774:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
    4778:	d4000001 	svc	#0x0
 ret
    477c:	d65f03c0 	ret

0000000000004780 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
    4780:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
    4784:	d4000001 	svc	#0x0
 ret
    4788:	d65f03c0 	ret

000000000000478c <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
    478c:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
    4790:	d4000001 	svc	#0x0
 ret
    4794:	d65f03c0 	ret

0000000000004798 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
    4798:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
    479c:	d4000001 	svc	#0x0
 ret
    47a0:	d65f03c0 	ret

00000000000047a4 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
    47a4:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
    47a8:	d4000001 	svc	#0x0
 ret
    47ac:	d65f03c0 	ret

00000000000047b0 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
    47b0:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
    47b4:	d4000001 	svc	#0x0
 ret
    47b8:	d65f03c0 	ret

00000000000047bc <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
    47bc:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
    47c0:	d4000001 	svc	#0x0
 ret
    47c4:	d65f03c0 	ret

00000000000047c8 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
    47c8:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
    47cc:	d4000001 	svc	#0x0
 ret
    47d0:	d65f03c0 	ret

00000000000047d4 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
    47d4:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
    47d8:	d4000001 	svc	#0x0
 ret
    47dc:	d65f03c0 	ret

00000000000047e0 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
    47e0:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
    47e4:	d4000001 	svc	#0x0
 ret
    47e8:	d65f03c0 	ret

00000000000047ec <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
    47ec:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
    47f0:	d4000001 	svc	#0x0
 ret
    47f4:	d65f03c0 	ret

00000000000047f8 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
    47f8:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
    47fc:	d4000001 	svc	#0x0
 ret
    4800:	d65f03c0 	ret

0000000000004804 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
    4804:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
    4808:	d4000001 	svc	#0x0
 ret
    480c:	d65f03c0 	ret

0000000000004810 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
    4810:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
    4814:	d4000001 	svc	#0x0
 ret
    4818:	d65f03c0 	ret

000000000000481c <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
    481c:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
    4820:	d4000001 	svc	#0x0
 ret
    4824:	d65f03c0 	ret

0000000000004828 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
    4828:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
    482c:	d4000001 	svc	#0x0
 ret
    4830:	d65f03c0 	ret

0000000000004834 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
    4834:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
    4838:	d4000001 	svc	#0x0
 ret
    483c:	d65f03c0 	ret

0000000000004840 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
    4840:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
    4844:	d4000001 	svc	#0x0
 ret
    4848:	d65f03c0 	ret

000000000000484c <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
    484c:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
    4850:	d4000001 	svc	#0x0
 ret
    4854:	d65f03c0 	ret

0000000000004858 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
    4858:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
    485c:	d4000001 	svc	#0x0
 ret
    4860:	d65f03c0 	ret

0000000000004864 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
    4864:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
    4868:	d4000001 	svc	#0x0
 ret
    486c:	d65f03c0 	ret

0000000000004870 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
    4870:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
    4874:	d4000001 	svc	#0x0
 ret
    4878:	d65f03c0 	ret

000000000000487c <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
    487c:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
    4880:	d4000001 	svc	#0x0
 ret
    4884:	d65f03c0 	ret

0000000000004888 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
    4888:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
    488c:	d4000001 	svc	#0x0
 ret
    4890:	d65f03c0 	ret

0000000000004894 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
    4894:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
    4898:	d4000001 	svc	#0x0
 ret
    489c:	d65f03c0 	ret

00000000000048a0 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
    48a0:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
    48a4:	d4000001 	svc	#0x0
 ret
    48a8:	d65f03c0 	ret

00000000000048ac <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
    48ac:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
    48b0:	d4000001 	svc	#0x0
 ret
    48b4:	d65f03c0 	ret

00000000000048b8 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
    48b8:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
    48bc:	d4000001 	svc	#0x0
 ret
    48c0:	d65f03c0 	ret

00000000000048c4 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
    48c4:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
    48c8:	d4000001 	svc	#0x0
 ret
    48cc:	d65f03c0 	ret

00000000000048d0 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
    48d0:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
    48d4:	d4000001 	svc	#0x0
 ret
    48d8:	d65f03c0 	ret

00000000000048dc <rename>:
.global rename
rename:
 mov x7, #SYS_rename
    48dc:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
    48e0:	d4000001 	svc	#0x0
 ret
    48e4:	d65f03c0 	ret

00000000000048e8 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
    48e8:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
    48ec:	d4000001 	svc	#0x0
 ret
    48f0:	d65f03c0 	ret

00000000000048f4 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
    48f4:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
    48f8:	d4000001 	svc	#0x0
 ret
    48fc:	d65f03c0 	ret

0000000000004900 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
    4900:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
    4904:	d4000001 	svc	#0x0
 ret
    4908:	d65f03c0 	ret

000000000000490c <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
    490c:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
    4910:	d4000001 	svc	#0x0
 ret
    4914:	d65f03c0 	ret

0000000000004918 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
    4918:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
    491c:	d4000001 	svc	#0x0
 ret
    4920:	d65f03c0 	ret

0000000000004924 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
    4924:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
    4928:	d4000001 	svc	#0x0
 ret
    492c:	d65f03c0 	ret

0000000000004930 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
    4930:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
    4934:	d4000001 	svc	#0x0
 ret
    4938:	d65f03c0 	ret

000000000000493c <clone>:
.global clone
clone:
 mov x7, #SYS_clone
    493c:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
    4940:	d4000001 	svc	#0x0
 ret
    4944:	d65f03c0 	ret

0000000000004948 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
    4948:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
    494c:	d4000001 	svc	#0x0
 ret
    4950:	d65f03c0 	ret

0000000000004954 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
    4954:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
    4958:	d4000001 	svc	#0x0
 ret
    495c:	d65f03c0 	ret

0000000000004960 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
    4960:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
    4964:	d4000001 	svc	#0x0
 ret
    4968:	d65f03c0 	ret

000000000000496c <socket>:
.global socket
socket:
 mov x7, #SYS_socket
    496c:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
    4970:	d4000001 	svc	#0x0
 ret
    4974:	d65f03c0 	ret

0000000000004978 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
    4978:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
    497c:	d4000001 	svc	#0x0
 ret
    4980:	d65f03c0 	ret

0000000000004984 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
    4984:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
    4988:	d4000001 	svc	#0x0
 ret
    498c:	d65f03c0 	ret

0000000000004990 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
    4990:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
    4994:	d4000001 	svc	#0x0
 ret
    4998:	d65f03c0 	ret

000000000000499c <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
    499c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
    49a0:	52800022 	mov	w2, #0x1                   	// #1
{
    49a4:	910003fd 	mov	x29, sp
    49a8:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
    49ac:	91007fe1 	add	x1, sp, #0x1f
    49b0:	97ffff2f 	bl	466c <write>
    49b4:	7100041f 	cmp	w0, #0x1
}
    49b8:	1a9f17e0 	cset	w0, eq	// eq = none
    49bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    49c0:	d65f03c0 	ret

00000000000049c4 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
    49c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    49c8:	910003fd 	mov	x29, sp
    49cc:	a90153f3 	stp	x19, x20, [sp, #16]
    49d0:	a9025bf5 	stp	x21, x22, [sp, #32]
    49d4:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    49d8:	6a417c7f 	tst	w3, w1, lsr #31
    49dc:	54000300 	b.eq	4a3c <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
    49e0:	4b0103e1 	neg	w1, w1
    neg = 1;
    49e4:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
    49e8:	f0000003 	adrp	x3, 7000 <malloc+0x20e4>
    49ec:	9108c063 	add	x3, x3, #0x230
    49f0:	9100c3f5 	add	x21, sp, #0x30
    49f4:	d2800000 	mov	x0, #0x0                   	// #0
    49f8:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
    49fc:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
    4a00:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
    4a04:	2a0403e1 	mov	w1, w4
    4a08:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
    4a0c:	38666866 	ldrb	w6, [x3, x6]
    4a10:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
    4a14:	91000400 	add	x0, x0, #0x1
    4a18:	54ffff09 	b.ls	49f8 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
    4a1c:	11000493 	add	w19, w4, #0x1
  if(neg)
    4a20:	34000085 	cbz	w5, 4a30 <printint+0x6c>
    buf[i++] = '-';
    4a24:	528005a0 	mov	w0, #0x2d                  	// #45
    4a28:	38334aa0 	strb	w0, [x21, w19, uxtw]
    4a2c:	11000893 	add	w19, w4, #0x2
    4a30:	51000673 	sub	w19, w19, #0x1
    4a34:	52800014 	mov	w20, #0x0                   	// #0
    4a38:	14000008 	b	4a58 <printint+0x94>
  neg = 0;
    4a3c:	52800005 	mov	w5, #0x0                   	// #0
    4a40:	17ffffea 	b	49e8 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
    4a44:	38736aa1 	ldrb	w1, [x21, x19]
    4a48:	2a1603e0 	mov	w0, w22
    4a4c:	d1000673 	sub	x19, x19, #0x1
    4a50:	97ffffd3 	bl	499c <putc>
    4a54:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
    4a58:	3100067f 	cmn	w19, #0x1
    4a5c:	54ffff41 	b.ne	4a44 <printint+0x80>  // b.any
  return written;
}
    4a60:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a64:	2a1403e0 	mov	w0, w20
    4a68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4a70:	d65f03c0 	ret

0000000000004a74 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
    4a74:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4a78:	910003fd 	mov	x29, sp
    4a7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a80:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
    4a84:	52800015 	mov	w21, #0x0                   	// #0
{
    4a88:	a90363f7 	stp	x23, x24, [sp, #48]
    4a8c:	2a0003f7 	mov	w23, w0
    4a90:	a9046bf9 	stp	x25, x26, [sp, #64]
    4a94:	aa0103f9 	mov	x25, x1

  state = 0;
    4a98:	52800001 	mov	w1, #0x0                   	// #0
{
    4a9c:	a90573fb 	stp	x27, x28, [sp, #80]
    4aa0:	a9406053 	ldp	x19, x24, [x2]
    4aa4:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
    4aa8:	39400320 	ldrb	w0, [x25]
    4aac:	35000120 	cbnz	w0, 4ad0 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
    4ab0:	2a1503e0 	mov	w0, w21
    4ab4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ab8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4abc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ac0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ac4:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ac8:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4acc:	d65f03c0 	ret
    c = fmt[i] & 0xff;
    4ad0:	2a0003f6 	mov	w22, w0
    if(state == 0){
    4ad4:	35000101 	cbnz	w1, 4af4 <vprintf+0x80>
      if(c == '%'){
    4ad8:	7100941f 	cmp	w0, #0x25
    4adc:	54000ba0 	b.eq	4c50 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
    4ae0:	2a1603e1 	mov	w1, w22
    4ae4:	2a1703e0 	mov	w0, w23
    4ae8:	97ffffad 	bl	499c <putc>
    4aec:	0b0002b5 	add	w21, w21, w0
    4af0:	14000057 	b	4c4c <vprintf+0x1d8>
      if(c == 'd'){
    4af4:	7101901f 	cmp	w0, #0x64
    4af8:	540002a1 	b.ne	4b4c <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
    4afc:	37f80174 	tbnz	w20, #31, 4b28 <vprintf+0xb4>
    4b00:	91002e76 	add	x22, x19, #0xb
    4b04:	2a1403fa 	mov	w26, w20
    4b08:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4b0c:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    4b10:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
    4b14:	b9400261 	ldr	w1, [x19]
    4b18:	2a1703e0 	mov	w0, w23
    4b1c:	97ffffaa 	bl	49c4 <printint>
        written += putc(fd, va_arg(ap, uint));
    4b20:	0b0002b5 	add	w21, w21, w0
    4b24:	14000048 	b	4c44 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
    4b28:	1100229a 	add	w26, w20, #0x8
    4b2c:	7100035f 	cmp	w26, #0x0
    4b30:	5400008d 	b.le	4b40 <vprintf+0xcc>
    4b34:	91002e76 	add	x22, x19, #0xb
    4b38:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4b3c:	17fffff4 	b	4b0c <vprintf+0x98>
    4b40:	aa1303f6 	mov	x22, x19
    4b44:	8b34c313 	add	x19, x24, w20, sxtw
    4b48:	17fffff1 	b	4b0c <vprintf+0x98>
      } else if(c == 'l') {
    4b4c:	7101b01f 	cmp	w0, #0x6c
    4b50:	54000201 	b.ne	4b90 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    4b54:	37f800d4 	tbnz	w20, #31, 4b6c <vprintf+0xf8>
    4b58:	91003e76 	add	x22, x19, #0xf
    4b5c:	2a1403fa 	mov	w26, w20
    4b60:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4b64:	52800003 	mov	w3, #0x0                   	// #0
    4b68:	17ffffea 	b	4b10 <vprintf+0x9c>
    4b6c:	1100229a 	add	w26, w20, #0x8
    4b70:	7100035f 	cmp	w26, #0x0
    4b74:	5400008d 	b.le	4b84 <vprintf+0x110>
    4b78:	91003e76 	add	x22, x19, #0xf
    4b7c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4b80:	17fffff9 	b	4b64 <vprintf+0xf0>
    4b84:	aa1303f6 	mov	x22, x19
    4b88:	8b34c313 	add	x19, x24, w20, sxtw
    4b8c:	17fffff6 	b	4b64 <vprintf+0xf0>
      } else if(c == 'x') {
    4b90:	7101e01f 	cmp	w0, #0x78
    4b94:	54000221 	b.ne	4bd8 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
    4b98:	37f800f4 	tbnz	w20, #31, 4bb4 <vprintf+0x140>
    4b9c:	91002e76 	add	x22, x19, #0xb
    4ba0:	2a1403fa 	mov	w26, w20
    4ba4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4ba8:	52800003 	mov	w3, #0x0                   	// #0
    4bac:	52800202 	mov	w2, #0x10                  	// #16
    4bb0:	17ffffd9 	b	4b14 <vprintf+0xa0>
    4bb4:	1100229a 	add	w26, w20, #0x8
    4bb8:	7100035f 	cmp	w26, #0x0
    4bbc:	5400008d 	b.le	4bcc <vprintf+0x158>
    4bc0:	91002e76 	add	x22, x19, #0xb
    4bc4:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4bc8:	17fffff8 	b	4ba8 <vprintf+0x134>
    4bcc:	aa1303f6 	mov	x22, x19
    4bd0:	8b34c313 	add	x19, x24, w20, sxtw
    4bd4:	17fffff5 	b	4ba8 <vprintf+0x134>
      } else if(c == 'p') {
    4bd8:	7101c01f 	cmp	w0, #0x70
    4bdc:	54000521 	b.ne	4c80 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    4be0:	37f803f4 	tbnz	w20, #31, 4c5c <vprintf+0x1e8>
    4be4:	91003e76 	add	x22, x19, #0xf
    4be8:	2a1403fa 	mov	w26, w20
    4bec:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4bf0:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
    4bf4:	52800601 	mov	w1, #0x30                  	// #48
    4bf8:	2a1703e0 	mov	w0, w23
    4bfc:	97ffff68 	bl	499c <putc>
    4c00:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    4c04:	f000001c 	adrp	x28, 7000 <malloc+0x20e4>
    4c08:	9108c39c 	add	x28, x28, #0x230
  written += putc(fd, 'x');
    4c0c:	2a1703e0 	mov	w0, w23
    4c10:	52800f01 	mov	w1, #0x78                  	// #120
    4c14:	97ffff62 	bl	499c <putc>
    4c18:	0b000273 	add	w19, w19, w0
    4c1c:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    4c20:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    4c24:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    4c28:	38606b81 	ldrb	w1, [x28, x0]
    4c2c:	2a1703e0 	mov	w0, w23
    4c30:	97ffff5b 	bl	499c <putc>
    4c34:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    4c38:	71000694 	subs	w20, w20, #0x1
    4c3c:	54ffff21 	b.ne	4c20 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    4c40:	0b1302b5 	add	w21, w21, w19
    4c44:	2a1a03f4 	mov	w20, w26
    4c48:	aa1603f3 	mov	x19, x22
      state = 0;
    4c4c:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
    4c50:	91000739 	add	x25, x25, #0x1
  state = 0;
    4c54:	2a1603e1 	mov	w1, w22
    4c58:	17ffff94 	b	4aa8 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
    4c5c:	1100229a 	add	w26, w20, #0x8
    4c60:	7100035f 	cmp	w26, #0x0
    4c64:	5400008d 	b.le	4c74 <vprintf+0x200>
    4c68:	91003e76 	add	x22, x19, #0xf
    4c6c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4c70:	17ffffe0 	b	4bf0 <vprintf+0x17c>
    4c74:	aa1303f6 	mov	x22, x19
    4c78:	8b34c313 	add	x19, x24, w20, sxtw
    4c7c:	17ffffdd 	b	4bf0 <vprintf+0x17c>
      } else if(c == 's'){
    4c80:	7101cc1f 	cmp	w0, #0x73
    4c84:	54000381 	b.ne	4cf4 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
    4c88:	37f80214 	tbnz	w20, #31, 4cc8 <vprintf+0x254>
    4c8c:	91003e61 	add	x1, x19, #0xf
    4c90:	aa1303e0 	mov	x0, x19
    4c94:	927df033 	and	x19, x1, #0xfffffffffffffff8
    4c98:	f9400016 	ldr	x22, [x0]
          s = "(null)";
    4c9c:	d0000000 	adrp	x0, 6000 <malloc+0x10e4>
    4ca0:	9137d400 	add	x0, x0, #0xdf5
    4ca4:	f10002df 	cmp	x22, #0x0
    4ca8:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
    4cac:	394002c1 	ldrb	w1, [x22]
    4cb0:	34fffce1 	cbz	w1, 4c4c <vprintf+0x1d8>
          written += putc(fd, *s);
    4cb4:	2a1703e0 	mov	w0, w23
          s++;
    4cb8:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
    4cbc:	97ffff38 	bl	499c <putc>
    4cc0:	0b0002b5 	add	w21, w21, w0
          s++;
    4cc4:	17fffffa 	b	4cac <vprintf+0x238>
        s = va_arg(ap, char*);
    4cc8:	11002281 	add	w1, w20, #0x8
    4ccc:	7100003f 	cmp	w1, #0x0
    4cd0:	540000cd 	b.le	4ce8 <vprintf+0x274>
    4cd4:	91003e62 	add	x2, x19, #0xf
    4cd8:	aa1303e0 	mov	x0, x19
    4cdc:	2a0103f4 	mov	w20, w1
    4ce0:	927df053 	and	x19, x2, #0xfffffffffffffff8
    4ce4:	17ffffed 	b	4c98 <vprintf+0x224>
    4ce8:	8b34c300 	add	x0, x24, w20, sxtw
    4cec:	2a0103f4 	mov	w20, w1
    4cf0:	17ffffea 	b	4c98 <vprintf+0x224>
      } else if(c == 'c'){
    4cf4:	71018c1f 	cmp	w0, #0x63
    4cf8:	54000241 	b.ne	4d40 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
    4cfc:	37f80114 	tbnz	w20, #31, 4d1c <vprintf+0x2a8>
    4d00:	91002e76 	add	x22, x19, #0xb
    4d04:	2a1403fa 	mov	w26, w20
    4d08:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4d0c:	39400261 	ldrb	w1, [x19]
    4d10:	2a1703e0 	mov	w0, w23
    4d14:	97ffff22 	bl	499c <putc>
    4d18:	17ffff82 	b	4b20 <vprintf+0xac>
    4d1c:	1100229a 	add	w26, w20, #0x8
    4d20:	7100035f 	cmp	w26, #0x0
    4d24:	5400008d 	b.le	4d34 <vprintf+0x2c0>
    4d28:	91002e76 	add	x22, x19, #0xb
    4d2c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    4d30:	17fffff7 	b	4d0c <vprintf+0x298>
    4d34:	aa1303f6 	mov	x22, x19
    4d38:	8b34c313 	add	x19, x24, w20, sxtw
    4d3c:	17fffff4 	b	4d0c <vprintf+0x298>
      } else if(c == '%'){
    4d40:	7100941f 	cmp	w0, #0x25
    4d44:	54ffece0 	b.eq	4ae0 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
    4d48:	2a1703e0 	mov	w0, w23
    4d4c:	528004a1 	mov	w1, #0x25                  	// #37
    4d50:	97ffff13 	bl	499c <putc>
    4d54:	0b0002b5 	add	w21, w21, w0
    4d58:	17ffff62 	b	4ae0 <vprintf+0x6c>

0000000000004d5c <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
    4d5c:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4d60:	910003fd 	mov	x29, sp
    4d64:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
    4d68:	910203e2 	add	x2, sp, #0x80
    4d6c:	a9030be2 	stp	x2, x2, [sp, #48]
    4d70:	910143e2 	add	x2, sp, #0x50
    4d74:	f90023e2 	str	x2, [sp, #64]
    4d78:	128005e2 	mov	w2, #0xffffffd0            	// #-48
    4d7c:	b9004be2 	str	w2, [sp, #72]
    4d80:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
    4d84:	a9430fe2 	ldp	x2, x3, [sp, #48]
    4d88:	a9010fe2 	stp	x2, x3, [sp, #16]
    4d8c:	a9440fe2 	ldp	x2, x3, [sp, #64]
    4d90:	a9020fe2 	stp	x2, x3, [sp, #32]
    4d94:	910043e2 	add	x2, sp, #0x10
{
    4d98:	a90617e4 	stp	x4, x5, [sp, #96]
    4d9c:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
    4da0:	97ffff35 	bl	4a74 <vprintf>
  va_end(ap);
  return result;
}
    4da4:	a8c87bfd 	ldp	x29, x30, [sp], #128
    4da8:	d65f03c0 	ret

0000000000004dac <printf>:

int
printf(const char *fmt, ...)
{
    4dac:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    4db0:	910003fd 	mov	x29, sp
    4db4:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
    4db8:	910243e1 	add	x1, sp, #0x90
    4dbc:	a90307e1 	stp	x1, x1, [sp, #48]
    4dc0:	910143e1 	add	x1, sp, #0x50
    4dc4:	f90023e1 	str	x1, [sp, #64]
    4dc8:	128006e1 	mov	w1, #0xffffffc8            	// #-56
    4dcc:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
    4dd0:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
    4dd4:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
    4dd8:	52800020 	mov	w0, #0x1                   	// #1
{
    4ddc:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
    4de0:	a9430fe2 	ldp	x2, x3, [sp, #48]
    4de4:	a9010fe2 	stp	x2, x3, [sp, #16]
    4de8:	a9440fe2 	ldp	x2, x3, [sp, #64]
    4dec:	a9020fe2 	stp	x2, x3, [sp, #32]
    4df0:	910043e2 	add	x2, sp, #0x10
{
    4df4:	a9079be5 	stp	x5, x6, [sp, #120]
    4df8:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
    4dfc:	97ffff1e 	bl	4a74 <vprintf>
  va_end(ap);
  return result;
}
    4e00:	a8c97bfd 	ldp	x29, x30, [sp], #144
    4e04:	d65f03c0 	ret

0000000000004e08 <free_locked>:
free_locked(void *ap)
{
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    4e08:	b0000045 	adrp	x5, d000 <buf+0x25a7>
    4e0c:	f94530a2 	ldr	x2, [x5, #2656]
  bp = (Header*)ap - 1;
    4e10:	d1004003 	sub	x3, x0, #0x10
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    4e14:	f9400041 	ldr	x1, [x2]
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    4e18:	eb03005f 	cmp	x2, x3
    4e1c:	54000342 	b.cs	4e84 <free_locked+0x7c>  // b.hs, b.nlast
    4e20:	eb01007f 	cmp	x3, x1
    4e24:	540002a2 	b.cs	4e78 <free_locked+0x70>  // b.hs, b.nlast
      break;
  if(bp + bp->s.size == p->s.ptr){
    4e28:	b85f8006 	ldur	w6, [x0, #-8]
    4e2c:	8b265064 	add	x4, x3, w6, uxtw #4
    4e30:	eb04003f 	cmp	x1, x4
    4e34:	540000a1 	b.ne	4e48 <free_locked+0x40>  // b.any
    bp->s.size += p->s.ptr->s.size;
    4e38:	b9400824 	ldr	w4, [x1, #8]
    bp->s.ptr = p->s.ptr->s.ptr;
    4e3c:	f9400021 	ldr	x1, [x1]
    bp->s.size += p->s.ptr->s.size;
    4e40:	0b060084 	add	w4, w4, w6
    4e44:	b81f8004 	stur	w4, [x0, #-8]
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    4e48:	b9400844 	ldr	w4, [x2, #8]
    4e4c:	f81f0001 	stur	x1, [x0, #-16]
    4e50:	8b245046 	add	x6, x2, w4, uxtw #4
    4e54:	eb06007f 	cmp	x3, x6
    4e58:	540000a1 	b.ne	4e6c <free_locked+0x64>  // b.any
    p->s.size += bp->s.size;
    4e5c:	b85f8000 	ldur	w0, [x0, #-8]
    p->s.ptr = bp->s.ptr;
    4e60:	aa0103e3 	mov	x3, x1
    p->s.size += bp->s.size;
    4e64:	0b040000 	add	w0, w0, w4
    4e68:	b9000840 	str	w0, [x2, #8]
  } else
    p->s.ptr = bp;
  freep = p;
    4e6c:	f90530a2 	str	x2, [x5, #2656]
    4e70:	f9000043 	str	x3, [x2]
}
    4e74:	d65f03c0 	ret
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    4e78:	eb01005f 	cmp	x2, x1
    4e7c:	540000c3 	b.cc	4e94 <free_locked+0x8c>  // b.lo, b.ul, b.last
    4e80:	17ffffea 	b	4e28 <free_locked+0x20>
    4e84:	eb01005f 	cmp	x2, x1
    4e88:	54000063 	b.cc	4e94 <free_locked+0x8c>  // b.lo, b.ul, b.last
    4e8c:	eb01007f 	cmp	x3, x1
    4e90:	54fffcc3 	b.cc	4e28 <free_locked+0x20>  // b.lo, b.ul, b.last
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    4e94:	aa0103e2 	mov	x2, x1
    4e98:	17ffffdf 	b	4e14 <free_locked+0xc>

0000000000004e9c <heap_acquire>:
{
    4e9c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4ea0:	910003fd 	mov	x29, sp
    4ea4:	a90153f3 	stp	x19, x20, [sp, #16]
    asm volatile("ldaxr %w0, [%1]"
    4ea8:	b0000053 	adrp	x19, d000 <buf+0x25a7>
    4eac:	91298273 	add	x19, x19, #0xa60
    4eb0:	91002273 	add	x19, x19, #0x8
      asm volatile("stxr %w0, %w1, [%2]"
    4eb4:	52800034 	mov	w20, #0x1                   	// #1
    asm volatile("ldaxr %w0, [%1]"
    4eb8:	885ffe60 	ldaxr	w0, [x19]
    if(old == 0){
    4ebc:	350000c0 	cbnz	w0, 4ed4 <heap_acquire+0x38>
      asm volatile("stxr %w0, %w1, [%2]"
    4ec0:	88007e74 	stxr	w0, w20, [x19]
      if(failed == 0)
    4ec4:	350000a0 	cbnz	w0, 4ed8 <heap_acquire+0x3c>
}
    4ec8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ecc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4ed0:	d65f03c0 	ret
      asm volatile("clrex" ::: "memory");
    4ed4:	d5033f5f 	clrex
    sched_yield();
    4ed8:	97fffe90 	bl	4918 <sched_yield>
  for(;;){
    4edc:	17fffff7 	b	4eb8 <heap_acquire+0x1c>

0000000000004ee0 <free>:

void
free(void *ap)
{
  if(ap == 0)
    4ee0:	b40001c0 	cbz	x0, 4f18 <free+0x38>
{
    4ee4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4ee8:	910003fd 	mov	x29, sp
    4eec:	f9000fe0 	str	x0, [sp, #24]
    return;
  heap_acquire();
    4ef0:	97ffffeb 	bl	4e9c <heap_acquire>
  free_locked(ap);
    4ef4:	f9400fe0 	ldr	x0, [sp, #24]
    4ef8:	97ffffc4 	bl	4e08 <free_locked>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    4efc:	b0000040 	adrp	x0, d000 <buf+0x25a7>
    4f00:	91298000 	add	x0, x0, #0xa60
    4f04:	52800001 	mov	w1, #0x0                   	// #0
    4f08:	91002000 	add	x0, x0, #0x8
    4f0c:	889ffc01 	stlr	w1, [x0]
  heap_release();
}
    4f10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4f14:	d65f03c0 	ret
    4f18:	d65f03c0 	ret

0000000000004f1c <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    4f1c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f20:	910003fd 	mov	x29, sp
    4f24:	a90153f3 	stp	x19, x20, [sp, #16]
  Header *p, *prevp;
  uint nunits;

  heap_acquire();
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    4f28:	2a0003f3 	mov	w19, w0
    4f2c:	91003e73 	add	x19, x19, #0xf
{
    4f30:	a9025bf5 	stp	x21, x22, [sp, #32]
  if((prevp = freep) == 0){
    4f34:	b0000056 	adrp	x22, d000 <buf+0x25a7>
    4f38:	912982d4 	add	x20, x22, #0xa60
{
    4f3c:	f9001bf7 	str	x23, [sp, #48]
  heap_acquire();
    4f40:	97ffffd7 	bl	4e9c <heap_acquire>
  if((prevp = freep) == 0){
    4f44:	f94532c1 	ldr	x1, [x22, #2656]
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    4f48:	d344fe73 	lsr	x19, x19, #4
    4f4c:	11000673 	add	w19, w19, #0x1
  if((prevp = freep) == 0){
    4f50:	b50000a1 	cbnz	x1, 4f64 <malloc+0x48>
    base.s.ptr = freep = prevp = &base;
    4f54:	91004281 	add	x1, x20, #0x10
    4f58:	f90532c1 	str	x1, [x22, #2656]
    4f5c:	f9000a81 	str	x1, [x20, #16]
    base.s.size = 0;
    4f60:	b9001a9f 	str	wzr, [x20, #24]
  if(nu < 4096)
    4f64:	7140067f 	cmp	w19, #0x1, lsl #12
    4f68:	52820015 	mov	w21, #0x1000                	// #4096
    4f6c:	1a952275 	csel	w21, w19, w21, cs	// cs = hs, nlast
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    4f70:	f9400020 	ldr	x0, [x1]
  p = sbrk(nu * sizeof(Header));
    4f74:	531c6eb7 	lsl	w23, w21, #4
    if(p->s.size >= nunits){
    4f78:	b9400802 	ldr	w2, [x0, #8]
    4f7c:	6b13005f 	cmp	w2, w19
    4f80:	54000263 	b.cc	4fcc <malloc+0xb0>  // b.lo, b.ul, b.last
      if(p->s.size == nunits)
    4f84:	540001a1 	b.ne	4fb8 <malloc+0x9c>  // b.any
        prevp->s.ptr = p->s.ptr;
    4f88:	f9400002 	ldr	x2, [x0]
    4f8c:	f9000022 	str	x2, [x1]
      else {
        p->s.size -= nunits;
        p += p->s.size;
        p->s.size = nunits;
      }
      freep = prevp;
    4f90:	f90532c1 	str	x1, [x22, #2656]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    4f94:	91002294 	add	x20, x20, #0x8
    4f98:	52800001 	mov	w1, #0x0                   	// #0
    4f9c:	889ffe81 	stlr	w1, [x20]
      heap_release();
      return (void*)(p + 1);
    4fa0:	91004000 	add	x0, x0, #0x10
      if((p = morecore(nunits)) == 0){
        heap_release();
        return 0;
      }
  }
}
    4fa4:	f9401bf7 	ldr	x23, [sp, #48]
    4fa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fb0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4fb4:	d65f03c0 	ret
        p->s.size -= nunits;
    4fb8:	4b130042 	sub	w2, w2, w19
    4fbc:	b9000802 	str	w2, [x0, #8]
        p += p->s.size;
    4fc0:	8b225000 	add	x0, x0, w2, uxtw #4
        p->s.size = nunits;
    4fc4:	b9000813 	str	w19, [x0, #8]
    4fc8:	17fffff2 	b	4f90 <malloc+0x74>
    if(p == freep)
    4fcc:	f9400281 	ldr	x1, [x20]
    4fd0:	eb00003f 	cmp	x1, x0
    4fd4:	540001e1 	b.ne	5010 <malloc+0xf4>  // b.any
  p = sbrk(nu * sizeof(Header));
    4fd8:	2a1703e0 	mov	w0, w23
    4fdc:	97fffdcb 	bl	4708 <sbrk>
  if(p == (char*)-1)
    4fe0:	b100041f 	cmn	x0, #0x1
    4fe4:	540000c1 	b.ne	4ffc <malloc+0xe0>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    4fe8:	91002294 	add	x20, x20, #0x8
    4fec:	52800000 	mov	w0, #0x0                   	// #0
    4ff0:	889ffe80 	stlr	w0, [x20]
        return 0;
    4ff4:	d2800000 	mov	x0, #0x0                   	// #0
    4ff8:	17ffffeb 	b	4fa4 <malloc+0x88>
  hp->s.size = nu;
    4ffc:	b9000815 	str	w21, [x0, #8]
  free_locked((void*)(hp + 1));
    5000:	91004000 	add	x0, x0, #0x10
    5004:	97ffff81 	bl	4e08 <free_locked>
  return freep;
    5008:	f9400280 	ldr	x0, [x20]
      if((p = morecore(nunits)) == 0){
    500c:	b4fffee0 	cbz	x0, 4fe8 <malloc+0xcc>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    5010:	aa0003e1 	mov	x1, x0
    5014:	f9400000 	ldr	x0, [x0]
    if(p->s.size >= nunits){
    5018:	17ffffd8 	b	4f78 <malloc+0x5c>
