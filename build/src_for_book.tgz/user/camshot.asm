
user/_camshot:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  exit(1);
}

int
main(int argc, char *argv[])
{
       0:	d10483ff 	sub	sp, sp, #0x120
       4:	a9027bfd 	stp	x29, x30, [sp, #32]
       8:	910083fd 	add	x29, sp, #0x20
       c:	a90563f7 	stp	x23, x24, [sp, #80]
      10:	2a0003f7 	mov	w23, w0
  char *out = "/boot/camera.bmp", *raw = 0, *in = 0;
      14:	b0000000 	adrp	x0, 1000 <sched_setscheduler+0x4>
      18:	911df400 	add	x0, x0, #0x77d
{
      1c:	a90353f3 	stp	x19, x20, [sp, #48]
      20:	aa0103f4 	mov	x20, x1
      24:	a90773fb 	stp	x27, x28, [sp, #112]
  int pattern = 0, wb = 1, half = 0, fd, n;

  for(int i = 1; i < argc; i++){
      28:	5280003c 	mov	w28, #0x1                   	// #1
  int pattern = 0, wb = 1, half = 0, fd, n;
      2c:	2a1c03fb 	mov	w27, w28
  char *out = "/boot/camera.bmp", *raw = 0, *in = 0;
      30:	f90047e0 	str	x0, [sp, #136]
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
      34:	b0000000 	adrp	x0, 1000 <sched_setscheduler+0x4>
      38:	911e3800 	add	x0, x0, #0x78e
  int pattern = 0, wb = 1, half = 0, fd, n;
      3c:	52800013 	mov	w19, #0x0                   	// #0
  char *out = "/boot/camera.bmp", *raw = 0, *in = 0;
      40:	d2800018 	mov	x24, #0x0                   	// #0
{
      44:	a9045bf5 	stp	x21, x22, [sp, #64]
  char *out = "/boot/camera.bmp", *raw = 0, *in = 0;
      48:	d2800016 	mov	x22, #0x0                   	// #0
{
      4c:	a9066bf9 	stp	x25, x26, [sp, #96]
  int pattern = 0, wb = 1, half = 0, fd, n;
      50:	b90097ff 	str	wzr, [sp, #148]
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
      54:	f9004fe0 	str	x0, [sp, #152]
    else if(strcmp(argv[i], "-r") == 0 && i + 1 < argc) raw = argv[++i];
      58:	b000001a 	adrp	x26, 1000 <sched_setscheduler+0x4>
      5c:	911e4740 	add	x0, x26, #0x791
      60:	f90053e0 	str	x0, [sp, #160]
  for(int i = 1; i < argc; i++){
      64:	6b17039f 	cmp	w28, w23
      68:	540001ab 	b.lt	9c <main+0x9c>  // b.tstop
    else if(strcmp(argv[i], "-t") == 0 && i + 1 < argc) pattern = atoi(argv[++i]);
    else if(strcmp(argv[i], "-w") == 0) wb = 0;
    else if(strcmp(argv[i], "-s") == 0) half = 1;
    else usage();
  }
  if(pattern < 0 || pattern > 3)
      6c:	71000e7f 	cmp	w19, #0x3
      70:	540007e8 	b.hi	16c <main+0x16c>  // b.pmore
    usage();

  uchar *frame = malloc(CAM_READ_MAX);
      74:	52800500 	mov	w0, #0x28                  	// #40
      78:	72a00100 	movk	w0, #0x8, lsl #16
      7c:	9400056d 	bl	1630 <malloc>
      80:	aa0003f5 	mov	x21, x0
  if(frame == 0){
      84:	b5000800 	cbnz	x0, 184 <main+0x184>
    fprintf(2, "camshot: out of memory\n");
      88:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
      8c:	911e8021 	add	x1, x1, #0x7a0
    }
    close(fd);
  }
  struct cam_frame_hdr *hdr = (struct cam_frame_hdr *)frame;
  if(n < (int)sizeof(*hdr) || hdr->magic != CAM_MAGIC){
    fprintf(2, "camshot: capture failed (see kernel log)\n");
      90:	52800040 	mov	w0, #0x2                   	// #2
      94:	940004f7 	bl	1470 <fprintf>
    exit(1);
      98:	14000046 	b	1b0 <main+0x1b0>
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
      9c:	937d7f95 	sbfiz	x21, x28, #3, #32
      a0:	8b3cce99 	add	x25, x20, w28, sxtw #3
      a4:	f9404fe1 	ldr	x1, [sp, #152]
      a8:	1100079a 	add	w26, w28, #0x1
      ac:	f8756a80 	ldr	x0, [x20, x21]
      b0:	94000286 	bl	ac8 <strcmp>
      b4:	35000100 	cbnz	w0, d4 <main+0xd4>
      b8:	6b17035f 	cmp	w26, w23
      bc:	540000ca 	b.ge	d4 <main+0xd4>  // b.tcont
      c0:	f9400720 	ldr	x0, [x25, #8]
      c4:	f90047e0 	str	x0, [sp, #136]
    else if(strcmp(argv[i], "-t") == 0 && i + 1 < argc) pattern = atoi(argv[++i]);
      c8:	2a1a03fc 	mov	w28, w26
  for(int i = 1; i < argc; i++){
      cc:	1100079c 	add	w28, w28, #0x1
      d0:	17ffffe5 	b	64 <main+0x64>
    else if(strcmp(argv[i], "-r") == 0 && i + 1 < argc) raw = argv[++i];
      d4:	f8756a80 	ldr	x0, [x20, x21]
      d8:	f94053e1 	ldr	x1, [sp, #160]
      dc:	9400027b 	bl	ac8 <strcmp>
      e0:	350000a0 	cbnz	w0, f4 <main+0xf4>
      e4:	6b17035f 	cmp	w26, w23
      e8:	5400006a 	b.ge	f4 <main+0xf4>  // b.tcont
      ec:	f9400736 	ldr	x22, [x25, #8]
      f0:	17fffff6 	b	c8 <main+0xc8>
    else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc) in = argv[++i];
      f4:	b0000000 	adrp	x0, 1000 <sched_setscheduler+0x4>
      f8:	911e5001 	add	x1, x0, #0x794
      fc:	f8756a80 	ldr	x0, [x20, x21]
     100:	94000272 	bl	ac8 <strcmp>
     104:	350000a0 	cbnz	w0, 118 <main+0x118>
     108:	6b17035f 	cmp	w26, w23
     10c:	5400006a 	b.ge	118 <main+0x118>  // b.tcont
     110:	f9400738 	ldr	x24, [x25, #8]
     114:	17ffffed 	b	c8 <main+0xc8>
    else if(strcmp(argv[i], "-t") == 0 && i + 1 < argc) pattern = atoi(argv[++i]);
     118:	f8756a80 	ldr	x0, [x20, x21]
     11c:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     120:	911e5c21 	add	x1, x1, #0x797
     124:	94000269 	bl	ac8 <strcmp>
     128:	350000e0 	cbnz	w0, 144 <main+0x144>
     12c:	6b17035f 	cmp	w26, w23
     130:	540000aa 	b.ge	144 <main+0x144>  // b.tcont
     134:	f9400720 	ldr	x0, [x25, #8]
     138:	940002d1 	bl	c7c <atoi>
     13c:	2a0003f3 	mov	w19, w0
     140:	17ffffe2 	b	c8 <main+0xc8>
    else if(strcmp(argv[i], "-w") == 0) wb = 0;
     144:	f8756a80 	ldr	x0, [x20, x21]
     148:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     14c:	911e6821 	add	x1, x1, #0x79a
     150:	9400025e 	bl	ac8 <strcmp>
     154:	340000e0 	cbz	w0, 170 <main+0x170>
    else if(strcmp(argv[i], "-s") == 0) half = 1;
     158:	f8756a80 	ldr	x0, [x20, x21]
     15c:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     160:	911e7421 	add	x1, x1, #0x79d
     164:	94000259 	bl	ac8 <strcmp>
     168:	34000080 	cbz	w0, 178 <main+0x178>
    else usage();
     16c:	9400022c 	bl	a1c <usage>
    else if(strcmp(argv[i], "-w") == 0) wb = 0;
     170:	5280001b 	mov	w27, #0x0                   	// #0
     174:	17ffffd6 	b	cc <main+0xcc>
    else if(strcmp(argv[i], "-s") == 0) half = 1;
     178:	52800020 	mov	w0, #0x1                   	// #1
     17c:	b90097e0 	str	w0, [sp, #148]
     180:	17ffffd3 	b	cc <main+0xcc>
  if(in){
     184:	b40004f8 	cbz	x24, 220 <main+0x220>
    if((fd = open(in, O_RDONLY)) < 0){
     188:	aa1803e0 	mov	x0, x24
     18c:	52800001 	mov	w1, #0x0                   	// #0
     190:	94000308 	bl	db0 <open>
     194:	2a0003f3 	mov	w19, w0
     198:	36f80100 	tbz	w0, #31, 1b8 <main+0x1b8>
      fprintf(2, "camshot: cannot open %s\n", in);
     19c:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     1a0:	911ee021 	add	x1, x1, #0x7b8
     1a4:	aa1803e2 	mov	x2, x24
     1a8:	52800040 	mov	w0, #0x2                   	// #2
     1ac:	940004b1 	bl	1470 <fprintf>
      exit(1);
     1b0:	52800020 	mov	w0, #0x1                   	// #1
     1b4:	940002e7 	bl	d50 <exit>
               (m = read(fd, frame + n, CAM_READ_MAX - n)) > 0; )
     1b8:	52800517 	mov	w23, #0x28                  	// #40
     1bc:	72a00117 	movk	w23, #0x8, lsl #16
    for(int m; n < (int)CAM_READ_MAX &&
     1c0:	528004f8 	mov	w24, #0x27                  	// #39
     1c4:	72a00118 	movk	w24, #0x8, lsl #16
    n = 0;
     1c8:	52800014 	mov	w20, #0x0                   	// #0
               (m = read(fd, frame + n, CAM_READ_MAX - n)) > 0; )
     1cc:	4b1402e2 	sub	w2, w23, w20
     1d0:	8b34c2a1 	add	x1, x21, w20, sxtw
     1d4:	2a1303e0 	mov	w0, w19
     1d8:	940002e7 	bl	d74 <read>
    for(int m; n < (int)CAM_READ_MAX &&
     1dc:	7100001f 	cmp	w0, #0x0
     1e0:	5400008d 	b.le	1f0 <main+0x1f0>
      n += m;
     1e4:	0b000294 	add	w20, w20, w0
    for(int m; n < (int)CAM_READ_MAX &&
     1e8:	6b18029f 	cmp	w20, w24
     1ec:	54ffff0d 	b.le	1cc <main+0x1cc>
    close(fd);
     1f0:	2a1303e0 	mov	w0, w19
    close(fd);
     1f4:	940002e6 	bl	d8c <close>
  if(n < (int)sizeof(*hdr) || hdr->magic != CAM_MAGIC){
     1f8:	71009e9f 	cmp	w20, #0x27
     1fc:	540000cd 	b.le	214 <main+0x214>
     200:	b94002a1 	ldr	w1, [x21]
     204:	52882860 	mov	w0, #0x4143                	// #16707
     208:	72a629a0 	movk	w0, #0x314d, lsl #16
     20c:	6b00003f 	cmp	w1, w0
     210:	54000660 	b.eq	2dc <main+0x2dc>  // b.none
    fprintf(2, "camshot: capture failed (see kernel log)\n");
     214:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     218:	91213021 	add	x1, x1, #0x84c
     21c:	17ffff9d 	b	90 <main+0x90>
    if((fd = open("/dev/video0", O_RDWR)) < 0){
     220:	b0000000 	adrp	x0, 1000 <sched_setscheduler+0x4>
     224:	911f4400 	add	x0, x0, #0x7d1
     228:	52800041 	mov	w1, #0x2                   	// #2
     22c:	940002e1 	bl	db0 <open>
     230:	2a0003f7 	mov	w23, w0
     234:	36f80080 	tbz	w0, #31, 244 <main+0x244>
      fprintf(2, "camshot: cannot open /dev/video0\n");
     238:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     23c:	911f7421 	add	x1, x1, #0x7dd
     240:	17ffff94 	b	90 <main+0x90>
    char cmd[] = "pattern=0";
     244:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     248:	9127c421 	add	x1, x1, #0x9f1
     24c:	f9400022 	ldr	x2, [x1]
     250:	f90077e2 	str	x2, [sp, #232]
     254:	79401021 	ldrh	w1, [x1, #8]
    if(write(fd, cmd, 9) != 9 && pattern){
     258:	52800122 	mov	w2, #0x9                   	// #9
    char cmd[] = "pattern=0";
     25c:	7901e3e1 	strh	w1, [sp, #240]
    cmd[8] = '0' + pattern;
     260:	1100c261 	add	w1, w19, #0x30
     264:	3903c3e1 	strb	w1, [sp, #240]
    if(write(fd, cmd, 9) != 9 && pattern){
     268:	9103a3e1 	add	x1, sp, #0xe8
     26c:	940002c5 	bl	d80 <write>
     270:	7100241f 	cmp	w0, #0x9
     274:	54000100 	b.eq	294 <main+0x294>  // b.none
     278:	340000f3 	cbz	w19, 294 <main+0x294>
      fprintf(2, "camshot: no camera, or test pattern %d not supported\n",
     27c:	2a1303e2 	mov	w2, w19
     280:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     284:	911ffc21 	add	x1, x1, #0x7ff
     288:	52800040 	mov	w0, #0x2                   	// #2
     28c:	94000479 	bl	1470 <fprintf>
      exit(1);
     290:	17ffffc8 	b	1b0 <main+0x1b0>
    printf("camshot: capturing...\n");
     294:	b0000000 	adrp	x0, 1000 <sched_setscheduler+0x4>
     298:	9120d400 	add	x0, x0, #0x835
     29c:	94000489 	bl	14c0 <printf>
    n = read(fd, frame, CAM_READ_MAX);
     2a0:	aa1503e1 	mov	x1, x21
     2a4:	2a1703e0 	mov	w0, w23
     2a8:	52800502 	mov	w2, #0x28                  	// #40
     2ac:	72a00102 	movk	w2, #0x8, lsl #16
     2b0:	940002b1 	bl	d74 <read>
     2b4:	2a0003f4 	mov	w20, w0
    if(pattern){
     2b8:	340000f3 	cbz	w19, 2d4 <main+0x2d4>
      cmd[8] = '0';
     2bc:	52800600 	mov	w0, #0x30                  	// #48
      write(fd, cmd, 9);
     2c0:	9103a3e1 	add	x1, sp, #0xe8
     2c4:	52800122 	mov	w2, #0x9                   	// #9
      cmd[8] = '0';
     2c8:	3903c3e0 	strb	w0, [sp, #240]
      write(fd, cmd, 9);
     2cc:	2a1703e0 	mov	w0, w23
     2d0:	940002ac 	bl	d80 <write>
    close(fd);
     2d4:	2a1703e0 	mov	w0, w23
     2d8:	17ffffc7 	b	1f4 <main+0x1f4>
  }
  W = hdr->width;
     2dc:	b0000013 	adrp	x19, 1000 <sched_setscheduler+0x4>
     2e0:	912d6277 	add	x23, x19, #0xb58
  H = hdr->height;
     2e4:	29408ea2 	ldp	w2, w3, [x21, #4]
  W = hdr->width;
     2e8:	b90b5a62 	str	w2, [x19, #2904]
  H = hdr->height;
     2ec:	b90006e3 	str	w3, [x23, #4]
  if(n != (int)(sizeof(*hdr) + hdr->data_bytes) || W < 4 || H < 4 ||
     W % 4 || H % 2 || hdr->bytesperline < W * 10 / 8 ||
     hdr->data_bytes < hdr->bytesperline * H || set_bayer(hdr->format) < 0){
     2f0:	29421aa4 	ldp	w4, w6, [x21, #16]
  if(n != (int)(sizeof(*hdr) + hdr->data_bytes) || W < 4 || H < 4 ||
     2f4:	1100a0c0 	add	w0, w6, #0x28
     2f8:	6b14001f 	cmp	w0, w20
     2fc:	54000a01 	b.ne	43c <main+0x43c>  // b.any
     300:	71000c5f 	cmp	w2, #0x3
     304:	540009cd 	b.le	43c <main+0x43c>
     308:	71000c7f 	cmp	w3, #0x3
     30c:	5400098d 	b.le	43c <main+0x43c>
     310:	12000459 	and	w25, w2, #0x3
     314:	12000060 	and	w0, w3, #0x1
     318:	2a000339 	orr	w25, w25, w0
     W % 4 || H % 2 || hdr->bytesperline < W * 10 / 8 ||
     31c:	35000919 	cbnz	w25, 43c <main+0x43c>
     320:	52800145 	mov	w5, #0xa                   	// #10
     324:	b9400ea1 	ldr	w1, [x21, #12]
     328:	1b057c45 	mul	w5, w2, w5
     32c:	6b850c3f 	cmp	w1, w5, asr #3
     330:	54000863 	b.cc	43c <main+0x43c>  // b.lo, b.ul, b.last
     hdr->data_bytes < hdr->bytesperline * H || set_bayer(hdr->format) < 0){
     334:	1b017c61 	mul	w1, w3, w1
     W % 4 || H % 2 || hdr->bytesperline < W * 10 / 8 ||
     338:	6b0100df 	cmp	w6, w1
     33c:	54000803 	b.cc	43c <main+0x43c>  // b.lo, b.ul, b.last
  if(format < CAM_FMT_SBGGR10P || format > CAM_FMT_SRGGB10P)
     340:	51000481 	sub	w1, w4, #0x1
     344:	71000c3f 	cmp	w1, #0x3
     348:	540007a8 	b.hi	43c <main+0x43c>  // b.pmore
    bayer[i] = orders[format - CAM_FMT_SBGGR10P][i];
     34c:	d37c7c21 	ubfiz	x1, x1, #4, #32
     350:	b0000018 	adrp	x24, 1000 <sched_setscheduler+0x4>
     354:	91281318 	add	x24, x24, #0xa04
     358:	8b010304 	add	x4, x24, x1
     35c:	f8616b00 	ldr	x0, [x24, x1]
     360:	f9400481 	ldr	x1, [x4, #8]
     364:	a90106e0 	stp	x0, x1, [x23, #16]
    fprintf(2, "camshot: unsupported frame %dx%d format %d (%d bytes)\n",
            W, H, hdr->format, n);
    exit(1);
  }
  if((px = malloc(W * H * sizeof(ushort))) == 0){
     368:	1b037c40 	mul	w0, w2, w3
     36c:	531f7800 	lsl	w0, w0, #1
     370:	940004b0 	bl	1630 <malloc>
     374:	f90006e0 	str	x0, [x23, #8]
     378:	b4ffe880 	cbz	x0, 88 <main+0x88>
    fprintf(2, "camshot: out of memory\n");
    exit(1);
  }

  if(raw){
     37c:	b4000296 	cbz	x22, 3cc <main+0x3cc>
    int rfd = open(raw, O_CREATE | O_WRONLY | O_TRUNC);
     380:	aa1603e0 	mov	x0, x22
     384:	5280c021 	mov	w1, #0x601                 	// #1537
     388:	9400028a 	bl	db0 <open>
     38c:	2a0003fa 	mov	w26, w0
    if(rfd < 0 || write(rfd, frame, n) != n)
     390:	37f800c0 	tbnz	w0, #31, 3a8 <main+0x3a8>
     394:	2a1403e2 	mov	w2, w20
     398:	aa1503e1 	mov	x1, x21
     39c:	94000279 	bl	d80 <write>
     3a0:	6b14001f 	cmp	w0, w20
     3a4:	54000580 	b.eq	454 <main+0x454>  // b.none
      fprintf(2, "camshot: cannot write %s (%d bytes; native xv6 files are "
     3a8:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     3ac:	9122b421 	add	x1, x1, #0x8ad
     3b0:	2a1403e3 	mov	w3, w20
     3b4:	aa1603e2 	mov	x2, x22
     3b8:	52800040 	mov	w0, #0x2                   	// #2
     3bc:	9400042d 	bl	1470 <fprintf>
              "limited to 268 KB, use /boot/...)\n", raw, n);
    else
      printf("camshot: raw frame -> %s (%d bytes)\n", raw, n);
    if(rfd >= 0)
     3c0:	37f8007a 	tbnz	w26, #31, 3cc <main+0x3cc>
      close(rfd);
     3c4:	2a1a03e0 	mov	w0, w26
     3c8:	94000271 	bl	d8c <close>
    ushort *d = px + y * W;
     3cc:	f94006eb 	ldr	x11, [x23, #8]
     3d0:	9100a2a6 	add	x6, x21, #0x28
     3d4:	b94b5a69 	ldr	w9, [x19, #2904]
  for(int y = 0; y < H; y++){
     3d8:	d2800005 	mov	x5, #0x0                   	// #0
     3dc:	b9800eac 	ldrsw	x12, [x21, #12]
     3e0:	52800004 	mov	w4, #0x0                   	// #0
     3e4:	b94006ea 	ldr	w10, [x23, #4]
        d[x + i] = v > BLACK ? v - BLACK : 0;
     3e8:	5280020d 	mov	w13, #0x10                  	// #16
  }

  uint seq = hdr->sequence;
     3ec:	b9401aa0 	ldr	w0, [x21, #24]
     3f0:	b900bbe0 	str	w0, [sp, #184]
  for(int y = 0; y < H; y++){
     3f4:	6b0a009f 	cmp	w4, w10
     3f8:	540003ab 	b.lt	46c <main+0x46c>  // b.tstop
  unpack_raw10(frame + sizeof(*hdr), hdr->bytesperline);
  free(frame);                      // hdr points into frame
     3fc:	aa1503e0 	mov	x0, x21
     400:	9400047d 	bl	15f4 <free>

  // Gray world: scale R and B so their means match G.  8.8 fixed point.
  uint64 sum[3] = { 0, 0, 0 };
  for(int y = 0; y < H; y++)
    for(int x = 0; x < W; x++)
     404:	b94b5a75 	ldr	w21, [x19, #2904]
      sum[colour(x, y)] += px[y * W + x];
     408:	910343e6 	add	x6, sp, #0xd0
     40c:	f94006e4 	ldr	x4, [x23, #8]
  for(int y = 0; y < H; y++)
     410:	52800003 	mov	w3, #0x0                   	// #0
     414:	b94006fa 	ldr	w26, [x23, #4]
     418:	52800002 	mov	w2, #0x0                   	// #0
  uint64 sum[3] = { 0, 0, 0 };
     41c:	a90d7fff 	stp	xzr, xzr, [sp, #208]
     420:	f90073ff 	str	xzr, [sp, #224]
  for(int y = 0; y < H; y++)
     424:	6b02035f 	cmp	w26, w2
     428:	5400078d 	b.le	518 <main+0x518>
  return bayer[(x & 1) + 2 * (y & 1)];
     42c:	531f0048 	ubfiz	w8, w2, #1, #1
     430:	8b23c487 	add	x7, x4, w3, sxtw #1
     434:	d2800001 	mov	x1, #0x0                   	// #0
     438:	14000033 	b	504 <main+0x504>
    fprintf(2, "camshot: unsupported frame %dx%d format %d (%d bytes)\n",
     43c:	2a1403e5 	mov	w5, w20
     440:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     444:	9121d821 	add	x1, x1, #0x876
     448:	52800040 	mov	w0, #0x2                   	// #2
     44c:	94000409 	bl	1470 <fprintf>
    exit(1);
     450:	17ffff58 	b	1b0 <main+0x1b0>
      printf("camshot: raw frame -> %s (%d bytes)\n", raw, n);
     454:	2a1403e2 	mov	w2, w20
     458:	aa1603e1 	mov	x1, x22
     45c:	b0000000 	adrp	x0, 1000 <sched_setscheduler+0x4>
     460:	91242400 	add	x0, x0, #0x909
     464:	94000417 	bl	14c0 <printf>
    if(rfd >= 0)
     468:	17ffffd7 	b	3c4 <main+0x3c4>
    const uchar *s = src + y * bpl;
     46c:	aa0603e3 	mov	x3, x6
    for(int x = 0; x < W; x += 4, s += 5){
     470:	8b050568 	add	x8, x11, x5, lsl #1
     474:	52800007 	mov	w7, #0x0                   	// #0
     478:	6b07013f 	cmp	w9, w7
     47c:	540000ac 	b.gt	490 <main+0x490>
  for(int y = 0; y < H; y++){
     480:	11000484 	add	w4, w4, #0x1
     484:	8b0c00c6 	add	x6, x6, x12
     488:	8b29c0a5 	add	x5, x5, w9, sxtw
     48c:	17ffffda 	b	3f4 <main+0x3f4>
        int v = (s[i] << 2) | ((lo >> (2 * i)) & 3);
     490:	3940106e 	ldrb	w14, [x3, #4]
     494:	d2800001 	mov	x1, #0x0                   	// #0
     498:	38616860 	ldrb	w0, [x3, x1]
     49c:	531f7822 	lsl	w2, w1, #1
     4a0:	1ac229c2 	asr	w2, w14, w2
     4a4:	12000442 	and	w2, w2, #0x3
     4a8:	2a000840 	orr	w0, w2, w0, lsl #2
        d[x + i] = v > BLACK ? v - BLACK : 0;
     4ac:	7100401f 	cmp	w0, #0x10
     4b0:	1a8da000 	csel	w0, w0, w13, ge	// ge = tcont
     4b4:	51004000 	sub	w0, w0, #0x10
     4b8:	78217900 	strh	w0, [x8, x1, lsl #1]
      for(int i = 0; i < 4; i++){
     4bc:	91000421 	add	x1, x1, #0x1
     4c0:	f100103f 	cmp	x1, #0x4
     4c4:	54fffea1 	b.ne	498 <main+0x498>  // b.any
    for(int x = 0; x < W; x += 4, s += 5){
     4c8:	110010e7 	add	w7, w7, #0x4
     4cc:	91001463 	add	x3, x3, #0x5
     4d0:	91002108 	add	x8, x8, #0x8
     4d4:	17ffffe9 	b	478 <main+0x478>
  return bayer[(x & 1) + 2 * (y & 1)];
     4d8:	12000020 	and	w0, w1, #0x1
      sum[colour(x, y)] += px[y * W + x];
     4dc:	786178e9 	ldrh	w9, [x7, x1, lsl #1]
  return bayer[(x & 1) + 2 * (y & 1)];
     4e0:	0b080000 	add	w0, w0, w8
     4e4:	91000421 	add	x1, x1, #0x1
     4e8:	d37e0800 	ubfiz	x0, x0, #2, #3
     4ec:	8b0002e0 	add	x0, x23, x0
      sum[colour(x, y)] += px[y * W + x];
     4f0:	b9801000 	ldrsw	x0, [x0, #16]
     4f4:	d37df000 	lsl	x0, x0, #3
     4f8:	f86068c5 	ldr	x5, [x6, x0]
     4fc:	8b0900a5 	add	x5, x5, x9
     500:	f82068c5 	str	x5, [x6, x0]
    for(int x = 0; x < W; x++)
     504:	6b0102bf 	cmp	w21, w1
     508:	54fffe8c 	b.gt	4d8 <main+0x4d8>
  for(int y = 0; y < H; y++)
     50c:	11000442 	add	w2, w2, #0x1
     510:	0b150063 	add	w3, w3, w21
     514:	17ffffc4 	b	424 <main+0x424>
  uint64 sum_r = sum[R], sum_g = sum[G], sum_b = sum[B];
     518:	f9406bf4 	ldr	x20, [sp, #208]
  uint gain_r = 256, gain_b = 256;
  if(wb && sum_r && sum_b){
     51c:	f100029f 	cmp	x20, #0x0
     520:	1a9f07e0 	cset	w0, ne	// ne = any
     524:	6a1b001f 	tst	w0, w27
     528:	54000060 	b.eq	534 <main+0x534>  // b.none
  uint64 sum_r = sum[R], sum_g = sum[G], sum_b = sum[B];
     52c:	f94073e2 	ldr	x2, [sp, #224]
  if(wb && sum_r && sum_b){
     530:	b5000182 	cbnz	x2, 560 <main+0x560>
  uint gain_r = 256, gain_b = 256;
     534:	52802013 	mov	w19, #0x100                 	// #256
     538:	2a1303f4 	mov	w20, w19
  // Auto level: map the 99th percentile of G to full scale (at most 8x).
  static uint hist[1024];
  for(int y = 0; y < H; y++)
    for(int x = 0; x < W; x++)
      if(colour(x, y) == G)
        hist[px[y * W + x]]++;
     53c:	b0000003 	adrp	x3, 1000 <sched_setscheduler+0x4>
     540:	912de063 	add	x3, x3, #0xb78
  for(int y = 0; y < H; y++)
     544:	52800005 	mov	w5, #0x0                   	// #0
     548:	52800002 	mov	w2, #0x0                   	// #0
     54c:	6b02035f 	cmp	w26, w2
     550:	540004ad 	b.le	5e4 <main+0x5e4>
  return bayer[(x & 1) + 2 * (y & 1)];
     554:	531f0047 	ubfiz	w7, w2, #1, #1
    for(int x = 0; x < W; x++)
     558:	52800001 	mov	w1, #0x0                   	// #0
     55c:	1400001d 	b	5d0 <main+0x5d0>
    gain_r = (uint)(sum_g * 128 / sum_r);          // sum_g counts 2 pixels
     560:	f9406ff3 	ldr	x19, [sp, #216]
    if(gain_r > 1024) gain_r = 1024;
     564:	52808001 	mov	w1, #0x400                 	// #1024
    if(gain_r < 128) gain_r = 128;
     568:	52801000 	mov	w0, #0x80                  	// #128
    gain_r = (uint)(sum_g * 128 / sum_r);          // sum_g counts 2 pixels
     56c:	d379e273 	lsl	x19, x19, #7
     570:	9ad40a74 	udiv	x20, x19, x20
    gain_b = (uint)(sum_g * 128 / sum_b);
     574:	9ac20a73 	udiv	x19, x19, x2
    if(gain_r > 1024) gain_r = 1024;
     578:	6b01029f 	cmp	w20, w1
     57c:	1a819294 	csel	w20, w20, w1, ls	// ls = plast
    if(gain_r < 128) gain_r = 128;
     580:	6b00029f 	cmp	w20, w0
     584:	1a802294 	csel	w20, w20, w0, cs	// cs = hs, nlast
    if(gain_b > 1024) gain_b = 1024;
     588:	6b01027f 	cmp	w19, w1
     58c:	1a819273 	csel	w19, w19, w1, ls	// ls = plast
    if(gain_b < 128) gain_b = 128;
     590:	6b00027f 	cmp	w19, w0
     594:	1a802273 	csel	w19, w19, w0, cs	// cs = hs, nlast
     598:	17ffffe9 	b	53c <main+0x53c>
  return bayer[(x & 1) + 2 * (y & 1)];
     59c:	12000020 	and	w0, w1, #0x1
     5a0:	0b070000 	add	w0, w0, w7
     5a4:	d37e0800 	ubfiz	x0, x0, #2, #3
     5a8:	8b0002e0 	add	x0, x23, x0
      if(colour(x, y) == G)
     5ac:	b9401000 	ldr	w0, [x0, #16]
     5b0:	7100041f 	cmp	w0, #0x1
     5b4:	540000c1 	b.ne	5cc <main+0x5cc>  // b.any
        hist[px[y * W + x]]++;
     5b8:	0b050020 	add	w0, w1, w5
     5bc:	78607886 	ldrh	w6, [x4, x0, lsl #1]
     5c0:	b8667860 	ldr	w0, [x3, x6, lsl #2]
     5c4:	11000400 	add	w0, w0, #0x1
     5c8:	b8267860 	str	w0, [x3, x6, lsl #2]
    for(int x = 0; x < W; x++)
     5cc:	11000421 	add	w1, w1, #0x1
     5d0:	6b0102bf 	cmp	w21, w1
     5d4:	54fffe4c 	b.gt	59c <main+0x59c>
  for(int y = 0; y < H; y++)
     5d8:	11000442 	add	w2, w2, #0x1
     5dc:	0b1500a5 	add	w5, w5, w21
     5e0:	17ffffdb 	b	54c <main+0x54c>
  uint want = (W * H / 2) / 100, seen = 0;
     5e4:	1b1a7ea1 	mul	w1, w21, w26
     5e8:	52801900 	mov	w0, #0xc8                  	// #200
  int p99 = 1023;
  while(p99 > 0 && seen + hist[p99] < want)
     5ec:	b0000002 	adrp	x2, 1000 <sched_setscheduler+0x4>
     5f0:	912de042 	add	x2, x2, #0xb78
  uint want = (W * H / 2) / 100, seen = 0;
     5f4:	1ac00c21 	sdiv	w1, w1, w0
     5f8:	d2807fe0 	mov	x0, #0x3ff                 	// #1023
  while(p99 > 0 && seen + hist[p99] < want)
     5fc:	b8607843 	ldr	w3, [x2, x0, lsl #2]
     600:	0b030339 	add	w25, w25, w3
     604:	6b01033f 	cmp	w25, w1
     608:	54000643 	b.cc	6d0 <main+0x6d0>  // b.lo, b.ul, b.last
     60c:	2a0003f9 	mov	w25, w0
  if(p99 < 128)
    p99 = 128;
  uint level = 1023 * 256 / p99;                  // 8.8

  // 24-bit BMP, rows bottom-up, BGR, each row padded to 4 bytes.
  int ow = half ? W / 2 : W, oh = half ? H / 2 : H;
     610:	b94097e0 	ldr	w0, [sp, #148]
     614:	34000080 	cbz	w0, 624 <main+0x624>
     618:	52800040 	mov	w0, #0x2                   	// #2
     61c:	1ac00eb5 	sdiv	w21, w21, w0
     620:	1ac00f5a 	sdiv	w26, w26, w0
  int row = (ow * 3 + 3) & ~3, img = row * oh;
     624:	110006b6 	add	w22, w21, #0x1
  uchar bmp[54];
  memset(bmp, 0, sizeof(bmp));
     628:	528006c2 	mov	w2, #0x36                  	// #54
     62c:	52800001 	mov	w1, #0x0                   	// #0
     630:	9103a3e0 	add	x0, sp, #0xe8
  int row = (ow * 3 + 3) & ~3, img = row * oh;
     634:	0b1606d6 	add	w22, w22, w22, lsl #1
  memset(bmp, 0, sizeof(bmp));
     638:	9400014d 	bl	b6c <memset>
  int row = (ow * 3 + 3) & ~3, img = row * oh;
     63c:	121e76d6 	and	w22, w22, #0xfffffffc
  bmp[0] = 'B'; bmp[1] = 'M';
     640:	5289a840 	mov	w0, #0x4d42                	// #19778
     644:	7901d3e0 	strh	w0, [sp, #232]
  p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24;
     648:	91043be1 	add	x1, sp, #0x10e
     64c:	b80fa3f5 	stur	w21, [sp, #250]
  int row = (ow * 3 + 3) & ~3, img = row * oh;
     650:	1b167f5b 	mul	w27, w26, w22
  p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24;
     654:	b80fe3fa 	stur	w26, [sp, #254]
  put32(bmp + 2, 54 + img);
     658:	1100db60 	add	w0, w27, #0x36
     65c:	b900abe0 	str	w0, [sp, #168]
  p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24;
     660:	b80ea3e0 	stur	w0, [sp, #234]
     664:	d28006c0 	mov	x0, #0x36                  	// #54
     668:	f2c00500 	movk	x0, #0x28, lsl #32
     66c:	f80f23e0 	stur	x0, [sp, #242]
  put32(bmp + 10, 54);
  put32(bmp + 14, 40);
  put32(bmp + 18, ow);
  put32(bmp + 22, oh);
  bmp[26] = 1;
     670:	52800020 	mov	w0, #0x1                   	// #1
     674:	39040be0 	strb	w0, [sp, #258]
  bmp[28] = 24;
     678:	52800300 	mov	w0, #0x18                  	// #24
     67c:	390413e0 	strb	w0, [sp, #260]
  p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24;
     680:	91042be0 	add	x0, sp, #0x10a
     684:	b900001b 	str	w27, [x0]
     688:	52816260 	mov	w0, #0xb13                 	// #2835
     68c:	b9000020 	str	w0, [x1]
     690:	91044be1 	add	x1, sp, #0x112
     694:	b9000020 	str	w0, [x1]
  put32(bmp + 34, img);
  put32(bmp + 38, 2835);                          // 72 dpi
  put32(bmp + 42, 2835);

  int ofd = open(out, O_CREATE | O_WRONLY | O_TRUNC);
     698:	5280c021 	mov	w1, #0x601                 	// #1537
     69c:	f94047e0 	ldr	x0, [sp, #136]
     6a0:	940001c4 	bl	db0 <open>
     6a4:	b9009be0 	str	w0, [sp, #152]
  if(ofd < 0 || write(ofd, bmp, 54) != 54){
     6a8:	37f800c0 	tbnz	w0, #31, 6c0 <main+0x6c0>
     6ac:	9103a3e1 	add	x1, sp, #0xe8
     6b0:	528006c2 	mov	w2, #0x36                  	// #54
     6b4:	940001b3 	bl	d80 <write>
     6b8:	7100d81f 	cmp	w0, #0x36
     6bc:	54000120 	b.eq	6e0 <main+0x6e0>  // b.none
    fprintf(2, "camshot: cannot create %s\n", out);
     6c0:	f94047e2 	ldr	x2, [sp, #136]
     6c4:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     6c8:	9124b821 	add	x1, x1, #0x92e
     6cc:	17fffeb7 	b	1a8 <main+0x1a8>
  while(p99 > 0 && seen + hist[p99] < want)
     6d0:	f1000400 	subs	x0, x0, #0x1
     6d4:	54fff941 	b.ne	5fc <main+0x5fc>  // b.any
     6d8:	52800019 	mov	w25, #0x0                   	// #0
     6dc:	17ffffcd 	b	610 <main+0x610>
  if(p99 < 128)
     6e0:	7102033f 	cmp	w25, #0x80
     6e4:	52801000 	mov	w0, #0x80                  	// #128
     6e8:	1a80a320 	csel	w0, w25, w0, ge	// ge = tcont
  uint level = 1023 * 256 / p99;                  // 8.8
     6ec:	321827f9 	mov	w25, #0x3ff00               	// #261888
    exit(1);
  }
  uchar *line = malloc(row);
  memset(line, 0, row);
  for(int y = oh - 1; y >= 0; y--){
     6f0:	5100075b 	sub	w27, w26, #0x1
      }
      // 10-bit -> 8-bit linear with WB and level, then gamma.
      uint lr = ((uint)r * gain_r / 256) * level / 256 / 4;
      uint lg = (uint)g * level / 256 / 4;
      uint lb = ((uint)b * gain_b / 256) * level / 256 / 4;
      line[x * 3 + 0] = gamma22[lb > 255 ? 255 : lb];
     6f4:	91010318 	add	x24, x24, #0x40
     6f8:	52801ffc 	mov	w28, #0xff                  	// #255
  uint level = 1023 * 256 / p99;                  // 8.8
     6fc:	1ac00b39 	udiv	w25, w25, w0
  uchar *line = malloc(row);
     700:	2a1603e0 	mov	w0, w22
     704:	940003cb 	bl	1630 <malloc>
     708:	f90053e0 	str	x0, [sp, #160]
  memset(line, 0, row);
     70c:	2a1603e2 	mov	w2, w22
     710:	52800001 	mov	w1, #0x0                   	// #0
     714:	94000116 	bl	b6c <memset>
  for(int y = oh - 1; y >= 0; y--){
     718:	37f8121b 	tbnz	w27, #31, 958 <main+0x958>
     71c:	531f7b60 	lsl	w0, w27, #1
  return bayer[(x & 1) + 2 * (y & 1)];
     720:	531f036e 	ubfiz	w14, w27, #1, #1
     724:	f94053e8 	ldr	x8, [sp, #160]
  int cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
     728:	5100076c 	sub	w12, w27, #0x1
     72c:	1100076b 	add	w11, w27, #0x1
          v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
     730:	910303f2 	add	x18, sp, #0xc0
    for(int x = 0; x < ow; x++){
     734:	52800006 	mov	w6, #0x0                   	// #0
     738:	b900afe0 	str	w0, [sp, #172]
          v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
     73c:	910042e0 	add	x0, x23, #0x10
     740:	f9005be0 	str	x0, [sp, #176]
     744:	14000032 	b	80c <main+0x80c>
      if(half){                     // superpixel: one 2x2 Bayer block
     748:	b94097e0 	ldr	w0, [sp, #148]
  int cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
     74c:	110004c9 	add	w9, w6, #0x1
      if(half){                     // superpixel: one 2x2 Bayer block
     750:	340007c0 	cbz	w0, 848 <main+0x848>
          v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
     754:	531f78c6 	lsl	w6, w6, #1
     758:	d2800005 	mov	x5, #0x0                   	// #0
        int v[3] = { 0, 0, 0 };
     75c:	f90063ff 	str	xzr, [sp, #192]
     760:	b900cbff 	str	wzr, [sp, #200]
          v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
     764:	b940afe1 	ldr	w1, [sp, #172]
     768:	120000a0 	and	w0, w5, #0x1
     76c:	0b060000 	add	w0, w0, w6
     770:	0b850421 	add	w1, w1, w5, asr #1
     774:	94000094 	bl	9c4 <P>
     778:	f9405be1 	ldr	x1, [sp, #176]
     77c:	b8a57821 	ldrsw	x1, [x1, x5, lsl #2]
        for(int i = 0; i < 4; i++)
     780:	910004a5 	add	x5, x5, #0x1
          v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
     784:	d37ef421 	lsl	x1, x1, #2
     788:	b8616a42 	ldr	w2, [x18, x1]
     78c:	0b000042 	add	w2, w2, w0
     790:	b8216a42 	str	w2, [x18, x1]
        for(int i = 0; i < 4; i++)
     794:	f10010bf 	cmp	x5, #0x4
     798:	54fffe61 	b.ne	764 <main+0x764>  // b.any
        g = v[G] / 2;
     79c:	29581fed 	ldp	w13, w7, [sp, #192]
     7a0:	52800040 	mov	w0, #0x2                   	// #2
        b = v[B];
     7a4:	b940cbe5 	ldr	w5, [sp, #200]
        g = v[G] / 2;
     7a8:	1ac00ce7 	sdiv	w7, w7, w0
      uint lb = ((uint)b * gain_b / 256) * level / 256 / 4;
     7ac:	1b137ca5 	mul	w5, w5, w19
     7b0:	91000d08 	add	x8, x8, #0x3
      uint lr = ((uint)r * gain_r / 256) * level / 256 / 4;
     7b4:	1b147dad 	mul	w13, w13, w20
    for(int x = 0; x < ow; x++){
     7b8:	2a0903e6 	mov	w6, w9
      uint lg = (uint)g * level / 256 / 4;
     7bc:	1b197ce7 	mul	w7, w7, w25
      uint lb = ((uint)b * gain_b / 256) * level / 256 / 4;
     7c0:	53087ca5 	lsr	w5, w5, #8
      uint lr = ((uint)r * gain_r / 256) * level / 256 / 4;
     7c4:	53087dad 	lsr	w13, w13, #8
      uint lg = (uint)g * level / 256 / 4;
     7c8:	530a7ce7 	lsr	w7, w7, #10
      uint lb = ((uint)b * gain_b / 256) * level / 256 / 4;
     7cc:	1b197ca5 	mul	w5, w5, w25
      uint lr = ((uint)r * gain_r / 256) * level / 256 / 4;
     7d0:	1b197dad 	mul	w13, w13, w25
      uint lb = ((uint)b * gain_b / 256) * level / 256 / 4;
     7d4:	530a7ca5 	lsr	w5, w5, #10
      line[x * 3 + 0] = gamma22[lb > 255 ? 255 : lb];
     7d8:	7103fcbf 	cmp	w5, #0xff
      uint lr = ((uint)r * gain_r / 256) * level / 256 / 4;
     7dc:	530a7dad 	lsr	w13, w13, #10
      line[x * 3 + 0] = gamma22[lb > 255 ? 255 : lb];
     7e0:	1a9c90a5 	csel	w5, w5, w28, ls	// ls = plast
      line[x * 3 + 1] = gamma22[lg > 255 ? 255 : lg];
     7e4:	7103fcff 	cmp	w7, #0xff
     7e8:	1a9c90e7 	csel	w7, w7, w28, ls	// ls = plast
      line[x * 3 + 2] = gamma22[lr > 255 ? 255 : lr];
     7ec:	7103fdbf 	cmp	w13, #0xff
     7f0:	1a9c91ad 	csel	w13, w13, w28, ls	// ls = plast
      line[x * 3 + 0] = gamma22[lb > 255 ? 255 : lb];
     7f4:	38656b00 	ldrb	w0, [x24, x5]
     7f8:	381fd100 	sturb	w0, [x8, #-3]
      line[x * 3 + 1] = gamma22[lg > 255 ? 255 : lg];
     7fc:	38676b00 	ldrb	w0, [x24, x7]
     800:	381fe100 	sturb	w0, [x8, #-2]
      line[x * 3 + 2] = gamma22[lr > 255 ? 255 : lr];
     804:	386d6b00 	ldrb	w0, [x24, x13]
     808:	381ff100 	sturb	w0, [x8, #-1]
    for(int x = 0; x < ow; x++){
     80c:	6b1500df 	cmp	w6, w21
     810:	54fff9cb 	b.lt	748 <main+0x748>  // b.tstop
    }
    if(write(ofd, line, row) != row){
     814:	f94053e1 	ldr	x1, [sp, #160]
     818:	2a1603e2 	mov	w2, w22
     81c:	b9409be0 	ldr	w0, [sp, #152]
     820:	94000158 	bl	d80 <write>
     824:	6b16001f 	cmp	w0, w22
     828:	54000940 	b.eq	950 <main+0x950>  // b.none
      fprintf(2, "camshot: write to %s failed (%d bytes; native xv6 files "
     82c:	f94047e2 	ldr	x2, [sp, #136]
     830:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     834:	91252421 	add	x1, x1, #0x949
     838:	b940abe3 	ldr	w3, [sp, #168]
     83c:	52800040 	mov	w0, #0x2                   	// #2
     840:	9400030c 	bl	1470 <fprintf>
              "are limited to 268 KB: use /boot/... or -s)\n", out,
              54 + img);
      exit(1);
     844:	17fffe5b 	b	1b0 <main+0x1b0>
  int cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
     848:	2a1b03e1 	mov	w1, w27
     84c:	510004c0 	sub	w0, w6, #0x1
     850:	9400005d 	bl	9c4 <P>
     854:	2a0003e5 	mov	w5, w0
     858:	2a1b03e1 	mov	w1, w27
     85c:	2a0903e0 	mov	w0, w9
     860:	94000059 	bl	9c4 <P>
     864:	0b0000a5 	add	w5, w5, w0
     868:	2a0c03e1 	mov	w1, w12
     86c:	2a0603e0 	mov	w0, w6
     870:	94000055 	bl	9c4 <P>
     874:	0b0000a7 	add	w7, w5, w0
     878:	2a0b03e1 	mov	w1, w11
     87c:	2a0003ea 	mov	w10, w0
     880:	2a0603e0 	mov	w0, w6
     884:	94000050 	bl	9c4 <P>
     888:	2a0003e2 	mov	w2, w0
     88c:	0b0000e7 	add	w7, w7, w0
  int diag  = (P(x-1,y-1) + P(x+1,y-1) + P(x-1,y+1) + P(x+1,y+1)) / 4;
     890:	2a0c03e1 	mov	w1, w12
     894:	510004c0 	sub	w0, w6, #0x1
  int cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
     898:	b900bfe2 	str	w2, [sp, #188]
     89c:	13027ce7 	asr	w7, w7, #2
  int diag  = (P(x-1,y-1) + P(x+1,y-1) + P(x-1,y+1) + P(x+1,y+1)) / 4;
     8a0:	94000049 	bl	9c4 <P>
     8a4:	2a0003ef 	mov	w15, w0
     8a8:	2a0c03e1 	mov	w1, w12
     8ac:	2a0903e0 	mov	w0, w9
     8b0:	94000045 	bl	9c4 <P>
     8b4:	0b0001ef 	add	w15, w15, w0
     8b8:	2a0b03e1 	mov	w1, w11
     8bc:	510004c0 	sub	w0, w6, #0x1
     8c0:	94000041 	bl	9c4 <P>
     8c4:	0b0001ed 	add	w13, w15, w0
     8c8:	2a0b03e1 	mov	w1, w11
     8cc:	2a0903e0 	mov	w0, w9
     8d0:	9400003d 	bl	9c4 <P>
     8d4:	0b0001ad 	add	w13, w13, w0
  int c = P(x, y);
     8d8:	2a0603e0 	mov	w0, w6
  return bayer[(x & 1) + 2 * (y & 1)];
     8dc:	120000c6 	and	w6, w6, #0x1
     8e0:	0b0e00c6 	add	w6, w6, w14
  int c = P(x, y);
     8e4:	2a1b03e1 	mov	w1, w27
     8e8:	94000037 	bl	9c4 <P>
  int diag  = (P(x-1,y-1) + P(x+1,y-1) + P(x-1,y+1) + P(x+1,y+1)) / 4;
     8ec:	13027dad 	asr	w13, w13, #2
  return bayer[(x & 1) + 2 * (y & 1)];
     8f0:	d37e08c6 	ubfiz	x6, x6, #2, #3
     8f4:	8b0602e6 	add	x6, x23, x6
     8f8:	b94010c1 	ldr	w1, [x6, #16]
  switch(colour(x, y)){
     8fc:	34000241 	cbz	w1, 944 <main+0x944>
     900:	7100083f 	cmp	w1, #0x2
     904:	540001c0 	b.eq	93c <main+0x93c>  // b.none
  return bayer[(x & 1) + 2 * (y & 1)];
     908:	12000121 	and	w1, w9, #0x1
  int vert  = (P(x,y-1) + P(x,y+1)) / 2;
     90c:	b940bfe2 	ldr	w2, [sp, #188]
  return bayer[(x & 1) + 2 * (y & 1)];
     910:	0b0e0021 	add	w1, w1, w14
  int horiz = (P(x-1,y) + P(x+1,y)) / 2;
     914:	13017ca5 	asr	w5, w5, #1
  int vert  = (P(x,y-1) + P(x,y+1)) / 2;
     918:	0b02014a 	add	w10, w10, w2
    *g = c;
     91c:	2a0003e7 	mov	w7, w0
  return bayer[(x & 1) + 2 * (y & 1)];
     920:	d37e0821 	ubfiz	x1, x1, #2, #3
     924:	8b0102e1 	add	x1, x23, x1
  int vert  = (P(x,y-1) + P(x,y+1)) / 2;
     928:	13017d4d 	asr	w13, w10, #1
    if(colour(x + 1, y) == R){ *r = horiz; *b = vert; }
     92c:	b9401021 	ldr	w1, [x1, #16]
     930:	35fff3e1 	cbnz	w1, 7ac <main+0x7ac>
     934:	2a0d03e0 	mov	w0, w13
     938:	2a0503ed 	mov	w13, w5
  switch(colour(x, y)){
     93c:	2a0003e5 	mov	w5, w0
     940:	17ffff9b 	b	7ac <main+0x7ac>
  case R: *r = c; *g = cross; *b = diag; break;
     944:	2a0d03e5 	mov	w5, w13
     948:	2a0003ed 	mov	w13, w0
     94c:	17ffff98 	b	7ac <main+0x7ac>
  for(int y = oh - 1; y >= 0; y--){
     950:	5100077b 	sub	w27, w27, #0x1
     954:	17ffff71 	b	718 <main+0x718>
    }
  }
  close(ofd);
     958:	b9409be0 	ldr	w0, [sp, #152]
     95c:	9400010c 	bl	d8c <close>
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
     960:	f94047e1 	ldr	x1, [sp, #136]
     964:	f9000be1 	str	x1, [sp, #16]
         ow, oh, seq, gain_r / 256, gain_r % 256 * 10 / 256,
         gain_b / 256, gain_b % 256 * 10 / 256,
         level / 256, level % 256 * 10 / 256, out);
     968:	12001f21 	and	w1, w25, #0xff
         gain_b / 256, gain_b % 256 * 10 / 256,
     96c:	52800142 	mov	w2, #0xa                   	// #10
     970:	12001e67 	and	w7, w19, #0xff
         ow, oh, seq, gain_r / 256, gain_r % 256 * 10 / 256,
     974:	12001e85 	and	w5, w20, #0xff
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
     978:	b940bbe3 	ldr	w3, [sp, #184]
     97c:	53087f39 	lsr	w25, w25, #8
         level / 256, level % 256 * 10 / 256, out);
     980:	1b027c21 	mul	w1, w1, w2
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
     984:	b90003f9 	str	w25, [sp]
         gain_b / 256, gain_b % 256 * 10 / 256,
     988:	1b027ce7 	mul	w7, w7, w2
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
     98c:	53087e66 	lsr	w6, w19, #8
         ow, oh, seq, gain_r / 256, gain_r % 256 * 10 / 256,
     990:	1b027ca5 	mul	w5, w5, w2
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
     994:	53087e84 	lsr	w4, w20, #8
     998:	53087c21 	lsr	w1, w1, #8
     99c:	b9000be1 	str	w1, [sp, #8]
     9a0:	53087ce7 	lsr	w7, w7, #8
     9a4:	2a1a03e2 	mov	w2, w26
     9a8:	53087ca5 	lsr	w5, w5, #8
     9ac:	2a1503e1 	mov	w1, w21
     9b0:	b0000000 	adrp	x0, 1000 <sched_setscheduler+0x4>
     9b4:	9126b800 	add	x0, x0, #0x9ae
     9b8:	940002c2 	bl	14c0 <printf>
  exit(0);
     9bc:	52800000 	mov	w0, #0x0                   	// #0
     9c0:	17fffdfd 	b	1b4 <main+0x1b4>

00000000000009c4 <P>:
  if(x >= W) x = 2 * W - 2 - x;
     9c4:	b0000002 	adrp	x2, 1000 <sched_setscheduler+0x4>
     9c8:	b94b5843 	ldr	w3, [x2, #2904]
  if(x < 0) x = -x;
     9cc:	7100001f 	cmp	w0, #0x0
  if(x >= W) x = 2 * W - 2 - x;
     9d0:	51000464 	sub	w4, w3, #0x1
  if(x < 0) x = -x;
     9d4:	5a80a400 	cneg	w0, w0, lt	// lt = tstop
  if(x >= W) x = 2 * W - 2 - x;
     9d8:	6b00007f 	cmp	w3, w0
     9dc:	531f7884 	lsl	w4, w4, #1
     9e0:	4b000084 	sub	w4, w4, w0
     9e4:	1a84c000 	csel	w0, w0, w4, gt
  if(y >= H) y = 2 * H - 2 - y;
     9e8:	912d6044 	add	x4, x2, #0xb58
  if(y < 0) y = -y;
     9ec:	7100003f 	cmp	w1, #0x0
     9f0:	5a81a421 	cneg	w1, w1, lt	// lt = tstop
  if(y >= H) y = 2 * H - 2 - y;
     9f4:	b9400482 	ldr	w2, [x4, #4]
     9f8:	6b02003f 	cmp	w1, w2
     9fc:	51000442 	sub	w2, w2, #0x1
     a00:	531f7842 	lsl	w2, w2, #1
     a04:	4b010042 	sub	w2, w2, w1
     a08:	1a82b021 	csel	w1, w1, w2, lt	// lt = tstop
  return px[y * W + x];
     a0c:	1b010063 	madd	w3, w3, w1, w0
     a10:	f9400480 	ldr	x0, [x4, #8]
}
     a14:	7863d800 	ldrh	w0, [x0, w3, sxtw #1]
     a18:	d65f03c0 	ret

0000000000000a1c <usage>:
{
     a1c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: camshot [-o OUT.bmp] [-r OUT.raw] [-i IN.raw] "
     a20:	b0000001 	adrp	x1, 1000 <sched_setscheduler+0x4>
     a24:	911cc021 	add	x1, x1, #0x730
{
     a28:	910003fd 	mov	x29, sp
  fprintf(2, "usage: camshot [-o OUT.bmp] [-r OUT.raw] [-i IN.raw] "
     a2c:	52800040 	mov	w0, #0x2                   	// #2
     a30:	94000290 	bl	1470 <fprintf>
  exit(1);
     a34:	52800020 	mov	w0, #0x1                   	// #1
     a38:	940000c6 	bl	d50 <exit>

0000000000000a3c <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     a3c:	d2800002 	mov	x2, #0x0                   	// #0
     a40:	38626823 	ldrb	w3, [x1, x2]
     a44:	38226803 	strb	w3, [x0, x2]
     a48:	91000442 	add	x2, x2, #0x1
     a4c:	35ffffa3 	cbnz	w3, a40 <strcpy+0x4>
    ;
  return os;
}
     a50:	d65f03c0 	ret

0000000000000a54 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
     a54:	d2800003 	mov	x3, #0x0                   	// #0
     a58:	4b030044 	sub	w4, w2, w3
     a5c:	7100009f 	cmp	w4, #0x0
     a60:	5400006d 	b.le	a6c <strncpy+0x18>
     a64:	38636825 	ldrb	w5, [x1, x3]
     a68:	350000e5 	cbnz	w5, a84 <strncpy+0x30>
     a6c:	8b030003 	add	x3, x0, x3
     a70:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
     a74:	4b010082 	sub	w2, w4, w1
     a78:	7100005f 	cmp	w2, #0x0
     a7c:	540000ac 	b.gt	a90 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
     a80:	d65f03c0 	ret
    *s++ = *t++;
     a84:	38236805 	strb	w5, [x0, x3]
    n--;
     a88:	91000463 	add	x3, x3, #0x1
     a8c:	17fffff3 	b	a58 <strncpy+0x4>
    *s++ = 0;
     a90:	3821687f 	strb	wzr, [x3, x1]
     a94:	91000421 	add	x1, x1, #0x1
     a98:	17fffff7 	b	a74 <strncpy+0x20>

0000000000000a9c <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
     a9c:	aa0003e2 	mov	x2, x0
     aa0:	39400043 	ldrb	w3, [x2]
     aa4:	aa0203e4 	mov	x4, x2
    s++;
     aa8:	91000442 	add	x2, x2, #0x1
  while(*s)
     aac:	35ffffa3 	cbnz	w3, aa0 <strcat+0x4>
     ab0:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
     ab4:	38626823 	ldrb	w3, [x1, x2]
     ab8:	38226883 	strb	w3, [x4, x2]
     abc:	91000442 	add	x2, x2, #0x1
     ac0:	35ffffa3 	cbnz	w3, ab4 <strcat+0x18>
    ;
  return os;
}
     ac4:	d65f03c0 	ret

0000000000000ac8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
     ac8:	d2800002 	mov	x2, #0x0                   	// #0
     acc:	38626803 	ldrb	w3, [x0, x2]
     ad0:	38626824 	ldrb	w4, [x1, x2]
     ad4:	34000083 	cbz	w3, ae4 <strcmp+0x1c>
     ad8:	91000442 	add	x2, x2, #0x1
     adc:	6b04007f 	cmp	w3, w4
     ae0:	54ffff60 	b.eq	acc <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
     ae4:	4b040060 	sub	w0, w3, w4
     ae8:	d65f03c0 	ret

0000000000000aec <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
     aec:	340001c2 	cbz	w2, b24 <strncmp+0x38>
     af0:	39400003 	ldrb	w3, [x0]
     af4:	34000083 	cbz	w3, b04 <strncmp+0x18>
     af8:	39400024 	ldrb	w4, [x1]
     afc:	6b03009f 	cmp	w4, w3
     b00:	540000a0 	b.eq	b14 <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
     b04:	39400000 	ldrb	w0, [x0]
     b08:	39400021 	ldrb	w1, [x1]
     b0c:	4b010000 	sub	w0, w0, w1
}
     b10:	d65f03c0 	ret
    n--, p++, q++;
     b14:	51000442 	sub	w2, w2, #0x1
     b18:	91000400 	add	x0, x0, #0x1
     b1c:	91000421 	add	x1, x1, #0x1
     b20:	17fffff3 	b	aec <strncmp>
    return 0;
     b24:	52800000 	mov	w0, #0x0                   	// #0
     b28:	17fffffa 	b	b10 <strncmp+0x24>

0000000000000b2c <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
     b2c:	d1000402 	sub	x2, x0, #0x1
     b30:	d2800001 	mov	x1, #0x0                   	// #0
     b34:	aa0103e0 	mov	x0, x1
     b38:	91000421 	add	x1, x1, #0x1
     b3c:	38616843 	ldrb	w3, [x2, x1]
     b40:	35ffffa3 	cbnz	w3, b34 <strlen+0x8>
    ;
  return n;
}
     b44:	d65f03c0 	ret

0000000000000b48 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
     b48:	d1000403 	sub	x3, x0, #0x1
     b4c:	d2800002 	mov	x2, #0x0                   	// #0
     b50:	2a0203e0 	mov	w0, w2
     b54:	6b02003f 	cmp	w1, w2
     b58:	54000089 	b.ls	b68 <strnlen+0x20>  // b.plast
     b5c:	91000442 	add	x2, x2, #0x1
     b60:	38626864 	ldrb	w4, [x3, x2]
     b64:	35ffff64 	cbnz	w4, b50 <strnlen+0x8>
    n++;
  return n;
}
     b68:	d65f03c0 	ret

0000000000000b6c <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     b6c:	d2800003 	mov	x3, #0x0                   	// #0
     b70:	6b03005f 	cmp	w2, w3
     b74:	54000048 	b.hi	b7c <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
     b78:	d65f03c0 	ret
    cdst[i] = c;
     b7c:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
     b80:	91000463 	add	x3, x3, #0x1
     b84:	17fffffb 	b	b70 <memset+0x4>

0000000000000b88 <strchr>:

char*
strchr(const char *s, char c)
{
     b88:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
     b8c:	39400002 	ldrb	w2, [x0]
     b90:	35000062 	cbnz	w2, b9c <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
     b94:	d2800000 	mov	x0, #0x0                   	// #0
}
     b98:	d65f03c0 	ret
    if(*s == c)
     b9c:	6b01005f 	cmp	w2, w1
     ba0:	54ffffc0 	b.eq	b98 <strchr+0x10>  // b.none
  for(; *s; s++)
     ba4:	91000400 	add	x0, x0, #0x1
     ba8:	17fffff9 	b	b8c <strchr+0x4>

0000000000000bac <gets>:

char*
gets(char *buf, int max)
{
     bac:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     bb0:	910003fd 	mov	x29, sp
     bb4:	a90153f3 	stp	x19, x20, [sp, #16]
     bb8:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     bbc:	d2800014 	mov	x20, #0x0                   	// #0
{
     bc0:	f9001bf7 	str	x23, [sp, #48]
     bc4:	2a0103f7 	mov	w23, w1
     bc8:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
     bcc:	11000695 	add	w21, w20, #0x1
     bd0:	2a1403f6 	mov	w22, w20
     bd4:	6b1702bf 	cmp	w21, w23
     bd8:	540000ea 	b.ge	bf4 <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
     bdc:	91013fe1 	add	x1, sp, #0x4f
     be0:	52800022 	mov	w2, #0x1                   	// #1
     be4:	52800000 	mov	w0, #0x0                   	// #0
     be8:	94000063 	bl	d74 <read>
    if(cc < 1)
     bec:	7100001f 	cmp	w0, #0x0
     bf0:	5400012c 	b.gt	c14 <gets+0x68>
  for(i=0; i+1 < max; ){
     bf4:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
     bf8:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
     bfc:	aa1303e0 	mov	x0, x19
     c00:	f9401bf7 	ldr	x23, [sp, #48]
     c04:	a94153f3 	ldp	x19, x20, [sp, #16]
     c08:	a9425bf5 	ldp	x21, x22, [sp, #32]
     c0c:	a8c57bfd 	ldp	x29, x30, [sp], #80
     c10:	d65f03c0 	ret
    buf[i++] = c;
     c14:	39413fe0 	ldrb	w0, [sp, #79]
     c18:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
     c1c:	91000694 	add	x20, x20, #0x1
     c20:	7100281f 	cmp	w0, #0xa
     c24:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
     c28:	54fffd21 	b.ne	bcc <gets+0x20>  // b.any
     c2c:	17fffff3 	b	bf8 <gets+0x4c>

0000000000000c30 <stat>:

int
stat(const char *n, struct stat *st)
{
     c30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     c34:	910003fd 	mov	x29, sp
     c38:	a90153f3 	stp	x19, x20, [sp, #16]
     c3c:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     c40:	52800001 	mov	w1, #0x0                   	// #0
     c44:	9400005b 	bl	db0 <open>
  if(fd < 0)
     c48:	37f80160 	tbnz	w0, #31, c74 <stat+0x44>
    return -1;
  r = fstat(fd, st);
     c4c:	aa1303e1 	mov	x1, x19
     c50:	2a0003f4 	mov	w20, w0
     c54:	94000060 	bl	dd4 <fstat>
     c58:	2a0003f3 	mov	w19, w0
  close(fd);
     c5c:	2a1403e0 	mov	w0, w20
     c60:	9400004b 	bl	d8c <close>
  return r;
}
     c64:	2a1303e0 	mov	w0, w19
     c68:	a94153f3 	ldp	x19, x20, [sp, #16]
     c6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
     c70:	d65f03c0 	ret
    return -1;
     c74:	12800013 	mov	w19, #0xffffffff            	// #-1
     c78:	17fffffb 	b	c64 <stat+0x34>

0000000000000c7c <atoi>:

int
atoi(const char *s)
{
     c7c:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
     c80:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
     c84:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
     c88:	39400043 	ldrb	w3, [x2]
     c8c:	5100c061 	sub	w1, w3, #0x30
     c90:	12001c21 	and	w1, w1, #0xff
     c94:	7100243f 	cmp	w1, #0x9
     c98:	54000049 	b.ls	ca0 <atoi+0x24>  // b.plast
  return n;
}
     c9c:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
     ca0:	1b040c01 	madd	w1, w0, w4, w3
     ca4:	91000442 	add	x2, x2, #0x1
     ca8:	5100c020 	sub	w0, w1, #0x30
     cac:	17fffff7 	b	c88 <atoi+0xc>

0000000000000cb0 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     cb0:	eb01001f 	cmp	x0, x1
     cb4:	54000263 	b.cc	d00 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
     cb8:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
     cbc:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
     cc0:	d2800003 	mov	x3, #0x0                   	// #0
     cc4:	d1000463 	sub	x3, x3, #0x1
     cc8:	11000464 	add	w4, w3, #0x1
     ccc:	0b020084 	add	w4, w4, w2
     cd0:	7100009f 	cmp	w4, #0x0
     cd4:	5400014d 	b.le	cfc <memmove+0x4c>
      *--dst = *--src;
     cd8:	38636824 	ldrb	w4, [x1, x3]
     cdc:	382368a4 	strb	w4, [x5, x3]
     ce0:	17fffff9 	b	cc4 <memmove+0x14>
      *dst++ = *src++;
     ce4:	38636824 	ldrb	w4, [x1, x3]
     ce8:	38236804 	strb	w4, [x0, x3]
     cec:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
     cf0:	4b030044 	sub	w4, w2, w3
     cf4:	7100009f 	cmp	w4, #0x0
     cf8:	54ffff6c 	b.gt	ce4 <memmove+0x34>
  }
  return vdst;
}
     cfc:	d65f03c0 	ret
     d00:	d2800003 	mov	x3, #0x0                   	// #0
     d04:	17fffffb 	b	cf0 <memmove+0x40>

0000000000000d08 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     d08:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
     d0c:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
     d10:	d2800004 	mov	x4, #0x0                   	// #0
     d14:	eb02009f 	cmp	x4, x2
     d18:	54000061 	b.ne	d24 <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
     d1c:	52800000 	mov	w0, #0x0                   	// #0
     d20:	14000007 	b	d3c <memcmp+0x34>
    if (*p1 != *p2) {
     d24:	38646803 	ldrb	w3, [x0, x4]
     d28:	91000484 	add	x4, x4, #0x1
     d2c:	38646825 	ldrb	w5, [x1, x4]
     d30:	6b05007f 	cmp	w3, w5
     d34:	54ffff00 	b.eq	d14 <memcmp+0xc>  // b.none
      return *p1 - *p2;
     d38:	4b050060 	sub	w0, w3, w5
}
     d3c:	d65f03c0 	ret

0000000000000d40 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
     d40:	17ffffdc 	b	cb0 <memmove>

0000000000000d44 <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
     d44:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
     d48:	d4000001 	svc	#0x0
 ret
     d4c:	d65f03c0 	ret

0000000000000d50 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
     d50:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
     d54:	d4000001 	svc	#0x0
 ret
     d58:	d65f03c0 	ret

0000000000000d5c <wait>:
.global wait
wait:
 mov x7, #SYS_wait
     d5c:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
     d60:	d4000001 	svc	#0x0
 ret
     d64:	d65f03c0 	ret

0000000000000d68 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
     d68:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
     d6c:	d4000001 	svc	#0x0
 ret
     d70:	d65f03c0 	ret

0000000000000d74 <read>:
.global read
read:
 mov x7, #SYS_read
     d74:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
     d78:	d4000001 	svc	#0x0
 ret
     d7c:	d65f03c0 	ret

0000000000000d80 <write>:
.global write
write:
 mov x7, #SYS_write
     d80:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
     d84:	d4000001 	svc	#0x0
 ret
     d88:	d65f03c0 	ret

0000000000000d8c <close>:
.global close
close:
 mov x7, #SYS_close
     d8c:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
     d90:	d4000001 	svc	#0x0
 ret
     d94:	d65f03c0 	ret

0000000000000d98 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
     d98:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
     d9c:	d4000001 	svc	#0x0
 ret
     da0:	d65f03c0 	ret

0000000000000da4 <exec>:
.global exec
exec:
 mov x7, #SYS_exec
     da4:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
     da8:	d4000001 	svc	#0x0
 ret
     dac:	d65f03c0 	ret

0000000000000db0 <open>:
.global open
open:
 mov x7, #SYS_open
     db0:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
     db4:	d4000001 	svc	#0x0
 ret
     db8:	d65f03c0 	ret

0000000000000dbc <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
     dbc:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
     dc0:	d4000001 	svc	#0x0
 ret
     dc4:	d65f03c0 	ret

0000000000000dc8 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
     dc8:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
     dcc:	d4000001 	svc	#0x0
 ret
     dd0:	d65f03c0 	ret

0000000000000dd4 <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
     dd4:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
     dd8:	d4000001 	svc	#0x0
 ret
     ddc:	d65f03c0 	ret

0000000000000de0 <link>:
.global link
link:
 mov x7, #SYS_link
     de0:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
     de4:	d4000001 	svc	#0x0
 ret
     de8:	d65f03c0 	ret

0000000000000dec <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
     dec:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
     df0:	d4000001 	svc	#0x0
 ret
     df4:	d65f03c0 	ret

0000000000000df8 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
     df8:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
     dfc:	d4000001 	svc	#0x0
 ret
     e00:	d65f03c0 	ret

0000000000000e04 <dup>:
.global dup
dup:
 mov x7, #SYS_dup
     e04:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
     e08:	d4000001 	svc	#0x0
 ret
     e0c:	d65f03c0 	ret

0000000000000e10 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
     e10:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
     e14:	d4000001 	svc	#0x0
 ret
     e18:	d65f03c0 	ret

0000000000000e1c <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
     e1c:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
     e20:	d4000001 	svc	#0x0
 ret
     e24:	d65f03c0 	ret

0000000000000e28 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
     e28:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
     e2c:	d4000001 	svc	#0x0
 ret
     e30:	d65f03c0 	ret

0000000000000e34 <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
     e34:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
     e38:	d4000001 	svc	#0x0
 ret
     e3c:	d65f03c0 	ret

0000000000000e40 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
     e40:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
     e44:	d4000001 	svc	#0x0
 ret
     e48:	d65f03c0 	ret

0000000000000e4c <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
     e4c:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
     e50:	d4000001 	svc	#0x0
 ret
     e54:	d65f03c0 	ret

0000000000000e58 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
     e58:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
     e5c:	d4000001 	svc	#0x0
 ret
     e60:	d65f03c0 	ret

0000000000000e64 <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
     e64:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
     e68:	d4000001 	svc	#0x0
 ret
     e6c:	d65f03c0 	ret

0000000000000e70 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
     e70:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
     e74:	d4000001 	svc	#0x0
 ret
     e78:	d65f03c0 	ret

0000000000000e7c <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
     e7c:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
     e80:	d4000001 	svc	#0x0
 ret
     e84:	d65f03c0 	ret

0000000000000e88 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
     e88:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
     e8c:	d4000001 	svc	#0x0
 ret
     e90:	d65f03c0 	ret

0000000000000e94 <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
     e94:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
     e98:	d4000001 	svc	#0x0
 ret
     e9c:	d65f03c0 	ret

0000000000000ea0 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
     ea0:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
     ea4:	d4000001 	svc	#0x0
 ret
     ea8:	d65f03c0 	ret

0000000000000eac <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
     eac:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
     eb0:	d4000001 	svc	#0x0
 ret
     eb4:	d65f03c0 	ret

0000000000000eb8 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
     eb8:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
     ebc:	d4000001 	svc	#0x0
 ret
     ec0:	d65f03c0 	ret

0000000000000ec4 <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
     ec4:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
     ec8:	d4000001 	svc	#0x0
 ret
     ecc:	d65f03c0 	ret

0000000000000ed0 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
     ed0:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
     ed4:	d4000001 	svc	#0x0
 ret
     ed8:	d65f03c0 	ret

0000000000000edc <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
     edc:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
     ee0:	d4000001 	svc	#0x0
 ret
     ee4:	d65f03c0 	ret

0000000000000ee8 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
     ee8:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
     eec:	d4000001 	svc	#0x0
 ret
     ef0:	d65f03c0 	ret

0000000000000ef4 <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
     ef4:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
     ef8:	d4000001 	svc	#0x0
 ret
     efc:	d65f03c0 	ret

0000000000000f00 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
     f00:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
     f04:	d4000001 	svc	#0x0
 ret
     f08:	d65f03c0 	ret

0000000000000f0c <mount>:
.global mount
mount:
 mov x7, #SYS_mount
     f0c:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
     f10:	d4000001 	svc	#0x0
 ret
     f14:	d65f03c0 	ret

0000000000000f18 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
     f18:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
     f1c:	d4000001 	svc	#0x0
 ret
     f20:	d65f03c0 	ret

0000000000000f24 <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
     f24:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
     f28:	d4000001 	svc	#0x0
 ret
     f2c:	d65f03c0 	ret

0000000000000f30 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
     f30:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
     f34:	d4000001 	svc	#0x0
 ret
     f38:	d65f03c0 	ret

0000000000000f3c <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
     f3c:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
     f40:	d4000001 	svc	#0x0
 ret
     f44:	d65f03c0 	ret

0000000000000f48 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
     f48:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
     f4c:	d4000001 	svc	#0x0
 ret
     f50:	d65f03c0 	ret

0000000000000f54 <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
     f54:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
     f58:	d4000001 	svc	#0x0
 ret
     f5c:	d65f03c0 	ret

0000000000000f60 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
     f60:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
     f64:	d4000001 	svc	#0x0
 ret
     f68:	d65f03c0 	ret

0000000000000f6c <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
     f6c:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
     f70:	d4000001 	svc	#0x0
 ret
     f74:	d65f03c0 	ret

0000000000000f78 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
     f78:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
     f7c:	d4000001 	svc	#0x0
 ret
     f80:	d65f03c0 	ret

0000000000000f84 <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
     f84:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
     f88:	d4000001 	svc	#0x0
 ret
     f8c:	d65f03c0 	ret

0000000000000f90 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
     f90:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
     f94:	d4000001 	svc	#0x0
 ret
     f98:	d65f03c0 	ret

0000000000000f9c <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
     f9c:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
     fa0:	d4000001 	svc	#0x0
 ret
     fa4:	d65f03c0 	ret

0000000000000fa8 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
     fa8:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
     fac:	d4000001 	svc	#0x0
 ret
     fb0:	d65f03c0 	ret

0000000000000fb4 <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
     fb4:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
     fb8:	d4000001 	svc	#0x0
 ret
     fbc:	d65f03c0 	ret

0000000000000fc0 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
     fc0:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
     fc4:	d4000001 	svc	#0x0
 ret
     fc8:	d65f03c0 	ret

0000000000000fcc <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
     fcc:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
     fd0:	d4000001 	svc	#0x0
 ret
     fd4:	d65f03c0 	ret

0000000000000fd8 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
     fd8:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
     fdc:	d4000001 	svc	#0x0
 ret
     fe0:	d65f03c0 	ret

0000000000000fe4 <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
     fe4:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
     fe8:	d4000001 	svc	#0x0
 ret
     fec:	d65f03c0 	ret

0000000000000ff0 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
     ff0:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
     ff4:	d4000001 	svc	#0x0
 ret
     ff8:	d65f03c0 	ret

0000000000000ffc <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
     ffc:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
    1000:	d4000001 	svc	#0x0
 ret
    1004:	d65f03c0 	ret

0000000000001008 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
    1008:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
    100c:	d4000001 	svc	#0x0
 ret
    1010:	d65f03c0 	ret

0000000000001014 <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
    1014:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
    1018:	d4000001 	svc	#0x0
 ret
    101c:	d65f03c0 	ret

0000000000001020 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
    1020:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
    1024:	d4000001 	svc	#0x0
 ret
    1028:	d65f03c0 	ret

000000000000102c <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
    102c:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
    1030:	d4000001 	svc	#0x0
 ret
    1034:	d65f03c0 	ret

0000000000001038 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
    1038:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
    103c:	d4000001 	svc	#0x0
 ret
    1040:	d65f03c0 	ret

0000000000001044 <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
    1044:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
    1048:	d4000001 	svc	#0x0
 ret
    104c:	d65f03c0 	ret

0000000000001050 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
    1050:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
    1054:	d4000001 	svc	#0x0
 ret
    1058:	d65f03c0 	ret

000000000000105c <texit>:
.global texit
texit:
 mov x7, #SYS_texit
    105c:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
    1060:	d4000001 	svc	#0x0
 ret
    1064:	d65f03c0 	ret

0000000000001068 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
    1068:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
    106c:	d4000001 	svc	#0x0
 ret
    1070:	d65f03c0 	ret

0000000000001074 <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
    1074:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
    1078:	d4000001 	svc	#0x0
 ret
    107c:	d65f03c0 	ret

0000000000001080 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
    1080:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
    1084:	d4000001 	svc	#0x0
 ret
    1088:	d65f03c0 	ret

000000000000108c <bind>:
.global bind
bind:
 mov x7, #SYS_bind
    108c:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
    1090:	d4000001 	svc	#0x0
 ret
    1094:	d65f03c0 	ret

0000000000001098 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
    1098:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
    109c:	d4000001 	svc	#0x0
 ret
    10a0:	d65f03c0 	ret

00000000000010a4 <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
    10a4:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
    10a8:	d4000001 	svc	#0x0
 ret
    10ac:	d65f03c0 	ret

00000000000010b0 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
    10b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
    10b4:	52800022 	mov	w2, #0x1                   	// #1
{
    10b8:	910003fd 	mov	x29, sp
    10bc:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
    10c0:	91007fe1 	add	x1, sp, #0x1f
    10c4:	97ffff2f 	bl	d80 <write>
    10c8:	7100041f 	cmp	w0, #0x1
}
    10cc:	1a9f17e0 	cset	w0, eq	// eq = none
    10d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    10d4:	d65f03c0 	ret

00000000000010d8 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
    10d8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    10dc:	910003fd 	mov	x29, sp
    10e0:	a90153f3 	stp	x19, x20, [sp, #16]
    10e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    10e8:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    10ec:	6a417c7f 	tst	w3, w1, lsr #31
    10f0:	54000300 	b.eq	1150 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
    10f4:	4b0103e1 	neg	w1, w1
    neg = 1;
    10f8:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
    10fc:	90000003 	adrp	x3, 1000 <sched_setscheduler+0x4>
    1100:	912d1063 	add	x3, x3, #0xb44
    1104:	9100c3f5 	add	x21, sp, #0x30
    1108:	d2800000 	mov	x0, #0x0                   	// #0
    110c:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
    1110:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
    1114:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
    1118:	2a0403e1 	mov	w1, w4
    111c:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
    1120:	38666866 	ldrb	w6, [x3, x6]
    1124:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
    1128:	91000400 	add	x0, x0, #0x1
    112c:	54ffff09 	b.ls	110c <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
    1130:	11000493 	add	w19, w4, #0x1
  if(neg)
    1134:	34000085 	cbz	w5, 1144 <printint+0x6c>
    buf[i++] = '-';
    1138:	528005a0 	mov	w0, #0x2d                  	// #45
    113c:	38334aa0 	strb	w0, [x21, w19, uxtw]
    1140:	11000893 	add	w19, w4, #0x2
    1144:	51000673 	sub	w19, w19, #0x1
    1148:	52800014 	mov	w20, #0x0                   	// #0
    114c:	14000008 	b	116c <printint+0x94>
  neg = 0;
    1150:	52800005 	mov	w5, #0x0                   	// #0
    1154:	17ffffea 	b	10fc <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
    1158:	38736aa1 	ldrb	w1, [x21, x19]
    115c:	2a1603e0 	mov	w0, w22
    1160:	d1000673 	sub	x19, x19, #0x1
    1164:	97ffffd3 	bl	10b0 <putc>
    1168:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
    116c:	3100067f 	cmn	w19, #0x1
    1170:	54ffff41 	b.ne	1158 <printint+0x80>  // b.any
  return written;
}
    1174:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1178:	2a1403e0 	mov	w0, w20
    117c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1180:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1184:	d65f03c0 	ret

0000000000001188 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
    1188:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    118c:	910003fd 	mov	x29, sp
    1190:	a90153f3 	stp	x19, x20, [sp, #16]
    1194:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
    1198:	52800015 	mov	w21, #0x0                   	// #0
{
    119c:	a90363f7 	stp	x23, x24, [sp, #48]
    11a0:	2a0003f7 	mov	w23, w0
    11a4:	a9046bf9 	stp	x25, x26, [sp, #64]
    11a8:	aa0103f9 	mov	x25, x1

  state = 0;
    11ac:	52800001 	mov	w1, #0x0                   	// #0
{
    11b0:	a90573fb 	stp	x27, x28, [sp, #80]
    11b4:	a9406053 	ldp	x19, x24, [x2]
    11b8:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
    11bc:	39400320 	ldrb	w0, [x25]
    11c0:	35000120 	cbnz	w0, 11e4 <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
    11c4:	2a1503e0 	mov	w0, w21
    11c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    11cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    11d0:	a94363f7 	ldp	x23, x24, [sp, #48]
    11d4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    11d8:	a94573fb 	ldp	x27, x28, [sp, #80]
    11dc:	a8c67bfd 	ldp	x29, x30, [sp], #96
    11e0:	d65f03c0 	ret
    c = fmt[i] & 0xff;
    11e4:	2a0003f6 	mov	w22, w0
    if(state == 0){
    11e8:	35000101 	cbnz	w1, 1208 <vprintf+0x80>
      if(c == '%'){
    11ec:	7100941f 	cmp	w0, #0x25
    11f0:	54000ba0 	b.eq	1364 <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
    11f4:	2a1603e1 	mov	w1, w22
    11f8:	2a1703e0 	mov	w0, w23
    11fc:	97ffffad 	bl	10b0 <putc>
    1200:	0b0002b5 	add	w21, w21, w0
    1204:	14000057 	b	1360 <vprintf+0x1d8>
      if(c == 'd'){
    1208:	7101901f 	cmp	w0, #0x64
    120c:	540002a1 	b.ne	1260 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
    1210:	37f80174 	tbnz	w20, #31, 123c <vprintf+0xb4>
    1214:	91002e76 	add	x22, x19, #0xb
    1218:	2a1403fa 	mov	w26, w20
    121c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1220:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    1224:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
    1228:	b9400261 	ldr	w1, [x19]
    122c:	2a1703e0 	mov	w0, w23
    1230:	97ffffaa 	bl	10d8 <printint>
        written += putc(fd, va_arg(ap, uint));
    1234:	0b0002b5 	add	w21, w21, w0
    1238:	14000048 	b	1358 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
    123c:	1100229a 	add	w26, w20, #0x8
    1240:	7100035f 	cmp	w26, #0x0
    1244:	5400008d 	b.le	1254 <vprintf+0xcc>
    1248:	91002e76 	add	x22, x19, #0xb
    124c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1250:	17fffff4 	b	1220 <vprintf+0x98>
    1254:	aa1303f6 	mov	x22, x19
    1258:	8b34c313 	add	x19, x24, w20, sxtw
    125c:	17fffff1 	b	1220 <vprintf+0x98>
      } else if(c == 'l') {
    1260:	7101b01f 	cmp	w0, #0x6c
    1264:	54000201 	b.ne	12a4 <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
    1268:	37f800d4 	tbnz	w20, #31, 1280 <vprintf+0xf8>
    126c:	91003e76 	add	x22, x19, #0xf
    1270:	2a1403fa 	mov	w26, w20
    1274:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1278:	52800003 	mov	w3, #0x0                   	// #0
    127c:	17ffffea 	b	1224 <vprintf+0x9c>
    1280:	1100229a 	add	w26, w20, #0x8
    1284:	7100035f 	cmp	w26, #0x0
    1288:	5400008d 	b.le	1298 <vprintf+0x110>
    128c:	91003e76 	add	x22, x19, #0xf
    1290:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1294:	17fffff9 	b	1278 <vprintf+0xf0>
    1298:	aa1303f6 	mov	x22, x19
    129c:	8b34c313 	add	x19, x24, w20, sxtw
    12a0:	17fffff6 	b	1278 <vprintf+0xf0>
      } else if(c == 'x') {
    12a4:	7101e01f 	cmp	w0, #0x78
    12a8:	54000221 	b.ne	12ec <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
    12ac:	37f800f4 	tbnz	w20, #31, 12c8 <vprintf+0x140>
    12b0:	91002e76 	add	x22, x19, #0xb
    12b4:	2a1403fa 	mov	w26, w20
    12b8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    12bc:	52800003 	mov	w3, #0x0                   	// #0
    12c0:	52800202 	mov	w2, #0x10                  	// #16
    12c4:	17ffffd9 	b	1228 <vprintf+0xa0>
    12c8:	1100229a 	add	w26, w20, #0x8
    12cc:	7100035f 	cmp	w26, #0x0
    12d0:	5400008d 	b.le	12e0 <vprintf+0x158>
    12d4:	91002e76 	add	x22, x19, #0xb
    12d8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    12dc:	17fffff8 	b	12bc <vprintf+0x134>
    12e0:	aa1303f6 	mov	x22, x19
    12e4:	8b34c313 	add	x19, x24, w20, sxtw
    12e8:	17fffff5 	b	12bc <vprintf+0x134>
      } else if(c == 'p') {
    12ec:	7101c01f 	cmp	w0, #0x70
    12f0:	54000521 	b.ne	1394 <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    12f4:	37f803f4 	tbnz	w20, #31, 1370 <vprintf+0x1e8>
    12f8:	91003e76 	add	x22, x19, #0xf
    12fc:	2a1403fa 	mov	w26, w20
    1300:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1304:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
    1308:	52800601 	mov	w1, #0x30                  	// #48
    130c:	2a1703e0 	mov	w0, w23
    1310:	97ffff68 	bl	10b0 <putc>
    1314:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    1318:	9000001c 	adrp	x28, 1000 <sched_setscheduler+0x4>
    131c:	912d139c 	add	x28, x28, #0xb44
  written += putc(fd, 'x');
    1320:	2a1703e0 	mov	w0, w23
    1324:	52800f01 	mov	w1, #0x78                  	// #120
    1328:	97ffff62 	bl	10b0 <putc>
    132c:	0b000273 	add	w19, w19, w0
    1330:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    1334:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    1338:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    133c:	38606b81 	ldrb	w1, [x28, x0]
    1340:	2a1703e0 	mov	w0, w23
    1344:	97ffff5b 	bl	10b0 <putc>
    1348:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    134c:	71000694 	subs	w20, w20, #0x1
    1350:	54ffff21 	b.ne	1334 <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
    1354:	0b1302b5 	add	w21, w21, w19
    1358:	2a1a03f4 	mov	w20, w26
    135c:	aa1603f3 	mov	x19, x22
      state = 0;
    1360:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
    1364:	91000739 	add	x25, x25, #0x1
  state = 0;
    1368:	2a1603e1 	mov	w1, w22
    136c:	17ffff94 	b	11bc <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
    1370:	1100229a 	add	w26, w20, #0x8
    1374:	7100035f 	cmp	w26, #0x0
    1378:	5400008d 	b.le	1388 <vprintf+0x200>
    137c:	91003e76 	add	x22, x19, #0xf
    1380:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1384:	17ffffe0 	b	1304 <vprintf+0x17c>
    1388:	aa1303f6 	mov	x22, x19
    138c:	8b34c313 	add	x19, x24, w20, sxtw
    1390:	17ffffdd 	b	1304 <vprintf+0x17c>
      } else if(c == 's'){
    1394:	7101cc1f 	cmp	w0, #0x73
    1398:	54000381 	b.ne	1408 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
    139c:	37f80214 	tbnz	w20, #31, 13dc <vprintf+0x254>
    13a0:	91003e61 	add	x1, x19, #0xf
    13a4:	aa1303e0 	mov	x0, x19
    13a8:	927df033 	and	x19, x1, #0xfffffffffffffff8
    13ac:	f9400016 	ldr	x22, [x0]
          s = "(null)";
    13b0:	90000000 	adrp	x0, 1000 <sched_setscheduler+0x4>
    13b4:	9127ec00 	add	x0, x0, #0x9fb
    13b8:	f10002df 	cmp	x22, #0x0
    13bc:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
    13c0:	394002c1 	ldrb	w1, [x22]
    13c4:	34fffce1 	cbz	w1, 1360 <vprintf+0x1d8>
          written += putc(fd, *s);
    13c8:	2a1703e0 	mov	w0, w23
          s++;
    13cc:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
    13d0:	97ffff38 	bl	10b0 <putc>
    13d4:	0b0002b5 	add	w21, w21, w0
          s++;
    13d8:	17fffffa 	b	13c0 <vprintf+0x238>
        s = va_arg(ap, char*);
    13dc:	11002281 	add	w1, w20, #0x8
    13e0:	7100003f 	cmp	w1, #0x0
    13e4:	540000cd 	b.le	13fc <vprintf+0x274>
    13e8:	91003e62 	add	x2, x19, #0xf
    13ec:	aa1303e0 	mov	x0, x19
    13f0:	2a0103f4 	mov	w20, w1
    13f4:	927df053 	and	x19, x2, #0xfffffffffffffff8
    13f8:	17ffffed 	b	13ac <vprintf+0x224>
    13fc:	8b34c300 	add	x0, x24, w20, sxtw
    1400:	2a0103f4 	mov	w20, w1
    1404:	17ffffea 	b	13ac <vprintf+0x224>
      } else if(c == 'c'){
    1408:	71018c1f 	cmp	w0, #0x63
    140c:	54000241 	b.ne	1454 <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
    1410:	37f80114 	tbnz	w20, #31, 1430 <vprintf+0x2a8>
    1414:	91002e76 	add	x22, x19, #0xb
    1418:	2a1403fa 	mov	w26, w20
    141c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1420:	39400261 	ldrb	w1, [x19]
    1424:	2a1703e0 	mov	w0, w23
    1428:	97ffff22 	bl	10b0 <putc>
    142c:	17ffff82 	b	1234 <vprintf+0xac>
    1430:	1100229a 	add	w26, w20, #0x8
    1434:	7100035f 	cmp	w26, #0x0
    1438:	5400008d 	b.le	1448 <vprintf+0x2c0>
    143c:	91002e76 	add	x22, x19, #0xb
    1440:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
    1444:	17fffff7 	b	1420 <vprintf+0x298>
    1448:	aa1303f6 	mov	x22, x19
    144c:	8b34c313 	add	x19, x24, w20, sxtw
    1450:	17fffff4 	b	1420 <vprintf+0x298>
      } else if(c == '%'){
    1454:	7100941f 	cmp	w0, #0x25
    1458:	54ffece0 	b.eq	11f4 <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
    145c:	2a1703e0 	mov	w0, w23
    1460:	528004a1 	mov	w1, #0x25                  	// #37
    1464:	97ffff13 	bl	10b0 <putc>
    1468:	0b0002b5 	add	w21, w21, w0
    146c:	17ffff62 	b	11f4 <vprintf+0x6c>

0000000000001470 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
    1470:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    1474:	910003fd 	mov	x29, sp
    1478:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
    147c:	910203e2 	add	x2, sp, #0x80
    1480:	a9030be2 	stp	x2, x2, [sp, #48]
    1484:	910143e2 	add	x2, sp, #0x50
    1488:	f90023e2 	str	x2, [sp, #64]
    148c:	128005e2 	mov	w2, #0xffffffd0            	// #-48
    1490:	b9004be2 	str	w2, [sp, #72]
    1494:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
    1498:	a9430fe2 	ldp	x2, x3, [sp, #48]
    149c:	a9010fe2 	stp	x2, x3, [sp, #16]
    14a0:	a9440fe2 	ldp	x2, x3, [sp, #64]
    14a4:	a9020fe2 	stp	x2, x3, [sp, #32]
    14a8:	910043e2 	add	x2, sp, #0x10
{
    14ac:	a90617e4 	stp	x4, x5, [sp, #96]
    14b0:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
    14b4:	97ffff35 	bl	1188 <vprintf>
  va_end(ap);
  return result;
}
    14b8:	a8c87bfd 	ldp	x29, x30, [sp], #128
    14bc:	d65f03c0 	ret

00000000000014c0 <printf>:

int
printf(const char *fmt, ...)
{
    14c0:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    14c4:	910003fd 	mov	x29, sp
    14c8:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
    14cc:	910243e1 	add	x1, sp, #0x90
    14d0:	a90307e1 	stp	x1, x1, [sp, #48]
    14d4:	910143e1 	add	x1, sp, #0x50
    14d8:	f90023e1 	str	x1, [sp, #64]
    14dc:	128006e1 	mov	w1, #0xffffffc8            	// #-56
    14e0:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
    14e4:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
    14e8:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
    14ec:	52800020 	mov	w0, #0x1                   	// #1
{
    14f0:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
    14f4:	a9430fe2 	ldp	x2, x3, [sp, #48]
    14f8:	a9010fe2 	stp	x2, x3, [sp, #16]
    14fc:	a9440fe2 	ldp	x2, x3, [sp, #64]
    1500:	a9020fe2 	stp	x2, x3, [sp, #32]
    1504:	910043e2 	add	x2, sp, #0x10
{
    1508:	a9079be5 	stp	x5, x6, [sp, #120]
    150c:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
    1510:	97ffff1e 	bl	1188 <vprintf>
  va_end(ap);
  return result;
}
    1514:	a8c97bfd 	ldp	x29, x30, [sp], #144
    1518:	d65f03c0 	ret

000000000000151c <free_locked>:
free_locked(void *ap)
{
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    151c:	b0000005 	adrp	x5, 2000 <hist.1+0x488>
    1520:	f945bca2 	ldr	x2, [x5, #2936]
  bp = (Header*)ap - 1;
    1524:	d1004003 	sub	x3, x0, #0x10
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1528:	f9400041 	ldr	x1, [x2]
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    152c:	eb03005f 	cmp	x2, x3
    1530:	54000342 	b.cs	1598 <free_locked+0x7c>  // b.hs, b.nlast
    1534:	eb01007f 	cmp	x3, x1
    1538:	540002a2 	b.cs	158c <free_locked+0x70>  // b.hs, b.nlast
      break;
  if(bp + bp->s.size == p->s.ptr){
    153c:	b85f8006 	ldur	w6, [x0, #-8]
    1540:	8b265064 	add	x4, x3, w6, uxtw #4
    1544:	eb04003f 	cmp	x1, x4
    1548:	540000a1 	b.ne	155c <free_locked+0x40>  // b.any
    bp->s.size += p->s.ptr->s.size;
    154c:	b9400824 	ldr	w4, [x1, #8]
    bp->s.ptr = p->s.ptr->s.ptr;
    1550:	f9400021 	ldr	x1, [x1]
    bp->s.size += p->s.ptr->s.size;
    1554:	0b060084 	add	w4, w4, w6
    1558:	b81f8004 	stur	w4, [x0, #-8]
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    155c:	b9400844 	ldr	w4, [x2, #8]
    1560:	f81f0001 	stur	x1, [x0, #-16]
    1564:	8b245046 	add	x6, x2, w4, uxtw #4
    1568:	eb06007f 	cmp	x3, x6
    156c:	540000a1 	b.ne	1580 <free_locked+0x64>  // b.any
    p->s.size += bp->s.size;
    1570:	b85f8000 	ldur	w0, [x0, #-8]
    p->s.ptr = bp->s.ptr;
    1574:	aa0103e3 	mov	x3, x1
    p->s.size += bp->s.size;
    1578:	0b040000 	add	w0, w0, w4
    157c:	b9000840 	str	w0, [x2, #8]
  } else
    p->s.ptr = bp;
  freep = p;
    1580:	f905bca2 	str	x2, [x5, #2936]
    1584:	f9000043 	str	x3, [x2]
}
    1588:	d65f03c0 	ret
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    158c:	eb01005f 	cmp	x2, x1
    1590:	540000c3 	b.cc	15a8 <free_locked+0x8c>  // b.lo, b.ul, b.last
    1594:	17ffffea 	b	153c <free_locked+0x20>
    1598:	eb01005f 	cmp	x2, x1
    159c:	54000063 	b.cc	15a8 <free_locked+0x8c>  // b.lo, b.ul, b.last
    15a0:	eb01007f 	cmp	x3, x1
    15a4:	54fffcc3 	b.cc	153c <free_locked+0x20>  // b.lo, b.ul, b.last
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    15a8:	aa0103e2 	mov	x2, x1
    15ac:	17ffffdf 	b	1528 <free_locked+0xc>

00000000000015b0 <heap_acquire>:
{
    15b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    15b4:	910003fd 	mov	x29, sp
    15b8:	a90153f3 	stp	x19, x20, [sp, #16]
    asm volatile("ldaxr %w0, [%1]"
    15bc:	b0000013 	adrp	x19, 2000 <hist.1+0x488>
    15c0:	912de273 	add	x19, x19, #0xb78
    15c4:	91002273 	add	x19, x19, #0x8
      asm volatile("stxr %w0, %w1, [%2]"
    15c8:	52800034 	mov	w20, #0x1                   	// #1
    asm volatile("ldaxr %w0, [%1]"
    15cc:	885ffe60 	ldaxr	w0, [x19]
    if(old == 0){
    15d0:	350000c0 	cbnz	w0, 15e8 <heap_acquire+0x38>
      asm volatile("stxr %w0, %w1, [%2]"
    15d4:	88007e74 	stxr	w0, w20, [x19]
      if(failed == 0)
    15d8:	350000a0 	cbnz	w0, 15ec <heap_acquire+0x3c>
}
    15dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    15e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    15e4:	d65f03c0 	ret
      asm volatile("clrex" ::: "memory");
    15e8:	d5033f5f 	clrex
    sched_yield();
    15ec:	97fffe90 	bl	102c <sched_yield>
  for(;;){
    15f0:	17fffff7 	b	15cc <heap_acquire+0x1c>

00000000000015f4 <free>:

void
free(void *ap)
{
  if(ap == 0)
    15f4:	b40001c0 	cbz	x0, 162c <free+0x38>
{
    15f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    15fc:	910003fd 	mov	x29, sp
    1600:	f9000fe0 	str	x0, [sp, #24]
    return;
  heap_acquire();
    1604:	97ffffeb 	bl	15b0 <heap_acquire>
  free_locked(ap);
    1608:	f9400fe0 	ldr	x0, [sp, #24]
    160c:	97ffffc4 	bl	151c <free_locked>
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    1610:	b0000000 	adrp	x0, 2000 <hist.1+0x488>
    1614:	912de000 	add	x0, x0, #0xb78
    1618:	52800001 	mov	w1, #0x0                   	// #0
    161c:	91002000 	add	x0, x0, #0x8
    1620:	889ffc01 	stlr	w1, [x0]
  heap_release();
}
    1624:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1628:	d65f03c0 	ret
    162c:	d65f03c0 	ret

0000000000001630 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1630:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1634:	910003fd 	mov	x29, sp
    1638:	a90153f3 	stp	x19, x20, [sp, #16]
  Header *p, *prevp;
  uint nunits;

  heap_acquire();
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    163c:	2a0003f3 	mov	w19, w0
    1640:	91003e73 	add	x19, x19, #0xf
{
    1644:	a9025bf5 	stp	x21, x22, [sp, #32]
  if((prevp = freep) == 0){
    1648:	b0000016 	adrp	x22, 2000 <hist.1+0x488>
    164c:	912de2d4 	add	x20, x22, #0xb78
{
    1650:	f9001bf7 	str	x23, [sp, #48]
  heap_acquire();
    1654:	97ffffd7 	bl	15b0 <heap_acquire>
  if((prevp = freep) == 0){
    1658:	f945bec1 	ldr	x1, [x22, #2936]
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    165c:	d344fe73 	lsr	x19, x19, #4
    1660:	11000673 	add	w19, w19, #0x1
  if((prevp = freep) == 0){
    1664:	b50000a1 	cbnz	x1, 1678 <malloc+0x48>
    base.s.ptr = freep = prevp = &base;
    1668:	91004281 	add	x1, x20, #0x10
    166c:	f905bec1 	str	x1, [x22, #2936]
    1670:	f9000a81 	str	x1, [x20, #16]
    base.s.size = 0;
    1674:	b9001a9f 	str	wzr, [x20, #24]
  if(nu < 4096)
    1678:	7140067f 	cmp	w19, #0x1, lsl #12
    167c:	52820015 	mov	w21, #0x1000                	// #4096
    1680:	1a952275 	csel	w21, w19, w21, cs	// cs = hs, nlast
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1684:	f9400020 	ldr	x0, [x1]
  p = sbrk(nu * sizeof(Header));
    1688:	531c6eb7 	lsl	w23, w21, #4
    if(p->s.size >= nunits){
    168c:	b9400802 	ldr	w2, [x0, #8]
    1690:	6b13005f 	cmp	w2, w19
    1694:	54000263 	b.cc	16e0 <malloc+0xb0>  // b.lo, b.ul, b.last
      if(p->s.size == nunits)
    1698:	540001a1 	b.ne	16cc <malloc+0x9c>  // b.any
        prevp->s.ptr = p->s.ptr;
    169c:	f9400002 	ldr	x2, [x0]
    16a0:	f9000022 	str	x2, [x1]
      else {
        p->s.size -= nunits;
        p += p->s.size;
        p->s.size = nunits;
      }
      freep = prevp;
    16a4:	f905bec1 	str	x1, [x22, #2936]
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    16a8:	91002294 	add	x20, x20, #0x8
    16ac:	52800001 	mov	w1, #0x0                   	// #0
    16b0:	889ffe81 	stlr	w1, [x20]
      heap_release();
      return (void*)(p + 1);
    16b4:	91004000 	add	x0, x0, #0x10
      if((p = morecore(nunits)) == 0){
        heap_release();
        return 0;
      }
  }
}
    16b8:	f9401bf7 	ldr	x23, [sp, #48]
    16bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    16c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    16c4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    16c8:	d65f03c0 	ret
        p->s.size -= nunits;
    16cc:	4b130042 	sub	w2, w2, w19
    16d0:	b9000802 	str	w2, [x0, #8]
        p += p->s.size;
    16d4:	8b225000 	add	x0, x0, w2, uxtw #4
        p->s.size = nunits;
    16d8:	b9000813 	str	w19, [x0, #8]
    16dc:	17fffff2 	b	16a4 <malloc+0x74>
    if(p == freep)
    16e0:	f9400281 	ldr	x1, [x20]
    16e4:	eb00003f 	cmp	x1, x0
    16e8:	540001e1 	b.ne	1724 <malloc+0xf4>  // b.any
  p = sbrk(nu * sizeof(Header));
    16ec:	2a1703e0 	mov	w0, w23
    16f0:	97fffdcb 	bl	e1c <sbrk>
  if(p == (char*)-1)
    16f4:	b100041f 	cmn	x0, #0x1
    16f8:	540000c1 	b.ne	1710 <malloc+0xe0>  // b.any
  asm volatile("stlr %w0, [%1]" :: "r"(zero), "r"(&heap_lock) : "memory");
    16fc:	91002294 	add	x20, x20, #0x8
    1700:	52800000 	mov	w0, #0x0                   	// #0
    1704:	889ffe80 	stlr	w0, [x20]
        return 0;
    1708:	d2800000 	mov	x0, #0x0                   	// #0
    170c:	17ffffeb 	b	16b8 <malloc+0x88>
  hp->s.size = nu;
    1710:	b9000815 	str	w21, [x0, #8]
  free_locked((void*)(hp + 1));
    1714:	91004000 	add	x0, x0, #0x10
    1718:	97ffff81 	bl	151c <free_locked>
  return freep;
    171c:	f9400280 	ldr	x0, [x20]
      if((p = morecore(nunits)) == 0){
    1720:	b4fffee0 	cbz	x0, 16fc <malloc+0xcc>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1724:	aa0003e1 	mov	x1, x0
    1728:	f9400000 	ldr	x0, [x0]
    if(p->s.size >= nunits){
    172c:	17ffffd8 	b	168c <malloc+0x5c>
