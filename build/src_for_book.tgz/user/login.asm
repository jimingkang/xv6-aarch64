
user/_login:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <main>:
  return -1;
}

int
main(void)
{
   0:	d10d43ff 	sub	sp, sp, #0x350
  char name[32], password[32], home[64], shell[64];

  if(tty_attach(0) < 0){
   4:	52800000 	mov	w0, #0x0                   	// #0
{
   8:	a9007bfd 	stp	x29, x30, [sp]
   c:	910003fd 	mov	x29, sp
  10:	a90153f3 	stp	x19, x20, [sp, #16]
  14:	a9025bf5 	stp	x21, x22, [sp, #32]
  18:	a90363f7 	stp	x23, x24, [sp, #48]
  1c:	f90023f9 	str	x25, [sp, #64]
  if(tty_attach(0) < 0){
  20:	940001c8 	bl	740 <tty_attach>
  24:	36f800c0 	tbz	w0, #31, 3c <main+0x3c>
    printf("login: cannot acquire ttyS0\n");
  28:	90000000 	adrp	x0, 0 <main>
  2c:	91351000 	add	x0, x0, #0xd44
  30:	9400032e 	bl	ce8 <printf>
      if(home[0] && chdir(home) < 0)
        chdir("/");
      exec(shell, argv);
      exec("/bin/sh", argv);
      printf("login: cannot execute %s\n", shell);
      exit(1);
  34:	52800020 	mov	w0, #0x1                   	// #1
  38:	94000150 	bl	578 <exit>
    printf("\nxv6-rpi3 login: ");
  3c:	90000018 	adrp	x24, 0 <main>
  40:	91358718 	add	x24, x24, #0xd61
      field[i+1] = p;
  44:	910263f9 	add	x25, sp, #0x98
  if(tty_attach(0) < 0){
  48:	52800077 	mov	w23, #0x3                   	// #3
    printf("\nxv6-rpi3 login: ");
  4c:	aa1803e0 	mov	x0, x24
  50:	94000326 	bl	ce8 <printf>
    gets(name, sizeof(name));
  54:	52800401 	mov	w1, #0x20                  	// #32
  58:	910163e0 	add	x0, sp, #0x58
  5c:	940000de 	bl	3d4 <gets>
    chomp(name);
  60:	910163e0 	add	x0, sp, #0x58
  64:	9400006d 	bl	218 <chomp>
    printf("Password: ");
  68:	90000000 	adrp	x0, 0 <main>
  6c:	9135cc00 	add	x0, x0, #0xd73
  70:	9400031e 	bl	ce8 <printf>
    gets(password, sizeof(password));
  74:	52800401 	mov	w1, #0x20                  	// #32
  78:	9101e3e0 	add	x0, sp, #0x78
  7c:	940000d6 	bl	3d4 <gets>
    chomp(password);
  80:	9101e3e0 	add	x0, sp, #0x78
  84:	94000065 	bl	218 <chomp>
  fd = open("/etc/passwd", O_RDONLY);
  88:	90000000 	adrp	x0, 0 <main>
  8c:	9135f800 	add	x0, x0, #0xd7e
  90:	52800001 	mov	w1, #0x0                   	// #0
  94:	94000151 	bl	5d8 <open>
  98:	2a0003f4 	mov	w20, w0
  if(fd < 0)
  9c:	36f80120 	tbz	w0, #31, c0 <main+0xc0>
    }
    printf("Login incorrect\n");
  a0:	90000000 	adrp	x0, 0 <main>
  a4:	91362800 	add	x0, x0, #0xd8a
  a8:	94000310 	bl	ce8 <printf>
    sleep_ticks(20);
  ac:	52800280 	mov	w0, #0x14                  	// #20
  b0:	94000168 	bl	650 <sleep_ticks>
  for(int attempt = 0; attempt < 3; attempt++){
  b4:	710006f7 	subs	w23, w23, #0x1
  b8:	54fffca1 	b.ne	4c <main+0x4c>  // b.any
  bc:	17ffffde 	b	34 <main+0x34>
  n = read(fd, buf, sizeof(buf) - 1);
  c0:	910543f5 	add	x21, sp, #0x150
  c4:	52803fe2 	mov	w2, #0x1ff                 	// #511
  c8:	aa1503e1 	mov	x1, x21
  cc:	94000134 	bl	59c <read>
  d0:	2a0003f3 	mov	w19, w0
  close(fd);
  d4:	2a1403e0 	mov	w0, w20
  d8:	94000137 	bl	5b4 <close>
  if(n <= 0)
  dc:	7100027f 	cmp	w19, #0x0
  e0:	54fffe0d 	b.le	a0 <main+0xa0>
  for(line = buf; *line; line = end){
  e4:	aa1503f4 	mov	x20, x21
  buf[n] = 0;
  e8:	38334abf 	strb	wzr, [x21, w19, uxtw]
  for(line = buf; *line; line = end){
  ec:	39400280 	ldrb	w0, [x20]
  f0:	34fffd80 	cbz	w0, a0 <main+0xa0>
    end = strchr(line, '\n');
  f4:	aa1403e0 	mov	x0, x20
  f8:	52800141 	mov	w1, #0xa                   	// #10
  fc:	940000ad 	bl	3b0 <strchr>
    if(end)
 100:	b4000120 	cbz	x0, 124 <main+0x124>
      *end++ = 0;
 104:	aa0003f3 	mov	x19, x0
 108:	3800167f 	strb	wzr, [x19], #1
    if(*line == 0 || *line == '#')
 10c:	39400280 	ldrb	w0, [x20]
 110:	71008c1f 	cmp	w0, #0x23
 114:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
 118:	540000e1 	b.ne	134 <main+0x134>  // b.any
  for(line = buf; *line; line = end){
 11c:	aa1303f4 	mov	x20, x19
 120:	17fffff3 	b	ec <main+0xec>
      end = line + strlen(line);
 124:	aa1403e0 	mov	x0, x20
 128:	9400008b 	bl	354 <strlen>
 12c:	8b204293 	add	x19, x20, w0, uxtw
 130:	17fffff7 	b	10c <main+0x10c>
    char *field[7], *p = line;
 134:	aa1403e0 	mov	x0, x20
    if(*line == 0 || *line == '#')
 138:	d2800036 	mov	x22, #0x1                   	// #1
      p = strchr(p, ':');
 13c:	52800741 	mov	w1, #0x3a                  	// #58
 140:	9400009c 	bl	3b0 <strchr>
      if(p == 0){
 144:	b4fffec0 	cbz	x0, 11c <main+0x11c>
      *p++ = 0;
 148:	3800141f 	strb	wzr, [x0], #1
      field[i+1] = p;
 14c:	f8367b20 	str	x0, [x25, x22, lsl #3]
    for(int i = 0; i < 6; i++){
 150:	910006d6 	add	x22, x22, #0x1
 154:	f1001edf 	cmp	x22, #0x7
 158:	54ffff21 	b.ne	13c <main+0x13c>  // b.any
    if(valid && strcmp(field[0], name) == 0 &&
 15c:	910163e1 	add	x1, sp, #0x58
 160:	aa1403e0 	mov	x0, x20
 164:	94000063 	bl	2f0 <strcmp>
 168:	35fffda0 	cbnz	w0, 11c <main+0x11c>
       strcmp(field[1], password) == 0){
 16c:	f94053e0 	ldr	x0, [sp, #160]
 170:	9101e3e1 	add	x1, sp, #0x78
 174:	9400005f 	bl	2f0 <strcmp>
    if(valid && strcmp(field[0], name) == 0 &&
 178:	35fffd20 	cbnz	w0, 11c <main+0x11c>
      strncpy(home, field[5], 63);
 17c:	f94063e1 	ldr	x1, [sp, #192]
 180:	910343f3 	add	x19, sp, #0xd0
 184:	528007e2 	mov	w2, #0x3f                  	// #63
 188:	aa1303e0 	mov	x0, x19
 18c:	9400003c 	bl	27c <strncpy>
      home[63] = 0;
 190:	39043fff 	strb	wzr, [sp, #271]
      strncpy(shell, field[6], 63);
 194:	f94067e1 	ldr	x1, [sp, #200]
 198:	528007e2 	mov	w2, #0x3f                  	// #63
 19c:	910443e0 	add	x0, sp, #0x110
 1a0:	94000037 	bl	27c <strncpy>
      shell[63] = 0;
 1a4:	39053fff 	strb	wzr, [sp, #335]
      char *argv[] = { "-sh", home, 0 };
 1a8:	90000000 	adrp	x0, 0 <main>
 1ac:	91366c00 	add	x0, x0, #0xd9b
      printf("Welcome %s\n", name);
 1b0:	910163e1 	add	x1, sp, #0x58
      char *argv[] = { "-sh", home, 0 };
 1b4:	a9154fe0 	stp	x0, x19, [sp, #336]
      printf("Welcome %s\n", name);
 1b8:	90000000 	adrp	x0, 0 <main>
 1bc:	91367c00 	add	x0, x0, #0xd9f
      char *argv[] = { "-sh", home, 0 };
 1c0:	f900b3ff 	str	xzr, [sp, #352]
      printf("Welcome %s\n", name);
 1c4:	940002c9 	bl	ce8 <printf>
      if(home[0] && chdir(home) < 0)
 1c8:	394343e0 	ldrb	w0, [sp, #208]
 1cc:	340000e0 	cbz	w0, 1e8 <main+0x1e8>
 1d0:	aa1303e0 	mov	x0, x19
 1d4:	94000113 	bl	620 <chdir>
 1d8:	36f80080 	tbz	w0, #31, 1e8 <main+0x1e8>
        chdir("/");
 1dc:	90000000 	adrp	x0, 0 <main>
 1e0:	9136ac00 	add	x0, x0, #0xdab
 1e4:	9400010f 	bl	620 <chdir>
      exec(shell, argv);
 1e8:	aa1503e1 	mov	x1, x21
 1ec:	910443e0 	add	x0, sp, #0x110
 1f0:	940000f7 	bl	5cc <exec>
      exec("/bin/sh", argv);
 1f4:	aa1503e1 	mov	x1, x21
 1f8:	90000000 	adrp	x0, 0 <main>
 1fc:	9136b400 	add	x0, x0, #0xdad
 200:	940000f3 	bl	5cc <exec>
      printf("login: cannot execute %s\n", shell);
 204:	910443e1 	add	x1, sp, #0x110
 208:	90000000 	adrp	x0, 0 <main>
 20c:	9136d400 	add	x0, x0, #0xdb5
 210:	940002b6 	bl	ce8 <printf>
 214:	17ffff88 	b	34 <main+0x34>

0000000000000218 <chomp>:
{
 218:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 21c:	910003fd 	mov	x29, sp
 220:	f9000bf3 	str	x19, [sp, #16]
 224:	aa0003f3 	mov	x19, x0
  int n = strlen(s);
 228:	9400004b 	bl	354 <strlen>
  while(n > 0 && (s[n-1] == '\n' || s[n-1] == '\r'))
 22c:	93407c00 	sxtw	x0, w0
 230:	d1000661 	sub	x1, x19, #0x1
 234:	7100001f 	cmp	w0, #0x0
 238:	540000ad 	b.le	24c <chomp+0x34>
 23c:	38606822 	ldrb	w2, [x1, x0]
 240:	7100285f 	cmp	w2, #0xa
 244:	7a4d1844 	ccmp	w2, #0xd, #0x4, ne	// ne = any
 248:	54000080 	b.eq	258 <chomp+0x40>  // b.none
}
 24c:	f9400bf3 	ldr	x19, [sp, #16]
 250:	a8c27bfd 	ldp	x29, x30, [sp], #32
 254:	d65f03c0 	ret
    s[--n] = 0;
 258:	3820683f 	strb	wzr, [x1, x0]
 25c:	d1000400 	sub	x0, x0, #0x1
 260:	17fffff5 	b	234 <chomp+0x1c>

0000000000000264 <strcpy>:
strcpy(char *s, const char *t)
{
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 264:	d2800002 	mov	x2, #0x0                   	// #0
 268:	38626823 	ldrb	w3, [x1, x2]
 26c:	38226803 	strb	w3, [x0, x2]
 270:	91000442 	add	x2, x2, #0x1
 274:	35ffffa3 	cbnz	w3, 268 <strcpy+0x4>
    ;
  return os;
}
 278:	d65f03c0 	ret

000000000000027c <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
  char *os = s;
  while(n > 0 && *t){
 27c:	d2800003 	mov	x3, #0x0                   	// #0
 280:	4b030044 	sub	w4, w2, w3
 284:	7100009f 	cmp	w4, #0x0
 288:	5400006d 	b.le	294 <strncpy+0x18>
 28c:	38636825 	ldrb	w5, [x1, x3]
 290:	350000e5 	cbnz	w5, 2ac <strncpy+0x30>
 294:	8b030003 	add	x3, x0, x3
 298:	d2800001 	mov	x1, #0x0                   	// #0
    *s++ = *t++;
    n--;
  }
  while(n-- > 0)
 29c:	4b010082 	sub	w2, w4, w1
 2a0:	7100005f 	cmp	w2, #0x0
 2a4:	540000ac 	b.gt	2b8 <strncpy+0x3c>
    *s++ = 0;
  return os;
}
 2a8:	d65f03c0 	ret
    *s++ = *t++;
 2ac:	38236805 	strb	w5, [x0, x3]
    n--;
 2b0:	91000463 	add	x3, x3, #0x1
 2b4:	17fffff3 	b	280 <strncpy+0x4>
    *s++ = 0;
 2b8:	3821687f 	strb	wzr, [x3, x1]
 2bc:	91000421 	add	x1, x1, #0x1
 2c0:	17fffff7 	b	29c <strncpy+0x20>

00000000000002c4 <strcat>:

char*
strcat(char *s, const char *t)
{
  char *os = s;
  while(*s)
 2c4:	aa0003e2 	mov	x2, x0
 2c8:	39400043 	ldrb	w3, [x2]
 2cc:	aa0203e4 	mov	x4, x2
    s++;
 2d0:	91000442 	add	x2, x2, #0x1
  while(*s)
 2d4:	35ffffa3 	cbnz	w3, 2c8 <strcat+0x4>
 2d8:	d2800002 	mov	x2, #0x0                   	// #0
  while((*s++ = *t++) != 0)
 2dc:	38626823 	ldrb	w3, [x1, x2]
 2e0:	38226883 	strb	w3, [x4, x2]
 2e4:	91000442 	add	x2, x2, #0x1
 2e8:	35ffffa3 	cbnz	w3, 2dc <strcat+0x18>
    ;
  return os;
}
 2ec:	d65f03c0 	ret

00000000000002f0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  while(*p && *p == *q)
 2f0:	d2800002 	mov	x2, #0x0                   	// #0
 2f4:	38626803 	ldrb	w3, [x0, x2]
 2f8:	38626824 	ldrb	w4, [x1, x2]
 2fc:	34000083 	cbz	w3, 30c <strcmp+0x1c>
 300:	91000442 	add	x2, x2, #0x1
 304:	6b04007f 	cmp	w3, w4
 308:	54ffff60 	b.eq	2f4 <strcmp+0x4>  // b.none
    p++, q++;
  return (uchar)*p - (uchar)*q;
}
 30c:	4b040060 	sub	w0, w3, w4
 310:	d65f03c0 	ret

0000000000000314 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
 314:	340001c2 	cbz	w2, 34c <strncmp+0x38>
 318:	39400003 	ldrb	w3, [x0]
 31c:	34000083 	cbz	w3, 32c <strncmp+0x18>
 320:	39400024 	ldrb	w4, [x1]
 324:	6b03009f 	cmp	w4, w3
 328:	540000a0 	b.eq	33c <strncmp+0x28>  // b.none
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
 32c:	39400000 	ldrb	w0, [x0]
 330:	39400021 	ldrb	w1, [x1]
 334:	4b010000 	sub	w0, w0, w1
}
 338:	d65f03c0 	ret
    n--, p++, q++;
 33c:	51000442 	sub	w2, w2, #0x1
 340:	91000400 	add	x0, x0, #0x1
 344:	91000421 	add	x1, x1, #0x1
 348:	17fffff3 	b	314 <strncmp>
    return 0;
 34c:	52800000 	mov	w0, #0x0                   	// #0
 350:	17fffffa 	b	338 <strncmp+0x24>

0000000000000354 <strlen>:
uint
strlen(const char *s)
{
  int n;

  for(n = 0; s[n]; n++)
 354:	d1000402 	sub	x2, x0, #0x1
 358:	d2800001 	mov	x1, #0x0                   	// #0
 35c:	aa0103e0 	mov	x0, x1
 360:	91000421 	add	x1, x1, #0x1
 364:	38616843 	ldrb	w3, [x2, x1]
 368:	35ffffa3 	cbnz	w3, 35c <strlen+0x8>
    ;
  return n;
}
 36c:	d65f03c0 	ret

0000000000000370 <strnlen>:

uint
strnlen(const char *s, uint max)
{
  uint n = 0;
  while(n < max && s[n])
 370:	d1000403 	sub	x3, x0, #0x1
 374:	d2800002 	mov	x2, #0x0                   	// #0
 378:	2a0203e0 	mov	w0, w2
 37c:	6b02003f 	cmp	w1, w2
 380:	54000089 	b.ls	390 <strnlen+0x20>  // b.plast
 384:	91000442 	add	x2, x2, #0x1
 388:	38626864 	ldrb	w4, [x3, x2]
 38c:	35ffff64 	cbnz	w4, 378 <strnlen+0x8>
    n++;
  return n;
}
 390:	d65f03c0 	ret

0000000000000394 <memset>:
void*
memset(void *dst, int c, uint n)
{
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 394:	d2800003 	mov	x3, #0x0                   	// #0
 398:	6b03005f 	cmp	w2, w3
 39c:	54000048 	b.hi	3a4 <memset+0x10>  // b.pmore
    cdst[i] = c;
  }
  return dst;
}
 3a0:	d65f03c0 	ret
    cdst[i] = c;
 3a4:	38236801 	strb	w1, [x0, x3]
  for(i = 0; i < n; i++){
 3a8:	91000463 	add	x3, x3, #0x1
 3ac:	17fffffb 	b	398 <memset+0x4>

00000000000003b0 <strchr>:

char*
strchr(const char *s, char c)
{
 3b0:	12001c21 	and	w1, w1, #0xff
  for(; *s; s++)
 3b4:	39400002 	ldrb	w2, [x0]
 3b8:	35000062 	cbnz	w2, 3c4 <strchr+0x14>
    if(*s == c)
      return (char*)s;
  return 0;
 3bc:	d2800000 	mov	x0, #0x0                   	// #0
}
 3c0:	d65f03c0 	ret
    if(*s == c)
 3c4:	6b01005f 	cmp	w2, w1
 3c8:	54ffffc0 	b.eq	3c0 <strchr+0x10>  // b.none
  for(; *s; s++)
 3cc:	91000400 	add	x0, x0, #0x1
 3d0:	17fffff9 	b	3b4 <strchr+0x4>

00000000000003d4 <gets>:

char*
gets(char *buf, int max)
{
 3d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 3d8:	910003fd 	mov	x29, sp
 3dc:	a90153f3 	stp	x19, x20, [sp, #16]
 3e0:	aa0003f3 	mov	x19, x0
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 3e4:	d2800014 	mov	x20, #0x0                   	// #0
{
 3e8:	f9001bf7 	str	x23, [sp, #48]
 3ec:	2a0103f7 	mov	w23, w1
 3f0:	a9025bf5 	stp	x21, x22, [sp, #32]
  for(i=0; i+1 < max; ){
 3f4:	11000695 	add	w21, w20, #0x1
 3f8:	2a1403f6 	mov	w22, w20
 3fc:	6b1702bf 	cmp	w21, w23
 400:	540000ea 	b.ge	41c <gets+0x48>  // b.tcont
    cc = read(0, &c, 1);
 404:	91013fe1 	add	x1, sp, #0x4f
 408:	52800022 	mov	w2, #0x1                   	// #1
 40c:	52800000 	mov	w0, #0x0                   	// #0
 410:	94000063 	bl	59c <read>
    if(cc < 1)
 414:	7100001f 	cmp	w0, #0x0
 418:	5400012c 	b.gt	43c <gets+0x68>
  for(i=0; i+1 < max; ){
 41c:	2a1603f5 	mov	w21, w22
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
      break;
  }
  buf[i] = '\0';
 420:	38354a7f 	strb	wzr, [x19, w21, uxtw]
  return buf;
}
 424:	aa1303e0 	mov	x0, x19
 428:	f9401bf7 	ldr	x23, [sp, #48]
 42c:	a94153f3 	ldp	x19, x20, [sp, #16]
 430:	a9425bf5 	ldp	x21, x22, [sp, #32]
 434:	a8c57bfd 	ldp	x29, x30, [sp], #80
 438:	d65f03c0 	ret
    buf[i++] = c;
 43c:	39413fe0 	ldrb	w0, [sp, #79]
 440:	38346a60 	strb	w0, [x19, x20]
    if(c == '\n' || c == '\r')
 444:	91000694 	add	x20, x20, #0x1
 448:	7100281f 	cmp	w0, #0xa
 44c:	7a4d1804 	ccmp	w0, #0xd, #0x4, ne	// ne = any
 450:	54fffd21 	b.ne	3f4 <gets+0x20>  // b.any
 454:	17fffff3 	b	420 <gets+0x4c>

0000000000000458 <stat>:

int
stat(const char *n, struct stat *st)
{
 458:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 45c:	910003fd 	mov	x29, sp
 460:	a90153f3 	stp	x19, x20, [sp, #16]
 464:	aa0103f3 	mov	x19, x1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 468:	52800001 	mov	w1, #0x0                   	// #0
 46c:	9400005b 	bl	5d8 <open>
  if(fd < 0)
 470:	37f80160 	tbnz	w0, #31, 49c <stat+0x44>
    return -1;
  r = fstat(fd, st);
 474:	aa1303e1 	mov	x1, x19
 478:	2a0003f4 	mov	w20, w0
 47c:	94000060 	bl	5fc <fstat>
 480:	2a0003f3 	mov	w19, w0
  close(fd);
 484:	2a1403e0 	mov	w0, w20
 488:	9400004b 	bl	5b4 <close>
  return r;
}
 48c:	2a1303e0 	mov	w0, w19
 490:	a94153f3 	ldp	x19, x20, [sp, #16]
 494:	a8c27bfd 	ldp	x29, x30, [sp], #32
 498:	d65f03c0 	ret
    return -1;
 49c:	12800013 	mov	w19, #0xffffffff            	// #-1
 4a0:	17fffffb 	b	48c <stat+0x34>

00000000000004a4 <atoi>:

int
atoi(const char *s)
{
 4a4:	aa0003e2 	mov	x2, x0
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    n = n*10 + *s++ - '0';
 4a8:	52800144 	mov	w4, #0xa                   	// #10
  n = 0;
 4ac:	52800000 	mov	w0, #0x0                   	// #0
  while('0' <= *s && *s <= '9')
 4b0:	39400043 	ldrb	w3, [x2]
 4b4:	5100c061 	sub	w1, w3, #0x30
 4b8:	12001c21 	and	w1, w1, #0xff
 4bc:	7100243f 	cmp	w1, #0x9
 4c0:	54000049 	b.ls	4c8 <atoi+0x24>  // b.plast
  return n;
}
 4c4:	d65f03c0 	ret
    n = n*10 + *s++ - '0';
 4c8:	1b040c01 	madd	w1, w0, w4, w3
 4cc:	91000442 	add	x2, x2, #0x1
 4d0:	5100c020 	sub	w0, w1, #0x30
 4d4:	17fffff7 	b	4b0 <atoi+0xc>

00000000000004d8 <memmove>:
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 4d8:	eb01001f 	cmp	x0, x1
 4dc:	54000263 	b.cc	528 <memmove+0x50>  // b.lo, b.ul, b.last
    while(n-- > 0)
      *dst++ = *src++;
  } else {
    dst += n;
 4e0:	8b22c005 	add	x5, x0, w2, sxtw
    src += n;
 4e4:	8b22c021 	add	x1, x1, w2, sxtw
    while(n-- > 0)
 4e8:	d2800003 	mov	x3, #0x0                   	// #0
 4ec:	d1000463 	sub	x3, x3, #0x1
 4f0:	11000464 	add	w4, w3, #0x1
 4f4:	0b020084 	add	w4, w4, w2
 4f8:	7100009f 	cmp	w4, #0x0
 4fc:	5400014d 	b.le	524 <memmove+0x4c>
      *--dst = *--src;
 500:	38636824 	ldrb	w4, [x1, x3]
 504:	382368a4 	strb	w4, [x5, x3]
 508:	17fffff9 	b	4ec <memmove+0x14>
      *dst++ = *src++;
 50c:	38636824 	ldrb	w4, [x1, x3]
 510:	38236804 	strb	w4, [x0, x3]
 514:	91000463 	add	x3, x3, #0x1
    while(n-- > 0)
 518:	4b030044 	sub	w4, w2, w3
 51c:	7100009f 	cmp	w4, #0x0
 520:	54ffff6c 	b.gt	50c <memmove+0x34>
  }
  return vdst;
}
 524:	d65f03c0 	ret
 528:	d2800003 	mov	x3, #0x0                   	// #0
 52c:	17fffffb 	b	518 <memmove+0x40>

0000000000000530 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 530:	2a0203e2 	mov	w2, w2
    if (*p1 != *p2) {
 534:	d1000421 	sub	x1, x1, #0x1
  while (n-- > 0) {
 538:	d2800004 	mov	x4, #0x0                   	// #0
 53c:	eb02009f 	cmp	x4, x2
 540:	54000061 	b.ne	54c <memcmp+0x1c>  // b.any
      return *p1 - *p2;
    }
    p1++;
    p2++;
  }
  return 0;
 544:	52800000 	mov	w0, #0x0                   	// #0
 548:	14000007 	b	564 <memcmp+0x34>
    if (*p1 != *p2) {
 54c:	38646803 	ldrb	w3, [x0, x4]
 550:	91000484 	add	x4, x4, #0x1
 554:	38646825 	ldrb	w5, [x1, x4]
 558:	6b05007f 	cmp	w3, w5
 55c:	54ffff00 	b.eq	53c <memcmp+0xc>  // b.none
      return *p1 - *p2;
 560:	4b050060 	sub	w0, w3, w5
}
 564:	d65f03c0 	ret

0000000000000568 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
 568:	17ffffdc 	b	4d8 <memmove>

000000000000056c <fork>:
// generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 mov x7, #SYS_fork
 56c:	d2800027 	mov	x7, #0x1                   	// #1
 svc #0
 570:	d4000001 	svc	#0x0
 ret
 574:	d65f03c0 	ret

0000000000000578 <exit>:
.global exit
exit:
 mov x7, #SYS_exit
 578:	d2800047 	mov	x7, #0x2                   	// #2
 svc #0
 57c:	d4000001 	svc	#0x0
 ret
 580:	d65f03c0 	ret

0000000000000584 <wait>:
.global wait
wait:
 mov x7, #SYS_wait
 584:	d2800067 	mov	x7, #0x3                   	// #3
 svc #0
 588:	d4000001 	svc	#0x0
 ret
 58c:	d65f03c0 	ret

0000000000000590 <pipe>:
.global pipe
pipe:
 mov x7, #SYS_pipe
 590:	d2800087 	mov	x7, #0x4                   	// #4
 svc #0
 594:	d4000001 	svc	#0x0
 ret
 598:	d65f03c0 	ret

000000000000059c <read>:
.global read
read:
 mov x7, #SYS_read
 59c:	d28000a7 	mov	x7, #0x5                   	// #5
 svc #0
 5a0:	d4000001 	svc	#0x0
 ret
 5a4:	d65f03c0 	ret

00000000000005a8 <write>:
.global write
write:
 mov x7, #SYS_write
 5a8:	d2800207 	mov	x7, #0x10                  	// #16
 svc #0
 5ac:	d4000001 	svc	#0x0
 ret
 5b0:	d65f03c0 	ret

00000000000005b4 <close>:
.global close
close:
 mov x7, #SYS_close
 5b4:	d28002a7 	mov	x7, #0x15                  	// #21
 svc #0
 5b8:	d4000001 	svc	#0x0
 ret
 5bc:	d65f03c0 	ret

00000000000005c0 <kill>:
.global kill
kill:
 mov x7, #SYS_kill
 5c0:	d28000c7 	mov	x7, #0x6                   	// #6
 svc #0
 5c4:	d4000001 	svc	#0x0
 ret
 5c8:	d65f03c0 	ret

00000000000005cc <exec>:
.global exec
exec:
 mov x7, #SYS_exec
 5cc:	d28000e7 	mov	x7, #0x7                   	// #7
 svc #0
 5d0:	d4000001 	svc	#0x0
 ret
 5d4:	d65f03c0 	ret

00000000000005d8 <open>:
.global open
open:
 mov x7, #SYS_open
 5d8:	d28001e7 	mov	x7, #0xf                   	// #15
 svc #0
 5dc:	d4000001 	svc	#0x0
 ret
 5e0:	d65f03c0 	ret

00000000000005e4 <mknod>:
.global mknod
mknod:
 mov x7, #SYS_mknod
 5e4:	d2800227 	mov	x7, #0x11                  	// #17
 svc #0
 5e8:	d4000001 	svc	#0x0
 ret
 5ec:	d65f03c0 	ret

00000000000005f0 <unlink>:
.global unlink
unlink:
 mov x7, #SYS_unlink
 5f0:	d2800247 	mov	x7, #0x12                  	// #18
 svc #0
 5f4:	d4000001 	svc	#0x0
 ret
 5f8:	d65f03c0 	ret

00000000000005fc <fstat>:
.global fstat
fstat:
 mov x7, #SYS_fstat
 5fc:	d2800107 	mov	x7, #0x8                   	// #8
 svc #0
 600:	d4000001 	svc	#0x0
 ret
 604:	d65f03c0 	ret

0000000000000608 <link>:
.global link
link:
 mov x7, #SYS_link
 608:	d2800267 	mov	x7, #0x13                  	// #19
 svc #0
 60c:	d4000001 	svc	#0x0
 ret
 610:	d65f03c0 	ret

0000000000000614 <mkdir>:
.global mkdir
mkdir:
 mov x7, #SYS_mkdir
 614:	d2800287 	mov	x7, #0x14                  	// #20
 svc #0
 618:	d4000001 	svc	#0x0
 ret
 61c:	d65f03c0 	ret

0000000000000620 <chdir>:
.global chdir
chdir:
 mov x7, #SYS_chdir
 620:	d2800127 	mov	x7, #0x9                   	// #9
 svc #0
 624:	d4000001 	svc	#0x0
 ret
 628:	d65f03c0 	ret

000000000000062c <dup>:
.global dup
dup:
 mov x7, #SYS_dup
 62c:	d2800147 	mov	x7, #0xa                   	// #10
 svc #0
 630:	d4000001 	svc	#0x0
 ret
 634:	d65f03c0 	ret

0000000000000638 <getpid>:
.global getpid
getpid:
 mov x7, #SYS_getpid
 638:	d2800167 	mov	x7, #0xb                   	// #11
 svc #0
 63c:	d4000001 	svc	#0x0
 ret
 640:	d65f03c0 	ret

0000000000000644 <sbrk>:
.global sbrk
sbrk:
 mov x7, #SYS_sbrk
 644:	d2800187 	mov	x7, #0xc                   	// #12
 svc #0
 648:	d4000001 	svc	#0x0
 ret
 64c:	d65f03c0 	ret

0000000000000650 <sleep_ticks>:
.global sleep_ticks
sleep_ticks:
 mov x7, #SYS_sleep
 650:	d28001a7 	mov	x7, #0xd                   	// #13
 svc #0
 654:	d4000001 	svc	#0x0
 ret
 658:	d65f03c0 	ret

000000000000065c <uptime>:
.global uptime
uptime:
 mov x7, #SYS_uptime
 65c:	d28001c7 	mov	x7, #0xe                   	// #14
 svc #0
 660:	d4000001 	svc	#0x0
 ret
 664:	d65f03c0 	ret

0000000000000668 <ps>:
.global ps
ps:
 mov x7, #SYS_ps
 668:	d28002c7 	mov	x7, #0x16                  	// #22
 svc #0
 66c:	d4000001 	svc	#0x0
 ret
 670:	d65f03c0 	ret

0000000000000674 <ext2read>:
.global ext2read
ext2read:
 mov x7, #SYS_ext2read
 674:	d28002e7 	mov	x7, #0x17                  	// #23
 svc #0
 678:	d4000001 	svc	#0x0
 ret
 67c:	d65f03c0 	ret

0000000000000680 <ext2readdir>:
.global ext2readdir
ext2readdir:
 mov x7, #SYS_ext2readdir
 680:	d2800307 	mov	x7, #0x18                  	// #24
 svc #0
 684:	d4000001 	svc	#0x0
 ret
 688:	d65f03c0 	ret

000000000000068c <sync_create>:
.global sync_create
sync_create:
 mov x7, #SYS_sync_create
 68c:	d2800327 	mov	x7, #0x19                  	// #25
 svc #0
 690:	d4000001 	svc	#0x0
 ret
 694:	d65f03c0 	ret

0000000000000698 <sync_wait>:
.global sync_wait
sync_wait:
 mov x7, #SYS_sync_wait
 698:	d2800347 	mov	x7, #0x1a                  	// #26
 svc #0
 69c:	d4000001 	svc	#0x0
 ret
 6a0:	d65f03c0 	ret

00000000000006a4 <sync_signal>:
.global sync_signal
sync_signal:
 mov x7, #SYS_sync_signal
 6a4:	d2800367 	mov	x7, #0x1b                  	// #27
 svc #0
 6a8:	d4000001 	svc	#0x0
 ret
 6ac:	d65f03c0 	ret

00000000000006b0 <sync_reset>:
.global sync_reset
sync_reset:
 mov x7, #SYS_sync_reset
 6b0:	d2800387 	mov	x7, #0x1c                  	// #28
 svc #0
 6b4:	d4000001 	svc	#0x0
 ret
 6b8:	d65f03c0 	ret

00000000000006bc <sync_atomic>:
.global sync_atomic
sync_atomic:
 mov x7, #SYS_sync_atomic
 6bc:	d28003a7 	mov	x7, #0x1d                  	// #29
 svc #0
 6c0:	d4000001 	svc	#0x0
 ret
 6c4:	d65f03c0 	ret

00000000000006c8 <sync_destroy>:
.global sync_destroy
sync_destroy:
 mov x7, #SYS_sync_destroy
 6c8:	d28003c7 	mov	x7, #0x1e                  	// #30
 svc #0
 6cc:	d4000001 	svc	#0x0
 ret
 6d0:	d65f03c0 	ret

00000000000006d4 <udp_bind>:
.global udp_bind
udp_bind:
 mov x7, #SYS_udp_bind
 6d4:	d28003e7 	mov	x7, #0x1f                  	// #31
 svc #0
 6d8:	d4000001 	svc	#0x0
 ret
 6dc:	d65f03c0 	ret

00000000000006e0 <udp_unbind>:
.global udp_unbind
udp_unbind:
 mov x7, #SYS_udp_unbind
 6e0:	d2800407 	mov	x7, #0x20                  	// #32
 svc #0
 6e4:	d4000001 	svc	#0x0
 ret
 6e8:	d65f03c0 	ret

00000000000006ec <udp_send>:
.global udp_send
udp_send:
 mov x7, #SYS_udp_send
 6ec:	d2800427 	mov	x7, #0x21                  	// #33
 svc #0
 6f0:	d4000001 	svc	#0x0
 ret
 6f4:	d65f03c0 	ret

00000000000006f8 <udp_recv>:
.global udp_recv
udp_recv:
 mov x7, #SYS_udp_recv
 6f8:	d2800447 	mov	x7, #0x22                  	// #34
 svc #0
 6fc:	d4000001 	svc	#0x0
 ret
 700:	d65f03c0 	ret

0000000000000704 <udp_tryrecv>:
.global udp_tryrecv
udp_tryrecv:
 mov x7, #SYS_udp_tryrecv
 704:	d2800707 	mov	x7, #0x38                  	// #56
 svc #0
 708:	d4000001 	svc	#0x0
 ret
 70c:	d65f03c0 	ret

0000000000000710 <udp_recv_timeout>:
.global udp_recv_timeout
udp_recv_timeout:
 mov x7, #SYS_udp_recv_timeout
 710:	d2800747 	mov	x7, #0x3a                  	// #58
 svc #0
 714:	d4000001 	svc	#0x0
 ret
 718:	d65f03c0 	ret

000000000000071c <icmp_send>:
.global icmp_send
icmp_send:
 mov x7, #SYS_icmp_send
 71c:	d2800467 	mov	x7, #0x23                  	// #35
 svc #0
 720:	d4000001 	svc	#0x0
 ret
 724:	d65f03c0 	ret

0000000000000728 <icmp_recv>:
.global icmp_recv
icmp_recv:
 mov x7, #SYS_icmp_recv
 728:	d2800487 	mov	x7, #0x24                  	// #36
 svc #0
 72c:	d4000001 	svc	#0x0
 ret
 730:	d65f03c0 	ret

0000000000000734 <mount>:
.global mount
mount:
 mov x7, #SYS_mount
 734:	d28004a7 	mov	x7, #0x25                  	// #37
 svc #0
 738:	d4000001 	svc	#0x0
 ret
 73c:	d65f03c0 	ret

0000000000000740 <tty_attach>:
.global tty_attach
tty_attach:
 mov x7, #SYS_tty_attach
 740:	d28004c7 	mov	x7, #0x26                  	// #38
 svc #0
 744:	d4000001 	svc	#0x0
 ret
 748:	d65f03c0 	ret

000000000000074c <tty_set_foreground>:
.global tty_set_foreground
tty_set_foreground:
 mov x7, #SYS_tty_set_foreground
 74c:	d2800727 	mov	x7, #0x39                  	// #57
 svc #0
 750:	d4000001 	svc	#0x0
 ret
 754:	d65f03c0 	ret

0000000000000758 <vmdump>:
.global vmdump
vmdump:
 mov x7, #SYS_vmdump
 758:	d28004e7 	mov	x7, #0x27                  	// #39
 svc #0
 75c:	d4000001 	svc	#0x0
 ret
 760:	d65f03c0 	ret

0000000000000764 <wifi_connect>:
.global wifi_connect
wifi_connect:
 mov x7, #SYS_wifi_connect
 764:	d2800507 	mov	x7, #0x28                  	// #40
 svc #0
 768:	d4000001 	svc	#0x0
 ret
 76c:	d65f03c0 	ret

0000000000000770 <net_dhcp>:
.global net_dhcp
net_dhcp:
 mov x7, #SYS_net_dhcp
 770:	d2800527 	mov	x7, #0x29                  	// #41
 svc #0
 774:	d4000001 	svc	#0x0
 ret
 778:	d65f03c0 	ret

000000000000077c <tcp_listen>:
.global tcp_listen
tcp_listen:
 mov x7, #SYS_tcp_listen
 77c:	d2800547 	mov	x7, #0x2a                  	// #42
 svc #0
 780:	d4000001 	svc	#0x0
 ret
 784:	d65f03c0 	ret

0000000000000788 <tcp_accept>:
.global tcp_accept
tcp_accept:
 mov x7, #SYS_tcp_accept
 788:	d2800567 	mov	x7, #0x2b                  	// #43
 svc #0
 78c:	d4000001 	svc	#0x0
 ret
 790:	d65f03c0 	ret

0000000000000794 <tcp_read>:
.global tcp_read
tcp_read:
 mov x7, #SYS_tcp_read
 794:	d2800587 	mov	x7, #0x2c                  	// #44
 svc #0
 798:	d4000001 	svc	#0x0
 ret
 79c:	d65f03c0 	ret

00000000000007a0 <tcp_write>:
.global tcp_write
tcp_write:
 mov x7, #SYS_tcp_write
 7a0:	d28005a7 	mov	x7, #0x2d                  	// #45
 svc #0
 7a4:	d4000001 	svc	#0x0
 ret
 7a8:	d65f03c0 	ret

00000000000007ac <tcp_close>:
.global tcp_close
tcp_close:
 mov x7, #SYS_tcp_close
 7ac:	d28005c7 	mov	x7, #0x2e                  	// #46
 svc #0
 7b0:	d4000001 	svc	#0x0
 ret
 7b4:	d65f03c0 	ret

00000000000007b8 <socket_listen>:
.global socket_listen
socket_listen:
 mov x7, #SYS_socket_listen
 7b8:	d28005e7 	mov	x7, #0x2f                  	// #47
 svc #0
 7bc:	d4000001 	svc	#0x0
 ret
 7c0:	d65f03c0 	ret

00000000000007c4 <socket_accept>:
.global socket_accept
socket_accept:
 mov x7, #SYS_socket_accept
 7c4:	d2800607 	mov	x7, #0x30                  	// #48
 svc #0
 7c8:	d4000001 	svc	#0x0
 ret
 7cc:	d65f03c0 	ret

00000000000007d0 <epoll_create>:
.global epoll_create
epoll_create:
 mov x7, #SYS_epoll_create
 7d0:	d2800627 	mov	x7, #0x31                  	// #49
 svc #0
 7d4:	d4000001 	svc	#0x0
 ret
 7d8:	d65f03c0 	ret

00000000000007dc <epoll_ctl>:
.global epoll_ctl
epoll_ctl:
 mov x7, #SYS_epoll_ctl
 7dc:	d2800647 	mov	x7, #0x32                  	// #50
 svc #0
 7e0:	d4000001 	svc	#0x0
 ret
 7e4:	d65f03c0 	ret

00000000000007e8 <epoll_wait>:
.global epoll_wait
epoll_wait:
 mov x7, #SYS_epoll_wait
 7e8:	d2800667 	mov	x7, #0x33                  	// #51
 svc #0
 7ec:	d4000001 	svc	#0x0
 ret
 7f0:	d65f03c0 	ret

00000000000007f4 <fcntl>:
.global fcntl
fcntl:
 mov x7, #SYS_fcntl
 7f4:	d2800687 	mov	x7, #0x34                  	// #52
 svc #0
 7f8:	d4000001 	svc	#0x0
 ret
 7fc:	d65f03c0 	ret

0000000000000800 <pty_open>:
.global pty_open
pty_open:
 mov x7, #SYS_pty_open
 800:	d28006a7 	mov	x7, #0x35                  	// #53
 svc #0
 804:	d4000001 	svc	#0x0
 ret
 808:	d65f03c0 	ret

000000000000080c <getrandom>:
.global getrandom
getrandom:
 mov x7, #SYS_getrandom
 80c:	d28006c7 	mov	x7, #0x36                  	// #54
 svc #0
 810:	d4000001 	svc	#0x0
 ret
 814:	d65f03c0 	ret

0000000000000818 <rename>:
.global rename
rename:
 mov x7, #SYS_rename
 818:	d28006e7 	mov	x7, #0x37                  	// #55
 svc #0
 81c:	d4000001 	svc	#0x0
 ret
 820:	d65f03c0 	ret

0000000000000824 <sched_setscheduler>:
.global sched_setscheduler
sched_setscheduler:
 mov x7, #SYS_sched_setscheduler
 824:	d2800767 	mov	x7, #0x3b                  	// #59
 svc #0
 828:	d4000001 	svc	#0x0
 ret
 82c:	d65f03c0 	ret

0000000000000830 <sched_getinfo>:
.global sched_getinfo
sched_getinfo:
 mov x7, #SYS_sched_getinfo
 830:	d2800787 	mov	x7, #0x3c                  	// #60
 svc #0
 834:	d4000001 	svc	#0x0
 ret
 838:	d65f03c0 	ret

000000000000083c <setnice>:
.global setnice
setnice:
 mov x7, #SYS_setnice
 83c:	d28007a7 	mov	x7, #0x3d                  	// #61
 svc #0
 840:	d4000001 	svc	#0x0
 ret
 844:	d65f03c0 	ret

0000000000000848 <sched_setaffinity>:
.global sched_setaffinity
sched_setaffinity:
 mov x7, #SYS_sched_setaffinity
 848:	d28007c7 	mov	x7, #0x3e                  	// #62
 svc #0
 84c:	d4000001 	svc	#0x0
 ret
 850:	d65f03c0 	ret

0000000000000854 <sched_yield>:
.global sched_yield
sched_yield:
 mov x7, #SYS_sched_yield
 854:	d28007e7 	mov	x7, #0x3f                  	// #63
 svc #0
 858:	d4000001 	svc	#0x0
 ret
 85c:	d65f03c0 	ret

0000000000000860 <clock_us>:
.global clock_us
clock_us:
 mov x7, #SYS_clock_us
 860:	d2800807 	mov	x7, #0x40                  	// #64
 svc #0
 864:	d4000001 	svc	#0x0
 ret
 868:	d65f03c0 	ret

000000000000086c <getcpu>:
.global getcpu
getcpu:
 mov x7, #SYS_getcpu
 86c:	d2800827 	mov	x7, #0x41                  	// #65
 svc #0
 870:	d4000001 	svc	#0x0
 ret
 874:	d65f03c0 	ret

0000000000000878 <clone>:
.global clone
clone:
 mov x7, #SYS_clone
 878:	d2800847 	mov	x7, #0x42                  	// #66
 svc #0
 87c:	d4000001 	svc	#0x0
 ret
 880:	d65f03c0 	ret

0000000000000884 <texit>:
.global texit
texit:
 mov x7, #SYS_texit
 884:	d2800867 	mov	x7, #0x43                  	// #67
 svc #0
 888:	d4000001 	svc	#0x0
 ret
 88c:	d65f03c0 	ret

0000000000000890 <tjoin>:
.global tjoin
tjoin:
 mov x7, #SYS_tjoin
 890:	d2800887 	mov	x7, #0x44                  	// #68
 svc #0
 894:	d4000001 	svc	#0x0
 ret
 898:	d65f03c0 	ret

000000000000089c <gettid>:
.global gettid
gettid:
 mov x7, #SYS_gettid
 89c:	d28008a7 	mov	x7, #0x45                  	// #69
 svc #0
 8a0:	d4000001 	svc	#0x0
 ret
 8a4:	d65f03c0 	ret

00000000000008a8 <socket>:
.global socket
socket:
 mov x7, #SYS_socket
 8a8:	d28008c7 	mov	x7, #0x46                  	// #70
 svc #0
 8ac:	d4000001 	svc	#0x0
 ret
 8b0:	d65f03c0 	ret

00000000000008b4 <bind>:
.global bind
bind:
 mov x7, #SYS_bind
 8b4:	d28008e7 	mov	x7, #0x47                  	// #71
 svc #0
 8b8:	d4000001 	svc	#0x0
 ret
 8bc:	d65f03c0 	ret

00000000000008c0 <listen>:
.global listen
listen:
 mov x7, #SYS_listen
 8c0:	d2800907 	mov	x7, #0x48                  	// #72
 svc #0
 8c4:	d4000001 	svc	#0x0
 ret
 8c8:	d65f03c0 	ret

00000000000008cc <lseek>:
.global lseek
lseek:
 mov x7, #SYS_lseek
 8cc:	d2800927 	mov	x7, #0x49                  	// #73
 svc #0
 8d0:	d4000001 	svc	#0x0
 ret
 8d4:	d65f03c0 	ret

00000000000008d8 <putc>:

static char digits[] = "0123456789ABCDEF";

static int
putc(int fd, char c)
{
 8d8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return write(fd, &c, 1) == 1 ? 1 : 0;
 8dc:	52800022 	mov	w2, #0x1                   	// #1
{
 8e0:	910003fd 	mov	x29, sp
 8e4:	39007fe1 	strb	w1, [sp, #31]
  return write(fd, &c, 1) == 1 ? 1 : 0;
 8e8:	91007fe1 	add	x1, sp, #0x1f
 8ec:	97ffff2f 	bl	5a8 <write>
 8f0:	7100041f 	cmp	w0, #0x1
}
 8f4:	1a9f17e0 	cset	w0, eq	// eq = none
 8f8:	a8c27bfd 	ldp	x29, x30, [sp], #32
 8fc:	d65f03c0 	ret

0000000000000900 <printint>:

static int
printint(int fd, int xx, int base, int sgn)
{
 900:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 904:	910003fd 	mov	x29, sp
 908:	a90153f3 	stp	x19, x20, [sp, #16]
 90c:	a9025bf5 	stp	x21, x22, [sp, #32]
 910:	2a0003f6 	mov	w22, w0
  char buf[16];
  int i, neg, written = 0;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 914:	6a417c7f 	tst	w3, w1, lsr #31
 918:	54000300 	b.eq	978 <printint+0x78>  // b.none
    neg = 1;
    x = -xx;
 91c:	4b0103e1 	neg	w1, w1
    neg = 1;
 920:	52800025 	mov	w5, #0x1                   	// #1
    x = xx;
  }

  i = 0;
  do{
    buf[i++] = digits[x % base];
 924:	90000003 	adrp	x3, 0 <main>
 928:	91375863 	add	x3, x3, #0xdd6
 92c:	9100c3f5 	add	x21, sp, #0x30
 930:	d2800000 	mov	x0, #0x0                   	// #0
 934:	1ac20824 	udiv	w4, w1, w2
  }while((x /= base) != 0);
 938:	6b01005f 	cmp	w2, w1
    buf[i++] = digits[x % base];
 93c:	1b028486 	msub	w6, w4, w2, w1
  }while((x /= base) != 0);
 940:	2a0403e1 	mov	w1, w4
 944:	aa0003e4 	mov	x4, x0
    buf[i++] = digits[x % base];
 948:	38666866 	ldrb	w6, [x3, x6]
 94c:	38356806 	strb	w6, [x0, x21]
  }while((x /= base) != 0);
 950:	91000400 	add	x0, x0, #0x1
 954:	54ffff09 	b.ls	934 <printint+0x34>  // b.plast
    buf[i++] = digits[x % base];
 958:	11000493 	add	w19, w4, #0x1
  if(neg)
 95c:	34000085 	cbz	w5, 96c <printint+0x6c>
    buf[i++] = '-';
 960:	528005a0 	mov	w0, #0x2d                  	// #45
 964:	38334aa0 	strb	w0, [x21, w19, uxtw]
 968:	11000893 	add	w19, w4, #0x2
 96c:	51000673 	sub	w19, w19, #0x1
 970:	52800014 	mov	w20, #0x0                   	// #0
 974:	14000008 	b	994 <printint+0x94>
  neg = 0;
 978:	52800005 	mov	w5, #0x0                   	// #0
 97c:	17ffffea 	b	924 <printint+0x24>

  while(--i >= 0)
    written += putc(fd, buf[i]);
 980:	38736aa1 	ldrb	w1, [x21, x19]
 984:	2a1603e0 	mov	w0, w22
 988:	d1000673 	sub	x19, x19, #0x1
 98c:	97ffffd3 	bl	8d8 <putc>
 990:	0b000294 	add	w20, w20, w0
  while(--i >= 0)
 994:	3100067f 	cmn	w19, #0x1
 998:	54ffff41 	b.ne	980 <printint+0x80>  // b.any
  return written;
}
 99c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 9a0:	2a1403e0 	mov	w0, w20
 9a4:	a94153f3 	ldp	x19, x20, [sp, #16]
 9a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
 9ac:	d65f03c0 	ret

00000000000009b0 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
static int
vprintf(int fd, const char *fmt, va_list ap)
{
 9b0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 9b4:	910003fd 	mov	x29, sp
 9b8:	a90153f3 	stp	x19, x20, [sp, #16]
 9bc:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *s;
  int c, i, state, written = 0;
 9c0:	52800015 	mov	w21, #0x0                   	// #0
{
 9c4:	a90363f7 	stp	x23, x24, [sp, #48]
 9c8:	2a0003f7 	mov	w23, w0
 9cc:	a9046bf9 	stp	x25, x26, [sp, #64]
 9d0:	aa0103f9 	mov	x25, x1

  state = 0;
 9d4:	52800001 	mov	w1, #0x0                   	// #0
{
 9d8:	a90573fb 	stp	x27, x28, [sp, #80]
 9dc:	a9406053 	ldp	x19, x24, [x2]
 9e0:	b9401854 	ldr	w20, [x2, #24]
  for(i = 0; fmt[i]; i++){
 9e4:	39400320 	ldrb	w0, [x25]
 9e8:	35000120 	cbnz	w0, a0c <vprintf+0x5c>
      }
      state = 0;
    }
  }
  return written;
}
 9ec:	2a1503e0 	mov	w0, w21
 9f0:	a94153f3 	ldp	x19, x20, [sp, #16]
 9f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
 9f8:	a94363f7 	ldp	x23, x24, [sp, #48]
 9fc:	a9446bf9 	ldp	x25, x26, [sp, #64]
 a00:	a94573fb 	ldp	x27, x28, [sp, #80]
 a04:	a8c67bfd 	ldp	x29, x30, [sp], #96
 a08:	d65f03c0 	ret
    c = fmt[i] & 0xff;
 a0c:	2a0003f6 	mov	w22, w0
    if(state == 0){
 a10:	35000101 	cbnz	w1, a30 <vprintf+0x80>
      if(c == '%'){
 a14:	7100941f 	cmp	w0, #0x25
 a18:	54000ba0 	b.eq	b8c <vprintf+0x1dc>  // b.none
        written += putc(fd, c);
 a1c:	2a1603e1 	mov	w1, w22
 a20:	2a1703e0 	mov	w0, w23
 a24:	97ffffad 	bl	8d8 <putc>
 a28:	0b0002b5 	add	w21, w21, w0
 a2c:	14000057 	b	b88 <vprintf+0x1d8>
      if(c == 'd'){
 a30:	7101901f 	cmp	w0, #0x64
 a34:	540002a1 	b.ne	a88 <vprintf+0xd8>  // b.any
        written += printint(fd, va_arg(ap, int), 10, 1);
 a38:	37f80174 	tbnz	w20, #31, a64 <vprintf+0xb4>
 a3c:	91002e76 	add	x22, x19, #0xb
 a40:	2a1403fa 	mov	w26, w20
 a44:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a48:	52800023 	mov	w3, #0x1                   	// #1
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 a4c:	52800142 	mov	w2, #0xa                   	// #10
        written += printint(fd, va_arg(ap, int), 16, 0);
 a50:	b9400261 	ldr	w1, [x19]
 a54:	2a1703e0 	mov	w0, w23
 a58:	97ffffaa 	bl	900 <printint>
        written += putc(fd, va_arg(ap, uint));
 a5c:	0b0002b5 	add	w21, w21, w0
 a60:	14000048 	b	b80 <vprintf+0x1d0>
        written += printint(fd, va_arg(ap, int), 10, 1);
 a64:	1100229a 	add	w26, w20, #0x8
 a68:	7100035f 	cmp	w26, #0x0
 a6c:	5400008d 	b.le	a7c <vprintf+0xcc>
 a70:	91002e76 	add	x22, x19, #0xb
 a74:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 a78:	17fffff4 	b	a48 <vprintf+0x98>
 a7c:	aa1303f6 	mov	x22, x19
 a80:	8b34c313 	add	x19, x24, w20, sxtw
 a84:	17fffff1 	b	a48 <vprintf+0x98>
      } else if(c == 'l') {
 a88:	7101b01f 	cmp	w0, #0x6c
 a8c:	54000201 	b.ne	acc <vprintf+0x11c>  // b.any
        written += printint(fd, va_arg(ap, uint64), 10, 0);
 a90:	37f800d4 	tbnz	w20, #31, aa8 <vprintf+0xf8>
 a94:	91003e76 	add	x22, x19, #0xf
 a98:	2a1403fa 	mov	w26, w20
 a9c:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 aa0:	52800003 	mov	w3, #0x0                   	// #0
 aa4:	17ffffea 	b	a4c <vprintf+0x9c>
 aa8:	1100229a 	add	w26, w20, #0x8
 aac:	7100035f 	cmp	w26, #0x0
 ab0:	5400008d 	b.le	ac0 <vprintf+0x110>
 ab4:	91003e76 	add	x22, x19, #0xf
 ab8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 abc:	17fffff9 	b	aa0 <vprintf+0xf0>
 ac0:	aa1303f6 	mov	x22, x19
 ac4:	8b34c313 	add	x19, x24, w20, sxtw
 ac8:	17fffff6 	b	aa0 <vprintf+0xf0>
      } else if(c == 'x') {
 acc:	7101e01f 	cmp	w0, #0x78
 ad0:	54000221 	b.ne	b14 <vprintf+0x164>  // b.any
        written += printint(fd, va_arg(ap, int), 16, 0);
 ad4:	37f800f4 	tbnz	w20, #31, af0 <vprintf+0x140>
 ad8:	91002e76 	add	x22, x19, #0xb
 adc:	2a1403fa 	mov	w26, w20
 ae0:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 ae4:	52800003 	mov	w3, #0x0                   	// #0
 ae8:	52800202 	mov	w2, #0x10                  	// #16
 aec:	17ffffd9 	b	a50 <vprintf+0xa0>
 af0:	1100229a 	add	w26, w20, #0x8
 af4:	7100035f 	cmp	w26, #0x0
 af8:	5400008d 	b.le	b08 <vprintf+0x158>
 afc:	91002e76 	add	x22, x19, #0xb
 b00:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b04:	17fffff8 	b	ae4 <vprintf+0x134>
 b08:	aa1303f6 	mov	x22, x19
 b0c:	8b34c313 	add	x19, x24, w20, sxtw
 b10:	17fffff5 	b	ae4 <vprintf+0x134>
      } else if(c == 'p') {
 b14:	7101c01f 	cmp	w0, #0x70
 b18:	54000521 	b.ne	bbc <vprintf+0x20c>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 b1c:	37f803f4 	tbnz	w20, #31, b98 <vprintf+0x1e8>
 b20:	91003e76 	add	x22, x19, #0xf
 b24:	2a1403fa 	mov	w26, w20
 b28:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 b2c:	f940027b 	ldr	x27, [x19]
  written += putc(fd, '0');
 b30:	52800601 	mov	w1, #0x30                  	// #48
 b34:	2a1703e0 	mov	w0, w23
 b38:	97ffff68 	bl	8d8 <putc>
 b3c:	2a0003f3 	mov	w19, w0
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b40:	9000001c 	adrp	x28, 0 <main>
 b44:	91375b9c 	add	x28, x28, #0xdd6
  written += putc(fd, 'x');
 b48:	2a1703e0 	mov	w0, w23
 b4c:	52800f01 	mov	w1, #0x78                  	// #120
 b50:	97ffff62 	bl	8d8 <putc>
 b54:	0b000273 	add	w19, w19, w0
 b58:	52800214 	mov	w20, #0x10                  	// #16
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b5c:	d37cff60 	lsr	x0, x27, #60
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 b60:	d37cef7b 	lsl	x27, x27, #4
    written += putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b64:	38606b81 	ldrb	w1, [x28, x0]
 b68:	2a1703e0 	mov	w0, w23
 b6c:	97ffff5b 	bl	8d8 <putc>
 b70:	0b000273 	add	w19, w19, w0
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 b74:	71000694 	subs	w20, w20, #0x1
 b78:	54ffff21 	b.ne	b5c <vprintf+0x1ac>  // b.any
        written += printptr(fd, va_arg(ap, uint64));
 b7c:	0b1302b5 	add	w21, w21, w19
 b80:	2a1a03f4 	mov	w20, w26
 b84:	aa1603f3 	mov	x19, x22
      state = 0;
 b88:	52800016 	mov	w22, #0x0                   	// #0
  for(i = 0; fmt[i]; i++){
 b8c:	91000739 	add	x25, x25, #0x1
  state = 0;
 b90:	2a1603e1 	mov	w1, w22
 b94:	17ffff94 	b	9e4 <vprintf+0x34>
        written += printptr(fd, va_arg(ap, uint64));
 b98:	1100229a 	add	w26, w20, #0x8
 b9c:	7100035f 	cmp	w26, #0x0
 ba0:	5400008d 	b.le	bb0 <vprintf+0x200>
 ba4:	91003e76 	add	x22, x19, #0xf
 ba8:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 bac:	17ffffe0 	b	b2c <vprintf+0x17c>
 bb0:	aa1303f6 	mov	x22, x19
 bb4:	8b34c313 	add	x19, x24, w20, sxtw
 bb8:	17ffffdd 	b	b2c <vprintf+0x17c>
      } else if(c == 's'){
 bbc:	7101cc1f 	cmp	w0, #0x73
 bc0:	54000381 	b.ne	c30 <vprintf+0x280>  // b.any
        s = va_arg(ap, char*);
 bc4:	37f80214 	tbnz	w20, #31, c04 <vprintf+0x254>
 bc8:	91003e61 	add	x1, x19, #0xf
 bcc:	aa1303e0 	mov	x0, x19
 bd0:	927df033 	and	x19, x1, #0xfffffffffffffff8
 bd4:	f9400016 	ldr	x22, [x0]
          s = "(null)";
 bd8:	90000000 	adrp	x0, 0 <main>
 bdc:	91373c00 	add	x0, x0, #0xdcf
 be0:	f10002df 	cmp	x22, #0x0
 be4:	9a960016 	csel	x22, x0, x22, eq	// eq = none
        while(*s != 0){
 be8:	394002c1 	ldrb	w1, [x22]
 bec:	34fffce1 	cbz	w1, b88 <vprintf+0x1d8>
          written += putc(fd, *s);
 bf0:	2a1703e0 	mov	w0, w23
          s++;
 bf4:	910006d6 	add	x22, x22, #0x1
          written += putc(fd, *s);
 bf8:	97ffff38 	bl	8d8 <putc>
 bfc:	0b0002b5 	add	w21, w21, w0
          s++;
 c00:	17fffffa 	b	be8 <vprintf+0x238>
        s = va_arg(ap, char*);
 c04:	11002281 	add	w1, w20, #0x8
 c08:	7100003f 	cmp	w1, #0x0
 c0c:	540000cd 	b.le	c24 <vprintf+0x274>
 c10:	91003e62 	add	x2, x19, #0xf
 c14:	aa1303e0 	mov	x0, x19
 c18:	2a0103f4 	mov	w20, w1
 c1c:	927df053 	and	x19, x2, #0xfffffffffffffff8
 c20:	17ffffed 	b	bd4 <vprintf+0x224>
 c24:	8b34c300 	add	x0, x24, w20, sxtw
 c28:	2a0103f4 	mov	w20, w1
 c2c:	17ffffea 	b	bd4 <vprintf+0x224>
      } else if(c == 'c'){
 c30:	71018c1f 	cmp	w0, #0x63
 c34:	54000241 	b.ne	c7c <vprintf+0x2cc>  // b.any
        written += putc(fd, va_arg(ap, uint));
 c38:	37f80114 	tbnz	w20, #31, c58 <vprintf+0x2a8>
 c3c:	91002e76 	add	x22, x19, #0xb
 c40:	2a1403fa 	mov	w26, w20
 c44:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c48:	39400261 	ldrb	w1, [x19]
 c4c:	2a1703e0 	mov	w0, w23
 c50:	97ffff22 	bl	8d8 <putc>
 c54:	17ffff82 	b	a5c <vprintf+0xac>
 c58:	1100229a 	add	w26, w20, #0x8
 c5c:	7100035f 	cmp	w26, #0x0
 c60:	5400008d 	b.le	c70 <vprintf+0x2c0>
 c64:	91002e76 	add	x22, x19, #0xb
 c68:	927df2d6 	and	x22, x22, #0xfffffffffffffff8
 c6c:	17fffff7 	b	c48 <vprintf+0x298>
 c70:	aa1303f6 	mov	x22, x19
 c74:	8b34c313 	add	x19, x24, w20, sxtw
 c78:	17fffff4 	b	c48 <vprintf+0x298>
      } else if(c == '%'){
 c7c:	7100941f 	cmp	w0, #0x25
 c80:	54ffece0 	b.eq	a1c <vprintf+0x6c>  // b.none
        written += putc(fd, '%');
 c84:	2a1703e0 	mov	w0, w23
 c88:	528004a1 	mov	w1, #0x25                  	// #37
 c8c:	97ffff13 	bl	8d8 <putc>
 c90:	0b0002b5 	add	w21, w21, w0
 c94:	17ffff62 	b	a1c <vprintf+0x6c>

0000000000000c98 <fprintf>:

int
fprintf(int fd, const char *fmt, ...)
{
 c98:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
 c9c:	910003fd 	mov	x29, sp
 ca0:	a9050fe2 	stp	x2, x3, [sp, #80]
  va_list ap;
  int result;

  va_start(ap, fmt);
 ca4:	910203e2 	add	x2, sp, #0x80
 ca8:	a9030be2 	stp	x2, x2, [sp, #48]
 cac:	910143e2 	add	x2, sp, #0x50
 cb0:	f90023e2 	str	x2, [sp, #64]
 cb4:	128005e2 	mov	w2, #0xffffffd0            	// #-48
 cb8:	b9004be2 	str	w2, [sp, #72]
 cbc:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(fd, fmt, ap);
 cc0:	a9430fe2 	ldp	x2, x3, [sp, #48]
 cc4:	a9010fe2 	stp	x2, x3, [sp, #16]
 cc8:	a9440fe2 	ldp	x2, x3, [sp, #64]
 ccc:	a9020fe2 	stp	x2, x3, [sp, #32]
 cd0:	910043e2 	add	x2, sp, #0x10
{
 cd4:	a90617e4 	stp	x4, x5, [sp, #96]
 cd8:	a9071fe6 	stp	x6, x7, [sp, #112]
  result = vprintf(fd, fmt, ap);
 cdc:	97ffff35 	bl	9b0 <vprintf>
  va_end(ap);
  return result;
}
 ce0:	a8c87bfd 	ldp	x29, x30, [sp], #128
 ce4:	d65f03c0 	ret

0000000000000ce8 <printf>:

int
printf(const char *fmt, ...)
{
 ce8:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
 cec:	910003fd 	mov	x29, sp
 cf0:	a9058be1 	stp	x1, x2, [sp, #88]
  va_list ap;
  int result;

  va_start(ap, fmt);
 cf4:	910243e1 	add	x1, sp, #0x90
 cf8:	a90307e1 	stp	x1, x1, [sp, #48]
 cfc:	910143e1 	add	x1, sp, #0x50
 d00:	f90023e1 	str	x1, [sp, #64]
 d04:	128006e1 	mov	w1, #0xffffffc8            	// #-56
 d08:	b9004be1 	str	w1, [sp, #72]
  result = vprintf(1, fmt, ap);
 d0c:	aa0003e1 	mov	x1, x0
  va_start(ap, fmt);
 d10:	b9004fff 	str	wzr, [sp, #76]
  result = vprintf(1, fmt, ap);
 d14:	52800020 	mov	w0, #0x1                   	// #1
{
 d18:	a90693e3 	stp	x3, x4, [sp, #104]
  result = vprintf(1, fmt, ap);
 d1c:	a9430fe2 	ldp	x2, x3, [sp, #48]
 d20:	a9010fe2 	stp	x2, x3, [sp, #16]
 d24:	a9440fe2 	ldp	x2, x3, [sp, #64]
 d28:	a9020fe2 	stp	x2, x3, [sp, #32]
 d2c:	910043e2 	add	x2, sp, #0x10
{
 d30:	a9079be5 	stp	x5, x6, [sp, #120]
 d34:	f90047e7 	str	x7, [sp, #136]
  result = vprintf(1, fmt, ap);
 d38:	97ffff1e 	bl	9b0 <vprintf>
  va_end(ap);
  return result;
}
 d3c:	a8c97bfd 	ldp	x29, x30, [sp], #144
 d40:	d65f03c0 	ret
