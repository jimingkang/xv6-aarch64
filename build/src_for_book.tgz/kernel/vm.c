#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "elf.h"
#include "aarch64.h"
#include "defs.h"
#include "fs.h"
#include "spinlock.h"
#include "proc.h"

/*
 * the kernel's page table.
 */
pagetable_t kernel_pagetable;

extern char etext[];  // kernel.ld sets this to end of kernel code.

// Make a direct-map page table for the kernel.
pagetable_t
kvmmake(void)
{
  pagetable_t kpgtbl;

  kpgtbl = (pagetable_t) kalloc();
  memset(kpgtbl, 0, PGSIZE);

  // BCM2837 peripheral and ARM-local MMIO windows.
  kvmmap(kpgtbl, PERIPHERAL_BASE, PERIPHERAL_BASE_PA,
         0x01000000, PTE_DEVICE | PTE_XN);
  kvmmap(kpgtbl, LOCAL_BASE, LOCAL_BASE_PA, PGSIZE,
         PTE_DEVICE | PTE_XN);

  // QEMU loads fs.img here; it is outside the allocator's RAM range.
  kvmmap(kpgtbl, RAMDISK, RAMDISK_PA, RAMDISK_SIZE,
         PTE_NORMAL | PTE_XN);

  // Camera DMA buffer: non-cacheable normal memory (see memlayout.h).
  kvmmap(kpgtbl, CAMDMA, CAMDMA_PA, CAMDMA_SIZE, PTE_NORMAL_NC | PTE_XN);

  // Raspberry Pi AArch64 secondary-core spin-table slots live at physical
  // 0xe0..0xf0.  Keep only page zero in the high direct map so CPU0 can
  // publish _entry after switching away from the bootstrap page table.
  kvmmap(kpgtbl, KERNBASE, 0, PGSIZE, PTE_NORMAL | PTE_XN);

  // map kernel text executable and read-only.
  kvmmap(kpgtbl, KERNLINK, V2P(KERNLINK), (uint64)etext-KERNLINK, PTE_NORMAL | PTE_RO);

  // map kernel data and the physical RAM we'll make use of.
  kvmmap(kpgtbl, (uint64)etext, V2P(etext), (uint64)P2V(PHYSTOP)-(uint64)etext, PTE_NORMAL | PTE_XN);

  return kpgtbl;
}

// Initialize the one kernel_pagetable
void
kvminit(void)
{
  kernel_pagetable = kvmmake();
}

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
  w_ttbr1_el1(V2P(kernel_pagetable));
  w_ttbr0_el1(0);
  flush_tlb();
}

// Print the final kernel page table before the scheduler starts.  With a
// 39-bit VA, translation starts at architectural level 1 (there is no level
// 0 table).  The final table maps 4KB level-3 pages, so summarize those leaves
// by the 2MB virtual-address window represented by each level-2 entry.
void
kvmdump(void)
{
  printf("\n=== kernel page table ===\n");
  printf("L0: omitted (T1SZ=25 gives a 39-bit VA; walk starts at L1)\n");
  printf("TTBR1_EL1 -> L1 root: kva=%p pa=%p\n",
         (uint64)kernel_pagetable, V2P(kernel_pagetable));

  for(int i = 0; i < 512; i++){
    pte_t l1e = kernel_pagetable[i];
    if((l1e & PTE_VALID) == 0)
      continue;

    uint64 l1va = KERNBASE + ((uint64)i << PXSHIFT(1));
    if((l1e & PTE_TABLE) == 0){
      printf(" L1[%d] va=%p: unexpected block pte=%p\n",
             i, l1va, l1e);
      continue;
    }

    pagetable_t l2 = (pagetable_t)P2V(PTE2PA(l1e));
    printf(" L1[%d] va=%p table-va=%p table-pa=%p\n",
           i, l1va, (uint64)l2, PTE2PA(l1e));

    for(int j = 0; j < 512; j++){
      pte_t l2e = l2[j];
      if((l2e & PTE_VALID) == 0)
        continue;

      uint64 va = l1va + ((uint64)j << PXSHIFT(2));
      uint64 vaend = va + (1UL << PXSHIFT(2)) - 1;

      if((l2e & PTE_TABLE) == 0){
        printf("  L2[%d] 2MB block va=%p..%p pa=%p flags=%p\n",
               j, va, vaend, PTE2PA(l2e), PTE_FLAGS(l2e));
        continue;
      }

      pagetable_t l3 = (pagetable_t)P2V(PTE2PA(l2e));
      int pages = 0;
      int linear = 1;
      int mixed = 0;
      uint64 firstpa = 0;
      uint64 lastpa = 0;
      uint64 flags = 0;

      for(int k = 0; k < 512; k++){
        pte_t l3e = l3[k];
        if((l3e & PTE_V) != PTE_V)
          continue;
        uint64 pa = PTE2PA(l3e);
        uint64 leaf_flags = PTE_FLAGS(l3e);
        if(pages == 0){
          firstpa = pa;
          flags = leaf_flags;
        } else {
          if(pa != lastpa + PGSIZE)
            linear = 0;
          if(leaf_flags != flags)
            mixed = 1;
        }
        lastpa = pa;
        pages++;
      }

      printf("  L2[%d] 2MB window va=%p..%p table-pa=%p",
             j, va, vaend, PTE2PA(l2e));
      if(pages == 0){
        printf(" no L3 leaves\n");
      } else {
        printf(" L3-pages=%d pa-first=%p pa-last=%p %s attrs=%s",
               pages, firstpa, lastpa,
               linear ? "linear" : "nonlinear",
               mixed ? "mixed" : "same");
        if(!mixed)
          printf(" flags=%p", flags);
        printf("\n");
      }
    }
  }
  printf("=== end kernel page table ===\n\n");
}

// Print a user page table when fork copies it or exec installs a new image.
// User address translation uses TTBR0 and the same 39-bit, three-level walk.
// User address spaces are small enough that every valid L3 leaf is useful.
void
uvmdump(pagetable_t root, int pid, char *name, char *event)
{
  (void)pid;
  (void)name;
  (void)event;
  printf("TTBR0_EL1[%p] (root-kva=%p)\n", V2P(root), (uint64)root);

  for(int i = 0; i < 512; i++){
    pte_t l1e = root[i];
    if((l1e & PTE_VALID) == 0)
      continue;
    uint64 l1va = (uint64)i << PXSHIFT(1);
    if((l1e & PTE_TABLE) == 0){
      printf("  -> L1[%d] BLOCK va=%p -> pa=%p flags=%p\n",
             i, l1va, PTE2PA(l1e), PTE_FLAGS(l1e));
      continue;
    }

    pagetable_t l2 = (pagetable_t)P2V(PTE2PA(l1e));
    for(int j = 0; j < 512; j++){
      pte_t l2e = l2[j];
      if((l2e & PTE_VALID) == 0)
        continue;
      uint64 l2va = l1va + ((uint64)j << PXSHIFT(2));
      if((l2e & PTE_TABLE) == 0){
        printf("  -> L1[%d] -> L2[%d] BLOCK va=%p -> pa=%p flags=%p\n",
               i, j, l2va, PTE2PA(l2e), PTE_FLAGS(l2e));
        continue;
      }

      pagetable_t l3 = (pagetable_t)P2V(PTE2PA(l2e));
      for(int k = 0; k < 512; k++){
        pte_t l3e = l3[k];
        if((l3e & PTE_V) != PTE_V)
          continue;
        uint64 va = l2va + ((uint64)k << PXSHIFT(3));
        printf("  -> L1[%d] -> L2[%d] -> L3[%d] VA=%p -> PA=%p"
               " flags=%p %s %s %s\n",
               i, j, k, va, PTE2PA(l3e), PTE_FLAGS(l3e),
               (l3e & PTE_U) ? "user" : "kernel",
               (l3e & PTE_RO) ? "RO" : "RW",
               (l3e & PTE_UXN) ? "XN" : "X");
      }
    }
  }
}

// Return the address of the PTE in page table pagetable
// that corresponds to virtual address va.  If alloc!=0,
// create any required page-table pages.
//
// This AArch64 configuration uses a 39-bit TTBR0 address space and three
// levels of 4KB page-table pages. Each table contains 512 64-bit descriptors.
// A user virtual address is split into four fields:
//   39..63 -- must be zero.
//   30..38 -- 9 bits of level-1 index.
//   21..29 -- 9 bits of level-2 index.
//   12..20 -- 9 bits of level-3 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
  if(va >= MAXVA)
    panic("walk");

  for(int level = 1; level < 3; level++) {
    pte_t *pte = &pagetable[PX(level, va)];
    if((*pte & PTE_VALID) && (*pte & PTE_TABLE)) {
      pagetable = (pagetable_t)P2V(PTE2PA(*pte));
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(V2P(pagetable)) | PTE_TABLE | PTE_VALID;
    }
  }
  return &pagetable[PX(3, va)];
}

// Look up a virtual address, return the physical address,
// or 0 if not mapped.
// Can only be used to look up user pages.
uint64
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    return 0;

  pte = walk(pagetable, va, 0);
  if(pte == 0)
    return 0;
  if((*pte & PTE_V) != PTE_V)
    return 0;
  if((*pte & PTE_AF) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}

// user virtual address to kernel virtual address
uint64
uva2ka(pagetable_t pagetable, uint64 va)
{
  uint64 pa = walkaddr(pagetable, va);
  if(pa == 0)
    return 0;

  return (uint64)P2V(pa);
}

// Make instructions written through the kernel's high direct mapping visible
// through the low EL0 mapping. AArch64 does not guarantee D/I coherence after
// loading executable bytes. Clean the data by its kernel VA, then invalidate
// the complete local I-cache: IC IVAU with the high kernel VA is insufficient
// for the low user-VA alias on implementations with a virtually indexed
// instruction cache.
void
uvmsync_icache(pagetable_t pagetable, uint64 sz)
{
  for(uint64 va = 0; va < PGROUNDUP(sz); va += PGSIZE){
    uint64 kva = uva2ka(pagetable, va);
    if(kva == 0)
      continue;
    for(uint64 p = kva; p < kva + PGSIZE; p += 64)
      asm volatile("dc cvau, %0" :: "r"(p) : "memory");
  }
  asm volatile("dsb ish" ::: "memory");
  asm volatile("ic iallu\n\tdsb ish\n\tisb" ::: "memory");
}

// add a mapping to the kernel page table.
// only used when booting.
// does not flush TLB or enable paging.
void
kvmmap(pagetable_t kpgtbl, uint64 va, uint64 pa, uint64 sz, uint64 perm)
{
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    panic("kvmmap");
}

// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa. va and size might not
// be page-aligned. Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, uint64 perm)
{
  uint64 a, last;
  pte_t *pte;

  if(size == 0)
    panic("mappages: size");
  a = PGROUNDDOWN(va);
  last = PGROUNDDOWN(va + size - 1);
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
      return -1;
    if(*pte & PTE_AF)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_AF | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) != PTE_V)
      panic("uvmunmap: not mapped");
    if((*pte & PTE_AF) == 0)
      panic("uvmunmap: not a leaf");
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)P2V(pa));
    }
    *pte = 0;
  }
}

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
  if(pagetable == 0)
    return 0;
  memset(pagetable, 0, PGSIZE);
  return pagetable;
}

// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvminit(pagetable_t pagetable, uchar *src, uint sz)
{
  char *mem;

  if(sz >= PGSIZE)
    panic("inituvm: more than a page");
  mem = kalloc();
  memset(mem, 0, PGSIZE);
  mappages(pagetable, 0, PGSIZE, V2P(mem), PTE_NORMAL|PTE_U);
  memmove(mem, src, sz);
  uvmsync_icache(pagetable, sz);
}

// Allocate PTEs and physical memory to grow process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.
uint64
uvmalloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  char *mem;
  uint64 a;

  if(newsz < oldsz)
    return oldsz;

  oldsz = PGROUNDUP(oldsz);
  for(a = oldsz; a < newsz; a += PGSIZE){
    mem = kalloc();
    if(mem == 0){
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
    memset(mem, 0, PGSIZE);
    if(mappages(pagetable, a, PGSIZE, V2P(mem), PTE_NORMAL|PTE_U) != 0){
      kfree(mem);
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
  }
  return newsz;
}

void
switchuvm(struct proc *p)
{
  if(p == 0)
    panic("switchuvm: no process");
  if(p->vm == 0 || p->vm->pagetable == 0)
    panic("switchuvm: no pagetable");

  w_ttbr0_el1(V2P(p->vm->pagetable));
  flush_tlb();
}

void
switchkvm(void)
{
  w_ttbr0_el1(0);
  flush_tlb();
}

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    return oldsz;

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
  // there are 2^9 = 512 PTEs in a page table.
  // printf("freeawlk %p\n", pagetable);
  for(int i = 0; i < 512; i++){
    pte_t pte = pagetable[i];
    // printf("pte%p %d\n", pte, i);
    if((pte & PTE_VALID) && (pte & PTE_TABLE) && !(pte & PTE_AF)){
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)P2V(child));
      pagetable[i] = 0;
    }
  }
  kfree((void*)pagetable);
}

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
  if(sz > 0)
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
}

// Given a parent process's page table, copy
// its memory into a child's page table.
// Copies both the page table and the
// physical memory.
// returns 0 on success, -1 on failure.
// frees any allocated pages on failure.
int
uvmcopy(pagetable_t old, pagetable_t new, uint64 sz)
{
  pte_t *pte;
  uint64 pa, i;
  uint64 flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    if((pte = walk(old, i, 0)) == 0)
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_AF) == 0)
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)P2V(pa), PGSIZE);
    if(mappages(new, i, PGSIZE, V2P(mem), flags) != 0){
      kfree(mem);
      goto err;
    }
  }
  uvmsync_icache(new, sz);
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
  return -1;
}

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
  if(pte == 0)
    panic("uvmclear");
  *pte &= ~PTE_U;
}

// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error.
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    va0 = PGROUNDDOWN(dstva);
    pa0 = uva2ka(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);

    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}

// Copy from user to kernel.
// Copy len bytes to dst from virtual address srcva in a given page table.
// Return 0 on success, -1 on error.
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = uva2ka(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);

    len -= n;
    dst += n;
    srcva = va0 + PGSIZE;
  }
  return 0;
}

// Copy a null-terminated string from user to kernel.
// Copy bytes to dst from virtual address srcva in a given page table,
// until a '\0', or max.
// Return 0 on success, -1 on error.
int
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = uva2ka(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    if(n > max)
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
        got_null = 1;
        break;
      } else {
        *dst = *p;
      }
      --n;
      --max;
      p++;
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    return 0;
  } else {
    return -1;
  }
}
