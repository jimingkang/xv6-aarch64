
user/_kill:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002b0 <.plt>:
 2b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2b4:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2b8:	f9425e11 	ldr	x17, [x16, #1208]
 2bc:	9112e210 	add	x16, x16, #0x4b8
 2c0:	d61f0220 	br	x17
 2c4:	d503201f 	nop
 2c8:	d503201f 	nop
 2cc:	d503201f 	nop

00000000000002d0 <fprintf@plt>:
 2d0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2d4:	f9426211 	ldr	x17, [x16, #1216]
 2d8:	91130210 	add	x16, x16, #0x4c0
 2dc:	d61f0220 	br	x17

00000000000002e0 <kill@plt>:
 2e0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2e4:	f9426611 	ldr	x17, [x16, #1224]
 2e8:	91132210 	add	x16, x16, #0x4c8
 2ec:	d61f0220 	br	x17

00000000000002f0 <exit@plt>:
 2f0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2f4:	f9426a11 	ldr	x17, [x16, #1232]
 2f8:	91134210 	add	x16, x16, #0x4d0
 2fc:	d61f0220 	br	x17

0000000000000300 <atoi@plt>:
 300:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 304:	f9426e11 	ldr	x17, [x16, #1240]
 308:	91136210 	add	x16, x16, #0x4d8
 30c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000310 <main>:
#include <uapi/stat.h>
#include "user/user.h"

int
main(int argc, char **argv)
{
 310:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 314:	910003fd 	mov	x29, sp
 318:	a90153f3 	stp	x19, x20, [sp, #16]
  int i;

  if(argc < 2){
 31c:	7100041f 	cmp	w0, #0x1
 320:	540000ec 	b.gt	33c <main+0x2c>
    fprintf(2, "usage: kill pid...\n");
 324:	90000001 	adrp	x1, 0 <.plt-0x2b0>
 328:	910db021 	add	x1, x1, #0x36c
 32c:	52800040 	mov	w0, #0x2                   	// #2
 330:	97ffffe8 	bl	2d0 <fprintf@plt>
    exit(1);
 334:	52800020 	mov	w0, #0x1                   	// #1
  }
  for(i=1; i<argc; i++)
    kill(atoi(argv[i]));
  exit(0);
 338:	97ffffee 	bl	2f0 <exit@plt>
 33c:	2a0003f4 	mov	w20, w0
  if(argc < 2){
 340:	d2800033 	mov	x19, #0x1                   	// #1
    kill(atoi(argv[i]));
 344:	f8737820 	ldr	x0, [x1, x19, lsl #3]
  for(i=1; i<argc; i++)
 348:	91000673 	add	x19, x19, #0x1
    kill(atoi(argv[i]));
 34c:	f90017e1 	str	x1, [sp, #40]
 350:	97ffffec 	bl	300 <atoi@plt>
 354:	97ffffe3 	bl	2e0 <kill@plt>
  for(i=1; i<argc; i++)
 358:	f94017e1 	ldr	x1, [sp, #40]
 35c:	6b13029f 	cmp	w20, w19
 360:	54ffff2c 	b.gt	344 <main+0x34>
  exit(0);
 364:	52800000 	mov	w0, #0x0                   	// #0
 368:	17fffff4 	b	338 <main+0x28>
