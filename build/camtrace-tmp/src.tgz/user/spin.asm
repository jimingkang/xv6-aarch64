
user/_spin:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000330 <.plt>:
 330:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 334:	b0000010 	adrp	x16, 1000 <main+0xc50>
 338:	f943a611 	ldr	x17, [x16, #1864]
 33c:	911d2210 	add	x16, x16, #0x748
 340:	d61f0220 	br	x17
 344:	d503201f 	nop
 348:	d503201f 	nop
 34c:	d503201f 	nop

0000000000000350 <printf@plt>:
 350:	b0000010 	adrp	x16, 1000 <main+0xc50>
 354:	f943aa11 	ldr	x17, [x16, #1872]
 358:	911d4210 	add	x16, x16, #0x750
 35c:	d61f0220 	br	x17

0000000000000360 <fprintf@plt>:
 360:	b0000010 	adrp	x16, 1000 <main+0xc50>
 364:	f943ae11 	ldr	x17, [x16, #1880]
 368:	911d6210 	add	x16, x16, #0x758
 36c:	d61f0220 	br	x17

0000000000000370 <sched_getinfo@plt>:
 370:	b0000010 	adrp	x16, 1000 <main+0xc50>
 374:	f943b211 	ldr	x17, [x16, #1888]
 378:	911d8210 	add	x16, x16, #0x760
 37c:	d61f0220 	br	x17

0000000000000380 <getcpu@plt>:
 380:	b0000010 	adrp	x16, 1000 <main+0xc50>
 384:	f943b611 	ldr	x17, [x16, #1896]
 388:	911da210 	add	x16, x16, #0x768
 38c:	d61f0220 	br	x17

0000000000000390 <clock_us@plt>:
 390:	b0000010 	adrp	x16, 1000 <main+0xc50>
 394:	f943ba11 	ldr	x17, [x16, #1904]
 398:	911dc210 	add	x16, x16, #0x770
 39c:	d61f0220 	br	x17

00000000000003a0 <exit@plt>:
 3a0:	b0000010 	adrp	x16, 1000 <main+0xc50>
 3a4:	f943be11 	ldr	x17, [x16, #1912]
 3a8:	911de210 	add	x16, x16, #0x778
 3ac:	d61f0220 	br	x17

Disassembly of section .text:

00000000000003b0 <main>:
#include "user/user.h"
#include "user/schedutil.h"

int
main(int argc, char *argv[])
{
 3b0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
 3b4:	910003fd 	mov	x29, sp
 3b8:	a90153f3 	stp	x19, x20, [sp, #16]
 3bc:	a9025bf5 	stp	x21, x22, [sp, #32]
  int secs = 5;
  struct sched_info si;

  if(argc > 2 || (argc == 2 && !parse_num(argv[1], &secs))){
 3c0:	7100081f 	cmp	w0, #0x2
 3c4:	54000d6c 	b.gt	570 <main+0x1c0>
 3c8:	54000e01 	b.ne	588 <main+0x1d8>  // b.any
 3cc:	f9400420 	ldr	x0, [x1, #8]
static __attribute__((unused)) int
parse_num(const char *s, int *out)
{
  int neg = 0, v = 0, any = 0;

  if(*s == '-'){
 3d0:	39400001 	ldrb	w1, [x0]
 3d4:	7100b43f 	cmp	w1, #0x2d
 3d8:	54000821 	b.ne	4dc <main+0x12c>  // b.any
    neg = 1;
    s++;
 3dc:	91000400 	add	x0, x0, #0x1
    neg = 1;
 3e0:	52800023 	mov	w3, #0x1                   	// #1
  }
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 3e4:	39400001 	ldrb	w1, [x0]
 3e8:	7100c03f 	cmp	w1, #0x30
 3ec:	54000ba1 	b.ne	560 <main+0x1b0>  // b.any
 3f0:	39400401 	ldrb	w1, [x0, #1]
 3f4:	121a7821 	and	w1, w1, #0xffffffdf
 3f8:	12001c21 	and	w1, w1, #0xff
 3fc:	7101603f 	cmp	w1, #0x58
 400:	54000b01 	b.ne	560 <main+0x1b0>  // b.any
    for(s += 2; *s; s++, any = 1){
 404:	91000800 	add	x0, x0, #0x2
  int neg = 0, v = 0, any = 0;
 408:	52800002 	mov	w2, #0x0                   	// #0
 40c:	52800013 	mov	w19, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 410:	39400001 	ldrb	w1, [x0]
 414:	35000681 	cbnz	w1, 4e4 <main+0x134>
      if(*s < '0' || *s > '9')
        return 0;
      v = v * 10 + (*s - '0');
    }
  }
  if(!any)
 418:	34000ac2 	cbz	w2, 570 <main+0x1c0>
    return 0;
  *out = neg ? -v : v;
 41c:	7100007f 	cmp	w3, #0x0
 420:	5a930673 	cneg	w19, w19, ne	// ne = any
    fprintf(2, "usage: spin [SECONDS]\n");
    exit(1);
  }
  uint64 start = clock_us(), end = start + (uint64)secs * 1000000;
 424:	97ffffdb 	bl	390 <clock_us@plt>
 428:	aa0003f4 	mov	x20, x0
 42c:	52884800 	mov	w0, #0x4240                	// #16960
 430:	72a001e0 	movk	w0, #0xf, lsl #16
 434:	9b205273 	smaddl	x19, w19, w0, x20
  while(clock_us() < end)
 438:	97ffffd6 	bl	390 <clock_us@plt>
 43c:	eb13001f 	cmp	x0, x19
 440:	54ffffc3 	b.cc	438 <main+0x88>  // b.lo, b.ul, b.last
    ;
  sched_getinfo(0, &si);
 444:	910123e1 	add	x1, sp, #0x48
 448:	52800000 	mov	w0, #0x0                   	// #0
 44c:	97ffffc9 	bl	370 <sched_getinfo@plt>
  uint64 done = clock_us();
 450:	97ffffd0 	bl	390 <clock_us@plt>
 454:	aa0003f5 	mov	x21, x0
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
 458:	294907f6 	ldp	w22, w1, [sp, #72]
}

static __attribute__((unused)) const char *
policy_name(int policy)
{
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 45c:	7100043f 	cmp	w1, #0x1
 460:	54000980 	b.eq	590 <main+0x1e0>  // b.none
  if(policy == SCHED_RR) return "SCHED_RR";
  return "SCHED_OTHER";
 464:	7100083f 	cmp	w1, #0x2
 468:	90000000 	adrp	x0, 0 <.plt-0x330>
 46c:	91169c00 	add	x0, x0, #0x5a7
 470:	90000013 	adrp	x19, 0 <.plt-0x330>
 474:	9116ce73 	add	x19, x19, #0x5b3
 478:	9a800273 	csel	x19, x19, x0, eq	// eq = none
 47c:	b94053e3 	ldr	w3, [sp, #80]
 480:	b9003fe3 	str	w3, [sp, #60]
 484:	97ffffbf 	bl	380 <getcpu@plt>
 488:	2a0003e4 	mov	w4, w0
         si.pid, policy_name(si.policy), si.priority, getcpu(),
         (int)(si.run_ticks * SCHED_TICK_MS), (int)(start / 1000 % 100000),
         (int)(done / 1000 % 100000));
 48c:	d2807d00 	mov	x0, #0x3e8                 	// #1000
 490:	d290d402 	mov	x2, #0x86a0                	// #34464
 494:	f2a00022 	movk	x2, #0x1, lsl #16
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
 498:	52800145 	mov	w5, #0xa                   	// #10
         (int)(done / 1000 % 100000));
 49c:	9ac00ab5 	udiv	x21, x21, x0
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
 4a0:	b9403fe3 	ldr	w3, [sp, #60]
 4a4:	f94037e1 	ldr	x1, [sp, #104]
         (int)(si.run_ticks * SCHED_TICK_MS), (int)(start / 1000 % 100000),
 4a8:	9ac00a94 	udiv	x20, x20, x0
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
 4ac:	90000000 	adrp	x0, 0 <.plt-0x330>
 4b0:	91174c00 	add	x0, x0, #0x5d3
         (int)(done / 1000 % 100000));
 4b4:	9ac20aa7 	udiv	x7, x21, x2
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
 4b8:	1b017ca5 	mul	w5, w5, w1
 4bc:	2a1603e1 	mov	w1, w22
         (int)(si.run_ticks * SCHED_TICK_MS), (int)(start / 1000 % 100000),
 4c0:	9ac20a86 	udiv	x6, x20, x2
  printf("spin pid %d: %s prio %d on CPU%d, ran %d ms, wall %d..%d ms\n",
 4c4:	1b02d4e7 	msub	w7, w7, w2, w21
 4c8:	1b02d0c6 	msub	w6, w6, w2, w20
 4cc:	aa1303e2 	mov	x2, x19
 4d0:	97ffffa0 	bl	350 <printf@plt>
  exit(0);
 4d4:	52800000 	mov	w0, #0x0                   	// #0
 4d8:	1400002b 	b	584 <main+0x1d4>
  int neg = 0, v = 0, any = 0;
 4dc:	52800003 	mov	w3, #0x0                   	// #0
 4e0:	17ffffc1 	b	3e4 <main+0x34>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 4e4:	5100c022 	sub	w2, w1, #0x30
 4e8:	12001c44 	and	w4, w2, #0xff
 4ec:	7100249f 	cmp	w4, #0x9
 4f0:	540000c8 	b.hi	508 <main+0x158>  // b.pmore
 4f4:	2a0203e1 	mov	w1, w2
      v = v * 16 + d;
 4f8:	0b131033 	add	w19, w1, w19, lsl #4
    for(s += 2; *s; s++, any = 1){
 4fc:	91000400 	add	x0, x0, #0x1
 500:	52800022 	mov	w2, #0x1                   	// #1
 504:	17ffffc3 	b	410 <main+0x60>
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 508:	51018422 	sub	w2, w1, #0x61
 50c:	12001c42 	and	w2, w2, #0xff
 510:	7100145f 	cmp	w2, #0x5
 514:	54000068 	b.hi	520 <main+0x170>  // b.pmore
 518:	51015c21 	sub	w1, w1, #0x57
 51c:	17fffff7 	b	4f8 <main+0x148>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 520:	51010422 	sub	w2, w1, #0x41
 524:	12001c42 	and	w2, w2, #0xff
 528:	7100145f 	cmp	w2, #0x5
 52c:	54000228 	b.hi	570 <main+0x1c0>  // b.pmore
 530:	5100dc21 	sub	w1, w1, #0x37
 534:	17fffff1 	b	4f8 <main+0x148>
      if(*s < '0' || *s > '9')
 538:	5100c021 	sub	w1, w1, #0x30
 53c:	12001c22 	and	w2, w1, #0xff
 540:	7100245f 	cmp	w2, #0x9
 544:	54000168 	b.hi	570 <main+0x1c0>  // b.pmore
      v = v * 10 + (*s - '0');
 548:	1b040673 	madd	w19, w19, w4, w1
    for(; *s; s++, any = 1){
 54c:	91000400 	add	x0, x0, #0x1
 550:	52800022 	mov	w2, #0x1                   	// #1
 554:	39400001 	ldrb	w1, [x0]
 558:	35ffff01 	cbnz	w1, 538 <main+0x188>
 55c:	17ffffaf 	b	418 <main+0x68>
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 560:	52800002 	mov	w2, #0x0                   	// #0
 564:	52800013 	mov	w19, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 568:	52800144 	mov	w4, #0xa                   	// #10
 56c:	17fffffa 	b	554 <main+0x1a4>
    fprintf(2, "usage: spin [SECONDS]\n");
 570:	90000001 	adrp	x1, 0 <.plt-0x330>
 574:	9116f021 	add	x1, x1, #0x5bc
 578:	52800040 	mov	w0, #0x2                   	// #2
 57c:	97ffff79 	bl	360 <fprintf@plt>
    exit(1);
 580:	52800020 	mov	w0, #0x1                   	// #1
  exit(0);
 584:	97ffff87 	bl	3a0 <exit@plt>
  int secs = 5;
 588:	528000b3 	mov	w19, #0x5                   	// #5
 58c:	17ffffa6 	b	424 <main+0x74>
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 590:	90000013 	adrp	x19, 0 <.plt-0x330>
 594:	91167273 	add	x19, x19, #0x59c
 598:	17ffffb9 	b	47c <main+0xcc>
