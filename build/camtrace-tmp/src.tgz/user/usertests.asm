
user/_usertests:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000001380 <.plt>:
    1380:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1384:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1388:	f940be11 	ldr	x17, [x16, #376]
    138c:	9105e210 	add	x16, x16, #0x178
    1390:	d61f0220 	br	x17
    1394:	d503201f 	nop
    1398:	d503201f 	nop
    139c:	d503201f 	nop

00000000000013a0 <printf@plt>:
    13a0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    13a4:	f940c211 	ldr	x17, [x16, #384]
    13a8:	91060210 	add	x16, x16, #0x180
    13ac:	d61f0220 	br	x17

00000000000013b0 <getpid@plt>:
    13b0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    13b4:	f940c611 	ldr	x17, [x16, #392]
    13b8:	91062210 	add	x16, x16, #0x188
    13bc:	d61f0220 	br	x17

00000000000013c0 <memcpy@plt>:
    13c0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    13c4:	f940ca11 	ldr	x17, [x16, #400]
    13c8:	91064210 	add	x16, x16, #0x190
    13cc:	d61f0220 	br	x17

00000000000013d0 <malloc@plt>:
    13d0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    13d4:	f940ce11 	ldr	x17, [x16, #408]
    13d8:	91066210 	add	x16, x16, #0x198
    13dc:	d61f0220 	br	x17

00000000000013e0 <pipe@plt>:
    13e0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    13e4:	f940d211 	ldr	x17, [x16, #416]
    13e8:	91068210 	add	x16, x16, #0x1a0
    13ec:	d61f0220 	br	x17

00000000000013f0 <write@plt>:
    13f0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    13f4:	f940d611 	ldr	x17, [x16, #424]
    13f8:	9106a210 	add	x16, x16, #0x1a8
    13fc:	d61f0220 	br	x17

0000000000001400 <kill@plt>:
    1400:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1404:	f940da11 	ldr	x17, [x16, #432]
    1408:	9106c210 	add	x16, x16, #0x1b0
    140c:	d61f0220 	br	x17

0000000000001410 <sleep_ticks@plt>:
    1410:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1414:	f940de11 	ldr	x17, [x16, #440]
    1418:	9106e210 	add	x16, x16, #0x1b8
    141c:	d61f0220 	br	x17

0000000000001420 <chdir@plt>:
    1420:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1424:	f940e211 	ldr	x17, [x16, #448]
    1428:	91070210 	add	x16, x16, #0x1c0
    142c:	d61f0220 	br	x17

0000000000001430 <exec@plt>:
    1430:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1434:	f940e611 	ldr	x17, [x16, #456]
    1438:	91072210 	add	x16, x16, #0x1c8
    143c:	d61f0220 	br	x17

0000000000001440 <wait@plt>:
    1440:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1444:	f940ea11 	ldr	x17, [x16, #464]
    1448:	91074210 	add	x16, x16, #0x1d0
    144c:	d61f0220 	br	x17

0000000000001450 <read@plt>:
    1450:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1454:	f940ee11 	ldr	x17, [x16, #472]
    1458:	91076210 	add	x16, x16, #0x1d8
    145c:	d61f0220 	br	x17

0000000000001460 <unlink@plt>:
    1460:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1464:	f940f211 	ldr	x17, [x16, #480]
    1468:	91078210 	add	x16, x16, #0x1e0
    146c:	d61f0220 	br	x17

0000000000001470 <fork@plt>:
    1470:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1474:	f940f611 	ldr	x17, [x16, #488]
    1478:	9107a210 	add	x16, x16, #0x1e8
    147c:	d61f0220 	br	x17

0000000000001480 <sbrk@plt>:
    1480:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1484:	f940fa11 	ldr	x17, [x16, #496]
    1488:	9107c210 	add	x16, x16, #0x1f0
    148c:	d61f0220 	br	x17

0000000000001490 <memset@plt>:
    1490:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1494:	f940fe11 	ldr	x17, [x16, #504]
    1498:	9107e210 	add	x16, x16, #0x1f8
    149c:	d61f0220 	br	x17

00000000000014a0 <strcmp@plt>:
    14a0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    14a4:	f9410211 	ldr	x17, [x16, #512]
    14a8:	91080210 	add	x16, x16, #0x200
    14ac:	d61f0220 	br	x17

00000000000014b0 <link@plt>:
    14b0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    14b4:	f9410611 	ldr	x17, [x16, #520]
    14b8:	91082210 	add	x16, x16, #0x208
    14bc:	d61f0220 	br	x17

00000000000014c0 <exit@plt>:
    14c0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    14c4:	f9410a11 	ldr	x17, [x16, #528]
    14c8:	91084210 	add	x16, x16, #0x210
    14cc:	d61f0220 	br	x17

00000000000014d0 <open@plt>:
    14d0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    14d4:	f9410e11 	ldr	x17, [x16, #536]
    14d8:	91086210 	add	x16, x16, #0x218
    14dc:	d61f0220 	br	x17

00000000000014e0 <mkdir@plt>:
    14e0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    14e4:	f9411211 	ldr	x17, [x16, #544]
    14e8:	91088210 	add	x16, x16, #0x220
    14ec:	d61f0220 	br	x17

00000000000014f0 <close@plt>:
    14f0:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    14f4:	f9411611 	ldr	x17, [x16, #552]
    14f8:	9108a210 	add	x16, x16, #0x228
    14fc:	d61f0220 	br	x17

0000000000001500 <free@plt>:
    1500:	f0000030 	adrp	x16, 8000 <_DYNAMIC>
    1504:	f9411a11 	ldr	x17, [x16, #560]
    1508:	9108c210 	add	x16, x16, #0x230
    150c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001510 <main>:
  }
}

int
main(int argc, char *argv[])
{
    1510:	d11083ff 	sub	sp, sp, #0x420
    1514:	a9007bfd 	stp	x29, x30, [sp]
    1518:	910003fd 	mov	x29, sp
    151c:	a90153f3 	stp	x19, x20, [sp, #16]
    1520:	2a0003f3 	mov	w19, w0
    1524:	a9025bf5 	stp	x21, x22, [sp, #32]
    1528:	f9001bf7 	str	x23, [sp, #48]
  int continuous = 0;
  char *justone = 0;

  if(argc == 2 && strcmp(argv[1], "-c") == 0){
    152c:	7100081f 	cmp	w0, #0x2
    1530:	540000e0 	b.eq	154c <main+0x3c>  // b.none
    continuous = 1;
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    continuous = 2;
  } else if(argc == 2 && argv[1][0] != '-'){
    justone = argv[1];
  } else if(argc > 1){
    1534:	7100041f 	cmp	w0, #0x1
    1538:	5400064d 	b.le	1600 <main+0xf0>
    printf("Usage: usertests [-c] [testname]\n");
    153c:	d0000020 	adrp	x0, 7000 <run+0x1858>
    1540:	910dc000 	add	x0, x0, #0x370
        fail = 1;
    }
  }

  if(fail){
    printf("SOME TESTS FAILED\n");
    1544:	97ffff97 	bl	13a0 <printf@plt>
    exit(1);
    1548:	1400002c 	b	15f8 <main+0xe8>
    154c:	aa0103f4 	mov	x20, x1
  if(argc == 2 && strcmp(argv[1], "-c") == 0){
    1550:	d0000021 	adrp	x1, 7000 <run+0x1858>
    1554:	910e4821 	add	x1, x1, #0x392
    1558:	f9400680 	ldr	x0, [x20, #8]
    155c:	97ffffd1 	bl	14a0 <strcmp@plt>
    1560:	34000540 	cbz	w0, 1608 <main+0xf8>
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    1564:	f9400680 	ldr	x0, [x20, #8]
    1568:	d0000021 	adrp	x1, 7000 <run+0x1858>
    156c:	910e5421 	add	x1, x1, #0x395
    1570:	97ffffcc 	bl	14a0 <strcmp@plt>
    1574:	34000500 	cbz	w0, 1614 <main+0x104>
  } else if(argc == 2 && argv[1][0] != '-'){
    1578:	f9400694 	ldr	x20, [x20, #8]
    157c:	39400280 	ldrb	w0, [x20]
    1580:	7100b41f 	cmp	w0, #0x2d
    1584:	54fffdc0 	b.eq	153c <main+0x2c>  // b.none
  int continuous = 0;
    1588:	52800013 	mov	w19, #0x0                   	// #0
  } tests[] = {
    158c:	d0000021 	adrp	x1, 7000 <run+0x1858>
    1590:	91184021 	add	x1, x1, #0x610
    1594:	91014021 	add	x1, x1, #0x50
    1598:	910103e0 	add	x0, sp, #0x40
    159c:	d2807c02 	mov	x2, #0x3e0                 	// #992
    15a0:	97ffff88 	bl	13c0 <memcpy@plt>
  if(continuous){
    15a4:	34000473 	cbz	w19, 1630 <main+0x120>
        printf("SOME TESTS FAILED\n");
    15a8:	d0000035 	adrp	x21, 7000 <run+0x1858>
    15ac:	910f56b5 	add	x21, x21, #0x3d5
        printf("FAILED -- lost %d free pages\n", free0 - free1);
    15b0:	d0000036 	adrp	x22, 7000 <run+0x1858>
    15b4:	910eded6 	add	x22, x22, #0x3b7
    printf("continuous usertests starting\n");
    15b8:	d0000020 	adrp	x0, 7000 <run+0x1858>
    15bc:	910e6000 	add	x0, x0, #0x398
    15c0:	97ffff78 	bl	13a0 <printf@plt>
      int free0 = countfree();
    15c4:	9400103d 	bl	56b8 <countfree>
      for (struct test *t = tests; t->s != 0; t++) {
    15c8:	910103f4 	add	x20, sp, #0x40
      int free0 = countfree();
    15cc:	2a0003f7 	mov	w23, w0
      for (struct test *t = tests; t->s != 0; t++) {
    15d0:	f9400681 	ldr	x1, [x20, #8]
    15d4:	b5000241 	cbnz	x1, 161c <main+0x10c>
      int free1 = countfree();
    15d8:	94001038 	bl	56b8 <countfree>
      if(free1 < free0){
    15dc:	6b0002ff 	cmp	w23, w0
    15e0:	54ffff2d 	b.le	15c4 <main+0xb4>
        printf("FAILED -- lost %d free pages\n", free0 - free1);
    15e4:	4b0002e1 	sub	w1, w23, w0
    15e8:	aa1603e0 	mov	x0, x22
    15ec:	97ffff6d 	bl	13a0 <printf@plt>
        if(continuous != 2)
    15f0:	71000a7f 	cmp	w19, #0x2
    15f4:	54fffe80 	b.eq	15c4 <main+0xb4>  // b.none
  } else if((free1 = countfree()) < free0){
    printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    exit(1);
    15f8:	52800020 	mov	w0, #0x1                   	// #1
  } else {
    printf("ALL TESTS PASSED\n");
    exit(0);
    15fc:	97ffffb1 	bl	14c0 <exit@plt>
  char *justone = 0;
    1600:	d2800014 	mov	x20, #0x0                   	// #0
    1604:	17ffffe1 	b	1588 <main+0x78>
    1608:	d2800014 	mov	x20, #0x0                   	// #0
    continuous = 1;
    160c:	52800033 	mov	w19, #0x1                   	// #1
    1610:	17ffffdf 	b	158c <main+0x7c>
  char *justone = 0;
    1614:	d2800014 	mov	x20, #0x0                   	// #0
    1618:	17ffffdd 	b	158c <main+0x7c>
        if(!run(t->f, t->s)){
    161c:	f9400280 	ldr	x0, [x20]
    1620:	94001062 	bl	57a8 <run>
    1624:	34000540 	cbz	w0, 16cc <main+0x1bc>
      for (struct test *t = tests; t->s != 0; t++) {
    1628:	91004294 	add	x20, x20, #0x10
    162c:	17ffffe9 	b	15d0 <main+0xc0>
  printf("usertests starting\n");
    1630:	d0000020 	adrp	x0, 7000 <run+0x1858>
    1634:	910e8c00 	add	x0, x0, #0x3a3
    1638:	97ffff5a 	bl	13a0 <printf@plt>
  for (struct test *t = tests; t->s != 0; t++) {
    163c:	910103f5 	add	x21, sp, #0x40
  int free0 = countfree();
    1640:	9400101e 	bl	56b8 <countfree>
    1644:	2a0003f7 	mov	w23, w0
  for (struct test *t = tests; t->s != 0; t++) {
    1648:	f94006b6 	ldr	x22, [x21, #8]
    164c:	b50000b6 	cbnz	x22, 1660 <main+0x150>
  if(fail){
    1650:	34000233 	cbz	w19, 1694 <main+0x184>
    printf("SOME TESTS FAILED\n");
    1654:	d0000020 	adrp	x0, 7000 <run+0x1858>
    1658:	910f5400 	add	x0, x0, #0x3d5
    165c:	17ffffba 	b	1544 <main+0x34>
    if((justone == 0) || strcmp(t->s, justone) == 0) {
    1660:	b5000114 	cbnz	x20, 1680 <main+0x170>
      if(!run(t->f, t->s))
    1664:	f94002a0 	ldr	x0, [x21]
    1668:	aa1603e1 	mov	x1, x22
    166c:	9400104f 	bl	57a8 <run>
    1670:	52000000 	eor	w0, w0, #0x1
    1674:	2a000273 	orr	w19, w19, w0
  for (struct test *t = tests; t->s != 0; t++) {
    1678:	910042b5 	add	x21, x21, #0x10
    167c:	17fffff3 	b	1648 <main+0x138>
    if((justone == 0) || strcmp(t->s, justone) == 0) {
    1680:	aa1403e1 	mov	x1, x20
    1684:	aa1603e0 	mov	x0, x22
    1688:	97ffff86 	bl	14a0 <strcmp@plt>
    168c:	34fffec0 	cbz	w0, 1664 <main+0x154>
    1690:	17fffffa 	b	1678 <main+0x168>
  } else if((free1 = countfree()) < free0){
    1694:	94001009 	bl	56b8 <countfree>
    1698:	2a0003e1 	mov	w1, w0
    169c:	6b0002ff 	cmp	w23, w0
    16a0:	540000cd 	b.le	16b8 <main+0x1a8>
    printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    16a4:	2a1703e2 	mov	w2, w23
    16a8:	d0000020 	adrp	x0, 7000 <run+0x1858>
    16ac:	910fa000 	add	x0, x0, #0x3e8
    16b0:	97ffff3c 	bl	13a0 <printf@plt>
    16b4:	17ffffd1 	b	15f8 <main+0xe8>
    printf("ALL TESTS PASSED\n");
    16b8:	d0000020 	adrp	x0, 7000 <run+0x1858>
    16bc:	91105c00 	add	x0, x0, #0x417
    16c0:	97ffff38 	bl	13a0 <printf@plt>
    exit(0);
    16c4:	52800000 	mov	w0, #0x0                   	// #0
    16c8:	17ffffcd 	b	15fc <main+0xec>
        printf("SOME TESTS FAILED\n");
    16cc:	aa1503e0 	mov	x0, x21
    16d0:	97ffff34 	bl	13a0 <printf@plt>
        if(continuous != 2)
    16d4:	71000a7f 	cmp	w19, #0x2
    16d8:	54fff800 	b.eq	15d8 <main+0xc8>  // b.none
    16dc:	17ffffc7 	b	15f8 <main+0xe8>

00000000000016e0 <copyinstr1>:
{
    16e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
    16e4:	d2b00000 	mov	x0, #0x80000000            	// #2147483648
{
    16e8:	910003fd 	mov	x29, sp
    16ec:	f90013f5 	str	x21, [sp, #32]
    uint64 addr = addrs[ai];
    16f0:	9100c3f5 	add	x21, sp, #0x30
{
    16f4:	a90153f3 	stp	x19, x20, [sp, #16]
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
    16f8:	d2800013 	mov	x19, #0x0                   	// #0
    16fc:	f9001be0 	str	x0, [sp, #48]
    1700:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    1704:	f9001fe0 	str	x0, [sp, #56]
    uint64 addr = addrs[ai];
    1708:	f8737ab4 	ldr	x20, [x21, x19, lsl #3]
    int fd = open((char *)addr, O_CREATE|O_WRONLY);
    170c:	52804021 	mov	w1, #0x201                 	// #513
    1710:	aa1403e0 	mov	x0, x20
    1714:	97ffff6f 	bl	14d0 <open@plt>
    1718:	2a0003e2 	mov	w2, w0
    if(fd >= 0){
    171c:	37f80120 	tbnz	w0, #31, 1740 <copyinstr1+0x60>
      printf("open(%p) returned %d, not -1\n", addr, fd);
    1720:	aa1403e1 	mov	x1, x20
    1724:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1728:	9120e000 	add	x0, x0, #0x838
    172c:	97ffff1d 	bl	13a0 <printf@plt>
      exit(1);
    1730:	52800020 	mov	w0, #0x1                   	// #1
    1734:	97ffff63 	bl	14c0 <exit@plt>
  for(int ai = 0; ai < 2; ai++){
    1738:	d2800033 	mov	x19, #0x1                   	// #1
    173c:	17fffff3 	b	1708 <copyinstr1+0x28>
    1740:	b4ffffd3 	cbz	x19, 1738 <copyinstr1+0x58>
}
    1744:	f94013f5 	ldr	x21, [sp, #32]
    1748:	a94153f3 	ldp	x19, x20, [sp, #16]
    174c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1750:	d65f03c0 	ret

0000000000001754 <truncate2>:
{
    1754:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1758:	910003fd 	mov	x29, sp
    175c:	a90153f3 	stp	x19, x20, [sp, #16]
    1760:	a9025bf5 	stp	x21, x22, [sp, #32]
    1764:	aa0003f5 	mov	x21, x0
  unlink("truncfile");
    1768:	90000033 	adrp	x19, 5000 <bigfile+0x108>
    176c:	91215a60 	add	x0, x19, #0x856
    1770:	97ffff3c 	bl	1460 <unlink@plt>
  int fd1 = open("truncfile", O_CREATE|O_TRUNC|O_WRONLY);
    1774:	5280c021 	mov	w1, #0x601                 	// #1537
    1778:	91215a60 	add	x0, x19, #0x856
    177c:	97ffff55 	bl	14d0 <open@plt>
    1780:	2a0003f4 	mov	w20, w0
  write(fd1, "abcd", 4);
    1784:	52800082 	mov	w2, #0x4                   	// #4
    1788:	90000021 	adrp	x1, 5000 <bigfile+0x108>
    178c:	91218021 	add	x1, x1, #0x860
    1790:	97ffff18 	bl	13f0 <write@plt>
  int fd2 = open("truncfile", O_TRUNC|O_WRONLY);
    1794:	52808021 	mov	w1, #0x401                 	// #1025
    1798:	91215a60 	add	x0, x19, #0x856
    179c:	97ffff4d 	bl	14d0 <open@plt>
    17a0:	2a0003f6 	mov	w22, w0
  int n = write(fd1, "x", 1);
    17a4:	b0000021 	adrp	x1, 6000 <run+0x858>
    17a8:	91275021 	add	x1, x1, #0x9d4
    17ac:	2a1403e0 	mov	w0, w20
    17b0:	52800022 	mov	w2, #0x1                   	// #1
    17b4:	97ffff0f 	bl	13f0 <write@plt>
  if(n != -1){
    17b8:	3100041f 	cmn	w0, #0x1
    17bc:	54000100 	b.eq	17dc <truncate2+0x88>  // b.none
    17c0:	2a0003e2 	mov	w2, w0
    printf("%s: write returned %d, expected -1\n", s, n);
    17c4:	aa1503e1 	mov	x1, x21
    17c8:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    17cc:	91219400 	add	x0, x0, #0x865
    17d0:	97fffef4 	bl	13a0 <printf@plt>
    exit(1);
    17d4:	52800020 	mov	w0, #0x1                   	// #1
    17d8:	97ffff3a 	bl	14c0 <exit@plt>
  unlink("truncfile");
    17dc:	91215a60 	add	x0, x19, #0x856
    17e0:	97ffff20 	bl	1460 <unlink@plt>
  close(fd1);
    17e4:	2a1403e0 	mov	w0, w20
    17e8:	97ffff42 	bl	14f0 <close@plt>
  close(fd2);
    17ec:	2a1603e0 	mov	w0, w22
}
    17f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    17f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    17f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
  close(fd2);
    17fc:	17ffff3d 	b	14f0 <close@plt>

0000000000001800 <createtest>:
{
    1800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  name[0] = 'a';
    1804:	52800c20 	mov	w0, #0x61                  	// #97
{
    1808:	910003fd 	mov	x29, sp
    180c:	f9000bf3 	str	x19, [sp, #16]
  name[2] = '\0';
    1810:	52800613 	mov	w19, #0x30                  	// #48
  name[0] = 'a';
    1814:	3900a3e0 	strb	w0, [sp, #40]
  name[2] = '\0';
    1818:	3900abff 	strb	wzr, [sp, #42]
    fd = open(name, O_CREATE|O_RDWR);
    181c:	52804041 	mov	w1, #0x202                 	// #514
    name[1] = '0' + i;
    1820:	3900a7f3 	strb	w19, [sp, #41]
  for(i = 0; i < N; i++){
    1824:	11000673 	add	w19, w19, #0x1
    fd = open(name, O_CREATE|O_RDWR);
    1828:	9100a3e0 	add	x0, sp, #0x28
  for(i = 0; i < N; i++){
    182c:	12001e73 	and	w19, w19, #0xff
    fd = open(name, O_CREATE|O_RDWR);
    1830:	97ffff28 	bl	14d0 <open@plt>
    close(fd);
    1834:	97ffff2f 	bl	14f0 <close@plt>
  for(i = 0; i < N; i++){
    1838:	7101927f 	cmp	w19, #0x64
    183c:	54ffff01 	b.ne	181c <createtest+0x1c>  // b.any
  name[0] = 'a';
    1840:	52800c20 	mov	w0, #0x61                  	// #97
  name[2] = '\0';
    1844:	52800613 	mov	w19, #0x30                  	// #48
  name[0] = 'a';
    1848:	3900a3e0 	strb	w0, [sp, #40]
  name[2] = '\0';
    184c:	3900abff 	strb	wzr, [sp, #42]
    name[1] = '0' + i;
    1850:	3900a7f3 	strb	w19, [sp, #41]
  for(i = 0; i < N; i++){
    1854:	11000673 	add	w19, w19, #0x1
    unlink(name);
    1858:	9100a3e0 	add	x0, sp, #0x28
  for(i = 0; i < N; i++){
    185c:	12001e73 	and	w19, w19, #0xff
    unlink(name);
    1860:	97ffff00 	bl	1460 <unlink@plt>
  for(i = 0; i < N; i++){
    1864:	7101927f 	cmp	w19, #0x64
    1868:	54ffff41 	b.ne	1850 <createtest+0x50>  // b.any
}
    186c:	f9400bf3 	ldr	x19, [sp, #16]
    1870:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1874:	d65f03c0 	ret

0000000000001878 <bigwrite>:
{
    1878:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    187c:	910003fd 	mov	x29, sp
    1880:	a9025bf5 	stp	x21, x22, [sp, #32]
      int cc = write(fd, buf, sz);
    1884:	d0000056 	adrp	x22, b000 <uninit+0x1cc7>
    1888:	912926d6 	add	x22, x22, #0xa49
{
    188c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
    1890:	52803e73 	mov	w19, #0x1f3                 	// #499
  unlink("bigwrite");
    1894:	90000034 	adrp	x20, 5000 <bigfile+0x108>
    1898:	91222694 	add	x20, x20, #0x889
{
    189c:	a90363f7 	stp	x23, x24, [sp, #48]
    18a0:	aa0003f7 	mov	x23, x0
  unlink("bigwrite");
    18a4:	aa1403e0 	mov	x0, x20
    18a8:	97fffeee 	bl	1460 <unlink@plt>
    fd = open("bigwrite", O_CREATE | O_RDWR);
    18ac:	aa1403e0 	mov	x0, x20
    18b0:	52804041 	mov	w1, #0x202                 	// #514
    18b4:	97ffff07 	bl	14d0 <open@plt>
    18b8:	2a0003f5 	mov	w21, w0
    if(fd < 0){
    18bc:	36f800e0 	tbz	w0, #31, 18d8 <bigwrite+0x60>
      printf("%s: cannot create bigwrite\n", s);
    18c0:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    18c4:	91224800 	add	x0, x0, #0x892
    18c8:	aa1703e1 	mov	x1, x23
    18cc:	97fffeb5 	bl	13a0 <printf@plt>
        exit(1);
    18d0:	52800020 	mov	w0, #0x1                   	// #1
    18d4:	97fffefb 	bl	14c0 <exit@plt>
    if(fd < 0){
    18d8:	52800058 	mov	w24, #0x2                   	// #2
      int cc = write(fd, buf, sz);
    18dc:	2a1303e2 	mov	w2, w19
    18e0:	aa1603e1 	mov	x1, x22
    18e4:	2a1503e0 	mov	w0, w21
    18e8:	97fffec2 	bl	13f0 <write@plt>
    18ec:	2a0003e3 	mov	w3, w0
      if(cc != sz){
    18f0:	6b13001f 	cmp	w0, w19
    18f4:	54000120 	b.eq	1918 <bigwrite+0xa0>  // b.none
        printf("%s: write(%d) ret %d\n", s, sz, cc);
    18f8:	2a1303e2 	mov	w2, w19
    18fc:	aa1703e1 	mov	x1, x23
    1900:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1904:	9122b800 	add	x0, x0, #0x8ae
    1908:	97fffea6 	bl	13a0 <printf@plt>
    190c:	17fffff1 	b	18d0 <bigwrite+0x58>
    for(i = 0; i < 2; i++){
    1910:	52800038 	mov	w24, #0x1                   	// #1
    1914:	17fffff2 	b	18dc <bigwrite+0x64>
    1918:	7100071f 	cmp	w24, #0x1
    191c:	54ffffa1 	b.ne	1910 <bigwrite+0x98>  // b.any
    close(fd);
    1920:	2a1503e0 	mov	w0, w21
    1924:	97fffef3 	bl	14f0 <close@plt>
    unlink("bigwrite");
    1928:	aa1403e0 	mov	x0, x20
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
    192c:	11075e73 	add	w19, w19, #0x1d7
    unlink("bigwrite");
    1930:	97fffecc 	bl	1460 <unlink@plt>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
    1934:	52863920 	mov	w0, #0x31c9                	// #12745
    1938:	6b00027f 	cmp	w19, w0
    193c:	54fffb81 	b.ne	18ac <bigwrite+0x34>  // b.any
}
    1940:	a94153f3 	ldp	x19, x20, [sp, #16]
    1944:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1948:	a94363f7 	ldp	x23, x24, [sp, #48]
    194c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1950:	d65f03c0 	ret

0000000000001954 <copyin>:
{
    1954:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
    1958:	d2b00000 	mov	x0, #0x80000000            	// #2147483648
{
    195c:	910003fd 	mov	x29, sp
    1960:	a90153f3 	stp	x19, x20, [sp, #16]
    int fd = open("copyin1", O_CREATE|O_WRONLY);
    1964:	90000034 	adrp	x20, 5000 <bigfile+0x108>
    1968:	91231294 	add	x20, x20, #0x8c4
{
    196c:	f9001bf7 	str	x23, [sp, #48]
    uint64 addr = addrs[ai];
    1970:	910143f7 	add	x23, sp, #0x50
{
    1974:	a9025bf5 	stp	x21, x22, [sp, #32]
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
    1978:	d2800015 	mov	x21, #0x0                   	// #0
    197c:	f9002be0 	str	x0, [sp, #80]
    1980:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    1984:	f9002fe0 	str	x0, [sp, #88]
    uint64 addr = addrs[ai];
    1988:	f8757af3 	ldr	x19, [x23, x21, lsl #3]
    int fd = open("copyin1", O_CREATE|O_WRONLY);
    198c:	aa1403e0 	mov	x0, x20
    1990:	52804021 	mov	w1, #0x201                 	// #513
    1994:	97fffecf 	bl	14d0 <open@plt>
    1998:	2a0003f6 	mov	w22, w0
    if(fd < 0){
    199c:	36f800e0 	tbz	w0, #31, 19b8 <copyin+0x64>
      printf("open(copyin1) failed\n");
    19a0:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    19a4:	91233000 	add	x0, x0, #0x8cc
      printf("pipe() failed\n");
    19a8:	97fffe7e 	bl	13a0 <printf@plt>
      exit(1);
    19ac:	1400000c 	b	19dc <copyin+0x88>
  for(int ai = 0; ai < 2; ai++){
    19b0:	d2800035 	mov	x21, #0x1                   	// #1
    19b4:	17fffff5 	b	1988 <copyin+0x34>
    int n = write(fd, (void*)addr, 8192);
    19b8:	52840002 	mov	w2, #0x2000                	// #8192
    19bc:	aa1303e1 	mov	x1, x19
    19c0:	97fffe8c 	bl	13f0 <write@plt>
    19c4:	2a0003e2 	mov	w2, w0
    if(n >= 0){
    19c8:	37f800e0 	tbnz	w0, #31, 19e4 <copyin+0x90>
      printf("write(fd, %p, 8192) returned %d, not -1\n", addr, n);
    19cc:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    19d0:	91238800 	add	x0, x0, #0x8e2
    19d4:	aa1303e1 	mov	x1, x19
    19d8:	97fffe72 	bl	13a0 <printf@plt>
      exit(1);
    19dc:	52800020 	mov	w0, #0x1                   	// #1
    19e0:	97fffeb8 	bl	14c0 <exit@plt>
    close(fd);
    19e4:	2a1603e0 	mov	w0, w22
    19e8:	97fffec2 	bl	14f0 <close@plt>
    unlink("copyin1");
    19ec:	aa1403e0 	mov	x0, x20
    19f0:	97fffe9c 	bl	1460 <unlink@plt>
    n = write(1, (char*)addr, 8192);
    19f4:	52840002 	mov	w2, #0x2000                	// #8192
    19f8:	aa1303e1 	mov	x1, x19
    19fc:	52800020 	mov	w0, #0x1                   	// #1
    1a00:	97fffe7c 	bl	13f0 <write@plt>
    1a04:	2a0003e2 	mov	w2, w0
    if(n > 0){
    1a08:	7100001f 	cmp	w0, #0x0
    1a0c:	5400008d 	b.le	1a1c <copyin+0xc8>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", addr, n);
    1a10:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1a14:	91242c00 	add	x0, x0, #0x90b
    1a18:	17ffffef 	b	19d4 <copyin+0x80>
    if(pipe(fds) < 0){
    1a1c:	910123e0 	add	x0, sp, #0x48
    1a20:	97fffe70 	bl	13e0 <pipe@plt>
    1a24:	36f80080 	tbz	w0, #31, 1a34 <copyin+0xe0>
      printf("pipe() failed\n");
    1a28:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1a2c:	913b5800 	add	x0, x0, #0xed6
    1a30:	17ffffde 	b	19a8 <copyin+0x54>
    n = write(fds[1], (char*)addr, 8192);
    1a34:	b9404fe0 	ldr	w0, [sp, #76]
    1a38:	52840002 	mov	w2, #0x2000                	// #8192
    1a3c:	aa1303e1 	mov	x1, x19
    1a40:	97fffe6c 	bl	13f0 <write@plt>
    1a44:	2a0003e2 	mov	w2, w0
    if(n > 0){
    1a48:	7100001f 	cmp	w0, #0x0
    1a4c:	5400008d 	b.le	1a5c <copyin+0x108>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", addr, n);
    1a50:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1a54:	9124e000 	add	x0, x0, #0x938
    1a58:	17ffffdf 	b	19d4 <copyin+0x80>
    close(fds[0]);
    1a5c:	b9404be0 	ldr	w0, [sp, #72]
    1a60:	97fffea4 	bl	14f0 <close@plt>
    close(fds[1]);
    1a64:	b9404fe0 	ldr	w0, [sp, #76]
    1a68:	97fffea2 	bl	14f0 <close@plt>
  for(int ai = 0; ai < 2; ai++){
    1a6c:	b4fffa35 	cbz	x21, 19b0 <copyin+0x5c>
}
    1a70:	f9401bf7 	ldr	x23, [sp, #48]
    1a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    1a78:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1a7c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    1a80:	d65f03c0 	ret

0000000000001a84 <copyout>:
{
    1a84:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
    1a88:	d2b00000 	mov	x0, #0x80000000            	// #2147483648
{
    1a8c:	910003fd 	mov	x29, sp
    1a90:	a9025bf5 	stp	x21, x22, [sp, #32]
    int fd = open("README", 0);
    1a94:	90000035 	adrp	x21, 5000 <bigfile+0x108>
    1a98:	9125a2b5 	add	x21, x21, #0x968
    n = write(fds[1], "x", 1);
    1a9c:	b0000036 	adrp	x22, 6000 <run+0x858>
    1aa0:	912752d6 	add	x22, x22, #0x9d4
{
    1aa4:	a90363f7 	stp	x23, x24, [sp, #48]
    uint64 addr = addrs[ai];
    1aa8:	910143f8 	add	x24, sp, #0x50
{
    1aac:	a90153f3 	stp	x19, x20, [sp, #16]
  uint64 addrs[] = { 0x80000000LL, 0xffffffffffffffff };
    1ab0:	d2800014 	mov	x20, #0x0                   	// #0
    1ab4:	f9002be0 	str	x0, [sp, #80]
    1ab8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    1abc:	f9002fe0 	str	x0, [sp, #88]
    uint64 addr = addrs[ai];
    1ac0:	f8747b13 	ldr	x19, [x24, x20, lsl #3]
    int fd = open("README", 0);
    1ac4:	aa1503e0 	mov	x0, x21
    1ac8:	52800001 	mov	w1, #0x0                   	// #0
    1acc:	97fffe81 	bl	14d0 <open@plt>
    1ad0:	2a0003f7 	mov	w23, w0
    if(fd < 0){
    1ad4:	36f800e0 	tbz	w0, #31, 1af0 <copyout+0x6c>
      printf("open(README) failed\n");
    1ad8:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1adc:	9125bc00 	add	x0, x0, #0x96f
      printf("pipe write failed\n");
    1ae0:	97fffe30 	bl	13a0 <printf@plt>
      exit(1);
    1ae4:	1400000d 	b	1b18 <copyout+0x94>
  for(int ai = 0; ai < 2; ai++){
    1ae8:	d2800034 	mov	x20, #0x1                   	// #1
    1aec:	17fffff5 	b	1ac0 <copyout+0x3c>
    int n = read(fd, (void*)addr, 8192);
    1af0:	52840002 	mov	w2, #0x2000                	// #8192
    1af4:	aa1303e1 	mov	x1, x19
    1af8:	97fffe56 	bl	1450 <read@plt>
    1afc:	2a0003e2 	mov	w2, w0
    if(n > 0){
    1b00:	7100001f 	cmp	w0, #0x0
    1b04:	540000ed 	b.le	1b20 <copyout+0x9c>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", addr, n);
    1b08:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1b0c:	91261000 	add	x0, x0, #0x984
    1b10:	aa1303e1 	mov	x1, x19
    1b14:	97fffe23 	bl	13a0 <printf@plt>
      exit(1);
    1b18:	52800020 	mov	w0, #0x1                   	// #1
    1b1c:	97fffe69 	bl	14c0 <exit@plt>
    close(fd);
    1b20:	2a1703e0 	mov	w0, w23
    1b24:	97fffe73 	bl	14f0 <close@plt>
    if(pipe(fds) < 0){
    1b28:	910123e0 	add	x0, sp, #0x48
    1b2c:	97fffe2d 	bl	13e0 <pipe@plt>
    1b30:	36f80080 	tbz	w0, #31, 1b40 <copyout+0xbc>
      printf("pipe() failed\n");
    1b34:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1b38:	913b5800 	add	x0, x0, #0xed6
    1b3c:	17ffffe9 	b	1ae0 <copyout+0x5c>
    n = write(fds[1], "x", 1);
    1b40:	b9404fe0 	ldr	w0, [sp, #76]
    1b44:	aa1603e1 	mov	x1, x22
    1b48:	52800022 	mov	w2, #0x1                   	// #1
    1b4c:	97fffe29 	bl	13f0 <write@plt>
    if(n != 1){
    1b50:	7100041f 	cmp	w0, #0x1
    1b54:	54000080 	b.eq	1b64 <copyout+0xe0>  // b.none
      printf("pipe write failed\n");
    1b58:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1b5c:	9126c400 	add	x0, x0, #0x9b1
    1b60:	17ffffe0 	b	1ae0 <copyout+0x5c>
    n = read(fds[0], (void*)addr, 8192);
    1b64:	b9404be0 	ldr	w0, [sp, #72]
    1b68:	52840002 	mov	w2, #0x2000                	// #8192
    1b6c:	aa1303e1 	mov	x1, x19
    1b70:	97fffe38 	bl	1450 <read@plt>
    1b74:	2a0003e2 	mov	w2, w0
    if(n > 0){
    1b78:	7100001f 	cmp	w0, #0x0
    1b7c:	5400008d 	b.le	1b8c <copyout+0x108>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", addr, n);
    1b80:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1b84:	91271000 	add	x0, x0, #0x9c4
    1b88:	17ffffe2 	b	1b10 <copyout+0x8c>
    close(fds[0]);
    1b8c:	b9404be0 	ldr	w0, [sp, #72]
    1b90:	97fffe58 	bl	14f0 <close@plt>
    close(fds[1]);
    1b94:	b9404fe0 	ldr	w0, [sp, #76]
    1b98:	97fffe56 	bl	14f0 <close@plt>
  for(int ai = 0; ai < 2; ai++){
    1b9c:	b4fffa74 	cbz	x20, 1ae8 <copyout+0x64>
}
    1ba0:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1ba8:	a94363f7 	ldp	x23, x24, [sp, #48]
    1bac:	a8c67bfd 	ldp	x29, x30, [sp], #96
    1bb0:	d65f03c0 	ret

0000000000001bb4 <truncate1>:
{
    1bb4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    1bb8:	910003fd 	mov	x29, sp
    1bbc:	a90153f3 	stp	x19, x20, [sp, #16]
    1bc0:	aa0003f4 	mov	x20, x0
  unlink("truncfile");
    1bc4:	90000033 	adrp	x19, 5000 <bigfile+0x108>
    1bc8:	91215a60 	add	x0, x19, #0x856
{
    1bcc:	a9025bf5 	stp	x21, x22, [sp, #32]
    1bd0:	a90363f7 	stp	x23, x24, [sp, #48]
  unlink("truncfile");
    1bd4:	97fffe23 	bl	1460 <unlink@plt>
  int fd1 = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    1bd8:	5280c021 	mov	w1, #0x601                 	// #1537
    1bdc:	91215a60 	add	x0, x19, #0x856
    1be0:	97fffe3c 	bl	14d0 <open@plt>
  write(fd1, "abcd", 4);
    1be4:	90000021 	adrp	x1, 5000 <bigfile+0x108>
    1be8:	91218021 	add	x1, x1, #0x860
    1bec:	52800082 	mov	w2, #0x4                   	// #4
  int fd1 = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    1bf0:	2a0003f5 	mov	w21, w0
  write(fd1, "abcd", 4);
    1bf4:	97fffdff 	bl	13f0 <write@plt>
  close(fd1);
    1bf8:	2a1503e0 	mov	w0, w21
    1bfc:	97fffe3d 	bl	14f0 <close@plt>
  int fd2 = open("truncfile", O_RDONLY);
    1c00:	52800001 	mov	w1, #0x0                   	// #0
    1c04:	91215a60 	add	x0, x19, #0x856
    1c08:	97fffe32 	bl	14d0 <open@plt>
    1c0c:	2a0003f5 	mov	w21, w0
  int n = read(fd2, buf, sizeof(buf));
    1c10:	910103e1 	add	x1, sp, #0x40
    1c14:	52800402 	mov	w2, #0x20                  	// #32
    1c18:	97fffe0e 	bl	1450 <read@plt>
  if(n != 4){
    1c1c:	7100101f 	cmp	w0, #0x4
    1c20:	54000100 	b.eq	1c40 <truncate1+0x8c>  // b.none
    1c24:	2a0003e2 	mov	w2, w0
    printf("%s: read %d bytes, wanted 4\n", s, n);
    1c28:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1c2c:	9127cc00 	add	x0, x0, #0x9f3
    printf("%s: read %d bytes, wanted 0\n", s, n);
    1c30:	aa1403e1 	mov	x1, x20
    1c34:	97fffddb 	bl	13a0 <printf@plt>
    exit(1);
    1c38:	52800020 	mov	w0, #0x1                   	// #1
    1c3c:	97fffe21 	bl	14c0 <exit@plt>
  fd1 = open("truncfile", O_WRONLY|O_TRUNC);
    1c40:	52808021 	mov	w1, #0x401                 	// #1025
    1c44:	91215a60 	add	x0, x19, #0x856
    1c48:	97fffe22 	bl	14d0 <open@plt>
    1c4c:	2a0003f7 	mov	w23, w0
  int fd3 = open("truncfile", O_RDONLY);
    1c50:	52800001 	mov	w1, #0x0                   	// #0
    1c54:	91215a60 	add	x0, x19, #0x856
    1c58:	97fffe1e 	bl	14d0 <open@plt>
    1c5c:	2a0003f6 	mov	w22, w0
  n = read(fd3, buf, sizeof(buf));
    1c60:	910103e1 	add	x1, sp, #0x40
    1c64:	52800402 	mov	w2, #0x20                  	// #32
    1c68:	97fffdfa 	bl	1450 <read@plt>
    1c6c:	2a0003f8 	mov	w24, w0
  if(n != 0){
    1c70:	34000120 	cbz	w0, 1c94 <truncate1+0xe0>
    printf("aaa fd3=%d\n", fd3);
    1c74:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1c78:	91284000 	add	x0, x0, #0xa10
    1c7c:	2a1603e1 	mov	w1, w22
    1c80:	97fffdc8 	bl	13a0 <printf@plt>
    printf("%s: read %d bytes, wanted 0\n", s, n);
    1c84:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1c88:	91287000 	add	x0, x0, #0xa1c
    1c8c:	2a1803e2 	mov	w2, w24
    1c90:	17ffffe8 	b	1c30 <truncate1+0x7c>
  n = read(fd2, buf, sizeof(buf));
    1c94:	910103e1 	add	x1, sp, #0x40
    1c98:	2a1503e0 	mov	w0, w21
    1c9c:	52800402 	mov	w2, #0x20                  	// #32
    1ca0:	97fffdec 	bl	1450 <read@plt>
    1ca4:	2a0003f8 	mov	w24, w0
  if(n != 0){
    1ca8:	340000a0 	cbz	w0, 1cbc <truncate1+0x108>
    printf("bbb fd2=%d\n", fd2);
    1cac:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1cb0:	9128e400 	add	x0, x0, #0xa39
    1cb4:	2a1503e1 	mov	w1, w21
    1cb8:	17fffff2 	b	1c80 <truncate1+0xcc>
  write(fd1, "abcdef", 6);
    1cbc:	528000c2 	mov	w2, #0x6                   	// #6
    1cc0:	2a1703e0 	mov	w0, w23
    1cc4:	90000021 	adrp	x1, 5000 <bigfile+0x108>
    1cc8:	91291421 	add	x1, x1, #0xa45
    1ccc:	97fffdc9 	bl	13f0 <write@plt>
  n = read(fd3, buf, sizeof(buf));
    1cd0:	52800402 	mov	w2, #0x20                  	// #32
    1cd4:	910103e1 	add	x1, sp, #0x40
    1cd8:	2a1603e0 	mov	w0, w22
    1cdc:	97fffddd 	bl	1450 <read@plt>
    1ce0:	2a0003e2 	mov	w2, w0
  if(n != 6){
    1ce4:	7100181f 	cmp	w0, #0x6
    1ce8:	54000080 	b.eq	1cf8 <truncate1+0x144>  // b.none
    printf("%s: read %d bytes, wanted 6\n", s, n);
    1cec:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1cf0:	91293000 	add	x0, x0, #0xa4c
    1cf4:	17ffffcf 	b	1c30 <truncate1+0x7c>
  n = read(fd2, buf, sizeof(buf));
    1cf8:	52800402 	mov	w2, #0x20                  	// #32
    1cfc:	910103e1 	add	x1, sp, #0x40
    1d00:	2a1503e0 	mov	w0, w21
    1d04:	97fffdd3 	bl	1450 <read@plt>
    1d08:	2a0003e2 	mov	w2, w0
  if(n != 2){
    1d0c:	7100081f 	cmp	w0, #0x2
    1d10:	54000080 	b.eq	1d20 <truncate1+0x16c>  // b.none
    printf("%s: read %d bytes, wanted 2\n", s, n);
    1d14:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1d18:	9129a400 	add	x0, x0, #0xa69
    1d1c:	17ffffc5 	b	1c30 <truncate1+0x7c>
  unlink("truncfile");
    1d20:	91215a60 	add	x0, x19, #0x856
    1d24:	97fffdcf 	bl	1460 <unlink@plt>
  close(fd1);
    1d28:	2a1703e0 	mov	w0, w23
    1d2c:	97fffdf1 	bl	14f0 <close@plt>
  close(fd2);
    1d30:	2a1503e0 	mov	w0, w21
    1d34:	97fffdef 	bl	14f0 <close@plt>
  close(fd3);
    1d38:	2a1603e0 	mov	w0, w22
    1d3c:	97fffded 	bl	14f0 <close@plt>
}
    1d40:	a94153f3 	ldp	x19, x20, [sp, #16]
    1d44:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1d48:	a94363f7 	ldp	x23, x24, [sp, #48]
    1d4c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    1d50:	d65f03c0 	ret

0000000000001d54 <writetest>:
{
    1d54:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  fd = open("small", O_CREATE|O_RDWR);
    1d58:	52804041 	mov	w1, #0x202                 	// #514
{
    1d5c:	910003fd 	mov	x29, sp
    1d60:	a90153f3 	stp	x19, x20, [sp, #16]
  fd = open("small", O_CREATE|O_RDWR);
    1d64:	90000034 	adrp	x20, 5000 <bigfile+0x108>
    1d68:	912a1a94 	add	x20, x20, #0xa86
{
    1d6c:	aa0003f3 	mov	x19, x0
  fd = open("small", O_CREATE|O_RDWR);
    1d70:	aa1403e0 	mov	x0, x20
{
    1d74:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d78:	a90363f7 	stp	x23, x24, [sp, #48]
  fd = open("small", O_CREATE|O_RDWR);
    1d7c:	97fffdd5 	bl	14d0 <open@plt>
  if(fd < 0){
    1d80:	37f80280 	tbnz	w0, #31, 1dd0 <writetest+0x7c>
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
    1d84:	90000037 	adrp	x23, 5000 <bigfile+0x108>
    1d88:	912ab2f7 	add	x23, x23, #0xaac
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
    1d8c:	90000038 	adrp	x24, 5000 <bigfile+0x108>
    1d90:	912b7f18 	add	x24, x24, #0xadf
    1d94:	2a0003f6 	mov	w22, w0
    1d98:	52800015 	mov	w21, #0x0                   	// #0
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
    1d9c:	aa1703e1 	mov	x1, x23
    1da0:	2a1603e0 	mov	w0, w22
    1da4:	52800142 	mov	w2, #0xa                   	// #10
    1da8:	97fffd92 	bl	13f0 <write@plt>
    1dac:	7100281f 	cmp	w0, #0xa
    1db0:	540001a0 	b.eq	1de4 <writetest+0x90>  // b.none
      printf("%s: error: write aa %d new file failed\n", s, i);
    1db4:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1db8:	912adc00 	add	x0, x0, #0xab7
    1dbc:	2a1503e2 	mov	w2, w21
    1dc0:	aa1303e1 	mov	x1, x19
    1dc4:	97fffd77 	bl	13a0 <printf@plt>
      exit(1);
    1dc8:	52800020 	mov	w0, #0x1                   	// #1
    1dcc:	97fffdbd 	bl	14c0 <exit@plt>
    printf("%s: error: creat small failed!\n", s);
    1dd0:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1dd4:	912a3000 	add	x0, x0, #0xa8c
    printf("%s: unlink small failed\n", s);
    1dd8:	aa1303e1 	mov	x1, x19
    1ddc:	97fffd71 	bl	13a0 <printf@plt>
    exit(1);
    1de0:	17fffffa 	b	1dc8 <writetest+0x74>
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
    1de4:	2a0003e2 	mov	w2, w0
    1de8:	aa1803e1 	mov	x1, x24
    1dec:	2a1603e0 	mov	w0, w22
    1df0:	97fffd80 	bl	13f0 <write@plt>
    1df4:	7100281f 	cmp	w0, #0xa
    1df8:	54000080 	b.eq	1e08 <writetest+0xb4>  // b.none
      printf("%s: error: write bb %d new file failed\n", s, i);
    1dfc:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1e00:	912ba800 	add	x0, x0, #0xaea
    1e04:	17ffffee 	b	1dbc <writetest+0x68>
  for(i = 0; i < N; i++){
    1e08:	110006b5 	add	w21, w21, #0x1
    1e0c:	710192bf 	cmp	w21, #0x64
    1e10:	54fffc61 	b.ne	1d9c <writetest+0x48>  // b.any
  close(fd);
    1e14:	2a1603e0 	mov	w0, w22
    1e18:	97fffdb6 	bl	14f0 <close@plt>
  fd = open("small", O_RDONLY);
    1e1c:	aa1403e0 	mov	x0, x20
    1e20:	52800001 	mov	w1, #0x0                   	// #0
    1e24:	97fffdab 	bl	14d0 <open@plt>
    1e28:	2a0003f5 	mov	w21, w0
  if(fd < 0){
    1e2c:	36f80080 	tbz	w0, #31, 1e3c <writetest+0xe8>
    printf("%s: error: open small failed!\n", s);
    1e30:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1e34:	912c4800 	add	x0, x0, #0xb12
    1e38:	17ffffe8 	b	1dd8 <writetest+0x84>
  i = read(fd, buf, N*SZ*2);
    1e3c:	d0000041 	adrp	x1, b000 <uninit+0x1cc7>
    1e40:	91292421 	add	x1, x1, #0xa49
    1e44:	5280fa02 	mov	w2, #0x7d0                 	// #2000
    1e48:	97fffd82 	bl	1450 <read@plt>
  if(i != N*SZ*2){
    1e4c:	711f401f 	cmp	w0, #0x7d0
    1e50:	54000080 	b.eq	1e60 <writetest+0x10c>  // b.none
    printf("%s: read failed\n", s);
    1e54:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1e58:	912cc400 	add	x0, x0, #0xb31
    1e5c:	17ffffdf 	b	1dd8 <writetest+0x84>
  close(fd);
    1e60:	2a1503e0 	mov	w0, w21
    1e64:	97fffda3 	bl	14f0 <close@plt>
  if(unlink("small") < 0){
    1e68:	aa1403e0 	mov	x0, x20
    1e6c:	97fffd7d 	bl	1460 <unlink@plt>
    1e70:	36f80080 	tbz	w0, #31, 1e80 <writetest+0x12c>
    printf("%s: unlink small failed\n", s);
    1e74:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1e78:	912d0800 	add	x0, x0, #0xb42
    1e7c:	17ffffd7 	b	1dd8 <writetest+0x84>
}
    1e80:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e84:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e88:	a94363f7 	ldp	x23, x24, [sp, #48]
    1e8c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e90:	d65f03c0 	ret

0000000000001e94 <unlinkread>:
{
    1e94:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  fd = open("unlinkread", O_CREATE | O_RDWR);
    1e98:	52804041 	mov	w1, #0x202                 	// #514
{
    1e9c:	910003fd 	mov	x29, sp
    1ea0:	a90153f3 	stp	x19, x20, [sp, #16]
    1ea4:	aa0003f4 	mov	x20, x0
  fd = open("unlinkread", O_CREATE | O_RDWR);
    1ea8:	90000033 	adrp	x19, 5000 <bigfile+0x108>
    1eac:	912d6e60 	add	x0, x19, #0xb5b
{
    1eb0:	a9025bf5 	stp	x21, x22, [sp, #32]
    1eb4:	f9001bf7 	str	x23, [sp, #48]
  fd = open("unlinkread", O_CREATE | O_RDWR);
    1eb8:	97fffd86 	bl	14d0 <open@plt>
  if(fd < 0){
    1ebc:	36f800e0 	tbz	w0, #31, 1ed8 <unlinkread+0x44>
    printf("%s: create unlinkread failed\n", s);
    1ec0:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1ec4:	912d9800 	add	x0, x0, #0xb66
    printf("%s: open unlinkread failed\n", s);
    1ec8:	aa1403e1 	mov	x1, x20
    1ecc:	97fffd35 	bl	13a0 <printf@plt>
    exit(1);
    1ed0:	52800020 	mov	w0, #0x1                   	// #1
    1ed4:	97fffd7b 	bl	14c0 <exit@plt>
  write(fd, "hello", SZ);
    1ed8:	90000021 	adrp	x1, 5000 <bigfile+0x108>
    1edc:	912e1021 	add	x1, x1, #0xb84
    1ee0:	528000a2 	mov	w2, #0x5                   	// #5
    1ee4:	2a0003f5 	mov	w21, w0
    1ee8:	97fffd42 	bl	13f0 <write@plt>
  close(fd);
    1eec:	2a1503e0 	mov	w0, w21
    1ef0:	97fffd80 	bl	14f0 <close@plt>
  fd = open("unlinkread", O_RDWR);
    1ef4:	912d6e60 	add	x0, x19, #0xb5b
    1ef8:	52800041 	mov	w1, #0x2                   	// #2
    1efc:	97fffd75 	bl	14d0 <open@plt>
    1f00:	2a0003f5 	mov	w21, w0
  if(fd < 0){
    1f04:	36f80080 	tbz	w0, #31, 1f14 <unlinkread+0x80>
    printf("%s: open unlinkread failed\n", s);
    1f08:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1f0c:	912e2800 	add	x0, x0, #0xb8a
    1f10:	17ffffee 	b	1ec8 <unlinkread+0x34>
  if(unlink("unlinkread") != 0){
    1f14:	912d6e60 	add	x0, x19, #0xb5b
    1f18:	97fffd52 	bl	1460 <unlink@plt>
    1f1c:	34000080 	cbz	w0, 1f2c <unlinkread+0x98>
    printf("%s: unlink unlinkread failed\n", s);
    1f20:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1f24:	912e9800 	add	x0, x0, #0xba6
    1f28:	17ffffe8 	b	1ec8 <unlinkread+0x34>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
    1f2c:	52804041 	mov	w1, #0x202                 	// #514
    1f30:	912d6e60 	add	x0, x19, #0xb5b
    1f34:	97fffd67 	bl	14d0 <open@plt>
    1f38:	2a0003f6 	mov	w22, w0
  write(fd1, "yyy", 3);
    1f3c:	90000021 	adrp	x1, 5000 <bigfile+0x108>
    1f40:	912f1021 	add	x1, x1, #0xbc4
    1f44:	52800062 	mov	w2, #0x3                   	// #3
    1f48:	97fffd2a 	bl	13f0 <write@plt>
  close(fd1);
    1f4c:	2a1603e0 	mov	w0, w22
  if(read(fd, buf, sizeof(buf)) != SZ){
    1f50:	d0000057 	adrp	x23, b000 <uninit+0x1cc7>
  close(fd1);
    1f54:	97fffd67 	bl	14f0 <close@plt>
  if(read(fd, buf, sizeof(buf)) != SZ){
    1f58:	912926e1 	add	x1, x23, #0xa49
    1f5c:	2a1503e0 	mov	w0, w21
    1f60:	52860002 	mov	w2, #0x3000                	// #12288
    1f64:	97fffd3b 	bl	1450 <read@plt>
    1f68:	7100141f 	cmp	w0, #0x5
    1f6c:	54000080 	b.eq	1f7c <unlinkread+0xe8>  // b.none
    printf("%s: unlinkread read failed", s);
    1f70:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1f74:	912f2000 	add	x0, x0, #0xbc8
    1f78:	17ffffd4 	b	1ec8 <unlinkread+0x34>
  if(buf[0] != 'h'){
    1f7c:	396926e0 	ldrb	w0, [x23, #2633]
    1f80:	7101a01f 	cmp	w0, #0x68
    1f84:	54000080 	b.eq	1f94 <unlinkread+0x100>  // b.none
    printf("%s: unlinkread wrong data\n", s);
    1f88:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1f8c:	912f8c00 	add	x0, x0, #0xbe3
    1f90:	17ffffce 	b	1ec8 <unlinkread+0x34>
  if(write(fd, buf, 10) != 10){
    1f94:	912926e1 	add	x1, x23, #0xa49
    1f98:	2a1503e0 	mov	w0, w21
    1f9c:	52800142 	mov	w2, #0xa                   	// #10
    1fa0:	97fffd14 	bl	13f0 <write@plt>
    1fa4:	7100281f 	cmp	w0, #0xa
    1fa8:	54000080 	b.eq	1fb8 <unlinkread+0x124>  // b.none
    printf("%s: unlinkread write failed\n", s);
    1fac:	90000020 	adrp	x0, 5000 <bigfile+0x108>
    1fb0:	912ff800 	add	x0, x0, #0xbfe
    1fb4:	17ffffc5 	b	1ec8 <unlinkread+0x34>
  close(fd);
    1fb8:	2a1503e0 	mov	w0, w21
    1fbc:	97fffd4d 	bl	14f0 <close@plt>
}
    1fc0:	f9401bf7 	ldr	x23, [sp, #48]
  unlink("unlinkread");
    1fc4:	912d6e60 	add	x0, x19, #0xb5b
}
    1fc8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1fcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    1fd0:	a8c47bfd 	ldp	x29, x30, [sp], #64
  unlink("unlinkread");
    1fd4:	17fffd23 	b	1460 <unlink@plt>

0000000000001fd8 <linktest>:
{
    1fd8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1fdc:	910003fd 	mov	x29, sp
    1fe0:	a90153f3 	stp	x19, x20, [sp, #16]
    1fe4:	aa0003f3 	mov	x19, x0
  unlink("lf1");
    1fe8:	90000034 	adrp	x20, 5000 <bigfile+0x108>
    1fec:	91306e80 	add	x0, x20, #0xc1b
{
    1ff0:	a9025bf5 	stp	x21, x22, [sp, #32]
  unlink("lf1");
    1ff4:	97fffd1b 	bl	1460 <unlink@plt>
  unlink("lf2");
    1ff8:	90000035 	adrp	x21, 5000 <bigfile+0x108>
    1ffc:	91307ea0 	add	x0, x21, #0xc1f
    2000:	97fffd18 	bl	1460 <unlink@plt>
  fd = open("lf1", O_CREATE|O_RDWR);
    2004:	91306e80 	add	x0, x20, #0xc1b
    2008:	52804041 	mov	w1, #0x202                 	// #514
    200c:	97fffd31 	bl	14d0 <open@plt>
  if(fd < 0){
    2010:	36f800e0 	tbz	w0, #31, 202c <linktest+0x54>
    printf("%s: create lf1 failed\n", s);
    2014:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2018:	91308c00 	add	x0, x0, #0xc23
    printf("%s: write lf1 failed\n", s);
    201c:	aa1303e1 	mov	x1, x19
    2020:	97fffce0 	bl	13a0 <printf@plt>
    exit(1);
    2024:	52800020 	mov	w0, #0x1                   	// #1
    2028:	97fffd26 	bl	14c0 <exit@plt>
  if(write(fd, "hello", SZ) != SZ){
    202c:	f0000001 	adrp	x1, 5000 <bigfile+0x108>
    2030:	912e1021 	add	x1, x1, #0xb84
    2034:	2a0003f6 	mov	w22, w0
    2038:	528000a2 	mov	w2, #0x5                   	// #5
    203c:	97fffced 	bl	13f0 <write@plt>
    2040:	7100141f 	cmp	w0, #0x5
    2044:	54000080 	b.eq	2054 <linktest+0x7c>  // b.none
    printf("%s: write lf1 failed\n", s);
    2048:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    204c:	9130e800 	add	x0, x0, #0xc3a
    2050:	17fffff3 	b	201c <linktest+0x44>
  close(fd);
    2054:	2a1603e0 	mov	w0, w22
    2058:	97fffd26 	bl	14f0 <close@plt>
  if(link("lf1", "lf2") < 0){
    205c:	91307ea1 	add	x1, x21, #0xc1f
    2060:	91306e80 	add	x0, x20, #0xc1b
    2064:	97fffd13 	bl	14b0 <link@plt>
    2068:	36f80080 	tbz	w0, #31, 2078 <linktest+0xa0>
    printf("%s: link lf1 lf2 failed\n", s);
    206c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2070:	91314000 	add	x0, x0, #0xc50
    2074:	17ffffea 	b	201c <linktest+0x44>
  unlink("lf1");
    2078:	91306e80 	add	x0, x20, #0xc1b
    207c:	97fffcf9 	bl	1460 <unlink@plt>
  if(open("lf1", 0) >= 0){
    2080:	91306e80 	add	x0, x20, #0xc1b
    2084:	52800001 	mov	w1, #0x0                   	// #0
    2088:	97fffd12 	bl	14d0 <open@plt>
    208c:	37f80080 	tbnz	w0, #31, 209c <linktest+0xc4>
    printf("%s: unlinked lf1 but it is still there!\n", s);
    2090:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2094:	9131a400 	add	x0, x0, #0xc69
    2098:	17ffffe1 	b	201c <linktest+0x44>
  fd = open("lf2", 0);
    209c:	91307ea0 	add	x0, x21, #0xc1f
    20a0:	52800001 	mov	w1, #0x0                   	// #0
    20a4:	97fffd0b 	bl	14d0 <open@plt>
    20a8:	2a0003f6 	mov	w22, w0
  if(fd < 0){
    20ac:	36f80080 	tbz	w0, #31, 20bc <linktest+0xe4>
    printf("%s: open lf2 failed\n", s);
    20b0:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    20b4:	91324800 	add	x0, x0, #0xc92
    20b8:	17ffffd9 	b	201c <linktest+0x44>
  if(read(fd, buf, sizeof(buf)) != SZ){
    20bc:	b0000041 	adrp	x1, b000 <uninit+0x1cc7>
    20c0:	91292421 	add	x1, x1, #0xa49
    20c4:	52860002 	mov	w2, #0x3000                	// #12288
    20c8:	97fffce2 	bl	1450 <read@plt>
    20cc:	7100141f 	cmp	w0, #0x5
    20d0:	54000080 	b.eq	20e0 <linktest+0x108>  // b.none
    printf("%s: read lf2 failed\n", s);
    20d4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    20d8:	91329c00 	add	x0, x0, #0xca7
    20dc:	17ffffd0 	b	201c <linktest+0x44>
  close(fd);
    20e0:	2a1603e0 	mov	w0, w22
    20e4:	97fffd03 	bl	14f0 <close@plt>
  if(link("lf2", "lf2") >= 0){
    20e8:	91307ea1 	add	x1, x21, #0xc1f
    20ec:	91307ea0 	add	x0, x21, #0xc1f
    20f0:	97fffcf0 	bl	14b0 <link@plt>
    20f4:	37f80080 	tbnz	w0, #31, 2104 <linktest+0x12c>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
    20f8:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    20fc:	9132f000 	add	x0, x0, #0xcbc
    2100:	17ffffc7 	b	201c <linktest+0x44>
  unlink("lf2");
    2104:	91307ea0 	add	x0, x21, #0xc1f
    2108:	97fffcd6 	bl	1460 <unlink@plt>
  if(link("lf2", "lf1") >= 0){
    210c:	91306e81 	add	x1, x20, #0xc1b
    2110:	91307ea0 	add	x0, x21, #0xc1f
    2114:	97fffce7 	bl	14b0 <link@plt>
    2118:	37f80080 	tbnz	w0, #31, 2128 <linktest+0x150>
    printf("%s: link non-existent succeeded! oops\n", s);
    211c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2120:	91337800 	add	x0, x0, #0xcde
    2124:	17ffffbe 	b	201c <linktest+0x44>
  if(link(".", "lf1") >= 0){
    2128:	90000020 	adrp	x0, 6000 <run+0x858>
    212c:	9122a000 	add	x0, x0, #0x8a8
    2130:	91306e81 	add	x1, x20, #0xc1b
    2134:	97fffcdf 	bl	14b0 <link@plt>
    2138:	37f80080 	tbnz	w0, #31, 2148 <linktest+0x170>
    printf("%s: link . lf1 succeeded! oops\n", s);
    213c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2140:	91341400 	add	x0, x0, #0xd05
    2144:	17ffffb6 	b	201c <linktest+0x44>
}
    2148:	a94153f3 	ldp	x19, x20, [sp, #16]
    214c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2150:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2154:	d65f03c0 	ret

0000000000002158 <pgbug>:
{
    2158:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  exec((char*)0xeaeb0b5b00002f5e, argv);
    215c:	d285ebc0 	mov	x0, #0x2f5e                	// #12126
    2160:	f2c16b60 	movk	x0, #0xb5b, lsl #32
    2164:	f2fd5d60 	movk	x0, #0xeaeb, lsl #48
{
    2168:	910003fd 	mov	x29, sp
  exec((char*)0xeaeb0b5b00002f5e, argv);
    216c:	910063e1 	add	x1, sp, #0x18
  argv[0] = 0;
    2170:	f9000fff 	str	xzr, [sp, #24]
  exec((char*)0xeaeb0b5b00002f5e, argv);
    2174:	97fffcaf 	bl	1430 <exec@plt>
  pipe((int*)0xeaeb0b5b00002f5e);
    2178:	d285ebc0 	mov	x0, #0x2f5e                	// #12126
    217c:	f2c16b60 	movk	x0, #0xb5b, lsl #32
    2180:	f2fd5d60 	movk	x0, #0xeaeb, lsl #48
    2184:	97fffc97 	bl	13e0 <pipe@plt>
  exit(0);
    2188:	52800000 	mov	w0, #0x0                   	// #0
    218c:	97fffccd 	bl	14c0 <exit@plt>

0000000000002190 <badarg>:
{
    2190:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2194:	910003fd 	mov	x29, sp
    2198:	a90153f3 	stp	x19, x20, [sp, #16]
    exec("/bin/echo", argv);
    219c:	f0000014 	adrp	x20, 5000 <bigfile+0x108>
    21a0:	91349694 	add	x20, x20, #0xd25
{
    21a4:	52986a13 	mov	w19, #0xc350                	// #50000
    21a8:	f90013f5 	str	x21, [sp, #32]
    argv[0] = (char*)0xffffffff;
    21ac:	b2407ff5 	mov	x21, #0xffffffff            	// #4294967295
    exec("/bin/echo", argv);
    21b0:	9100c3e1 	add	x1, sp, #0x30
    21b4:	aa1403e0 	mov	x0, x20
    argv[0] = (char*)0xffffffff;
    21b8:	a9037ff5 	stp	x21, xzr, [sp, #48]
    exec("/bin/echo", argv);
    21bc:	97fffc9d 	bl	1430 <exec@plt>
  for(int i = 0; i < 50000; i++){
    21c0:	71000673 	subs	w19, w19, #0x1
    21c4:	54ffff61 	b.ne	21b0 <badarg+0x20>  // b.any
  exit(0);
    21c8:	52800000 	mov	w0, #0x0                   	// #0
    21cc:	97fffcbd 	bl	14c0 <exit@plt>

00000000000021d0 <copyinstr2>:
{
    21d0:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
    21d4:	d2800000 	mov	x0, #0x0                   	// #0
    b[i] = 'x';
    21d8:	52800f01 	mov	w1, #0x78                  	// #120
{
    21dc:	910003fd 	mov	x29, sp
    b[i] = 'x';
    21e0:	910163e2 	add	x2, sp, #0x58
    21e4:	38206841 	strb	w1, [x2, x0]
  for(int i = 0; i < MAXPATH; i++)
    21e8:	91000400 	add	x0, x0, #0x1
    21ec:	f102001f 	cmp	x0, #0x80
    21f0:	54ffff81 	b.ne	21e0 <copyinstr2+0x10>  // b.any
  int ret = unlink(b);
    21f4:	aa0203e0 	mov	x0, x2
  b[MAXPATH] = '\0';
    21f8:	390363ff 	strb	wzr, [sp, #216]
  int ret = unlink(b);
    21fc:	97fffc99 	bl	1460 <unlink@plt>
    2200:	2a0003e2 	mov	w2, w0
  if(ret != -1){
    2204:	3100041f 	cmn	w0, #0x1
    2208:	540000e0 	b.eq	2224 <copyinstr2+0x54>  // b.none
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    220c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2210:	9134bc00 	add	x0, x0, #0xd2f
    printf("open(%s) returned %d, not -1\n", b, fd);
    2214:	910163e1 	add	x1, sp, #0x58
    2218:	97fffc62 	bl	13a0 <printf@plt>
    exit(1);
    221c:	52800020 	mov	w0, #0x1                   	// #1
    2220:	97fffca8 	bl	14c0 <exit@plt>
  int fd = open(b, O_CREATE | O_WRONLY);
    2224:	910163e0 	add	x0, sp, #0x58
    2228:	52804021 	mov	w1, #0x201                 	// #513
    222c:	97fffca9 	bl	14d0 <open@plt>
    2230:	2a0003e2 	mov	w2, w0
  if(fd != -1){
    2234:	3100041f 	cmn	w0, #0x1
    2238:	54000080 	b.eq	2248 <copyinstr2+0x78>  // b.none
    printf("open(%s) returned %d, not -1\n", b, fd);
    223c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2240:	91353c00 	add	x0, x0, #0xd4f
    2244:	17fffff4 	b	2214 <copyinstr2+0x44>
  ret = link(b, b);
    2248:	910163e1 	add	x1, sp, #0x58
    224c:	aa0103e0 	mov	x0, x1
    2250:	97fffc98 	bl	14b0 <link@plt>
    2254:	2a0003e2 	mov	w2, w0
  if(ret != -1){
    2258:	3100041f 	cmn	w0, #0x1
    225c:	54000100 	b.eq	227c <copyinstr2+0xac>  // b.none
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    2260:	2a0203e3 	mov	w3, w2
    2264:	910163e2 	add	x2, sp, #0x58
    2268:	aa0203e1 	mov	x1, x2
    226c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2270:	9135b400 	add	x0, x0, #0xd6d
    2274:	97fffc4b 	bl	13a0 <printf@plt>
    exit(1);
    2278:	17ffffe9 	b	221c <copyinstr2+0x4c>
  char *args[] = { "xx", 0 };
    227c:	90000020 	adrp	x0, 6000 <run+0x858>
    2280:	91274c00 	add	x0, x0, #0x9d3
  ret = exec(b, args);
    2284:	9100a3e1 	add	x1, sp, #0x28
    2288:	b9001fe2 	str	w2, [sp, #28]
  char *args[] = { "xx", 0 };
    228c:	a902ffe0 	stp	x0, xzr, [sp, #40]
  ret = exec(b, args);
    2290:	910163e0 	add	x0, sp, #0x58
    2294:	97fffc67 	bl	1430 <exec@plt>
  if(ret != -1){
    2298:	b9401fe2 	ldr	w2, [sp, #28]
    229c:	3100041f 	cmn	w0, #0x1
    22a0:	54000080 	b.eq	22b0 <copyinstr2+0xe0>  // b.none
    printf("exec(%s) returned %d, not -1\n", b, fd);
    22a4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    22a8:	91363c00 	add	x0, x0, #0xd8f
    22ac:	17ffffda 	b	2214 <copyinstr2+0x44>
  int pid = fork();
    22b0:	97fffc70 	bl	1470 <fork@plt>
  if(pid < 0){
    22b4:	36f800a0 	tbz	w0, #31, 22c8 <copyinstr2+0xf8>
    printf("fork failed\n");
    22b8:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    22bc:	91381400 	add	x0, x0, #0xe05
    printf("exec(echo, BIG) succeeded, should have failed\n");
    22c0:	97fffc38 	bl	13a0 <printf@plt>
    exit(1);
    22c4:	17ffffd6 	b	221c <copyinstr2+0x4c>
  if(pid == 0){
    22c8:	350003c0 	cbnz	w0, 2340 <copyinstr2+0x170>
      big[i] = 'x';
    22cc:	d0000020 	adrp	x0, 8000 <_DYNAMIC>
    22d0:	910ce000 	add	x0, x0, #0x338
  if(pid == 0){
    22d4:	d2800001 	mov	x1, #0x0                   	// #0
      big[i] = 'x';
    22d8:	52800f02 	mov	w2, #0x78                  	// #120
    22dc:	38216802 	strb	w2, [x0, x1]
    for(int i = 0; i < PGSIZE; i++)
    22e0:	91000421 	add	x1, x1, #0x1
    22e4:	f140043f 	cmp	x1, #0x1, lsl #12
    22e8:	54ffffa1 	b.ne	22dc <copyinstr2+0x10c>  // b.any
    big[PGSIZE] = '\0';
    22ec:	91400400 	add	x0, x0, #0x1, lsl #12
    22f0:	3900001f 	strb	wzr, [x0]
    char *args2[] = { big, big, big, 0 };
    22f4:	b0000020 	adrp	x0, 7000 <run+0x1858>
    22f8:	91184000 	add	x0, x0, #0x610
    22fc:	a9400c02 	ldp	x2, x3, [x0]
    2300:	a9038fe2 	stp	x2, x3, [sp, #56]
    2304:	a9410400 	ldp	x0, x1, [x0, #16]
    2308:	a90487e0 	stp	x0, x1, [sp, #72]
    ret = exec("/bin/echo", args2);
    230c:	9100e3e1 	add	x1, sp, #0x38
    2310:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2314:	91349400 	add	x0, x0, #0xd25
    2318:	97fffc46 	bl	1430 <exec@plt>
    if(ret != -1){
    231c:	3100041f 	cmn	w0, #0x1
    2320:	540000c0 	b.eq	2338 <copyinstr2+0x168>  // b.none
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
    2324:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2328:	9136b400 	add	x0, x0, #0xdad
    232c:	12800001 	mov	w1, #0xffffffff            	// #-1
    2330:	97fffc1c 	bl	13a0 <printf@plt>
      exit(1);
    2334:	17ffffba 	b	221c <copyinstr2+0x4c>
    exit(747); // OK
    2338:	52805d60 	mov	w0, #0x2eb                 	// #747
    233c:	17ffffb9 	b	2220 <copyinstr2+0x50>
  wait(&st);
    2340:	9100e3e0 	add	x0, sp, #0x38
  int st = 0;
    2344:	b9003bff 	str	wzr, [sp, #56]
  wait(&st);
    2348:	97fffc3e 	bl	1440 <wait@plt>
  if(st != 747){
    234c:	b9403be0 	ldr	w0, [sp, #56]
    2350:	710bac1f 	cmp	w0, #0x2eb
    2354:	54000080 	b.eq	2364 <copyinstr2+0x194>  // b.none
    printf("exec(echo, BIG) succeeded, should have failed\n");
    2358:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    235c:	91374800 	add	x0, x0, #0xdd2
    2360:	17ffffd8 	b	22c0 <copyinstr2+0xf0>
}
    2364:	a8ce7bfd 	ldp	x29, x30, [sp], #224
    2368:	d65f03c0 	ret

000000000000236c <truncate3>:
{
    236c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
    2370:	5280c021 	mov	w1, #0x601                 	// #1537
{
    2374:	910003fd 	mov	x29, sp
    2378:	a90153f3 	stp	x19, x20, [sp, #16]
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
    237c:	f0000013 	adrp	x19, 5000 <bigfile+0x108>
    2380:	91215a73 	add	x19, x19, #0x856
{
    2384:	aa0003f4 	mov	x20, x0
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
    2388:	aa1303e0 	mov	x0, x19
{
    238c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2390:	f9001bf7 	str	x23, [sp, #48]
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
    2394:	97fffc4f 	bl	14d0 <open@plt>
    2398:	97fffc56 	bl	14f0 <close@plt>
  pid = fork();
    239c:	97fffc35 	bl	1470 <fork@plt>
  if(pid < 0){
    23a0:	36f800e0 	tbz	w0, #31, 23bc <truncate3+0x50>
    printf("%s: fork failed\n", s);
    23a4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    23a8:	91380400 	add	x0, x0, #0xe01
        printf("%s: open failed\n", s);
    23ac:	aa1403e1 	mov	x1, x20
    23b0:	97fffbfc 	bl	13a0 <printf@plt>
        exit(1);
    23b4:	52800020 	mov	w0, #0x1                   	// #1
    23b8:	97fffc42 	bl	14c0 <exit@plt>
  if(pid == 0){
    23bc:	350004c0 	cbnz	w0, 2454 <truncate3+0xe8>
      int n = write(fd, "1234567890", 10);
    23c0:	f0000016 	adrp	x22, 5000 <bigfile+0x108>
    23c4:	91388ed6 	add	x22, x22, #0xe23
  if(pid == 0){
    23c8:	52800c95 	mov	w21, #0x64                  	// #100
      int fd = open("truncfile", O_WRONLY);
    23cc:	aa1303e0 	mov	x0, x19
    23d0:	52800021 	mov	w1, #0x1                   	// #1
    23d4:	97fffc3f 	bl	14d0 <open@plt>
    23d8:	2a0003f7 	mov	w23, w0
      if(fd < 0){
    23dc:	36f80080 	tbz	w0, #31, 23ec <truncate3+0x80>
        printf("%s: open failed\n", s);
    23e0:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    23e4:	91384800 	add	x0, x0, #0xe12
    23e8:	17fffff1 	b	23ac <truncate3+0x40>
      int n = write(fd, "1234567890", 10);
    23ec:	52800142 	mov	w2, #0xa                   	// #10
    23f0:	aa1603e1 	mov	x1, x22
    23f4:	97fffbff 	bl	13f0 <write@plt>
    23f8:	2a0003e2 	mov	w2, w0
      if(n != 10){
    23fc:	7100281f 	cmp	w0, #0xa
    2400:	540000c0 	b.eq	2418 <truncate3+0xac>  // b.none
        printf("%s: write got %d, expected 10\n", s, n);
    2404:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2408:	9138b800 	add	x0, x0, #0xe2e
      printf("%s: write got %d, expected 3\n", s, n);
    240c:	aa1403e1 	mov	x1, x20
    2410:	97fffbe4 	bl	13a0 <printf@plt>
      exit(1);
    2414:	17ffffe8 	b	23b4 <truncate3+0x48>
      close(fd);
    2418:	2a1703e0 	mov	w0, w23
    241c:	97fffc35 	bl	14f0 <close@plt>
      fd = open("truncfile", O_RDONLY);
    2420:	52800001 	mov	w1, #0x0                   	// #0
    2424:	aa1303e0 	mov	x0, x19
    2428:	97fffc2a 	bl	14d0 <open@plt>
    242c:	2a0003f7 	mov	w23, w0
      read(fd, buf, sizeof(buf));
    2430:	910103e1 	add	x1, sp, #0x40
    2434:	52800402 	mov	w2, #0x20                  	// #32
    2438:	97fffc06 	bl	1450 <read@plt>
      close(fd);
    243c:	2a1703e0 	mov	w0, w23
    2440:	97fffc2c 	bl	14f0 <close@plt>
    for(int i = 0; i < 100; i++){
    2444:	710006b5 	subs	w21, w21, #0x1
    2448:	54fffc21 	b.ne	23cc <truncate3+0x60>  // b.any
    exit(0);
    244c:	52800000 	mov	w0, #0x0                   	// #0
    2450:	17ffffda 	b	23b8 <truncate3+0x4c>
    int n = write(fd, "xxx", 3);
    2454:	f0000016 	adrp	x22, 5000 <bigfile+0x108>
    2458:	913936d6 	add	x22, x22, #0xe4d
  if(pid == 0){
    245c:	528012d5 	mov	w21, #0x96                  	// #150
    int fd = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    2460:	aa1303e0 	mov	x0, x19
    2464:	5280c021 	mov	w1, #0x601                 	// #1537
    2468:	97fffc1a 	bl	14d0 <open@plt>
    246c:	2a0003f7 	mov	w23, w0
    if(fd < 0){
    2470:	37fffb80 	tbnz	w0, #31, 23e0 <truncate3+0x74>
    int n = write(fd, "xxx", 3);
    2474:	52800062 	mov	w2, #0x3                   	// #3
    2478:	aa1603e1 	mov	x1, x22
    247c:	97fffbdd 	bl	13f0 <write@plt>
    2480:	2a0003e2 	mov	w2, w0
    if(n != 3){
    2484:	71000c1f 	cmp	w0, #0x3
    2488:	54000080 	b.eq	2498 <truncate3+0x12c>  // b.none
      printf("%s: write got %d, expected 3\n", s, n);
    248c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2490:	91394400 	add	x0, x0, #0xe51
    2494:	17ffffde 	b	240c <truncate3+0xa0>
    close(fd);
    2498:	2a1703e0 	mov	w0, w23
    249c:	97fffc15 	bl	14f0 <close@plt>
  for(int i = 0; i < 150; i++){
    24a0:	710006b5 	subs	w21, w21, #0x1
    24a4:	54fffde1 	b.ne	2460 <truncate3+0xf4>  // b.any
  wait(&xstatus);
    24a8:	910103e0 	add	x0, sp, #0x40
    24ac:	97fffbe5 	bl	1440 <wait@plt>
  unlink("truncfile");
    24b0:	aa1303e0 	mov	x0, x19
    24b4:	97fffbeb 	bl	1460 <unlink@plt>
  exit(xstatus);
    24b8:	b94043e0 	ldr	w0, [sp, #64]
    24bc:	17ffffbf 	b	23b8 <truncate3+0x4c>

00000000000024c0 <exectest>:
{
    24c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    24c4:	910003fd 	mov	x29, sp
    24c8:	a90153f3 	stp	x19, x20, [sp, #16]
    24cc:	aa0003f3 	mov	x19, x0
  char *echoargv[] = { "echo", "OK", 0 };
    24d0:	b0000020 	adrp	x0, 7000 <run+0x1858>
    24d4:	91184000 	add	x0, x0, #0x610
  unlink("echo-ok");
    24d8:	f0000014 	adrp	x20, 5000 <bigfile+0x108>
    24dc:	9139be94 	add	x20, x20, #0xe6f
{
    24e0:	a9025bf5 	stp	x21, x22, [sp, #32]
  char *echoargv[] = { "echo", "OK", 0 };
    24e4:	a9420c02 	ldp	x2, x3, [x0, #32]
    24e8:	a9038fe2 	stp	x2, x3, [sp, #56]
    24ec:	f9401800 	ldr	x0, [x0, #48]
    24f0:	f90027e0 	str	x0, [sp, #72]
  unlink("echo-ok");
    24f4:	aa1403e0 	mov	x0, x20
    24f8:	97fffbda 	bl	1460 <unlink@plt>
  pid = fork();
    24fc:	97fffbdd 	bl	1470 <fork@plt>
  if(pid < 0) {
    2500:	36f800e0 	tbz	w0, #31, 251c <exectest+0x5c>
     printf("%s: fork failed\n", s);
    2504:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2508:	91380400 	add	x0, x0, #0xe01
      printf("%s: create failed\n", s);
    250c:	aa1303e1 	mov	x1, x19
    2510:	97fffba4 	bl	13a0 <printf@plt>
      exit(1);
    2514:	52800020 	mov	w0, #0x1                   	// #1
    2518:	97fffbea 	bl	14c0 <exit@plt>
    251c:	2a0003f5 	mov	w21, w0
  if(pid == 0) {
    2520:	350002e0 	cbnz	w0, 257c <exectest+0xbc>
    close(1);
    2524:	52800020 	mov	w0, #0x1                   	// #1
    2528:	97fffbf2 	bl	14f0 <close@plt>
    fd = open("echo-ok", O_CREATE|O_WRONLY);
    252c:	aa1403e0 	mov	x0, x20
    2530:	52804021 	mov	w1, #0x201                 	// #513
    2534:	97fffbe7 	bl	14d0 <open@plt>
    if(fd < 0) {
    2538:	36f80080 	tbz	w0, #31, 2548 <exectest+0x88>
      printf("%s: create failed\n", s);
    253c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2540:	9139dc00 	add	x0, x0, #0xe77
    2544:	17fffff2 	b	250c <exectest+0x4c>
    if(fd != 1) {
    2548:	7100041f 	cmp	w0, #0x1
    254c:	54000080 	b.eq	255c <exectest+0x9c>  // b.none
      printf("%s: wrong fd\n", s);
    2550:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2554:	913a2800 	add	x0, x0, #0xe8a
    2558:	17ffffed 	b	250c <exectest+0x4c>
    if(exec("/bin/echo", echoargv) < 0){
    255c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2560:	91349400 	add	x0, x0, #0xd25
    2564:	9100e3e1 	add	x1, sp, #0x38
    2568:	97fffbb2 	bl	1430 <exec@plt>
    256c:	36f80080 	tbz	w0, #31, 257c <exectest+0xbc>
      printf("%s: exec echo failed\n", s);
    2570:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2574:	913a6000 	add	x0, x0, #0xe98
    2578:	17ffffe5 	b	250c <exectest+0x4c>
  if (wait(&xstatus) != pid) {
    257c:	9100d3e0 	add	x0, sp, #0x34
    2580:	97fffbb0 	bl	1440 <wait@plt>
    2584:	6b15001f 	cmp	w0, w21
    2588:	540000a0 	b.eq	259c <exectest+0xdc>  // b.none
    printf("%s: wait failed!\n", s);
    258c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2590:	913ab800 	add	x0, x0, #0xeae
    2594:	aa1303e1 	mov	x1, x19
    2598:	97fffb82 	bl	13a0 <printf@plt>
  if(xstatus != 0)
    259c:	b94037e0 	ldr	w0, [sp, #52]
    25a0:	35fffbc0 	cbnz	w0, 2518 <exectest+0x58>
  fd = open("echo-ok", O_RDONLY);
    25a4:	aa1403e0 	mov	x0, x20
    25a8:	52800001 	mov	w1, #0x0                   	// #0
    25ac:	97fffbc9 	bl	14d0 <open@plt>
  if(fd < 0) {
    25b0:	36f80080 	tbz	w0, #31, 25c0 <exectest+0x100>
    printf("%s: open failed\n", s);
    25b4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    25b8:	91384800 	add	x0, x0, #0xe12
    25bc:	17ffffd4 	b	250c <exectest+0x4c>
  if (read(fd, buf, 2) != 2) {
    25c0:	9100c3e1 	add	x1, sp, #0x30
    25c4:	52800042 	mov	w2, #0x2                   	// #2
    25c8:	97fffba2 	bl	1450 <read@plt>
    25cc:	7100081f 	cmp	w0, #0x2
    25d0:	54000080 	b.eq	25e0 <exectest+0x120>  // b.none
    printf("%s: read failed\n", s);
    25d4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    25d8:	912cc400 	add	x0, x0, #0xb31
    25dc:	17ffffcc 	b	250c <exectest+0x4c>
  unlink("echo-ok");
    25e0:	aa1403e0 	mov	x0, x20
    25e4:	97fffb9f 	bl	1460 <unlink@plt>
  if(buf[0] == 'O' && buf[1] == 'K')
    25e8:	3940c3e0 	ldrb	w0, [sp, #48]
    25ec:	71013c1f 	cmp	w0, #0x4f
    25f0:	540000c1 	b.ne	2608 <exectest+0x148>  // b.any
    25f4:	3940c7e0 	ldrb	w0, [sp, #49]
    25f8:	71012c1f 	cmp	w0, #0x4b
    25fc:	54000061 	b.ne	2608 <exectest+0x148>  // b.any
    exit(0);
    2600:	52800000 	mov	w0, #0x0                   	// #0
    2604:	17ffffc5 	b	2518 <exectest+0x58>
    printf("%s: wrong output\n", s);
    2608:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    260c:	913b0000 	add	x0, x0, #0xec0
    2610:	17ffffbf 	b	250c <exectest+0x4c>

0000000000002614 <pipe1>:
{
    2614:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2618:	910003fd 	mov	x29, sp
    261c:	a90153f3 	stp	x19, x20, [sp, #16]
    2620:	a9025bf5 	stp	x21, x22, [sp, #32]
    2624:	aa0003f6 	mov	x22, x0
  if(pipe(fds) != 0){
    2628:	910123e0 	add	x0, sp, #0x48
{
    262c:	f9001bf7 	str	x23, [sp, #48]
  if(pipe(fds) != 0){
    2630:	97fffb6c 	bl	13e0 <pipe@plt>
    2634:	340000e0 	cbz	w0, 2650 <pipe1+0x3c>
    printf("%s: pipe() failed\n", s);
    2638:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    263c:	913b4800 	add	x0, x0, #0xed2
        printf("%s: pipe1 oops 1\n", s);
    2640:	aa1603e1 	mov	x1, x22
    2644:	97fffb57 	bl	13a0 <printf@plt>
        exit(1);
    2648:	52800020 	mov	w0, #0x1                   	// #1
    264c:	97fffb9d 	bl	14c0 <exit@plt>
    2650:	2a0003f3 	mov	w19, w0
  pid = fork();
    2654:	b0000055 	adrp	x21, b000 <uninit+0x1cc7>
    2658:	912926b5 	add	x21, x21, #0xa49
    265c:	97fffb85 	bl	1470 <fork@plt>
    2660:	2a0003f4 	mov	w20, w0
  if(pid == 0){
    2664:	7100001f 	cmp	w0, #0x0
    2668:	350002e0 	cbnz	w0, 26c4 <pipe1+0xb0>
    close(fds[0]);
    266c:	b9404be0 	ldr	w0, [sp, #72]
    for(n = 0; n < N; n++){
    2670:	528285b3 	mov	w19, #0x142d                	// #5165
    close(fds[0]);
    2674:	97fffb9f 	bl	14f0 <close@plt>
{
    2678:	d2800002 	mov	x2, #0x0                   	// #0
        buf[i] = seq++;
    267c:	0b020280 	add	w0, w20, w2
    2680:	38226aa0 	strb	w0, [x21, x2]
      for(i = 0; i < SZ; i++)
    2684:	91000442 	add	x2, x2, #0x1
    2688:	f110245f 	cmp	x2, #0x409
    268c:	54ffff81 	b.ne	267c <pipe1+0x68>  // b.any
      if(write(fds[1], buf, SZ) != SZ){
    2690:	b9404fe0 	ldr	w0, [sp, #76]
    2694:	aa1503e1 	mov	x1, x21
    2698:	97fffb56 	bl	13f0 <write@plt>
    269c:	7110241f 	cmp	w0, #0x409
    26a0:	54000080 	b.eq	26b0 <pipe1+0x9c>  // b.none
        printf("%s: pipe1 oops 1\n", s);
    26a4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    26a8:	913b9400 	add	x0, x0, #0xee5
    26ac:	17ffffe5 	b	2640 <pipe1+0x2c>
    26b0:	11102694 	add	w20, w20, #0x409
    for(n = 0; n < N; n++){
    26b4:	6b13029f 	cmp	w20, w19
    26b8:	54fffe01 	b.ne	2678 <pipe1+0x64>  // b.any
    exit(0);
    26bc:	52800000 	mov	w0, #0x0                   	// #0
    26c0:	17ffffe3 	b	264c <pipe1+0x38>
  } else if(pid > 0){
    26c4:	5400062d 	b.le	2788 <pipe1+0x174>
    close(fds[1]);
    26c8:	b9404fe0 	ldr	w0, [sp, #76]
    total = 0;
    26cc:	52800017 	mov	w23, #0x0                   	// #0
    cc = 1;
    26d0:	52800034 	mov	w20, #0x1                   	// #1
    close(fds[1]);
    26d4:	97fffb87 	bl	14f0 <close@plt>
    while((n = read(fds[0], buf, cc)) > 0){
    26d8:	b9404be0 	ldr	w0, [sp, #72]
    26dc:	2a1403e2 	mov	w2, w20
    26e0:	aa1503e1 	mov	x1, x21
    26e4:	97fffb5b 	bl	1450 <read@plt>
    26e8:	7100001f 	cmp	w0, #0x0
    26ec:	5400012c 	b.gt	2710 <pipe1+0xfc>
    if(total != N * SZ){
    26f0:	528285a0 	mov	w0, #0x142d                	// #5165
    26f4:	6b0002ff 	cmp	w23, w0
    26f8:	540003c0 	b.eq	2770 <pipe1+0x15c>  // b.none
      printf("%s: pipe1 oops 3 total %d\n", total);
    26fc:	2a1703e1 	mov	w1, w23
    2700:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2704:	913c2400 	add	x0, x0, #0xf09
    2708:	97fffb26 	bl	13a0 <printf@plt>
      exit(1);
    270c:	17ffffcf 	b	2648 <pipe1+0x34>
    2710:	aa1503e1 	mov	x1, x21
    2714:	0b000262 	add	w2, w19, w0
        if((buf[i] & 0xff) != (seq++ & 0xff)){
    2718:	39400023 	ldrb	w3, [x1]
    271c:	6b33007f 	cmp	w3, w19, uxtb
    2720:	54000140 	b.eq	2748 <pipe1+0x134>  // b.none
          printf("%s: pipe1 oops 2\n", s);
    2724:	aa1603e1 	mov	x1, x22
    2728:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    272c:	913bdc00 	add	x0, x0, #0xef7
    2730:	97fffb1c 	bl	13a0 <printf@plt>
}
    2734:	f9401bf7 	ldr	x23, [sp, #48]
    2738:	a94153f3 	ldp	x19, x20, [sp, #16]
    273c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2740:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2744:	d65f03c0 	ret
        if((buf[i] & 0xff) != (seq++ & 0xff)){
    2748:	11000673 	add	w19, w19, #0x1
      for(i = 0; i < n; i++){
    274c:	91000421 	add	x1, x1, #0x1
    2750:	6b02027f 	cmp	w19, w2
    2754:	54fffe21 	b.ne	2718 <pipe1+0x104>  // b.any
      cc = cc * 2;
    2758:	531f7a94 	lsl	w20, w20, #1
      total += n;
    275c:	0b0002f7 	add	w23, w23, w0
      if(cc > sizeof(buf))
    2760:	71400e9f 	cmp	w20, #0x3, lsl #12
    2764:	52860000 	mov	w0, #0x3000                	// #12288
    2768:	1a80d294 	csel	w20, w20, w0, le
    276c:	17ffffdb 	b	26d8 <pipe1+0xc4>
    close(fds[0]);
    2770:	b9404be0 	ldr	w0, [sp, #72]
    2774:	97fffb5f 	bl	14f0 <close@plt>
    wait(&xstatus);
    2778:	910113e0 	add	x0, sp, #0x44
    277c:	97fffb31 	bl	1440 <wait@plt>
    exit(xstatus);
    2780:	b94047e0 	ldr	w0, [sp, #68]
    2784:	17ffffb2 	b	264c <pipe1+0x38>
    printf("%s: fork() failed\n", s);
    2788:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    278c:	913c9000 	add	x0, x0, #0xf24
    2790:	17ffffac 	b	2640 <pipe1+0x2c>

0000000000002794 <exitwait>:
{
    2794:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2798:	910003fd 	mov	x29, sp
    279c:	a90153f3 	stp	x19, x20, [sp, #16]
    27a0:	aa0003f4 	mov	x20, x0
  for(i = 0; i < 100; i++){
    27a4:	52800013 	mov	w19, #0x0                   	// #0
{
    27a8:	f90013f5 	str	x21, [sp, #32]
    pid = fork();
    27ac:	97fffb31 	bl	1470 <fork@plt>
    27b0:	2a0003f5 	mov	w21, w0
    if(pid < 0){
    27b4:	36f800e0 	tbz	w0, #31, 27d0 <exitwait+0x3c>
      printf("%s: fork failed\n", s);
    27b8:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    27bc:	91380400 	add	x0, x0, #0xe01
        printf("%s: wait wrong pid\n", s);
    27c0:	aa1403e1 	mov	x1, x20
    27c4:	97fffaf7 	bl	13a0 <printf@plt>
        exit(1);
    27c8:	52800020 	mov	w0, #0x1                   	// #1
    27cc:	97fffb3d 	bl	14c0 <exit@plt>
    if(pid){
    27d0:	340002a0 	cbz	w0, 2824 <exitwait+0x90>
      if(wait(&xstate) != pid){
    27d4:	9100f3e0 	add	x0, sp, #0x3c
    27d8:	97fffb1a 	bl	1440 <wait@plt>
    27dc:	6b15001f 	cmp	w0, w21
    27e0:	54000080 	b.eq	27f0 <exitwait+0x5c>  // b.none
        printf("%s: wait wrong pid\n", s);
    27e4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    27e8:	913cdc00 	add	x0, x0, #0xf37
    27ec:	17fffff5 	b	27c0 <exitwait+0x2c>
      if(i != xstate) {
    27f0:	b9403fe0 	ldr	w0, [sp, #60]
    27f4:	6b13001f 	cmp	w0, w19
    27f8:	54000080 	b.eq	2808 <exitwait+0x74>  // b.none
        printf("%s: wait wrong exit status\n", s);
    27fc:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2800:	913d2c00 	add	x0, x0, #0xf4b
    2804:	17ffffef 	b	27c0 <exitwait+0x2c>
  for(i = 0; i < 100; i++){
    2808:	11000673 	add	w19, w19, #0x1
    280c:	7101927f 	cmp	w19, #0x64
    2810:	54fffce1 	b.ne	27ac <exitwait+0x18>  // b.any
}
    2814:	f94013f5 	ldr	x21, [sp, #32]
    2818:	a94153f3 	ldp	x19, x20, [sp, #16]
    281c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2820:	d65f03c0 	ret
      exit(i);
    2824:	2a1303e0 	mov	w0, w19
    2828:	17ffffe9 	b	27cc <exitwait+0x38>

000000000000282c <twochildren>:
{
    282c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2830:	910003fd 	mov	x29, sp
    2834:	a90153f3 	stp	x19, x20, [sp, #16]
    2838:	aa0003f4 	mov	x20, x0
    283c:	52807d13 	mov	w19, #0x3e8                 	// #1000
    int pid1 = fork();
    2840:	97fffb0c 	bl	1470 <fork@plt>
    if(pid1 < 0){
    2844:	36f800e0 	tbz	w0, #31, 2860 <twochildren+0x34>
      printf("%s: fork failed\n", s);
    2848:	aa1403e1 	mov	x1, x20
    284c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2850:	91380400 	add	x0, x0, #0xe01
    2854:	97fffad3 	bl	13a0 <printf@plt>
      exit(1);
    2858:	52800020 	mov	w0, #0x1                   	// #1
      exit(0);
    285c:	97fffb19 	bl	14c0 <exit@plt>
    if(pid1 == 0){
    2860:	35000060 	cbnz	w0, 286c <twochildren+0x40>
      exit(0);
    2864:	52800000 	mov	w0, #0x0                   	// #0
    2868:	17fffffd 	b	285c <twochildren+0x30>
      int pid2 = fork();
    286c:	97fffb01 	bl	1470 <fork@plt>
      if(pid2 < 0){
    2870:	37fffec0 	tbnz	w0, #31, 2848 <twochildren+0x1c>
      if(pid2 == 0){
    2874:	34ffff80 	cbz	w0, 2864 <twochildren+0x38>
        wait(0);
    2878:	d2800000 	mov	x0, #0x0                   	// #0
    287c:	97fffaf1 	bl	1440 <wait@plt>
        wait(0);
    2880:	d2800000 	mov	x0, #0x0                   	// #0
    2884:	97fffaef 	bl	1440 <wait@plt>
  for(int i = 0; i < 1000; i++){
    2888:	71000673 	subs	w19, w19, #0x1
    288c:	54fffda1 	b.ne	2840 <twochildren+0x14>  // b.any
}
    2890:	a94153f3 	ldp	x19, x20, [sp, #16]
    2894:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2898:	d65f03c0 	ret

000000000000289c <forkfork>:
{
    289c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    28a0:	910003fd 	mov	x29, sp
    28a4:	f9000bf3 	str	x19, [sp, #16]
    28a8:	aa0003f3 	mov	x19, x0
    int pid = fork();
    28ac:	97fffaf1 	bl	1470 <fork@plt>
    if(pid < 0){
    28b0:	37f80180 	tbnz	w0, #31, 28e0 <forkfork+0x44>
    if(pid == 0){
    28b4:	34000200 	cbz	w0, 28f4 <forkfork+0x58>
    int pid = fork();
    28b8:	97fffaee 	bl	1470 <fork@plt>
    if(pid < 0){
    28bc:	37f80120 	tbnz	w0, #31, 28e0 <forkfork+0x44>
    if(pid == 0){
    28c0:	340001a0 	cbz	w0, 28f4 <forkfork+0x58>
    wait(&xstatus);
    28c4:	9100b3e0 	add	x0, sp, #0x2c
    28c8:	97fffade 	bl	1440 <wait@plt>
    if(xstatus != 0) {
    28cc:	b9402fe0 	ldr	w0, [sp, #44]
    28d0:	340002c0 	cbz	w0, 2928 <forkfork+0x8c>
      printf("%s: fork in child failed", s);
    28d4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    28d8:	913ddc00 	add	x0, x0, #0xf77
    28dc:	14000003 	b	28e8 <forkfork+0x4c>
      printf("%s: fork failed", s);
    28e0:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    28e4:	913d9c00 	add	x0, x0, #0xf67
      printf("%s: fork in child failed", s);
    28e8:	aa1303e1 	mov	x1, x19
    28ec:	97fffaad 	bl	13a0 <printf@plt>
    28f0:	14000004 	b	2900 <forkfork+0x64>
{
    28f4:	52801913 	mov	w19, #0xc8                  	// #200
        int pid1 = fork();
    28f8:	97fffade 	bl	1470 <fork@plt>
        if(pid1 < 0){
    28fc:	36f80060 	tbz	w0, #31, 2908 <forkfork+0x6c>
      exit(1);
    2900:	52800020 	mov	w0, #0x1                   	// #1
    2904:	14000003 	b	2910 <forkfork+0x74>
        if(pid1 == 0){
    2908:	35000060 	cbnz	w0, 2914 <forkfork+0x78>
          exit(0);
    290c:	52800000 	mov	w0, #0x0                   	// #0
      exit(1);
    2910:	97fffaec 	bl	14c0 <exit@plt>
        wait(0);
    2914:	d2800000 	mov	x0, #0x0                   	// #0
    2918:	97fffaca 	bl	1440 <wait@plt>
      for(int j = 0; j < 200; j++){
    291c:	71000673 	subs	w19, w19, #0x1
    2920:	54fffec1 	b.ne	28f8 <forkfork+0x5c>  // b.any
    2924:	17fffffa 	b	290c <forkfork+0x70>
    wait(&xstatus);
    2928:	9100b3e0 	add	x0, sp, #0x2c
    292c:	97fffac5 	bl	1440 <wait@plt>
    if(xstatus != 0) {
    2930:	b9402fe0 	ldr	w0, [sp, #44]
    2934:	35fffd00 	cbnz	w0, 28d4 <forkfork+0x38>
}
    2938:	f9400bf3 	ldr	x19, [sp, #16]
    293c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2940:	d65f03c0 	ret

0000000000002944 <reparent2>:
{
    2944:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2948:	910003fd 	mov	x29, sp
    294c:	f9000bf3 	str	x19, [sp, #16]
    2950:	52806413 	mov	w19, #0x320                 	// #800
    int pid1 = fork();
    2954:	97fffac7 	bl	1470 <fork@plt>
    if(pid1 < 0){
    2958:	36f800c0 	tbz	w0, #31, 2970 <reparent2+0x2c>
      printf("fork failed\n");
    295c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2960:	91381400 	add	x0, x0, #0xe05
    2964:	97fffa8f 	bl	13a0 <printf@plt>
      exit(1);
    2968:	52800020 	mov	w0, #0x1                   	// #1
      exit(0);
    296c:	97fffad5 	bl	14c0 <exit@plt>
    if(pid1 == 0){
    2970:	350000a0 	cbnz	w0, 2984 <reparent2+0x40>
      fork();
    2974:	97fffabf 	bl	1470 <fork@plt>
      fork();
    2978:	97fffabe 	bl	1470 <fork@plt>
      exit(0);
    297c:	52800000 	mov	w0, #0x0                   	// #0
    2980:	17fffffb 	b	296c <reparent2+0x28>
    wait(0);
    2984:	d2800000 	mov	x0, #0x0                   	// #0
    2988:	97fffaae 	bl	1440 <wait@plt>
  for(int i = 0; i < 800; i++){
    298c:	71000673 	subs	w19, w19, #0x1
    2990:	54fffe21 	b.ne	2954 <reparent2+0x10>  // b.any
    2994:	17fffffa 	b	297c <reparent2+0x38>

0000000000002998 <createdelete>:
{
    2998:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    299c:	910003fd 	mov	x29, sp
    29a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    29a4:	aa0003f5 	mov	x21, x0
    29a8:	a90153f3 	stp	x19, x20, [sp, #16]
  for(pi = 0; pi < NCHILD; pi++){
    29ac:	52800014 	mov	w20, #0x0                   	// #0
{
    29b0:	f9001bf7 	str	x23, [sp, #48]
    pid = fork();
    29b4:	97fffaaf 	bl	1470 <fork@plt>
    29b8:	2a0003f3 	mov	w19, w0
    if(pid < 0){
    29bc:	36f800e0 	tbz	w0, #31, 29d8 <createdelete+0x40>
      printf("fork failed\n", s);
    29c0:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    29c4:	91381400 	add	x0, x0, #0xe05
          printf("%s: create failed\n", s);
    29c8:	aa1503e1 	mov	x1, x21
    29cc:	97fffa75 	bl	13a0 <printf@plt>
          exit(1);
    29d0:	52800020 	mov	w0, #0x1                   	// #1
    29d4:	97fffabb 	bl	14c0 <exit@plt>
    if(pid == 0){
    29d8:	35000460 	cbnz	w0, 2a64 <createdelete+0xcc>
      name[0] = 'p' + pi;
    29dc:	1101c294 	add	w20, w20, #0x70
    29e0:	390143f4 	strb	w20, [sp, #80]
      name[2] = '\0';
    29e4:	39014bff 	strb	wzr, [sp, #82]
        name[1] = '0' + i;
    29e8:	1100c260 	add	w0, w19, #0x30
        fd = open(name, O_CREATE | O_RDWR);
    29ec:	52804041 	mov	w1, #0x202                 	// #514
        name[1] = '0' + i;
    29f0:	390147e0 	strb	w0, [sp, #81]
        fd = open(name, O_CREATE | O_RDWR);
    29f4:	910143e0 	add	x0, sp, #0x50
    29f8:	97fffab6 	bl	14d0 <open@plt>
        if(fd < 0){
    29fc:	36f80080 	tbz	w0, #31, 2a0c <createdelete+0x74>
          printf("%s: create failed\n", s);
    2a00:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2a04:	9139dc00 	add	x0, x0, #0xe77
    2a08:	17fffff0 	b	29c8 <createdelete+0x30>
        close(fd);
    2a0c:	97fffab9 	bl	14f0 <close@plt>
        if(i > 0 && (i % 2 ) == 0){
    2a10:	34000273 	cbz	w19, 2a5c <createdelete+0xc4>
    2a14:	11000674 	add	w20, w19, #0x1
    2a18:	37000193 	tbnz	w19, #0, 2a48 <createdelete+0xb0>
          name[1] = '0' + (i / 2);
    2a1c:	13017e73 	asr	w19, w19, #1
          if(unlink(name) < 0){
    2a20:	910143e0 	add	x0, sp, #0x50
          name[1] = '0' + (i / 2);
    2a24:	1100c273 	add	w19, w19, #0x30
    2a28:	390147f3 	strb	w19, [sp, #81]
          if(unlink(name) < 0){
    2a2c:	97fffa8d 	bl	1460 <unlink@plt>
    2a30:	36f80080 	tbz	w0, #31, 2a40 <createdelete+0xa8>
            printf("%s: unlink failed\n", s);
    2a34:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2a38:	913e4000 	add	x0, x0, #0xf90
    2a3c:	17ffffe3 	b	29c8 <createdelete+0x30>
      for(i = 0; i < N; i++){
    2a40:	2a1403f3 	mov	w19, w20
    2a44:	17ffffe9 	b	29e8 <createdelete+0x50>
    2a48:	2a1403f3 	mov	w19, w20
    2a4c:	7100529f 	cmp	w20, #0x14
    2a50:	54fffcc1 	b.ne	29e8 <createdelete+0x50>  // b.any
      exit(0);
    2a54:	52800000 	mov	w0, #0x0                   	// #0
    2a58:	17ffffdf 	b	29d4 <createdelete+0x3c>
      for(i = 0; i < N; i++){
    2a5c:	52800033 	mov	w19, #0x1                   	// #1
    2a60:	17ffffe2 	b	29e8 <createdelete+0x50>
  for(pi = 0; pi < NCHILD; pi++){
    2a64:	11000694 	add	w20, w20, #0x1
    2a68:	7100129f 	cmp	w20, #0x4
    2a6c:	54fffa41 	b.ne	29b4 <createdelete+0x1c>  // b.any
    wait(&xstatus);
    2a70:	910133e0 	add	x0, sp, #0x4c
    2a74:	97fffa73 	bl	1440 <wait@plt>
    if(xstatus != 0)
    2a78:	b9404ff3 	ldr	w19, [sp, #76]
    2a7c:	35fffab3 	cbnz	w19, 29d0 <createdelete+0x38>
  for(pi = 0; pi < NCHILD; pi++){
    2a80:	71000694 	subs	w20, w20, #0x1
    2a84:	54ffff61 	b.ne	2a70 <createdelete+0xd8>  // b.any
  name[0] = name[1] = name[2] = 0;
    2a88:	39014bff 	strb	wzr, [sp, #82]
      if((i == 0 || i >= N/2) && fd < 0){
    2a8c:	7100027f 	cmp	w19, #0x0
      name[1] = '0' + i;
    2a90:	1100c277 	add	w23, w19, #0x30
      if((i == 0 || i >= N/2) && fd < 0){
    2a94:	7a491a60 	ccmp	w19, #0x9, #0x0, ne	// ne = any
    2a98:	52800e14 	mov	w20, #0x70                  	// #112
    2a9c:	1a9fd7f6 	cset	w22, gt
      fd = open(name, 0);
    2aa0:	910143e0 	add	x0, sp, #0x50
    2aa4:	52800001 	mov	w1, #0x0                   	// #0
      name[0] = 'p' + pi;
    2aa8:	390143f4 	strb	w20, [sp, #80]
      name[1] = '0' + i;
    2aac:	390147f7 	strb	w23, [sp, #81]
      fd = open(name, 0);
    2ab0:	97fffa88 	bl	14d0 <open@plt>
      if((i == 0 || i >= N/2) && fd < 0){
    2ab4:	34000116 	cbz	w22, 2ad4 <createdelete+0x13c>
    2ab8:	36f80160 	tbz	w0, #31, 2ae4 <createdelete+0x14c>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    2abc:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2ac0:	913e8c00 	add	x0, x0, #0xfa3
        printf("%s: oops createdelete %s did exist\n", s, name);
    2ac4:	910143e2 	add	x2, sp, #0x50
    2ac8:	aa1503e1 	mov	x1, x21
    2acc:	97fffa35 	bl	13a0 <printf@plt>
        exit(1);
    2ad0:	17ffffc0 	b	29d0 <createdelete+0x38>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    2ad4:	37f800a0 	tbnz	w0, #31, 2ae8 <createdelete+0x150>
        printf("%s: oops createdelete %s did exist\n", s, name);
    2ad8:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2adc:	913f2800 	add	x0, x0, #0xfca
    2ae0:	17fffff9 	b	2ac4 <createdelete+0x12c>
        close(fd);
    2ae4:	97fffa83 	bl	14f0 <close@plt>
    for(pi = 0; pi < NCHILD; pi++){
    2ae8:	11000694 	add	w20, w20, #0x1
    2aec:	12001e94 	and	w20, w20, #0xff
    2af0:	7101d29f 	cmp	w20, #0x74
    2af4:	54fffd61 	b.ne	2aa0 <createdelete+0x108>  // b.any
  for(i = 0; i < N; i++){
    2af8:	11000673 	add	w19, w19, #0x1
    2afc:	7100527f 	cmp	w19, #0x14
    2b00:	54fffc61 	b.ne	2a8c <createdelete+0xf4>  // b.any
    2b04:	52800e13 	mov	w19, #0x70                  	// #112
      name[1] = '0' + i;
    2b08:	51010275 	sub	w21, w19, #0x40
    2b0c:	52800094 	mov	w20, #0x4                   	// #4
      unlink(name);
    2b10:	910143e0 	add	x0, sp, #0x50
      name[0] = 'p' + i;
    2b14:	390143f3 	strb	w19, [sp, #80]
      name[1] = '0' + i;
    2b18:	390147f5 	strb	w21, [sp, #81]
      unlink(name);
    2b1c:	97fffa51 	bl	1460 <unlink@plt>
    for(pi = 0; pi < NCHILD; pi++){
    2b20:	71000694 	subs	w20, w20, #0x1
    2b24:	54ffff61 	b.ne	2b10 <createdelete+0x178>  // b.any
  for(i = 0; i < N; i++){
    2b28:	11000673 	add	w19, w19, #0x1
    2b2c:	12001e73 	and	w19, w19, #0xff
    2b30:	7102127f 	cmp	w19, #0x84
    2b34:	54fffea1 	b.ne	2b08 <createdelete+0x170>  // b.any
}
    2b38:	f9401bf7 	ldr	x23, [sp, #48]
    2b3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2b44:	a8c77bfd 	ldp	x29, x30, [sp], #112
    2b48:	d65f03c0 	ret

0000000000002b4c <linkunlink>:
{
    2b4c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2b50:	910003fd 	mov	x29, sp
    2b54:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("x");
    2b58:	90000034 	adrp	x20, 6000 <run+0x858>
    2b5c:	91275294 	add	x20, x20, #0x9d4
{
    2b60:	aa0003f3 	mov	x19, x0
  unlink("x");
    2b64:	aa1403e0 	mov	x0, x20
{
    2b68:	a9025bf5 	stp	x21, x22, [sp, #32]
    2b6c:	a90363f7 	stp	x23, x24, [sp, #48]
    2b70:	a9046bf9 	stp	x25, x26, [sp, #64]
  unlink("x");
    2b74:	97fffa3b 	bl	1460 <unlink@plt>
  pid = fork();
    2b78:	97fffa3e 	bl	1470 <fork@plt>
  if(pid < 0){
    2b7c:	36f800e0 	tbz	w0, #31, 2b98 <linkunlink+0x4c>
    printf("%s: fork failed\n", s);
    2b80:	aa1303e1 	mov	x1, x19
    2b84:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2b88:	91380400 	add	x0, x0, #0xe01
    2b8c:	97fffa05 	bl	13a0 <printf@plt>
    exit(1);
    2b90:	52800020 	mov	w0, #0x1                   	// #1
    exit(0);
    2b94:	97fffa4b 	bl	14c0 <exit@plt>
    2b98:	7100001f 	cmp	w0, #0x0
  unsigned int x = (pid ? 1 : 97);
    2b9c:	52800c33 	mov	w19, #0x61                  	// #97
      link("cat", "x");
    2ba0:	f0000017 	adrp	x23, 5000 <bigfile+0x108>
    2ba4:	913fbaf7 	add	x23, x23, #0xfee
    2ba8:	2a0003f5 	mov	w21, w0
  unsigned int x = (pid ? 1 : 97);
    2bac:	1a9f0673 	csinc	w19, w19, wzr, eq	// eq = none
    x = x * 1103515245 + 12345;
    2bb0:	5289cdb8 	mov	w24, #0x4e6d                	// #20077
    2bb4:	72a838d8 	movk	w24, #0x41c6, lsl #16
  unsigned int x = (pid ? 1 : 97);
    2bb8:	52800c96 	mov	w22, #0x64                  	// #100
    x = x * 1103515245 + 12345;
    2bbc:	52860739 	mov	w25, #0x3039                	// #12345
    if((x % 3) == 0){
    2bc0:	5280007a 	mov	w26, #0x3                   	// #3
    x = x * 1103515245 + 12345;
    2bc4:	1b186673 	madd	w19, w19, w24, w25
    if((x % 3) == 0){
    2bc8:	1ada0a62 	udiv	w2, w19, w26
    2bcc:	0b020442 	add	w2, w2, w2, lsl #1
    2bd0:	6b020262 	subs	w2, w19, w2
    2bd4:	540001e1 	b.ne	2c10 <linkunlink+0xc4>  // b.any
      close(open("x", O_RDWR | O_CREATE));
    2bd8:	52804041 	mov	w1, #0x202                 	// #514
    2bdc:	aa1403e0 	mov	x0, x20
    2be0:	97fffa3c 	bl	14d0 <open@plt>
    2be4:	97fffa43 	bl	14f0 <close@plt>
  for(i = 0; i < 100; i++){
    2be8:	710006d6 	subs	w22, w22, #0x1
    2bec:	54fffec1 	b.ne	2bc4 <linkunlink+0x78>  // b.any
  if(pid)
    2bf0:	34000235 	cbz	w21, 2c34 <linkunlink+0xe8>
}
    2bf4:	a94153f3 	ldp	x19, x20, [sp, #16]
    wait(0);
    2bf8:	d2800000 	mov	x0, #0x0                   	// #0
}
    2bfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2c00:	a94363f7 	ldp	x23, x24, [sp, #48]
    2c04:	a9446bf9 	ldp	x25, x26, [sp, #64]
    2c08:	a8c57bfd 	ldp	x29, x30, [sp], #80
    wait(0);
    2c0c:	17fffa0d 	b	1440 <wait@plt>
    } else if((x % 3) == 1){
    2c10:	7100045f 	cmp	w2, #0x1
    2c14:	540000a1 	b.ne	2c28 <linkunlink+0xdc>  // b.any
      link("cat", "x");
    2c18:	aa1403e1 	mov	x1, x20
    2c1c:	aa1703e0 	mov	x0, x23
    2c20:	97fffa24 	bl	14b0 <link@plt>
    2c24:	17fffff1 	b	2be8 <linkunlink+0x9c>
      unlink("x");
    2c28:	aa1403e0 	mov	x0, x20
    2c2c:	97fffa0d 	bl	1460 <unlink@plt>
    2c30:	17ffffee 	b	2be8 <linkunlink+0x9c>
    exit(0);
    2c34:	52800000 	mov	w0, #0x0                   	// #0
    2c38:	17ffffd7 	b	2b94 <linkunlink+0x48>

0000000000002c3c <manywrites>:
{
    2c3c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    2c40:	910003fd 	mov	x29, sp
    2c44:	a90363f7 	stp	x23, x24, [sp, #48]
    2c48:	aa0003f8 	mov	x24, x0
    2c4c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(int ci = 0; ci < nchildren; ci++){
    2c50:	52800013 	mov	w19, #0x0                   	// #0
{
    2c54:	a9025bf5 	stp	x21, x22, [sp, #32]
    2c58:	f90023f9 	str	x25, [sp, #64]
    int pid = fork();
    2c5c:	97fffa05 	bl	1470 <fork@plt>
    2c60:	2a0003f5 	mov	w21, w0
    if(pid < 0){
    2c64:	36f800c0 	tbz	w0, #31, 2c7c <manywrites+0x40>
      printf("fork failed\n");
    2c68:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2c6c:	91381400 	add	x0, x0, #0xe05
    2c70:	97fff9cc 	bl	13a0 <printf@plt>
            exit(1);
    2c74:	52800020 	mov	w0, #0x1                   	// #1
    2c78:	97fffa12 	bl	14c0 <exit@plt>
    if(pid == 0){
    2c7c:	35000600 	cbnz	w0, 2d3c <manywrites+0x100>
          int cc = write(fd, buf, sz);
    2c80:	b0000057 	adrp	x23, b000 <uninit+0x1cc7>
    2c84:	912926f7 	add	x23, x23, #0xa49
      name[0] = 'b';
    2c88:	52800c40 	mov	w0, #0x62                  	// #98
      unlink(name);
    2c8c:	528003d6 	mov	w22, #0x1e                  	// #30
      name[0] = 'b';
    2c90:	390163e0 	strb	w0, [sp, #88]
      name[1] = 'a' + ci;
    2c94:	11018660 	add	w0, w19, #0x61
    2c98:	390167e0 	strb	w0, [sp, #89]
      unlink(name);
    2c9c:	910163e0 	add	x0, sp, #0x58
      name[2] = '\0';
    2ca0:	39016bff 	strb	wzr, [sp, #90]
      unlink(name);
    2ca4:	97fff9ef 	bl	1460 <unlink@plt>
        for(int i = 0; i < ci+1; i++){
    2ca8:	2a1503f4 	mov	w20, w21
          int fd = open(name, O_CREATE | O_RDWR);
    2cac:	910163e0 	add	x0, sp, #0x58
    2cb0:	52804041 	mov	w1, #0x202                 	// #514
    2cb4:	97fffa07 	bl	14d0 <open@plt>
    2cb8:	2a0003f9 	mov	w25, w0
          if(fd < 0){
    2cbc:	36f800e0 	tbz	w0, #31, 2cd8 <manywrites+0x9c>
            printf("%s: cannot create %s\n", s, name);
    2cc0:	910163e2 	add	x2, sp, #0x58
    2cc4:	aa1803e1 	mov	x1, x24
    2cc8:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2ccc:	913fc800 	add	x0, x0, #0xff2
    2cd0:	97fff9b4 	bl	13a0 <printf@plt>
    2cd4:	17ffffe8 	b	2c74 <manywrites+0x38>
          int cc = write(fd, buf, sz);
    2cd8:	aa1703e1 	mov	x1, x23
    2cdc:	52860002 	mov	w2, #0x3000                	// #12288
    2ce0:	97fff9c4 	bl	13f0 <write@plt>
    2ce4:	2a0003e3 	mov	w3, w0
          if(cc != sz){
    2ce8:	71400c1f 	cmp	w0, #0x3, lsl #12
    2cec:	540000e0 	b.eq	2d08 <manywrites+0xcc>  // b.none
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    2cf0:	aa1803e1 	mov	x1, x24
    2cf4:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2cf8:	9122b800 	add	x0, x0, #0x8ae
    2cfc:	52860002 	mov	w2, #0x3000                	// #12288
    2d00:	97fff9a8 	bl	13a0 <printf@plt>
            exit(1);
    2d04:	17ffffdc 	b	2c74 <manywrites+0x38>
          close(fd);
    2d08:	2a1903e0 	mov	w0, w25
        for(int i = 0; i < ci+1; i++){
    2d0c:	11000694 	add	w20, w20, #0x1
          close(fd);
    2d10:	97fff9f8 	bl	14f0 <close@plt>
        for(int i = 0; i < ci+1; i++){
    2d14:	6b13029f 	cmp	w20, w19
    2d18:	54fffcad 	b.le	2cac <manywrites+0x70>
        unlink(name);
    2d1c:	910163e0 	add	x0, sp, #0x58
    2d20:	97fff9d0 	bl	1460 <unlink@plt>
      for(int iters = 0; iters < howmany; iters++){
    2d24:	710006d6 	subs	w22, w22, #0x1
    2d28:	54fffc01 	b.ne	2ca8 <manywrites+0x6c>  // b.any
      unlink(name);
    2d2c:	910163e0 	add	x0, sp, #0x58
    2d30:	97fff9cc 	bl	1460 <unlink@plt>
      exit(0);
    2d34:	52800000 	mov	w0, #0x0                   	// #0
    2d38:	17ffffd0 	b	2c78 <manywrites+0x3c>
  for(int ci = 0; ci < nchildren; ci++){
    2d3c:	11000673 	add	w19, w19, #0x1
    2d40:	7100127f 	cmp	w19, #0x4
    2d44:	54fff8c1 	b.ne	2c5c <manywrites+0x20>  // b.any
    wait(&st);
    2d48:	910163e0 	add	x0, sp, #0x58
    int st = 0;
    2d4c:	b9005bff 	str	wzr, [sp, #88]
    wait(&st);
    2d50:	97fff9bc 	bl	1440 <wait@plt>
    if(st != 0)
    2d54:	b9405be0 	ldr	w0, [sp, #88]
    2d58:	35fff900 	cbnz	w0, 2c78 <manywrites+0x3c>
  for(int ci = 0; ci < nchildren; ci++){
    2d5c:	71000673 	subs	w19, w19, #0x1
    2d60:	54ffff41 	b.ne	2d48 <manywrites+0x10c>  // b.any
    2d64:	17ffffc5 	b	2c78 <manywrites+0x3c>

0000000000002d68 <forktest>:
{
    2d68:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d6c:	910003fd 	mov	x29, sp
    2d70:	a90153f3 	stp	x19, x20, [sp, #16]
    2d74:	aa0003f4 	mov	x20, x0
  for(n=0; n<N; n++){
    2d78:	52800013 	mov	w19, #0x0                   	// #0
    pid = fork();
    2d7c:	97fff9bd 	bl	1470 <fork@plt>
    if(pid < 0)
    2d80:	37f80300 	tbnz	w0, #31, 2de0 <forktest+0x78>
    if(pid == 0)
    2d84:	35000040 	cbnz	w0, 2d8c <forktest+0x24>
    exit(1);
    2d88:	97fff9ce 	bl	14c0 <exit@plt>
  for(n=0; n<N; n++){
    2d8c:	11000673 	add	w19, w19, #0x1
    2d90:	710fa27f 	cmp	w19, #0x3e8
    2d94:	54ffff41 	b.ne	2d7c <forktest+0x14>  // b.any
    printf("%s: fork claimed to work 1000 times!\n", s);
    2d98:	90000020 	adrp	x0, 6000 <run+0x858>
    2d9c:	91013000 	add	x0, x0, #0x4c
    2da0:	14000013 	b	2dec <forktest+0x84>
    if(wait(0) < 0){
    2da4:	d2800000 	mov	x0, #0x0                   	// #0
    2da8:	97fff9a6 	bl	1440 <wait@plt>
    2dac:	36f80080 	tbz	w0, #31, 2dbc <forktest+0x54>
      printf("%s: wait stopped early\n", s);
    2db0:	90000020 	adrp	x0, 6000 <run+0x858>
    2db4:	91007400 	add	x0, x0, #0x1d
    2db8:	1400000d 	b	2dec <forktest+0x84>
  for(; n > 0; n--){
    2dbc:	71000673 	subs	w19, w19, #0x1
    2dc0:	54ffff21 	b.ne	2da4 <forktest+0x3c>  // b.any
  if(wait(0) != -1){
    2dc4:	d2800000 	mov	x0, #0x0                   	// #0
    2dc8:	97fff99e 	bl	1440 <wait@plt>
    2dcc:	3100041f 	cmn	w0, #0x1
    2dd0:	54000160 	b.eq	2dfc <forktest+0x94>  // b.none
    printf("%s: wait got too many\n", s);
    2dd4:	90000020 	adrp	x0, 6000 <run+0x858>
    2dd8:	9100d400 	add	x0, x0, #0x35
    2ddc:	14000004 	b	2dec <forktest+0x84>
  if (n == 0) {
    2de0:	35fffe33 	cbnz	w19, 2da4 <forktest+0x3c>
    printf("%s: no fork at all!\n", s);
    2de4:	90000020 	adrp	x0, 6000 <run+0x858>
    2de8:	91002000 	add	x0, x0, #0x8
    2dec:	aa1403e1 	mov	x1, x20
    2df0:	97fff96c 	bl	13a0 <printf@plt>
    exit(1);
    2df4:	52800020 	mov	w0, #0x1                   	// #1
    2df8:	17ffffe4 	b	2d88 <forktest+0x20>
}
    2dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e04:	d65f03c0 	ret

0000000000002e08 <kernmem>:
{
    2e08:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2e0c:	910003fd 	mov	x29, sp
    2e10:	a90153f3 	stp	x19, x20, [sp, #16]
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    2e14:	b25963f3 	mov	x19, #0xffffff8000000000    	// #-549755813888
{
    2e18:	aa0003f4 	mov	x20, x0
    2e1c:	f90013f5 	str	x21, [sp, #32]
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    2e20:	9147a275 	add	x21, x19, #0x1e8, lsl #12
    2e24:	911202b5 	add	x21, x21, #0x480
    pid = fork();
    2e28:	97fff992 	bl	1470 <fork@plt>
    if(pid < 0){
    2e2c:	36f800e0 	tbz	w0, #31, 2e48 <kernmem+0x40>
      printf("%s: fork failed\n", s);
    2e30:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2e34:	91380400 	add	x0, x0, #0xe01
    2e38:	aa1403e1 	mov	x1, x20
    2e3c:	97fff959 	bl	13a0 <printf@plt>
      exit(1);
    2e40:	52800020 	mov	w0, #0x1                   	// #1
    2e44:	97fff99f 	bl	14c0 <exit@plt>
    if(pid == 0){
    2e48:	35000100 	cbnz	w0, 2e68 <kernmem+0x60>
      printf("%s: oops could read %x = %x\n", s, a, *a);
    2e4c:	39400263 	ldrb	w3, [x19]
    2e50:	aa1303e2 	mov	x2, x19
    2e54:	aa1403e1 	mov	x1, x20
    2e58:	90000020 	adrp	x0, 6000 <run+0x858>
    2e5c:	9101c800 	add	x0, x0, #0x72
    2e60:	97fff950 	bl	13a0 <printf@plt>
    2e64:	17fffff7 	b	2e40 <kernmem+0x38>
    wait(&xstatus);
    2e68:	9100f3e0 	add	x0, sp, #0x3c
    2e6c:	97fff975 	bl	1440 <wait@plt>
    if(xstatus != -1)  // did kernel kill child?
    2e70:	b9403fe0 	ldr	w0, [sp, #60]
    2e74:	3100041f 	cmn	w0, #0x1
    2e78:	54fffe41 	b.ne	2e40 <kernmem+0x38>  // b.any
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    2e7c:	d2986a00 	mov	x0, #0xc350                	// #50000
    2e80:	8b000273 	add	x19, x19, x0
    2e84:	eb15027f 	cmp	x19, x21
    2e88:	54fffd01 	b.ne	2e28 <kernmem+0x20>  // b.any
}
    2e8c:	f94013f5 	ldr	x21, [sp, #32]
    2e90:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e94:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2e98:	d65f03c0 	ret

0000000000002e9c <MAXVAplus>:
{
    2e9c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ea0:	910003fd 	mov	x29, sp
    2ea4:	f9000bf3 	str	x19, [sp, #16]
    2ea8:	aa0003f3 	mov	x19, x0
  volatile uint64 a = MAXVA;
    2eac:	b25a67e0 	mov	x0, #0xffffffc000000000    	// #-274877906944
  for( ; a != 0; a <<= 1){
    2eb0:	f90017e0 	str	x0, [sp, #40]
    2eb4:	f94017e0 	ldr	x0, [sp, #40]
    2eb8:	b5000080 	cbnz	x0, 2ec8 <MAXVAplus+0x2c>
}
    2ebc:	f9400bf3 	ldr	x19, [sp, #16]
    2ec0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ec4:	d65f03c0 	ret
    pid = fork();
    2ec8:	97fff96a 	bl	1470 <fork@plt>
    if(pid < 0){
    2ecc:	36f800e0 	tbz	w0, #31, 2ee8 <MAXVAplus+0x4c>
      printf("%s: fork failed\n", s);
    2ed0:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2ed4:	91380400 	add	x0, x0, #0xe01
    2ed8:	aa1303e1 	mov	x1, x19
    2edc:	97fff931 	bl	13a0 <printf@plt>
      exit(1);
    2ee0:	52800020 	mov	w0, #0x1                   	// #1
    2ee4:	97fff977 	bl	14c0 <exit@plt>
    if(pid == 0){
    2ee8:	35000140 	cbnz	w0, 2f10 <MAXVAplus+0x74>
      *(char*)a = 99;
    2eec:	f94017e0 	ldr	x0, [sp, #40]
    2ef0:	52800c61 	mov	w1, #0x63                  	// #99
      printf("%s: oops wrote %x\n", s, a);
    2ef4:	f94017e2 	ldr	x2, [sp, #40]
      *(char*)a = 99;
    2ef8:	39000001 	strb	w1, [x0]
      printf("%s: oops wrote %x\n", s, a);
    2efc:	aa1303e1 	mov	x1, x19
    2f00:	90000020 	adrp	x0, 6000 <run+0x858>
    2f04:	91023c00 	add	x0, x0, #0x8f
    2f08:	97fff926 	bl	13a0 <printf@plt>
    2f0c:	17fffff5 	b	2ee0 <MAXVAplus+0x44>
    wait(&xstatus);
    2f10:	910093e0 	add	x0, sp, #0x24
    2f14:	97fff94b 	bl	1440 <wait@plt>
    if(xstatus != -1)  // did kernel kill child?
    2f18:	b94027e0 	ldr	w0, [sp, #36]
    2f1c:	3100041f 	cmn	w0, #0x1
    2f20:	54fffe01 	b.ne	2ee0 <MAXVAplus+0x44>  // b.any
  for( ; a != 0; a <<= 1){
    2f24:	f94017e0 	ldr	x0, [sp, #40]
    2f28:	d37ff800 	lsl	x0, x0, #1
    2f2c:	17ffffe1 	b	2eb0 <MAXVAplus+0x14>

0000000000002f30 <bigargtest>:
{
    2f30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2f34:	910003fd 	mov	x29, sp
    2f38:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("bigarg-ok");
    2f3c:	90000033 	adrp	x19, 6000 <run+0x858>
    2f40:	91028a73 	add	x19, x19, #0xa2
{
    2f44:	aa0003f4 	mov	x20, x0
  unlink("bigarg-ok");
    2f48:	aa1303e0 	mov	x0, x19
    2f4c:	97fff945 	bl	1460 <unlink@plt>
  pid = fork();
    2f50:	97fff948 	bl	1470 <fork@plt>
  if(pid == 0){
    2f54:	35000280 	cbnz	w0, 2fa4 <bigargtest+0x74>
      args[i] = "bigargs test: failed\n                                                                                                                                                                                                       ";
    2f58:	d0000021 	adrp	x1, 8000 <_DYNAMIC>
    2f5c:	9108e021 	add	x1, x1, #0x238
    2f60:	90000022 	adrp	x2, 6000 <run+0x858>
    2f64:	9102b042 	add	x2, x2, #0xac
    2f68:	d2800000 	mov	x0, #0x0                   	// #0
    2f6c:	f8207822 	str	x2, [x1, x0, lsl #3]
    for(i = 0; i < MAXARG-1; i++)
    2f70:	91000400 	add	x0, x0, #0x1
    2f74:	f1007c1f 	cmp	x0, #0x1f
    2f78:	54ffffa1 	b.ne	2f6c <bigargtest+0x3c>  // b.any
    exec("/bin/echo", args);
    2f7c:	f0000000 	adrp	x0, 5000 <bigfile+0x108>
    2f80:	91349400 	add	x0, x0, #0xd25
    args[MAXARG-1] = 0;
    2f84:	f9007c3f 	str	xzr, [x1, #248]
    exec("/bin/echo", args);
    2f88:	97fff92a 	bl	1430 <exec@plt>
    fd = open("bigarg-ok", O_CREATE);
    2f8c:	52804001 	mov	w1, #0x200                 	// #512
    2f90:	aa1303e0 	mov	x0, x19
    2f94:	97fff94f 	bl	14d0 <open@plt>
    close(fd);
    2f98:	97fff956 	bl	14f0 <close@plt>
    exit(0);
    2f9c:	52800000 	mov	w0, #0x0                   	// #0
    exit(1);
    2fa0:	97fff948 	bl	14c0 <exit@plt>
  } else if(pid < 0){
    2fa4:	36f800e0 	tbz	w0, #31, 2fc0 <bigargtest+0x90>
    printf("%s: bigargtest: fork failed\n", s);
    2fa8:	90000020 	adrp	x0, 6000 <run+0x858>
    2fac:	91062400 	add	x0, x0, #0x189
    2fb0:	aa1403e1 	mov	x1, x20
    2fb4:	97fff8fb 	bl	13a0 <printf@plt>
    exit(1);
    2fb8:	52800020 	mov	w0, #0x1                   	// #1
    2fbc:	17fffff9 	b	2fa0 <bigargtest+0x70>
  wait(&xstatus);
    2fc0:	9100b3e0 	add	x0, sp, #0x2c
    2fc4:	97fff91f 	bl	1440 <wait@plt>
  if(xstatus != 0)
    2fc8:	b9402fe0 	ldr	w0, [sp, #44]
    2fcc:	35fffea0 	cbnz	w0, 2fa0 <bigargtest+0x70>
  fd = open("bigarg-ok", 0);
    2fd0:	aa1303e0 	mov	x0, x19
    2fd4:	52800001 	mov	w1, #0x0                   	// #0
    2fd8:	97fff93e 	bl	14d0 <open@plt>
  if(fd < 0){
    2fdc:	36f80080 	tbz	w0, #31, 2fec <bigargtest+0xbc>
    printf("%s: bigarg test failed!\n", s);
    2fe0:	90000020 	adrp	x0, 6000 <run+0x858>
    2fe4:	91069800 	add	x0, x0, #0x1a6
    2fe8:	17fffff2 	b	2fb0 <bigargtest+0x80>
  close(fd);
    2fec:	97fff941 	bl	14f0 <close@plt>
}
    2ff0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ff4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ff8:	d65f03c0 	ret

0000000000002ffc <stacktest>:
{
    2ffc:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3000:	910003fd 	mov	x29, sp
    3004:	f9000fe0 	str	x0, [sp, #24]
  pid = fork();
    3008:	97fff91a 	bl	1470 <fork@plt>
  if(pid == 0) {
    300c:	f9400fe1 	ldr	x1, [sp, #24]
    3010:	35000120 	cbnz	w0, 3034 <stacktest+0x38>

static inline uint64
r_sp(void)
{
  uint64 value;
  __asm__ volatile("mov %0, sp" : "=r" (value));
    3014:	910003e2 	mov	x2, sp
    printf("%s: stacktest: read below stack %p\n", s, *sp);
    3018:	d1400442 	sub	x2, x2, #0x1, lsl #12
    301c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3020:	9106fc00 	add	x0, x0, #0x1bf
    3024:	39400042 	ldrb	w2, [x2]
    3028:	97fff8de 	bl	13a0 <printf@plt>
    exit(1);
    302c:	52800020 	mov	w0, #0x1                   	// #1
    3030:	97fff924 	bl	14c0 <exit@plt>
  } else if(pid < 0){
    3034:	36f800a0 	tbz	w0, #31, 3048 <stacktest+0x4c>
    printf("%s: fork failed\n", s);
    3038:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    303c:	91380400 	add	x0, x0, #0xe01
    3040:	97fff8d8 	bl	13a0 <printf@plt>
    3044:	17fffffa 	b	302c <stacktest+0x30>
  wait(&xstatus);
    3048:	9100b3e0 	add	x0, sp, #0x2c
    304c:	97fff8fd 	bl	1440 <wait@plt>
  if(xstatus == -1)  // kernel killed child?
    3050:	b9402fe0 	ldr	w0, [sp, #44]
    3054:	3100041f 	cmn	w0, #0x1
    3058:	54fffec1 	b.ne	3030 <stacktest+0x34>  // b.any
    exit(0);
    305c:	52800000 	mov	w0, #0x0                   	// #0
    3060:	17fffff4 	b	3030 <stacktest+0x34>

0000000000003064 <copyinstr3>:
{
    3064:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  sbrk(8192);
    3068:	52840000 	mov	w0, #0x2000                	// #8192
{
    306c:	910003fd 	mov	x29, sp
    3070:	a90153f3 	stp	x19, x20, [sp, #16]
  sbrk(8192);
    3074:	97fff903 	bl	1480 <sbrk@plt>
  uint64 top = (uint64) sbrk(0);
    3078:	52800000 	mov	w0, #0x0                   	// #0
    307c:	97fff901 	bl	1480 <sbrk@plt>
  if((top % PGSIZE) != 0){
    3080:	f2402c00 	ands	x0, x0, #0xfff
    3084:	54000080 	b.eq	3094 <copyinstr3+0x30>  // b.none
    sbrk(PGSIZE - (top % PGSIZE));
    3088:	52820001 	mov	w1, #0x1000                	// #4096
    308c:	4b000020 	sub	w0, w1, w0
    3090:	97fff8fc 	bl	1480 <sbrk@plt>
  top = (uint64) sbrk(0);
    3094:	52800000 	mov	w0, #0x0                   	// #0
    3098:	97fff8fa 	bl	1480 <sbrk@plt>
  if(top % PGSIZE){
    309c:	f2402c1f 	tst	x0, #0xfff
    30a0:	540000c0 	b.eq	30b8 <copyinstr3+0x54>  // b.none
    printf("oops\n");
    30a4:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    30a8:	91347c00 	add	x0, x0, #0xd1f
    30ac:	97fff8bd 	bl	13a0 <printf@plt>
    exit(1);
    30b0:	52800020 	mov	w0, #0x1                   	// #1
    30b4:	97fff903 	bl	14c0 <exit@plt>
  *b = 'x';
    30b8:	52800f01 	mov	w1, #0x78                  	// #120
    30bc:	381ff001 	sturb	w1, [x0, #-1]
  char *b = (char *) (top - 1);
    30c0:	d1000413 	sub	x19, x0, #0x1
  int ret = unlink(b);
    30c4:	aa1303e0 	mov	x0, x19
    30c8:	97fff8e6 	bl	1460 <unlink@plt>
    30cc:	2a0003e2 	mov	w2, w0
  if(ret != -1){
    30d0:	3100041f 	cmn	w0, #0x1
    30d4:	540000c0 	b.eq	30ec <copyinstr3+0x88>  // b.none
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    30d8:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    30dc:	9134bc00 	add	x0, x0, #0xd2f
    30e0:	aa1303e1 	mov	x1, x19
    30e4:	97fff8af 	bl	13a0 <printf@plt>
    30e8:	17fffff2 	b	30b0 <copyinstr3+0x4c>
  int fd = open(b, O_CREATE | O_WRONLY);
    30ec:	aa1303e0 	mov	x0, x19
    30f0:	52804021 	mov	w1, #0x201                 	// #513
    30f4:	97fff8f7 	bl	14d0 <open@plt>
    30f8:	2a0003e2 	mov	w2, w0
  if(fd != -1){
    30fc:	3100041f 	cmn	w0, #0x1
    3100:	54000080 	b.eq	3110 <copyinstr3+0xac>  // b.none
    printf("open(%s) returned %d, not -1\n", b, fd);
    3104:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    3108:	91353c00 	add	x0, x0, #0xd4f
    310c:	17fffff5 	b	30e0 <copyinstr3+0x7c>
  ret = link(b, b);
    3110:	aa1303e1 	mov	x1, x19
    3114:	aa1303e0 	mov	x0, x19
    3118:	97fff8e6 	bl	14b0 <link@plt>
    311c:	2a0003f4 	mov	w20, w0
  if(ret != -1){
    3120:	3100041f 	cmn	w0, #0x1
    3124:	54000100 	b.eq	3144 <copyinstr3+0xe0>  // b.none
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    3128:	2a1403e3 	mov	w3, w20
    312c:	aa1303e2 	mov	x2, x19
    3130:	aa1303e1 	mov	x1, x19
    3134:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    3138:	9135b400 	add	x0, x0, #0xd6d
    313c:	97fff899 	bl	13a0 <printf@plt>
    exit(1);
    3140:	17ffffdc 	b	30b0 <copyinstr3+0x4c>
  char *args[] = { "xx", 0 };
    3144:	f0000000 	adrp	x0, 6000 <run+0x858>
    3148:	91274c00 	add	x0, x0, #0x9d3
  ret = exec(b, args);
    314c:	910083e1 	add	x1, sp, #0x20
  char *args[] = { "xx", 0 };
    3150:	a9027fe0 	stp	x0, xzr, [sp, #32]
  ret = exec(b, args);
    3154:	aa1303e0 	mov	x0, x19
    3158:	97fff8b6 	bl	1430 <exec@plt>
  if(ret != -1){
    315c:	3100041f 	cmn	w0, #0x1
    3160:	540000a0 	b.eq	3174 <copyinstr3+0x110>  // b.none
    printf("exec(%s) returned %d, not -1\n", b, fd);
    3164:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    3168:	91363c00 	add	x0, x0, #0xd8f
    316c:	2a1403e2 	mov	w2, w20
    3170:	17ffffdc 	b	30e0 <copyinstr3+0x7c>
}
    3174:	a94153f3 	ldp	x19, x20, [sp, #16]
    3178:	a8c37bfd 	ldp	x29, x30, [sp], #48
    317c:	d65f03c0 	ret

0000000000003180 <rwsbrk>:
{
    3180:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  uint64 a = (uint64) sbrk(8192);
    3184:	52840000 	mov	w0, #0x2000                	// #8192
{
    3188:	910003fd 	mov	x29, sp
    318c:	a90153f3 	stp	x19, x20, [sp, #16]
    3190:	f90013f5 	str	x21, [sp, #32]
  uint64 a = (uint64) sbrk(8192);
    3194:	97fff8bb 	bl	1480 <sbrk@plt>
  if(a == 0xffffffffffffffffLL) {
    3198:	b100041f 	cmn	x0, #0x1
    319c:	540000c1 	b.ne	31b4 <rwsbrk+0x34>  // b.any
    printf("sbrk(rwsbrk) failed\n");
    31a0:	f0000000 	adrp	x0, 6000 <run+0x858>
    31a4:	91078c00 	add	x0, x0, #0x1e3
    printf("sbrk(rwsbrk) shrink failed\n");
    31a8:	97fff87e 	bl	13a0 <printf@plt>
    exit(1);
    31ac:	52800020 	mov	w0, #0x1                   	// #1
    31b0:	97fff8c4 	bl	14c0 <exit@plt>
    31b4:	aa0003f3 	mov	x19, x0
  if ((uint64) sbrk(-8192) ==  0xffffffffffffffffLL) {
    31b8:	1283ffe0 	mov	w0, #0xffffe000            	// #-8192
    31bc:	97fff8b1 	bl	1480 <sbrk@plt>
    31c0:	b100041f 	cmn	x0, #0x1
    31c4:	54000081 	b.ne	31d4 <rwsbrk+0x54>  // b.any
    printf("sbrk(rwsbrk) shrink failed\n");
    31c8:	f0000000 	adrp	x0, 6000 <run+0x858>
    31cc:	9107e000 	add	x0, x0, #0x1f8
    31d0:	17fffff6 	b	31a8 <rwsbrk+0x28>
  fd = open("rwsbrk", O_CREATE|O_WRONLY);
    31d4:	f0000014 	adrp	x20, 6000 <run+0x858>
    31d8:	91085294 	add	x20, x20, #0x214
    31dc:	aa1403e0 	mov	x0, x20
    31e0:	52804021 	mov	w1, #0x201                 	// #513
    31e4:	97fff8bb 	bl	14d0 <open@plt>
    31e8:	2a0003f5 	mov	w21, w0
  if(fd < 0){
    31ec:	36f80080 	tbz	w0, #31, 31fc <rwsbrk+0x7c>
    printf("open(rwsbrk) failed\n");
    31f0:	f0000000 	adrp	x0, 6000 <run+0x858>
    31f4:	91086c00 	add	x0, x0, #0x21b
    31f8:	17ffffec 	b	31a8 <rwsbrk+0x28>
  n = write(fd, (void*)(a+4096), 1024);
    31fc:	52808002 	mov	w2, #0x400                 	// #1024
    3200:	91400673 	add	x19, x19, #0x1, lsl #12
    3204:	aa1303e1 	mov	x1, x19
    3208:	97fff87a 	bl	13f0 <write@plt>
    320c:	2a0003e2 	mov	w2, w0
  if(n >= 0){
    3210:	37f800c0 	tbnz	w0, #31, 3228 <rwsbrk+0xa8>
    printf("write(fd, %p, 1024) returned %d, not -1\n", a+4096, n);
    3214:	f0000000 	adrp	x0, 6000 <run+0x858>
    3218:	9108c000 	add	x0, x0, #0x230
    printf("read(fd, %p, 10) returned %d, not -1\n", a+4096, n);
    321c:	aa1303e1 	mov	x1, x19
    3220:	97fff860 	bl	13a0 <printf@plt>
    exit(1);
    3224:	17ffffe2 	b	31ac <rwsbrk+0x2c>
  close(fd);
    3228:	2a1503e0 	mov	w0, w21
    322c:	97fff8b1 	bl	14f0 <close@plt>
  unlink("rwsbrk");
    3230:	aa1403e0 	mov	x0, x20
    3234:	97fff88b 	bl	1460 <unlink@plt>
  fd = open("README", O_RDONLY);
    3238:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    323c:	9125a000 	add	x0, x0, #0x968
    3240:	52800001 	mov	w1, #0x0                   	// #0
    3244:	97fff8a3 	bl	14d0 <open@plt>
    3248:	2a0003f4 	mov	w20, w0
  if(fd < 0){
    324c:	37fffd20 	tbnz	w0, #31, 31f0 <rwsbrk+0x70>
  n = read(fd, (void*)(a+4096), 10);
    3250:	52800142 	mov	w2, #0xa                   	// #10
    3254:	aa1303e1 	mov	x1, x19
    3258:	97fff87e 	bl	1450 <read@plt>
    325c:	2a0003e2 	mov	w2, w0
  if(n >= 0){
    3260:	37f80080 	tbnz	w0, #31, 3270 <rwsbrk+0xf0>
    printf("read(fd, %p, 10) returned %d, not -1\n", a+4096, n);
    3264:	f0000000 	adrp	x0, 6000 <run+0x858>
    3268:	91096400 	add	x0, x0, #0x259
    326c:	17ffffec 	b	321c <rwsbrk+0x9c>
  close(fd);
    3270:	2a1403e0 	mov	w0, w20
    3274:	97fff89f 	bl	14f0 <close@plt>
  exit(0);
    3278:	52800000 	mov	w0, #0x0                   	// #0
    327c:	17ffffcd 	b	31b0 <rwsbrk+0x30>

0000000000003280 <sbrkbasic>:
{
    3280:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3284:	910003fd 	mov	x29, sp
    3288:	a90153f3 	stp	x19, x20, [sp, #16]
    328c:	aa0003f4 	mov	x20, x0
    3290:	a9025bf5 	stp	x21, x22, [sp, #32]
  pid = fork();
    3294:	97fff877 	bl	1470 <fork@plt>
  if(pid < 0){
    3298:	36f800c0 	tbz	w0, #31, 32b0 <sbrkbasic+0x30>
    printf("fork failed in sbrkbasic\n");
    329c:	f0000000 	adrp	x0, 6000 <run+0x858>
    32a0:	9109fc00 	add	x0, x0, #0x27f
    32a4:	97fff83f 	bl	13a0 <printf@plt>
    exit(1);
    32a8:	52800020 	mov	w0, #0x1                   	// #1
    32ac:	14000007 	b	32c8 <sbrkbasic+0x48>
  if(pid == 0){
    32b0:	350001e0 	cbnz	w0, 32ec <sbrkbasic+0x6c>
    a = sbrk(TOOMUCH);
    32b4:	52a80000 	mov	w0, #0x40000000            	// #1073741824
    32b8:	97fff872 	bl	1480 <sbrk@plt>
    if(a == (char*)0xffffffffffffffffL){
    32bc:	b100041f 	cmn	x0, #0x1
    32c0:	54000061 	b.ne	32cc <sbrkbasic+0x4c>  // b.any
      exit(0);
    32c4:	52800000 	mov	w0, #0x0                   	// #0
    32c8:	97fff87e 	bl	14c0 <exit@plt>
    if(a == (char*)0xffffffffffffffffL){
    32cc:	d2800001 	mov	x1, #0x0                   	// #0
      *b = 99;
    32d0:	52800c63 	mov	w3, #0x63                  	// #99
    for(b = a; b < a+TOOMUCH; b += 4096){
    32d4:	d2a80002 	mov	x2, #0x40000000            	// #1073741824
      *b = 99;
    32d8:	38216803 	strb	w3, [x0, x1]
    for(b = a; b < a+TOOMUCH; b += 4096){
    32dc:	91400421 	add	x1, x1, #0x1, lsl #12
    32e0:	eb02003f 	cmp	x1, x2
    32e4:	54ffffa1 	b.ne	32d8 <sbrkbasic+0x58>  // b.any
    32e8:	17fffff0 	b	32a8 <sbrkbasic+0x28>
  wait(&xstatus);
    32ec:	910133e0 	add	x0, sp, #0x4c
    32f0:	97fff854 	bl	1440 <wait@plt>
  if(xstatus == 1){
    32f4:	b9404ff3 	ldr	w19, [sp, #76]
    32f8:	7100067f 	cmp	w19, #0x1
    32fc:	540000c1 	b.ne	3314 <sbrkbasic+0x94>  // b.any
    printf("%s: too much memory allocated!\n", s);
    3300:	f0000000 	adrp	x0, 6000 <run+0x858>
    3304:	910a6400 	add	x0, x0, #0x299
    printf("%s: sbrk test failed post-fork\n", s);
    3308:	aa1403e1 	mov	x1, x20
    330c:	97fff825 	bl	13a0 <printf@plt>
    3310:	17ffffe6 	b	32a8 <sbrkbasic+0x28>
  a = sbrk(0);
    3314:	52800000 	mov	w0, #0x0                   	// #0
    3318:	97fff85a 	bl	1480 <sbrk@plt>
    331c:	aa0003f3 	mov	x19, x0
  for(i = 0; i < 5000; i++){
    3320:	52800002 	mov	w2, #0x0                   	// #0
    *b = 1;
    3324:	52800036 	mov	w22, #0x1                   	// #1
  for(i = 0; i < 5000; i++){
    3328:	52827115 	mov	w21, #0x1388                	// #5000
    b = sbrk(1);
    332c:	52800020 	mov	w0, #0x1                   	// #1
    3330:	b9003fe2 	str	w2, [sp, #60]
    3334:	97fff853 	bl	1480 <sbrk@plt>
    3338:	aa0003e4 	mov	x4, x0
    if(b != a){
    333c:	b9403fe2 	ldr	w2, [sp, #60]
    3340:	eb13001f 	cmp	x0, x19
    3344:	54000120 	b.eq	3368 <sbrkbasic+0xe8>  // b.none
      printf("%s: sbrk test failed %d %x %x\n", s, i, a, b);
    3348:	aa1303e3 	mov	x3, x19
    334c:	aa1403e1 	mov	x1, x20
    3350:	f0000000 	adrp	x0, 6000 <run+0x858>
    3354:	910ae400 	add	x0, x0, #0x2b9
    3358:	97fff812 	bl	13a0 <printf@plt>
      exit(1);
    335c:	17ffffd3 	b	32a8 <sbrkbasic+0x28>
  for(i = 0; i < 5000; i++){
    3360:	aa0003f3 	mov	x19, x0
    3364:	17fffff2 	b	332c <sbrkbasic+0xac>
    *b = 1;
    3368:	aa1303e0 	mov	x0, x19
  for(i = 0; i < 5000; i++){
    336c:	11000442 	add	w2, w2, #0x1
    *b = 1;
    3370:	38001416 	strb	w22, [x0], #1
  for(i = 0; i < 5000; i++){
    3374:	6b15005f 	cmp	w2, w21
    3378:	54ffff41 	b.ne	3360 <sbrkbasic+0xe0>  // b.any
  pid = fork();
    337c:	97fff83d 	bl	1470 <fork@plt>
    3380:	2a0003f5 	mov	w21, w0
  if(pid < 0){
    3384:	36f80080 	tbz	w0, #31, 3394 <sbrkbasic+0x114>
    printf("%s: sbrk test fork failed\n", s);
    3388:	f0000000 	adrp	x0, 6000 <run+0x858>
    338c:	910b6000 	add	x0, x0, #0x2d8
    3390:	17ffffde 	b	3308 <sbrkbasic+0x88>
  c = sbrk(1);
    3394:	52800020 	mov	w0, #0x1                   	// #1
  if(c != a + 1){
    3398:	91000a73 	add	x19, x19, #0x2
  c = sbrk(1);
    339c:	97fff839 	bl	1480 <sbrk@plt>
  c = sbrk(1);
    33a0:	52800020 	mov	w0, #0x1                   	// #1
    33a4:	97fff837 	bl	1480 <sbrk@plt>
  if(c != a + 1){
    33a8:	eb13001f 	cmp	x0, x19
    33ac:	54000080 	b.eq	33bc <sbrkbasic+0x13c>  // b.none
    printf("%s: sbrk test failed post-fork\n", s);
    33b0:	f0000000 	adrp	x0, 6000 <run+0x858>
    33b4:	910bcc00 	add	x0, x0, #0x2f3
    33b8:	17ffffd4 	b	3308 <sbrkbasic+0x88>
  if(pid == 0)
    33bc:	34fff855 	cbz	w21, 32c4 <sbrkbasic+0x44>
  wait(&xstatus);
    33c0:	910133e0 	add	x0, sp, #0x4c
    33c4:	97fff81f 	bl	1440 <wait@plt>
  exit(xstatus);
    33c8:	b9404fe0 	ldr	w0, [sp, #76]
    33cc:	17ffffbf 	b	32c8 <sbrkbasic+0x48>

00000000000033d0 <sbrkmuch>:
{
    33d0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    33d4:	910003fd 	mov	x29, sp
    33d8:	a90153f3 	stp	x19, x20, [sp, #16]
    33dc:	aa0003f4 	mov	x20, x0
  oldbrk = sbrk(0);
    33e0:	52800000 	mov	w0, #0x0                   	// #0
{
    33e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    33e8:	f9001bf7 	str	x23, [sp, #48]
  oldbrk = sbrk(0);
    33ec:	97fff825 	bl	1480 <sbrk@plt>
    33f0:	aa0003f7 	mov	x23, x0
  a = sbrk(0);
    33f4:	52800000 	mov	w0, #0x0                   	// #0
    33f8:	97fff822 	bl	1480 <sbrk@plt>
    33fc:	aa0003f3 	mov	x19, x0
  p = sbrk(amt);
    3400:	d2a0c800 	mov	x0, #0x6400000             	// #104857600
    3404:	4b130000 	sub	w0, w0, w19
    3408:	97fff81e 	bl	1480 <sbrk@plt>
  if (p != a) {
    340c:	eb00027f 	cmp	x19, x0
    3410:	540000e0 	b.eq	342c <sbrkmuch+0x5c>  // b.none
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n", s);
    3414:	f0000000 	adrp	x0, 6000 <run+0x858>
    3418:	910c4c00 	add	x0, x0, #0x313
    printf("%s: sbrk could not deallocate\n", s);
    341c:	aa1403e1 	mov	x1, x20
    3420:	97fff7e0 	bl	13a0 <printf@plt>
    exit(1);
    3424:	52800020 	mov	w0, #0x1                   	// #1
    3428:	97fff826 	bl	14c0 <exit@plt>
  char *eee = sbrk(0);
    342c:	52800000 	mov	w0, #0x0                   	// #0
    3430:	97fff814 	bl	1480 <sbrk@plt>
    *pp = 1;
    3434:	52800021 	mov	w1, #0x1                   	// #1
  for(char *pp = a; pp < eee; pp += 4096)
    3438:	eb00027f 	cmp	x19, x0
    343c:	540001c3 	b.cc	3474 <sbrkmuch+0xa4>  // b.lo, b.ul, b.last
  *lastaddr = 99;
    3440:	12bf3815 	mov	w21, #0x63fffff             	// #104857599
    3444:	52800c60 	mov	w0, #0x63                  	// #99
    3448:	390002a0 	strb	w0, [x21]
  a = sbrk(0);
    344c:	52800000 	mov	w0, #0x0                   	// #0
    3450:	97fff80c 	bl	1480 <sbrk@plt>
    3454:	aa0003f3 	mov	x19, x0
  c = sbrk(-PGSIZE);
    3458:	1281ffe0 	mov	w0, #0xfffff000            	// #-4096
    345c:	97fff809 	bl	1480 <sbrk@plt>
  if(c == (char*)0xffffffffffffffffL){
    3460:	b100041f 	cmn	x0, #0x1
    3464:	540000e1 	b.ne	3480 <sbrkmuch+0xb0>  // b.any
    printf("%s: sbrk could not deallocate\n", s);
    3468:	f0000000 	adrp	x0, 6000 <run+0x858>
    346c:	910d5400 	add	x0, x0, #0x355
    3470:	17ffffeb 	b	341c <sbrkmuch+0x4c>
    *pp = 1;
    3474:	39000261 	strb	w1, [x19]
  for(char *pp = a; pp < eee; pp += 4096)
    3478:	91400673 	add	x19, x19, #0x1, lsl #12
    347c:	17ffffef 	b	3438 <sbrkmuch+0x68>
  c = sbrk(0);
    3480:	52800000 	mov	w0, #0x0                   	// #0
    3484:	97fff7ff 	bl	1480 <sbrk@plt>
    3488:	aa0003e3 	mov	x3, x0
  if(c != a - PGSIZE){
    348c:	d1400660 	sub	x0, x19, #0x1, lsl #12
    3490:	eb00007f 	cmp	x3, x0
    3494:	540000e0 	b.eq	34b0 <sbrkmuch+0xe0>  // b.none
    printf("%s: sbrk deallocation produced wrong address, a %x c %x\n", s, a, c);
    3498:	f0000000 	adrp	x0, 6000 <run+0x858>
    349c:	910dd000 	add	x0, x0, #0x374
    printf("%s: sbrk downsize failed, a %x c %x\n", s, a, c);
    34a0:	aa1303e2 	mov	x2, x19
    34a4:	aa1403e1 	mov	x1, x20
    34a8:	97fff7be 	bl	13a0 <printf@plt>
    exit(1);
    34ac:	17ffffde 	b	3424 <sbrkmuch+0x54>
  a = sbrk(0);
    34b0:	52800000 	mov	w0, #0x0                   	// #0
    34b4:	97fff7f3 	bl	1480 <sbrk@plt>
    34b8:	aa0003f3 	mov	x19, x0
  c = sbrk(PGSIZE);
    34bc:	52820000 	mov	w0, #0x1000                	// #4096
    34c0:	97fff7f0 	bl	1480 <sbrk@plt>
    34c4:	aa0003f6 	mov	x22, x0
  if(c != a || sbrk(0) != a + PGSIZE){
    34c8:	eb00027f 	cmp	x19, x0
    34cc:	540000a0 	b.eq	34e0 <sbrkmuch+0x110>  // b.none
    printf("%s: sbrk re-allocation failed, a %x c %x\n", s, a, c);
    34d0:	f0000000 	adrp	x0, 6000 <run+0x858>
    34d4:	910eb400 	add	x0, x0, #0x3ad
    34d8:	aa1603e3 	mov	x3, x22
    34dc:	17fffff1 	b	34a0 <sbrkmuch+0xd0>
  if(c != a || sbrk(0) != a + PGSIZE){
    34e0:	52800000 	mov	w0, #0x0                   	// #0
    34e4:	97fff7e7 	bl	1480 <sbrk@plt>
    34e8:	91400661 	add	x1, x19, #0x1, lsl #12
    34ec:	eb01001f 	cmp	x0, x1
    34f0:	54ffff01 	b.ne	34d0 <sbrkmuch+0x100>  // b.any
  if(*lastaddr == 99){
    34f4:	394002a0 	ldrb	w0, [x21]
    34f8:	71018c1f 	cmp	w0, #0x63
    34fc:	54000081 	b.ne	350c <sbrkmuch+0x13c>  // b.any
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    3500:	f0000000 	adrp	x0, 6000 <run+0x858>
    3504:	910f5c00 	add	x0, x0, #0x3d7
    3508:	17ffffc5 	b	341c <sbrkmuch+0x4c>
  a = sbrk(0);
    350c:	52800000 	mov	w0, #0x0                   	// #0
    3510:	97fff7dc 	bl	1480 <sbrk@plt>
    3514:	aa0003f3 	mov	x19, x0
  c = sbrk(-(sbrk(0) - oldbrk));
    3518:	52800000 	mov	w0, #0x0                   	// #0
    351c:	97fff7d9 	bl	1480 <sbrk@plt>
    3520:	4b0002e0 	sub	w0, w23, w0
    3524:	97fff7d7 	bl	1480 <sbrk@plt>
    3528:	aa0003e3 	mov	x3, x0
  if(c != a){
    352c:	eb00027f 	cmp	x19, x0
    3530:	54000080 	b.eq	3540 <sbrkmuch+0x170>  // b.none
    printf("%s: sbrk downsize failed, a %x c %x\n", s, a, c);
    3534:	f0000000 	adrp	x0, 6000 <run+0x858>
    3538:	91102000 	add	x0, x0, #0x408
    353c:	17ffffd9 	b	34a0 <sbrkmuch+0xd0>
}
    3540:	f9401bf7 	ldr	x23, [sp, #48]
    3544:	a94153f3 	ldp	x19, x20, [sp, #16]
    3548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    354c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3550:	d65f03c0 	ret

0000000000003554 <sbrkarg>:
{
    3554:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3558:	910003fd 	mov	x29, sp
    355c:	a90153f3 	stp	x19, x20, [sp, #16]
    3560:	aa0003f4 	mov	x20, x0
  a = sbrk(PGSIZE);
    3564:	52820000 	mov	w0, #0x1000                	// #4096
{
    3568:	a9025bf5 	stp	x21, x22, [sp, #32]
  a = sbrk(PGSIZE);
    356c:	97fff7c5 	bl	1480 <sbrk@plt>
  fd = open("sbrk", O_CREATE|O_WRONLY);
    3570:	52804021 	mov	w1, #0x201                 	// #513
    3574:	f0000013 	adrp	x19, 6000 <run+0x858>
  a = sbrk(PGSIZE);
    3578:	aa0003f6 	mov	x22, x0
  fd = open("sbrk", O_CREATE|O_WRONLY);
    357c:	91085a60 	add	x0, x19, #0x216
    3580:	97fff7d4 	bl	14d0 <open@plt>
    3584:	2a0003f5 	mov	w21, w0
  unlink("sbrk");
    3588:	91085a60 	add	x0, x19, #0x216
    358c:	97fff7b5 	bl	1460 <unlink@plt>
  if(fd < 0)  {
    3590:	36f800f5 	tbz	w21, #31, 35ac <sbrkarg+0x58>
    printf("%s: open sbrk failed\n", s);
    3594:	f0000000 	adrp	x0, 6000 <run+0x858>
    3598:	9110b400 	add	x0, x0, #0x42d
    printf("%s: write sbrk failed\n", s);
    359c:	aa1403e1 	mov	x1, x20
    35a0:	97fff780 	bl	13a0 <printf@plt>
    exit(1);
    35a4:	52800020 	mov	w0, #0x1                   	// #1
    35a8:	97fff7c6 	bl	14c0 <exit@plt>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    35ac:	aa1603e1 	mov	x1, x22
    35b0:	2a1503e0 	mov	w0, w21
    35b4:	52820002 	mov	w2, #0x1000                	// #4096
    35b8:	97fff78e 	bl	13f0 <write@plt>
    35bc:	36f80080 	tbz	w0, #31, 35cc <sbrkarg+0x78>
    printf("%s: write sbrk failed\n", s);
    35c0:	f0000000 	adrp	x0, 6000 <run+0x858>
    35c4:	91110c00 	add	x0, x0, #0x443
    35c8:	17fffff5 	b	359c <sbrkarg+0x48>
  close(fd);
    35cc:	2a1503e0 	mov	w0, w21
    35d0:	97fff7c8 	bl	14f0 <close@plt>
  a = sbrk(PGSIZE);
    35d4:	52820000 	mov	w0, #0x1000                	// #4096
    35d8:	97fff7aa 	bl	1480 <sbrk@plt>
  if(pipe((int *) a) != 0){
    35dc:	97fff781 	bl	13e0 <pipe@plt>
    35e0:	34000080 	cbz	w0, 35f0 <sbrkarg+0x9c>
    printf("%s: pipe() failed\n", s);
    35e4:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    35e8:	913b4800 	add	x0, x0, #0xed2
    35ec:	17ffffec 	b	359c <sbrkarg+0x48>
}
    35f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    35f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35fc:	d65f03c0 	ret

0000000000003600 <sbrkbugs>:
{
    3600:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3604:	910003fd 	mov	x29, sp
  int pid = fork();
    3608:	97fff79a 	bl	1470 <fork@plt>
  if(pid < 0){
    360c:	36f800c0 	tbz	w0, #31, 3624 <sbrkbugs+0x24>
    printf("fork failed\n");
    3610:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    3614:	91381400 	add	x0, x0, #0xe05
    3618:	97fff762 	bl	13a0 <printf@plt>
    exit(1);
    361c:	52800020 	mov	w0, #0x1                   	// #1
    exit(0);
    3620:	97fff7a8 	bl	14c0 <exit@plt>
  if(pid == 0){
    3624:	350000c0 	cbnz	w0, 363c <sbrkbugs+0x3c>
    int sz = (uint64) sbrk(0);
    3628:	97fff796 	bl	1480 <sbrk@plt>
    sbrk(-sz);
    362c:	4b0003e0 	neg	w0, w0
    3630:	97fff794 	bl	1480 <sbrk@plt>
    exit(0);
    3634:	52800000 	mov	w0, #0x0                   	// #0
    3638:	17fffffa 	b	3620 <sbrkbugs+0x20>
  wait(0);
    363c:	d2800000 	mov	x0, #0x0                   	// #0
    3640:	97fff780 	bl	1440 <wait@plt>
  pid = fork();
    3644:	97fff78b 	bl	1470 <fork@plt>
  if(pid < 0){
    3648:	37fffe40 	tbnz	w0, #31, 3610 <sbrkbugs+0x10>
  if(pid == 0){
    364c:	350000a0 	cbnz	w0, 3660 <sbrkbugs+0x60>
    int sz = (uint64) sbrk(0);
    3650:	97fff78c 	bl	1480 <sbrk@plt>
    sbrk(-(sz - 3500));
    3654:	5281b581 	mov	w1, #0xdac                 	// #3500
    3658:	4b000020 	sub	w0, w1, w0
    365c:	17fffff5 	b	3630 <sbrkbugs+0x30>
  wait(0);
    3660:	d2800000 	mov	x0, #0x0                   	// #0
    3664:	97fff777 	bl	1440 <wait@plt>
  pid = fork();
    3668:	97fff782 	bl	1470 <fork@plt>
  if(pid < 0){
    366c:	37fffd20 	tbnz	w0, #31, 3610 <sbrkbugs+0x10>
  if(pid == 0){
    3670:	350000e0 	cbnz	w0, 368c <sbrkbugs+0x8c>
    sbrk((10*4096 + 2048) - (uint64)sbrk(0));
    3674:	97fff783 	bl	1480 <sbrk@plt>
    3678:	52950001 	mov	w1, #0xa800                	// #43008
    367c:	4b000020 	sub	w0, w1, w0
    3680:	97fff780 	bl	1480 <sbrk@plt>
    sbrk(-10);
    3684:	12800120 	mov	w0, #0xfffffff6            	// #-10
    3688:	17ffffea 	b	3630 <sbrkbugs+0x30>
  wait(0);
    368c:	d2800000 	mov	x0, #0x0                   	// #0
    3690:	97fff76c 	bl	1440 <wait@plt>
  exit(0);
    3694:	17ffffe8 	b	3634 <sbrkbugs+0x34>

0000000000003698 <sbrklast>:
{
    3698:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  uint64 top = (uint64) sbrk(0);
    369c:	52800000 	mov	w0, #0x0                   	// #0
{
    36a0:	910003fd 	mov	x29, sp
    36a4:	a90153f3 	stp	x19, x20, [sp, #16]
    36a8:	f90013f5 	str	x21, [sp, #32]
  uint64 top = (uint64) sbrk(0);
    36ac:	97fff775 	bl	1480 <sbrk@plt>
  if((top % 4096) != 0)
    36b0:	f2402c00 	ands	x0, x0, #0xfff
    36b4:	54000080 	b.eq	36c4 <sbrklast+0x2c>  // b.none
    sbrk(4096 - (top % 4096));
    36b8:	52820001 	mov	w1, #0x1000                	// #4096
    36bc:	4b000020 	sub	w0, w1, w0
    36c0:	97fff770 	bl	1480 <sbrk@plt>
  sbrk(4096);
    36c4:	52820000 	mov	w0, #0x1000                	// #4096
    36c8:	97fff76e 	bl	1480 <sbrk@plt>
  sbrk(10);
    36cc:	52800140 	mov	w0, #0xa                   	// #10
    36d0:	97fff76c 	bl	1480 <sbrk@plt>
  sbrk(-20);
    36d4:	12800260 	mov	w0, #0xffffffec            	// #-20
    36d8:	97fff76a 	bl	1480 <sbrk@plt>
  top = (uint64) sbrk(0);
    36dc:	52800000 	mov	w0, #0x0                   	// #0
    36e0:	97fff768 	bl	1480 <sbrk@plt>
    36e4:	aa0003f3 	mov	x19, x0
  p[0] = 'x';
    36e8:	52800f00 	mov	w0, #0x78                  	// #120
  int fd = open(p, O_RDWR|O_CREATE);
    36ec:	52804041 	mov	w1, #0x202                 	// #514
  p[0] = 'x';
    36f0:	781c0260 	sturh	w0, [x19, #-64]
  int fd = open(p, O_RDWR|O_CREATE);
    36f4:	d1010260 	sub	x0, x19, #0x40
    36f8:	97fff776 	bl	14d0 <open@plt>
    36fc:	2a0003f5 	mov	w21, w0
  write(fd, p, 1);
    3700:	d1010261 	sub	x1, x19, #0x40
    3704:	52800022 	mov	w2, #0x1                   	// #1
    3708:	97fff73a 	bl	13f0 <write@plt>
  close(fd);
    370c:	2a1503e0 	mov	w0, w21
    3710:	97fff778 	bl	14f0 <close@plt>
  fd = open(p, O_RDWR);
    3714:	52800041 	mov	w1, #0x2                   	// #2
    3718:	d1010260 	sub	x0, x19, #0x40
    371c:	97fff76d 	bl	14d0 <open@plt>
  p[0] = '\0';
    3720:	381c027f 	sturb	wzr, [x19, #-64]
  read(fd, p, 1);
    3724:	d1010261 	sub	x1, x19, #0x40
    3728:	52800022 	mov	w2, #0x1                   	// #1
    372c:	97fff749 	bl	1450 <read@plt>
  if(p[0] != 'x')
    3730:	385c0260 	ldurb	w0, [x19, #-64]
    3734:	7101e01f 	cmp	w0, #0x78
    3738:	54000060 	b.eq	3744 <sbrklast+0xac>  // b.none
    exit(1);
    373c:	52800020 	mov	w0, #0x1                   	// #1
    3740:	97fff760 	bl	14c0 <exit@plt>
}
    3744:	f94013f5 	ldr	x21, [sp, #32]
    3748:	a94153f3 	ldp	x19, x20, [sp, #16]
    374c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3750:	d65f03c0 	ret

0000000000003754 <sbrk8000>:
{
    3754:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  sbrk(0x80000004);
    3758:	52800080 	mov	w0, #0x4                   	// #4
    375c:	72b00000 	movk	w0, #0x8000, lsl #16
{
    3760:	910003fd 	mov	x29, sp
  sbrk(0x80000004);
    3764:	97fff747 	bl	1480 <sbrk@plt>
  volatile char *top = sbrk(0);
    3768:	52800000 	mov	w0, #0x0                   	// #0
    376c:	97fff745 	bl	1480 <sbrk@plt>
  *(top-1) = *(top-1) + 1;
    3770:	385ff001 	ldurb	w1, [x0, #-1]
    3774:	11000421 	add	w1, w1, #0x1
    3778:	381ff001 	sturb	w1, [x0, #-1]
}
    377c:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3780:	d65f03c0 	ret

0000000000003784 <execout>:
{
    3784:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3788:	910003fd 	mov	x29, sp
    378c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(int avail = 0; avail < 15; avail++){
    3790:	52800014 	mov	w20, #0x0                   	// #0
{
    3794:	f90013f5 	str	x21, [sp, #32]
    int pid = fork();
    3798:	97fff736 	bl	1470 <fork@plt>
    379c:	2a0003f3 	mov	w19, w0
    if(pid < 0){
    37a0:	36f800c0 	tbz	w0, #31, 37b8 <execout+0x34>
      printf("fork failed\n");
    37a4:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    37a8:	91381400 	add	x0, x0, #0xe05
    37ac:	97fff6fd 	bl	13a0 <printf@plt>
      exit(1);
    37b0:	52800020 	mov	w0, #0x1                   	// #1
      exit(0);
    37b4:	97fff743 	bl	14c0 <exit@plt>
    } else if(pid == 0){
    37b8:	35000360 	cbnz	w0, 3824 <execout+0xa0>
        *(char*)(a + 4096 - 1) = 1;
    37bc:	52800035 	mov	w21, #0x1                   	// #1
        uint64 a = (uint64) sbrk(4096);
    37c0:	52820000 	mov	w0, #0x1000                	// #4096
    37c4:	97fff72f 	bl	1480 <sbrk@plt>
        if(a == 0xffffffffffffffffLL)
    37c8:	b100041f 	cmn	x0, #0x1
    37cc:	540000c0 	b.eq	37e4 <execout+0x60>  // b.none
        *(char*)(a + 4096 - 1) = 1;
    37d0:	393ffc15 	strb	w21, [x0, #4095]
      while(1){
    37d4:	17fffffb 	b	37c0 <execout+0x3c>
      for(int i = 0; i < avail; i++)
    37d8:	11000673 	add	w19, w19, #0x1
        sbrk(-4096);
    37dc:	1281ffe0 	mov	w0, #0xfffff000            	// #-4096
    37e0:	97fff728 	bl	1480 <sbrk@plt>
      for(int i = 0; i < avail; i++)
    37e4:	6b14027f 	cmp	w19, w20
    37e8:	54ffff81 	b.ne	37d8 <execout+0x54>  // b.any
      close(1);
    37ec:	52800020 	mov	w0, #0x1                   	// #1
    37f0:	97fff740 	bl	14f0 <close@plt>
      char *args[] = { "echo", "x", 0 };
    37f4:	90000020 	adrp	x0, 7000 <run+0x1858>
    37f8:	91184000 	add	x0, x0, #0x610
      exec("/bin/echo", args);
    37fc:	9100e3e1 	add	x1, sp, #0x38
      char *args[] = { "echo", "x", 0 };
    3800:	a9438c02 	ldp	x2, x3, [x0, #56]
    3804:	a9038fe2 	stp	x2, x3, [sp, #56]
    3808:	f9402400 	ldr	x0, [x0, #72]
    380c:	f90027e0 	str	x0, [sp, #72]
      exec("/bin/echo", args);
    3810:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    3814:	91349400 	add	x0, x0, #0xd25
    3818:	97fff706 	bl	1430 <exec@plt>
      exit(0);
    381c:	52800000 	mov	w0, #0x0                   	// #0
    3820:	17ffffe5 	b	37b4 <execout+0x30>
      wait((int*)0);
    3824:	d2800000 	mov	x0, #0x0                   	// #0
  for(int avail = 0; avail < 15; avail++){
    3828:	11000694 	add	w20, w20, #0x1
      wait((int*)0);
    382c:	97fff705 	bl	1440 <wait@plt>
  for(int avail = 0; avail < 15; avail++){
    3830:	71003e9f 	cmp	w20, #0xf
    3834:	54fffb21 	b.ne	3798 <execout+0x14>  // b.any
    3838:	17fffff9 	b	381c <execout+0x98>

000000000000383c <fourteen>:
{
    383c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3840:	910003fd 	mov	x29, sp
    3844:	a90153f3 	stp	x19, x20, [sp, #16]
    3848:	aa0003f3 	mov	x19, x0
  if(mkdir("12345678901234") != 0){
    384c:	f0000014 	adrp	x20, 6000 <run+0x858>
    3850:	91157280 	add	x0, x20, #0x55c
{
    3854:	a9025bf5 	stp	x21, x22, [sp, #32]
    3858:	a90363f7 	stp	x23, x24, [sp, #48]
    385c:	f90023f9 	str	x25, [sp, #64]
  if(mkdir("12345678901234") != 0){
    3860:	97fff720 	bl	14e0 <mkdir@plt>
    3864:	340000e0 	cbz	w0, 3880 <fourteen+0x44>
    printf("%s: mkdir 12345678901234 failed\n", s);
    3868:	f0000000 	adrp	x0, 6000 <run+0x858>
    386c:	91116800 	add	x0, x0, #0x45a
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    3870:	aa1303e1 	mov	x1, x19
    3874:	97fff6cb 	bl	13a0 <printf@plt>
    exit(1);
    3878:	52800020 	mov	w0, #0x1                   	// #1
    387c:	97fff711 	bl	14c0 <exit@plt>
  if(mkdir("12345678901234/123456789012345") != 0){
    3880:	f0000015 	adrp	x21, 6000 <run+0x858>
    3884:	9111eea0 	add	x0, x21, #0x47b
    3888:	97fff716 	bl	14e0 <mkdir@plt>
    388c:	34000080 	cbz	w0, 389c <fourteen+0x60>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    3890:	f0000000 	adrp	x0, 6000 <run+0x858>
    3894:	91126800 	add	x0, x0, #0x49a
    3898:	17fffff6 	b	3870 <fourteen+0x34>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    389c:	f0000016 	adrp	x22, 6000 <run+0x858>
    38a0:	52804001 	mov	w1, #0x200                 	// #512
    38a4:	91132ec0 	add	x0, x22, #0x4cb
    38a8:	97fff70a 	bl	14d0 <open@plt>
  if(fd < 0){
    38ac:	36f80080 	tbz	w0, #31, 38bc <fourteen+0x80>
    printf("%s: create 123456789012345/123456789012345/123456789012345 failed\n", s);
    38b0:	f0000000 	adrp	x0, 6000 <run+0x858>
    38b4:	9113ec00 	add	x0, x0, #0x4fb
    38b8:	17ffffee 	b	3870 <fourteen+0x34>
  close(fd);
    38bc:	97fff70d 	bl	14f0 <close@plt>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    38c0:	f0000017 	adrp	x23, 6000 <run+0x858>
    38c4:	52800001 	mov	w1, #0x0                   	// #0
    38c8:	9114fae0 	add	x0, x23, #0x53e
    38cc:	97fff701 	bl	14d0 <open@plt>
  if(fd < 0){
    38d0:	36f80080 	tbz	w0, #31, 38e0 <fourteen+0xa4>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    38d4:	f0000000 	adrp	x0, 6000 <run+0x858>
    38d8:	9115ac00 	add	x0, x0, #0x56b
    38dc:	17ffffe5 	b	3870 <fourteen+0x34>
  close(fd);
    38e0:	97fff704 	bl	14f0 <close@plt>
  if(mkdir("12345678901234/12345678901234") == 0){
    38e4:	f0000018 	adrp	x24, 6000 <run+0x858>
    38e8:	91153700 	add	x0, x24, #0x54d
    38ec:	97fff6fd 	bl	14e0 <mkdir@plt>
    38f0:	35000080 	cbnz	w0, 3900 <fourteen+0xc4>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    38f4:	f0000000 	adrp	x0, 6000 <run+0x858>
    38f8:	9116a400 	add	x0, x0, #0x5a9
    38fc:	17ffffdd 	b	3870 <fourteen+0x34>
  if(mkdir("123456789012345/12345678901234") == 0){
    3900:	f0000019 	adrp	x25, 6000 <run+0x858>
    3904:	91177720 	add	x0, x25, #0x5dd
    3908:	97fff6f6 	bl	14e0 <mkdir@plt>
    390c:	35000080 	cbnz	w0, 391c <fourteen+0xe0>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    3910:	f0000000 	adrp	x0, 6000 <run+0x858>
    3914:	9117f000 	add	x0, x0, #0x5fc
    3918:	17ffffd6 	b	3870 <fourteen+0x34>
  unlink("123456789012345/12345678901234");
    391c:	91177720 	add	x0, x25, #0x5dd
    3920:	97fff6d0 	bl	1460 <unlink@plt>
  unlink("12345678901234/12345678901234");
    3924:	91153700 	add	x0, x24, #0x54d
    3928:	97fff6ce 	bl	1460 <unlink@plt>
  unlink("12345678901234/12345678901234/12345678901234");
    392c:	9114fae0 	add	x0, x23, #0x53e
    3930:	97fff6cc 	bl	1460 <unlink@plt>
  unlink("123456789012345/123456789012345/123456789012345");
    3934:	91132ec0 	add	x0, x22, #0x4cb
    3938:	97fff6ca 	bl	1460 <unlink@plt>
  unlink("12345678901234/123456789012345");
    393c:	9111eea0 	add	x0, x21, #0x47b
    3940:	97fff6c8 	bl	1460 <unlink@plt>
}
    3944:	f94023f9 	ldr	x25, [sp, #64]
  unlink("12345678901234");
    3948:	91157280 	add	x0, x20, #0x55c
}
    394c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3950:	a94153f3 	ldp	x19, x20, [sp, #16]
    3954:	a94363f7 	ldp	x23, x24, [sp, #48]
    3958:	a8c57bfd 	ldp	x29, x30, [sp], #80
  unlink("12345678901234");
    395c:	17fff6c1 	b	1460 <unlink@plt>

0000000000003960 <iputtest>:
{
    3960:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3964:	910003fd 	mov	x29, sp
    3968:	a90153f3 	stp	x19, x20, [sp, #16]
    396c:	aa0003f3 	mov	x19, x0
  if(mkdir("iputdir") < 0){
    3970:	f0000014 	adrp	x20, 6000 <run+0x858>
    3974:	91198280 	add	x0, x20, #0x660
    3978:	97fff6da 	bl	14e0 <mkdir@plt>
    397c:	36f800e0 	tbz	w0, #31, 3998 <iputtest+0x38>
    printf("%s: mkdir failed\n", s);
    3980:	f0000000 	adrp	x0, 6000 <run+0x858>
    3984:	9118c400 	add	x0, x0, #0x631
    printf("%s: chdir iputdir failed\n", s);
    3988:	aa1303e1 	mov	x1, x19
    398c:	97fff685 	bl	13a0 <printf@plt>
    exit(1);
    3990:	52800020 	mov	w0, #0x1                   	// #1
    3994:	97fff6cb 	bl	14c0 <exit@plt>
  if(chdir("iputdir") < 0){
    3998:	91198280 	add	x0, x20, #0x660
    399c:	97fff6a1 	bl	1420 <chdir@plt>
    39a0:	36f80080 	tbz	w0, #31, 39b0 <iputtest+0x50>
    printf("%s: chdir iputdir failed\n", s);
    39a4:	f0000000 	adrp	x0, 6000 <run+0x858>
    39a8:	91190c00 	add	x0, x0, #0x643
    39ac:	17fffff7 	b	3988 <iputtest+0x28>
  if(unlink("../iputdir") < 0){
    39b0:	f0000000 	adrp	x0, 6000 <run+0x858>
    39b4:	91197400 	add	x0, x0, #0x65d
    39b8:	97fff6aa 	bl	1460 <unlink@plt>
    39bc:	36f80080 	tbz	w0, #31, 39cc <iputtest+0x6c>
    printf("%s: unlink ../iputdir failed\n", s);
    39c0:	f0000000 	adrp	x0, 6000 <run+0x858>
    39c4:	9119a000 	add	x0, x0, #0x668
    39c8:	17fffff0 	b	3988 <iputtest+0x28>
  if(chdir("/") < 0){
    39cc:	f0000000 	adrp	x0, 6000 <run+0x858>
    39d0:	911a1800 	add	x0, x0, #0x686
    39d4:	97fff693 	bl	1420 <chdir@plt>
    39d8:	36f80080 	tbz	w0, #31, 39e8 <iputtest+0x88>
    printf("%s: chdir / failed\n", s);
    39dc:	f0000000 	adrp	x0, 6000 <run+0x858>
    39e0:	911a2000 	add	x0, x0, #0x688
    39e4:	17ffffe9 	b	3988 <iputtest+0x28>
}
    39e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39f0:	d65f03c0 	ret

00000000000039f4 <exitiputtest>:
{
    39f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39f8:	910003fd 	mov	x29, sp
    39fc:	a90153f3 	stp	x19, x20, [sp, #16]
    3a00:	aa0003f3 	mov	x19, x0
  pid = fork();
    3a04:	97fff69b 	bl	1470 <fork@plt>
  if(pid < 0){
    3a08:	36f800e0 	tbz	w0, #31, 3a24 <exitiputtest+0x30>
    printf("%s: fork failed\n", s);
    3a0c:	d0000000 	adrp	x0, 5000 <bigfile+0x108>
    3a10:	91380400 	add	x0, x0, #0xe01
      printf("%s: mkdir failed\n", s);
    3a14:	aa1303e1 	mov	x1, x19
    3a18:	97fff662 	bl	13a0 <printf@plt>
      exit(1);
    3a1c:	52800020 	mov	w0, #0x1                   	// #1
    3a20:	97fff6a8 	bl	14c0 <exit@plt>
  if(pid == 0){
    3a24:	350002e0 	cbnz	w0, 3a80 <exitiputtest+0x8c>
    if(mkdir("iputdir") < 0){
    3a28:	f0000014 	adrp	x20, 6000 <run+0x858>
    3a2c:	91198280 	add	x0, x20, #0x660
    3a30:	97fff6ac 	bl	14e0 <mkdir@plt>
    3a34:	36f80080 	tbz	w0, #31, 3a44 <exitiputtest+0x50>
      printf("%s: mkdir failed\n", s);
    3a38:	f0000000 	adrp	x0, 6000 <run+0x858>
    3a3c:	9118c400 	add	x0, x0, #0x631
    3a40:	17fffff5 	b	3a14 <exitiputtest+0x20>
    if(chdir("iputdir") < 0){
    3a44:	91198280 	add	x0, x20, #0x660
    3a48:	97fff676 	bl	1420 <chdir@plt>
    3a4c:	36f80080 	tbz	w0, #31, 3a5c <exitiputtest+0x68>
      printf("%s: child chdir failed\n", s);
    3a50:	f0000000 	adrp	x0, 6000 <run+0x858>
    3a54:	911a7000 	add	x0, x0, #0x69c
    3a58:	17ffffef 	b	3a14 <exitiputtest+0x20>
    if(unlink("../iputdir") < 0){
    3a5c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3a60:	91197400 	add	x0, x0, #0x65d
    3a64:	97fff67f 	bl	1460 <unlink@plt>
    3a68:	36f80080 	tbz	w0, #31, 3a78 <exitiputtest+0x84>
      printf("%s: unlink ../iputdir failed\n", s);
    3a6c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3a70:	9119a000 	add	x0, x0, #0x668
    3a74:	17ffffe8 	b	3a14 <exitiputtest+0x20>
    exit(0);
    3a78:	52800000 	mov	w0, #0x0                   	// #0
    3a7c:	17ffffe9 	b	3a20 <exitiputtest+0x2c>
  wait(&xstatus);
    3a80:	9100b3e0 	add	x0, sp, #0x2c
    3a84:	97fff66f 	bl	1440 <wait@plt>
  exit(xstatus);
    3a88:	b9402fe0 	ldr	w0, [sp, #44]
    3a8c:	17ffffe5 	b	3a20 <exitiputtest+0x2c>

0000000000003a90 <dirtest>:
{
    3a90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3a94:	910003fd 	mov	x29, sp
    3a98:	a90153f3 	stp	x19, x20, [sp, #16]
    3a9c:	aa0003f4 	mov	x20, x0
  if(mkdir("dir0") < 0){
    3aa0:	f0000013 	adrp	x19, 6000 <run+0x858>
    3aa4:	911ad260 	add	x0, x19, #0x6b4
    3aa8:	97fff68e 	bl	14e0 <mkdir@plt>
    3aac:	36f800e0 	tbz	w0, #31, 3ac8 <dirtest+0x38>
    printf("%s: mkdir failed\n", s);
    3ab0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3ab4:	9118c400 	add	x0, x0, #0x631
    printf("%s: chdir dir0 failed\n", s);
    3ab8:	aa1403e1 	mov	x1, x20
    3abc:	97fff639 	bl	13a0 <printf@plt>
    exit(1);
    3ac0:	52800020 	mov	w0, #0x1                   	// #1
    3ac4:	97fff67f 	bl	14c0 <exit@plt>
  if(chdir("dir0") < 0){
    3ac8:	911ad260 	add	x0, x19, #0x6b4
    3acc:	97fff655 	bl	1420 <chdir@plt>
    3ad0:	36f80080 	tbz	w0, #31, 3ae0 <dirtest+0x50>
    printf("%s: chdir dir0 failed\n", s);
    3ad4:	f0000000 	adrp	x0, 6000 <run+0x858>
    3ad8:	911ae400 	add	x0, x0, #0x6b9
    3adc:	17fffff7 	b	3ab8 <dirtest+0x28>
  if(chdir("..") < 0){
    3ae0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3ae4:	91229c00 	add	x0, x0, #0x8a7
    3ae8:	97fff64e 	bl	1420 <chdir@plt>
    3aec:	36f80080 	tbz	w0, #31, 3afc <dirtest+0x6c>
    printf("%s: chdir .. failed\n", s);
    3af0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3af4:	911b4000 	add	x0, x0, #0x6d0
    3af8:	17fffff0 	b	3ab8 <dirtest+0x28>
  if(unlink("dir0") < 0){
    3afc:	911ad260 	add	x0, x19, #0x6b4
    3b00:	97fff658 	bl	1460 <unlink@plt>
    3b04:	36f80080 	tbz	w0, #31, 3b14 <dirtest+0x84>
    printf("%s: unlink dir0 failed\n", s);
    3b08:	f0000000 	adrp	x0, 6000 <run+0x858>
    3b0c:	911b9400 	add	x0, x0, #0x6e5
    3b10:	17ffffea 	b	3ab8 <dirtest+0x28>
}
    3b14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b18:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3b1c:	d65f03c0 	ret

0000000000003b20 <subdir>:
{
    3b20:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3b24:	910003fd 	mov	x29, sp
    3b28:	a90153f3 	stp	x19, x20, [sp, #16]
    3b2c:	aa0003f3 	mov	x19, x0
    3b30:	a9025bf5 	stp	x21, x22, [sp, #32]
  unlink("ff");
    3b34:	f0000015 	adrp	x21, 6000 <run+0x858>
    3b38:	911ea2a0 	add	x0, x21, #0x7a8
{
    3b3c:	a90363f7 	stp	x23, x24, [sp, #48]
    3b40:	f90023f9 	str	x25, [sp, #64]
  unlink("ff");
    3b44:	97fff647 	bl	1460 <unlink@plt>
  if(mkdir("dd") != 0){
    3b48:	f0000014 	adrp	x20, 6000 <run+0x858>
    3b4c:	91228a80 	add	x0, x20, #0x8a2
    3b50:	97fff664 	bl	14e0 <mkdir@plt>
    3b54:	340000e0 	cbz	w0, 3b70 <subdir+0x50>
    printf("%s: mkdir dd failed\n", s);
    3b58:	f0000000 	adrp	x0, 6000 <run+0x858>
    3b5c:	911bf400 	add	x0, x0, #0x6fd
    printf("%s: create dd/ff failed\n", s);
    3b60:	aa1303e1 	mov	x1, x19
    3b64:	97fff60f 	bl	13a0 <printf@plt>
    exit(1);
    3b68:	52800020 	mov	w0, #0x1                   	// #1
    3b6c:	97fff655 	bl	14c0 <exit@plt>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    3b70:	f0000017 	adrp	x23, 6000 <run+0x858>
    3b74:	52804041 	mov	w1, #0x202                 	// #514
    3b78:	911deae0 	add	x0, x23, #0x77a
    3b7c:	97fff655 	bl	14d0 <open@plt>
    3b80:	2a0003f6 	mov	w22, w0
  if(fd < 0){
    3b84:	36f80080 	tbz	w0, #31, 3b94 <subdir+0x74>
    printf("%s: create dd/ff failed\n", s);
    3b88:	f0000000 	adrp	x0, 6000 <run+0x858>
    3b8c:	911c4800 	add	x0, x0, #0x712
    3b90:	17fffff4 	b	3b60 <subdir+0x40>
  write(fd, "ff", 2);
    3b94:	911ea2a1 	add	x1, x21, #0x7a8
    3b98:	52800042 	mov	w2, #0x2                   	// #2
    3b9c:	97fff615 	bl	13f0 <write@plt>
  close(fd);
    3ba0:	2a1603e0 	mov	w0, w22
    3ba4:	97fff653 	bl	14f0 <close@plt>
  if(unlink("dd") >= 0){
    3ba8:	91228a80 	add	x0, x20, #0x8a2
    3bac:	97fff62d 	bl	1460 <unlink@plt>
    3bb0:	37f80080 	tbnz	w0, #31, 3bc0 <subdir+0xa0>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    3bb4:	f0000000 	adrp	x0, 6000 <run+0x858>
    3bb8:	911cac00 	add	x0, x0, #0x72b
    3bbc:	17ffffe9 	b	3b60 <subdir+0x40>
  if(mkdir("/dd/dd") != 0){
    3bc0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3bc4:	911d5400 	add	x0, x0, #0x755
    3bc8:	97fff646 	bl	14e0 <mkdir@plt>
    3bcc:	34000080 	cbz	w0, 3bdc <subdir+0xbc>
    printf("subdir mkdir dd/dd failed\n", s);
    3bd0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3bd4:	911d7000 	add	x0, x0, #0x75c
    3bd8:	17ffffe2 	b	3b60 <subdir+0x40>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    3bdc:	f0000016 	adrp	x22, 6000 <run+0x858>
    3be0:	52804041 	mov	w1, #0x202                 	// #514
    3be4:	911ddec0 	add	x0, x22, #0x777
    3be8:	97fff63a 	bl	14d0 <open@plt>
    3bec:	2a0003f5 	mov	w21, w0
  if(fd < 0){
    3bf0:	36f80080 	tbz	w0, #31, 3c00 <subdir+0xe0>
    printf("%s: create dd/dd/ff failed\n", s);
    3bf4:	f0000000 	adrp	x0, 6000 <run+0x858>
    3bf8:	911e0000 	add	x0, x0, #0x780
    3bfc:	17ffffd9 	b	3b60 <subdir+0x40>
  write(fd, "FF", 2);
    3c00:	f0000001 	adrp	x1, 6000 <run+0x858>
    3c04:	911e7021 	add	x1, x1, #0x79c
    3c08:	52800042 	mov	w2, #0x2                   	// #2
    3c0c:	97fff5f9 	bl	13f0 <write@plt>
  close(fd);
    3c10:	2a1503e0 	mov	w0, w21
    3c14:	97fff637 	bl	14f0 <close@plt>
  fd = open("dd/dd/../ff", 0);
    3c18:	f0000000 	adrp	x0, 6000 <run+0x858>
    3c1c:	911e7c00 	add	x0, x0, #0x79f
    3c20:	52800001 	mov	w1, #0x0                   	// #0
    3c24:	97fff62b 	bl	14d0 <open@plt>
    3c28:	2a0003f5 	mov	w21, w0
  if(fd < 0){
    3c2c:	36f80080 	tbz	w0, #31, 3c3c <subdir+0x11c>
    printf("%s: open dd/dd/../ff failed\n", s);
    3c30:	f0000000 	adrp	x0, 6000 <run+0x858>
    3c34:	911eac00 	add	x0, x0, #0x7ab
    3c38:	17ffffca 	b	3b60 <subdir+0x40>
  cc = read(fd, buf, sizeof(buf));
    3c3c:	90000058 	adrp	x24, b000 <uninit+0x1cc7>
    3c40:	91292719 	add	x25, x24, #0xa49
    3c44:	aa1903e1 	mov	x1, x25
    3c48:	52860002 	mov	w2, #0x3000                	// #12288
    3c4c:	97fff601 	bl	1450 <read@plt>
  if(cc != 2 || buf[0] != 'f'){
    3c50:	7100081f 	cmp	w0, #0x2
    3c54:	54000081 	b.ne	3c64 <subdir+0x144>  // b.any
    3c58:	39692700 	ldrb	w0, [x24, #2633]
    3c5c:	7101981f 	cmp	w0, #0x66
    3c60:	54000080 	b.eq	3c70 <subdir+0x150>  // b.none
    printf("%s: dd/dd/../ff wrong content\n", s);
    3c64:	f0000000 	adrp	x0, 6000 <run+0x858>
    3c68:	911f2000 	add	x0, x0, #0x7c8
    3c6c:	17ffffbd 	b	3b60 <subdir+0x40>
  close(fd);
    3c70:	2a1503e0 	mov	w0, w21
    3c74:	97fff61f 	bl	14f0 <close@plt>
  if(link("dd/dd/ff", "dd/dd/ffff") != 0){
    3c78:	f0000015 	adrp	x21, 6000 <run+0x858>
    3c7c:	911f9ea1 	add	x1, x21, #0x7e7
    3c80:	911ddec0 	add	x0, x22, #0x777
    3c84:	97fff60b 	bl	14b0 <link@plt>
    3c88:	34000080 	cbz	w0, 3c98 <subdir+0x178>
    printf("link dd/dd/ff dd/dd/ffff failed\n", s);
    3c8c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3c90:	911fc800 	add	x0, x0, #0x7f2
    3c94:	17ffffb3 	b	3b60 <subdir+0x40>
  if(unlink("dd/dd/ff") != 0){
    3c98:	911ddec0 	add	x0, x22, #0x777
    3c9c:	97fff5f1 	bl	1460 <unlink@plt>
    3ca0:	34000080 	cbz	w0, 3cb0 <subdir+0x190>
    printf("%s: unlink dd/dd/ff failed\n", s);
    3ca4:	f0000000 	adrp	x0, 6000 <run+0x858>
    3ca8:	91204c00 	add	x0, x0, #0x813
    3cac:	17ffffad 	b	3b60 <subdir+0x40>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    3cb0:	911ddec0 	add	x0, x22, #0x777
    3cb4:	52800001 	mov	w1, #0x0                   	// #0
    3cb8:	97fff606 	bl	14d0 <open@plt>
    3cbc:	37f80080 	tbnz	w0, #31, 3ccc <subdir+0x1ac>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    3cc0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3cc4:	9120bc00 	add	x0, x0, #0x82f
    3cc8:	17ffffa6 	b	3b60 <subdir+0x40>
  if(chdir("dd") != 0){
    3ccc:	91228a80 	add	x0, x20, #0x8a2
    3cd0:	97fff5d4 	bl	1420 <chdir@plt>
    3cd4:	34000080 	cbz	w0, 3ce4 <subdir+0x1c4>
    printf("%s: chdir dd failed\n", s);
    3cd8:	f0000000 	adrp	x0, 6000 <run+0x858>
    3cdc:	91215c00 	add	x0, x0, #0x857
    3ce0:	17ffffa0 	b	3b60 <subdir+0x40>
  if(chdir("dd/../../dd") != 0){
    3ce4:	f0000000 	adrp	x0, 6000 <run+0x858>
    3ce8:	9121b000 	add	x0, x0, #0x86c
    3cec:	97fff5cd 	bl	1420 <chdir@plt>
    3cf0:	34000080 	cbz	w0, 3d00 <subdir+0x1e0>
    printf("%s: chdir dd/../../dd failed\n", s);
    3cf4:	f0000000 	adrp	x0, 6000 <run+0x858>
    3cf8:	9121e000 	add	x0, x0, #0x878
    3cfc:	17ffff99 	b	3b60 <subdir+0x40>
  if(chdir("dd/../../../dd") != 0){
    3d00:	f0000000 	adrp	x0, 6000 <run+0x858>
    3d04:	91225800 	add	x0, x0, #0x896
    3d08:	97fff5c6 	bl	1420 <chdir@plt>
    3d0c:	34000080 	cbz	w0, 3d1c <subdir+0x1fc>
    printf("chdir dd/../../dd failed\n", s);
    3d10:	f0000000 	adrp	x0, 6000 <run+0x858>
    3d14:	9121f000 	add	x0, x0, #0x87c
    3d18:	17ffff92 	b	3b60 <subdir+0x40>
  if(chdir("./..") != 0){
    3d1c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3d20:	91229400 	add	x0, x0, #0x8a5
    3d24:	97fff5bf 	bl	1420 <chdir@plt>
    3d28:	34000080 	cbz	w0, 3d38 <subdir+0x218>
    printf("%s: chdir ./.. failed\n", s);
    3d2c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3d30:	9122a800 	add	x0, x0, #0x8aa
    3d34:	17ffff8b 	b	3b60 <subdir+0x40>
  fd = open("dd/dd/ffff", 0);
    3d38:	911f9ea0 	add	x0, x21, #0x7e7
    3d3c:	52800001 	mov	w1, #0x0                   	// #0
    3d40:	97fff5e4 	bl	14d0 <open@plt>
    3d44:	2a0003f8 	mov	w24, w0
  if(fd < 0){
    3d48:	36f80080 	tbz	w0, #31, 3d58 <subdir+0x238>
    printf("%s: open dd/dd/ffff failed\n", s);
    3d4c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3d50:	91230400 	add	x0, x0, #0x8c1
    3d54:	17ffff83 	b	3b60 <subdir+0x40>
  if(read(fd, buf, sizeof(buf)) != 2){
    3d58:	aa1903e1 	mov	x1, x25
    3d5c:	52860002 	mov	w2, #0x3000                	// #12288
    3d60:	97fff5bc 	bl	1450 <read@plt>
    3d64:	7100081f 	cmp	w0, #0x2
    3d68:	54000080 	b.eq	3d78 <subdir+0x258>  // b.none
    printf("%s: read dd/dd/ffff wrong len\n", s);
    3d6c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3d70:	91237400 	add	x0, x0, #0x8dd
    3d74:	17ffff7b 	b	3b60 <subdir+0x40>
  close(fd);
    3d78:	2a1803e0 	mov	w0, w24
    3d7c:	97fff5dd 	bl	14f0 <close@plt>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    3d80:	911ddec0 	add	x0, x22, #0x777
    3d84:	52800001 	mov	w1, #0x0                   	// #0
    3d88:	97fff5d2 	bl	14d0 <open@plt>
    3d8c:	37f80080 	tbnz	w0, #31, 3d9c <subdir+0x27c>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    3d90:	f0000000 	adrp	x0, 6000 <run+0x858>
    3d94:	9123f000 	add	x0, x0, #0x8fc
    3d98:	17ffff72 	b	3b60 <subdir+0x40>
  if(open("dd/ff/ff", O_CREATE|O_RDWR) >= 0){
    3d9c:	f0000016 	adrp	x22, 6000 <run+0x858>
    3da0:	52804041 	mov	w1, #0x202                 	// #514
    3da4:	912496c0 	add	x0, x22, #0x925
    3da8:	97fff5ca 	bl	14d0 <open@plt>
    3dac:	37f80080 	tbnz	w0, #31, 3dbc <subdir+0x29c>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    3db0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3db4:	9124b800 	add	x0, x0, #0x92e
    3db8:	17ffff6a 	b	3b60 <subdir+0x40>
  if(open("dd/xx/ff", O_CREATE|O_RDWR) >= 0){
    3dbc:	f0000018 	adrp	x24, 6000 <run+0x858>
    3dc0:	52804041 	mov	w1, #0x202                 	// #514
    3dc4:	91253b00 	add	x0, x24, #0x94e
    3dc8:	97fff5c2 	bl	14d0 <open@plt>
    3dcc:	37f80080 	tbnz	w0, #31, 3ddc <subdir+0x2bc>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    3dd0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3dd4:	91255c00 	add	x0, x0, #0x957
    3dd8:	17ffff62 	b	3b60 <subdir+0x40>
  if(open("dd", O_CREATE) >= 0){
    3ddc:	91228a80 	add	x0, x20, #0x8a2
    3de0:	52804001 	mov	w1, #0x200                 	// #512
    3de4:	97fff5bb 	bl	14d0 <open@plt>
    3de8:	37f80080 	tbnz	w0, #31, 3df8 <subdir+0x2d8>
    printf("%s: create dd succeeded!\n", s);
    3dec:	f0000000 	adrp	x0, 6000 <run+0x858>
    3df0:	9125dc00 	add	x0, x0, #0x977
    3df4:	17ffff5b 	b	3b60 <subdir+0x40>
  if(open("dd", O_RDWR) >= 0){
    3df8:	91228a80 	add	x0, x20, #0x8a2
    3dfc:	52800041 	mov	w1, #0x2                   	// #2
    3e00:	97fff5b4 	bl	14d0 <open@plt>
    3e04:	37f80080 	tbnz	w0, #31, 3e14 <subdir+0x2f4>
    printf("%s: open dd rdwr succeeded!\n", s);
    3e08:	f0000000 	adrp	x0, 6000 <run+0x858>
    3e0c:	91264400 	add	x0, x0, #0x991
    3e10:	17ffff54 	b	3b60 <subdir+0x40>
  if(open("dd", O_WRONLY) >= 0){
    3e14:	91228a80 	add	x0, x20, #0x8a2
    3e18:	52800021 	mov	w1, #0x1                   	// #1
    3e1c:	97fff5ad 	bl	14d0 <open@plt>
    3e20:	37f80080 	tbnz	w0, #31, 3e30 <subdir+0x310>
    printf("%s: open dd wronly succeeded!\n", s);
    3e24:	f0000000 	adrp	x0, 6000 <run+0x858>
    3e28:	9126b800 	add	x0, x0, #0x9ae
    3e2c:	17ffff4d 	b	3b60 <subdir+0x40>
  if(link("dd/ff/ff", "dd/dd/xx") == 0){
    3e30:	f0000014 	adrp	x20, 6000 <run+0x858>
    3e34:	91273681 	add	x1, x20, #0x9cd
    3e38:	912496c0 	add	x0, x22, #0x925
    3e3c:	97fff59d 	bl	14b0 <link@plt>
    3e40:	35000080 	cbnz	w0, 3e50 <subdir+0x330>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    3e44:	f0000000 	adrp	x0, 6000 <run+0x858>
    3e48:	91275800 	add	x0, x0, #0x9d6
    3e4c:	17ffff45 	b	3b60 <subdir+0x40>
  if(link("dd/xx/ff", "dd/dd/xx") == 0){
    3e50:	91273681 	add	x1, x20, #0x9cd
    3e54:	91253b00 	add	x0, x24, #0x94e
    3e58:	97fff596 	bl	14b0 <link@plt>
    3e5c:	35000080 	cbnz	w0, 3e6c <subdir+0x34c>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    3e60:	f0000000 	adrp	x0, 6000 <run+0x858>
    3e64:	9127f400 	add	x0, x0, #0x9fd
    3e68:	17ffff3e 	b	3b60 <subdir+0x40>
  if(link("dd/ff", "dd/dd/ffff") == 0){
    3e6c:	911f9ea1 	add	x1, x21, #0x7e7
    3e70:	911deae0 	add	x0, x23, #0x77a
    3e74:	97fff58f 	bl	14b0 <link@plt>
    3e78:	35000080 	cbnz	w0, 3e88 <subdir+0x368>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    3e7c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3e80:	91289000 	add	x0, x0, #0xa24
    3e84:	17ffff37 	b	3b60 <subdir+0x40>
  if(mkdir("dd/ff/ff") == 0){
    3e88:	912496c0 	add	x0, x22, #0x925
    3e8c:	97fff595 	bl	14e0 <mkdir@plt>
    3e90:	35000080 	cbnz	w0, 3ea0 <subdir+0x380>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    3e94:	f0000000 	adrp	x0, 6000 <run+0x858>
    3e98:	91292800 	add	x0, x0, #0xa4a
    3e9c:	17ffff31 	b	3b60 <subdir+0x40>
  if(mkdir("dd/xx/ff") == 0){
    3ea0:	91253b00 	add	x0, x24, #0x94e
    3ea4:	97fff58f 	bl	14e0 <mkdir@plt>
    3ea8:	35000080 	cbnz	w0, 3eb8 <subdir+0x398>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    3eac:	f0000000 	adrp	x0, 6000 <run+0x858>
    3eb0:	9129a400 	add	x0, x0, #0xa69
    3eb4:	17ffff2b 	b	3b60 <subdir+0x40>
  if(mkdir("dd/dd/ffff") == 0){
    3eb8:	911f9ea0 	add	x0, x21, #0x7e7
    3ebc:	97fff589 	bl	14e0 <mkdir@plt>
    3ec0:	35000080 	cbnz	w0, 3ed0 <subdir+0x3b0>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    3ec4:	f0000000 	adrp	x0, 6000 <run+0x858>
    3ec8:	912a2000 	add	x0, x0, #0xa88
    3ecc:	17ffff25 	b	3b60 <subdir+0x40>
  if(unlink("dd/xx/ff") == 0){
    3ed0:	91253b00 	add	x0, x24, #0x94e
    3ed4:	97fff563 	bl	1460 <unlink@plt>
    3ed8:	35000080 	cbnz	w0, 3ee8 <subdir+0x3c8>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    3edc:	f0000000 	adrp	x0, 6000 <run+0x858>
    3ee0:	912aa400 	add	x0, x0, #0xaa9
    3ee4:	17ffff1f 	b	3b60 <subdir+0x40>
  if(unlink("dd/ff/ff") == 0){
    3ee8:	912496c0 	add	x0, x22, #0x925
    3eec:	97fff55d 	bl	1460 <unlink@plt>
    3ef0:	35000080 	cbnz	w0, 3f00 <subdir+0x3e0>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    3ef4:	f0000000 	adrp	x0, 6000 <run+0x858>
    3ef8:	912b2400 	add	x0, x0, #0xac9
    3efc:	17ffff19 	b	3b60 <subdir+0x40>
  if(chdir("dd/ff") == 0){
    3f00:	911deae0 	add	x0, x23, #0x77a
    3f04:	97fff547 	bl	1420 <chdir@plt>
    3f08:	35000080 	cbnz	w0, 3f18 <subdir+0x3f8>
    printf("%s: chdir dd/ff succeeded!\n", s);
    3f0c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3f10:	912ba400 	add	x0, x0, #0xae9
    3f14:	17ffff13 	b	3b60 <subdir+0x40>
  if(chdir("dd/xx") == 0){
    3f18:	f0000000 	adrp	x0, 6000 <run+0x858>
    3f1c:	91274000 	add	x0, x0, #0x9d0
    3f20:	97fff540 	bl	1420 <chdir@plt>
    3f24:	35000080 	cbnz	w0, 3f34 <subdir+0x414>
    printf("%s: chdir dd/xx succeeded!\n", s);
    3f28:	f0000000 	adrp	x0, 6000 <run+0x858>
    3f2c:	912c1400 	add	x0, x0, #0xb05
    3f30:	17ffff0c 	b	3b60 <subdir+0x40>
  if(unlink("dd/dd/ffff") != 0){
    3f34:	911f9ea0 	add	x0, x21, #0x7e7
    3f38:	97fff54a 	bl	1460 <unlink@plt>
    3f3c:	35ffeb40 	cbnz	w0, 3ca4 <subdir+0x184>
  if(unlink("dd/ff") != 0){
    3f40:	911deae0 	add	x0, x23, #0x77a
    3f44:	97fff547 	bl	1460 <unlink@plt>
    3f48:	34000080 	cbz	w0, 3f58 <subdir+0x438>
    printf("%s: unlink dd/ff failed\n", s);
    3f4c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3f50:	912c8400 	add	x0, x0, #0xb21
    3f54:	17ffff03 	b	3b60 <subdir+0x40>
  if(unlink("dd") == 0){
    3f58:	f0000014 	adrp	x20, 6000 <run+0x858>
    3f5c:	91228a80 	add	x0, x20, #0x8a2
    3f60:	97fff540 	bl	1460 <unlink@plt>
    3f64:	35000080 	cbnz	w0, 3f74 <subdir+0x454>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    3f68:	f0000000 	adrp	x0, 6000 <run+0x858>
    3f6c:	912ce800 	add	x0, x0, #0xb3a
    3f70:	17fffefc 	b	3b60 <subdir+0x40>
  if(unlink("dd/dd") < 0){
    3f74:	f0000000 	adrp	x0, 6000 <run+0x858>
    3f78:	911d5800 	add	x0, x0, #0x756
    3f7c:	97fff539 	bl	1460 <unlink@plt>
    3f80:	36f80080 	tbz	w0, #31, 3f90 <subdir+0x470>
    printf("%s: unlink dd/dd failed\n", s);
    3f84:	f0000000 	adrp	x0, 6000 <run+0x858>
    3f88:	912d7800 	add	x0, x0, #0xb5e
    3f8c:	17fffef5 	b	3b60 <subdir+0x40>
  if(unlink("dd") < 0){
    3f90:	91228a80 	add	x0, x20, #0x8a2
    3f94:	97fff533 	bl	1460 <unlink@plt>
    3f98:	36f80080 	tbz	w0, #31, 3fa8 <subdir+0x488>
    printf("%s: unlink dd failed\n", s);
    3f9c:	f0000000 	adrp	x0, 6000 <run+0x858>
    3fa0:	912ddc00 	add	x0, x0, #0xb77
    3fa4:	17fffeef 	b	3b60 <subdir+0x40>
}
    3fa8:	f94023f9 	ldr	x25, [sp, #64]
    3fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fb0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fb4:	a94363f7 	ldp	x23, x24, [sp, #48]
    3fb8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3fbc:	d65f03c0 	ret

0000000000003fc0 <rmdot>:
{
    3fc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3fc4:	910003fd 	mov	x29, sp
    3fc8:	a90153f3 	stp	x19, x20, [sp, #16]
    3fcc:	aa0003f3 	mov	x19, x0
  if(mkdir("dots") != 0){
    3fd0:	f0000014 	adrp	x20, 6000 <run+0x858>
    3fd4:	912e3680 	add	x0, x20, #0xb8d
    3fd8:	97fff542 	bl	14e0 <mkdir@plt>
    3fdc:	340000e0 	cbz	w0, 3ff8 <rmdot+0x38>
    printf("%s: mkdir dots failed\n", s);
    3fe0:	f0000000 	adrp	x0, 6000 <run+0x858>
    3fe4:	912e4800 	add	x0, x0, #0xb92
    printf("%s: chdir dots failed\n", s);
    3fe8:	aa1303e1 	mov	x1, x19
    3fec:	97fff4ed 	bl	13a0 <printf@plt>
    exit(1);
    3ff0:	52800020 	mov	w0, #0x1                   	// #1
    3ff4:	97fff533 	bl	14c0 <exit@plt>
  if(chdir("dots") != 0){
    3ff8:	912e3680 	add	x0, x20, #0xb8d
    3ffc:	97fff509 	bl	1420 <chdir@plt>
    4000:	34000080 	cbz	w0, 4010 <rmdot+0x50>
    printf("%s: chdir dots failed\n", s);
    4004:	d0000000 	adrp	x0, 6000 <run+0x858>
    4008:	912ea400 	add	x0, x0, #0xba9
    400c:	17fffff7 	b	3fe8 <rmdot+0x28>
  if(unlink(".") == 0){
    4010:	d0000000 	adrp	x0, 6000 <run+0x858>
    4014:	9122a000 	add	x0, x0, #0x8a8
    4018:	97fff512 	bl	1460 <unlink@plt>
    401c:	35000080 	cbnz	w0, 402c <rmdot+0x6c>
    printf("%s: rm . worked!\n", s);
    4020:	d0000000 	adrp	x0, 6000 <run+0x858>
    4024:	912f0000 	add	x0, x0, #0xbc0
    4028:	17fffff0 	b	3fe8 <rmdot+0x28>
  if(unlink("..") == 0){
    402c:	d0000000 	adrp	x0, 6000 <run+0x858>
    4030:	91229c00 	add	x0, x0, #0x8a7
    4034:	97fff50b 	bl	1460 <unlink@plt>
    4038:	35000080 	cbnz	w0, 4048 <rmdot+0x88>
    printf("%s: rm .. worked!\n", s);
    403c:	d0000000 	adrp	x0, 6000 <run+0x858>
    4040:	912f4800 	add	x0, x0, #0xbd2
    4044:	17ffffe9 	b	3fe8 <rmdot+0x28>
  if(chdir("/") != 0){
    4048:	d0000000 	adrp	x0, 6000 <run+0x858>
    404c:	911a1800 	add	x0, x0, #0x686
    4050:	97fff4f4 	bl	1420 <chdir@plt>
    4054:	34000080 	cbz	w0, 4064 <rmdot+0xa4>
    printf("%s: chdir / failed\n", s);
    4058:	d0000000 	adrp	x0, 6000 <run+0x858>
    405c:	911a2000 	add	x0, x0, #0x688
    4060:	17ffffe2 	b	3fe8 <rmdot+0x28>
  if(unlink("dots/.") == 0){
    4064:	d0000000 	adrp	x0, 6000 <run+0x858>
    4068:	912f9400 	add	x0, x0, #0xbe5
    406c:	97fff4fd 	bl	1460 <unlink@plt>
    4070:	35000080 	cbnz	w0, 4080 <rmdot+0xc0>
    printf("%s: unlink dots/. worked!\n", s);
    4074:	d0000000 	adrp	x0, 6000 <run+0x858>
    4078:	912fb000 	add	x0, x0, #0xbec
    407c:	17ffffdb 	b	3fe8 <rmdot+0x28>
  if(unlink("dots/..") == 0){
    4080:	d0000000 	adrp	x0, 6000 <run+0x858>
    4084:	91301c00 	add	x0, x0, #0xc07
    4088:	97fff4f6 	bl	1460 <unlink@plt>
    408c:	35000080 	cbnz	w0, 409c <rmdot+0xdc>
    printf("%s: unlink dots/.. worked!\n", s);
    4090:	d0000000 	adrp	x0, 6000 <run+0x858>
    4094:	91303c00 	add	x0, x0, #0xc0f
    4098:	17ffffd4 	b	3fe8 <rmdot+0x28>
  if(unlink("dots") != 0){
    409c:	912e3680 	add	x0, x20, #0xb8d
    40a0:	97fff4f0 	bl	1460 <unlink@plt>
    40a4:	34000080 	cbz	w0, 40b4 <rmdot+0xf4>
    printf("%s: unlink dots failed!\n", s);
    40a8:	d0000000 	adrp	x0, 6000 <run+0x858>
    40ac:	9130ac00 	add	x0, x0, #0xc2b
    40b0:	17ffffce 	b	3fe8 <rmdot+0x28>
}
    40b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    40b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    40bc:	d65f03c0 	ret

00000000000040c0 <dirfile>:
{
    40c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  fd = open("dirfile", O_CREATE);
    40c4:	52804001 	mov	w1, #0x200                 	// #512
{
    40c8:	910003fd 	mov	x29, sp
    40cc:	a90153f3 	stp	x19, x20, [sp, #16]
    40d0:	aa0003f3 	mov	x19, x0
    40d4:	f90013f5 	str	x21, [sp, #32]
  fd = open("dirfile", O_CREATE);
    40d8:	d0000015 	adrp	x21, 6000 <run+0x858>
    40dc:	913112a0 	add	x0, x21, #0xc44
    40e0:	97fff4fc 	bl	14d0 <open@plt>
  if(fd < 0){
    40e4:	36f800e0 	tbz	w0, #31, 4100 <dirfile+0x40>
    printf("%s: create dirfile failed\n", s);
    40e8:	d0000000 	adrp	x0, 6000 <run+0x858>
    40ec:	91313000 	add	x0, x0, #0xc4c
    printf("%s: chdir dirfile succeeded!\n", s);
    40f0:	aa1303e1 	mov	x1, x19
    40f4:	97fff4ab 	bl	13a0 <printf@plt>
    exit(1);
    40f8:	52800020 	mov	w0, #0x1                   	// #1
    40fc:	97fff4f1 	bl	14c0 <exit@plt>
  close(fd);
    4100:	97fff4fc 	bl	14f0 <close@plt>
  if(chdir("dirfile") == 0){
    4104:	913112a0 	add	x0, x21, #0xc44
    4108:	97fff4c6 	bl	1420 <chdir@plt>
    410c:	35000080 	cbnz	w0, 411c <dirfile+0x5c>
    printf("%s: chdir dirfile succeeded!\n", s);
    4110:	d0000000 	adrp	x0, 6000 <run+0x858>
    4114:	91319c00 	add	x0, x0, #0xc67
    4118:	17fffff6 	b	40f0 <dirfile+0x30>
  fd = open("dirfile/xx", 0);
    411c:	d0000014 	adrp	x20, 6000 <run+0x858>
    4120:	52800001 	mov	w1, #0x0                   	// #0
    4124:	91321680 	add	x0, x20, #0xc85
    4128:	97fff4ea 	bl	14d0 <open@plt>
  if(fd >= 0){
    412c:	37f80080 	tbnz	w0, #31, 413c <dirfile+0x7c>
    printf("%s: create dirfile/xx succeeded!\n", s);
    4130:	d0000000 	adrp	x0, 6000 <run+0x858>
    4134:	91324000 	add	x0, x0, #0xc90
    4138:	17ffffee 	b	40f0 <dirfile+0x30>
  fd = open("dirfile/xx", O_CREATE);
    413c:	91321680 	add	x0, x20, #0xc85
    4140:	52804001 	mov	w1, #0x200                 	// #512
    4144:	97fff4e3 	bl	14d0 <open@plt>
  if(fd >= 0){
    4148:	36ffff40 	tbz	w0, #31, 4130 <dirfile+0x70>
  if(mkdir("dirfile/xx") == 0){
    414c:	91321680 	add	x0, x20, #0xc85
    4150:	97fff4e4 	bl	14e0 <mkdir@plt>
    4154:	35000080 	cbnz	w0, 4164 <dirfile+0xa4>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    4158:	d0000000 	adrp	x0, 6000 <run+0x858>
    415c:	9132c800 	add	x0, x0, #0xcb2
    4160:	17ffffe4 	b	40f0 <dirfile+0x30>
  if(unlink("dirfile/xx") == 0){
    4164:	91321680 	add	x0, x20, #0xc85
    4168:	97fff4be 	bl	1460 <unlink@plt>
    416c:	35000080 	cbnz	w0, 417c <dirfile+0xbc>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    4170:	d0000000 	adrp	x0, 6000 <run+0x858>
    4174:	91334c00 	add	x0, x0, #0xcd3
    4178:	17ffffde 	b	40f0 <dirfile+0x30>
  if(link("README", "dirfile/xx") == 0){
    417c:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4180:	9125a000 	add	x0, x0, #0x968
    4184:	91321681 	add	x1, x20, #0xc85
    4188:	97fff4ca 	bl	14b0 <link@plt>
    418c:	35000080 	cbnz	w0, 419c <dirfile+0xdc>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    4190:	d0000000 	adrp	x0, 6000 <run+0x858>
    4194:	9133d400 	add	x0, x0, #0xcf5
    4198:	17ffffd6 	b	40f0 <dirfile+0x30>
  if(unlink("dirfile") != 0){
    419c:	913112a0 	add	x0, x21, #0xc44
    41a0:	97fff4b0 	bl	1460 <unlink@plt>
    41a4:	34000080 	cbz	w0, 41b4 <dirfile+0xf4>
    printf("%s: unlink dirfile failed!\n", s);
    41a8:	d0000000 	adrp	x0, 6000 <run+0x858>
    41ac:	91346000 	add	x0, x0, #0xd18
    41b0:	17ffffd0 	b	40f0 <dirfile+0x30>
  fd = open(".", O_RDWR);
    41b4:	d0000014 	adrp	x20, 6000 <run+0x858>
    41b8:	52800041 	mov	w1, #0x2                   	// #2
    41bc:	9122a280 	add	x0, x20, #0x8a8
    41c0:	97fff4c4 	bl	14d0 <open@plt>
  if(fd >= 0){
    41c4:	37f80080 	tbnz	w0, #31, 41d4 <dirfile+0x114>
    printf("%s: open . for writing succeeded!\n", s);
    41c8:	d0000000 	adrp	x0, 6000 <run+0x858>
    41cc:	9134d000 	add	x0, x0, #0xd34
    41d0:	17ffffc8 	b	40f0 <dirfile+0x30>
  fd = open(".", 0);
    41d4:	9122a280 	add	x0, x20, #0x8a8
    41d8:	52800001 	mov	w1, #0x0                   	// #0
    41dc:	97fff4bd 	bl	14d0 <open@plt>
    41e0:	2a0003f4 	mov	w20, w0
  if(write(fd, "x", 1) > 0){
    41e4:	d0000001 	adrp	x1, 6000 <run+0x858>
    41e8:	91275021 	add	x1, x1, #0x9d4
    41ec:	52800022 	mov	w2, #0x1                   	// #1
    41f0:	97fff480 	bl	13f0 <write@plt>
    41f4:	7100001f 	cmp	w0, #0x0
    41f8:	5400008d 	b.le	4208 <dirfile+0x148>
    printf("%s: write . succeeded!\n", s);
    41fc:	d0000000 	adrp	x0, 6000 <run+0x858>
    4200:	91355c00 	add	x0, x0, #0xd57
    4204:	17ffffbb 	b	40f0 <dirfile+0x30>
}
    4208:	f94013f5 	ldr	x21, [sp, #32]
  close(fd);
    420c:	2a1403e0 	mov	w0, w20
}
    4210:	a94153f3 	ldp	x19, x20, [sp, #16]
    4214:	a8c37bfd 	ldp	x29, x30, [sp], #48
  close(fd);
    4218:	17fff4b6 	b	14f0 <close@plt>

000000000000421c <iref>:
{
    421c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4220:	910003fd 	mov	x29, sp
    4224:	a90153f3 	stp	x19, x20, [sp, #16]
    if(mkdir("irefd") != 0){
    4228:	d0000013 	adrp	x19, 6000 <run+0x858>
    422c:	9135be73 	add	x19, x19, #0xd6f
    mkdir("");
    4230:	d0000014 	adrp	x20, 6000 <run+0x858>
    4234:	913ad294 	add	x20, x20, #0xeb4
{
    4238:	a90363f7 	stp	x23, x24, [sp, #48]
    link("README", "");
    423c:	b0000017 	adrp	x23, 5000 <bigfile+0x108>
    4240:	9125a2f7 	add	x23, x23, #0x968
{
    4244:	aa0003f8 	mov	x24, x0
    4248:	a9025bf5 	stp	x21, x22, [sp, #32]
    424c:	52800676 	mov	w22, #0x33                  	// #51
    if(mkdir("irefd") != 0){
    4250:	aa1303e0 	mov	x0, x19
    4254:	97fff4a3 	bl	14e0 <mkdir@plt>
    4258:	340000e0 	cbz	w0, 4274 <iref+0x58>
      printf("%s: mkdir irefd failed\n", s);
    425c:	d0000000 	adrp	x0, 6000 <run+0x858>
    4260:	9135d400 	add	x0, x0, #0xd75
      printf("%s: chdir irefd failed\n", s);
    4264:	aa1803e1 	mov	x1, x24
    4268:	97fff44e 	bl	13a0 <printf@plt>
      exit(1);
    426c:	52800020 	mov	w0, #0x1                   	// #1
    4270:	97fff494 	bl	14c0 <exit@plt>
    if(chdir("irefd") != 0){
    4274:	aa1303e0 	mov	x0, x19
    4278:	97fff46a 	bl	1420 <chdir@plt>
    427c:	34000080 	cbz	w0, 428c <iref+0x70>
      printf("%s: chdir irefd failed\n", s);
    4280:	d0000000 	adrp	x0, 6000 <run+0x858>
    4284:	91363400 	add	x0, x0, #0xd8d
    4288:	17fffff7 	b	4264 <iref+0x48>
    mkdir("");
    428c:	aa1403e0 	mov	x0, x20
    4290:	97fff494 	bl	14e0 <mkdir@plt>
    link("README", "");
    4294:	aa1403e1 	mov	x1, x20
    4298:	aa1703e0 	mov	x0, x23
    429c:	97fff485 	bl	14b0 <link@plt>
    fd = open("", O_CREATE);
    42a0:	aa1403e0 	mov	x0, x20
    42a4:	52804001 	mov	w1, #0x200                 	// #512
    42a8:	97fff48a 	bl	14d0 <open@plt>
    if(fd >= 0)
    42ac:	37f80040 	tbnz	w0, #31, 42b4 <iref+0x98>
      close(fd);
    42b0:	97fff490 	bl	14f0 <close@plt>
    fd = open("xx", O_CREATE);
    42b4:	d0000015 	adrp	x21, 6000 <run+0x858>
    42b8:	91274eb5 	add	x21, x21, #0x9d3
    42bc:	aa1503e0 	mov	x0, x21
    42c0:	52804001 	mov	w1, #0x200                 	// #512
    42c4:	97fff483 	bl	14d0 <open@plt>
    if(fd >= 0)
    42c8:	37f80040 	tbnz	w0, #31, 42d0 <iref+0xb4>
      close(fd);
    42cc:	97fff489 	bl	14f0 <close@plt>
    unlink("xx");
    42d0:	aa1503e0 	mov	x0, x21
    42d4:	97fff463 	bl	1460 <unlink@plt>
  for(i = 0; i < NINODE + 1; i++){
    42d8:	710006d6 	subs	w22, w22, #0x1
    42dc:	54fffba1 	b.ne	4250 <iref+0x34>  // b.any
    chdir("..");
    42e0:	d0000015 	adrp	x21, 6000 <run+0x858>
    42e4:	91229eb5 	add	x21, x21, #0x8a7
  for(i = 0; i < NINODE + 1; i++){
    42e8:	52800674 	mov	w20, #0x33                  	// #51
    chdir("..");
    42ec:	aa1503e0 	mov	x0, x21
    42f0:	97fff44c 	bl	1420 <chdir@plt>
    unlink("irefd");
    42f4:	aa1303e0 	mov	x0, x19
    42f8:	97fff45a 	bl	1460 <unlink@plt>
  for(i = 0; i < NINODE + 1; i++){
    42fc:	71000694 	subs	w20, w20, #0x1
    4300:	54ffff61 	b.ne	42ec <iref+0xd0>  // b.any
}
    4304:	a94153f3 	ldp	x19, x20, [sp, #16]
  chdir("/");
    4308:	d0000000 	adrp	x0, 6000 <run+0x858>
    430c:	911a1800 	add	x0, x0, #0x686
}
    4310:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4314:	a94363f7 	ldp	x23, x24, [sp, #48]
    4318:	a8c47bfd 	ldp	x29, x30, [sp], #64
  chdir("/");
    431c:	17fff441 	b	1420 <chdir@plt>

0000000000004320 <openiputtest>:
{
    4320:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4324:	910003fd 	mov	x29, sp
    4328:	a90153f3 	stp	x19, x20, [sp, #16]
  if(mkdir("oidir") < 0){
    432c:	d0000013 	adrp	x19, 6000 <run+0x858>
    4330:	91369673 	add	x19, x19, #0xda5
{
    4334:	aa0003f4 	mov	x20, x0
  if(mkdir("oidir") < 0){
    4338:	aa1303e0 	mov	x0, x19
    433c:	97fff469 	bl	14e0 <mkdir@plt>
    4340:	36f800e0 	tbz	w0, #31, 435c <openiputtest+0x3c>
    printf("%s: mkdir oidir failed\n", s);
    4344:	d0000000 	adrp	x0, 6000 <run+0x858>
    4348:	9136ac00 	add	x0, x0, #0xdab
    printf("%s: fork failed\n", s);
    434c:	aa1403e1 	mov	x1, x20
    4350:	97fff414 	bl	13a0 <printf@plt>
    exit(1);
    4354:	52800020 	mov	w0, #0x1                   	// #1
    4358:	97fff45a 	bl	14c0 <exit@plt>
  pid = fork();
    435c:	97fff445 	bl	1470 <fork@plt>
  if(pid < 0){
    4360:	36f80080 	tbz	w0, #31, 4370 <openiputtest+0x50>
    printf("%s: fork failed\n", s);
    4364:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4368:	91380400 	add	x0, x0, #0xe01
    436c:	17fffff8 	b	434c <openiputtest+0x2c>
  if(pid == 0){
    4370:	35000140 	cbnz	w0, 4398 <openiputtest+0x78>
    int fd = open("oidir", O_RDWR);
    4374:	aa1303e0 	mov	x0, x19
    4378:	52800041 	mov	w1, #0x2                   	// #2
    437c:	97fff455 	bl	14d0 <open@plt>
    if(fd >= 0){
    4380:	37f80080 	tbnz	w0, #31, 4390 <openiputtest+0x70>
      printf("%s: open directory for write succeeded\n", s);
    4384:	d0000000 	adrp	x0, 6000 <run+0x858>
    4388:	91370c00 	add	x0, x0, #0xdc3
    438c:	17fffff0 	b	434c <openiputtest+0x2c>
    exit(0);
    4390:	52800000 	mov	w0, #0x0                   	// #0
    4394:	17fffff1 	b	4358 <openiputtest+0x38>
  sleep_ticks(1);
    4398:	52800020 	mov	w0, #0x1                   	// #1
    439c:	97fff41d 	bl	1410 <sleep_ticks@plt>
  if(unlink("oidir") != 0){
    43a0:	aa1303e0 	mov	x0, x19
    43a4:	97fff42f 	bl	1460 <unlink@plt>
    43a8:	34000080 	cbz	w0, 43b8 <openiputtest+0x98>
    printf("%s: unlink failed\n", s);
    43ac:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    43b0:	913e4000 	add	x0, x0, #0xf90
    43b4:	17ffffe6 	b	434c <openiputtest+0x2c>
  wait(&xstatus);
    43b8:	9100b3e0 	add	x0, sp, #0x2c
    43bc:	97fff421 	bl	1440 <wait@plt>
  exit(xstatus);
    43c0:	b9402fe0 	ldr	w0, [sp, #44]
    43c4:	17ffffe5 	b	4358 <openiputtest+0x38>

00000000000043c8 <forkforkfork>:
{
    43c8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43cc:	910003fd 	mov	x29, sp
    43d0:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("stopforking");
    43d4:	d0000013 	adrp	x19, 6000 <run+0x858>
    43d8:	9137ae73 	add	x19, x19, #0xdeb
{
    43dc:	aa0003f4 	mov	x20, x0
  unlink("stopforking");
    43e0:	aa1303e0 	mov	x0, x19
    43e4:	97fff41f 	bl	1460 <unlink@plt>
  int pid = fork();
    43e8:	97fff422 	bl	1470 <fork@plt>
  if(pid < 0){
    43ec:	36f800e0 	tbz	w0, #31, 4408 <forkforkfork+0x40>
    printf("%s: fork failed", s);
    43f0:	aa1403e1 	mov	x1, x20
    43f4:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    43f8:	913d9c00 	add	x0, x0, #0xf67
    43fc:	97fff3e9 	bl	13a0 <printf@plt>
    exit(1);
    4400:	52800020 	mov	w0, #0x1                   	// #1
        exit(0);
    4404:	97fff42f 	bl	14c0 <exit@plt>
  if(pid == 0){
    4408:	350001c0 	cbnz	w0, 4440 <forkforkfork+0x78>
      int fd = open("stopforking", 0);
    440c:	aa1303e0 	mov	x0, x19
    4410:	52800001 	mov	w1, #0x0                   	// #0
    4414:	97fff42f 	bl	14d0 <open@plt>
      if(fd >= 0){
    4418:	37f80060 	tbnz	w0, #31, 4424 <forkforkfork+0x5c>
        exit(0);
    441c:	52800000 	mov	w0, #0x0                   	// #0
    4420:	17fffff9 	b	4404 <forkforkfork+0x3c>
      if(fork() < 0){
    4424:	97fff413 	bl	1470 <fork@plt>
    4428:	36ffff20 	tbz	w0, #31, 440c <forkforkfork+0x44>
        close(open("stopforking", O_CREATE|O_RDWR));
    442c:	52804041 	mov	w1, #0x202                 	// #514
    4430:	aa1303e0 	mov	x0, x19
    4434:	97fff427 	bl	14d0 <open@plt>
    4438:	97fff42e 	bl	14f0 <close@plt>
    443c:	17fffff4 	b	440c <forkforkfork+0x44>
  sleep_ticks(20); // two seconds
    4440:	52800280 	mov	w0, #0x14                  	// #20
    4444:	97fff3f3 	bl	1410 <sleep_ticks@plt>
  close(open("stopforking", O_CREATE|O_RDWR));
    4448:	52804041 	mov	w1, #0x202                 	// #514
    444c:	aa1303e0 	mov	x0, x19
    4450:	97fff420 	bl	14d0 <open@plt>
    4454:	97fff427 	bl	14f0 <close@plt>
  wait(0);
    4458:	d2800000 	mov	x0, #0x0                   	// #0
    445c:	97fff3f9 	bl	1440 <wait@plt>
}
    4460:	a94153f3 	ldp	x19, x20, [sp, #16]
  sleep_ticks(10); // one second
    4464:	52800140 	mov	w0, #0xa                   	// #10
}
    4468:	a8c27bfd 	ldp	x29, x30, [sp], #32
  sleep_ticks(10); // one second
    446c:	17fff3e9 	b	1410 <sleep_ticks@plt>

0000000000004470 <killstatus>:
{
    4470:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4474:	910003fd 	mov	x29, sp
    4478:	f90013f5 	str	x21, [sp, #32]
    447c:	aa0003f5 	mov	x21, x0
    4480:	a90153f3 	stp	x19, x20, [sp, #16]
    4484:	52800c93 	mov	w19, #0x64                  	// #100
    int pid1 = fork();
    4488:	97fff3fa 	bl	1470 <fork@plt>
    448c:	2a0003f4 	mov	w20, w0
    if(pid1 < 0){
    4490:	36f800e0 	tbz	w0, #31, 44ac <killstatus+0x3c>
      printf("%s: fork failed\n", s);
    4494:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4498:	91380400 	add	x0, x0, #0xe01
       printf("%s: status should be -1\n", s);
    449c:	aa1503e1 	mov	x1, x21
    44a0:	97fff3c0 	bl	13a0 <printf@plt>
       exit(1);
    44a4:	52800020 	mov	w0, #0x1                   	// #1
    44a8:	97fff406 	bl	14c0 <exit@plt>
    if(pid1 == 0){
    44ac:	35000060 	cbnz	w0, 44b8 <killstatus+0x48>
        getpid();
    44b0:	97fff3c0 	bl	13b0 <getpid@plt>
      while(1) {
    44b4:	17ffffff 	b	44b0 <killstatus+0x40>
    sleep_ticks(1);
    44b8:	52800020 	mov	w0, #0x1                   	// #1
    44bc:	97fff3d5 	bl	1410 <sleep_ticks@plt>
    kill(pid1);
    44c0:	2a1403e0 	mov	w0, w20
    44c4:	97fff3cf 	bl	1400 <kill@plt>
    wait(&xst);
    44c8:	9100f3e0 	add	x0, sp, #0x3c
    44cc:	97fff3dd 	bl	1440 <wait@plt>
    if(xst != -1) {
    44d0:	b9403fe0 	ldr	w0, [sp, #60]
    44d4:	3100041f 	cmn	w0, #0x1
    44d8:	54000080 	b.eq	44e8 <killstatus+0x78>  // b.none
       printf("%s: status should be -1\n", s);
    44dc:	d0000000 	adrp	x0, 6000 <run+0x858>
    44e0:	9137dc00 	add	x0, x0, #0xdf7
    44e4:	17ffffee 	b	449c <killstatus+0x2c>
  for(int i = 0; i < 100; i++){
    44e8:	71000673 	subs	w19, w19, #0x1
    44ec:	54fffce1 	b.ne	4488 <killstatus+0x18>  // b.any
  exit(0);
    44f0:	52800000 	mov	w0, #0x0                   	// #0
    44f4:	17ffffed 	b	44a8 <killstatus+0x38>

00000000000044f8 <preempt>:
{
    44f8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44fc:	910003fd 	mov	x29, sp
    4500:	a90153f3 	stp	x19, x20, [sp, #16]
    4504:	aa0003f3 	mov	x19, x0
    4508:	a9025bf5 	stp	x21, x22, [sp, #32]
  pid1 = fork();
    450c:	97fff3d9 	bl	1470 <fork@plt>
  if(pid1 < 0) {
    4510:	36f800e0 	tbz	w0, #31, 452c <preempt+0x34>
    printf("%s: fork failed", s);
    4514:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4518:	913d9c00 	add	x0, x0, #0xf67
    printf("%s: fork failed\n", s);
    451c:	aa1303e1 	mov	x1, x19
    4520:	97fff3a0 	bl	13a0 <printf@plt>
    exit(1);
    4524:	52800020 	mov	w0, #0x1                   	// #1
    4528:	97fff3e6 	bl	14c0 <exit@plt>
    452c:	2a0003f6 	mov	w22, w0
  if(pid1 == 0)
    4530:	35000040 	cbnz	w0, 4538 <preempt+0x40>
    for(;;)
    4534:	14000000 	b	4534 <preempt+0x3c>
  pid2 = fork();
    4538:	97fff3ce 	bl	1470 <fork@plt>
    453c:	2a0003f5 	mov	w21, w0
  if(pid2 < 0) {
    4540:	36f80080 	tbz	w0, #31, 4550 <preempt+0x58>
    printf("%s: fork failed\n", s);
    4544:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4548:	91380400 	add	x0, x0, #0xe01
    454c:	17fffff4 	b	451c <preempt+0x24>
  if(pid2 == 0)
    4550:	35000040 	cbnz	w0, 4558 <preempt+0x60>
    for(;;)
    4554:	14000000 	b	4554 <preempt+0x5c>
  pipe(pfds);
    4558:	9100e3e0 	add	x0, sp, #0x38
    455c:	97fff3a1 	bl	13e0 <pipe@plt>
  pid3 = fork();
    4560:	97fff3c4 	bl	1470 <fork@plt>
    4564:	2a0003f4 	mov	w20, w0
  if(pid3 < 0) {
    4568:	37fffee0 	tbnz	w0, #31, 4544 <preempt+0x4c>
  if(pid3 == 0){
    456c:	35000220 	cbnz	w0, 45b0 <preempt+0xb8>
    close(pfds[0]);
    4570:	b9403be0 	ldr	w0, [sp, #56]
    4574:	97fff3df 	bl	14f0 <close@plt>
    if(write(pfds[1], "x", 1) != 1)
    4578:	b9403fe0 	ldr	w0, [sp, #60]
    457c:	d0000001 	adrp	x1, 6000 <run+0x858>
    4580:	91275021 	add	x1, x1, #0x9d4
    4584:	52800022 	mov	w2, #0x1                   	// #1
    4588:	97fff39a 	bl	13f0 <write@plt>
    458c:	7100041f 	cmp	w0, #0x1
    4590:	540000a0 	b.eq	45a4 <preempt+0xac>  // b.none
      printf("%s: preempt write error", s);
    4594:	d0000000 	adrp	x0, 6000 <run+0x858>
    4598:	91384000 	add	x0, x0, #0xe10
    459c:	aa1303e1 	mov	x1, x19
    45a0:	97fff380 	bl	13a0 <printf@plt>
    close(pfds[1]);
    45a4:	b9403fe0 	ldr	w0, [sp, #60]
    45a8:	97fff3d2 	bl	14f0 <close@plt>
    for(;;)
    45ac:	14000000 	b	45ac <preempt+0xb4>
  close(pfds[1]);
    45b0:	b9403fe0 	ldr	w0, [sp, #60]
    45b4:	97fff3cf 	bl	14f0 <close@plt>
  if(read(pfds[0], buf, sizeof(buf)) != 1){
    45b8:	b9403be0 	ldr	w0, [sp, #56]
    45bc:	f0000021 	adrp	x1, b000 <uninit+0x1cc7>
    45c0:	91292421 	add	x1, x1, #0xa49
    45c4:	52860002 	mov	w2, #0x3000                	// #12288
    45c8:	97fff3a2 	bl	1450 <read@plt>
    45cc:	7100041f 	cmp	w0, #0x1
    45d0:	54000120 	b.eq	45f4 <preempt+0xfc>  // b.none
    printf("%s: preempt read error", s);
    45d4:	d0000000 	adrp	x0, 6000 <run+0x858>
    45d8:	9138a000 	add	x0, x0, #0xe28
    45dc:	aa1303e1 	mov	x1, x19
    45e0:	97fff370 	bl	13a0 <printf@plt>
}
    45e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    45e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    45ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    45f0:	d65f03c0 	ret
  close(pfds[0]);
    45f4:	b9403be0 	ldr	w0, [sp, #56]
    45f8:	97fff3be 	bl	14f0 <close@plt>
  printf("kill... ");
    45fc:	d0000000 	adrp	x0, 6000 <run+0x858>
    4600:	9138fc00 	add	x0, x0, #0xe3f
    4604:	97fff367 	bl	13a0 <printf@plt>
  kill(pid1);
    4608:	2a1603e0 	mov	w0, w22
    460c:	97fff37d 	bl	1400 <kill@plt>
  kill(pid2);
    4610:	2a1503e0 	mov	w0, w21
    4614:	97fff37b 	bl	1400 <kill@plt>
  kill(pid3);
    4618:	2a1403e0 	mov	w0, w20
    461c:	97fff379 	bl	1400 <kill@plt>
  printf("wait... ");
    4620:	d0000000 	adrp	x0, 6000 <run+0x858>
    4624:	91392000 	add	x0, x0, #0xe48
    4628:	97fff35e 	bl	13a0 <printf@plt>
  wait(0);
    462c:	d2800000 	mov	x0, #0x0                   	// #0
    4630:	97fff384 	bl	1440 <wait@plt>
  wait(0);
    4634:	d2800000 	mov	x0, #0x0                   	// #0
    4638:	97fff382 	bl	1440 <wait@plt>
  wait(0);
    463c:	d2800000 	mov	x0, #0x0                   	// #0
    4640:	97fff380 	bl	1440 <wait@plt>
    4644:	17ffffe8 	b	45e4 <preempt+0xec>

0000000000004648 <reparent>:
{
    4648:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    464c:	910003fd 	mov	x29, sp
    4650:	a90153f3 	stp	x19, x20, [sp, #16]
  int master_pid = getpid();
    4654:	52801913 	mov	w19, #0xc8                  	// #200
{
    4658:	a9025bf5 	stp	x21, x22, [sp, #32]
    465c:	aa0003f5 	mov	x21, x0
  int master_pid = getpid();
    4660:	97fff354 	bl	13b0 <getpid@plt>
    4664:	2a0003f6 	mov	w22, w0
    int pid = fork();
    4668:	97fff382 	bl	1470 <fork@plt>
    466c:	2a0003f4 	mov	w20, w0
    if(pid < 0){
    4670:	36f800e0 	tbz	w0, #31, 468c <reparent+0x44>
      printf("%s: fork failed\n", s);
    4674:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4678:	91380400 	add	x0, x0, #0xe01
        printf("%s: wait wrong pid\n", s);
    467c:	aa1503e1 	mov	x1, x21
    4680:	97fff348 	bl	13a0 <printf@plt>
        exit(1);
    4684:	52800020 	mov	w0, #0x1                   	// #1
    4688:	97fff38e 	bl	14c0 <exit@plt>
    if(pid){
    468c:	34000100 	cbz	w0, 46ac <reparent+0x64>
      if(wait(0) != pid){
    4690:	d2800000 	mov	x0, #0x0                   	// #0
    4694:	97fff36b 	bl	1440 <wait@plt>
    4698:	6b14001f 	cmp	w0, w20
    469c:	54000120 	b.eq	46c0 <reparent+0x78>  // b.none
        printf("%s: wait wrong pid\n", s);
    46a0:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    46a4:	913cdc00 	add	x0, x0, #0xf37
    46a8:	17fffff5 	b	467c <reparent+0x34>
      int pid2 = fork();
    46ac:	97fff371 	bl	1470 <fork@plt>
      if(pid2 < 0){
    46b0:	36f800c0 	tbz	w0, #31, 46c8 <reparent+0x80>
        kill(master_pid);
    46b4:	2a1603e0 	mov	w0, w22
    46b8:	97fff352 	bl	1400 <kill@plt>
        exit(1);
    46bc:	17fffff2 	b	4684 <reparent+0x3c>
  for(int i = 0; i < 200; i++){
    46c0:	71000673 	subs	w19, w19, #0x1
    46c4:	54fffd21 	b.ne	4668 <reparent+0x20>  // b.any
      exit(0);
    46c8:	52800000 	mov	w0, #0x0                   	// #0
    46cc:	17ffffef 	b	4688 <reparent+0x40>

00000000000046d0 <sbrkfail>:
{
    46d0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    46d4:	910003fd 	mov	x29, sp
    46d8:	a90153f3 	stp	x19, x20, [sp, #16]
    46dc:	aa0003f3 	mov	x19, x0
  if(pipe(fds) != 0){
    46e0:	910103e0 	add	x0, sp, #0x40
{
    46e4:	a9025bf5 	stp	x21, x22, [sp, #32]
  if(pipe(fds) != 0){
    46e8:	97fff33e 	bl	13e0 <pipe@plt>
    46ec:	35000240 	cbnz	w0, 4734 <sbrkfail+0x64>
    if((pids[i] = fork()) == 0){
    46f0:	910123f5 	add	x21, sp, #0x48
    46f4:	d2800014 	mov	x20, #0x0                   	// #0
    46f8:	97fff35e 	bl	1470 <fork@plt>
    46fc:	b8347aa0 	str	w0, [x21, x20, lsl #2]
    4700:	35000260 	cbnz	w0, 474c <sbrkfail+0x7c>
      sbrk(BIG - (uint64)sbrk(0));
    4704:	97fff35f 	bl	1480 <sbrk@plt>
    4708:	52a0c801 	mov	w1, #0x6400000             	// #104857600
    470c:	4b000020 	sub	w0, w1, w0
    4710:	97fff35c 	bl	1480 <sbrk@plt>
      write(fds[1], "x", 1);
    4714:	b94047e0 	ldr	w0, [sp, #68]
    4718:	d0000001 	adrp	x1, 6000 <run+0x858>
    471c:	91275021 	add	x1, x1, #0x9d4
    4720:	52800022 	mov	w2, #0x1                   	// #1
    4724:	97fff333 	bl	13f0 <write@plt>
      for(;;) sleep_ticks(1000);
    4728:	52807d00 	mov	w0, #0x3e8                 	// #1000
    472c:	97fff339 	bl	1410 <sleep_ticks@plt>
    4730:	17fffffe 	b	4728 <sbrkfail+0x58>
    printf("%s: pipe() failed\n", s);
    4734:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4738:	913b4800 	add	x0, x0, #0xed2
    printf("%s: failed sbrk leaked memory\n", s);
    473c:	aa1303e1 	mov	x1, x19
    4740:	97fff318 	bl	13a0 <printf@plt>
    exit(1);
    4744:	52800020 	mov	w0, #0x1                   	// #1
    4748:	97fff35e 	bl	14c0 <exit@plt>
    if(pids[i] != -1)
    474c:	3100041f 	cmn	w0, #0x1
    4750:	540000a0 	b.eq	4764 <sbrkfail+0x94>  // b.none
      read(fds[0], &scratch, 1);
    4754:	b94043e0 	ldr	w0, [sp, #64]
    4758:	9100efe1 	add	x1, sp, #0x3b
    475c:	52800022 	mov	w2, #0x1                   	// #1
    4760:	97fff33c 	bl	1450 <read@plt>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    4764:	91000694 	add	x20, x20, #0x1
    4768:	f1002a9f 	cmp	x20, #0xa
    476c:	54fffc61 	b.ne	46f8 <sbrkfail+0x28>  // b.any
  c = sbrk(PGSIZE);
    4770:	52820000 	mov	w0, #0x1000                	// #4096
    4774:	97fff343 	bl	1480 <sbrk@plt>
    4778:	aa0003f6 	mov	x22, x0
    477c:	d2800014 	mov	x20, #0x0                   	// #0
    if(pids[i] == -1)
    4780:	b8747aa0 	ldr	w0, [x21, x20, lsl #2]
    4784:	3100041f 	cmn	w0, #0x1
    4788:	54000080 	b.eq	4798 <sbrkfail+0xc8>  // b.none
    kill(pids[i]);
    478c:	97fff31d 	bl	1400 <kill@plt>
    wait(0);
    4790:	d2800000 	mov	x0, #0x0                   	// #0
    4794:	97fff32b 	bl	1440 <wait@plt>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    4798:	91000694 	add	x20, x20, #0x1
    479c:	f1002a9f 	cmp	x20, #0xa
    47a0:	54ffff01 	b.ne	4780 <sbrkfail+0xb0>  // b.any
  if(c == (char*)0xffffffffffffffffL){
    47a4:	b10006df 	cmn	x22, #0x1
    47a8:	54000081 	b.ne	47b8 <sbrkfail+0xe8>  // b.any
    printf("%s: failed sbrk leaked memory\n", s);
    47ac:	d0000000 	adrp	x0, 6000 <run+0x858>
    47b0:	91394400 	add	x0, x0, #0xe51
    47b4:	17ffffe2 	b	473c <sbrkfail+0x6c>
  pid = fork();
    47b8:	97fff32e 	bl	1470 <fork@plt>
    47bc:	2a0003f5 	mov	w21, w0
  if(pid < 0){
    47c0:	36f80080 	tbz	w0, #31, 47d0 <sbrkfail+0x100>
    printf("%s: fork failed\n", s);
    47c4:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    47c8:	91380400 	add	x0, x0, #0xe01
    47cc:	17ffffdc 	b	473c <sbrkfail+0x6c>
  if(pid == 0){
    47d0:	35000240 	cbnz	w0, 4818 <sbrkfail+0x148>
    a = sbrk(0);
    47d4:	97fff32b 	bl	1480 <sbrk@plt>
    47d8:	aa0003f4 	mov	x20, x0
    sbrk(10*BIG);
    47dc:	52a7d000 	mov	w0, #0x3e800000            	// #1048576000
    47e0:	97fff328 	bl	1480 <sbrk@plt>
    47e4:	d2800000 	mov	x0, #0x0                   	// #0
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    47e8:	d2a7d001 	mov	x1, #0x3e800000            	// #1048576000
      n += *(a+i);
    47ec:	38606a83 	ldrb	w3, [x20, x0]
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    47f0:	91400400 	add	x0, x0, #0x1, lsl #12
      n += *(a+i);
    47f4:	0b0302b5 	add	w21, w21, w3
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    47f8:	eb01001f 	cmp	x0, x1
    47fc:	54ffff81 	b.ne	47ec <sbrkfail+0x11c>  // b.any
    printf("%s: allocate a lot of memory succeeded %d\n", s, n);
    4800:	2a1503e2 	mov	w2, w21
    4804:	aa1303e1 	mov	x1, x19
    4808:	d0000000 	adrp	x0, 6000 <run+0x858>
    480c:	9139c000 	add	x0, x0, #0xe70
    4810:	97fff2e4 	bl	13a0 <printf@plt>
    exit(1);
    4814:	17ffffcc 	b	4744 <sbrkfail+0x74>
  wait(&xstatus);
    4818:	9100f3e0 	add	x0, sp, #0x3c
    481c:	97fff309 	bl	1440 <wait@plt>
  if(xstatus != -1 && xstatus != 2)
    4820:	b9403fe0 	ldr	w0, [sp, #60]
    4824:	7100081f 	cmp	w0, #0x2
    4828:	3a411804 	ccmn	w0, #0x1, #0x4, ne	// ne = any
    482c:	54fff8c1 	b.ne	4744 <sbrkfail+0x74>  // b.any
}
    4830:	a94153f3 	ldp	x19, x20, [sp, #16]
    4834:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4838:	a8c77bfd 	ldp	x29, x30, [sp], #112
    483c:	d65f03c0 	ret

0000000000004840 <mem>:
{
    4840:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4844:	910003fd 	mov	x29, sp
    4848:	a90153f3 	stp	x19, x20, [sp, #16]
    484c:	aa0003f4 	mov	x20, x0
    4850:	f90013f5 	str	x21, [sp, #32]
  if((pid = fork()) == 0){
    4854:	97fff307 	bl	1470 <fork@plt>
    4858:	340002c0 	cbz	w0, 48b0 <mem+0x70>
    wait(&xstatus);
    485c:	9100f3e0 	add	x0, sp, #0x3c
    4860:	97fff2f8 	bl	1440 <wait@plt>
    if(xstatus == -1){
    4864:	b9403fe0 	ldr	w0, [sp, #60]
    4868:	3100041f 	cmn	w0, #0x1
    486c:	54000201 	b.ne	48ac <mem+0x6c>  // b.any
    4870:	14000018 	b	48d0 <mem+0x90>
      *(char**)m2 = m1;
    4874:	f9000013 	str	x19, [x0]
      m1 = m2;
    4878:	aa0003f3 	mov	x19, x0
    while((m2 = malloc(10001)) != 0){
    487c:	5284e220 	mov	w0, #0x2711                	// #10001
    4880:	97fff2d4 	bl	13d0 <malloc@plt>
    4884:	b5ffff80 	cbnz	x0, 4874 <mem+0x34>
    while(m1){
    4888:	b5000193 	cbnz	x19, 48b8 <mem+0x78>
    m1 = malloc(1024*20);
    488c:	528a0000 	mov	w0, #0x5000                	// #20480
    4890:	97fff2d0 	bl	13d0 <malloc@plt>
    if(m1 == 0){
    4894:	b50001c0 	cbnz	x0, 48cc <mem+0x8c>
      printf("couldn't allocate mem?!!\n", s);
    4898:	aa1403e1 	mov	x1, x20
    489c:	d0000000 	adrp	x0, 6000 <run+0x858>
    48a0:	913a6c00 	add	x0, x0, #0xe9b
    48a4:	97fff2bf 	bl	13a0 <printf@plt>
      exit(1);
    48a8:	52800020 	mov	w0, #0x1                   	// #1
    exit(0);
    48ac:	97fff305 	bl	14c0 <exit@plt>
    m1 = 0;
    48b0:	d2800013 	mov	x19, #0x0                   	// #0
    48b4:	17fffff2 	b	487c <mem+0x3c>
      m2 = *(char**)m1;
    48b8:	f9400275 	ldr	x21, [x19]
      free(m1);
    48bc:	aa1303e0 	mov	x0, x19
    48c0:	97fff310 	bl	1500 <free@plt>
      m1 = m2;
    48c4:	aa1503f3 	mov	x19, x21
    48c8:	17fffff0 	b	4888 <mem+0x48>
    free(m1);
    48cc:	97fff30d 	bl	1500 <free@plt>
    exit(0);
    48d0:	52800000 	mov	w0, #0x0                   	// #0
    48d4:	17fffff6 	b	48ac <mem+0x6c>

00000000000048d8 <sharedfd>:
{
    48d8:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    48dc:	910003fd 	mov	x29, sp
    48e0:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("sharedfd");
    48e4:	d0000013 	adrp	x19, 6000 <run+0x858>
    48e8:	913ad673 	add	x19, x19, #0xeb5
{
    48ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    48f0:	aa0003f5 	mov	x21, x0
  unlink("sharedfd");
    48f4:	aa1303e0 	mov	x0, x19
{
    48f8:	a90363f7 	stp	x23, x24, [sp, #48]
  unlink("sharedfd");
    48fc:	97fff2d9 	bl	1460 <unlink@plt>
  fd = open("sharedfd", O_CREATE|O_RDWR);
    4900:	aa1303e0 	mov	x0, x19
    4904:	52804041 	mov	w1, #0x202                 	// #514
    4908:	97fff2f2 	bl	14d0 <open@plt>
  if(fd < 0){
    490c:	36f800e0 	tbz	w0, #31, 4928 <sharedfd+0x50>
    printf("%s: cannot open sharedfd for writing", s);
    4910:	d0000000 	adrp	x0, 6000 <run+0x858>
    4914:	913af800 	add	x0, x0, #0xebe
      printf("%s: write sharedfd failed\n", s);
    4918:	aa1503e1 	mov	x1, x21
    491c:	97fff2a1 	bl	13a0 <printf@plt>
      exit(1);
    4920:	52800020 	mov	w0, #0x1                   	// #1
    4924:	97fff2e7 	bl	14c0 <exit@plt>
    4928:	2a0003f7 	mov	w23, w0
  pid = fork();
    492c:	97fff2d1 	bl	1470 <fork@plt>
  memset(buf, pid==0?'c':'p', sizeof(buf));
    4930:	7100001f 	cmp	w0, #0x0
    4934:	52807d14 	mov	w20, #0x3e8                 	// #1000
  pid = fork();
    4938:	2a0003f8 	mov	w24, w0
  memset(buf, pid==0?'c':'p', sizeof(buf));
    493c:	910143f6 	add	x22, sp, #0x50
    4940:	52800c60 	mov	w0, #0x63                  	// #99
    4944:	52800142 	mov	w2, #0xa                   	// #10
    4948:	52800e01 	mov	w1, #0x70                  	// #112
    494c:	1a801021 	csel	w1, w1, w0, ne	// ne = any
    4950:	aa1603e0 	mov	x0, x22
    4954:	97fff2cf 	bl	1490 <memset@plt>
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)){
    4958:	aa1603e1 	mov	x1, x22
    495c:	2a1703e0 	mov	w0, w23
    4960:	52800142 	mov	w2, #0xa                   	// #10
    4964:	97fff2a3 	bl	13f0 <write@plt>
    4968:	7100281f 	cmp	w0, #0xa
    496c:	54000080 	b.eq	497c <sharedfd+0xa4>  // b.none
      printf("%s: write sharedfd failed\n", s);
    4970:	d0000000 	adrp	x0, 6000 <run+0x858>
    4974:	913b8c00 	add	x0, x0, #0xee3
    4978:	17ffffe8 	b	4918 <sharedfd+0x40>
  for(i = 0; i < N; i++){
    497c:	71000694 	subs	w20, w20, #0x1
    4980:	54fffec1 	b.ne	4958 <sharedfd+0x80>  // b.any
  if(pid == 0) {
    4984:	35000078 	cbnz	w24, 4990 <sharedfd+0xb8>
    exit(0);
    4988:	52800000 	mov	w0, #0x0                   	// #0
    498c:	17ffffe6 	b	4924 <sharedfd+0x4c>
    wait(&xstatus);
    4990:	910133e0 	add	x0, sp, #0x4c
    4994:	97fff2ab 	bl	1440 <wait@plt>
    if(xstatus != 0)
    4998:	b9404ff4 	ldr	w20, [sp, #76]
    499c:	34000074 	cbz	w20, 49a8 <sharedfd+0xd0>
      exit(xstatus);
    49a0:	2a1403e0 	mov	w0, w20
    49a4:	17ffffe0 	b	4924 <sharedfd+0x4c>
  close(fd);
    49a8:	2a1703e0 	mov	w0, w23
    49ac:	97fff2d1 	bl	14f0 <close@plt>
  fd = open("sharedfd", 0);
    49b0:	aa1303e0 	mov	x0, x19
    49b4:	52800001 	mov	w1, #0x0                   	// #0
    49b8:	97fff2c6 	bl	14d0 <open@plt>
    49bc:	2a0003f8 	mov	w24, w0
  if(fd < 0){
    49c0:	36f80400 	tbz	w0, #31, 4a40 <sharedfd+0x168>
    printf("%s: cannot open sharedfd for reading\n", s);
    49c4:	d0000000 	adrp	x0, 6000 <run+0x858>
    49c8:	913bf800 	add	x0, x0, #0xefe
    49cc:	17ffffd3 	b	4918 <sharedfd+0x40>
  while((n = read(fd, buf, sizeof(buf))) > 0){
    49d0:	d2800000 	mov	x0, #0x0                   	// #0
      if(buf[i] == 'c')
    49d4:	38606ac1 	ldrb	w1, [x22, x0]
    49d8:	71018c3f 	cmp	w1, #0x63
    49dc:	540002c1 	b.ne	4a34 <sharedfd+0x15c>  // b.any
        nc++;
    49e0:	11000694 	add	w20, w20, #0x1
    for(i = 0; i < sizeof(buf); i++){
    49e4:	91000400 	add	x0, x0, #0x1
    49e8:	f100281f 	cmp	x0, #0xa
    49ec:	54ffff41 	b.ne	49d4 <sharedfd+0xfc>  // b.any
  while((n = read(fd, buf, sizeof(buf))) > 0){
    49f0:	aa1603e1 	mov	x1, x22
    49f4:	2a1803e0 	mov	w0, w24
    49f8:	52800142 	mov	w2, #0xa                   	// #10
    49fc:	97fff295 	bl	1450 <read@plt>
    4a00:	7100001f 	cmp	w0, #0x0
    4a04:	54fffe6c 	b.gt	49d0 <sharedfd+0xf8>
  close(fd);
    4a08:	2a1803e0 	mov	w0, w24
    4a0c:	97fff2b9 	bl	14f0 <close@plt>
  unlink("sharedfd");
    4a10:	aa1303e0 	mov	x0, x19
    4a14:	97fff293 	bl	1460 <unlink@plt>
  if(nc == N*SZ && np == N*SZ){
    4a18:	5284e200 	mov	w0, #0x2710                	// #10000
    4a1c:	6b00029f 	cmp	w20, w0
    4a20:	7a4002e0 	ccmp	w23, w0, #0x0, eq	// eq = none
    4a24:	54fffb20 	b.eq	4988 <sharedfd+0xb0>  // b.none
    printf("%s: nc/np test fails\n", s);
    4a28:	d0000000 	adrp	x0, 6000 <run+0x858>
    4a2c:	913c9000 	add	x0, x0, #0xf24
    4a30:	17ffffba 	b	4918 <sharedfd+0x40>
        np++;
    4a34:	7101c03f 	cmp	w1, #0x70
    4a38:	1a9716f7 	cinc	w23, w23, eq	// eq = none
    4a3c:	17ffffea 	b	49e4 <sharedfd+0x10c>
  nc = np = 0;
    4a40:	52800017 	mov	w23, #0x0                   	// #0
    4a44:	17ffffeb 	b	49f0 <sharedfd+0x118>

0000000000004a48 <fourfiles>:
{
    4a48:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    4a4c:	910003fd 	mov	x29, sp
    4a50:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a54:	aa0003f6 	mov	x22, x0
  char *names[] = { "f0", "f1", "f2", "f3" };
    4a58:	d0000000 	adrp	x0, 6000 <run+0x858>
    4a5c:	913ce800 	add	x0, x0, #0xf3a
    4a60:	f9003be0 	str	x0, [sp, #112]
    4a64:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4a68:	91307000 	add	x0, x0, #0xc1c
{
    4a6c:	a90363f7 	stp	x23, x24, [sp, #48]
    fname = names[pi];
    4a70:	9101c3f8 	add	x24, sp, #0x70
  char *names[] = { "f0", "f1", "f2", "f3" };
    4a74:	f9003fe0 	str	x0, [sp, #120]
    4a78:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4a7c:	91308000 	add	x0, x0, #0xc20
{
    4a80:	a90153f3 	stp	x19, x20, [sp, #16]
  char *names[] = { "f0", "f1", "f2", "f3" };
    4a84:	d2800013 	mov	x19, #0x0                   	// #0
{
    4a88:	a9046bf9 	stp	x25, x26, [sp, #64]
    4a8c:	f9002bfb 	str	x27, [sp, #80]
  char *names[] = { "f0", "f1", "f2", "f3" };
    4a90:	f90043e0 	str	x0, [sp, #128]
    4a94:	d0000000 	adrp	x0, 6000 <run+0x858>
    4a98:	913cf400 	add	x0, x0, #0xf3d
    4a9c:	f90047e0 	str	x0, [sp, #136]
    fname = names[pi];
    4aa0:	f8737b14 	ldr	x20, [x24, x19, lsl #3]
    unlink(fname);
    4aa4:	aa1403e0 	mov	x0, x20
    4aa8:	97fff26e 	bl	1460 <unlink@plt>
    pid = fork();
    4aac:	97fff271 	bl	1470 <fork@plt>
    if(pid < 0){
    4ab0:	36f800e0 	tbz	w0, #31, 4acc <fourfiles+0x84>
      printf("fork failed\n", s);
    4ab4:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4ab8:	91381400 	add	x0, x0, #0xe05
        printf("create failed\n", s);
    4abc:	aa1603e1 	mov	x1, x22
    4ac0:	97fff238 	bl	13a0 <printf@plt>
        exit(1);
    4ac4:	52800020 	mov	w0, #0x1                   	// #1
    4ac8:	97fff27e 	bl	14c0 <exit@plt>
    if(pid == 0){
    4acc:	350003e0 	cbnz	w0, 4b48 <fourfiles+0x100>
      fd = open(fname, O_CREATE | O_RDWR);
    4ad0:	aa1403e0 	mov	x0, x20
    4ad4:	52804041 	mov	w1, #0x202                 	// #514
    4ad8:	97fff27e 	bl	14d0 <open@plt>
    4adc:	2a0003f5 	mov	w21, w0
      if(fd < 0){
    4ae0:	36f80080 	tbz	w0, #31, 4af0 <fourfiles+0xa8>
        printf("create failed\n", s);
    4ae4:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4ae8:	9139ec00 	add	x0, x0, #0xe7b
    4aec:	17fffff4 	b	4abc <fourfiles+0x74>
      memset(buf, '0'+pi, SZ);
    4af0:	1100c261 	add	w1, w19, #0x30
    4af4:	52800193 	mov	w19, #0xc                   	// #12
    4af8:	f0000034 	adrp	x20, b000 <uninit+0x1cc7>
    4afc:	91292694 	add	x20, x20, #0xa49
    4b00:	aa1403e0 	mov	x0, x20
    4b04:	52803e82 	mov	w2, #0x1f4                 	// #500
    4b08:	97fff262 	bl	1490 <memset@plt>
        if((n = write(fd, buf, SZ)) != SZ){
    4b0c:	aa1403e1 	mov	x1, x20
    4b10:	2a1503e0 	mov	w0, w21
    4b14:	52803e82 	mov	w2, #0x1f4                 	// #500
    4b18:	97fff236 	bl	13f0 <write@plt>
    4b1c:	2a0003e1 	mov	w1, w0
    4b20:	7107d01f 	cmp	w0, #0x1f4
    4b24:	540000a0 	b.eq	4b38 <fourfiles+0xf0>  // b.none
          printf("write failed %d\n", n);
    4b28:	d0000000 	adrp	x0, 6000 <run+0x858>
    4b2c:	913d0000 	add	x0, x0, #0xf40
      printf("wrong length %d\n", total);
    4b30:	97fff21c 	bl	13a0 <printf@plt>
      exit(1);
    4b34:	17ffffe4 	b	4ac4 <fourfiles+0x7c>
      for(i = 0; i < N; i++){
    4b38:	71000673 	subs	w19, w19, #0x1
    4b3c:	54fffe81 	b.ne	4b0c <fourfiles+0xc4>  // b.any
      exit(0);
    4b40:	52800000 	mov	w0, #0x0                   	// #0
    4b44:	17ffffe1 	b	4ac8 <fourfiles+0x80>
  for(pi = 0; pi < NCHILD; pi++){
    4b48:	91000673 	add	x19, x19, #0x1
    4b4c:	f100127f 	cmp	x19, #0x4
    4b50:	54fffa81 	b.ne	4aa0 <fourfiles+0x58>  // b.any
    wait(&xstatus);
    4b54:	9101b3e0 	add	x0, sp, #0x6c
    4b58:	97fff23a 	bl	1440 <wait@plt>
    if(xstatus != 0)
    4b5c:	b9406fe0 	ldr	w0, [sp, #108]
    4b60:	35fffb40 	cbnz	w0, 4ac8 <fourfiles+0x80>
  for(pi = 0; pi < NCHILD; pi++){
    4b64:	71000673 	subs	w19, w19, #0x1
    4b68:	54ffff61 	b.ne	4b54 <fourfiles+0x10c>  // b.any
    while((n = read(fd, buf, sizeof(buf))) > 0){
    4b6c:	f0000034 	adrp	x20, b000 <uninit+0x1cc7>
    4b70:	91292694 	add	x20, x20, #0xa49
  for(pi = 0; pi < NCHILD; pi++){
    4b74:	d2800013 	mov	x19, #0x0                   	// #0
    if(total != N*SZ){
    4b78:	5282ee1a 	mov	w26, #0x1770                	// #6000
    fname = names[i];
    4b7c:	f8737b17 	ldr	x23, [x24, x19, lsl #3]
    fd = open(fname, 0);
    4b80:	52800001 	mov	w1, #0x0                   	// #0
        if(buf[j] != '0'+i){
    4b84:	1100c27b 	add	w27, w19, #0x30
    total = 0;
    4b88:	52800015 	mov	w21, #0x0                   	// #0
    fd = open(fname, 0);
    4b8c:	aa1703e0 	mov	x0, x23
    4b90:	97fff250 	bl	14d0 <open@plt>
    4b94:	2a0003f9 	mov	w25, w0
    while((n = read(fd, buf, sizeof(buf))) > 0){
    4b98:	aa1403e1 	mov	x1, x20
    4b9c:	2a1903e0 	mov	w0, w25
    4ba0:	52860002 	mov	w2, #0x3000                	// #12288
    4ba4:	97fff22b 	bl	1450 <read@plt>
    4ba8:	7100001f 	cmp	w0, #0x0
    4bac:	5400012c 	b.gt	4bd0 <fourfiles+0x188>
    close(fd);
    4bb0:	2a1903e0 	mov	w0, w25
    4bb4:	97fff24f 	bl	14f0 <close@plt>
    if(total != N*SZ){
    4bb8:	6b1a02bf 	cmp	w21, w26
    4bbc:	54000220 	b.eq	4c00 <fourfiles+0x1b8>  // b.none
      printf("wrong length %d\n", total);
    4bc0:	d0000000 	adrp	x0, 6000 <run+0x858>
    4bc4:	913d7400 	add	x0, x0, #0xf5d
    4bc8:	2a1503e1 	mov	w1, w21
    4bcc:	17ffffd9 	b	4b30 <fourfiles+0xe8>
    while((n = read(fd, buf, sizeof(buf))) > 0){
    4bd0:	d2800001 	mov	x1, #0x0                   	// #0
        if(buf[j] != '0'+i){
    4bd4:	38616a82 	ldrb	w2, [x20, x1]
    4bd8:	6b1b005f 	cmp	w2, w27
    4bdc:	54000080 	b.eq	4bec <fourfiles+0x1a4>  // b.none
          printf("wrong char\n", s);
    4be0:	d0000000 	adrp	x0, 6000 <run+0x858>
    4be4:	913d4400 	add	x0, x0, #0xf51
    4be8:	17ffffb5 	b	4abc <fourfiles+0x74>
      for(j = 0; j < n; j++){
    4bec:	91000421 	add	x1, x1, #0x1
    4bf0:	6b01001f 	cmp	w0, w1
    4bf4:	54ffff0c 	b.gt	4bd4 <fourfiles+0x18c>
      total += n;
    4bf8:	0b0002b5 	add	w21, w21, w0
    4bfc:	17ffffe7 	b	4b98 <fourfiles+0x150>
    unlink(fname);
    4c00:	aa1703e0 	mov	x0, x23
  for(i = 0; i < NCHILD; i++){
    4c04:	91000673 	add	x19, x19, #0x1
    unlink(fname);
    4c08:	97fff216 	bl	1460 <unlink@plt>
  for(i = 0; i < NCHILD; i++){
    4c0c:	f100127f 	cmp	x19, #0x4
    4c10:	54fffb61 	b.ne	4b7c <fourfiles+0x134>  // b.any
}
    4c14:	f9402bfb 	ldr	x27, [sp, #80]
    4c18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c1c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c20:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c24:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4c28:	a8c97bfd 	ldp	x29, x30, [sp], #144
    4c2c:	d65f03c0 	ret

0000000000004c30 <concreate>:
{
    4c30:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    4c34:	910003fd 	mov	x29, sp
    4c38:	a9025bf5 	stp	x21, x22, [sp, #32]
      link("C0", file);
    4c3c:	d0000016 	adrp	x22, 6000 <run+0x858>
    4c40:	913dbad6 	add	x22, x22, #0xf6e
{
    4c44:	aa0003f5 	mov	x21, x0
  file[0] = 'C';
    4c48:	52800860 	mov	w0, #0x43                  	// #67
{
    4c4c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(i = 0; i < N; i++){
    4c50:	52800013 	mov	w19, #0x0                   	// #0
{
    4c54:	a90363f7 	stp	x23, x24, [sp, #48]
      link("C0", file);
    4c58:	528000b7 	mov	w23, #0x5                   	// #5
  file[0] = 'C';
    4c5c:	390103e0 	strb	w0, [sp, #64]
  file[2] = '\0';
    4c60:	39010bff 	strb	wzr, [sp, #66]
    file[1] = '0' + i;
    4c64:	1100c260 	add	w0, w19, #0x30
    4c68:	390107e0 	strb	w0, [sp, #65]
    unlink(file);
    4c6c:	910103e0 	add	x0, sp, #0x40
    4c70:	97fff1fc 	bl	1460 <unlink@plt>
    pid = fork();
    4c74:	97fff1ff 	bl	1470 <fork@plt>
    4c78:	2a0003f4 	mov	w20, w0
    if(pid && (i % 3) == 1){
    4c7c:	34000220 	cbz	w0, 4cc0 <concreate+0x90>
    4c80:	52800061 	mov	w1, #0x3                   	// #3
    4c84:	1ac10e61 	sdiv	w1, w19, w1
    4c88:	0b010421 	add	w1, w1, w1, lsl #1
    4c8c:	4b010261 	sub	w1, w19, w1
    4c90:	7100043f 	cmp	w1, #0x1
    4c94:	540002c1 	b.ne	4cec <concreate+0xbc>  // b.any
      link("C0", file);
    4c98:	910103e1 	add	x1, sp, #0x40
    4c9c:	aa1603e0 	mov	x0, x22
    4ca0:	97fff204 	bl	14b0 <link@plt>
      wait(&xstatus);
    4ca4:	9101a3f8 	add	x24, sp, #0x68
    4ca8:	aa1803e0 	mov	x0, x24
    4cac:	97fff1e5 	bl	1440 <wait@plt>
      if(xstatus != 0)
    4cb0:	b9406bf4 	ldr	w20, [sp, #104]
    4cb4:	34000354 	cbz	w20, 4d1c <concreate+0xec>
      exit(1);
    4cb8:	52800020 	mov	w0, #0x1                   	// #1
    4cbc:	1400000b 	b	4ce8 <concreate+0xb8>
      link("C0", file);
    4cc0:	1ad70e61 	sdiv	w1, w19, w23
    4cc4:	0b010821 	add	w1, w1, w1, lsl #2
    4cc8:	4b010261 	sub	w1, w19, w1
    } else if(pid == 0 && (i % 5) == 1){
    4ccc:	7100043f 	cmp	w1, #0x1
    4cd0:	540000e1 	b.ne	4cec <concreate+0xbc>  // b.any
      link("C0", file);
    4cd4:	d0000000 	adrp	x0, 6000 <run+0x858>
    4cd8:	913db800 	add	x0, x0, #0xf6e
    4cdc:	910103e1 	add	x1, sp, #0x40
    4ce0:	97fff1f4 	bl	14b0 <link@plt>
      exit(0);
    4ce4:	52800000 	mov	w0, #0x0                   	// #0
    4ce8:	97fff1f6 	bl	14c0 <exit@plt>
      fd = open(file, O_CREATE | O_RDWR);
    4cec:	910103e0 	add	x0, sp, #0x40
    4cf0:	52804041 	mov	w1, #0x202                 	// #514
    4cf4:	97fff1f7 	bl	14d0 <open@plt>
      if(fd < 0){
    4cf8:	36f800c0 	tbz	w0, #31, 4d10 <concreate+0xe0>
        printf("concreate create %s failed\n", file);
    4cfc:	d0000000 	adrp	x0, 6000 <run+0x858>
    4d00:	913dc400 	add	x0, x0, #0xf71
    4d04:	910103e1 	add	x1, sp, #0x40
      printf("%s: fork failed\n", s);
    4d08:	97fff1a6 	bl	13a0 <printf@plt>
    4d0c:	17ffffeb 	b	4cb8 <concreate+0x88>
      close(fd);
    4d10:	97fff1f8 	bl	14f0 <close@plt>
    if(pid == 0) {
    4d14:	35fffc94 	cbnz	w20, 4ca4 <concreate+0x74>
    4d18:	17fffff3 	b	4ce4 <concreate+0xb4>
  for(i = 0; i < N; i++){
    4d1c:	11000673 	add	w19, w19, #0x1
    4d20:	7100a27f 	cmp	w19, #0x28
    4d24:	54fffa01 	b.ne	4c64 <concreate+0x34>  // b.any
  memset(fa, 0, sizeof(fa));
    4d28:	2a1303e2 	mov	w2, w19
    4d2c:	52800001 	mov	w1, #0x0                   	// #0
    4d30:	aa1803e0 	mov	x0, x24
    4d34:	97fff1d7 	bl	1490 <memset@plt>
  fd = open(".", 0);
    4d38:	d0000000 	adrp	x0, 6000 <run+0x858>
    4d3c:	9122a000 	add	x0, x0, #0x8a8
    4d40:	52800001 	mov	w1, #0x0                   	// #0
    4d44:	97fff1e3 	bl	14d0 <open@plt>
    4d48:	2a0003f6 	mov	w22, w0
  n = 0;
    4d4c:	52800013 	mov	w19, #0x0                   	// #0
      fa[i] = 1;
    4d50:	52800037 	mov	w23, #0x1                   	// #1
  while(read(fd, &de, sizeof(de)) > 0){
    4d54:	910123e1 	add	x1, sp, #0x48
    4d58:	2a1603e0 	mov	w0, w22
    4d5c:	52800402 	mov	w2, #0x20                  	// #32
    4d60:	97fff1bc 	bl	1450 <read@plt>
    4d64:	7100001f 	cmp	w0, #0x0
    4d68:	540001cc 	b.gt	4da0 <concreate+0x170>
  close(fd);
    4d6c:	2a1603e0 	mov	w0, w22
    4d70:	97fff1e0 	bl	14f0 <close@plt>
  if(n != N){
    4d74:	7100a27f 	cmp	w19, #0x28
    4d78:	54000481 	b.ne	4e08 <concreate+0x1d8>  // b.any
    if(((i % 3) == 0 && pid == 0) ||
    4d7c:	52800076 	mov	w22, #0x3                   	// #3
    file[1] = '0' + i;
    4d80:	1100c280 	add	w0, w20, #0x30
    4d84:	390107e0 	strb	w0, [sp, #65]
    pid = fork();
    4d88:	97fff1ba 	bl	1470 <fork@plt>
    4d8c:	2a0003f3 	mov	w19, w0
    if(pid < 0){
    4d90:	36f80440 	tbz	w0, #31, 4e18 <concreate+0x1e8>
      printf("%s: fork failed\n", s);
    4d94:	b0000000 	adrp	x0, 5000 <bigfile+0x108>
    4d98:	91380400 	add	x0, x0, #0xe01
    4d9c:	1400001d 	b	4e10 <concreate+0x1e0>
    if(de.inum == 0)
    4da0:	794093e0 	ldrh	w0, [sp, #72]
    4da4:	34fffd80 	cbz	w0, 4d54 <concreate+0x124>
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    4da8:	39412be0 	ldrb	w0, [sp, #74]
    4dac:	71010c1f 	cmp	w0, #0x43
    4db0:	54fffd21 	b.ne	4d54 <concreate+0x124>  // b.any
    4db4:	394133e0 	ldrb	w0, [sp, #76]
    4db8:	35fffce0 	cbnz	w0, 4d54 <concreate+0x124>
      i = de.name[1] - '0';
    4dbc:	39412fe0 	ldrb	w0, [sp, #75]
    4dc0:	5100c000 	sub	w0, w0, #0x30
      if(i < 0 || i >= sizeof(fa)){
    4dc4:	71009c1f 	cmp	w0, #0x27
    4dc8:	540000e9 	b.ls	4de4 <concreate+0x1b4>  // b.plast
        printf("%s: concreate weird file %s\n", s, de.name);
    4dcc:	d0000000 	adrp	x0, 6000 <run+0x858>
    4dd0:	913e3400 	add	x0, x0, #0xf8d
        printf("%s: concreate duplicate file %s\n", s, de.name);
    4dd4:	91012be2 	add	x2, sp, #0x4a
    4dd8:	aa1503e1 	mov	x1, x21
    4ddc:	97fff171 	bl	13a0 <printf@plt>
        exit(1);
    4de0:	17ffffb6 	b	4cb8 <concreate+0x88>
      if(fa[i]){
    4de4:	2a0003e1 	mov	w1, w0
    4de8:	38604b00 	ldrb	w0, [x24, w0, uxtw]
    4dec:	34000080 	cbz	w0, 4dfc <concreate+0x1cc>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    4df0:	d0000000 	adrp	x0, 6000 <run+0x858>
    4df4:	913ea800 	add	x0, x0, #0xfaa
    4df8:	17fffff7 	b	4dd4 <concreate+0x1a4>
      n++;
    4dfc:	11000673 	add	w19, w19, #0x1
      fa[i] = 1;
    4e00:	38216b17 	strb	w23, [x24, x1]
      n++;
    4e04:	17ffffd4 	b	4d54 <concreate+0x124>
    printf("%s: concreate not enough files in directory listing\n", s);
    4e08:	d0000000 	adrp	x0, 6000 <run+0x858>
    4e0c:	913f2c00 	add	x0, x0, #0xfcb
      printf("%s: fork failed\n", s);
    4e10:	aa1503e1 	mov	x1, x21
    4e14:	17ffffbd 	b	4d08 <concreate+0xd8>
    if(((i % 3) == 0 && pid == 0) ||
    4e18:	1ad60a80 	udiv	w0, w20, w22
    4e1c:	0b000400 	add	w0, w0, w0, lsl #1
    4e20:	4b000280 	sub	w0, w20, w0
    4e24:	2a130001 	orr	w1, w0, w19
    4e28:	34000081 	cbz	w1, 4e38 <concreate+0x208>
    4e2c:	7100041f 	cmp	w0, #0x1
    4e30:	540004a1 	b.ne	4ec4 <concreate+0x294>  // b.any
       ((i % 3) == 1 && pid != 0)){
    4e34:	34000493 	cbz	w19, 4ec4 <concreate+0x294>
      close(open(file, 0));
    4e38:	52800001 	mov	w1, #0x0                   	// #0
    4e3c:	910103e0 	add	x0, sp, #0x40
    4e40:	97fff1a4 	bl	14d0 <open@plt>
    4e44:	97fff1ab 	bl	14f0 <close@plt>
      close(open(file, 0));
    4e48:	52800001 	mov	w1, #0x0                   	// #0
    4e4c:	910103e0 	add	x0, sp, #0x40
    4e50:	97fff1a0 	bl	14d0 <open@plt>
    4e54:	97fff1a7 	bl	14f0 <close@plt>
      close(open(file, 0));
    4e58:	52800001 	mov	w1, #0x0                   	// #0
    4e5c:	910103e0 	add	x0, sp, #0x40
    4e60:	97fff19c 	bl	14d0 <open@plt>
    4e64:	97fff1a3 	bl	14f0 <close@plt>
      close(open(file, 0));
    4e68:	52800001 	mov	w1, #0x0                   	// #0
    4e6c:	910103e0 	add	x0, sp, #0x40
    4e70:	97fff198 	bl	14d0 <open@plt>
    4e74:	97fff19f 	bl	14f0 <close@plt>
      close(open(file, 0));
    4e78:	52800001 	mov	w1, #0x0                   	// #0
    4e7c:	910103e0 	add	x0, sp, #0x40
    4e80:	97fff194 	bl	14d0 <open@plt>
    4e84:	97fff19b 	bl	14f0 <close@plt>
      close(open(file, 0));
    4e88:	52800001 	mov	w1, #0x0                   	// #0
    4e8c:	910103e0 	add	x0, sp, #0x40
    4e90:	97fff190 	bl	14d0 <open@plt>
    4e94:	97fff197 	bl	14f0 <close@plt>
    if(pid == 0)
    4e98:	34fff273 	cbz	w19, 4ce4 <concreate+0xb4>
      wait(0);
    4e9c:	d2800000 	mov	x0, #0x0                   	// #0
  for(i = 0; i < N; i++){
    4ea0:	11000694 	add	w20, w20, #0x1
      wait(0);
    4ea4:	97fff167 	bl	1440 <wait@plt>
  for(i = 0; i < N; i++){
    4ea8:	7100a29f 	cmp	w20, #0x28
    4eac:	54fff6a1 	b.ne	4d80 <concreate+0x150>  // b.any
}
    4eb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eb4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4eb8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ebc:	a8c97bfd 	ldp	x29, x30, [sp], #144
    4ec0:	d65f03c0 	ret
      unlink(file);
    4ec4:	910103e0 	add	x0, sp, #0x40
    4ec8:	97fff166 	bl	1460 <unlink@plt>
      unlink(file);
    4ecc:	910103e0 	add	x0, sp, #0x40
    4ed0:	97fff164 	bl	1460 <unlink@plt>
      unlink(file);
    4ed4:	910103e0 	add	x0, sp, #0x40
    4ed8:	97fff162 	bl	1460 <unlink@plt>
      unlink(file);
    4edc:	910103e0 	add	x0, sp, #0x40
    4ee0:	97fff160 	bl	1460 <unlink@plt>
      unlink(file);
    4ee4:	910103e0 	add	x0, sp, #0x40
    4ee8:	97fff15e 	bl	1460 <unlink@plt>
      unlink(file);
    4eec:	910103e0 	add	x0, sp, #0x40
    4ef0:	97fff15c 	bl	1460 <unlink@plt>
    4ef4:	17ffffe9 	b	4e98 <concreate+0x268>

0000000000004ef8 <bigfile>:
{
    4ef8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4efc:	910003fd 	mov	x29, sp
    4f00:	a9025bf5 	stp	x21, x22, [sp, #32]
  unlink("bigfile.dat");
    4f04:	f0000015 	adrp	x21, 7000 <run+0x1858>
    4f08:	910002b5 	add	x21, x21, #0x0
{
    4f0c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f10:	aa0003f3 	mov	x19, x0
  unlink("bigfile.dat");
    4f14:	aa1503e0 	mov	x0, x21
{
    4f18:	f9001bf7 	str	x23, [sp, #48]
  unlink("bigfile.dat");
    4f1c:	97fff151 	bl	1460 <unlink@plt>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    4f20:	aa1503e0 	mov	x0, x21
    4f24:	52804041 	mov	w1, #0x202                 	// #514
    4f28:	97fff16a 	bl	14d0 <open@plt>
  if(fd < 0){
    4f2c:	37f80240 	tbnz	w0, #31, 4f74 <bigfile+0x7c>
    memset(buf, i, SZ);
    4f30:	f0000034 	adrp	x20, b000 <uninit+0x1cc7>
    4f34:	91292694 	add	x20, x20, #0xa49
    4f38:	2a0003f7 	mov	w23, w0
    4f3c:	52800016 	mov	w22, #0x0                   	// #0
    4f40:	2a1603e1 	mov	w1, w22
    4f44:	52804b02 	mov	w2, #0x258                 	// #600
    4f48:	aa1403e0 	mov	x0, x20
    4f4c:	97fff151 	bl	1490 <memset@plt>
    if(write(fd, buf, SZ) != SZ){
    4f50:	aa1403e1 	mov	x1, x20
    4f54:	2a1703e0 	mov	w0, w23
    4f58:	52804b02 	mov	w2, #0x258                 	// #600
    4f5c:	97fff125 	bl	13f0 <write@plt>
    4f60:	7109601f 	cmp	w0, #0x258
    4f64:	54000140 	b.eq	4f8c <bigfile+0x94>  // b.none
      printf("%s: write bigfile failed\n", s);
    4f68:	f0000000 	adrp	x0, 7000 <run+0x1858>
    4f6c:	91009800 	add	x0, x0, #0x26
    4f70:	14000003 	b	4f7c <bigfile+0x84>
    printf("%s: cannot create bigfile", s);
    4f74:	f0000000 	adrp	x0, 7000 <run+0x1858>
    4f78:	91003000 	add	x0, x0, #0xc
      printf("%s: write bigfile failed\n", s);
    4f7c:	aa1303e1 	mov	x1, x19
    4f80:	97fff108 	bl	13a0 <printf@plt>
      exit(1);
    4f84:	52800020 	mov	w0, #0x1                   	// #1
    4f88:	97fff14e 	bl	14c0 <exit@plt>
  for(i = 0; i < N; i++){
    4f8c:	110006d6 	add	w22, w22, #0x1
    4f90:	710052df 	cmp	w22, #0x14
    4f94:	54fffd61 	b.ne	4f40 <bigfile+0x48>  // b.any
  close(fd);
    4f98:	2a1703e0 	mov	w0, w23
    4f9c:	97fff155 	bl	14f0 <close@plt>
  fd = open("bigfile.dat", 0);
    4fa0:	aa1503e0 	mov	x0, x21
    4fa4:	52800001 	mov	w1, #0x0                   	// #0
  for(i = 0; ; i++){
    4fa8:	52800016 	mov	w22, #0x0                   	// #0
  fd = open("bigfile.dat", 0);
    4fac:	97fff149 	bl	14d0 <open@plt>
    4fb0:	2a0003f7 	mov	w23, w0
  if(fd < 0){
    4fb4:	36f80280 	tbz	w0, #31, 5004 <bigfile+0x10c>
    printf("%s: cannot open bigfile\n", s);
    4fb8:	f0000000 	adrp	x0, 7000 <run+0x1858>
    4fbc:	91010000 	add	x0, x0, #0x40
    4fc0:	17ffffef 	b	4f7c <bigfile+0x84>
    if(cc == 0)
    4fc4:	34000300 	cbz	w0, 5024 <bigfile+0x12c>
    if(cc != SZ/2){
    4fc8:	7104b01f 	cmp	w0, #0x12c
    4fcc:	54000080 	b.eq	4fdc <bigfile+0xe4>  // b.none
      printf("%s: short read bigfile\n", s);
    4fd0:	f0000000 	adrp	x0, 7000 <run+0x1858>
    4fd4:	9101c800 	add	x0, x0, #0x72
    4fd8:	17ffffe9 	b	4f7c <bigfile+0x84>
    if(buf[0] != i/2 || buf[SZ/2-1] != i/2){
    4fdc:	39400280 	ldrb	w0, [x20]
    4fe0:	6b96041f 	cmp	w0, w22, asr #1
    4fe4:	54000080 	b.eq	4ff4 <bigfile+0xfc>  // b.none
      printf("%s: read bigfile wrong data\n", s);
    4fe8:	f0000000 	adrp	x0, 7000 <run+0x1858>
    4fec:	91022800 	add	x0, x0, #0x8a
    4ff0:	17ffffe3 	b	4f7c <bigfile+0x84>
    if(buf[0] != i/2 || buf[SZ/2-1] != i/2){
    4ff4:	3944ae81 	ldrb	w1, [x20, #299]
    4ff8:	6b01001f 	cmp	w0, w1
    4ffc:	54ffff61 	b.ne	4fe8 <bigfile+0xf0>  // b.any
  for(i = 0; ; i++){
    5000:	110006d6 	add	w22, w22, #0x1
    cc = read(fd, buf, SZ/2);
    5004:	aa1403e1 	mov	x1, x20
    5008:	2a1703e0 	mov	w0, w23
    500c:	52802582 	mov	w2, #0x12c                 	// #300
    5010:	97fff110 	bl	1450 <read@plt>
    if(cc < 0){
    5014:	36fffd80 	tbz	w0, #31, 4fc4 <bigfile+0xcc>
      printf("%s: read bigfile failed\n", s);
    5018:	d0000000 	adrp	x0, 7000 <run+0x1858>
    501c:	91016400 	add	x0, x0, #0x59
    5020:	17ffffd7 	b	4f7c <bigfile+0x84>
  close(fd);
    5024:	2a1703e0 	mov	w0, w23
    5028:	97fff132 	bl	14f0 <close@plt>
  if(total != N*SZ){
    502c:	52802580 	mov	w0, #0x12c                 	// #300
    5030:	1b007ed6 	mul	w22, w22, w0
    5034:	5285dc00 	mov	w0, #0x2ee0                	// #12000
    5038:	6b0002df 	cmp	w22, w0
    503c:	54000080 	b.eq	504c <bigfile+0x154>  // b.none
    printf("%s: read bigfile wrong total\n", s);
    5040:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5044:	91029c00 	add	x0, x0, #0xa7
    5048:	17ffffcd 	b	4f7c <bigfile+0x84>
}
    504c:	f9401bf7 	ldr	x23, [sp, #48]
  unlink("bigfile.dat");
    5050:	aa1503e0 	mov	x0, x21
}
    5054:	a94153f3 	ldp	x19, x20, [sp, #16]
    5058:	a9425bf5 	ldp	x21, x22, [sp, #32]
    505c:	a8c47bfd 	ldp	x29, x30, [sp], #64
  unlink("bigfile.dat");
    5060:	17fff100 	b	1460 <unlink@plt>

0000000000005064 <bsstest>:
    if(uninit[i] != '\0'){
    5064:	90000023 	adrp	x3, 9000 <big.0+0xcc8>
    5068:	910ce463 	add	x3, x3, #0x339
{
    506c:	d2800002 	mov	x2, #0x0                   	// #0
  for(i = 0; i < sizeof(uninit); i++){
    5070:	d284e201 	mov	x1, #0x2710                	// #10000
    if(uninit[i] != '\0'){
    5074:	38626864 	ldrb	w4, [x3, x2]
    5078:	34000124 	cbz	w4, 509c <bsstest+0x38>
{
    507c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5080:	aa0003e1 	mov	x1, x0
      printf("%s: bss test failed\n", s);
    5084:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5088:	91031400 	add	x0, x0, #0xc5
{
    508c:	910003fd 	mov	x29, sp
      printf("%s: bss test failed\n", s);
    5090:	97fff0c4 	bl	13a0 <printf@plt>
      exit(1);
    5094:	52800020 	mov	w0, #0x1                   	// #1
    5098:	97fff10a 	bl	14c0 <exit@plt>
  for(i = 0; i < sizeof(uninit); i++){
    509c:	91000442 	add	x2, x2, #0x1
    50a0:	eb01005f 	cmp	x2, x1
    50a4:	54fffe81 	b.ne	5074 <bsstest+0x10>  // b.any
    50a8:	d65f03c0 	ret

00000000000050ac <opentest>:
{
    50ac:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  fd = open("echo", 0);
    50b0:	52800001 	mov	w1, #0x0                   	// #0
{
    50b4:	910003fd 	mov	x29, sp
    50b8:	f9000bf3 	str	x19, [sp, #16]
    50bc:	aa0003f3 	mov	x19, x0
  fd = open("echo", 0);
    50c0:	90000000 	adrp	x0, 5000 <bigfile+0x108>
    50c4:	9134a800 	add	x0, x0, #0xd2a
    50c8:	97fff102 	bl	14d0 <open@plt>
  if(fd < 0){
    50cc:	36f800e0 	tbz	w0, #31, 50e8 <opentest+0x3c>
    printf("%s: open echo failed!\n", s);
    50d0:	d0000000 	adrp	x0, 7000 <run+0x1858>
    50d4:	91036800 	add	x0, x0, #0xda
    printf("%s: open doesnotexist succeeded!\n", s);
    50d8:	aa1303e1 	mov	x1, x19
    50dc:	97fff0b1 	bl	13a0 <printf@plt>
    exit(1);
    50e0:	52800020 	mov	w0, #0x1                   	// #1
    50e4:	97fff0f7 	bl	14c0 <exit@plt>
  close(fd);
    50e8:	97fff102 	bl	14f0 <close@plt>
  fd = open("doesnotexist", 0);
    50ec:	d0000000 	adrp	x0, 7000 <run+0x1858>
    50f0:	9103c400 	add	x0, x0, #0xf1
    50f4:	52800001 	mov	w1, #0x0                   	// #0
    50f8:	97fff0f6 	bl	14d0 <open@plt>
  if(fd >= 0){
    50fc:	37f80080 	tbnz	w0, #31, 510c <opentest+0x60>
    printf("%s: open doesnotexist succeeded!\n", s);
    5100:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5104:	9103f800 	add	x0, x0, #0xfe
    5108:	17fffff4 	b	50d8 <opentest+0x2c>
}
    510c:	f9400bf3 	ldr	x19, [sp, #16]
    5110:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5114:	d65f03c0 	ret

0000000000005118 <bigdir>:
{
    5118:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    511c:	910003fd 	mov	x29, sp
    5120:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("bd");
    5124:	d0000014 	adrp	x20, 7000 <run+0x1858>
    5128:	91048294 	add	x20, x20, #0x120
{
    512c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5130:	aa0003f6 	mov	x22, x0
  unlink("bd");
    5134:	aa1403e0 	mov	x0, x20
{
    5138:	f9001bf7 	str	x23, [sp, #48]
  unlink("bd");
    513c:	97fff0c9 	bl	1460 <unlink@plt>
  fd = open("bd", O_CREATE);
    5140:	aa1403e0 	mov	x0, x20
    5144:	52804001 	mov	w1, #0x200                 	// #512
    5148:	97fff0e2 	bl	14d0 <open@plt>
  if(fd < 0){
    514c:	36f800c0 	tbz	w0, #31, 5164 <bigdir+0x4c>
    printf("%s: bigdir create failed\n", s);
    5150:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5154:	91048c00 	add	x0, x0, #0x123
      printf("%s: bigdir unlink failed", s);
    5158:	aa1603e1 	mov	x1, x22
    515c:	97fff091 	bl	13a0 <printf@plt>
      exit(1);
    5160:	14000016 	b	51b8 <bigdir+0xa0>
  for(i = 0; i < N; i++){
    5164:	52800015 	mov	w21, #0x0                   	// #0
    name[0] = 'x';
    5168:	52800f17 	mov	w23, #0x78                  	// #120
  close(fd);
    516c:	97fff0e1 	bl	14f0 <close@plt>
    name[1] = '0' + (i / 64);
    5170:	13067ea0 	asr	w0, w21, #6
    if(link("bd", name) != 0){
    5174:	910103e1 	add	x1, sp, #0x40
    name[1] = '0' + (i / 64);
    5178:	1100c000 	add	w0, w0, #0x30
    517c:	390107e0 	strb	w0, [sp, #65]
    name[2] = '0' + (i % 64);
    5180:	120016a0 	and	w0, w21, #0x3f
    name[0] = 'x';
    5184:	390103f7 	strb	w23, [sp, #64]
    name[2] = '0' + (i % 64);
    5188:	1100c000 	add	w0, w0, #0x30
    518c:	39010be0 	strb	w0, [sp, #66]
    if(link("bd", name) != 0){
    5190:	aa1403e0 	mov	x0, x20
    name[3] = '\0';
    5194:	39010fff 	strb	wzr, [sp, #67]
    if(link("bd", name) != 0){
    5198:	97fff0c6 	bl	14b0 <link@plt>
    519c:	2a0003f3 	mov	w19, w0
    51a0:	34000100 	cbz	w0, 51c0 <bigdir+0xa8>
      printf("%s: bigdir link(bd, %s) failed\n", s, name);
    51a4:	d0000000 	adrp	x0, 7000 <run+0x1858>
    51a8:	9104f400 	add	x0, x0, #0x13d
    51ac:	910103e2 	add	x2, sp, #0x40
    51b0:	aa1603e1 	mov	x1, x22
    51b4:	97fff07b 	bl	13a0 <printf@plt>
      exit(1);
    51b8:	52800020 	mov	w0, #0x1                   	// #1
    51bc:	97fff0c1 	bl	14c0 <exit@plt>
  for(i = 0; i < N; i++){
    51c0:	110006b5 	add	w21, w21, #0x1
    51c4:	7107d2bf 	cmp	w21, #0x1f4
    51c8:	54fffd41 	b.ne	5170 <bigdir+0x58>  // b.any
  unlink("bd");
    51cc:	aa1403e0 	mov	x0, x20
    name[0] = 'x';
    51d0:	52800f14 	mov	w20, #0x78                  	// #120
  unlink("bd");
    51d4:	97fff0a3 	bl	1460 <unlink@plt>
    name[1] = '0' + (i / 64);
    51d8:	13067e60 	asr	w0, w19, #6
    name[0] = 'x';
    51dc:	390103f4 	strb	w20, [sp, #64]
    name[1] = '0' + (i / 64);
    51e0:	1100c000 	add	w0, w0, #0x30
    51e4:	390107e0 	strb	w0, [sp, #65]
    name[2] = '0' + (i % 64);
    51e8:	12001660 	and	w0, w19, #0x3f
    name[3] = '\0';
    51ec:	39010fff 	strb	wzr, [sp, #67]
    name[2] = '0' + (i % 64);
    51f0:	1100c000 	add	w0, w0, #0x30
    51f4:	39010be0 	strb	w0, [sp, #66]
    if(unlink(name) != 0){
    51f8:	910103e0 	add	x0, sp, #0x40
    51fc:	97fff099 	bl	1460 <unlink@plt>
    5200:	34000080 	cbz	w0, 5210 <bigdir+0xf8>
      printf("%s: bigdir unlink failed", s);
    5204:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5208:	91057400 	add	x0, x0, #0x15d
    520c:	17ffffd3 	b	5158 <bigdir+0x40>
  for(i = 0; i < N; i++){
    5210:	11000673 	add	w19, w19, #0x1
    5214:	7107d27f 	cmp	w19, #0x1f4
    5218:	54fffe01 	b.ne	51d8 <bigdir+0xc0>  // b.any
}
    521c:	f9401bf7 	ldr	x23, [sp, #48]
    5220:	a94153f3 	ldp	x19, x20, [sp, #16]
    5224:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5228:	a8c57bfd 	ldp	x29, x30, [sp], #80
    522c:	d65f03c0 	ret

0000000000005230 <validatetest>:
{
    5230:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5234:	910003fd 	mov	x29, sp
    5238:	a90153f3 	stp	x19, x20, [sp, #16]
    if(link("nosuchfile", (char*)p) != -1){
    523c:	d0000013 	adrp	x19, 7000 <run+0x1858>
    5240:	9105da73 	add	x19, x19, #0x176
{
    5244:	f90013f5 	str	x21, [sp, #32]
    5248:	aa0003f5 	mov	x21, x0
  for(p = 0; p <= (uint)hi; p += PGSIZE){
    524c:	d2800014 	mov	x20, #0x0                   	// #0
    if(link("nosuchfile", (char*)p) != -1){
    5250:	aa1403e1 	mov	x1, x20
    5254:	aa1303e0 	mov	x0, x19
    5258:	97fff096 	bl	14b0 <link@plt>
    525c:	3100041f 	cmn	w0, #0x1
    5260:	540000e0 	b.eq	527c <validatetest+0x4c>  // b.none
      printf("%s: link should not succeed\n", s);
    5264:	aa1503e1 	mov	x1, x21
    5268:	d0000000 	adrp	x0, 7000 <run+0x1858>
    526c:	91060400 	add	x0, x0, #0x181
    5270:	97fff04c 	bl	13a0 <printf@plt>
      exit(1);
    5274:	52800020 	mov	w0, #0x1                   	// #1
    5278:	97fff092 	bl	14c0 <exit@plt>
  for(p = 0; p <= (uint)hi; p += PGSIZE){
    527c:	91400694 	add	x20, x20, #0x1, lsl #12
    5280:	f144529f 	cmp	x20, #0x114, lsl #12
    5284:	54fffe61 	b.ne	5250 <validatetest+0x20>  // b.any
}
    5288:	f94013f5 	ldr	x21, [sp, #32]
    528c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5290:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5294:	d65f03c0 	ret

0000000000005298 <argptest>:
{
    5298:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  fd = open("init", O_RDONLY);
    529c:	52800001 	mov	w1, #0x0                   	// #0
{
    52a0:	910003fd 	mov	x29, sp
    52a4:	a90153f3 	stp	x19, x20, [sp, #16]
    52a8:	aa0003f4 	mov	x20, x0
  fd = open("init", O_RDONLY);
    52ac:	d0000000 	adrp	x0, 7000 <run+0x1858>
    52b0:	91067800 	add	x0, x0, #0x19e
    52b4:	97fff087 	bl	14d0 <open@plt>
  if (fd < 0) {
    52b8:	36f800e0 	tbz	w0, #31, 52d4 <argptest+0x3c>
    printf("%s: open failed\n", s);
    52bc:	aa1403e1 	mov	x1, x20
    52c0:	90000000 	adrp	x0, 5000 <bigfile+0x108>
    52c4:	91384800 	add	x0, x0, #0xe12
    52c8:	97fff036 	bl	13a0 <printf@plt>
    exit(1);
    52cc:	52800020 	mov	w0, #0x1                   	// #1
    52d0:	97fff07c 	bl	14c0 <exit@plt>
    52d4:	2a0003f3 	mov	w19, w0
  read(fd, sbrk(0) - 1, -1);
    52d8:	52800000 	mov	w0, #0x0                   	// #0
    52dc:	97fff069 	bl	1480 <sbrk@plt>
    52e0:	d1000401 	sub	x1, x0, #0x1
    52e4:	12800002 	mov	w2, #0xffffffff            	// #-1
    52e8:	2a1303e0 	mov	w0, w19
    52ec:	97fff059 	bl	1450 <read@plt>
  close(fd);
    52f0:	2a1303e0 	mov	w0, w19
}
    52f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    52f8:	a8c27bfd 	ldp	x29, x30, [sp], #32
  close(fd);
    52fc:	17fff07d 	b	14f0 <close@plt>

0000000000005300 <writebig>:
{
    5300:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  fd = open("big", O_CREATE|O_RDWR);
    5304:	52804041 	mov	w1, #0x202                 	// #514
{
    5308:	910003fd 	mov	x29, sp
    530c:	a9025bf5 	stp	x21, x22, [sp, #32]
  fd = open("big", O_CREATE|O_RDWR);
    5310:	d0000016 	adrp	x22, 7000 <run+0x1858>
    5314:	910876d6 	add	x22, x22, #0x21d
{
    5318:	a90153f3 	stp	x19, x20, [sp, #16]
    531c:	aa0003f3 	mov	x19, x0
  fd = open("big", O_CREATE|O_RDWR);
    5320:	aa1603e0 	mov	x0, x22
{
    5324:	f9001bf7 	str	x23, [sp, #48]
  fd = open("big", O_CREATE|O_RDWR);
    5328:	97fff06a 	bl	14d0 <open@plt>
  if(fd < 0){
    532c:	37f80260 	tbnz	w0, #31, 5378 <writebig+0x78>
    ((int*)buf)[0] = i;
    5330:	d0000035 	adrp	x21, b000 <uninit+0x1cc7>
    5334:	912926b5 	add	x21, x21, #0xa49
    5338:	2a0003f7 	mov	w23, w0
    533c:	52800014 	mov	w20, #0x0                   	// #0
    if(write(fd, buf, BSIZE) != BSIZE){
    5340:	aa1503e1 	mov	x1, x21
    5344:	2a1703e0 	mov	w0, w23
    5348:	52808002 	mov	w2, #0x400                 	// #1024
    ((int*)buf)[0] = i;
    534c:	b90002b4 	str	w20, [x21]
    if(write(fd, buf, BSIZE) != BSIZE){
    5350:	97fff028 	bl	13f0 <write@plt>
    5354:	7110001f 	cmp	w0, #0x400
    5358:	540001a0 	b.eq	538c <writebig+0x8c>  // b.none
      printf("%s: error: write big file failed\n", s, i);
    535c:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5360:	91070400 	add	x0, x0, #0x1c1
    5364:	2a1403e2 	mov	w2, w20
    5368:	aa1303e1 	mov	x1, x19
    536c:	97fff00d 	bl	13a0 <printf@plt>
      exit(1);
    5370:	52800020 	mov	w0, #0x1                   	// #1
    5374:	97fff053 	bl	14c0 <exit@plt>
    printf("%s: error: creat big failed!\n", s);
    5378:	d0000000 	adrp	x0, 7000 <run+0x1858>
    537c:	91068c00 	add	x0, x0, #0x1a3
    printf("%s: unlink big failed\n", s);
    5380:	aa1303e1 	mov	x1, x19
    5384:	97fff007 	bl	13a0 <printf@plt>
    exit(1);
    5388:	17fffffa 	b	5370 <writebig+0x70>
  for(i = 0; i < MAXFILE; i++){
    538c:	11000694 	add	w20, w20, #0x1
    5390:	7104329f 	cmp	w20, #0x10c
    5394:	54fffd61 	b.ne	5340 <writebig+0x40>  // b.any
  close(fd);
    5398:	2a1703e0 	mov	w0, w23
    539c:	97fff055 	bl	14f0 <close@plt>
  fd = open("big", O_RDONLY);
    53a0:	aa1603e0 	mov	x0, x22
    53a4:	52800001 	mov	w1, #0x0                   	// #0
  n = 0;
    53a8:	52800014 	mov	w20, #0x0                   	// #0
  fd = open("big", O_RDONLY);
    53ac:	97fff049 	bl	14d0 <open@plt>
    53b0:	2a0003f7 	mov	w23, w0
  if(fd < 0){
    53b4:	36f80260 	tbz	w0, #31, 5400 <writebig+0x100>
    printf("%s: error: open big failed!\n", s);
    53b8:	d0000000 	adrp	x0, 7000 <run+0x1858>
    53bc:	91078c00 	add	x0, x0, #0x1e3
    53c0:	17fffff0 	b	5380 <writebig+0x80>
    } else if(i != BSIZE){
    53c4:	7110001f 	cmp	w0, #0x400
    53c8:	54000080 	b.eq	53d8 <writebig+0xd8>  // b.none
      printf("%s: read failed %d\n", s, i);
    53cc:	d0000000 	adrp	x0, 7000 <run+0x1858>
    53d0:	91088400 	add	x0, x0, #0x221
    53d4:	17ffffe5 	b	5368 <writebig+0x68>
    if(((int*)buf)[0] != n){
    53d8:	b94002a3 	ldr	w3, [x21]
    53dc:	6b14007f 	cmp	w3, w20
    53e0:	540000e0 	b.eq	53fc <writebig+0xfc>  // b.none
      printf("%s: read content of block %d is %d\n", s,
    53e4:	2a1403e2 	mov	w2, w20
    53e8:	aa1303e1 	mov	x1, x19
    53ec:	d0000000 	adrp	x0, 7000 <run+0x1858>
    53f0:	9108d400 	add	x0, x0, #0x235
    53f4:	97ffefeb 	bl	13a0 <printf@plt>
      exit(1);
    53f8:	17ffffde 	b	5370 <writebig+0x70>
    n++;
    53fc:	11000694 	add	w20, w20, #0x1
    i = read(fd, buf, BSIZE);
    5400:	52808002 	mov	w2, #0x400                 	// #1024
    5404:	aa1503e1 	mov	x1, x21
    5408:	2a1703e0 	mov	w0, w23
    540c:	97fff011 	bl	1450 <read@plt>
    5410:	2a0003e2 	mov	w2, w0
    if(i == 0){
    5414:	35fffd80 	cbnz	w0, 53c4 <writebig+0xc4>
      if(n == MAXFILE - 1){
    5418:	71042e9f 	cmp	w20, #0x10b
    541c:	54000081 	b.ne	542c <writebig+0x12c>  // b.any
        printf("%s: read only %d blocks from big", s, n);
    5420:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5424:	91080000 	add	x0, x0, #0x200
    5428:	17ffffcf 	b	5364 <writebig+0x64>
  close(fd);
    542c:	2a1703e0 	mov	w0, w23
    5430:	97fff030 	bl	14f0 <close@plt>
  if(unlink("big") < 0){
    5434:	aa1603e0 	mov	x0, x22
    5438:	97fff00a 	bl	1460 <unlink@plt>
    543c:	36f80080 	tbz	w0, #31, 544c <writebig+0x14c>
    printf("%s: unlink big failed\n", s);
    5440:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5444:	91096400 	add	x0, x0, #0x259
    5448:	17ffffce 	b	5380 <writebig+0x80>
}
    544c:	f9401bf7 	ldr	x23, [sp, #48]
    5450:	a94153f3 	ldp	x19, x20, [sp, #16]
    5454:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    545c:	d65f03c0 	ret

0000000000005460 <fsfull>:
{
    5460:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
  printf("fsfull test\n");
    5464:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5468:	9109c000 	add	x0, x0, #0x270
{
    546c:	910003fd 	mov	x29, sp
    5470:	a9025bf5 	stp	x21, x22, [sp, #32]
    printf("writing %s\n", name);
    5474:	d0000016 	adrp	x22, 7000 <run+0x1858>
    5478:	9109f6d6 	add	x22, x22, #0x27d
    name[3] = '0' + (nfiles % 100) / 10;
    547c:	52800155 	mov	w21, #0xa                   	// #10
{
    5480:	a90153f3 	stp	x19, x20, [sp, #16]
  for(nfiles = 0; ; nfiles++){
    5484:	52800013 	mov	w19, #0x0                   	// #0
    name[2] = '0' + (nfiles % 1000) / 100;
    5488:	52800c94 	mov	w20, #0x64                  	// #100
{
    548c:	a90363f7 	stp	x23, x24, [sp, #48]
    name[0] = 'f';
    5490:	52800cd8 	mov	w24, #0x66                  	// #102
    name[1] = '0' + nfiles / 1000;
    5494:	52807d17 	mov	w23, #0x3e8                 	// #1000
{
    5498:	a9046bf9 	stp	x25, x26, [sp, #64]
  printf("fsfull test\n");
    549c:	97ffefc1 	bl	13a0 <printf@plt>
    name[1] = '0' + nfiles / 1000;
    54a0:	1ad70a61 	udiv	w1, w19, w23
    name[0] = 'f';
    54a4:	390143f8 	strb	w24, [sp, #80]
    name[5] = '\0';
    54a8:	390157ff 	strb	wzr, [sp, #85]
    name[1] = '0' + nfiles / 1000;
    54ac:	1100c020 	add	w0, w1, #0x30
    54b0:	390147e0 	strb	w0, [sp, #81]
    name[3] = '0' + (nfiles % 100) / 10;
    54b4:	1ad40a60 	udiv	w0, w19, w20
    name[2] = '0' + (nfiles % 1000) / 100;
    54b8:	1b17cc21 	msub	w1, w1, w23, w19
    54bc:	1ad40821 	udiv	w1, w1, w20
    name[3] = '0' + (nfiles % 100) / 10;
    54c0:	1b14cc00 	msub	w0, w0, w20, w19
    54c4:	1ad50800 	udiv	w0, w0, w21
    name[2] = '0' + (nfiles % 1000) / 100;
    54c8:	1100c021 	add	w1, w1, #0x30
    54cc:	39014be1 	strb	w1, [sp, #82]
    printf("writing %s\n", name);
    54d0:	910143e1 	add	x1, sp, #0x50
    name[3] = '0' + (nfiles % 100) / 10;
    54d4:	1100c000 	add	w0, w0, #0x30
    54d8:	39014fe0 	strb	w0, [sp, #83]
    name[4] = '0' + (nfiles % 10);
    54dc:	1ad50a60 	udiv	w0, w19, w21
    54e0:	1b15cc00 	msub	w0, w0, w21, w19
    54e4:	1100c000 	add	w0, w0, #0x30
    54e8:	390153e0 	strb	w0, [sp, #84]
    printf("writing %s\n", name);
    54ec:	aa1603e0 	mov	x0, x22
    54f0:	97ffefac 	bl	13a0 <printf@plt>
    int fd = open(name, O_CREATE|O_RDWR);
    54f4:	910143e0 	add	x0, sp, #0x50
    54f8:	52804041 	mov	w1, #0x202                 	// #514
    54fc:	97ffeff5 	bl	14d0 <open@plt>
    5500:	2a0003fa 	mov	w26, w0
    if(fd < 0){
    5504:	36f80500 	tbz	w0, #31, 55a4 <fsfull+0x144>
      printf("open %s failed\n", name);
    5508:	d0000000 	adrp	x0, 7000 <run+0x1858>
    550c:	910a2400 	add	x0, x0, #0x289
    5510:	910143e1 	add	x1, sp, #0x50
    5514:	97ffefa3 	bl	13a0 <printf@plt>
    name[0] = 'f';
    5518:	52800cd7 	mov	w23, #0x66                  	// #102
    name[1] = '0' + nfiles / 1000;
    551c:	52807d16 	mov	w22, #0x3e8                 	// #1000
    name[2] = '0' + (nfiles % 1000) / 100;
    5520:	52800c95 	mov	w21, #0x64                  	// #100
    name[3] = '0' + (nfiles % 100) / 10;
    5524:	52800154 	mov	w20, #0xa                   	// #10
    name[1] = '0' + nfiles / 1000;
    5528:	1ad60a60 	udiv	w0, w19, w22
    name[0] = 'f';
    552c:	390143f7 	strb	w23, [sp, #80]
    name[5] = '\0';
    5530:	390157ff 	strb	wzr, [sp, #85]
    name[1] = '0' + nfiles / 1000;
    5534:	1100c001 	add	w1, w0, #0x30
    name[2] = '0' + (nfiles % 1000) / 100;
    5538:	1b16cc00 	msub	w0, w0, w22, w19
    name[1] = '0' + nfiles / 1000;
    553c:	390147e1 	strb	w1, [sp, #81]
    name[2] = '0' + (nfiles % 1000) / 100;
    5540:	1ad50800 	udiv	w0, w0, w21
    5544:	1100c000 	add	w0, w0, #0x30
    5548:	39014be0 	strb	w0, [sp, #82]
    name[3] = '0' + (nfiles % 100) / 10;
    554c:	1ad50a60 	udiv	w0, w19, w21
    5550:	1b15cc00 	msub	w0, w0, w21, w19
    5554:	1ad40800 	udiv	w0, w0, w20
    5558:	1100c000 	add	w0, w0, #0x30
    555c:	39014fe0 	strb	w0, [sp, #83]
    name[4] = '0' + (nfiles % 10);
    5560:	1ad40a60 	udiv	w0, w19, w20
    5564:	1b14cc00 	msub	w0, w0, w20, w19
    nfiles--;
    5568:	51000673 	sub	w19, w19, #0x1
    name[4] = '0' + (nfiles % 10);
    556c:	1100c000 	add	w0, w0, #0x30
    5570:	390153e0 	strb	w0, [sp, #84]
    unlink(name);
    5574:	910143e0 	add	x0, sp, #0x50
    5578:	97ffefba 	bl	1460 <unlink@plt>
  while(nfiles >= 0){
    557c:	3100067f 	cmn	w19, #0x1
    5580:	54fffd41 	b.ne	5528 <fsfull+0xc8>  // b.any
}
    5584:	a94153f3 	ldp	x19, x20, [sp, #16]
  printf("fsfull test finished\n");
    5588:	d0000000 	adrp	x0, 7000 <run+0x1858>
    558c:	910aa400 	add	x0, x0, #0x2a9
}
    5590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5594:	a94363f7 	ldp	x23, x24, [sp, #48]
    5598:	a9446bf9 	ldp	x25, x26, [sp, #64]
    559c:	a8c97bfd 	ldp	x29, x30, [sp], #144
  printf("fsfull test finished\n");
    55a0:	17ffef80 	b	13a0 <printf@plt>
      int cc = write(fd, buf, BSIZE);
    55a4:	d0000021 	adrp	x1, b000 <uninit+0x1cc7>
    55a8:	91292421 	add	x1, x1, #0xa49
    int total = 0;
    55ac:	52800019 	mov	w25, #0x0                   	// #0
      int cc = write(fd, buf, BSIZE);
    55b0:	2a1a03e0 	mov	w0, w26
    55b4:	52808002 	mov	w2, #0x400                 	// #1024
    55b8:	97ffef8e 	bl	13f0 <write@plt>
      if(cc < BSIZE)
    55bc:	710ffc1f 	cmp	w0, #0x3ff
    55c0:	540000ad 	b.le	55d4 <fsfull+0x174>
      total += cc;
    55c4:	0b000339 	add	w25, w25, w0
    while(1){
    55c8:	d0000020 	adrp	x0, b000 <uninit+0x1cc7>
    55cc:	91292401 	add	x1, x0, #0xa49
    55d0:	17fffff8 	b	55b0 <fsfull+0x150>
    printf("wrote %d bytes\n", total);
    55d4:	2a1903e1 	mov	w1, w25
    55d8:	d0000000 	adrp	x0, 7000 <run+0x1858>
    55dc:	910a6400 	add	x0, x0, #0x299
    55e0:	97ffef70 	bl	13a0 <printf@plt>
    close(fd);
    55e4:	2a1a03e0 	mov	w0, w26
    55e8:	97ffefc2 	bl	14f0 <close@plt>
    if(total == 0)
    55ec:	34fff979 	cbz	w25, 5518 <fsfull+0xb8>
  for(nfiles = 0; ; nfiles++){
    55f0:	11000673 	add	w19, w19, #0x1
    55f4:	17ffffab 	b	54a0 <fsfull+0x40>

00000000000055f8 <badwrite>:
{
    55f8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    55fc:	910003fd 	mov	x29, sp
    5600:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("junk");
    5604:	d0000013 	adrp	x19, 7000 <run+0x1858>
    5608:	910afe73 	add	x19, x19, #0x2bf
    560c:	aa1303e0 	mov	x0, x19
    5610:	52804b14 	mov	w20, #0x258                 	// #600
{
    5614:	f90013f5 	str	x21, [sp, #32]
  unlink("junk");
    5618:	97ffef92 	bl	1460 <unlink@plt>
    int fd = open("junk", O_CREATE|O_WRONLY);
    561c:	aa1303e0 	mov	x0, x19
    5620:	52804021 	mov	w1, #0x201                 	// #513
    5624:	97ffefab 	bl	14d0 <open@plt>
    5628:	2a0003f5 	mov	w21, w0
    if(fd < 0){
    562c:	36f800c0 	tbz	w0, #31, 5644 <badwrite+0x4c>
      printf("open junk failed\n");
    5630:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5634:	910b1000 	add	x0, x0, #0x2c4
    printf("write failed\n");
    5638:	97ffef5a 	bl	13a0 <printf@plt>
    exit(1);
    563c:	52800020 	mov	w0, #0x1                   	// #1
    5640:	97ffefa0 	bl	14c0 <exit@plt>
    write(fd, (char*)0xffffffffffL, 1);
    5644:	52800022 	mov	w2, #0x1                   	// #1
    5648:	b2409fe1 	mov	x1, #0xffffffffff          	// #1099511627775
    564c:	97ffef69 	bl	13f0 <write@plt>
    close(fd);
    5650:	2a1503e0 	mov	w0, w21
    5654:	97ffefa7 	bl	14f0 <close@plt>
    unlink("junk");
    5658:	aa1303e0 	mov	x0, x19
    565c:	97ffef81 	bl	1460 <unlink@plt>
  for(int i = 0; i < assumed_free; i++){
    5660:	71000694 	subs	w20, w20, #0x1
    5664:	54fffdc1 	b.ne	561c <badwrite+0x24>  // b.any
  int fd = open("junk", O_CREATE|O_WRONLY);
    5668:	aa1303e0 	mov	x0, x19
    566c:	52804021 	mov	w1, #0x201                 	// #513
    5670:	97ffef98 	bl	14d0 <open@plt>
    5674:	2a0003f4 	mov	w20, w0
  if(fd < 0){
    5678:	37fffdc0 	tbnz	w0, #31, 5630 <badwrite+0x38>
  if(write(fd, "x", 1) != 1){
    567c:	b0000001 	adrp	x1, 6000 <run+0x858>
    5680:	91275021 	add	x1, x1, #0x9d4
    5684:	52800022 	mov	w2, #0x1                   	// #1
    5688:	97ffef5a 	bl	13f0 <write@plt>
    568c:	7100041f 	cmp	w0, #0x1
    5690:	54000080 	b.eq	56a0 <badwrite+0xa8>  // b.none
    printf("write failed\n");
    5694:	90000000 	adrp	x0, 5000 <bigfile+0x108>
    5698:	91303400 	add	x0, x0, #0xc0d
    569c:	17ffffe7 	b	5638 <badwrite+0x40>
  close(fd);
    56a0:	2a1403e0 	mov	w0, w20
    56a4:	97ffef93 	bl	14f0 <close@plt>
  unlink("junk");
    56a8:	aa1303e0 	mov	x0, x19
    56ac:	97ffef6d 	bl	1460 <unlink@plt>
  exit(0);
    56b0:	52800000 	mov	w0, #0x0                   	// #0
    56b4:	17ffffe3 	b	5640 <badwrite+0x48>

00000000000056b8 <countfree>:
{
    56b8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    56bc:	910003fd 	mov	x29, sp
  if(pipe(fds) < 0){
    56c0:	9100a3e0 	add	x0, sp, #0x28
{
    56c4:	a90153f3 	stp	x19, x20, [sp, #16]
  if(pipe(fds) < 0){
    56c8:	97ffef46 	bl	13e0 <pipe@plt>
    56cc:	36f800c0 	tbz	w0, #31, 56e4 <countfree+0x2c>
    printf("pipe() failed in countfree()\n");
    56d0:	d0000000 	adrp	x0, 7000 <run+0x1858>
    56d4:	910b5800 	add	x0, x0, #0x2d6
    printf("fork failed in countfree()\n");
    56d8:	97ffef32 	bl	13a0 <printf@plt>
    exit(1);
    56dc:	52800020 	mov	w0, #0x1                   	// #1
    56e0:	97ffef78 	bl	14c0 <exit@plt>
  int pid = fork();
    56e4:	97ffef63 	bl	1470 <fork@plt>
  if(pid < 0){
    56e8:	36f80080 	tbz	w0, #31, 56f8 <countfree+0x40>
    printf("fork failed in countfree()\n");
    56ec:	d0000000 	adrp	x0, 7000 <run+0x1858>
    56f0:	910bd000 	add	x0, x0, #0x2f4
    56f4:	17fffff9 	b	56d8 <countfree+0x20>
  if(pid == 0){
    56f8:	350002c0 	cbnz	w0, 5750 <countfree+0x98>
    close(fds[0]);
    56fc:	b9402be0 	ldr	w0, [sp, #40]
      if(write(fds[1], "x", 1) != 1){
    5700:	b0000013 	adrp	x19, 6000 <run+0x858>
    5704:	91275273 	add	x19, x19, #0x9d4
      *(char *)(a + 4096 - 1) = 1;
    5708:	52800034 	mov	w20, #0x1                   	// #1
    close(fds[0]);
    570c:	97ffef79 	bl	14f0 <close@plt>
      uint64 a = (uint64) sbrk(4096);
    5710:	52820000 	mov	w0, #0x1000                	// #4096
    5714:	97ffef5b 	bl	1480 <sbrk@plt>
      if(a == 0xffffffffffffffff){
    5718:	b100041f 	cmn	x0, #0x1
    571c:	54000160 	b.eq	5748 <countfree+0x90>  // b.none
      *(char *)(a + 4096 - 1) = 1;
    5720:	393ffc14 	strb	w20, [x0, #4095]
      if(write(fds[1], "x", 1) != 1){
    5724:	aa1303e1 	mov	x1, x19
    5728:	52800022 	mov	w2, #0x1                   	// #1
    572c:	b9402fe0 	ldr	w0, [sp, #44]
    5730:	97ffef30 	bl	13f0 <write@plt>
    5734:	7100041f 	cmp	w0, #0x1
    5738:	54fffec0 	b.eq	5710 <countfree+0x58>  // b.none
        printf("write() failed in countfree()\n");
    573c:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5740:	910c4000 	add	x0, x0, #0x310
    5744:	17ffffe5 	b	56d8 <countfree+0x20>
    exit(0);
    5748:	52800000 	mov	w0, #0x0                   	// #0
    574c:	17ffffe5 	b	56e0 <countfree+0x28>
  close(fds[1]);
    5750:	b9402fe0 	ldr	w0, [sp, #44]
  int n = 0;
    5754:	52800013 	mov	w19, #0x0                   	// #0
  close(fds[1]);
    5758:	97ffef66 	bl	14f0 <close@plt>
    int cc = read(fds[0], &c, 1);
    575c:	b9402be0 	ldr	w0, [sp, #40]
    5760:	91009fe1 	add	x1, sp, #0x27
    5764:	52800022 	mov	w2, #0x1                   	// #1
    5768:	97ffef3a 	bl	1450 <read@plt>
    if(cc < 0){
    576c:	36f80080 	tbz	w0, #31, 577c <countfree+0xc4>
      printf("read() failed in countfree()\n");
    5770:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5774:	910cbc00 	add	x0, x0, #0x32f
    5778:	17ffffd8 	b	56d8 <countfree+0x20>
    if(cc == 0)
    577c:	34000060 	cbz	w0, 5788 <countfree+0xd0>
    n += 1;
    5780:	11000673 	add	w19, w19, #0x1
  while(1){
    5784:	17fffff6 	b	575c <countfree+0xa4>
  close(fds[0]);
    5788:	b9402be0 	ldr	w0, [sp, #40]
    578c:	97ffef59 	bl	14f0 <close@plt>
  wait((int*)0);
    5790:	d2800000 	mov	x0, #0x0                   	// #0
    5794:	97ffef2b 	bl	1440 <wait@plt>
}
    5798:	2a1303e0 	mov	w0, w19
    579c:	a94153f3 	ldp	x19, x20, [sp, #16]
    57a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    57a4:	d65f03c0 	ret

00000000000057a8 <run>:
run(void f(char *), char *s) {
    57a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    57ac:	910003fd 	mov	x29, sp
    57b0:	a90153f3 	stp	x19, x20, [sp, #16]
    57b4:	aa0003f3 	mov	x19, x0
    57b8:	aa0103f4 	mov	x20, x1
  printf("test %s: ", s);
    57bc:	d0000000 	adrp	x0, 7000 <run+0x1858>
    57c0:	910d3400 	add	x0, x0, #0x34d
    57c4:	97ffeef7 	bl	13a0 <printf@plt>
  if((pid = fork()) < 0) {
    57c8:	97ffef2a 	bl	1470 <fork@plt>
    57cc:	36f800c0 	tbz	w0, #31, 57e4 <run+0x3c>
    printf("runtest: fork error\n");
    57d0:	d0000000 	adrp	x0, 7000 <run+0x1858>
    57d4:	910d5c00 	add	x0, x0, #0x357
    57d8:	97ffeef2 	bl	13a0 <printf@plt>
    exit(1);
    57dc:	52800020 	mov	w0, #0x1                   	// #1
    exit(0);
    57e0:	97ffef38 	bl	14c0 <exit@plt>
  if(pid == 0) {
    57e4:	350000a0 	cbnz	w0, 57f8 <run+0x50>
    f(s);
    57e8:	aa1403e0 	mov	x0, x20
    57ec:	d63f0260 	blr	x19
    exit(0);
    57f0:	52800000 	mov	w0, #0x0                   	// #0
    57f4:	17fffffb 	b	57e0 <run+0x38>
    wait(&xstatus);
    57f8:	9100b3e0 	add	x0, sp, #0x2c
    57fc:	97ffef11 	bl	1440 <wait@plt>
    if(xstatus != 0) 
    5800:	b9402fe0 	ldr	w0, [sp, #44]
    5804:	34000140 	cbz	w0, 582c <run+0x84>
      printf("FAILED\n");
    5808:	d0000000 	adrp	x0, 7000 <run+0x1858>
    580c:	910f8000 	add	x0, x0, #0x3e0
      printf("OK\n");
    5810:	97ffeee4 	bl	13a0 <printf@plt>
    return xstatus == 0;
    5814:	b9402fe0 	ldr	w0, [sp, #44]
}
    5818:	a94153f3 	ldp	x19, x20, [sp, #16]
    return xstatus == 0;
    581c:	7100001f 	cmp	w0, #0x0
}
    5820:	1a9f17e0 	cset	w0, eq	// eq = none
    5824:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5828:	d65f03c0 	ret
      printf("OK\n");
    582c:	d0000000 	adrp	x0, 7000 <run+0x1858>
    5830:	910db000 	add	x0, x0, #0x36c
    5834:	17fffff7 	b	5810 <run+0x68>
