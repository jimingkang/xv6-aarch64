
user/_rtlat:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000005c0 <.plt>:
 5c0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 5c4:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 5c8:	f9478e11 	ldr	x17, [x16, #3864]
 5cc:	913c6210 	add	x16, x16, #0xf18
 5d0:	d61f0220 	br	x17
 5d4:	d503201f 	nop
 5d8:	d503201f 	nop
 5dc:	d503201f 	nop

00000000000005e0 <printf@plt>:
 5e0:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 5e4:	f9479211 	ldr	x17, [x16, #3872]
 5e8:	913c8210 	add	x16, x16, #0xf20
 5ec:	d61f0220 	br	x17

00000000000005f0 <sched_setscheduler@plt>:
 5f0:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 5f4:	f9479611 	ldr	x17, [x16, #3880]
 5f8:	913ca210 	add	x16, x16, #0xf28
 5fc:	d61f0220 	br	x17

0000000000000600 <pipe@plt>:
 600:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 604:	f9479a11 	ldr	x17, [x16, #3888]
 608:	913cc210 	add	x16, x16, #0xf30
 60c:	d61f0220 	br	x17

0000000000000610 <write@plt>:
 610:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 614:	f9479e11 	ldr	x17, [x16, #3896]
 618:	913ce210 	add	x16, x16, #0xf38
 61c:	d61f0220 	br	x17

0000000000000620 <fprintf@plt>:
 620:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 624:	f947a211 	ldr	x17, [x16, #3904]
 628:	913d0210 	add	x16, x16, #0xf40
 62c:	d61f0220 	br	x17

0000000000000630 <kill@plt>:
 630:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 634:	f947a611 	ldr	x17, [x16, #3912]
 638:	913d2210 	add	x16, x16, #0xf48
 63c:	d61f0220 	br	x17

0000000000000640 <sleep_ticks@plt>:
 640:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 644:	f947aa11 	ldr	x17, [x16, #3920]
 648:	913d4210 	add	x16, x16, #0xf50
 64c:	d61f0220 	br	x17

0000000000000650 <wait@plt>:
 650:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 654:	f947ae11 	ldr	x17, [x16, #3928]
 658:	913d6210 	add	x16, x16, #0xf58
 65c:	d61f0220 	br	x17

0000000000000660 <read@plt>:
 660:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 664:	f947b211 	ldr	x17, [x16, #3936]
 668:	913d8210 	add	x16, x16, #0xf60
 66c:	d61f0220 	br	x17

0000000000000670 <fork@plt>:
 670:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 674:	f947b611 	ldr	x17, [x16, #3944]
 678:	913da210 	add	x16, x16, #0xf68
 67c:	d61f0220 	br	x17

0000000000000680 <getcpu@plt>:
 680:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 684:	f947ba11 	ldr	x17, [x16, #3952]
 688:	913dc210 	add	x16, x16, #0xf70
 68c:	d61f0220 	br	x17

0000000000000690 <strcmp@plt>:
 690:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 694:	f947be11 	ldr	x17, [x16, #3960]
 698:	913de210 	add	x16, x16, #0xf78
 69c:	d61f0220 	br	x17

00000000000006a0 <sched_setaffinity@plt>:
 6a0:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 6a4:	f947c211 	ldr	x17, [x16, #3968]
 6a8:	913e0210 	add	x16, x16, #0xf80
 6ac:	d61f0220 	br	x17

00000000000006b0 <clock_us@plt>:
 6b0:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 6b4:	f947c611 	ldr	x17, [x16, #3976]
 6b8:	913e2210 	add	x16, x16, #0xf88
 6bc:	d61f0220 	br	x17

00000000000006c0 <exit@plt>:
 6c0:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 6c4:	f947ca11 	ldr	x17, [x16, #3984]
 6c8:	913e4210 	add	x16, x16, #0xf90
 6cc:	d61f0220 	br	x17

00000000000006d0 <close@plt>:
 6d0:	b0000010 	adrp	x16, 1000 <usage+0x3c8>
 6d4:	f947ce11 	ldr	x17, [x16, #3992]
 6d8:	913e6210 	add	x16, x16, #0xf98
 6dc:	d61f0220 	br	x17

Disassembly of section .text:

00000000000006e0 <main>:
         (us / 10) % 10, us % 10);
}

int
main(int argc, char *argv[])
{
 6e0:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
 6e4:	910003fd 	mov	x29, sp
 6e8:	a9046bf9 	stp	x25, x26, [sp, #64]
 6ec:	2a0003f9 	mov	w25, w0
  int policy = SCHED_FIFO, prio = 80, cpu = 3, hogs = 3, samples = 30;
 6f0:	52800a00 	mov	w0, #0x50                  	// #80
{
 6f4:	aa0103fa 	mov	x26, x1
 6f8:	a90153f3 	stp	x19, x20, [sp, #16]
  int fds[2], hog_pid[8], reader;

  for(int i = 1; i < argc; i++){
 6fc:	d2800033 	mov	x19, #0x1                   	// #1
  int policy = SCHED_FIFO, prio = 80, cpu = 3, hogs = 3, samples = 30;
 700:	2a1303f4 	mov	w20, w19
{
 704:	a90363f7 	stp	x23, x24, [sp, #48]
    if(i + 1 >= argc)
      usage();
    char *opt = argv[i], *val = argv[++i];
    if(strcmp(opt, "-p") == 0){
 708:	90000017 	adrp	x23, 0 <.plt-0x5c0>
 70c:	91335af7 	add	x23, x23, #0xcd6
      if(strcmp(val, "fifo") == 0) policy = SCHED_FIFO;
      else if(strcmp(val, "rr") == 0) policy = SCHED_RR;
      else if(strcmp(val, "other") == 0) policy = SCHED_OTHER;
      else usage();
    } else if(strcmp(opt, "-P") == 0){
 710:	90000018 	adrp	x24, 0 <.plt-0x5c0>
 714:	91339f18 	add	x24, x24, #0xce7
{
 718:	a90573fb 	stp	x27, x28, [sp, #80]
    char *opt = argv[i], *val = argv[++i];
 71c:	9100203b 	add	x27, x1, #0x8
  int policy = SCHED_FIFO, prio = 80, cpu = 3, hogs = 3, samples = 30;
 720:	b90063e0 	str	w0, [sp, #96]
 724:	52800060 	mov	w0, #0x3                   	// #3
{
 728:	a9025bf5 	stp	x21, x22, [sp, #32]
  int policy = SCHED_FIFO, prio = 80, cpu = 3, hogs = 3, samples = 30;
 72c:	290c83e0 	stp	w0, w0, [sp, #100]
 730:	528003c0 	mov	w0, #0x1e                  	// #30
 734:	b9006fe0 	str	w0, [sp, #108]
  for(int i = 1; i < argc; i++){
 738:	6b13033f 	cmp	w25, w19
 73c:	5400032c 	b.gt	7a0 <main+0xc0>
      if(!parse_num(val, &samples) || samples < 1) usage();
    } else {
      usage();
    }
  }
  if(policy == SCHED_OTHER)
 740:	35000cf4 	cbnz	w20, 8dc <main+0x1fc>
static __attribute__((unused)) const char *
policy_name(int policy)
{
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
  if(policy == SCHED_RR) return "SCHED_RR";
  return "SCHED_OTHER";
 744:	90000013 	adrp	x19, 0 <.plt-0x5c0>
 748:	91330673 	add	x19, x19, #0xcc1
    prio = 0;
 74c:	b90063ff 	str	wzr, [sp, #96]

  printf("rtlat: reader %s prio %d on CPU%d, %d busy loop(s) on CPU%d, "
 750:	294c5bfa 	ldp	w26, w22, [sp, #96]
 754:	aa1303e1 	mov	x1, x19
 758:	294d57f9 	ldp	w25, w21, [sp, #104]
 75c:	2a1603e5 	mov	w5, w22
 760:	2a1603e3 	mov	w3, w22
 764:	2a1a03e2 	mov	w2, w26
 768:	2a1503e6 	mov	w6, w21
 76c:	2a1903e4 	mov	w4, w25
 770:	90000000 	adrp	x0, 0 <.plt-0x5c0>
 774:	9133cc00 	add	x0, x0, #0xcf3
 778:	97ffff9a 	bl	5e0 <printf@plt>
         "%d samples\n", policy_name(policy), prio, cpu, hogs, cpu, samples);

  if(pipe(fds) < 0){
 77c:	9101c3e0 	add	x0, sp, #0x70
 780:	97ffffa0 	bl	600 <pipe@plt>
 784:	36f80e40 	tbz	w0, #31, 94c <main+0x26c>
    fprintf(2, "rtlat: pipe failed\n");
 788:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 78c:	9134f021 	add	x1, x1, #0xd3c
 790:	52800040 	mov	w0, #0x2                   	// #2
 794:	97ffffa3 	bl	620 <fprintf@plt>
    exit(1);
 798:	52800020 	mov	w0, #0x1                   	// #1
 79c:	97ffffc9 	bl	6c0 <exit@plt>
    if(i + 1 >= argc)
 7a0:	11000660 	add	w0, w19, #0x1
 7a4:	6b00033f 	cmp	w25, w0
 7a8:	5400004c 	b.gt	7b0 <main+0xd0>
      usage();
 7ac:	94000123 	bl	c38 <usage>
    char *opt = argv[i], *val = argv[++i];
 7b0:	f8737b56 	ldr	x22, [x26, x19, lsl #3]
    if(strcmp(opt, "-p") == 0){
 7b4:	aa1703e1 	mov	x1, x23
    char *opt = argv[i], *val = argv[++i];
 7b8:	f8737b75 	ldr	x21, [x27, x19, lsl #3]
    if(strcmp(opt, "-p") == 0){
 7bc:	aa1603e0 	mov	x0, x22
 7c0:	97ffffb4 	bl	690 <strcmp@plt>
 7c4:	35000260 	cbnz	w0, 810 <main+0x130>
      if(strcmp(val, "fifo") == 0) policy = SCHED_FIFO;
 7c8:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 7cc:	91336421 	add	x1, x1, #0xcd9
 7d0:	aa1503e0 	mov	x0, x21
 7d4:	97ffffaf 	bl	690 <strcmp@plt>
 7d8:	340007a0 	cbz	w0, 8cc <main+0x1ec>
      else if(strcmp(val, "rr") == 0) policy = SCHED_RR;
 7dc:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 7e0:	91337821 	add	x1, x1, #0xcde
 7e4:	aa1503e0 	mov	x0, x21
 7e8:	97ffffaa 	bl	690 <strcmp@plt>
 7ec:	34000740 	cbz	w0, 8d4 <main+0x1f4>
      else if(strcmp(val, "other") == 0) policy = SCHED_OTHER;
 7f0:	aa1503e0 	mov	x0, x21
 7f4:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 7f8:	91338421 	add	x1, x1, #0xce1
 7fc:	97ffffa5 	bl	690 <strcmp@plt>
 800:	2a0003f4 	mov	w20, w0
 804:	35fffd40 	cbnz	w0, 7ac <main+0xcc>
  for(int i = 1; i < argc; i++){
 808:	91000a73 	add	x19, x19, #0x2
 80c:	17ffffcb 	b	738 <main+0x58>
    } else if(strcmp(opt, "-P") == 0){
 810:	aa1803e1 	mov	x1, x24
 814:	aa1603e0 	mov	x0, x22
 818:	97ffff9e 	bl	690 <strcmp@plt>
 81c:	350000c0 	cbnz	w0, 834 <main+0x154>
      if(!parse_num(val, &prio)) usage();
 820:	910183e1 	add	x1, sp, #0x60
 824:	aa1503e0 	mov	x0, x21
 828:	940000b8 	bl	b08 <parse_num>
 82c:	35fffee0 	cbnz	w0, 808 <main+0x128>
 830:	17ffffdf 	b	7ac <main+0xcc>
    } else if(strcmp(opt, "-c") == 0){
 834:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 838:	9133a821 	add	x1, x1, #0xcea
 83c:	aa1603e0 	mov	x0, x22
 840:	97ffff94 	bl	690 <strcmp@plt>
 844:	35000120 	cbnz	w0, 868 <main+0x188>
      if(!parse_num(val, &cpu) || cpu < 0 || cpu >= NCPU) usage();
 848:	910193e1 	add	x1, sp, #0x64
 84c:	aa1503e0 	mov	x0, x21
 850:	940000ae 	bl	b08 <parse_num>
 854:	34fffac0 	cbz	w0, 7ac <main+0xcc>
 858:	b94067e0 	ldr	w0, [sp, #100]
 85c:	71000c1f 	cmp	w0, #0x3
      if(!parse_num(val, &hogs) || hogs < 0 || hogs > 8) usage();
 860:	54fffd49 	b.ls	808 <main+0x128>  // b.plast
 864:	17ffffd2 	b	7ac <main+0xcc>
    } else if(strcmp(opt, "-l") == 0){
 868:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 86c:	9133b421 	add	x1, x1, #0xced
 870:	aa1603e0 	mov	x0, x22
 874:	97ffff87 	bl	690 <strcmp@plt>
 878:	35000100 	cbnz	w0, 898 <main+0x1b8>
      if(!parse_num(val, &hogs) || hogs < 0 || hogs > 8) usage();
 87c:	9101a3e1 	add	x1, sp, #0x68
 880:	aa1503e0 	mov	x0, x21
 884:	940000a1 	bl	b08 <parse_num>
 888:	34fff920 	cbz	w0, 7ac <main+0xcc>
 88c:	b9406be0 	ldr	w0, [sp, #104]
 890:	7100201f 	cmp	w0, #0x8
 894:	17fffff3 	b	860 <main+0x180>
    } else if(strcmp(opt, "-n") == 0){
 898:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 89c:	9133c021 	add	x1, x1, #0xcf0
 8a0:	aa1603e0 	mov	x0, x22
 8a4:	97ffff7b 	bl	690 <strcmp@plt>
 8a8:	35fff820 	cbnz	w0, 7ac <main+0xcc>
      if(!parse_num(val, &samples) || samples < 1) usage();
 8ac:	9101b3e1 	add	x1, sp, #0x6c
 8b0:	aa1503e0 	mov	x0, x21
 8b4:	94000095 	bl	b08 <parse_num>
 8b8:	34fff7a0 	cbz	w0, 7ac <main+0xcc>
 8bc:	b9406fe0 	ldr	w0, [sp, #108]
 8c0:	7100001f 	cmp	w0, #0x0
 8c4:	54fffa2c 	b.gt	808 <main+0x128>
 8c8:	17ffffb9 	b	7ac <main+0xcc>
      if(strcmp(val, "fifo") == 0) policy = SCHED_FIFO;
 8cc:	52800034 	mov	w20, #0x1                   	// #1
 8d0:	17ffffce 	b	808 <main+0x128>
      else if(strcmp(val, "rr") == 0) policy = SCHED_RR;
 8d4:	52800054 	mov	w20, #0x2                   	// #2
 8d8:	17ffffcc 	b	808 <main+0x128>
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 8dc:	7100069f 	cmp	w20, #0x1
 8e0:	90000000 	adrp	x0, 0 <.plt-0x5c0>
 8e4:	9132d800 	add	x0, x0, #0xcb6
 8e8:	90000013 	adrp	x19, 0 <.plt-0x5c0>
 8ec:	91333673 	add	x19, x19, #0xccd
 8f0:	9a801273 	csel	x19, x19, x0, ne	// ne = any
 8f4:	17ffff97 	b	750 <main+0x70>
  }

  // CPU hogs: ordinary time-sharing tasks that never block.
  for(int h = 0; h < hogs; h++){
    if((hog_pid[h] = fork()) == 0){
 8f8:	97ffff5e 	bl	670 <fork@plt>
 8fc:	b8377b00 	str	w0, [x24, x23, lsl #2]
 900:	910006f7 	add	x23, x23, #0x1
 904:	35000280 	cbnz	w0, 954 <main+0x274>
      close(fds[0]);
 908:	b94073e0 	ldr	w0, [sp, #112]
 90c:	97ffff71 	bl	6d0 <close@plt>
      close(fds[1]);
 910:	b94077e0 	ldr	w0, [sp, #116]
 914:	97ffff6f 	bl	6d0 <close@plt>
      sched_setaffinity(0, 1U << cpu);
 918:	52800021 	mov	w1, #0x1                   	// #1
 91c:	52800000 	mov	w0, #0x0                   	// #0
 920:	1ad62021 	lsl	w1, w1, w22
 924:	97ffff5f 	bl	6a0 <sched_setaffinity@plt>
      sched_setscheduler(0, SCHED_OTHER, 0);
 928:	52800002 	mov	w2, #0x0                   	// #0
 92c:	52800001 	mov	w1, #0x0                   	// #0
 930:	52800000 	mov	w0, #0x0                   	// #0
 934:	97ffff2f 	bl	5f0 <sched_setscheduler@plt>
      for(volatile uint64 n = 0; ; n++)
 938:	f9003fff 	str	xzr, [sp, #120]
 93c:	f9403fe0 	ldr	x0, [sp, #120]
 940:	91000400 	add	x0, x0, #0x1
 944:	f9003fe0 	str	x0, [sp, #120]
 948:	17fffffd 	b	93c <main+0x25c>
    if((hog_pid[h] = fork()) == 0){
 94c:	910203f8 	add	x24, sp, #0x80
  if(pipe(fds) < 0){
 950:	d2800017 	mov	x23, #0x0                   	// #0
  for(int h = 0; h < hogs; h++){
 954:	6b17033f 	cmp	w25, w23
 958:	54fffd0c 	b.gt	8f8 <main+0x218>
      sched_setaffinity(0, 1U << cpu);
 95c:	5280003b 	mov	w27, #0x1                   	// #1
        ;
    }
  }

  if((reader = fork()) == 0){
 960:	97ffff44 	bl	670 <fork@plt>
      sched_setaffinity(0, 1U << cpu);
 964:	1ad62378 	lsl	w24, w27, w22
  if((reader = fork()) == 0){
 968:	2a0003f7 	mov	w23, w0
 96c:	35000880 	cbnz	w0, a7c <main+0x39c>
    uint64 ts, lat, min = ~0ULL, max = 0, sum = 0;
    int over1ms = 0, wrong_cpu = 0;

    close(fds[1]);
 970:	b94077e0 	ldr	w0, [sp, #116]
 974:	97ffff57 	bl	6d0 <close@plt>
    sched_setaffinity(0, 1U << cpu);
 978:	2a1803e1 	mov	w1, w24
 97c:	52800000 	mov	w0, #0x0                   	// #0
 980:	97ffff48 	bl	6a0 <sched_setaffinity@plt>
    if(sched_setscheduler(0, policy, prio) < 0){
 984:	2a1a03e2 	mov	w2, w26
 988:	2a1403e1 	mov	w1, w20
 98c:	52800000 	mov	w0, #0x0                   	// #0
 990:	97ffff18 	bl	5f0 <sched_setscheduler@plt>
 994:	36f80680 	tbz	w0, #31, a64 <main+0x384>
      fprintf(2, "rtlat: cannot set reader policy\n");
 998:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 99c:	91354021 	add	x1, x1, #0xd50
 9a0:	17ffff7c 	b	790 <main+0xb0>
      exit(1);
    }
    for(int s = 0; s < samples; s++){
      if(read(fds[0], &ts, sizeof(ts)) != sizeof(ts))
 9a4:	b94073e0 	ldr	w0, [sp, #112]
 9a8:	9101e3e1 	add	x1, sp, #0x78
 9ac:	52800102 	mov	w2, #0x8                   	// #8
 9b0:	97ffff2c 	bl	660 <read@plt>
 9b4:	7100201f 	cmp	w0, #0x8
 9b8:	54000221 	b.ne	9fc <main+0x31c>  // b.any
        break;
      lat = clock_us() - ts;
 9bc:	97ffff3d 	bl	6b0 <clock_us@plt>
    for(int s = 0; s < samples; s++){
 9c0:	1100079c 	add	w28, w28, #0x1
      lat = clock_us() - ts;
 9c4:	f9403fe1 	ldr	x1, [sp, #120]
 9c8:	cb010014 	sub	x20, x0, x1
      if(getcpu() != cpu)
 9cc:	97ffff2d 	bl	680 <getcpu@plt>
        wrong_cpu++;
 9d0:	6b0002df 	cmp	w22, w0
 9d4:	1a9706f7 	cinc	w23, w23, ne	// ne = any
      if(lat < min) min = lat;
 9d8:	eb14033f 	cmp	x25, x20
 9dc:	9a949339 	csel	x25, x25, x20, ls	// ls = plast
      if(lat > max) max = lat;
 9e0:	eb14031f 	cmp	x24, x20
 9e4:	9a942318 	csel	x24, x24, x20, cs	// cs = hs, nlast
      if(lat > 1000) over1ms++;
 9e8:	f10fa29f 	cmp	x20, #0x3e8
 9ec:	1a9a975a 	cinc	w26, w26, hi	// hi = pmore
      sum += lat;
 9f0:	8b14037b 	add	x27, x27, x20
    for(int s = 0; s < samples; s++){
 9f4:	6b1c02bf 	cmp	w21, w28
 9f8:	54fffd6c 	b.gt	9a4 <main+0x2c4>
    }
    printf("rtlat: %s wakeup latency over %d samples\n",
 9fc:	2a1503e2 	mov	w2, w21
 a00:	aa1303e1 	mov	x1, x19
 a04:	90000000 	adrp	x0, 0 <.plt-0x5c0>
 a08:	9135c400 	add	x0, x0, #0xd71
 a0c:	97fffef5 	bl	5e0 <printf@plt>
           policy_name(policy), samples);
    print_us("min", min);
 a10:	aa1903e1 	mov	x1, x25
 a14:	90000000 	adrp	x0, 0 <.plt-0x5c0>
 a18:	91366c00 	add	x0, x0, #0xd9b
 a1c:	94000077 	bl	bf8 <print_us>
    print_us("avg", sum / samples);
 a20:	93407ea1 	sxtw	x1, w21
 a24:	90000000 	adrp	x0, 0 <.plt-0x5c0>
 a28:	91367c00 	add	x0, x0, #0xd9f
 a2c:	9ac10b61 	udiv	x1, x27, x1
 a30:	94000072 	bl	bf8 <print_us>
    print_us("max", max);
 a34:	aa1803e1 	mov	x1, x24
 a38:	90000000 	adrp	x0, 0 <.plt-0x5c0>
 a3c:	91368c00 	add	x0, x0, #0xda3
 a40:	9400006e 	bl	bf8 <print_us>
    printf("  samples > 1 ms: %d, ran on a CPU other than CPU%d: %d\n",
 a44:	90000000 	adrp	x0, 0 <.plt-0x5c0>
 a48:	91369c00 	add	x0, x0, #0xda7
 a4c:	2a1703e3 	mov	w3, w23
 a50:	2a1603e2 	mov	w2, w22
 a54:	2a1a03e1 	mov	w1, w26
 a58:	97fffee2 	bl	5e0 <printf@plt>
  wait(0);                          // reader
  for(int h = 0; h < hogs; h++){
    kill(hog_pid[h]);
    wait(0);
  }
  exit(0);
 a5c:	52800000 	mov	w0, #0x0                   	// #0
 a60:	17ffff4f 	b	79c <main+0xbc>
    for(int s = 0; s < samples; s++){
 a64:	5280001c 	mov	w28, #0x0                   	// #0
    int over1ms = 0, wrong_cpu = 0;
 a68:	5280001a 	mov	w26, #0x0                   	// #0
    uint64 ts, lat, min = ~0ULL, max = 0, sum = 0;
 a6c:	d280001b 	mov	x27, #0x0                   	// #0
 a70:	d2800018 	mov	x24, #0x0                   	// #0
 a74:	92800019 	mov	x25, #0xffffffffffffffff    	// #-1
 a78:	17ffffdf 	b	9f4 <main+0x314>
  close(fds[0]);
 a7c:	b94073e0 	ldr	w0, [sp, #112]
  for(int s = 0; s < samples; s++){
 a80:	52800013 	mov	w19, #0x0                   	// #0
  close(fds[0]);
 a84:	97ffff13 	bl	6d0 <close@plt>
  sched_setaffinity(0, ((1U << NCPU) - 1) & ~(1U << cpu));
 a88:	2a3803e1 	mvn	w1, w24
 a8c:	52800000 	mov	w0, #0x0                   	// #0
 a90:	12000c21 	and	w1, w1, #0xf
 a94:	97ffff03 	bl	6a0 <sched_setaffinity@plt>
  sleep_ticks(2);                   // let the hogs and reader settle
 a98:	52800040 	mov	w0, #0x2                   	// #2
 a9c:	97fffee9 	bl	640 <sleep_ticks@plt>
  for(int s = 0; s < samples; s++){
 aa0:	6b1302bf 	cmp	w21, w19
 aa4:	540001ec 	b.gt	ae0 <main+0x400>
  close(fds[1]);
 aa8:	b94077e0 	ldr	w0, [sp, #116]
    kill(hog_pid[h]);
 aac:	910203f4 	add	x20, sp, #0x80
  for(int h = 0; h < hogs; h++){
 ab0:	d2800013 	mov	x19, #0x0                   	// #0
  close(fds[1]);
 ab4:	97ffff07 	bl	6d0 <close@plt>
  wait(0);                          // reader
 ab8:	d2800000 	mov	x0, #0x0                   	// #0
 abc:	97fffee5 	bl	650 <wait@plt>
  for(int h = 0; h < hogs; h++){
 ac0:	6b13033f 	cmp	w25, w19
 ac4:	54fffccd 	b.le	a5c <main+0x37c>
    kill(hog_pid[h]);
 ac8:	b8737a80 	ldr	w0, [x20, x19, lsl #2]
 acc:	91000673 	add	x19, x19, #0x1
 ad0:	97fffed8 	bl	630 <kill@plt>
    wait(0);
 ad4:	d2800000 	mov	x0, #0x0                   	// #0
 ad8:	97fffede 	bl	650 <wait@plt>
  for(int h = 0; h < hogs; h++){
 adc:	17fffff9 	b	ac0 <main+0x3e0>
    sleep_ticks(1);                 // one xv6 tick, 100 ms
 ae0:	52800020 	mov	w0, #0x1                   	// #1
 ae4:	97fffed7 	bl	640 <sleep_ticks@plt>
    uint64 now = clock_us();
 ae8:	97fffef2 	bl	6b0 <clock_us@plt>
 aec:	f9003fe0 	str	x0, [sp, #120]
    write(fds[1], &now, sizeof(now));
 af0:	b94077e0 	ldr	w0, [sp, #116]
 af4:	9101e3e1 	add	x1, sp, #0x78
  for(int s = 0; s < samples; s++){
 af8:	11000673 	add	w19, w19, #0x1
    write(fds[1], &now, sizeof(now));
 afc:	52800102 	mov	w2, #0x8                   	// #8
 b00:	97fffec4 	bl	610 <write@plt>
  for(int s = 0; s < samples; s++){
 b04:	17ffffe7 	b	aa0 <main+0x3c0>

0000000000000b08 <parse_num>:
{
 b08:	aa0003e2 	mov	x2, x0
  if(*s == '-'){
 b0c:	39400000 	ldrb	w0, [x0]
 b10:	7100b41f 	cmp	w0, #0x2d
 b14:	540002c1 	b.ne	b6c <parse_num+0x64>  // b.any
    s++;
 b18:	91000442 	add	x2, x2, #0x1
    neg = 1;
 b1c:	52800025 	mov	w5, #0x1                   	// #1
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 b20:	39400040 	ldrb	w0, [x2]
 b24:	7100c01f 	cmp	w0, #0x30
 b28:	540000c1 	b.ne	b40 <parse_num+0x38>  // b.any
 b2c:	39400440 	ldrb	w0, [x2, #1]
 b30:	121a7800 	and	w0, w0, #0xffffffdf
 b34:	12001c00 	and	w0, w0, #0xff
 b38:	7101601f 	cmp	w0, #0x58
 b3c:	540001c0 	b.eq	b74 <parse_num+0x6c>  // b.none
 b40:	52800000 	mov	w0, #0x0                   	// #0
 b44:	52800003 	mov	w3, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 b48:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
 b4c:	39400044 	ldrb	w4, [x2]
 b50:	340001c4 	cbz	w4, b88 <parse_num+0x80>
      if(*s < '0' || *s > '9')
 b54:	5100c084 	sub	w4, w4, #0x30
 b58:	12001c80 	and	w0, w4, #0xff
 b5c:	7100241f 	cmp	w0, #0x9
 b60:	54000449 	b.ls	be8 <parse_num+0xe0>  // b.plast
      else return 0;
 b64:	52800000 	mov	w0, #0x0                   	// #0
}
 b68:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
 b6c:	52800005 	mov	w5, #0x0                   	// #0
 b70:	17ffffec 	b	b20 <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
 b74:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
 b78:	52800000 	mov	w0, #0x0                   	// #0
 b7c:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 b80:	39400044 	ldrb	w4, [x2]
 b84:	350000c4 	cbnz	w4, b9c <parse_num+0x94>
  if(!any)
 b88:	34ffff00 	cbz	w0, b68 <parse_num+0x60>
  *out = neg ? -v : v;
 b8c:	710000bf 	cmp	w5, #0x0
 b90:	5a830463 	cneg	w3, w3, ne	// ne = any
 b94:	b9000023 	str	w3, [x1]
  return 1;
 b98:	17fffff4 	b	b68 <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 b9c:	5100c080 	sub	w0, w4, #0x30
 ba0:	12001c06 	and	w6, w0, #0xff
 ba4:	710024df 	cmp	w6, #0x9
 ba8:	540000c9 	b.ls	bc0 <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 bac:	51018480 	sub	w0, w4, #0x61
 bb0:	12001c00 	and	w0, w0, #0xff
 bb4:	7100141f 	cmp	w0, #0x5
 bb8:	540000c8 	b.hi	bd0 <parse_num+0xc8>  // b.pmore
 bbc:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
 bc0:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
 bc4:	91000442 	add	x2, x2, #0x1
 bc8:	52800020 	mov	w0, #0x1                   	// #1
 bcc:	17ffffed 	b	b80 <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 bd0:	51010480 	sub	w0, w4, #0x41
 bd4:	12001c00 	and	w0, w0, #0xff
 bd8:	7100141f 	cmp	w0, #0x5
 bdc:	54fffc48 	b.hi	b64 <parse_num+0x5c>  // b.pmore
 be0:	5100dc80 	sub	w0, w4, #0x37
 be4:	17fffff7 	b	bc0 <parse_num+0xb8>
      v = v * 10 + (*s - '0');
 be8:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
 bec:	91000442 	add	x2, x2, #0x1
 bf0:	52800020 	mov	w0, #0x1                   	// #1
 bf4:	17ffffd6 	b	b4c <parse_num+0x44>

0000000000000bf8 <print_us>:
  printf("  %s %l.%l%l%l ms\n", label, us / 1000, (us / 100) % 10,
 bf8:	d2800c82 	mov	x2, #0x64                  	// #100
 bfc:	d2800146 	mov	x6, #0xa                   	// #10
{
 c00:	aa0003e7 	mov	x7, x0
  printf("  %s %l.%l%l%l ms\n", label, us / 1000, (us / 100) % 10,
 c04:	90000000 	adrp	x0, 0 <.plt-0x5c0>
 c08:	91316000 	add	x0, x0, #0xc58
 c0c:	9ac20822 	udiv	x2, x1, x2
 c10:	9ac60824 	udiv	x4, x1, x6
 c14:	9ac60843 	udiv	x3, x2, x6
 c18:	9ac60888 	udiv	x8, x4, x6
 c1c:	9b068485 	msub	x5, x4, x6, x1
 c20:	9b068863 	msub	x3, x3, x6, x2
 c24:	d2807d02 	mov	x2, #0x3e8                 	// #1000
 c28:	9ac20822 	udiv	x2, x1, x2
 c2c:	9b069104 	msub	x4, x8, x6, x4
 c30:	aa0703e1 	mov	x1, x7
 c34:	17fffe6b 	b	5e0 <printf@plt>

0000000000000c38 <usage>:
{
 c38:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: rtlat [-p fifo|rr|other] [-P PRIO] [-c CPU] [-l HOGS] "
 c3c:	90000001 	adrp	x1, 0 <.plt-0x5c0>
 c40:	9131ac21 	add	x1, x1, #0xc6b
{
 c44:	910003fd 	mov	x29, sp
  fprintf(2, "usage: rtlat [-p fifo|rr|other] [-P PRIO] [-c CPU] [-l HOGS] "
 c48:	52800040 	mov	w0, #0x2                   	// #2
 c4c:	97fffe75 	bl	620 <fprintf@plt>
  exit(1);
 c50:	52800020 	mov	w0, #0x1                   	// #1
 c54:	97fffe9b 	bl	6c0 <exit@plt>
