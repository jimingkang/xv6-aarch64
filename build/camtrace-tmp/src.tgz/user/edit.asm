
user/_edit:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000358 <.plt>:
 358:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 35c:	b0000010 	adrp	x16, 1000 <main+0xc18>
 360:	f9434611 	ldr	x17, [x16, #1672]
 364:	911a2210 	add	x16, x16, #0x688
 368:	d61f0220 	br	x17
 36c:	d503201f 	nop
 370:	d503201f 	nop
 374:	d503201f 	nop

0000000000000378 <printf@plt>:
 378:	b0000010 	adrp	x16, 1000 <main+0xc18>
 37c:	f9434a11 	ldr	x17, [x16, #1680]
 380:	911a4210 	add	x16, x16, #0x690
 384:	d61f0220 	br	x17

0000000000000388 <write@plt>:
 388:	b0000010 	adrp	x16, 1000 <main+0xc18>
 38c:	f9434e11 	ldr	x17, [x16, #1688]
 390:	911a6210 	add	x16, x16, #0x698
 394:	d61f0220 	br	x17

0000000000000398 <fprintf@plt>:
 398:	b0000010 	adrp	x16, 1000 <main+0xc18>
 39c:	f9435211 	ldr	x17, [x16, #1696]
 3a0:	911a8210 	add	x16, x16, #0x6a0
 3a4:	d61f0220 	br	x17

00000000000003a8 <read@plt>:
 3a8:	b0000010 	adrp	x16, 1000 <main+0xc18>
 3ac:	f9435611 	ldr	x17, [x16, #1704]
 3b0:	911aa210 	add	x16, x16, #0x6a8
 3b4:	d61f0220 	br	x17

00000000000003b8 <exit@plt>:
 3b8:	b0000010 	adrp	x16, 1000 <main+0xc18>
 3bc:	f9435a11 	ldr	x17, [x16, #1712]
 3c0:	911ac210 	add	x16, x16, #0x6b0
 3c4:	d61f0220 	br	x17

00000000000003c8 <open@plt>:
 3c8:	b0000010 	adrp	x16, 1000 <main+0xc18>
 3cc:	f9435e11 	ldr	x17, [x16, #1720]
 3d0:	911ae210 	add	x16, x16, #0x6b8
 3d4:	d61f0220 	br	x17

00000000000003d8 <close@plt>:
 3d8:	b0000010 	adrp	x16, 1000 <main+0xc18>
 3dc:	f9436211 	ldr	x17, [x16, #1728]
 3e0:	911b0210 	add	x16, x16, #0x6c0
 3e4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000003e8 <main>:
#include <fcntl.h>
#include "user/user.h"

int
main(int argc, char **argv)
{
 3e8:	a9b57bfd 	stp	x29, x30, [sp, #-176]!
 3ec:	910003fd 	mov	x29, sp
 3f0:	a90153f3 	stp	x19, x20, [sp, #16]
 3f4:	f90013f5 	str	x21, [sp, #32]
  char buf[128];
  int n;

  if(argc != 2){
 3f8:	7100081f 	cmp	w0, #0x2
 3fc:	540000c0 	b.eq	414 <main+0x2c>  // b.none
    fprintf(2, "usage: edit file\n");
 400:	90000001 	adrp	x1, 0 <.plt-0x358>
 404:	91132021 	add	x1, x1, #0x4c8
      exit(1);
    }
  }
  close(fd);
  if(n < 0){
    fprintf(2, "edit: read failed\n");
 408:	52800040 	mov	w0, #0x2                   	// #2
 40c:	97ffffe3 	bl	398 <fprintf@plt>
    exit(1);
 410:	1400000d 	b	444 <main+0x5c>
 414:	aa0103f5 	mov	x21, x1
  int fd = open(argv[1], O_CREATE | O_WRONLY | O_TRUNC);
 418:	2a0003f3 	mov	w19, w0
 41c:	5280c021 	mov	w1, #0x601                 	// #1537
 420:	f94006a0 	ldr	x0, [x21, #8]
 424:	97ffffe9 	bl	3c8 <open@plt>
 428:	2a0003f4 	mov	w20, w0
  if(fd < 0){
 42c:	36f80100 	tbz	w0, #31, 44c <main+0x64>
    fprintf(2, "edit: cannot open %s\n", argv[1]);
 430:	f94006a2 	ldr	x2, [x21, #8]
 434:	90000001 	adrp	x1, 0 <.plt-0x358>
 438:	91136821 	add	x1, x1, #0x4da
 43c:	2a1303e0 	mov	w0, w19
 440:	97ffffd6 	bl	398 <fprintf@plt>
    exit(1);
 444:	52800020 	mov	w0, #0x1                   	// #1
 448:	97ffffdc 	bl	3b8 <exit@plt>
  printf("edit: enter text; press Ctrl-D on a new line to save\n");
 44c:	90000000 	adrp	x0, 0 <.plt-0x358>
 450:	9113c000 	add	x0, x0, #0x4f0
 454:	97ffffc9 	bl	378 <printf@plt>
  while((n = read(0, buf, sizeof(buf))) > 0){
 458:	9100c3e1 	add	x1, sp, #0x30
 45c:	52801002 	mov	w2, #0x80                  	// #128
 460:	52800000 	mov	w0, #0x0                   	// #0
 464:	97ffffd1 	bl	3a8 <read@plt>
 468:	2a0003f3 	mov	w19, w0
 46c:	7100001f 	cmp	w0, #0x0
 470:	540000ec 	b.gt	48c <main+0xa4>
  close(fd);
 474:	2a1403e0 	mov	w0, w20
 478:	97ffffd8 	bl	3d8 <close@plt>
  if(n < 0){
 47c:	34000233 	cbz	w19, 4c0 <main+0xd8>
    fprintf(2, "edit: read failed\n");
 480:	90000001 	adrp	x1, 0 <.plt-0x358>
 484:	9114e821 	add	x1, x1, #0x53a
 488:	17ffffe0 	b	408 <main+0x20>
    if(write(fd, buf, n) != n){
 48c:	2a1303e2 	mov	w2, w19
 490:	9100c3e1 	add	x1, sp, #0x30
 494:	2a1403e0 	mov	w0, w20
 498:	97ffffbc 	bl	388 <write@plt>
 49c:	6b13001f 	cmp	w0, w19
 4a0:	54fffdc0 	b.eq	458 <main+0x70>  // b.none
      fprintf(2, "edit: write failed\n");
 4a4:	90000001 	adrp	x1, 0 <.plt-0x358>
 4a8:	91149821 	add	x1, x1, #0x526
 4ac:	52800040 	mov	w0, #0x2                   	// #2
 4b0:	97ffffba 	bl	398 <fprintf@plt>
      close(fd);
 4b4:	2a1403e0 	mov	w0, w20
 4b8:	97ffffc8 	bl	3d8 <close@plt>
      exit(1);
 4bc:	17ffffe2 	b	444 <main+0x5c>
  }
  exit(0);
 4c0:	52800000 	mov	w0, #0x0                   	// #0
 4c4:	17ffffe1 	b	448 <main+0x60>
