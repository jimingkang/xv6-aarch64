
user/_umount:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000278 <.plt>:
 278:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 27c:	b0000010 	adrp	x16, 1000 <main+0xd38>
 280:	f9425611 	ldr	x17, [x16, #1192]
 284:	9112a210 	add	x16, x16, #0x4a8
 288:	d61f0220 	br	x17
 28c:	d503201f 	nop
 290:	d503201f 	nop
 294:	d503201f 	nop

0000000000000298 <fprintf@plt>:
 298:	b0000010 	adrp	x16, 1000 <main+0xd38>
 29c:	f9425a11 	ldr	x17, [x16, #1200]
 2a0:	9112c210 	add	x16, x16, #0x4b0
 2a4:	d61f0220 	br	x17

00000000000002a8 <umount@plt>:
 2a8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2ac:	f9425e11 	ldr	x17, [x16, #1208]
 2b0:	9112e210 	add	x16, x16, #0x4b8
 2b4:	d61f0220 	br	x17

00000000000002b8 <exit@plt>:
 2b8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2bc:	f9426211 	ldr	x17, [x16, #1216]
 2c0:	91130210 	add	x16, x16, #0x4c0
 2c4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000002c8 <main>:
#include "user.h"

int
main(int argc, char **argv)
{
 2c8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 2cc:	910003fd 	mov	x29, sp
 2d0:	a90153f3 	stp	x19, x20, [sp, #16]
  if(argc != 2){
 2d4:	7100081f 	cmp	w0, #0x2
 2d8:	540000e0 	b.eq	2f4 <main+0x2c>  // b.none
    fprintf(2, "usage: umount target\n");
 2dc:	90000001 	adrp	x1, 0 <.plt-0x278>
 2e0:	910ca021 	add	x1, x1, #0x328
 2e4:	52800040 	mov	w0, #0x2                   	// #2
 2e8:	97ffffec 	bl	298 <fprintf@plt>
    exit(1);
  }
  if(umount(argv[1]) < 0){
    fprintf(2, "umount: %s failed (busy, root, or flush error)\n", argv[1]);
    exit(1);
 2ec:	52800020 	mov	w0, #0x1                   	// #1
 2f0:	97fffff2 	bl	2b8 <exit@plt>
 2f4:	2a0003f3 	mov	w19, w0
 2f8:	aa0103f4 	mov	x20, x1
  if(umount(argv[1]) < 0){
 2fc:	f9400420 	ldr	x0, [x1, #8]
 300:	97ffffea 	bl	2a8 <umount@plt>
 304:	36f800e0 	tbz	w0, #31, 320 <main+0x58>
    fprintf(2, "umount: %s failed (busy, root, or flush error)\n", argv[1]);
 308:	f9400682 	ldr	x2, [x20, #8]
 30c:	2a1303e0 	mov	w0, w19
 310:	90000001 	adrp	x1, 0 <.plt-0x278>
 314:	910cf821 	add	x1, x1, #0x33e
 318:	97ffffe0 	bl	298 <fprintf@plt>
 31c:	17fffff4 	b	2ec <main+0x24>
  }
  exit(0);
 320:	52800000 	mov	w0, #0x0                   	// #0
 324:	17fffff3 	b	2f0 <main+0x28>
