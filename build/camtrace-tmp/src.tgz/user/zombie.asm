
user/_zombie:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000278 <.plt>:
 278:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 27c:	b0000010 	adrp	x16, 1000 <main+0xd38>
 280:	f9421611 	ldr	x17, [x16, #1064]
 284:	9110a210 	add	x16, x16, #0x428
 288:	d61f0220 	br	x17
 28c:	d503201f 	nop
 290:	d503201f 	nop
 294:	d503201f 	nop

0000000000000298 <sleep_ticks@plt>:
 298:	b0000010 	adrp	x16, 1000 <main+0xd38>
 29c:	f9421a11 	ldr	x17, [x16, #1072]
 2a0:	9110c210 	add	x16, x16, #0x430
 2a4:	d61f0220 	br	x17

00000000000002a8 <fork@plt>:
 2a8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2ac:	f9421e11 	ldr	x17, [x16, #1080]
 2b0:	9110e210 	add	x16, x16, #0x438
 2b4:	d61f0220 	br	x17

00000000000002b8 <exit@plt>:
 2b8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2bc:	f9422211 	ldr	x17, [x16, #1088]
 2c0:	91110210 	add	x16, x16, #0x440
 2c4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000002c8 <main>:
#include <uapi/stat.h>
#include "user/user.h"

int
main(void)
{
 2c8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 2cc:	910003fd 	mov	x29, sp
  if(fork() > 0)
 2d0:	97fffff6 	bl	2a8 <fork@plt>
 2d4:	7100001f 	cmp	w0, #0x0
 2d8:	5400006d 	b.le	2e4 <main+0x1c>
    sleep_ticks(5);  // Let child exit before parent.
 2dc:	528000a0 	mov	w0, #0x5                   	// #5
 2e0:	97ffffee 	bl	298 <sleep_ticks@plt>
  exit(0);
 2e4:	52800000 	mov	w0, #0x0                   	// #0
 2e8:	97fffff4 	bl	2b8 <exit@plt>
