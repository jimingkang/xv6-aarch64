
user/_waltest:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000005b0 <.plt>:
 5b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 5b4:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 5b8:	f9441a11 	ldr	x17, [x16, #2096]
 5bc:	9120c210 	add	x16, x16, #0x830
 5c0:	d61f0220 	br	x17
 5c4:	d503201f 	nop
 5c8:	d503201f 	nop
 5cc:	d503201f 	nop

00000000000005d0 <strcpy@plt>:
 5d0:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 5d4:	f9441e11 	ldr	x17, [x16, #2104]
 5d8:	9120e210 	add	x16, x16, #0x838
 5dc:	d61f0220 	br	x17

00000000000005e0 <printf@plt>:
 5e0:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 5e4:	f9442211 	ldr	x17, [x16, #2112]
 5e8:	91210210 	add	x16, x16, #0x840
 5ec:	d61f0220 	br	x17

00000000000005f0 <ftruncate@plt>:
 5f0:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 5f4:	f9442611 	ldr	x17, [x16, #2120]
 5f8:	91212210 	add	x16, x16, #0x848
 5fc:	d61f0220 	br	x17

0000000000000600 <rename@plt>:
 600:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 604:	f9442a11 	ldr	x17, [x16, #2128]
 608:	91214210 	add	x16, x16, #0x850
 60c:	d61f0220 	br	x17

0000000000000610 <fdatasync@plt>:
 610:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 614:	f9442e11 	ldr	x17, [x16, #2136]
 618:	91216210 	add	x16, x16, #0x858
 61c:	d61f0220 	br	x17

0000000000000620 <unlink@plt>:
 620:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 624:	f9443211 	ldr	x17, [x16, #2144]
 628:	91218210 	add	x16, x16, #0x860
 62c:	d61f0220 	br	x17

0000000000000630 <memset@plt>:
 630:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 634:	f9443611 	ldr	x17, [x16, #2152]
 638:	9121a210 	add	x16, x16, #0x868
 63c:	d61f0220 	br	x17

0000000000000640 <strcmp@plt>:
 640:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 644:	f9443a11 	ldr	x17, [x16, #2160]
 648:	9121c210 	add	x16, x16, #0x870
 64c:	d61f0220 	br	x17

0000000000000650 <fsync@plt>:
 650:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 654:	f9443e11 	ldr	x17, [x16, #2168]
 658:	9121e210 	add	x16, x16, #0x878
 65c:	d61f0220 	br	x17

0000000000000660 <pread@plt>:
 660:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 664:	f9444211 	ldr	x17, [x16, #2176]
 668:	91220210 	add	x16, x16, #0x880
 66c:	d61f0220 	br	x17

0000000000000670 <exit@plt>:
 670:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 674:	f9444611 	ldr	x17, [x16, #2184]
 678:	91222210 	add	x16, x16, #0x888
 67c:	d61f0220 	br	x17

0000000000000680 <atoi@plt>:
 680:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 684:	f9444a11 	ldr	x17, [x16, #2192]
 688:	91224210 	add	x16, x16, #0x890
 68c:	d61f0220 	br	x17

0000000000000690 <open@plt>:
 690:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 694:	f9444e11 	ldr	x17, [x16, #2200]
 698:	91226210 	add	x16, x16, #0x898
 69c:	d61f0220 	br	x17

00000000000006a0 <mkdir@plt>:
 6a0:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 6a4:	f9445211 	ldr	x17, [x16, #2208]
 6a8:	91228210 	add	x16, x16, #0x8a0
 6ac:	d61f0220 	br	x17

00000000000006b0 <pwrite@plt>:
 6b0:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 6b4:	f9445611 	ldr	x17, [x16, #2216]
 6b8:	9122a210 	add	x16, x16, #0x8a8
 6bc:	d61f0220 	br	x17

00000000000006c0 <close@plt>:
 6c0:	d0000010 	adrp	x16, 2000 <commit_value+0xf00>
 6c4:	f9445a11 	ldr	x17, [x16, #2224]
 6c8:	9122c210 	add	x16, x16, #0x8b0
 6cc:	d61f0220 	br	x17

Disassembly of section .text:

00000000000006d0 <main>:
  }
}

int
main(int argc, char **argv)
{
     6d0:	a9b47bfd 	stp	x29, x30, [sp, #-192]!
     6d4:	910003fd 	mov	x29, sp
     6d8:	a90153f3 	stp	x19, x20, [sp, #16]
     6dc:	a9025bf5 	stp	x21, x22, [sp, #32]
     6e0:	a90363f7 	stp	x23, x24, [sp, #48]
  if(argc < 2){
     6e4:	7100041f 	cmp	w0, #0x1
     6e8:	540000cc 	b.gt	700 <main+0x30>
    printf("usage: waltest init|commit N|prepare N|recover|show|large|fsops|semantics|jstress\n");
     6ec:	b0000000 	adrp	x0, 1000 <load+0x18>
     6f0:	910d1800 	add	x0, x0, #0x346
     6f4:	97ffffbb 	bl	5e0 <printf@plt>
    exit(1);
     6f8:	52800020 	mov	w0, #0x1                   	// #1
  else if(strcmp(argv[1], "large") == 0) r = large_test();
  else if(strcmp(argv[1], "fsops") == 0) r = fsops_test();
  else if(strcmp(argv[1], "semantics") == 0) r = semantics_test();
  else if(strcmp(argv[1], "jstress") == 0) r = journal_stress();
  else printf("waltest: bad command\n");
  exit(r < 0);
     6fc:	97ffffdd 	bl	670 <exit@plt>
     700:	aa0103f5 	mov	x21, x1
  if(strcmp(argv[1], "init") == 0) r = initialize();
     704:	2a0003f3 	mov	w19, w0
     708:	b0000001 	adrp	x1, 1000 <load+0x18>
     70c:	910e6421 	add	x1, x1, #0x399
     710:	f94006a0 	ldr	x0, [x21, #8]
     714:	97ffffcb 	bl	640 <strcmp@plt>
     718:	35000420 	cbnz	w0, 79c <main+0xcc>
  mkdir(WALDIR); // EEXIST is harmless in this small libc.
     71c:	b0000014 	adrp	x20, 1000 <load+0x18>
     720:	910e7a80 	add	x0, x20, #0x39e
     724:	97ffffdf 	bl	6a0 <mkdir@plt>
  memset(&data, 0, sizeof(data));
     728:	52800402 	mov	w2, #0x20                  	// #32
     72c:	52800001 	mov	w1, #0x0                   	// #0
     730:	910203e0 	add	x0, sp, #0x80
     734:	97ffffbf 	bl	630 <memset@plt>
  data.magic = MAGIC; data.kind = 2; data.txid = 0; data.value = 0;
     738:	d2898620 	mov	x0, #0x4c31                	// #19505
     73c:	f2aae820 	movk	x0, #0x5741, lsl #16
     740:	f2c00040 	movk	x0, #0x2, lsl #32
     744:	a9087fe0 	stp	x0, xzr, [sp, #128]
  data.checksum = checksum(&data);
     748:	910203e0 	add	x0, sp, #0x80
  data.magic = MAGIC; data.kind = 2; data.txid = 0; data.value = 0;
     74c:	f9004bff 	str	xzr, [sp, #144]
  data.checksum = checksum(&data);
     750:	940001dd 	bl	ec4 <checksum>
  if(store(DBFILE, &data) < 0 || clear_wal() < 0)
     754:	910203e1 	add	x1, sp, #0x80
  data.checksum = checksum(&data);
     758:	b9009be0 	str	w0, [sp, #152]
  if(store(DBFILE, &data) < 0 || clear_wal() < 0)
     75c:	b0000000 	adrp	x0, 1000 <load+0x18>
     760:	9109ec00 	add	x0, x0, #0x27b
     764:	940001e5 	bl	ef8 <store>
     768:	2a0003f3 	mov	w19, w0
     76c:	3100041f 	cmn	w0, #0x1
     770:	54000300 	b.eq	7d0 <main+0x100>  // b.none
     774:	94000249 	bl	1098 <clear_wal>
     778:	2a0003f3 	mov	w19, w0
     77c:	3100041f 	cmn	w0, #0x1
     780:	54000280 	b.eq	7d0 <main+0x100>  // b.none
  printf("waltest: initialized %s value=0\n", WALDIR);
     784:	b0000000 	adrp	x0, 1000 <load+0x18>
     788:	910ec000 	add	x0, x0, #0x3b0
     78c:	910e7a81 	add	x1, x20, #0x39e
     790:	97ffff94 	bl	5e0 <printf@plt>
  return 0;
     794:	52800013 	mov	w19, #0x0                   	// #0
    r = recover();
     798:	1400000e 	b	7d0 <main+0x100>
  else if(strcmp(argv[1], "commit") == 0 && argc == 3)
     79c:	f94006a0 	ldr	x0, [x21, #8]
     7a0:	b0000001 	adrp	x1, 1000 <load+0x18>
     7a4:	910f4421 	add	x1, x1, #0x3d1
     7a8:	97ffffa6 	bl	640 <strcmp@plt>
     7ac:	35000180 	cbnz	w0, 7dc <main+0x10c>
     7b0:	71000e7f 	cmp	w19, #0x3
     7b4:	54000141 	b.ne	7dc <main+0x10c>  // b.any
    r = commit_value((uint64)atoi(argv[2]), 0);
     7b8:	f9400aa0 	ldr	x0, [x21, #16]
     7bc:	97ffffb1 	bl	680 <atoi@plt>
     7c0:	52800001 	mov	w1, #0x0                   	// #0
    r = commit_value((uint64)atoi(argv[2]), 1);
     7c4:	93407c00 	sxtw	x0, w0
     7c8:	9400024e 	bl	1100 <commit_value>
     7cc:	2a0003f3 	mov	w19, w0
  exit(r < 0);
     7d0:	3100067f 	cmn	w19, #0x1
     7d4:	1a9f17e0 	cset	w0, eq	// eq = none
     7d8:	17ffffc9 	b	6fc <main+0x2c>
  else if(strcmp(argv[1], "prepare") == 0 && argc == 3)
     7dc:	f94006a0 	ldr	x0, [x21, #8]
     7e0:	b0000001 	adrp	x1, 1000 <load+0x18>
     7e4:	910f6021 	add	x1, x1, #0x3d8
     7e8:	97ffff96 	bl	640 <strcmp@plt>
     7ec:	350000e0 	cbnz	w0, 808 <main+0x138>
     7f0:	71000e7f 	cmp	w19, #0x3
     7f4:	540000a1 	b.ne	808 <main+0x138>  // b.any
    r = commit_value((uint64)atoi(argv[2]), 1);
     7f8:	f9400aa0 	ldr	x0, [x21, #16]
     7fc:	97ffffa1 	bl	680 <atoi@plt>
     800:	52800021 	mov	w1, #0x1                   	// #1
     804:	17fffff0 	b	7c4 <main+0xf4>
  else if(strcmp(argv[1], "recover") == 0 || strcmp(argv[1], "show") == 0)
     808:	f94006a0 	ldr	x0, [x21, #8]
     80c:	b0000001 	adrp	x1, 1000 <load+0x18>
     810:	910f8021 	add	x1, x1, #0x3e0
     814:	97ffff8b 	bl	640 <strcmp@plt>
     818:	35000720 	cbnz	w0, 8fc <main+0x22c>
  int have_wal = load(WALFILE, &wal) == 0 && valid(&wal, 1);
     81c:	910103e1 	add	x1, sp, #0x40
     820:	b0000000 	adrp	x0, 1000 <load+0x18>
     824:	91098000 	add	x0, x0, #0x260
     828:	940001f0 	bl	fe8 <load>
     82c:	2a0003f3 	mov	w19, w0
     830:	34000a80 	cbz	w0, 980 <main+0x2b0>
     834:	52800013 	mov	w19, #0x0                   	// #0
  int have_data = load(DBFILE, &data) == 0 && valid(&data, 2);
     838:	b0000014 	adrp	x20, 1000 <load+0x18>
     83c:	9109ee94 	add	x20, x20, #0x27b
     840:	910203e1 	add	x1, sp, #0x80
     844:	aa1403e0 	mov	x0, x20
     848:	940001e8 	bl	fe8 <load>
     84c:	35003380 	cbnz	w0, ebc <main+0x7ec>
  return r->magic == MAGIC && r->kind == kind && r->checksum == checksum(r);
     850:	f94043e1 	ldr	x1, [sp, #128]
     854:	d2898620 	mov	x0, #0x4c31                	// #19505
     858:	f2aae820 	movk	x0, #0x5741, lsl #16
     85c:	f2c00040 	movk	x0, #0x2, lsl #32
     860:	eb00003f 	cmp	x1, x0
     864:	540032c1 	b.ne	ebc <main+0x7ec>  // b.any
     868:	910203e0 	add	x0, sp, #0x80
     86c:	94000196 	bl	ec4 <checksum>
     870:	b9409be5 	ldr	w5, [sp, #152]
  if(have_wal && (!have_data || wal.txid >= data.txid)){
     874:	6b0000bf 	cmp	w5, w0
     878:	34000a73 	cbz	w19, 9c4 <main+0x2f4>
     87c:	540000a1 	b.ne	890 <main+0x1c0>  // b.any
     880:	f94027e1 	ldr	x1, [sp, #72]
     884:	f94047e0 	ldr	x0, [sp, #136]
     888:	eb00003f 	cmp	x1, x0
     88c:	54000923 	b.cc	9b0 <main+0x2e0>  // b.lo, b.ul, b.last
    wal.kind = 2;
     890:	52800040 	mov	w0, #0x2                   	// #2
     894:	b90047e0 	str	w0, [sp, #68]
    wal.checksum = checksum(&wal);
     898:	910103e0 	add	x0, sp, #0x40
     89c:	9400018a 	bl	ec4 <checksum>
    if(store(DBFILE, &wal) < 0 || clear_wal() < 0)
     8a0:	910103e1 	add	x1, sp, #0x40
    wal.checksum = checksum(&wal);
     8a4:	b9005be0 	str	w0, [sp, #88]
    if(store(DBFILE, &wal) < 0 || clear_wal() < 0)
     8a8:	aa1403e0 	mov	x0, x20
     8ac:	94000193 	bl	ef8 <store>
     8b0:	2a0003f3 	mov	w19, w0
     8b4:	3100041f 	cmn	w0, #0x1
     8b8:	54fff8c0 	b.eq	7d0 <main+0x100>  // b.none
     8bc:	940001f7 	bl	1098 <clear_wal>
     8c0:	2a0003f3 	mov	w19, w0
     8c4:	3100041f 	cmn	w0, #0x1
     8c8:	54fff840 	b.eq	7d0 <main+0x100>  // b.none
    data = wal;
     8cc:	a94503e2 	ldp	x2, x0, [sp, #80]
     8d0:	a90903e2 	stp	x2, x0, [sp, #144]
     8d4:	a94407e3 	ldp	x3, x1, [sp, #64]
    printf("waltest: REDO tx=%l value=%l\n", data.txid, data.value);
     8d8:	b0000000 	adrp	x0, 1000 <load+0x18>
     8dc:	910fb400 	add	x0, x0, #0x3ed
    data = wal;
     8e0:	a90807e3 	stp	x3, x1, [sp, #128]
    printf("waltest: REDO tx=%l value=%l\n", data.txid, data.value);
     8e4:	97ffff3f 	bl	5e0 <printf@plt>
  printf("waltest: recovered tx=%l value=%l\n", data.txid, data.value);
     8e8:	a9488be1 	ldp	x1, x2, [sp, #136]
     8ec:	b0000000 	adrp	x0, 1000 <load+0x18>
     8f0:	9110b800 	add	x0, x0, #0x42e
     8f4:	97ffff3b 	bl	5e0 <printf@plt>
     8f8:	17ffffa7 	b	794 <main+0xc4>
  else if(strcmp(argv[1], "recover") == 0 || strcmp(argv[1], "show") == 0)
     8fc:	f94006a0 	ldr	x0, [x21, #8]
     900:	b0000001 	adrp	x1, 1000 <load+0x18>
     904:	910fa021 	add	x1, x1, #0x3e8
     908:	97ffff4e 	bl	640 <strcmp@plt>
     90c:	34fff880 	cbz	w0, 81c <main+0x14c>
  else if(strcmp(argv[1], "large") == 0) r = large_test();
     910:	f94006a0 	ldr	x0, [x21, #8]
     914:	b0000001 	adrp	x1, 1000 <load+0x18>
     918:	91114421 	add	x1, x1, #0x451
     91c:	d0000014 	adrp	x20, 2000 <commit_value+0xf00>
     920:	9122e294 	add	x20, x20, #0x8b8
     924:	97ffff47 	bl	640 <strcmp@plt>
     928:	2a0003f3 	mov	w19, w0
     92c:	35000920 	cbnz	w0, a50 <main+0x380>
  uint64 marker = 0x1122334455667788ULL, got = 0;
     930:	d28ef100 	mov	x0, #0x7788                	// #30600
     934:	f2aaacc0 	movk	x0, #0x5566, lsl #16
     938:	f2c66880 	movk	x0, #0x3344, lsl #32
     93c:	f2e22440 	movk	x0, #0x1122, lsl #48
  return open(path, O_CREATE | O_RDWR);
     940:	52804041 	mov	w1, #0x202                 	// #514
  uint64 marker = 0x1122334455667788ULL, got = 0;
     944:	f90023e0 	str	x0, [sp, #64]
  return open(path, O_CREATE | O_RDWR);
     948:	aa1403e0 	mov	x0, x20
  uint64 marker = 0x1122334455667788ULL, got = 0;
     94c:	f90043ff 	str	xzr, [sp, #128]
  return open(path, O_CREATE | O_RDWR);
     950:	97ffff50 	bl	690 <open@plt>
     954:	2a0003f4 	mov	w20, w0
  if(fd < 0 || ftruncate(fd, size) < 0 ||
     958:	37f800e0 	tbnz	w0, #31, 974 <main+0x2a4>
     95c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
     960:	f2c00021 	movk	x1, #0x1, lsl #32
     964:	97ffff23 	bl	5f0 <ftruncate@plt>
     968:	36f80380 	tbz	w0, #31, 9d8 <main+0x308>
    if(fd >= 0) close(fd);
     96c:	2a1403e0 	mov	w0, w20
     970:	97ffff54 	bl	6c0 <close@plt>
    printf("waltest: 5 GiB triple-indirect sparse test failed\n");
     974:	b0000000 	adrp	x0, 1000 <load+0x18>
     978:	91115c00 	add	x0, x0, #0x457
     97c:	14000015 	b	9d0 <main+0x300>
  return r->magic == MAGIC && r->kind == kind && r->checksum == checksum(r);
     980:	f94023e1 	ldr	x1, [sp, #64]
     984:	d2898620 	mov	x0, #0x4c31                	// #19505
     988:	f2aae820 	movk	x0, #0x5741, lsl #16
     98c:	f2c00020 	movk	x0, #0x1, lsl #32
     990:	eb00003f 	cmp	x1, x0
     994:	54fff521 	b.ne	838 <main+0x168>  // b.any
     998:	910103e0 	add	x0, sp, #0x40
     99c:	9400014a 	bl	ec4 <checksum>
     9a0:	b9405be1 	ldr	w1, [sp, #88]
     9a4:	6b00003f 	cmp	w1, w0
     9a8:	1a9f17f3 	cset	w19, eq	// eq = none
     9ac:	17ffffa3 	b	838 <main+0x168>
  } else if(have_wal && clear_wal() < 0){
     9b0:	940001ba 	bl	1098 <clear_wal>
     9b4:	2a0003f3 	mov	w19, w0
     9b8:	3100041f 	cmn	w0, #0x1
     9bc:	54fff961 	b.ne	8e8 <main+0x218>  // b.any
     9c0:	17ffff84 	b	7d0 <main+0x100>
  if(!have_data){
     9c4:	54fff920 	b.eq	8e8 <main+0x218>  // b.none
    printf("waltest: no valid database record\n");
     9c8:	b0000000 	adrp	x0, 1000 <load+0x18>
     9cc:	91102c00 	add	x0, x0, #0x40b
  else printf("waltest: bad command\n");
     9d0:	97ffff04 	bl	5e0 <printf@plt>
     9d4:	14000037 	b	ab0 <main+0x3e0>
     pwrite(fd, &marker, sizeof(marker), size - sizeof(marker)) != sizeof(marker) ||
     9d8:	910103e1 	add	x1, sp, #0x40
     9dc:	2a1403e0 	mov	w0, w20
     9e0:	b27d77e3 	mov	x3, #0x1fffffff8           	// #8589934584
     9e4:	f2a7ffe3 	movk	x3, #0x3fff, lsl #16
     9e8:	52800102 	mov	w2, #0x8                   	// #8
     9ec:	97ffff31 	bl	6b0 <pwrite@plt>
     9f0:	2a0003f5 	mov	w21, w0
  if(fd < 0 || ftruncate(fd, size) < 0 ||
     9f4:	7100201f 	cmp	w0, #0x8
     9f8:	54fffba1 	b.ne	96c <main+0x29c>  // b.any
     fsync(fd) < 0 ||
     9fc:	2a1403e0 	mov	w0, w20
     a00:	97ffff14 	bl	650 <fsync@plt>
     pwrite(fd, &marker, sizeof(marker), size - sizeof(marker)) != sizeof(marker) ||
     a04:	37fffb40 	tbnz	w0, #31, 96c <main+0x29c>
     pread(fd, &got, sizeof(got), size - sizeof(got)) != sizeof(got) ||
     a08:	b27d77e3 	mov	x3, #0x1fffffff8           	// #8589934584
     a0c:	f2a7ffe3 	movk	x3, #0x3fff, lsl #16
     a10:	2a1503e2 	mov	w2, w21
     a14:	910203e1 	add	x1, sp, #0x80
     a18:	2a1403e0 	mov	w0, w20
     a1c:	97ffff11 	bl	660 <pread@plt>
     fsync(fd) < 0 ||
     a20:	7100201f 	cmp	w0, #0x8
     a24:	54fffa41 	b.ne	96c <main+0x29c>  // b.any
     pread(fd, &got, sizeof(got), size - sizeof(got)) != sizeof(got) ||
     a28:	f94023e0 	ldr	x0, [sp, #64]
     a2c:	f94043e1 	ldr	x1, [sp, #128]
     a30:	eb00003f 	cmp	x1, x0
     a34:	54fff9c1 	b.ne	96c <main+0x29c>  // b.any
  close(fd);
     a38:	2a1403e0 	mov	w0, w20
     a3c:	97ffff21 	bl	6c0 <close@plt>
  printf("waltest: 5 GiB triple-indirect sparse test passed\n");
     a40:	b0000000 	adrp	x0, 1000 <load+0x18>
     a44:	91122800 	add	x0, x0, #0x48a
  printf("waltest: rename-replace, subtree check, unlink-while-open passed\n");
     a48:	97fffee6 	bl	5e0 <printf@plt>
  return 0;
     a4c:	17ffff61 	b	7d0 <main+0x100>
  else if(strcmp(argv[1], "fsops") == 0) r = fsops_test();
     a50:	f94006a0 	ldr	x0, [x21, #8]
     a54:	b0000001 	adrp	x1, 1000 <load+0x18>
     a58:	9112f421 	add	x1, x1, #0x4bd
     a5c:	97fffef9 	bl	640 <strcmp@plt>
     a60:	2a0003f3 	mov	w19, w0
     a64:	35000800 	cbnz	w0, b64 <main+0x494>
  uint64 value = 0xaabbccddU, got = 0;
     a68:	d2999ba0 	mov	x0, #0xccdd                	// #52445
     a6c:	f2b55760 	movk	x0, #0xaabb, lsl #16
     a70:	f90023e0 	str	x0, [sp, #64]
  unlink(a); unlink(b); unlink(dir);
     a74:	91007e80 	add	x0, x20, #0x1f
  uint64 value = 0xaabbccddU, got = 0;
     a78:	f90043ff 	str	xzr, [sp, #128]
  unlink(a); unlink(b); unlink(dir);
     a7c:	97fffee9 	bl	620 <unlink@plt>
     a80:	9100de80 	add	x0, x20, #0x37
     a84:	97fffee7 	bl	620 <unlink@plt>
     a88:	91013e80 	add	x0, x20, #0x4f
     a8c:	97fffee5 	bl	620 <unlink@plt>
  if(mkdir(dir) < 0) return -1;
     a90:	91013e80 	add	x0, x20, #0x4f
     a94:	97ffff03 	bl	6a0 <mkdir@plt>
     a98:	37f800c0 	tbnz	w0, #31, ab0 <main+0x3e0>
  int fd = open(a, O_CREATE | O_RDWR);
     a9c:	91007e80 	add	x0, x20, #0x1f
     aa0:	52804041 	mov	w1, #0x202                 	// #514
     aa4:	97fffefb 	bl	690 <open@plt>
     aa8:	2a0003f5 	mov	w21, w0
  if(fd < 0 || pwrite(fd, &value, sizeof(value), 8192) != sizeof(value) ||
     aac:	36f80060 	tbz	w0, #31, ab8 <main+0x3e8>
  else if(strcmp(argv[1], "jstress") == 0) r = journal_stress();
     ab0:	12800013 	mov	w19, #0xffffffff            	// #-1
     ab4:	17ffff47 	b	7d0 <main+0x100>
  if(fd < 0 || pwrite(fd, &value, sizeof(value), 8192) != sizeof(value) ||
     ab8:	910103e1 	add	x1, sp, #0x40
     abc:	d2840003 	mov	x3, #0x2000                	// #8192
     ac0:	52800102 	mov	w2, #0x8                   	// #8
     ac4:	97fffefb 	bl	6b0 <pwrite@plt>
     ac8:	2a0003f6 	mov	w22, w0
     acc:	7100201f 	cmp	w0, #0x8
     ad0:	54000080 	b.eq	ae0 <main+0x410>  // b.none
    if(fd >= 0) close(fd);
     ad4:	2a1503e0 	mov	w0, w21
     ad8:	97fffefa 	bl	6c0 <close@plt>
     adc:	17fffff5 	b	ab0 <main+0x3e0>
     ftruncate(fd, 8192 + sizeof(value)) < 0 || fsync(fd) < 0 ||
     ae0:	2a1503e0 	mov	w0, w21
     ae4:	d2840101 	mov	x1, #0x2008                	// #8200
     ae8:	97fffec2 	bl	5f0 <ftruncate@plt>
  if(fd < 0 || pwrite(fd, &value, sizeof(value), 8192) != sizeof(value) ||
     aec:	37ffff40 	tbnz	w0, #31, ad4 <main+0x404>
     ftruncate(fd, 8192 + sizeof(value)) < 0 || fsync(fd) < 0 ||
     af0:	2a1503e0 	mov	w0, w21
     af4:	97fffed7 	bl	650 <fsync@plt>
     af8:	37fffee0 	tbnz	w0, #31, ad4 <main+0x404>
     pread(fd, &got, sizeof(got), 8192) != sizeof(got) || got != value){
     afc:	2a1603e2 	mov	w2, w22
     b00:	910203e1 	add	x1, sp, #0x80
     b04:	2a1503e0 	mov	w0, w21
     b08:	d2840003 	mov	x3, #0x2000                	// #8192
     b0c:	97fffed5 	bl	660 <pread@plt>
     ftruncate(fd, 8192 + sizeof(value)) < 0 || fsync(fd) < 0 ||
     b10:	7100201f 	cmp	w0, #0x8
     b14:	54fffe01 	b.ne	ad4 <main+0x404>  // b.any
     pread(fd, &got, sizeof(got), 8192) != sizeof(got) || got != value){
     b18:	f94023e0 	ldr	x0, [sp, #64]
     b1c:	f94043e1 	ldr	x1, [sp, #128]
     b20:	eb00003f 	cmp	x1, x0
     b24:	54fffd81 	b.ne	ad4 <main+0x404>  // b.any
  close(fd);
     b28:	2a1503e0 	mov	w0, w21
     b2c:	97fffee5 	bl	6c0 <close@plt>
  if(rename(a, b) < 0 || unlink(b) < 0 || unlink(dir) < 0)
     b30:	9100de81 	add	x1, x20, #0x37
     b34:	91007e80 	add	x0, x20, #0x1f
     b38:	97fffeb2 	bl	600 <rename@plt>
     b3c:	37fffba0 	tbnz	w0, #31, ab0 <main+0x3e0>
     b40:	9100de80 	add	x0, x20, #0x37
     b44:	97fffeb7 	bl	620 <unlink@plt>
     b48:	37fffb40 	tbnz	w0, #31, ab0 <main+0x3e0>
     b4c:	91013e80 	add	x0, x20, #0x4f
     b50:	97fffeb4 	bl	620 <unlink@plt>
     b54:	37fffae0 	tbnz	w0, #31, ab0 <main+0x3e0>
  printf("waltest: mkdir/rename/unlink/ftruncate/pread/pwrite passed\n");
     b58:	b0000000 	adrp	x0, 1000 <load+0x18>
     b5c:	91130c00 	add	x0, x0, #0x4c3
     b60:	17ffffba 	b	a48 <main+0x378>
  else if(strcmp(argv[1], "semantics") == 0) r = semantics_test();
     b64:	f94006a0 	ldr	x0, [x21, #8]
     b68:	b0000001 	adrp	x1, 1000 <load+0x18>
     b6c:	9113fc21 	add	x1, x1, #0x4ff
     b70:	97fffeb4 	bl	640 <strcmp@plt>
     b74:	35001320 	cbnz	w0, dd8 <main+0x708>
  unlink(a); unlink(b); unlink(sd2); unlink(sd); unlink(d);
     b78:	91019680 	add	x0, x20, #0x65
  uint64 v = 0;
     b7c:	f90023ff 	str	xzr, [sp, #64]
  unlink(a); unlink(b); unlink(sd2); unlink(sd); unlink(d);
     b80:	97fffea8 	bl	620 <unlink@plt>
     b84:	b0000015 	adrp	x21, 1000 <load+0x18>
     b88:	91144eb5 	add	x21, x21, #0x513
     b8c:	9101f680 	add	x0, x20, #0x7d
     b90:	97fffea4 	bl	620 <unlink@plt>
     b94:	91025680 	add	x0, x20, #0x95
     b98:	97fffea2 	bl	620 <unlink@plt>
     b9c:	9102d680 	add	x0, x20, #0xb5
     ba0:	97fffea0 	bl	620 <unlink@plt>
     ba4:	91033e80 	add	x0, x20, #0xcf
     ba8:	97fffe9e 	bl	620 <unlink@plt>
  CHECK(mkdir(d) == 0, "mkdir sem");
     bac:	91033e80 	add	x0, x20, #0xcf
     bb0:	97fffebc 	bl	6a0 <mkdir@plt>
     bb4:	340000c0 	cbz	w0, bcc <main+0x4fc>
     bb8:	b0000001 	adrp	x1, 1000 <load+0x18>
     bbc:	91142421 	add	x1, x1, #0x509
     bc0:	aa1503e0 	mov	x0, x21
     bc4:	97fffe87 	bl	5e0 <printf@plt>
     bc8:	17ffffba 	b	ab0 <main+0x3e0>
  CHECK(put_file(a, 111) == 0 && put_file(b, 222) == 0, "create a/b");
     bcc:	91019680 	add	x0, x20, #0x65
     bd0:	d2800de1 	mov	x1, #0x6f                  	// #111
     bd4:	940000e9 	bl	f78 <put_file>
     bd8:	34000080 	cbz	w0, be8 <main+0x518>
     bdc:	b0000001 	adrp	x1, 1000 <load+0x18>
     be0:	91149421 	add	x1, x1, #0x525
     be4:	17fffff7 	b	bc0 <main+0x4f0>
     be8:	9101f680 	add	x0, x20, #0x7d
     bec:	d2801bc1 	mov	x1, #0xde                  	// #222
     bf0:	940000e2 	bl	f78 <put_file>
     bf4:	35ffff40 	cbnz	w0, bdc <main+0x50c>
  CHECK(rename(a, b) == 0, "rename a over b");
     bf8:	9101f681 	add	x1, x20, #0x7d
     bfc:	91019680 	add	x0, x20, #0x65
     c00:	97fffe80 	bl	600 <rename@plt>
     c04:	34000080 	cbz	w0, c14 <main+0x544>
     c08:	b0000001 	adrp	x1, 1000 <load+0x18>
     c0c:	9114c021 	add	x1, x1, #0x530
     c10:	17ffffec 	b	bc0 <main+0x4f0>
  CHECK(get_file(b, &v) == 0 && v == 111, "b holds a's data");
     c14:	910103e1 	add	x1, sp, #0x40
     c18:	9101f680 	add	x0, x20, #0x7d
     c1c:	94000109 	bl	1040 <get_file>
     c20:	35000080 	cbnz	w0, c30 <main+0x560>
     c24:	f94023e0 	ldr	x0, [sp, #64]
     c28:	f101bc1f 	cmp	x0, #0x6f
     c2c:	54000080 	b.eq	c3c <main+0x56c>  // b.none
     c30:	b0000001 	adrp	x1, 1000 <load+0x18>
     c34:	91150021 	add	x1, x1, #0x540
     c38:	17ffffe2 	b	bc0 <main+0x4f0>
  CHECK(get_file(a, &v) < 0, "a is gone");
     c3c:	910103e1 	add	x1, sp, #0x40
     c40:	91019680 	add	x0, x20, #0x65
     c44:	940000ff 	bl	1040 <get_file>
     c48:	35000080 	cbnz	w0, c58 <main+0x588>
     c4c:	b0000001 	adrp	x1, 1000 <load+0x18>
     c50:	91154421 	add	x1, x1, #0x551
     c54:	17ffffdb 	b	bc0 <main+0x4f0>
  CHECK(mkdir(sd) == 0 && mkdir(sd2) == 0, "mkdir sub/inner");
     c58:	9102d680 	add	x0, x20, #0xb5
     c5c:	97fffe91 	bl	6a0 <mkdir@plt>
     c60:	34000080 	cbz	w0, c70 <main+0x5a0>
     c64:	b0000001 	adrp	x1, 1000 <load+0x18>
     c68:	91156c21 	add	x1, x1, #0x55b
     c6c:	17ffffd5 	b	bc0 <main+0x4f0>
     c70:	91025680 	add	x0, x20, #0x95
     c74:	97fffe8b 	bl	6a0 <mkdir@plt>
     c78:	35ffff60 	cbnz	w0, c64 <main+0x594>
  CHECK(rename(sd, sd3) < 0, "rename dir into own subtree rejected");
     c7c:	91039681 	add	x1, x20, #0xe5
     c80:	9102d680 	add	x0, x20, #0xb5
     c84:	97fffe5f 	bl	600 <rename@plt>
     c88:	37f80080 	tbnz	w0, #31, c98 <main+0x5c8>
     c8c:	b0000001 	adrp	x1, 1000 <load+0x18>
     c90:	9115ac21 	add	x1, x1, #0x56b
     c94:	17ffffcb 	b	bc0 <main+0x4f0>
  CHECK(unlink(sd2) == 0 && unlink(sd) == 0, "rmdir sub/inner");
     c98:	91025680 	add	x0, x20, #0x95
     c9c:	97fffe61 	bl	620 <unlink@plt>
     ca0:	34000080 	cbz	w0, cb0 <main+0x5e0>
     ca4:	b0000001 	adrp	x1, 1000 <load+0x18>
     ca8:	91164021 	add	x1, x1, #0x590
     cac:	17ffffc5 	b	bc0 <main+0x4f0>
     cb0:	9102d680 	add	x0, x20, #0xb5
     cb4:	97fffe5b 	bl	620 <unlink@plt>
     cb8:	35ffff60 	cbnz	w0, ca4 <main+0x5d4>
  int fd = open(b, O_RDWR);
     cbc:	9101f680 	add	x0, x20, #0x7d
     cc0:	52800041 	mov	w1, #0x2                   	// #2
     cc4:	97fffe73 	bl	690 <open@plt>
     cc8:	2a0003f3 	mov	w19, w0
  CHECK(fd >= 0, "open b");
     ccc:	36f80080 	tbz	w0, #31, cdc <main+0x60c>
     cd0:	b0000001 	adrp	x1, 1000 <load+0x18>
     cd4:	91169c21 	add	x1, x1, #0x5a7
     cd8:	17ffffba 	b	bc0 <main+0x4f0>
  CHECK(unlink(b) == 0, "unlink open b");
     cdc:	9101f680 	add	x0, x20, #0x7d
     ce0:	97fffe50 	bl	620 <unlink@plt>
     ce4:	34000080 	cbz	w0, cf4 <main+0x624>
     ce8:	b0000001 	adrp	x1, 1000 <load+0x18>
     cec:	91168021 	add	x1, x1, #0x5a0
     cf0:	17ffffb4 	b	bc0 <main+0x4f0>
  CHECK(put_file(b, 333) == 0, "recreate b");
     cf4:	9101f680 	add	x0, x20, #0x7d
     cf8:	d28029a1 	mov	x1, #0x14d                 	// #333
     cfc:	9400009f 	bl	f78 <put_file>
     d00:	34000080 	cbz	w0, d10 <main+0x640>
     d04:	b0000001 	adrp	x1, 1000 <load+0x18>
     d08:	9116b821 	add	x1, x1, #0x5ae
     d0c:	17ffffad 	b	bc0 <main+0x4f0>
  CHECK(pread(fd, &v, sizeof(v), 0) == sizeof(v) && v == 111,
     d10:	910103e1 	add	x1, sp, #0x40
     d14:	2a1303e0 	mov	w0, w19
     d18:	d2800003 	mov	x3, #0x0                   	// #0
     d1c:	52800102 	mov	w2, #0x8                   	// #8
     d20:	97fffe50 	bl	660 <pread@plt>
     d24:	7100201f 	cmp	w0, #0x8
     d28:	54000081 	b.ne	d38 <main+0x668>  // b.any
     d2c:	f94023e1 	ldr	x1, [sp, #64]
     d30:	f101bc3f 	cmp	x1, #0x6f
     d34:	54000080 	b.eq	d44 <main+0x674>  // b.none
     d38:	b0000001 	adrp	x1, 1000 <load+0x18>
     d3c:	9116e421 	add	x1, x1, #0x5b9
     d40:	17ffffa0 	b	bc0 <main+0x4f0>
  uint64 w = 444;
     d44:	d2803781 	mov	x1, #0x1bc                 	// #444
  CHECK(pwrite(fd, &w, sizeof(w), 0) == sizeof(w), "write to unlinked file");
     d48:	2a0003e2 	mov	w2, w0
     d4c:	d2800003 	mov	x3, #0x0                   	// #0
     d50:	2a1303e0 	mov	w0, w19
  uint64 w = 444;
     d54:	f90043e1 	str	x1, [sp, #128]
  CHECK(pwrite(fd, &w, sizeof(w), 0) == sizeof(w), "write to unlinked file");
     d58:	910203e1 	add	x1, sp, #0x80
     d5c:	97fffe55 	bl	6b0 <pwrite@plt>
     d60:	7100201f 	cmp	w0, #0x8
     d64:	54000080 	b.eq	d74 <main+0x6a4>  // b.none
     d68:	b0000001 	adrp	x1, 1000 <load+0x18>
     d6c:	91176821 	add	x1, x1, #0x5da
     d70:	17ffff94 	b	bc0 <main+0x4f0>
  close(fd);                       // orphan is reclaimed here
     d74:	2a1303e0 	mov	w0, w19
     d78:	97fffe52 	bl	6c0 <close@plt>
  CHECK(get_file(b, &v) == 0 && v == 333, "new b untouched by old fd");
     d7c:	910103e1 	add	x1, sp, #0x40
     d80:	9101f680 	add	x0, x20, #0x7d
     d84:	940000af 	bl	1040 <get_file>
     d88:	35000080 	cbnz	w0, d98 <main+0x6c8>
     d8c:	f94023e0 	ldr	x0, [sp, #64]
     d90:	f105341f 	cmp	x0, #0x14d
     d94:	54000080 	b.eq	da4 <main+0x6d4>  // b.none
     d98:	b0000001 	adrp	x1, 1000 <load+0x18>
     d9c:	9117c421 	add	x1, x1, #0x5f1
     da0:	17ffff88 	b	bc0 <main+0x4f0>
  CHECK(unlink(b) == 0 && unlink(d) == 0, "cleanup");
     da4:	9101f680 	add	x0, x20, #0x7d
     da8:	97fffe1e 	bl	620 <unlink@plt>
     dac:	34000080 	cbz	w0, dbc <main+0x6ec>
     db0:	b0000001 	adrp	x1, 1000 <load+0x18>
     db4:	91182c21 	add	x1, x1, #0x60b
     db8:	17ffff82 	b	bc0 <main+0x4f0>
     dbc:	91033e80 	add	x0, x20, #0xcf
     dc0:	97fffe18 	bl	620 <unlink@plt>
     dc4:	2a0003f3 	mov	w19, w0
     dc8:	35ffff40 	cbnz	w0, db0 <main+0x6e0>
  printf("waltest: rename-replace, subtree check, unlink-while-open passed\n");
     dcc:	b0000000 	adrp	x0, 1000 <load+0x18>
     dd0:	91184c00 	add	x0, x0, #0x613
     dd4:	17ffff1d 	b	a48 <main+0x378>
  else if(strcmp(argv[1], "jstress") == 0) r = journal_stress();
     dd8:	f94006a0 	ldr	x0, [x21, #8]
     ddc:	b0000001 	adrp	x1, 1000 <load+0x18>
     de0:	91195421 	add	x1, x1, #0x655
     de4:	97fffe17 	bl	640 <strcmp@plt>
     de8:	35000640 	cbnz	w0, eb0 <main+0x7e0>
  mkdir(d);
     dec:	91042a80 	add	x0, x20, #0x10a
    strcpy(p2, "/mnt/ext2/waltest/j/g00");
     df0:	b0000015 	adrp	x21, 1000 <load+0x18>
     df4:	9119d6b5 	add	x21, x21, #0x675
    strcpy(p1, "/mnt/ext2/waltest/j/f00");
     df8:	b0000014 	adrp	x20, 1000 <load+0x18>
     dfc:	91197694 	add	x20, x20, #0x65d
      printf("waltest: jstress %l operations; cut power any time\n", i);
     e00:	b0000016 	adrp	x22, 1000 <load+0x18>
     e04:	911ab2d6 	add	x22, x22, #0x6ac
  for(uint64 i = 0;; i++){
     e08:	d2800013 	mov	x19, #0x0                   	// #0
    p1[21] = p2[21] = '0' + k / 10;
     e0c:	52800157 	mov	w23, #0xa                   	// #10
  mkdir(d);
     e10:	97fffe24 	bl	6a0 <mkdir@plt>
    int k = i % 16;
     e14:	12000e78 	and	w24, w19, #0xf
    strcpy(p1, "/mnt/ext2/waltest/j/f00");
     e18:	aa1403e1 	mov	x1, x20
     e1c:	910103e0 	add	x0, sp, #0x40
     e20:	97fffdec 	bl	5d0 <strcpy@plt>
    strcpy(p2, "/mnt/ext2/waltest/j/g00");
     e24:	aa1503e1 	mov	x1, x21
     e28:	910203e0 	add	x0, sp, #0x80
     e2c:	97fffde9 	bl	5d0 <strcpy@plt>
    p1[21] = p2[21] = '0' + k / 10;
     e30:	1ad70b02 	udiv	w2, w24, w23
     e34:	1100c040 	add	w0, w2, #0x30
    p1[22] = p2[22] = '0' + k % 10;
     e38:	1b17e042 	msub	w2, w2, w23, w24
    p1[21] = p2[21] = '0' + k / 10;
     e3c:	390157e0 	strb	w0, [sp, #85]
    p1[22] = p2[22] = '0' + k % 10;
     e40:	1100c042 	add	w2, w2, #0x30
     e44:	39015be2 	strb	w2, [sp, #86]
    p1[21] = p2[21] = '0' + k / 10;
     e48:	390257e0 	strb	w0, [sp, #149]
    unlink(p2);
     e4c:	910203e0 	add	x0, sp, #0x80
    p1[22] = p2[22] = '0' + k % 10;
     e50:	39025be2 	strb	w2, [sp, #150]
    unlink(p2);
     e54:	97fffdf3 	bl	620 <unlink@plt>
    if(put_file(p1, i) < 0 || rename(p1, p2) < 0){
     e58:	aa1303e1 	mov	x1, x19
     e5c:	910103e0 	add	x0, sp, #0x40
     e60:	94000046 	bl	f78 <put_file>
     e64:	3100041f 	cmn	w0, #0x1
     e68:	540000a1 	b.ne	e7c <main+0x7ac>  // b.any
      printf("waltest: jstress failed at %l\n", i);
     e6c:	b0000000 	adrp	x0, 1000 <load+0x18>
     e70:	911a3400 	add	x0, x0, #0x68d
     e74:	aa1303e1 	mov	x1, x19
     e78:	17ffff53 	b	bc4 <main+0x4f4>
    if(put_file(p1, i) < 0 || rename(p1, p2) < 0){
     e7c:	910203e1 	add	x1, sp, #0x80
     e80:	910103e0 	add	x0, sp, #0x40
     e84:	97fffddf 	bl	600 <rename@plt>
     e88:	37ffff20 	tbnz	w0, #31, e6c <main+0x79c>
     e8c:	d2800641 	mov	x1, #0x32                  	// #50
     e90:	9ac10a60 	udiv	x0, x19, x1
     e94:	9b01cc00 	msub	x0, x0, x1, x19
    if(i % 50 == 0)
     e98:	b5000080 	cbnz	x0, ea8 <main+0x7d8>
      printf("waltest: jstress %l operations; cut power any time\n", i);
     e9c:	aa1303e1 	mov	x1, x19
     ea0:	aa1603e0 	mov	x0, x22
     ea4:	97fffdcf 	bl	5e0 <printf@plt>
  for(uint64 i = 0;; i++){
     ea8:	91000673 	add	x19, x19, #0x1
     eac:	17ffffda 	b	e14 <main+0x744>
  else printf("waltest: bad command\n");
     eb0:	b0000000 	adrp	x0, 1000 <load+0x18>
     eb4:	911b8000 	add	x0, x0, #0x6e0
     eb8:	17fffec6 	b	9d0 <main+0x300>
  if(have_wal && (!have_data || wal.txid >= data.txid)){
     ebc:	34ffd873 	cbz	w19, 9c8 <main+0x2f8>
     ec0:	17fffe74 	b	890 <main+0x1c0>

0000000000000ec4 <checksum>:
{
     ec4:	aa0003e4 	mov	x4, x0
    h *= 16777619U;
     ec8:	52803263 	mov	w3, #0x193                 	// #403
     ecc:	72a02003 	movk	w3, #0x100, lsl #16
  uint32 h = 2166136261U;
     ed0:	5293b8a0 	mov	w0, #0x9dc5                	// #40389
     ed4:	72b02380 	movk	w0, #0x811c, lsl #16
{
     ed8:	d2800002 	mov	x2, #0x0                   	// #0
    h ^= p[i];
     edc:	38626881 	ldrb	w1, [x4, x2]
  for(uint i = 0; i < sizeof(*r) - 8; i++){
     ee0:	91000442 	add	x2, x2, #0x1
    h ^= p[i];
     ee4:	4a000021 	eor	w1, w1, w0
    h *= 16777619U;
     ee8:	1b037c20 	mul	w0, w1, w3
  for(uint i = 0; i < sizeof(*r) - 8; i++){
     eec:	f100605f 	cmp	x2, #0x18
     ef0:	54ffff61 	b.ne	edc <checksum+0x18>  // b.any
}
     ef4:	d65f03c0 	ret

0000000000000ef8 <store>:
{
     ef8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     efc:	910003fd 	mov	x29, sp
     f00:	a90153f3 	stp	x19, x20, [sp, #16]
     f04:	aa0103f4 	mov	x20, x1
  return open(path, O_CREATE | O_RDWR);
     f08:	52804041 	mov	w1, #0x202                 	// #514
     f0c:	97fffde1 	bl	690 <open@plt>
  if(fd < 0 || ftruncate(fd, sizeof(*r)) < 0 ||
     f10:	36f800a0 	tbz	w0, #31, f24 <store+0x2c>
    return -1;
     f14:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     f18:	a94153f3 	ldp	x19, x20, [sp, #16]
     f1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
     f20:	d65f03c0 	ret
     f24:	2a0003f3 	mov	w19, w0
  if(fd < 0 || ftruncate(fd, sizeof(*r)) < 0 ||
     f28:	d2800401 	mov	x1, #0x20                  	// #32
     f2c:	97fffdb1 	bl	5f0 <ftruncate@plt>
     f30:	36f80080 	tbz	w0, #31, f40 <store+0x48>
    if(fd >= 0) close(fd);
     f34:	2a1303e0 	mov	w0, w19
     f38:	97fffde2 	bl	6c0 <close@plt>
     f3c:	17fffff6 	b	f14 <store+0x1c>
     pwrite(fd, r, sizeof(*r), 0) != sizeof(*r) || fdatasync(fd) < 0){
     f40:	aa1403e1 	mov	x1, x20
     f44:	2a1303e0 	mov	w0, w19
     f48:	d2800003 	mov	x3, #0x0                   	// #0
     f4c:	52800402 	mov	w2, #0x20                  	// #32
     f50:	97fffdd8 	bl	6b0 <pwrite@plt>
  if(fd < 0 || ftruncate(fd, sizeof(*r)) < 0 ||
     f54:	7100801f 	cmp	w0, #0x20
     f58:	54fffee1 	b.ne	f34 <store+0x3c>  // b.any
     pwrite(fd, r, sizeof(*r), 0) != sizeof(*r) || fdatasync(fd) < 0){
     f5c:	2a1303e0 	mov	w0, w19
     f60:	97fffdac 	bl	610 <fdatasync@plt>
     f64:	37fffe80 	tbnz	w0, #31, f34 <store+0x3c>
  close(fd);
     f68:	2a1303e0 	mov	w0, w19
     f6c:	97fffdd5 	bl	6c0 <close@plt>
  return 0;
     f70:	52800000 	mov	w0, #0x0                   	// #0
     f74:	17ffffe9 	b	f18 <store+0x20>

0000000000000f78 <put_file>:
{
     f78:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     f7c:	910003fd 	mov	x29, sp
     f80:	a90153f3 	stp	x19, x20, [sp, #16]
     f84:	f90017e1 	str	x1, [sp, #40]
  int fd = open(path, O_CREATE | O_RDWR);
     f88:	52804041 	mov	w1, #0x202                 	// #514
     f8c:	97fffdc1 	bl	690 <open@plt>
  if(fd < 0) return -1;
     f90:	37f80280 	tbnz	w0, #31, fe0 <put_file+0x68>
     f94:	2a0003f4 	mov	w20, w0
  int ok = ftruncate(fd, 0) == 0 && pwrite(fd, &v, sizeof(v), 0) == sizeof(v);
     f98:	d2800001 	mov	x1, #0x0                   	// #0
     f9c:	97fffd95 	bl	5f0 <ftruncate@plt>
     fa0:	350001c0 	cbnz	w0, fd8 <put_file+0x60>
     fa4:	9100a3e1 	add	x1, sp, #0x28
     fa8:	2a1403e0 	mov	w0, w20
     fac:	d2800003 	mov	x3, #0x0                   	// #0
     fb0:	52800102 	mov	w2, #0x8                   	// #8
     fb4:	97fffdbf 	bl	6b0 <pwrite@plt>
     fb8:	7100201f 	cmp	w0, #0x8
     fbc:	1a9f17f3 	cset	w19, eq	// eq = none
  close(fd);
     fc0:	2a1403e0 	mov	w0, w20
     fc4:	97fffdbf 	bl	6c0 <close@plt>
  return ok ? 0 : -1;
     fc8:	51000660 	sub	w0, w19, #0x1
}
     fcc:	a94153f3 	ldp	x19, x20, [sp, #16]
     fd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
     fd4:	d65f03c0 	ret
  int ok = ftruncate(fd, 0) == 0 && pwrite(fd, &v, sizeof(v), 0) == sizeof(v);
     fd8:	52800013 	mov	w19, #0x0                   	// #0
     fdc:	17fffff9 	b	fc0 <put_file+0x48>
  if(fd < 0) return -1;
     fe0:	12800000 	mov	w0, #0xffffffff            	// #-1
     fe4:	17fffffa 	b	fcc <put_file+0x54>

0000000000000fe8 <load>:
{
     fe8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     fec:	910003fd 	mov	x29, sp
     ff0:	a90153f3 	stp	x19, x20, [sp, #16]
     ff4:	aa0103f4 	mov	x20, x1
  int fd = open(path, O_RDONLY);
     ff8:	52800001 	mov	w1, #0x0                   	// #0
     ffc:	97fffda5 	bl	690 <open@plt>
  if(fd < 0) return -1;
    1000:	37f801c0 	tbnz	w0, #31, 1038 <load+0x50>
  int n = pread(fd, r, sizeof(*r), 0);
    1004:	aa1403e1 	mov	x1, x20
    1008:	d2800003 	mov	x3, #0x0                   	// #0
    100c:	52800402 	mov	w2, #0x20                  	// #32
    1010:	2a0003f3 	mov	w19, w0
    1014:	97fffd93 	bl	660 <pread@plt>
    1018:	2a0003f4 	mov	w20, w0
  close(fd);
    101c:	2a1303e0 	mov	w0, w19
    1020:	97fffda8 	bl	6c0 <close@plt>
  return n == sizeof(*r) ? 0 : -1;
    1024:	7100829f 	cmp	w20, #0x20
    1028:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    102c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1030:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1034:	d65f03c0 	ret
  if(fd < 0) return -1;
    1038:	12800000 	mov	w0, #0xffffffff            	// #-1
    103c:	17fffffc 	b	102c <load+0x44>

0000000000001040 <get_file>:
{
    1040:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1044:	910003fd 	mov	x29, sp
    1048:	a90153f3 	stp	x19, x20, [sp, #16]
    104c:	aa0103f4 	mov	x20, x1
  int fd = open(path, O_RDONLY);
    1050:	52800001 	mov	w1, #0x0                   	// #0
    1054:	97fffd8f 	bl	690 <open@plt>
  if(fd < 0) return -1;
    1058:	37f801c0 	tbnz	w0, #31, 1090 <get_file+0x50>
  int n = pread(fd, v, sizeof(*v), 0);
    105c:	aa1403e1 	mov	x1, x20
    1060:	d2800003 	mov	x3, #0x0                   	// #0
    1064:	52800102 	mov	w2, #0x8                   	// #8
    1068:	2a0003f3 	mov	w19, w0
    106c:	97fffd7d 	bl	660 <pread@plt>
    1070:	2a0003f4 	mov	w20, w0
  close(fd);
    1074:	2a1303e0 	mov	w0, w19
    1078:	97fffd92 	bl	6c0 <close@plt>
  return n == sizeof(*v) ? 0 : -1;
    107c:	7100229f 	cmp	w20, #0x8
    1080:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    1084:	a94153f3 	ldp	x19, x20, [sp, #16]
    1088:	a8c27bfd 	ldp	x29, x30, [sp], #32
    108c:	d65f03c0 	ret
  if(fd < 0) return -1;
    1090:	12800000 	mov	w0, #0xffffffff            	// #-1
    1094:	17fffffc 	b	1084 <get_file+0x44>

0000000000001098 <clear_wal>:
{
    1098:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return open(path, O_CREATE | O_RDWR);
    109c:	90000000 	adrp	x0, 1000 <load+0x18>
    10a0:	91098000 	add	x0, x0, #0x260
{
    10a4:	910003fd 	mov	x29, sp
  return open(path, O_CREATE | O_RDWR);
    10a8:	52804041 	mov	w1, #0x202                 	// #514
{
    10ac:	f9000bf3 	str	x19, [sp, #16]
  return open(path, O_CREATE | O_RDWR);
    10b0:	97fffd78 	bl	690 <open@plt>
  if(fd < 0 || ftruncate(fd, 0) < 0 || fsync(fd) < 0){
    10b4:	36f800a0 	tbz	w0, #31, 10c8 <clear_wal+0x30>
    return -1;
    10b8:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    10bc:	f9400bf3 	ldr	x19, [sp, #16]
    10c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    10c4:	d65f03c0 	ret
    10c8:	2a0003f3 	mov	w19, w0
  if(fd < 0 || ftruncate(fd, 0) < 0 || fsync(fd) < 0){
    10cc:	d2800001 	mov	x1, #0x0                   	// #0
    10d0:	97fffd48 	bl	5f0 <ftruncate@plt>
    10d4:	36f80080 	tbz	w0, #31, 10e4 <clear_wal+0x4c>
    if(fd >= 0) close(fd);
    10d8:	2a1303e0 	mov	w0, w19
    10dc:	97fffd79 	bl	6c0 <close@plt>
    10e0:	17fffff6 	b	10b8 <clear_wal+0x20>
  if(fd < 0 || ftruncate(fd, 0) < 0 || fsync(fd) < 0){
    10e4:	2a1303e0 	mov	w0, w19
    10e8:	97fffd5a 	bl	650 <fsync@plt>
    10ec:	37ffff60 	tbnz	w0, #31, 10d8 <clear_wal+0x40>
  close(fd);
    10f0:	2a1303e0 	mov	w0, w19
    10f4:	97fffd73 	bl	6c0 <close@plt>
  return 0;
    10f8:	52800000 	mov	w0, #0x0                   	// #0
    10fc:	17fffff0 	b	10bc <clear_wal+0x24>

0000000000001100 <commit_value>:
{
    1100:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    1104:	910003fd 	mov	x29, sp
    1108:	a9025bf5 	stp	x21, x22, [sp, #32]
  if(load(DBFILE, &data) == 0 && valid(&data, 2))
    110c:	90000016 	adrp	x22, 1000 <load+0x18>
    1110:	9109eed6 	add	x22, x22, #0x27b
{
    1114:	aa0003f5 	mov	x21, x0
  if(load(DBFILE, &data) == 0 && valid(&data, 2))
    1118:	aa1603e0 	mov	x0, x22
{
    111c:	a90153f3 	stp	x19, x20, [sp, #16]
    1120:	f9001bf7 	str	x23, [sp, #48]
    1124:	2a0103f7 	mov	w23, w1
  if(load(DBFILE, &data) == 0 && valid(&data, 2))
    1128:	910103e1 	add	x1, sp, #0x40
    112c:	97ffffaf 	bl	fe8 <load>
    1130:	340003c0 	cbz	w0, 11a8 <commit_value+0xa8>
  uint64 txid = 1;
    1134:	d2800034 	mov	x20, #0x1                   	// #1
  memset(&wal, 0, sizeof(wal));
    1138:	52800402 	mov	w2, #0x20                  	// #32
    113c:	52800001 	mov	w1, #0x0                   	// #0
    1140:	910183e0 	add	x0, sp, #0x60
    1144:	97fffd3b 	bl	630 <memset@plt>
  wal.magic = MAGIC; wal.kind = 1; wal.txid = txid; wal.value = value;
    1148:	d2898620 	mov	x0, #0x4c31                	// #19505
    114c:	f2aae820 	movk	x0, #0x5741, lsl #16
    1150:	f2c00020 	movk	x0, #0x1, lsl #32
    1154:	a90653e0 	stp	x0, x20, [sp, #96]
  wal.checksum = checksum(&wal);
    1158:	910183e0 	add	x0, sp, #0x60
  wal.magic = MAGIC; wal.kind = 1; wal.txid = txid; wal.value = value;
    115c:	f9003bf5 	str	x21, [sp, #112]
  wal.checksum = checksum(&wal);
    1160:	97ffff59 	bl	ec4 <checksum>
  if(store(WALFILE, &wal) < 0){
    1164:	910183e1 	add	x1, sp, #0x60
  wal.checksum = checksum(&wal);
    1168:	b9007be0 	str	w0, [sp, #120]
  if(store(WALFILE, &wal) < 0){
    116c:	90000000 	adrp	x0, 1000 <load+0x18>
    1170:	91098000 	add	x0, x0, #0x260
    1174:	97ffff61 	bl	ef8 <store>
    1178:	2a0003f3 	mov	w19, w0
    117c:	3100041f 	cmn	w0, #0x1
    1180:	54000301 	b.ne	11e0 <commit_value+0xe0>  // b.any
    printf("waltest: WAL write/fsync failed\n");
    1184:	90000000 	adrp	x0, 1000 <load+0x18>
    1188:	910a5400 	add	x0, x0, #0x295
    118c:	97fffd15 	bl	5e0 <printf@plt>
}
    1190:	f9401bf7 	ldr	x23, [sp, #48]
    1194:	2a1303e0 	mov	w0, w19
    1198:	a94153f3 	ldp	x19, x20, [sp, #16]
    119c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    11a0:	a8c87bfd 	ldp	x29, x30, [sp], #128
    11a4:	d65f03c0 	ret
  return r->magic == MAGIC && r->kind == kind && r->checksum == checksum(r);
    11a8:	f94023e1 	ldr	x1, [sp, #64]
    11ac:	d2898620 	mov	x0, #0x4c31                	// #19505
    11b0:	f2aae820 	movk	x0, #0x5741, lsl #16
    11b4:	f2c00040 	movk	x0, #0x2, lsl #32
    11b8:	eb00003f 	cmp	x1, x0
    11bc:	54fffbc1 	b.ne	1134 <commit_value+0x34>  // b.any
    11c0:	910103e0 	add	x0, sp, #0x40
    11c4:	97ffff40 	bl	ec4 <checksum>
    11c8:	b9405be1 	ldr	w1, [sp, #88]
    11cc:	6b00003f 	cmp	w1, w0
    11d0:	54fffb21 	b.ne	1134 <commit_value+0x34>  // b.any
    txid = data.txid + 1;
    11d4:	f94027f4 	ldr	x20, [sp, #72]
    11d8:	91000694 	add	x20, x20, #0x1
    11dc:	17ffffd7 	b	1138 <commit_value+0x38>
  printf("waltest: WAL durable tx=%l value=%l\n", txid, value);
    11e0:	90000000 	adrp	x0, 1000 <load+0x18>
    11e4:	910ad800 	add	x0, x0, #0x2b6
    11e8:	aa1503e2 	mov	x2, x21
    11ec:	aa1403e1 	mov	x1, x20
    11f0:	97fffcfc 	bl	5e0 <printf@plt>
  if(stop_after_wal){
    11f4:	340000d7 	cbz	w23, 120c <commit_value+0x10c>
    printf("waltest: STOP-AFTER-WAL; cut power now, then run waltest recover\n");
    11f8:	90000000 	adrp	x0, 1000 <load+0x18>
    11fc:	910b6c00 	add	x0, x0, #0x2db
    1200:	97fffcf8 	bl	5e0 <printf@plt>
    return 0;
    1204:	52800013 	mov	w19, #0x0                   	// #0
  return 0;
    1208:	17ffffe2 	b	1190 <commit_value+0x90>
  wal.kind = 2;
    120c:	52800040 	mov	w0, #0x2                   	// #2
    1210:	b90067e0 	str	w0, [sp, #100]
  wal.checksum = checksum(&wal);
    1214:	910183e0 	add	x0, sp, #0x60
    1218:	97ffff2b 	bl	ec4 <checksum>
  if(store(DBFILE, &wal) < 0 || clear_wal() < 0)
    121c:	910183e1 	add	x1, sp, #0x60
  wal.checksum = checksum(&wal);
    1220:	b9007be0 	str	w0, [sp, #120]
  if(store(DBFILE, &wal) < 0 || clear_wal() < 0)
    1224:	aa1603e0 	mov	x0, x22
    1228:	97ffff34 	bl	ef8 <store>
    122c:	2a0003f3 	mov	w19, w0
    1230:	3100041f 	cmn	w0, #0x1
    1234:	54fffae0 	b.eq	1190 <commit_value+0x90>  // b.none
    1238:	97ffff98 	bl	1098 <clear_wal>
    123c:	2a0003f3 	mov	w19, w0
    1240:	3100041f 	cmn	w0, #0x1
    1244:	54fffa60 	b.eq	1190 <commit_value+0x90>  // b.none
  printf("waltest: commit complete tx=%l value=%l\n", txid, value);
    1248:	aa1503e2 	mov	x2, x21
    124c:	aa1403e1 	mov	x1, x20
    1250:	90000000 	adrp	x0, 1000 <load+0x18>
    1254:	910c7400 	add	x0, x0, #0x31d
    1258:	97fffce2 	bl	5e0 <printf@plt>
    125c:	17ffffea 	b	1204 <commit_value+0x104>
