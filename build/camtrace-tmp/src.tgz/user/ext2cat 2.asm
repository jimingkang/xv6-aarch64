
user/_ext2cat:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002b8 <.plt>:
 2b8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2bc:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2c0:	f942a611 	ldr	x17, [x16, #1352]
 2c4:	91152210 	add	x16, x16, #0x548
 2c8:	d61f0220 	br	x17
 2cc:	d503201f 	nop
 2d0:	d503201f 	nop
 2d4:	d503201f 	nop

00000000000002d8 <write@plt>:
 2d8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2dc:	f942aa11 	ldr	x17, [x16, #1360]
 2e0:	91154210 	add	x16, x16, #0x550
 2e4:	d61f0220 	br	x17

00000000000002e8 <fprintf@plt>:
 2e8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2ec:	f942ae11 	ldr	x17, [x16, #1368]
 2f0:	91156210 	add	x16, x16, #0x558
 2f4:	d61f0220 	br	x17

00000000000002f8 <exit@plt>:
 2f8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2fc:	f942b211 	ldr	x17, [x16, #1376]
 300:	91158210 	add	x16, x16, #0x560
 304:	d61f0220 	br	x17

0000000000000308 <ext2read@plt>:
 308:	b0000010 	adrp	x16, 1000 <main+0xce8>
 30c:	f942b611 	ldr	x17, [x16, #1384]
 310:	9115a210 	add	x16, x16, #0x568
 314:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000318 <main>:
#include <uapi/types.h>
#include "user/user.h"

int
main(int argc, char **argv)
{
 318:	d108c3ff 	sub	sp, sp, #0x230
 31c:	a9007bfd 	stp	x29, x30, [sp]
 320:	910003fd 	mov	x29, sp
 324:	a90153f3 	stp	x19, x20, [sp, #16]
  char buf[512];
  uint64 off = 0;
  int n;
  if(argc != 2){ fprintf(2, "usage: ext2cat /path\n"); exit(1); }
 328:	7100081f 	cmp	w0, #0x2
 32c:	54000420 	b.eq	3b0 <main+0x98>  // b.none
 330:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 334:	910ef021 	add	x1, x1, #0x3bc
  while((n = ext2read(argv[1], buf, sizeof(buf), off)) > 0){
    if(write(1, buf, n) != n){ fprintf(2, "ext2cat: stdout write failed\n"); exit(1); }
 338:	52800040 	mov	w0, #0x2                   	// #2
 33c:	97ffffeb 	bl	2e8 <fprintf@plt>
 340:	52800020 	mov	w0, #0x1                   	// #1
 344:	97ffffed 	bl	2f8 <exit@plt>
 348:	9100c3e1 	add	x1, sp, #0x30
 34c:	52800020 	mov	w0, #0x1                   	// #1
 350:	b9002fe2 	str	w2, [sp, #44]
 354:	97ffffe1 	bl	2d8 <write@plt>
 358:	b9402fe2 	ldr	w2, [sp, #44]
 35c:	6b02001f 	cmp	w0, w2
 360:	54000080 	b.eq	370 <main+0x58>  // b.none
 364:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 368:	910f4821 	add	x1, x1, #0x3d2
 36c:	17fffff3 	b	338 <main+0x20>
    off += n;
 370:	8b204273 	add	x19, x19, w0, uxtw
  while((n = ext2read(argv[1], buf, sizeof(buf), off)) > 0){
 374:	f9400680 	ldr	x0, [x20, #8]
 378:	52804002 	mov	w2, #0x200                 	// #512
 37c:	aa1303e3 	mov	x3, x19
 380:	9100c3e1 	add	x1, sp, #0x30
 384:	97ffffe1 	bl	308 <ext2read@plt>
 388:	2a0003e2 	mov	w2, w0
 38c:	7100001f 	cmp	w0, #0x0
 390:	54fffdcc 	b.gt	348 <main+0x30>
  }
  if(n < 0){ fprintf(2, "ext2cat: cannot read %s\n", argv[1]); exit(1); }
 394:	54fffd80 	b.eq	344 <main+0x2c>  // b.none
 398:	f9400682 	ldr	x2, [x20, #8]
 39c:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 3a0:	910fc021 	add	x1, x1, #0x3f0
 3a4:	52800040 	mov	w0, #0x2                   	// #2
 3a8:	97ffffd0 	bl	2e8 <fprintf@plt>
 3ac:	17ffffe5 	b	340 <main+0x28>
 3b0:	aa0103f4 	mov	x20, x1
  uint64 off = 0;
 3b4:	d2800013 	mov	x19, #0x0                   	// #0
 3b8:	17ffffef 	b	374 <main+0x5c>
