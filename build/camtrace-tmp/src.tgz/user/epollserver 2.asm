
user/_epollserver:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000004a8 <.plt>:
 4a8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 4ac:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 4b0:	f945ae11 	ldr	x17, [x16, #2904]
 4b4:	912d6210 	add	x16, x16, #0xb58
 4b8:	d61f0220 	br	x17
 4bc:	d503201f 	nop
 4c0:	d503201f 	nop
 4c4:	d503201f 	nop

00000000000004c8 <socket_accept@plt>:
 4c8:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 4cc:	f945b211 	ldr	x17, [x16, #2912]
 4d0:	912d8210 	add	x16, x16, #0xb60
 4d4:	d61f0220 	br	x17

00000000000004d8 <printf@plt>:
 4d8:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 4dc:	f945b611 	ldr	x17, [x16, #2920]
 4e0:	912da210 	add	x16, x16, #0xb68
 4e4:	d61f0220 	br	x17

00000000000004e8 <epoll_wait@plt>:
 4e8:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 4ec:	f945ba11 	ldr	x17, [x16, #2928]
 4f0:	912dc210 	add	x16, x16, #0xb70
 4f4:	d61f0220 	br	x17

00000000000004f8 <memmove@plt>:
 4f8:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 4fc:	f945be11 	ldr	x17, [x16, #2936]
 500:	912de210 	add	x16, x16, #0xb78
 504:	d61f0220 	br	x17

0000000000000508 <epoll_ctl@plt>:
 508:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 50c:	f945c211 	ldr	x17, [x16, #2944]
 510:	912e0210 	add	x16, x16, #0xb80
 514:	d61f0220 	br	x17

0000000000000518 <write@plt>:
 518:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 51c:	f945c611 	ldr	x17, [x16, #2952]
 520:	912e2210 	add	x16, x16, #0xb88
 524:	d61f0220 	br	x17

0000000000000528 <read@plt>:
 528:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 52c:	f945ca11 	ldr	x17, [x16, #2960]
 530:	912e4210 	add	x16, x16, #0xb90
 534:	d61f0220 	br	x17

0000000000000538 <epoll_create@plt>:
 538:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 53c:	f945ce11 	ldr	x17, [x16, #2968]
 540:	912e6210 	add	x16, x16, #0xb98
 544:	d61f0220 	br	x17

0000000000000548 <socket_listen@plt>:
 548:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 54c:	f945d211 	ldr	x17, [x16, #2976]
 550:	912e8210 	add	x16, x16, #0xba0
 554:	d61f0220 	br	x17

0000000000000558 <exit@plt>:
 558:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 55c:	f945d611 	ldr	x17, [x16, #2984]
 560:	912ea210 	add	x16, x16, #0xba8
 564:	d61f0220 	br	x17

0000000000000568 <fcntl@plt>:
 568:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 56c:	f945da11 	ldr	x17, [x16, #2992]
 570:	912ec210 	add	x16, x16, #0xbb0
 574:	d61f0220 	br	x17

0000000000000578 <close@plt>:
 578:	b0000010 	adrp	x16, 1000 <set_nonblocking+0x6d0>
 57c:	f945de11 	ldr	x17, [x16, #3000]
 580:	912ee210 	add	x16, x16, #0xbb8
 584:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000588 <main>:
  }
}

int
main(void)
{
 588:	d11643ff 	sub	sp, sp, #0x590
  struct epoll_event ev, events[MAX_EVENTS];
  int server_fd = socket_listen(PORT, 10);
 58c:	52800141 	mov	w1, #0xa                   	// #10
 590:	5283f200 	mov	w0, #0x1f90                	// #8080
{
 594:	a9007bfd 	stp	x29, x30, [sp]
 598:	910003fd 	mov	x29, sp
 59c:	a90153f3 	stp	x19, x20, [sp, #16]
 5a0:	a9025bf5 	stp	x21, x22, [sp, #32]
 5a4:	a90363f7 	stp	x23, x24, [sp, #48]
 5a8:	a9046bf9 	stp	x25, x26, [sp, #64]
 5ac:	a90573fb 	stp	x27, x28, [sp, #80]
  int server_fd = socket_listen(PORT, 10);
 5b0:	97ffffe6 	bl	548 <socket_listen@plt>
  if(server_fd < 0 || set_nonblocking(server_fd) < 0){
 5b4:	37f80080 	tbnz	w0, #31, 5c4 <main+0x3c>
 5b8:	2a0003f5 	mov	w21, w0
 5bc:	940000dd 	bl	930 <set_nonblocking>
 5c0:	36f800e0 	tbz	w0, #31, 5dc <main+0x54>
    printf("epollserver: cannot listen on %d\n", PORT);
 5c4:	90000000 	adrp	x0, 0 <.plt-0x4a8>
 5c8:	9125e000 	add	x0, x0, #0x978
 5cc:	5283f201 	mov	w1, #0x1f90                	// #8080
 5d0:	97ffffc2 	bl	4d8 <printf@plt>
  }

  int epoll_fd = epoll_create();
  if(epoll_fd < 0){
    close(server_fd);
    exit(1);
 5d4:	52800020 	mov	w0, #0x1                   	// #1
 5d8:	97ffffe0 	bl	558 <exit@plt>
  int epoll_fd = epoll_create();
 5dc:	97ffffd7 	bl	538 <epoll_create@plt>
 5e0:	2a0003f9 	mov	w25, w0
  if(epoll_fd < 0){
 5e4:	36f80080 	tbz	w0, #31, 5f4 <main+0x6c>
    close(server_fd);
 5e8:	2a1503e0 	mov	w0, w21
 5ec:	97ffffe3 	bl	578 <close@plt>
 5f0:	17fffff9 	b	5d4 <main+0x4c>
  }
  ev.events = EPOLLIN;
 5f4:	52800033 	mov	w19, #0x1                   	// #1
  ev.data.fd = server_fd;
  if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, server_fd, &ev) < 0){
 5f8:	910203e3 	add	x3, sp, #0x80
 5fc:	2a1503e2 	mov	w2, w21
 600:	2a1303e1 	mov	w1, w19
  ev.events = EPOLLIN;
 604:	b90083f3 	str	w19, [sp, #128]
  ev.data.fd = server_fd;
 608:	b9008bf5 	str	w21, [sp, #136]
  if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, server_fd, &ev) < 0){
 60c:	97ffffbf 	bl	508 <epoll_ctl@plt>
 610:	36f800a0 	tbz	w0, #31, 624 <main+0x9c>
    printf("epollserver: epoll_ctl listener failed\n");
 614:	90000000 	adrp	x0, 0 <.plt-0x4a8>
 618:	91266800 	add	x0, x0, #0x99a
 61c:	97ffffaf 	bl	4d8 <printf@plt>
    exit(1);
 620:	17ffffed 	b	5d4 <main+0x4c>
    if(clients[i].fd == 0){
 624:	b0000013 	adrp	x19, 1000 <set_nonblocking+0x6d0>
 628:	912f0273 	add	x19, x19, #0xbc0
  }
  printf("Epoll server started on port %d...\n", PORT);
 62c:	90000000 	adrp	x0, 0 <.plt-0x4a8>
 630:	91270800 	add	x0, x0, #0x9c2
 634:	5283f201 	mov	w1, #0x1f90                	// #8080
 638:	97ffffa8 	bl	4d8 <printf@plt>

  for(;;){
    int nfds = epoll_wait(epoll_fd, events, MAX_EVENTS, -1);
 63c:	910243e1 	add	x1, sp, #0x90
 640:	2a1903e0 	mov	w0, w25
 644:	12800003 	mov	w3, #0xffffffff            	// #-1
 648:	52800202 	mov	w2, #0x10                  	// #16
 64c:	97ffffa7 	bl	4e8 <epoll_wait@plt>
 650:	b9007be0 	str	w0, [sp, #120]
    if(nfds < 0)
 654:	37f81400 	tbnz	w0, #31, 8d4 <main+0x34c>
 658:	910243f6 	add	x22, sp, #0x90
      break;
    for(int i = 0; i < nfds; i++){
 65c:	5280001b 	mov	w27, #0x0                   	// #0
 660:	b9407be0 	ldr	w0, [sp, #120]
 664:	6b00037f 	cmp	w27, w0
 668:	54fffea0 	b.eq	63c <main+0xb4>  // b.none
      int fd = events[i].data.fd;
 66c:	b9400ada 	ldr	w26, [x22, #8]
      if(fd == server_fd){
 670:	6b1a02bf 	cmp	w21, w26
 674:	54000181 	b.ne	6a4 <main+0x11c>  // b.any
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
            close(client_fd);
            client->fd = 0;
            continue;
          }
          printf("New client connected fd=%d.\n", client_fd);
 678:	90000014 	adrp	x20, 0 <.plt-0x4a8>
 67c:	91279a94 	add	x20, x20, #0x9e6
          int client_fd = socket_accept(server_fd);
 680:	2a1a03e0 	mov	w0, w26
 684:	97ffff91 	bl	4c8 <socket_accept@plt>
 688:	2a0003f8 	mov	w24, w0
          if(client_fd < 0)
 68c:	37f80780 	tbnz	w0, #31, 77c <main+0x1f4>
          if(set_nonblocking(client_fd) < 0){
 690:	940000a8 	bl	930 <set_nonblocking>
 694:	36f802e0 	tbz	w0, #31, 6f0 <main+0x168>
            close(client_fd);
 698:	2a1803e0 	mov	w0, w24
 69c:	97ffffb7 	bl	578 <close@plt>
            continue;
 6a0:	17fffff8 	b	680 <main+0xf8>
      if(fd == server_fd){
 6a4:	d2800014 	mov	x20, #0x0                   	// #0
    if(clients[i].fd == fd)
 6a8:	52820200 	mov	w0, #0x1010                	// #4112
 6ac:	9ba07e9c 	umull	x28, w20, w0
 6b0:	8b130380 	add	x0, x28, x19
 6b4:	f90037e0 	str	x0, [sp, #104]
 6b8:	b87c6a60 	ldr	w0, [x19, x28]
 6bc:	6b00035f 	cmp	w26, w0
 6c0:	54000581 	b.ne	770 <main+0x1e8>  // b.any
        }
      } else {
        struct client *client = find_client(fd);
        if(client == 0)
          continue;
        if(events[i].events & EPOLLERR){
 6c4:	b94002c0 	ldr	w0, [x22]
 6c8:	121d0018 	and	w24, w0, #0x8
 6cc:	361805e0 	tbz	w0, #3, 788 <main+0x200>
          close_client(epoll_fd, client);
          printf("Client fd=%d disconnected.\n", fd);
          continue;
        }
        if(update_client_events(epoll_fd, client) < 0){
          close_client(epoll_fd, client);
 6d0:	f94037e1 	ldr	x1, [sp, #104]
 6d4:	2a1903e0 	mov	w0, w25
 6d8:	94000088 	bl	8f8 <close_client>
          printf("Client fd=%d disconnected.\n", fd);
 6dc:	2a1a03e1 	mov	w1, w26
 6e0:	90000000 	adrp	x0, 0 <.plt-0x4a8>
 6e4:	91280c00 	add	x0, x0, #0xa03
 6e8:	97ffff7c 	bl	4d8 <printf@plt>
 6ec:	14000024 	b	77c <main+0x1f4>
          if(set_nonblocking(client_fd) < 0){
 6f0:	d2800003 	mov	x3, #0x0                   	// #0
    if(clients[i].fd == 0){
 6f4:	52820200 	mov	w0, #0x1010                	// #4112
 6f8:	9ba07c60 	umull	x0, w3, w0
 6fc:	b8606a60 	ldr	w0, [x19, x0]
 700:	35000280 	cbnz	w0, 750 <main+0x1c8>
      clients[i].fd = fd;
 704:	2a0303e3 	mov	w3, w3
 708:	d2820200 	mov	x0, #0x1010                	// #4112
      clients[i].events = EPOLLIN;
 70c:	d2800021 	mov	x1, #0x1                   	// #1
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
 710:	2a1803e2 	mov	w2, w24
          ev.events = EPOLLIN;
 714:	b90083e1 	str	w1, [sp, #128]
      clients[i].fd = fd;
 718:	9b007c77 	mul	x23, x3, x0
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
 71c:	910203e3 	add	x3, sp, #0x80
      clients[i].fd = fd;
 720:	8b170260 	add	x0, x19, x23
 724:	b8376a78 	str	w24, [x19, x23]
      clients[i].events = EPOLLIN;
 728:	f8004001 	stur	x1, [x0, #4]
      clients[i].read_closed = 0;
 72c:	b9000c1f 	str	wzr, [x0, #12]
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
 730:	2a1903e0 	mov	w0, w25
          ev.data.fd = client_fd;
 734:	b9008bf8 	str	w24, [sp, #136]
          if(epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &ev) < 0){
 738:	97ffff74 	bl	508 <epoll_ctl@plt>
 73c:	36f80120 	tbz	w0, #31, 760 <main+0x1d8>
            close(client_fd);
 740:	2a1803e0 	mov	w0, w24
 744:	97ffff8d 	bl	578 <close@plt>
            client->fd = 0;
 748:	b8376a7f 	str	wzr, [x19, x23]
            continue;
 74c:	17ffffcd 	b	680 <main+0xf8>
  for(int i = 0; i < MAX_EVENTS - 1; i++){
 750:	91000463 	add	x3, x3, #0x1
 754:	f1003c7f 	cmp	x3, #0xf
 758:	54fffce1 	b.ne	6f4 <main+0x16c>  // b.any
 75c:	17ffffcf 	b	698 <main+0x110>
          printf("New client connected fd=%d.\n", client_fd);
 760:	2a1803e1 	mov	w1, w24
 764:	aa1403e0 	mov	x0, x20
 768:	97ffff5c 	bl	4d8 <printf@plt>
 76c:	17ffffc5 	b	680 <main+0xf8>
  for(int i = 0; i < MAX_EVENTS - 1; i++)
 770:	91000694 	add	x20, x20, #0x1
 774:	f1003e9f 	cmp	x20, #0xf
 778:	54fff981 	b.ne	6a8 <main+0x120>  // b.any
    for(int i = 0; i < nfds; i++){
 77c:	1100077b 	add	w27, w27, #0x1
 780:	910042d6 	add	x22, x22, #0x10
 784:	17ffffb7 	b	660 <main+0xd8>
        if(events[i].events & EPOLLIN){
 788:	2a1403f4 	mov	w20, w20
 78c:	36000120 	tbz	w0, #0, 7b0 <main+0x228>
  while(client->output_len < OUTPUT_SIZE){
 790:	d2820203 	mov	x3, #0x1010                	// #4112
    memmove(client->output + client->output_len, buf, n);
 794:	91004260 	add	x0, x19, #0x10
 798:	8b1c0000 	add	x0, x0, x28
 79c:	f9003be0 	str	x0, [sp, #112]
  while(client->output_len < OUTPUT_SIZE){
 7a0:	9b034e97 	madd	x23, x20, x3, x19
 7a4:	b9400ae2 	ldr	w2, [x23, #8]
 7a8:	713ffc5f 	cmp	w2, #0xfff
 7ac:	5400046d 	b.le	838 <main+0x2b0>
        if(events[i].events & EPOLLOUT)
 7b0:	b94002c0 	ldr	w0, [x22]
 7b4:	36100120 	tbz	w0, #2, 7d8 <main+0x250>
  while(client->output_len > 0){
 7b8:	d2820203 	mov	x3, #0x1010                	// #4112
    int n = write(client->fd, client->output, client->output_len);
 7bc:	b0000000 	adrp	x0, 1000 <set_nonblocking+0x6d0>
 7c0:	912f4000 	add	x0, x0, #0xbd0
 7c4:	8b1c0017 	add	x23, x0, x28
  while(client->output_len > 0){
 7c8:	9b034e9c 	madd	x28, x20, x3, x19
 7cc:	b9400b82 	ldr	w2, [x28, #8]
 7d0:	7100005f 	cmp	w2, #0x0
 7d4:	540005ec 	b.gt	890 <main+0x308>
        if(client->read_closed && client->output_len == 0){
 7d8:	d2820200 	mov	x0, #0x1010                	// #4112
 7dc:	9b004e80 	madd	x0, x20, x0, x19
 7e0:	29410400 	ldp	w0, w1, [x0, #8]
 7e4:	34000721 	cbz	w1, 8c8 <main+0x340>
 7e8:	34fff740 	cbz	w0, 6d0 <main+0x148>
    events |= EPOLLOUT;
 7ec:	7100001f 	cmp	w0, #0x0
  if(events == client->events)
 7f0:	d2820200 	mov	x0, #0x1010                	// #4112
    events |= EPOLLOUT;
 7f4:	321e0301 	orr	w1, w24, #0x4
  if(events == client->events)
 7f8:	9b007e80 	mul	x0, x20, x0
    events |= EPOLLOUT;
 7fc:	1a98c038 	csel	w24, w1, w24, gt
  if(events == client->events)
 800:	8b000274 	add	x20, x19, x0
 804:	b9400681 	ldr	w1, [x20, #4]
 808:	6b18003f 	cmp	w1, w24
 80c:	54fffb80 	b.eq	77c <main+0x1f4>  // b.none
  ev.data.fd = client->fd;
 810:	b8606a62 	ldr	w2, [x19, x0]
  if(epoll_ctl(epoll_fd, EPOLL_CTL_MOD, client->fd, &ev) < 0)
 814:	910643e3 	add	x3, sp, #0x190
 818:	2a1903e0 	mov	w0, w25
 81c:	52800061 	mov	w1, #0x3                   	// #3
  ev.events = events;
 820:	b90193f8 	str	w24, [sp, #400]
  ev.data.fd = client->fd;
 824:	b9019be2 	str	w2, [sp, #408]
  if(epoll_ctl(epoll_fd, EPOLL_CTL_MOD, client->fd, &ev) < 0)
 828:	97ffff38 	bl	508 <epoll_ctl@plt>
 82c:	37fff520 	tbnz	w0, #31, 6d0 <main+0x148>
  client->events = events;
 830:	b9000698 	str	w24, [x20, #4]
  return 0;
 834:	17ffffd2 	b	77c <main+0x1f4>
    int space = OUTPUT_SIZE - client->output_len;
 838:	52820000 	mov	w0, #0x1000                	// #4096
 83c:	4b020002 	sub	w2, w0, w2
    int size = space < READ_SIZE ? space : READ_SIZE;
 840:	7110005f 	cmp	w2, #0x400
    int n = read(client->fd, buf, size);
 844:	52808000 	mov	w0, #0x400                 	// #1024
 848:	1a80d042 	csel	w2, w2, w0, le
 84c:	b94002e0 	ldr	w0, [x23]
 850:	910643e1 	add	x1, sp, #0x190
 854:	97ffff35 	bl	528 <read@plt>
 858:	2a0003e2 	mov	w2, w0
    if(n == 0)
 85c:	34000480 	cbz	w0, 8ec <main+0x364>
    if(n < 0)
 860:	37fffa80 	tbnz	w0, #31, 7b0 <main+0x228>
    memmove(client->output + client->output_len, buf, n);
 864:	f9403be3 	ldr	x3, [sp, #112]
 868:	910643e1 	add	x1, sp, #0x190
 86c:	b9800ae0 	ldrsw	x0, [x23, #8]
 870:	b9007fe2 	str	w2, [sp, #124]
 874:	8b000060 	add	x0, x3, x0
 878:	97ffff20 	bl	4f8 <memmove@plt>
    client->output_len += n;
 87c:	b9400ae0 	ldr	w0, [x23, #8]
 880:	b9407fe2 	ldr	w2, [sp, #124]
 884:	0b020000 	add	w0, w0, w2
 888:	b9000ae0 	str	w0, [x23, #8]
 88c:	17ffffc6 	b	7a4 <main+0x21c>
    int n = write(client->fd, client->output, client->output_len);
 890:	b9400380 	ldr	w0, [x28]
 894:	aa1703e1 	mov	x1, x23
 898:	97ffff20 	bl	518 <write@plt>
    if(n <= 0)
 89c:	7100001f 	cmp	w0, #0x0
 8a0:	54fff9cd 	b.le	7d8 <main+0x250>
    client->output_len -= n;
 8a4:	b9400b82 	ldr	w2, [x28, #8]
 8a8:	4b000042 	sub	w2, w2, w0
 8ac:	b9000b82 	str	w2, [x28, #8]
    if(client->output_len > 0)
 8b0:	7100005f 	cmp	w2, #0x0
 8b4:	54fff8cd 	b.le	7cc <main+0x244>
      memmove(client->output, client->output + n, client->output_len);
 8b8:	8b2042e1 	add	x1, x23, w0, uxtw
 8bc:	aa1703e0 	mov	x0, x23
 8c0:	97ffff0e 	bl	4f8 <memmove@plt>
 8c4:	17ffffc2 	b	7cc <main+0x244>
  if(!client->read_closed && client->output_len < OUTPUT_SIZE)
 8c8:	713ffc1f 	cmp	w0, #0xfff
 8cc:	1a9fc7f8 	cset	w24, le
 8d0:	17ffffc7 	b	7ec <main+0x264>
        }
      }
    }
  }
  close(epoll_fd);
 8d4:	2a1903e0 	mov	w0, w25
 8d8:	97ffff28 	bl	578 <close@plt>
  close(server_fd);
 8dc:	2a1503e0 	mov	w0, w21
 8e0:	97ffff26 	bl	578 <close@plt>
  exit(0);
 8e4:	52800000 	mov	w0, #0x0                   	// #0
 8e8:	17ffff3c 	b	5d8 <main+0x50>
            client->read_closed = 1;
 8ec:	52800020 	mov	w0, #0x1                   	// #1
 8f0:	b9000ee0 	str	w0, [x23, #12]
 8f4:	17ffffaf 	b	7b0 <main+0x228>

00000000000008f8 <close_client>:
{
 8f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  epoll_ctl(epoll_fd, EPOLL_CTL_DEL, client->fd, 0);
 8fc:	d2800003 	mov	x3, #0x0                   	// #0
{
 900:	910003fd 	mov	x29, sp
 904:	f9000bf3 	str	x19, [sp, #16]
 908:	aa0103f3 	mov	x19, x1
  epoll_ctl(epoll_fd, EPOLL_CTL_DEL, client->fd, 0);
 90c:	52800041 	mov	w1, #0x2                   	// #2
 910:	b9400262 	ldr	w2, [x19]
 914:	97fffefd 	bl	508 <epoll_ctl@plt>
  close(client->fd);
 918:	b9400260 	ldr	w0, [x19]
 91c:	97ffff17 	bl	578 <close@plt>
  client->fd = 0;
 920:	a9007e7f 	stp	xzr, xzr, [x19]
}
 924:	f9400bf3 	ldr	x19, [sp, #16]
 928:	a8c27bfd 	ldp	x29, x30, [sp], #32
 92c:	d65f03c0 	ret

0000000000000930 <set_nonblocking>:
{
 930:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  int flags = fcntl(fd, F_GETFL, 0);
 934:	52800002 	mov	w2, #0x0                   	// #0
 938:	52800061 	mov	w1, #0x3                   	// #3
{
 93c:	910003fd 	mov	x29, sp
 940:	f9000bf3 	str	x19, [sp, #16]
 944:	2a0003f3 	mov	w19, w0
  int flags = fcntl(fd, F_GETFL, 0);
 948:	97ffff08 	bl	568 <fcntl@plt>
  if(flags < 0)
 94c:	37f800e0 	tbnz	w0, #31, 968 <set_nonblocking+0x38>
  return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
 950:	32150002 	orr	w2, w0, #0x800
 954:	2a1303e0 	mov	w0, w19
}
 958:	f9400bf3 	ldr	x19, [sp, #16]
  return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
 95c:	52800081 	mov	w1, #0x4                   	// #4
}
 960:	a8c27bfd 	ldp	x29, x30, [sp], #32
  return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
 964:	17ffff01 	b	568 <fcntl@plt>
}
 968:	f9400bf3 	ldr	x19, [sp, #16]
 96c:	12800000 	mov	w0, #0xffffffff            	// #-1
 970:	a8c27bfd 	ldp	x29, x30, [sp], #32
 974:	d65f03c0 	ret
