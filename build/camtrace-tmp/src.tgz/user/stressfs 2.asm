
user/_stressfs:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000003d0 <.plt>:
 3d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 3d4:	b0000010 	adrp	x16, 1000 <main+0xb80>
 3d8:	f9437611 	ldr	x17, [x16, #1768]
 3dc:	911ba210 	add	x16, x16, #0x6e8
 3e0:	d61f0220 	br	x17
 3e4:	d503201f 	nop
 3e8:	d503201f 	nop
 3ec:	d503201f 	nop

00000000000003f0 <printf@plt>:
 3f0:	b0000010 	adrp	x16, 1000 <main+0xb80>
 3f4:	f9437a11 	ldr	x17, [x16, #1776]
 3f8:	911bc210 	add	x16, x16, #0x6f0
 3fc:	d61f0220 	br	x17

0000000000000400 <write@plt>:
 400:	b0000010 	adrp	x16, 1000 <main+0xb80>
 404:	f9437e11 	ldr	x17, [x16, #1784]
 408:	911be210 	add	x16, x16, #0x6f8
 40c:	d61f0220 	br	x17

0000000000000410 <wait@plt>:
 410:	b0000010 	adrp	x16, 1000 <main+0xb80>
 414:	f9438211 	ldr	x17, [x16, #1792]
 418:	911c0210 	add	x16, x16, #0x700
 41c:	d61f0220 	br	x17

0000000000000420 <read@plt>:
 420:	b0000010 	adrp	x16, 1000 <main+0xb80>
 424:	f9438611 	ldr	x17, [x16, #1800]
 428:	911c2210 	add	x16, x16, #0x708
 42c:	d61f0220 	br	x17

0000000000000430 <fork@plt>:
 430:	b0000010 	adrp	x16, 1000 <main+0xb80>
 434:	f9438a11 	ldr	x17, [x16, #1808]
 438:	911c4210 	add	x16, x16, #0x710
 43c:	d61f0220 	br	x17

0000000000000440 <memset@plt>:
 440:	b0000010 	adrp	x16, 1000 <main+0xb80>
 444:	f9438e11 	ldr	x17, [x16, #1816]
 448:	911c6210 	add	x16, x16, #0x718
 44c:	d61f0220 	br	x17

0000000000000450 <exit@plt>:
 450:	b0000010 	adrp	x16, 1000 <main+0xb80>
 454:	f9439211 	ldr	x17, [x16, #1824]
 458:	911c8210 	add	x16, x16, #0x720
 45c:	d61f0220 	br	x17

0000000000000460 <open@plt>:
 460:	b0000010 	adrp	x16, 1000 <main+0xb80>
 464:	f9439611 	ldr	x17, [x16, #1832]
 468:	911ca210 	add	x16, x16, #0x728
 46c:	d61f0220 	br	x17

0000000000000470 <close@plt>:
 470:	b0000010 	adrp	x16, 1000 <main+0xb80>
 474:	f9439a11 	ldr	x17, [x16, #1840]
 478:	911cc210 	add	x16, x16, #0x730
 47c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000480 <main>:
#include <uapi/xv6fs.h>
#include <fcntl.h>

int
main(int argc, char *argv[])
{
 480:	d108c3ff 	sub	sp, sp, #0x230
  int fd, i;
  char path[] = "stressfs0";
 484:	90000000 	adrp	x0, 0 <.plt-0x3d0>
 488:	91168c00 	add	x0, x0, #0x5a3
{
 48c:	a9007bfd 	stp	x29, x30, [sp]
 490:	910003fd 	mov	x29, sp
  char path[] = "stressfs0";
 494:	f9400001 	ldr	x1, [x0]
{
 498:	a90153f3 	stp	x19, x20, [sp, #16]
  char path[] = "stressfs0";
 49c:	79401000 	ldrh	w0, [x0, #8]
 4a0:	f90013e1 	str	x1, [sp, #32]
  char data[512];

  printf("stressfs starting\n");
  memset(data, 'a', sizeof(data));

  for(i = 0; i < 4; i++)
 4a4:	52800013 	mov	w19, #0x0                   	// #0
  char path[] = "stressfs0";
 4a8:	790053e0 	strh	w0, [sp, #40]
  printf("stressfs starting\n");
 4ac:	90000000 	adrp	x0, 0 <.plt-0x3d0>
 4b0:	91160000 	add	x0, x0, #0x580
 4b4:	97ffffcf 	bl	3f0 <printf@plt>
  memset(data, 'a', sizeof(data));
 4b8:	9100c3e0 	add	x0, sp, #0x30
 4bc:	52804002 	mov	w2, #0x200                 	// #512
 4c0:	52800c21 	mov	w1, #0x61                  	// #97
 4c4:	97ffffdf 	bl	440 <memset@plt>
    if(fork() > 0)
 4c8:	97ffffda 	bl	430 <fork@plt>
 4cc:	7100001f 	cmp	w0, #0x0
 4d0:	5400008c 	b.gt	4e0 <main+0x60>
  for(i = 0; i < 4; i++)
 4d4:	11000673 	add	w19, w19, #0x1
 4d8:	7100127f 	cmp	w19, #0x4
 4dc:	54ffff61 	b.ne	4c8 <main+0x48>  // b.any
      break;

  printf("write %d\n", i);
 4e0:	2a1303e1 	mov	w1, w19
 4e4:	90000000 	adrp	x0, 0 <.plt-0x3d0>
 4e8:	91164c00 	add	x0, x0, #0x593
 4ec:	97ffffc1 	bl	3f0 <printf@plt>

  path[8] += i;
 4f0:	3940a3e0 	ldrb	w0, [sp, #40]
  fd = open(path, O_CREATE | O_RDWR);
 4f4:	52804041 	mov	w1, #0x202                 	// #514
  path[8] += i;
 4f8:	0b000273 	add	w19, w19, w0
  fd = open(path, O_CREATE | O_RDWR);
 4fc:	910083e0 	add	x0, sp, #0x20
  path[8] += i;
 500:	3900a3f3 	strb	w19, [sp, #40]
  fd = open(path, O_CREATE | O_RDWR);
 504:	97ffffd7 	bl	460 <open@plt>
 508:	2a0003f4 	mov	w20, w0
 50c:	52800293 	mov	w19, #0x14                  	// #20
  for(i = 0; i < 20; i++)
//    printf(fd, "%d\n", i);
    write(fd, data, sizeof(data));
 510:	9100c3e1 	add	x1, sp, #0x30
 514:	2a1403e0 	mov	w0, w20
 518:	52804002 	mov	w2, #0x200                 	// #512
 51c:	97ffffb9 	bl	400 <write@plt>
  for(i = 0; i < 20; i++)
 520:	71000673 	subs	w19, w19, #0x1
 524:	54ffff61 	b.ne	510 <main+0x90>  // b.any
  close(fd);
 528:	2a1403e0 	mov	w0, w20
 52c:	97ffffd1 	bl	470 <close@plt>

  printf("read\n");
 530:	90000000 	adrp	x0, 0 <.plt-0x3d0>
 534:	91167400 	add	x0, x0, #0x59d
 538:	97ffffae 	bl	3f0 <printf@plt>

  fd = open(path, O_RDONLY);
 53c:	52800293 	mov	w19, #0x14                  	// #20
 540:	910083e0 	add	x0, sp, #0x20
 544:	52800001 	mov	w1, #0x0                   	// #0
 548:	97ffffc6 	bl	460 <open@plt>
 54c:	2a0003f4 	mov	w20, w0
  for (i = 0; i < 20; i++)
    read(fd, data, sizeof(data));
 550:	9100c3e1 	add	x1, sp, #0x30
 554:	2a1403e0 	mov	w0, w20
 558:	52804002 	mov	w2, #0x200                 	// #512
 55c:	97ffffb1 	bl	420 <read@plt>
  for (i = 0; i < 20; i++)
 560:	71000673 	subs	w19, w19, #0x1
 564:	54ffff61 	b.ne	550 <main+0xd0>  // b.any
  close(fd);
 568:	2a1403e0 	mov	w0, w20
 56c:	97ffffc1 	bl	470 <close@plt>

  wait(0);
 570:	d2800000 	mov	x0, #0x0                   	// #0
 574:	97ffffa7 	bl	410 <wait@plt>

  exit(0);
 578:	52800000 	mov	w0, #0x0                   	// #0
 57c:	97ffffb5 	bl	450 <exit@plt>
