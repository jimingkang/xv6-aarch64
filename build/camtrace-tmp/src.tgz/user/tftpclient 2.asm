
user/_tftpclient:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000510 <.plt>:
 510:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 514:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 518:	f9413611 	ldr	x17, [x16, #616]
 51c:	9109a210 	add	x16, x16, #0x268
 520:	d61f0220 	br	x17
 524:	d503201f 	nop
 528:	d503201f 	nop
 52c:	d503201f 	nop

0000000000000530 <printf@plt>:
 530:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 534:	f9413a11 	ldr	x17, [x16, #624]
 538:	9109c210 	add	x16, x16, #0x270
 53c:	d61f0220 	br	x17

0000000000000540 <memmove@plt>:
 540:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 544:	f9413e11 	ldr	x17, [x16, #632]
 548:	9109e210 	add	x16, x16, #0x278
 54c:	d61f0220 	br	x17

0000000000000550 <write@plt>:
 550:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 554:	f9414211 	ldr	x17, [x16, #640]
 558:	910a0210 	add	x16, x16, #0x280
 55c:	d61f0220 	br	x17

0000000000000560 <uptime@plt>:
 560:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 564:	f9414611 	ldr	x17, [x16, #648]
 568:	910a2210 	add	x16, x16, #0x288
 56c:	d61f0220 	br	x17

0000000000000570 <memset@plt>:
 570:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 574:	f9414a11 	ldr	x17, [x16, #656]
 578:	910a4210 	add	x16, x16, #0x290
 57c:	d61f0220 	br	x17

0000000000000580 <udp_bind@plt>:
 580:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 584:	f9414e11 	ldr	x17, [x16, #664]
 588:	910a6210 	add	x16, x16, #0x298
 58c:	d61f0220 	br	x17

0000000000000590 <udp_recv_timeout@plt>:
 590:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 594:	f9415211 	ldr	x17, [x16, #672]
 598:	910a8210 	add	x16, x16, #0x2a0
 59c:	d61f0220 	br	x17

00000000000005a0 <udp_send@plt>:
 5a0:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 5a4:	f9415611 	ldr	x17, [x16, #680]
 5a8:	910aa210 	add	x16, x16, #0x2a8
 5ac:	d61f0220 	br	x17

00000000000005b0 <udp_unbind@plt>:
 5b0:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 5b4:	f9415a11 	ldr	x17, [x16, #688]
 5b8:	910ac210 	add	x16, x16, #0x2b0
 5bc:	d61f0220 	br	x17

00000000000005c0 <exit@plt>:
 5c0:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 5c4:	f9415e11 	ldr	x17, [x16, #696]
 5c8:	910ae210 	add	x16, x16, #0x2b8
 5cc:	d61f0220 	br	x17

00000000000005d0 <strlen@plt>:
 5d0:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 5d4:	f9416211 	ldr	x17, [x16, #704]
 5d8:	910b0210 	add	x16, x16, #0x2c0
 5dc:	d61f0220 	br	x17

00000000000005e0 <open@plt>:
 5e0:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 5e4:	f9416611 	ldr	x17, [x16, #712]
 5e8:	910b2210 	add	x16, x16, #0x2c8
 5ec:	d61f0220 	br	x17

00000000000005f0 <strchr@plt>:
 5f0:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 5f4:	f9416a11 	ldr	x17, [x16, #720]
 5f8:	910b4210 	add	x16, x16, #0x2d0
 5fc:	d61f0220 	br	x17

0000000000000600 <close@plt>:
 600:	d0000010 	adrp	x16, 2000 <wait_packet.constprop.0+0x1360>
 604:	f9416e11 	ldr	x17, [x16, #728]
 608:	910b6210 	add	x16, x16, #0x2d8
 60c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000610 <main>:
  return -1;
}

int
main(int argc, char **argv)
{
 610:	a9af7bfd 	stp	x29, x30, [sp, #-272]!
 614:	910003fd 	mov	x29, sp
 618:	a90153f3 	stp	x19, x20, [sp, #16]
 61c:	a9025bf5 	stp	x21, x22, [sp, #32]
 620:	a90363f7 	stp	x23, x24, [sp, #48]
 624:	a9046bf9 	stp	x25, x26, [sp, #64]
 628:	a90573fb 	stp	x27, x28, [sp, #80]
  uint32 server;
  const char *server_name = TFTP_DEFAULT_SERVER;
  const char *remote_name = TFTP_DEFAULT_FILE;

  if(argc > 3){
 62c:	71000c1f 	cmp	w0, #0x3
 630:	540000cd 	b.le	648 <main+0x38>
    server_name = argv[1];
  if(argc == 3)
    remote_name = argv[2];
  if(parse_ipv4(server_name, &server) < 0){
    printf("tftpclient: invalid server IPv4 address: %s\n", server_name);
    printf("usage: tftpclient [server-ip [remote-filename]]\n");
 634:	90000000 	adrp	x0, 0 <.plt-0x510>
 638:	9135b400 	add	x0, x0, #0xd6d
 63c:	97ffffbd 	bl	530 <printf@plt>
    exit(1);
 640:	52800020 	mov	w0, #0x1                   	// #1
 644:	97ffffdf 	bl	5c0 <exit@plt>
  if(argc >= 2)
 648:	7100041f 	cmp	w0, #0x1
 64c:	5400092d 	b.le	770 <main+0x160>
 650:	aa0103e2 	mov	x2, x1
    server_name = argv[1];
 654:	f9400421 	ldr	x1, [x1, #8]
  if(argc == 3)
 658:	71000c1f 	cmp	w0, #0x3
 65c:	540008e1 	b.ne	778 <main+0x168>  // b.any
    remote_name = argv[2];
 660:	f9400854 	ldr	x20, [x2, #16]
  const char *p = text;
 664:	aa0103e0 	mov	x0, x1
  int octets = 0;
 668:	52800004 	mov	w4, #0x0                   	// #0
  uint32 result = 0;
 66c:	52800015 	mov	w21, #0x0                   	// #0
  while(*p){
 670:	39400002 	ldrb	w2, [x0]
 674:	350009a2 	cbnz	w2, 7a8 <main+0x198>
  if(octets != 4)
 678:	7100109f 	cmp	w4, #0x4
 67c:	540008e1 	b.ne	798 <main+0x188>  // b.any
  memset(final_path, 0, TFTP_PATH_SIZE);
 680:	d0000013 	adrp	x19, 2000 <wait_packet.constprop.0+0x1360>
 684:	910b8273 	add	x19, x19, #0x2e0
 688:	52801002 	mov	w2, #0x80                  	// #128
 68c:	52800001 	mov	w1, #0x0                   	// #0
 690:	91081260 	add	x0, x19, #0x204
  uint16 server_port = 0, expected_block = 1, last_ack = 0;
 694:	79011fff 	strh	wzr, [sp, #142]
  memset(final_path, 0, TFTP_PATH_SIZE);
 698:	97ffffb6 	bl	570 <memset@plt>
  const char mode[] = "octet";
 69c:	910243f8 	add	x24, sp, #0x90
  memmove(final_path, "/boot/", sizeof("/boot/"));
 6a0:	528000e2 	mov	w2, #0x7                   	// #7
 6a4:	91081260 	add	x0, x19, #0x204
 6a8:	90000001 	adrp	x1, 0 <.plt-0x510>
 6ac:	91372c21 	add	x1, x1, #0xdcb
 6b0:	97ffffa4 	bl	540 <memmove@plt>
  const char mode[] = "octet";
 6b4:	b0000000 	adrp	x0, 1000 <wait_packet.constprop.0+0x360>
 6b8:	91049400 	add	x0, x0, #0x125
 6bc:	b9400001 	ldr	w1, [x0]
 6c0:	79400800 	ldrh	w0, [x0, #4]
 6c4:	b90093e1 	str	w1, [sp, #144]
 6c8:	79000b00 	strh	w0, [x24, #4]
  int name_len = strlen(filename);
 6cc:	aa1403e0 	mov	x0, x20
 6d0:	97ffffc0 	bl	5d0 <strlen@plt>
  int length = 2 + name_len + 1 + mode_len;
 6d4:	11002416 	add	w22, w0, #0x9
  if(name_len == 0 || length > capacity)
 6d8:	710402df 	cmp	w22, #0x100
  int name_len = strlen(filename);
 6dc:	2a0003f7 	mov	w23, w0
  if(name_len == 0 || length > capacity)
 6e0:	7a40d804 	ccmp	w0, #0x0, #0x4, le
 6e4:	540008a0 	b.eq	7f8 <main+0x1e8>  // b.none
  p[0] = value >> 8;
 6e8:	52802000 	mov	w0, #0x100                 	// #256
  memmove(packet + 2, filename, name_len);
 6ec:	2a1703e2 	mov	w2, w23
 6f0:	aa1403e1 	mov	x1, x20
  p[0] = value >> 8;
 6f4:	79050a60 	strh	w0, [x19, #644]
  memmove(packet + 2, filename, name_len);
 6f8:	910a1a60 	add	x0, x19, #0x286
 6fc:	97ffff91 	bl	540 <memmove@plt>
  packet[2 + name_len] = 0;
 700:	11000ae1 	add	w1, w23, #0x2
  p[0] = value >> 8;
 704:	910a1279 	add	x25, x19, #0x284
  memmove(packet + 3 + name_len, mode, mode_len);
 708:	11000ef7 	add	w23, w23, #0x3
 70c:	528000c2 	mov	w2, #0x6                   	// #6
  packet[2 + name_len] = 0;
 710:	3821cb3f 	strb	wzr, [x25, w1, sxtw]
  memmove(packet + 3 + name_len, mode, mode_len);
 714:	8b37c320 	add	x0, x25, w23, sxtw
 718:	aa1803e1 	mov	x1, x24
 71c:	97ffff89 	bl	540 <memmove@plt>
  name_len = strlen(remote_name);
 720:	aa1403e0 	mov	x0, x20
 724:	97ffffab 	bl	5d0 <strlen@plt>
  if(rrq_len < 0 || name_len == 0 ||
 728:	710002df 	cmp	w22, #0x0
  name_len = strlen(remote_name);
 72c:	2a0003f7 	mov	w23, w0
  if(rrq_len < 0 || name_len == 0 ||
 730:	7a40a804 	ccmp	w0, #0x0, #0x4, ge	// ge = tcont
 734:	54000120 	b.eq	758 <main+0x148>  // b.none
     name_len + sizeof("/boot/") > TFTP_PATH_SIZE ||
 738:	93407c00 	sxtw	x0, w0
 73c:	91001c00 	add	x0, x0, #0x7
  if(rrq_len < 0 || name_len == 0 ||
 740:	f102001f 	cmp	x0, #0x80
 744:	540000a8 	b.hi	758 <main+0x148>  // b.pmore
     strchr(remote_name, '/') != 0){
 748:	aa1403e0 	mov	x0, x20
 74c:	528005e1 	mov	w1, #0x2f                  	// #47
 750:	97ffffa8 	bl	5f0 <strchr@plt>
     name_len + sizeof("/boot/") > TFTP_PATH_SIZE ||
 754:	b4000560 	cbz	x0, 800 <main+0x1f0>
    printf("tftpclient: invalid remote basename or filename is too long\n");
 758:	90000000 	adrp	x0, 0 <.plt-0x510>
 75c:	91374800 	add	x0, x0, #0xdd2
 760:	97ffff74 	bl	530 <printf@plt>
    return -1;
 764:	12800000 	mov	w0, #0xffffffff            	// #-1
  }
  exit(download(server, remote_name) < 0 ? 1 : 0);
 768:	4b0003e0 	neg	w0, w0
 76c:	17ffffb6 	b	644 <main+0x34>
  const char *server_name = TFTP_DEFAULT_SERVER;
 770:	90000001 	adrp	x1, 0 <.plt-0x510>
 774:	91357c21 	add	x1, x1, #0xd5f
  const char *remote_name = TFTP_DEFAULT_FILE;
 778:	90000014 	adrp	x20, 0 <.plt-0x510>
 77c:	91352a94 	add	x20, x20, #0xd4a
 780:	17ffffb9 	b	664 <main+0x54>
      value = value * 10 + *p++ - '0';
 784:	1b071442 	madd	w2, w2, w7, w5
      if(value > 255)
 788:	91000463 	add	x3, x3, #0x1
      value = value * 10 + *p++ - '0';
 78c:	5100c042 	sub	w2, w2, #0x30
      if(value > 255)
 790:	7103fc5f 	cmp	w2, #0xff
 794:	5400010d 	b.le	7b4 <main+0x1a4>
    printf("tftpclient: invalid server IPv4 address: %s\n", server_name);
 798:	90000000 	adrp	x0, 0 <.plt-0x510>
 79c:	91367800 	add	x0, x0, #0xd9e
 7a0:	97ffff64 	bl	530 <printf@plt>
 7a4:	17ffffa4 	b	634 <main+0x24>
  while(*p){
 7a8:	d2800003 	mov	x3, #0x0                   	// #0
    int value = 0, digits = 0;
 7ac:	52800002 	mov	w2, #0x0                   	// #0
      value = value * 10 + *p++ - '0';
 7b0:	52800147 	mov	w7, #0xa                   	// #10
    while(*p >= '0' && *p <= '9'){
 7b4:	38636805 	ldrb	w5, [x0, x3]
 7b8:	5100c0a6 	sub	w6, w5, #0x30
 7bc:	12001cc6 	and	w6, w6, #0xff
 7c0:	710024df 	cmp	w6, #0x9
 7c4:	54fffe09 	b.ls	784 <main+0x174>  // b.plast
    if(digits == 0)
 7c8:	34fffe83 	cbz	w3, 798 <main+0x188>
    octets++;
 7cc:	11000484 	add	w4, w4, #0x1
 7d0:	8b030000 	add	x0, x0, x3
    if(octets < 4){
 7d4:	71000c9f 	cmp	w4, #0x3
 7d8:	540000cc 	b.gt	7f0 <main+0x1e0>
      if(*p++ != '.')
 7dc:	7100b8bf 	cmp	w5, #0x2e
 7e0:	54fffdc1 	b.ne	798 <main+0x188>  // b.any
 7e4:	91000400 	add	x0, x0, #0x1
    result = (result << 8) | value;
 7e8:	2a152055 	orr	w21, w2, w21, lsl #8
 7ec:	17ffffa1 	b	670 <main+0x60>
    } else if(*p != 0){
 7f0:	34ffffc5 	cbz	w5, 7e8 <main+0x1d8>
 7f4:	17ffffe9 	b	798 <main+0x188>
    return -1;
 7f8:	12800016 	mov	w22, #0xffffffff            	// #-1
 7fc:	17ffffc9 	b	720 <main+0x110>
  memmove(final_path + sizeof("/boot/") - 1, remote_name, name_len + 1);
 800:	110006e2 	add	w2, w23, #0x1
 804:	aa1403e1 	mov	x1, x20
 808:	91082a60 	add	x0, x19, #0x20a
 80c:	97ffff4d 	bl	540 <memmove@plt>
  if(udp_bind(LOCAL_PORT) < 0){
 810:	52980000 	mov	w0, #0xc000                	// #49152
 814:	97ffff5b 	bl	580 <udp_bind@plt>
 818:	36f800c0 	tbz	w0, #31, 830 <main+0x220>
    printf("tftpclient: cannot bind local UDP port %d\n", LOCAL_PORT);
 81c:	90000000 	adrp	x0, 0 <.plt-0x510>
 820:	91383c00 	add	x0, x0, #0xe0f
 824:	52980001 	mov	w1, #0xc000                	// #49152
 828:	97ffff42 	bl	530 <printf@plt>
    return -1;
 82c:	17ffffce 	b	764 <main+0x154>
  start_ticks = uptime();
 830:	97ffff4c 	bl	560 <uptime@plt>
    printf("tftpclient: timeout waiting for server response (%d/%d)\n",
 834:	9000001a 	adrp	x26, 0 <.plt-0x510>
 838:	91399b5a 	add	x26, x26, #0xe66
  printf("tftpclient: requesting %s from %d.%d.%d.%d\n", remote_name,
 83c:	12001ea5 	and	w5, w21, #0xff
 840:	d3483ea4 	ubfx	x4, x21, #8, #8
 844:	d3505ea3 	ubfx	x3, x21, #16, #8
 848:	53187ea2 	lsr	w2, w21, #24
 84c:	aa1403e1 	mov	x1, x20
    if(udp_send(server, LOCAL_PORT, TFTP_PORT, rrq, rrq_len) != rrq_len)
 850:	910a127b 	add	x27, x19, #0x284
  for(int retry = 0; retry < TFTP_RETRIES; retry++){
 854:	52800017 	mov	w23, #0x0                   	// #0
  start_ticks = uptime();
 858:	b9007be0 	str	w0, [sp, #120]
  printf("tftpclient: requesting %s from %d.%d.%d.%d\n", remote_name,
 85c:	90000000 	adrp	x0, 0 <.plt-0x510>
 860:	9138e800 	add	x0, x0, #0xe3a
 864:	97ffff33 	bl	530 <printf@plt>
    if(udp_send(server, LOCAL_PORT, TFTP_PORT, rrq, rrq_len) != rrq_len)
 868:	2a1603e4 	mov	w4, w22
 86c:	aa1b03e3 	mov	x3, x27
 870:	2a1503e0 	mov	w0, w21
 874:	528008a2 	mov	w2, #0x45                  	// #69
 878:	52980001 	mov	w1, #0xc000                	// #49152
 87c:	97ffff49 	bl	5a0 <udp_send@plt>
 880:	6b0002df 	cmp	w22, w0
 884:	540001e1 	b.ne	8c0 <main+0x2b0>  // b.any
    int n = wait_packet(server, server_port, port, packet, TFTP_PACKET_SIZE);
 888:	91023be1 	add	x1, sp, #0x8e
 88c:	2a1503e0 	mov	w0, w21
 890:	94000104 	bl	ca0 <wait_packet.constprop.0>
 894:	2a0003e2 	mov	w2, w0
    if(n < 0)
 898:	3100041f 	cmn	w0, #0x1
 89c:	54000120 	b.eq	8c0 <main+0x2b0>  // b.none
    if(n > 0){
 8a0:	35001840 	cbnz	w0, ba8 <main+0x598>
    printf("tftpclient: timeout waiting for server response (%d/%d)\n",
 8a4:	110006f7 	add	w23, w23, #0x1
 8a8:	aa1a03e0 	mov	x0, x26
 8ac:	2a1703e1 	mov	w1, w23
 8b0:	528000a2 	mov	w2, #0x5                   	// #5
 8b4:	97ffff1f 	bl	530 <printf@plt>
  for(int retry = 0; retry < TFTP_RETRIES; retry++){
 8b8:	710016ff 	cmp	w23, #0x5
 8bc:	54fffd61 	b.ne	868 <main+0x258>  // b.any
    printf("tftpclient: no response from server\n");
 8c0:	b0000000 	adrp	x0, 1000 <wait_packet.constprop.0+0x360>
 8c4:	91040000 	add	x0, x0, #0x100
  int rrq_len, packet_len, fd = -1, total = 0, retries = 0, name_len;
 8c8:	12800017 	mov	w23, #0xffffffff            	// #-1
    printf("tftpclient: no response from server\n");
 8cc:	97ffff19 	bl	530 <printf@plt>
  if(fd >= 0)
 8d0:	14000005 	b	8e4 <main+0x2d4>
    printf("tftpclient: cannot create %s (check that /boot is mounted rw)\n",
 8d4:	90000000 	adrp	x0, 0 <.plt-0x510>
 8d8:	913a7c00 	add	x0, x0, #0xe9f
 8dc:	91081261 	add	x1, x19, #0x204
 8e0:	97ffff14 	bl	530 <printf@plt>
  udp_unbind(LOCAL_PORT);
 8e4:	52980000 	mov	w0, #0xc000                	// #49152
 8e8:	97ffff32 	bl	5b0 <udp_unbind@plt>
  if(fd >= 0)
 8ec:	37f81597 	tbnz	w23, #31, b9c <main+0x58c>
    printf("tftpclient: incomplete download remains at %s\n", final_path);
 8f0:	b0000000 	adrp	x0, 1000 <wait_packet.constprop.0+0x360>
 8f4:	91029400 	add	x0, x0, #0xa5
    printf("tftpclient: existing %s was left unchanged\n", final_path);
 8f8:	91081261 	add	x1, x19, #0x204
 8fc:	97ffff0d 	bl	530 <printf@plt>
 900:	17ffff99 	b	764 <main+0x154>
    opcode = get16(packet);
 904:	79400260 	ldrh	w0, [x19]
    if(opcode == 5){
 908:	7114001f 	cmp	w0, #0x500
 90c:	54000441 	b.ne	994 <main+0x384>  // b.any
      int code = packet_len >= 4 ? get16(packet + 2) : -1;
 910:	71000c5f 	cmp	w2, #0x3
 914:	5400020d 	b.le	954 <main+0x344>
 918:	79400661 	ldrh	w1, [x19, #2]
        while(length < packet_len - 4 && length < sizeof(message) - 1 &&
 91c:	51001059 	sub	w25, w2, #0x4
 920:	d2800000 	mov	x0, #0x0                   	// #0
      int code = packet_len >= 4 ? get16(packet + 2) : -1;
 924:	5ac00421 	rev16	w1, w1
 928:	12003c21 	and	w1, w1, #0xffff
      if(packet_len < 4){
 92c:	2a0003e2 	mov	w2, w0
        while(length < packet_len - 4 && length < sizeof(message) - 1 &&
 930:	6b00033f 	cmp	w25, w0
 934:	540000cd 	b.le	94c <main+0x33c>
 938:	f101fc1f 	cmp	x0, #0x7f
 93c:	54000080 	b.eq	94c <main+0x33c>  // b.none
              packet[length + 4] != 0){
 940:	8b000263 	add	x3, x19, x0
 944:	39401063 	ldrb	w3, [x3, #4]
        while(length < packet_len - 4 && length < sizeof(message) - 1 &&
 948:	35000203 	cbnz	w3, 988 <main+0x378>
        message[length] = 0;
 94c:	38224b1f 	strb	wzr, [x24, w2, uxtw]
 950:	14000007 	b	96c <main+0x35c>
        memmove(message, "malformed error", sizeof("malformed error"));
 954:	aa1803e0 	mov	x0, x24
 958:	90000001 	adrp	x1, 0 <.plt-0x510>
 95c:	913bf021 	add	x1, x1, #0xefc
 960:	52800202 	mov	w2, #0x10                  	// #16
 964:	97fffef7 	bl	540 <memmove@plt>
      int code = packet_len >= 4 ? get16(packet + 2) : -1;
 968:	12800001 	mov	w1, #0xffffffff            	// #-1
      printf("tftpclient: server error %d: %s\n", code, message);
 96c:	90000000 	adrp	x0, 0 <.plt-0x510>
 970:	913c3000 	add	x0, x0, #0xf0c
 974:	aa1803e2 	mov	x2, x24
 978:	97fffeee 	bl	530 <printf@plt>
    close(fd);
 97c:	2a1703e0 	mov	w0, w23
 980:	97ffff20 	bl	600 <close@plt>
 984:	17ffffd8 	b	8e4 <main+0x2d4>
          message[length] = packet[length + 4];
 988:	38206b03 	strb	w3, [x24, x0]
          length++;
 98c:	91000400 	add	x0, x0, #0x1
 990:	17ffffe7 	b	92c <main+0x31c>
    if(opcode != 3 || packet_len < 4 ||
 994:	710c001f 	cmp	w0, #0x300
 998:	540000a1 	b.ne	9ac <main+0x39c>  // b.any
 99c:	71000c5f 	cmp	w2, #0x3
 9a0:	5400006d 	b.le	9ac <main+0x39c>
 9a4:	7108105f 	cmp	w2, #0x204
 9a8:	5400008d 	b.le	9b8 <main+0x3a8>
      printf("tftpclient: unexpected opcode or packet size\n");
 9ac:	90000000 	adrp	x0, 0 <.plt-0x510>
 9b0:	913cb400 	add	x0, x0, #0xf2d
 9b4:	14000091 	b	bf8 <main+0x5e8>
    uint16 block = get16(packet + 2);
 9b8:	79400660 	ldrh	w0, [x19, #2]
    if(block == expected_block){
 9bc:	b9406fe1 	ldr	w1, [sp, #108]
 9c0:	5ac00400 	rev16	w0, w0
 9c4:	12003c1b 	and	w27, w0, #0xffff
 9c8:	6b20203f 	cmp	w1, w0, uxth
 9cc:	54000621 	b.ne	a90 <main+0x480>  // b.any
      if(data_len > 0 && write(fd, packet + 4, data_len) != data_len){
 9d0:	71001059 	subs	w25, w2, #0x4
 9d4:	54000140 	b.eq	9fc <main+0x3ec>  // b.none
 9d8:	2a1903e2 	mov	w2, w25
 9dc:	91001261 	add	x1, x19, #0x4
 9e0:	2a1703e0 	mov	w0, w23
 9e4:	97fffedb 	bl	550 <write@plt>
 9e8:	6b00033f 	cmp	w25, w0
 9ec:	54000080 	b.eq	9fc <main+0x3ec>  // b.none
        printf("tftpclient: failed writing downloaded data\n");
 9f0:	90000000 	adrp	x0, 0 <.plt-0x510>
 9f4:	913d6c00 	add	x0, x0, #0xf5b
 9f8:	14000080 	b	bf8 <main+0x5e8>
      total += data_len;
 9fc:	0b1902d6 	add	w22, w22, w25
      if(total - last_progress >= TFTP_PROGRESS_BYTES){
 a00:	5287ffe0 	mov	w0, #0x3fff                	// #16383
 a04:	4b1c02c1 	sub	w1, w22, w28
 a08:	6b00003f 	cmp	w1, w0
 a0c:	540000ad 	b.le	a20 <main+0x410>
        print_progress(total, start_ticks);
 a10:	b9407be1 	ldr	w1, [sp, #120]
 a14:	2a1603e0 	mov	w0, w22
        last_progress = total;
 a18:	2a1603fc 	mov	w28, w22
        print_progress(total, start_ticks);
 a1c:	94000079 	bl	c00 <print_progress>
      if(send_ack(server, server_port, block) < 0){
 a20:	79411fe1 	ldrh	w1, [sp, #142]
 a24:	2a1b03e2 	mov	w2, w27
 a28:	2a1503e0 	mov	w0, w21
 a2c:	9400008e 	bl	c64 <send_ack>
 a30:	3100041f 	cmn	w0, #0x1
 a34:	540000c1 	b.ne	a4c <main+0x43c>  // b.any
        printf("tftpclient: failed sending ACK for block %d\n", block);
 a38:	2a1b03e1 	mov	w1, w27
 a3c:	90000000 	adrp	x0, 0 <.plt-0x510>
 a40:	913e1c00 	add	x0, x0, #0xf87
 a44:	97fffebb 	bl	530 <printf@plt>
  if(fd >= 0)
 a48:	17ffffcd 	b	97c <main+0x36c>
      if(data_len < TFTP_BLOCK_SIZE)
 a4c:	7108033f 	cmp	w25, #0x200
 a50:	540004c1 	b.ne	ae8 <main+0x4d8>  // b.any
      expected_block++;
 a54:	b9406fe0 	ldr	w0, [sp, #108]
      last_ack = block;
 a58:	2a1b03f9 	mov	w25, w27
      retries = 0;
 a5c:	5280001a 	mov	w26, #0x0                   	// #0
      expected_block++;
 a60:	11000400 	add	w0, w0, #0x1
 a64:	12003c00 	and	w0, w0, #0xffff
 a68:	b9006fe0 	str	w0, [sp, #108]
      packet_len = wait_packet(server, &server_port, LOCAL_PORT,
 a6c:	91023be1 	add	x1, sp, #0x8e
 a70:	2a1503e0 	mov	w0, w21
 a74:	9400008b 	bl	ca0 <wait_packet.constprop.0>
 a78:	2a0003e2 	mov	w2, w0
      if(packet_len < 0){
 a7c:	3100041f 	cmn	w0, #0x1
 a80:	540001a1 	b.ne	ab4 <main+0x4a4>  // b.any
        printf("tftpclient: UDP receive failed\n");
 a84:	90000000 	adrp	x0, 0 <.plt-0x510>
 a88:	913ed000 	add	x0, x0, #0xfb4
 a8c:	1400005b 	b	bf8 <main+0x5e8>
    } else if(block == last_ack){
 a90:	6b1b033f 	cmp	w25, w27
 a94:	54fffec1 	b.ne	a6c <main+0x45c>  // b.any
      if(send_ack(server, server_port, last_ack) < 0)
 a98:	79411fe1 	ldrh	w1, [sp, #142]
 a9c:	2a1903e2 	mov	w2, w25
 aa0:	2a1503e0 	mov	w0, w21
 aa4:	94000070 	bl	c64 <send_ack>
 aa8:	3100041f 	cmn	w0, #0x1
 aac:	54fffe01 	b.ne	a6c <main+0x45c>  // b.any
 ab0:	17ffffb3 	b	97c <main+0x36c>
      if(packet_len > 0)
 ab4:	350009a0 	cbnz	w0, be8 <main+0x5d8>
      if(++retries > TFTP_RETRIES){
 ab8:	1100075a 	add	w26, w26, #0x1
 abc:	7100175f 	cmp	w26, #0x5
 ac0:	5400008d 	b.le	ad0 <main+0x4c0>
        printf("tftpclient: transfer timed out\n");
 ac4:	90000000 	adrp	x0, 0 <.plt-0x510>
 ac8:	913f5000 	add	x0, x0, #0xfd4
 acc:	1400004b 	b	bf8 <main+0x5e8>
      printf("tftpclient: retrying block %d (%d/%d)\n",
 ad0:	f9403be0 	ldr	x0, [sp, #112]
 ad4:	2a1a03e2 	mov	w2, w26
 ad8:	2a1903e1 	mov	w1, w25
 adc:	528000a3 	mov	w3, #0x5                   	// #5
 ae0:	97fffe94 	bl	530 <printf@plt>
      if(send_ack(server, server_port, last_ack) < 0)
 ae4:	17ffffed 	b	a98 <main+0x488>
  if(close(fd) < 0){
 ae8:	2a1703e0 	mov	w0, w23
 aec:	97fffec5 	bl	600 <close@plt>
 af0:	36f800e0 	tbz	w0, #31, b0c <main+0x4fc>
    printf("tftpclient: close failed\n");
 af4:	b0000000 	adrp	x0, 1000 <wait_packet.constprop.0+0x360>
 af8:	91006c00 	add	x0, x0, #0x1b
 afc:	97fffe8d 	bl	530 <printf@plt>
    udp_unbind(LOCAL_PORT);
 b00:	52980000 	mov	w0, #0xc000                	// #49152
 b04:	97fffeab 	bl	5b0 <udp_unbind@plt>
    return -1;
 b08:	17ffff17 	b	764 <main+0x154>
  if(udp_unbind(LOCAL_PORT) < 0){
 b0c:	52980000 	mov	w0, #0xc000                	// #49152
 b10:	97fffea8 	bl	5b0 <udp_unbind@plt>
 b14:	36f80080 	tbz	w0, #31, b24 <main+0x514>
    printf("tftpclient: failed to release UDP port\n");
 b18:	b0000000 	adrp	x0, 1000 <wait_packet.constprop.0+0x360>
 b1c:	9100d400 	add	x0, x0, #0x35
 b20:	17ffff10 	b	760 <main+0x150>
  if(total != last_progress)
 b24:	6b1c02df 	cmp	w22, w28
 b28:	54000080 	b.eq	b38 <main+0x528>  // b.none
    print_progress(total, start_ticks);
 b2c:	b9407be1 	ldr	w1, [sp, #120]
 b30:	2a1603e0 	mov	w0, w22
 b34:	94000033 	bl	c00 <print_progress>
  int elapsed = uptime() - start_ticks;
 b38:	97fffe8a 	bl	560 <uptime@plt>
 b3c:	b9407be1 	ldr	w1, [sp, #120]
 b40:	4b010001 	sub	w1, w0, w1
  int rate_tenths = elapsed > 0 ? (total / 1024 * 100) / elapsed : 0;
 b44:	7100003f 	cmp	w1, #0x0
 b48:	5400026d 	b.le	b94 <main+0x584>
 b4c:	52808006 	mov	w6, #0x400                 	// #1024
 b50:	52800c80 	mov	w0, #0x64                  	// #100
 b54:	1ac60ec6 	sdiv	w6, w22, w6
 b58:	1b007cc6 	mul	w6, w6, w0
 b5c:	1ac10cc6 	sdiv	w6, w6, w1
  printf("\ntftpclient: downloaded %s (%d bytes in %d.%d s, avg %d.%d KB/s) to %s\n",
 b60:	52800144 	mov	w4, #0xa                   	// #10
 b64:	91081267 	add	x7, x19, #0x204
 b68:	2a1603e2 	mov	w2, w22
 b6c:	b0000000 	adrp	x0, 1000 <wait_packet.constprop.0+0x360>
 b70:	91017400 	add	x0, x0, #0x5d
 b74:	1ac40cc5 	sdiv	w5, w6, w4
 b78:	1ac40c23 	sdiv	w3, w1, w4
 b7c:	1b0498a6 	msub	w6, w5, w4, w6
 b80:	1b048464 	msub	w4, w3, w4, w1
 b84:	aa1403e1 	mov	x1, x20
 b88:	97fffe6a 	bl	530 <printf@plt>
  return 0;
 b8c:	52800000 	mov	w0, #0x0                   	// #0
 b90:	17fffef6 	b	768 <main+0x158>
  int rate_tenths = elapsed > 0 ? (total / 1024 * 100) / elapsed : 0;
 b94:	52800006 	mov	w6, #0x0                   	// #0
 b98:	17fffff2 	b	b60 <main+0x550>
    printf("tftpclient: existing %s was left unchanged\n", final_path);
 b9c:	b0000000 	adrp	x0, 1000 <wait_packet.constprop.0+0x360>
 ba0:	91035000 	add	x0, x0, #0xd4
 ba4:	17ffff55 	b	8f8 <main+0x2e8>
  fd = open(final_path, O_WRONLY | O_CREATE | O_TRUNC);
 ba8:	91081260 	add	x0, x19, #0x204
 bac:	5280c021 	mov	w1, #0x601                 	// #1537
 bb0:	b9007fe2 	str	w2, [sp, #124]
 bb4:	97fffe8b 	bl	5e0 <open@plt>
 bb8:	2a0003f7 	mov	w23, w0
  if(fd < 0){
 bbc:	37ffe8c0 	tbnz	w0, #31, 8d4 <main+0x2c4>
 bc0:	b9407fe2 	ldr	w2, [sp, #124]
  uint16 server_port = 0, expected_block = 1, last_ack = 0;
 bc4:	52800020 	mov	w0, #0x1                   	// #1
  int start_ticks, last_progress = 0;
 bc8:	5280001c 	mov	w28, #0x0                   	// #0
  int rrq_len, packet_len, fd = -1, total = 0, retries = 0, name_len;
 bcc:	5280001a 	mov	w26, #0x0                   	// #0
 bd0:	52800016 	mov	w22, #0x0                   	// #0
  uint16 server_port = 0, expected_block = 1, last_ack = 0;
 bd4:	52800019 	mov	w25, #0x0                   	// #0
 bd8:	b9006fe0 	str	w0, [sp, #108]
      printf("tftpclient: retrying block %d (%d/%d)\n",
 bdc:	90000000 	adrp	x0, 0 <.plt-0x510>
 be0:	913fd000 	add	x0, x0, #0xff4
 be4:	f9003be0 	str	x0, [sp, #112]
    if(packet_len < 2){
 be8:	7100045f 	cmp	w2, #0x1
 bec:	54ffe8c1 	b.ne	904 <main+0x2f4>  // b.any
      printf("tftpclient: malformed packet\n");
 bf0:	90000000 	adrp	x0, 0 <.plt-0x510>
 bf4:	913b7800 	add	x0, x0, #0xede
        printf("tftpclient: transfer timed out\n");
 bf8:	97fffe4e 	bl	530 <printf@plt>
  if(fd >= 0)
 bfc:	17ffff60 	b	97c <main+0x36c>

0000000000000c00 <print_progress>:
{
 c00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 c04:	910003fd 	mov	x29, sp
 c08:	a90153f3 	stp	x19, x20, [sp, #16]
 c0c:	2a0103f4 	mov	w20, w1
 c10:	2a0003f3 	mov	w19, w0
  int elapsed = uptime() - start_ticks;
 c14:	97fffe53 	bl	560 <uptime@plt>
 c18:	4b140000 	sub	w0, w0, w20
  int rate_tenths = elapsed > 0 ? (total / 1024 * 100) / elapsed : 0;
 c1c:	7100001f 	cmp	w0, #0x0
 c20:	540001ed 	b.le	c5c <print_progress+0x5c>
 c24:	52808001 	mov	w1, #0x400                 	// #1024
 c28:	52800c82 	mov	w2, #0x64                  	// #100
 c2c:	1ac10e61 	sdiv	w1, w19, w1
 c30:	1b027c21 	mul	w1, w1, w2
 c34:	1ac00c21 	sdiv	w1, w1, w0
    printf("\rtftpclient: %d bytes, %d.%d KB/s", total,
 c38:	52800143 	mov	w3, #0xa                   	// #10
 c3c:	90000000 	adrp	x0, 0 <.plt-0x510>
 c40:	9134a000 	add	x0, x0, #0xd28
 c44:	1ac30c22 	sdiv	w2, w1, w3
 c48:	1b038443 	msub	w3, w2, w3, w1
 c4c:	2a1303e1 	mov	w1, w19
}
 c50:	a94153f3 	ldp	x19, x20, [sp, #16]
 c54:	a8c27bfd 	ldp	x29, x30, [sp], #32
    printf("\rtftpclient: %d bytes, %d.%d KB/s", total,
 c58:	17fffe36 	b	530 <printf@plt>
  int rate_tenths = elapsed > 0 ? (total / 1024 * 100) / elapsed : 0;
 c5c:	52800001 	mov	w1, #0x0                   	// #0
 c60:	17fffff6 	b	c38 <print_progress+0x38>

0000000000000c64 <send_ack>:
{
 c64:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  p[0] = value >> 8;
 c68:	5ac00442 	rev16	w2, w2
 c6c:	52808003 	mov	w3, #0x400                 	// #1024
{
 c70:	910003fd 	mov	x29, sp
  return udp_send(server, LOCAL_PORT, server_port, packet, sizeof(packet)) == 4
 c74:	52800084 	mov	w4, #0x4                   	// #4
  p[0] = value >> 8;
 c78:	790033e3 	strh	w3, [sp, #24]
  return udp_send(server, LOCAL_PORT, server_port, packet, sizeof(packet)) == 4
 c7c:	910063e3 	add	x3, sp, #0x18
  p[0] = value >> 8;
 c80:	790037e2 	strh	w2, [sp, #26]
  return udp_send(server, LOCAL_PORT, server_port, packet, sizeof(packet)) == 4
 c84:	12003c22 	and	w2, w1, #0xffff
 c88:	52980001 	mov	w1, #0xc000                	// #49152
 c8c:	97fffe45 	bl	5a0 <udp_send@plt>
           ? 0 : -1;
 c90:	7100101f 	cmp	w0, #0x4
}
 c94:	5a9f03e0 	csetm	w0, ne	// ne = any
 c98:	a8c27bfd 	ldp	x29, x30, [sp], #32
 c9c:	d65f03c0 	ret

0000000000000ca0 <wait_packet.constprop.0>:
wait_packet(uint32 server, uint16 *server_port, int port,
 ca0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 ca4:	910003fd 	mov	x29, sp
 ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    int n = udp_recv_timeout(port, &source, &source_port, packet, capacity,
 cac:	d0000014 	adrp	x20, 2000 <wait_packet.constprop.0+0x1360>
 cb0:	910b8294 	add	x20, x20, #0x2e0
wait_packet(uint32 server, uint16 *server_port, int port,
 cb4:	aa0103f3 	mov	x19, x1
 cb8:	f90013f5 	str	x21, [sp, #32]
 cbc:	2a0003f5 	mov	w21, w0
    int n = udp_recv_timeout(port, &source, &source_port, packet, capacity,
 cc0:	aa1403e3 	mov	x3, x20
 cc4:	9100ebe2 	add	x2, sp, #0x3a
 cc8:	9100f3e1 	add	x1, sp, #0x3c
 ccc:	52800145 	mov	w5, #0xa                   	// #10
 cd0:	52804084 	mov	w4, #0x204                 	// #516
 cd4:	52980000 	mov	w0, #0xc000                	// #49152
 cd8:	97fffe2e 	bl	590 <udp_recv_timeout@plt>
    if(n < 0)
 cdc:	37f801c0 	tbnz	w0, #31, d14 <wait_packet.constprop.0+0x74>
    if(n == 0)
 ce0:	34000120 	cbz	w0, d04 <wait_packet.constprop.0+0x64>
      if(source != server)
 ce4:	b9403fe1 	ldr	w1, [sp, #60]
 ce8:	6b15003f 	cmp	w1, w21
 cec:	54fffea1 	b.ne	cc0 <wait_packet.constprop.0+0x20>  // b.any
      if(*server_port != 0 && source_port != *server_port)
 cf0:	79400261 	ldrh	w1, [x19]
 cf4:	34000141 	cbz	w1, d1c <wait_packet.constprop.0+0x7c>
 cf8:	794077e2 	ldrh	w2, [sp, #58]
 cfc:	6b01005f 	cmp	w2, w1
 d00:	54fffe01 	b.ne	cc0 <wait_packet.constprop.0+0x20>  // b.any
}
 d04:	f94013f5 	ldr	x21, [sp, #32]
 d08:	a94153f3 	ldp	x19, x20, [sp, #16]
 d0c:	a8c47bfd 	ldp	x29, x30, [sp], #64
 d10:	d65f03c0 	ret
      return -1;
 d14:	12800000 	mov	w0, #0xffffffff            	// #-1
 d18:	17fffffb 	b	d04 <wait_packet.constprop.0+0x64>
        *server_port = source_port;
 d1c:	794077e1 	ldrh	w1, [sp, #58]
 d20:	79000261 	strh	w1, [x19]
 d24:	17fffff8 	b	d04 <wait_packet.constprop.0+0x64>
