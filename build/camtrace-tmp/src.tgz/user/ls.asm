
user/_ls:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000004b8 <.plt>:
 4b8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 4bc:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 4c0:	f9451e11 	ldr	x17, [x16, #2616]
 4c4:	9128e210 	add	x16, x16, #0xa38
 4c8:	d61f0220 	br	x17
 4cc:	d503201f 	nop
 4d0:	d503201f 	nop
 4d4:	d503201f 	nop

00000000000004d8 <strcpy@plt>:
 4d8:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 4dc:	f9452211 	ldr	x17, [x16, #2624]
 4e0:	91290210 	add	x16, x16, #0xa40
 4e4:	d61f0220 	br	x17

00000000000004e8 <printf@plt>:
 4e8:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 4ec:	f9452611 	ldr	x17, [x16, #2632]
 4f0:	91292210 	add	x16, x16, #0xa48
 4f4:	d61f0220 	br	x17

00000000000004f8 <memmove@plt>:
 4f8:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 4fc:	f9452a11 	ldr	x17, [x16, #2640]
 500:	91294210 	add	x16, x16, #0xa50
 504:	d61f0220 	br	x17

0000000000000508 <readlink@plt>:
 508:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 50c:	f9452e11 	ldr	x17, [x16, #2648]
 510:	91296210 	add	x16, x16, #0xa58
 514:	d61f0220 	br	x17

0000000000000518 <fstat@plt>:
 518:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 51c:	f9453211 	ldr	x17, [x16, #2656]
 520:	91298210 	add	x16, x16, #0xa60
 524:	d61f0220 	br	x17

0000000000000528 <fprintf@plt>:
 528:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 52c:	f9453611 	ldr	x17, [x16, #2664]
 530:	9129a210 	add	x16, x16, #0xa68
 534:	d61f0220 	br	x17

0000000000000538 <read@plt>:
 538:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 53c:	f9453a11 	ldr	x17, [x16, #2672]
 540:	9129c210 	add	x16, x16, #0xa70
 544:	d61f0220 	br	x17

0000000000000548 <memset@plt>:
 548:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 54c:	f9453e11 	ldr	x17, [x16, #2680]
 550:	9129e210 	add	x16, x16, #0xa78
 554:	d61f0220 	br	x17

0000000000000558 <stat@plt>:
 558:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 55c:	f9454211 	ldr	x17, [x16, #2688]
 560:	912a0210 	add	x16, x16, #0xa80
 564:	d61f0220 	br	x17

0000000000000568 <exit@plt>:
 568:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 56c:	f9454611 	ldr	x17, [x16, #2696]
 570:	912a2210 	add	x16, x16, #0xa88
 574:	d61f0220 	br	x17

0000000000000578 <strlen@plt>:
 578:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 57c:	f9454a11 	ldr	x17, [x16, #2704]
 580:	912a4210 	add	x16, x16, #0xa90
 584:	d61f0220 	br	x17

0000000000000588 <open@plt>:
 588:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 58c:	f9454e11 	ldr	x17, [x16, #2712]
 590:	912a6210 	add	x16, x16, #0xa98
 594:	d61f0220 	br	x17

0000000000000598 <close@plt>:
 598:	b0000010 	adrp	x16, 1000 <ls+0x95c>
 59c:	f9455211 	ldr	x17, [x16, #2720]
 5a0:	912a8210 	add	x16, x16, #0xaa0
 5a4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000005a8 <main>:
  close(fd);
}

int
main(int argc, char *argv[])
{
 5a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 5ac:	910003fd 	mov	x29, sp
 5b0:	a90153f3 	stp	x19, x20, [sp, #16]
  int i;

  if(argc < 2){
 5b4:	7100041f 	cmp	w0, #0x1
 5b8:	540000cc 	b.gt	5d0 <main+0x28>
    ls(".");
 5bc:	90000000 	adrp	x0, 0 <.plt-0x4b8>
 5c0:	9123dc00 	add	x0, x0, #0x8f7
 5c4:	94000038 	bl	6a4 <ls>
    exit(0);
  }
  for(i=1; i<argc; i++)
    ls(argv[i]);
  exit(0);
 5c8:	52800000 	mov	w0, #0x0                   	// #0
 5cc:	97ffffe7 	bl	568 <exit@plt>
 5d0:	2a0003f4 	mov	w20, w0
  if(argc < 2){
 5d4:	d2800033 	mov	x19, #0x1                   	// #1
    ls(argv[i]);
 5d8:	f8737820 	ldr	x0, [x1, x19, lsl #3]
  for(i=1; i<argc; i++)
 5dc:	91000673 	add	x19, x19, #0x1
    ls(argv[i]);
 5e0:	f90017e1 	str	x1, [sp, #40]
 5e4:	94000030 	bl	6a4 <ls>
  for(i=1; i<argc; i++)
 5e8:	f94017e1 	ldr	x1, [sp, #40]
 5ec:	6b13029f 	cmp	w20, w19
 5f0:	54ffff4c 	b.gt	5d8 <main+0x30>
 5f4:	17fffff5 	b	5c8 <main+0x20>

00000000000005f8 <fmtname>:
{
 5f8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 5fc:	910003fd 	mov	x29, sp
 600:	a90153f3 	stp	x19, x20, [sp, #16]
 604:	aa0003f4 	mov	x20, x0
 608:	f90013f5 	str	x21, [sp, #32]
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
 60c:	97ffffdb 	bl	578 <strlen@plt>
 610:	8b204293 	add	x19, x20, w0, uxtw
 614:	eb14027f 	cmp	x19, x20
 618:	540003c2 	b.cs	690 <fmtname+0x98>  // b.hs, b.nlast
  p++;
 61c:	91000673 	add	x19, x19, #0x1
  if(strlen(p) >= DIRSIZ)
 620:	aa1303e0 	mov	x0, x19
 624:	97ffffd5 	bl	578 <strlen@plt>
 628:	7100741f 	cmp	w0, #0x1d
 62c:	54000288 	b.hi	67c <fmtname+0x84>  // b.pmore
  memmove(buf, p, strlen(p));
 630:	aa1303e0 	mov	x0, x19
 634:	97ffffd1 	bl	578 <strlen@plt>
 638:	aa1303e1 	mov	x1, x19
 63c:	2a0003e2 	mov	w2, w0
 640:	b0000014 	adrp	x20, 1000 <ls+0x95c>
 644:	912aa294 	add	x20, x20, #0xaa8
 648:	aa1403e0 	mov	x0, x20
 64c:	97ffffab 	bl	4f8 <memmove@plt>
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
 650:	aa1303e0 	mov	x0, x19
 654:	97ffffc9 	bl	578 <strlen@plt>
 658:	2a0003f5 	mov	w21, w0
 65c:	aa1303e0 	mov	x0, x19
  return buf;
 660:	aa1403f3 	mov	x19, x20
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
 664:	97ffffc5 	bl	578 <strlen@plt>
 668:	528003c2 	mov	w2, #0x1e                  	// #30
 66c:	52800401 	mov	w1, #0x20                  	// #32
 670:	4b000042 	sub	w2, w2, w0
 674:	8b354280 	add	x0, x20, w21, uxtw
 678:	97ffffb4 	bl	548 <memset@plt>
}
 67c:	f94013f5 	ldr	x21, [sp, #32]
 680:	aa1303e0 	mov	x0, x19
 684:	a94153f3 	ldp	x19, x20, [sp, #16]
 688:	a8c37bfd 	ldp	x29, x30, [sp], #48
 68c:	d65f03c0 	ret
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
 690:	39400260 	ldrb	w0, [x19]
 694:	7100bc1f 	cmp	w0, #0x2f
 698:	54fffc20 	b.eq	61c <fmtname+0x24>  // b.none
 69c:	d1000673 	sub	x19, x19, #0x1
 6a0:	17ffffdd 	b	614 <fmtname+0x1c>

00000000000006a4 <ls>:
{
 6a4:	d10e43ff 	sub	sp, sp, #0x390
  if((fd = open(path, 0)) < 0){
 6a8:	52800001 	mov	w1, #0x0                   	// #0
{
 6ac:	a9007bfd 	stp	x29, x30, [sp]
 6b0:	910003fd 	mov	x29, sp
 6b4:	a90153f3 	stp	x19, x20, [sp, #16]
 6b8:	aa0003f4 	mov	x20, x0
 6bc:	a9025bf5 	stp	x21, x22, [sp, #32]
 6c0:	a90363f7 	stp	x23, x24, [sp, #48]
 6c4:	f90023f9 	str	x25, [sp, #64]
  if((fd = open(path, 0)) < 0){
 6c8:	97ffffb0 	bl	588 <open@plt>
 6cc:	36f80180 	tbz	w0, #31, 6fc <ls+0x58>
}
 6d0:	a9407bfd 	ldp	x29, x30, [sp]
    fprintf(2, "ls: cannot open %s\n", path);
 6d4:	aa1403e2 	mov	x2, x20
}
 6d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    fprintf(2, "ls: cannot open %s\n", path);
 6dc:	90000001 	adrp	x1, 0 <.plt-0x4b8>
 6e0:	91226021 	add	x1, x1, #0x898
 6e4:	52800040 	mov	w0, #0x2                   	// #2
}
 6e8:	a94153f3 	ldp	x19, x20, [sp, #16]
 6ec:	a94363f7 	ldp	x23, x24, [sp, #48]
 6f0:	f94023f9 	ldr	x25, [sp, #64]
 6f4:	910e43ff 	add	sp, sp, #0x390
    fprintf(2, "ls: cannot open %s\n", path);
 6f8:	17ffff8c 	b	528 <fprintf@plt>
 6fc:	2a0003f5 	mov	w21, w0
  if(fstat(fd, &st) < 0){
 700:	910163e1 	add	x1, sp, #0x58
 704:	97ffff85 	bl	518 <fstat@plt>
 708:	36f801e0 	tbz	w0, #31, 744 <ls+0xa0>
    fprintf(2, "ls: cannot stat %s\n", path);
 70c:	90000001 	adrp	x1, 0 <.plt-0x4b8>
 710:	9122b021 	add	x1, x1, #0x8ac
 714:	aa1403e2 	mov	x2, x20
 718:	52800040 	mov	w0, #0x2                   	// #2
 71c:	97ffff83 	bl	528 <fprintf@plt>
  close(fd);
 720:	2a1503e0 	mov	w0, w21
 724:	97ffff9d 	bl	598 <close@plt>
}
 728:	f94023f9 	ldr	x25, [sp, #64]
 72c:	a9407bfd 	ldp	x29, x30, [sp]
 730:	a94153f3 	ldp	x19, x20, [sp, #16]
 734:	a9425bf5 	ldp	x21, x22, [sp, #32]
 738:	a94363f7 	ldp	x23, x24, [sp, #48]
 73c:	910e43ff 	add	sp, sp, #0x390
 740:	d65f03c0 	ret
  switch(st.type){
 744:	79c0c3e0 	ldrsh	w0, [sp, #96]
 748:	7100041f 	cmp	w0, #0x1
 74c:	540001e0 	b.eq	788 <ls+0xe4>  // b.none
 750:	51000800 	sub	w0, w0, #0x2
 754:	12003c00 	and	w0, w0, #0xffff
 758:	7100041f 	cmp	w0, #0x1
 75c:	54fffe28 	b.hi	720 <ls+0x7c>  // b.pmore
    printf("%s %d %d %l\n", fmtname(path), st.type, st.ino, st.size);
 760:	aa1403e0 	mov	x0, x20
 764:	97ffffa5 	bl	5f8 <fmtname>
 768:	f94037e4 	ldr	x4, [sp, #104]
 76c:	aa0003e1 	mov	x1, x0
 770:	79c0c3e2 	ldrsh	w2, [sp, #96]
 774:	90000000 	adrp	x0, 0 <.plt-0x4b8>
 778:	91230000 	add	x0, x0, #0x8c0
 77c:	b9405fe3 	ldr	w3, [sp, #92]
 780:	97ffff5a 	bl	4e8 <printf@plt>
    break;
 784:	17ffffe7 	b	720 <ls+0x7c>
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 788:	aa1403e0 	mov	x0, x20
 78c:	97ffff7b 	bl	578 <strlen@plt>
 790:	11008000 	add	w0, w0, #0x20
 794:	7108001f 	cmp	w0, #0x200
 798:	540000a9 	b.ls	7ac <ls+0x108>  // b.plast
      printf("ls: path too long\n");
 79c:	90000000 	adrp	x0, 0 <.plt-0x4b8>
 7a0:	91233400 	add	x0, x0, #0x8cd
 7a4:	97ffff51 	bl	4e8 <printf@plt>
      break;
 7a8:	17ffffde 	b	720 <ls+0x7c>
    strcpy(buf, path);
 7ac:	aa1403e1 	mov	x1, x20
 7b0:	910643f3 	add	x19, sp, #0x190
 7b4:	aa1303e0 	mov	x0, x19
 7b8:	97ffff48 	bl	4d8 <strcpy@plt>
    p = buf+strlen(buf);
 7bc:	aa1303e0 	mov	x0, x19
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);
 7c0:	90000014 	adrp	x20, 0 <.plt-0x4b8>
 7c4:	9123aa94 	add	x20, x20, #0x8ea
    p = buf+strlen(buf);
 7c8:	97ffff6c 	bl	578 <strlen@plt>
        printf("%s -> %s\n", fmtname(buf), target);
 7cc:	90000016 	adrp	x22, 0 <.plt-0x4b8>
 7d0:	912382d6 	add	x22, x22, #0x8e0
    p = buf+strlen(buf);
 7d4:	8b204278 	add	x24, x19, w0, uxtw
    *p++ = '/';
 7d8:	528005e1 	mov	w1, #0x2f                  	// #47
 7dc:	38204a61 	strb	w1, [x19, w0, uxtw]
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 7e0:	9101c3e1 	add	x1, sp, #0x70
 7e4:	2a1503e0 	mov	w0, w21
 7e8:	52800402 	mov	w2, #0x20                  	// #32
 7ec:	97ffff53 	bl	538 <read@plt>
 7f0:	7100801f 	cmp	w0, #0x20
 7f4:	54fff961 	b.ne	720 <ls+0x7c>  // b.any
      if(de.inum == 0)
 7f8:	7940e3e0 	ldrh	w0, [sp, #112]
 7fc:	34ffff20 	cbz	w0, 7e0 <ls+0x13c>
      memmove(p, de.name, DIRSIZ);
 800:	9101cbe1 	add	x1, sp, #0x72
 804:	528003c2 	mov	w2, #0x1e                  	// #30
 808:	91000700 	add	x0, x24, #0x1
 80c:	97ffff3b 	bl	4f8 <memmove@plt>
      p[DIRSIZ] = 0;
 810:	39007f1f 	strb	wzr, [x24, #31]
      if((rl = readlink(buf, target, sizeof(target) - 1)) > 0){
 814:	910243f7 	add	x23, sp, #0x90
 818:	aa1703e1 	mov	x1, x23
 81c:	aa1303e0 	mov	x0, x19
 820:	52801fe2 	mov	w2, #0xff                  	// #255
 824:	97ffff39 	bl	508 <readlink@plt>
 828:	7100001f 	cmp	w0, #0x0
 82c:	5400012d 	b.le	850 <ls+0x1ac>
        target[rl] = 0;
 830:	38204aff 	strb	wzr, [x23, w0, uxtw]
        printf("%s -> %s\n", fmtname(buf), target);
 834:	aa1303e0 	mov	x0, x19
 838:	97ffff70 	bl	5f8 <fmtname>
 83c:	aa0003e1 	mov	x1, x0
 840:	aa1703e2 	mov	x2, x23
 844:	aa1603e0 	mov	x0, x22
 848:	97ffff28 	bl	4e8 <printf@plt>
        continue;
 84c:	17ffffe5 	b	7e0 <ls+0x13c>
      if(stat(buf, &st) < 0){
 850:	910163e1 	add	x1, sp, #0x58
 854:	aa1303e0 	mov	x0, x19
 858:	97ffff40 	bl	558 <stat@plt>
 85c:	36f800c0 	tbz	w0, #31, 874 <ls+0x1d0>
        printf("ls: cannot stat %s\n", buf);
 860:	aa1303e1 	mov	x1, x19
 864:	90000000 	adrp	x0, 0 <.plt-0x4b8>
 868:	9122b000 	add	x0, x0, #0x8ac
 86c:	97ffff1f 	bl	4e8 <printf@plt>
        continue;
 870:	17ffffdc 	b	7e0 <ls+0x13c>
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);
 874:	aa1303e0 	mov	x0, x19
 878:	97ffff60 	bl	5f8 <fmtname>
 87c:	f94037e4 	ldr	x4, [sp, #104]
 880:	aa0003e1 	mov	x1, x0
 884:	79c0c3e2 	ldrsh	w2, [sp, #96]
 888:	aa1403e0 	mov	x0, x20
 88c:	b9405fe3 	ldr	w3, [sp, #92]
 890:	97ffff16 	bl	4e8 <printf@plt>
 894:	17ffffd3 	b	7e0 <ls+0x13c>
