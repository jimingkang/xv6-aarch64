
user/_file:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002b0 <.plt>:
 2b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2b4:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2b8:	f942ce11 	ldr	x17, [x16, #1432]
 2bc:	91166210 	add	x16, x16, #0x598
 2c0:	d61f0220 	br	x17
 2c4:	d503201f 	nop
 2c8:	d503201f 	nop
 2cc:	d503201f 	nop

00000000000002d0 <printf@plt>:
 2d0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2d4:	f942d211 	ldr	x17, [x16, #1440]
 2d8:	91168210 	add	x16, x16, #0x5a0
 2dc:	d61f0220 	br	x17

00000000000002e0 <fprintf@plt>:
 2e0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2e4:	f942d611 	ldr	x17, [x16, #1448]
 2e8:	9116a210 	add	x16, x16, #0x5a8
 2ec:	d61f0220 	br	x17

00000000000002f0 <stat@plt>:
 2f0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2f4:	f942da11 	ldr	x17, [x16, #1456]
 2f8:	9116c210 	add	x16, x16, #0x5b0
 2fc:	d61f0220 	br	x17

0000000000000300 <exit@plt>:
 300:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 304:	f942de11 	ldr	x17, [x16, #1464]
 308:	9116e210 	add	x16, x16, #0x5b8
 30c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000310 <main>:
  return "unknown";
}

int
main(int argc, char **argv)
{
 310:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 314:	910003fd 	mov	x29, sp
 318:	a90153f3 	stp	x19, x20, [sp, #16]
 31c:	a9025bf5 	stp	x21, x22, [sp, #32]
 320:	f9001bf7 	str	x23, [sp, #48]
  if(argc < 2){
 324:	7100041f 	cmp	w0, #0x1
 328:	540000ec 	b.gt	344 <main+0x34>
    fprintf(2, "usage: file path...\n");
 32c:	90000001 	adrp	x1, 0 <.plt-0x2b0>
 330:	91105821 	add	x1, x1, #0x416
 334:	52800040 	mov	w0, #0x2                   	// #2
 338:	97ffffea 	bl	2e0 <fprintf@plt>
    exit(1);
 33c:	52800020 	mov	w0, #0x1                   	// #1
      continue;
    }
    printf("%s: %s, inode %d, %d bytes\n",
           argv[i], typename(st.type), st.ino, st.size);
  }
  exit(0);
 340:	97fffff0 	bl	300 <exit@plt>
    printf("%s: %s, inode %d, %d bytes\n",
 344:	90000014 	adrp	x20, 0 <.plt-0x2b0>
 348:	91110694 	add	x20, x20, #0x441
 34c:	2a0003f5 	mov	w21, w0
 350:	aa0103f6 	mov	x22, x1
  if(argc < 2){
 354:	d2800033 	mov	x19, #0x1                   	// #1
  if(type == T_DIR) return "directory";
 358:	90000017 	adrp	x23, 0 <.plt-0x2b0>
    if(stat(argv[i], &st) < 0){
 35c:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
 360:	910123e1 	add	x1, sp, #0x48
 364:	97ffffe3 	bl	2f0 <stat@plt>
      fprintf(2, "file: cannot stat %s\n", argv[i]);
 368:	f8737ac5 	ldr	x5, [x22, x19, lsl #3]
    if(stat(argv[i], &st) < 0){
 36c:	36f80160 	tbz	w0, #31, 398 <main+0x88>
      fprintf(2, "file: cannot stat %s\n", argv[i]);
 370:	90000001 	adrp	x1, 0 <.plt-0x2b0>
 374:	9110ac21 	add	x1, x1, #0x42b
 378:	aa0503e2 	mov	x2, x5
 37c:	52800040 	mov	w0, #0x2                   	// #2
 380:	97ffffd8 	bl	2e0 <fprintf@plt>
  for(int i = 1; i < argc; i++){
 384:	91000673 	add	x19, x19, #0x1
 388:	6b1302bf 	cmp	w21, w19
 38c:	54fffe8c 	b.gt	35c <main+0x4c>
  exit(0);
 390:	52800000 	mov	w0, #0x0                   	// #0
 394:	17ffffeb 	b	340 <main+0x30>
    printf("%s: %s, inode %d, %d bytes\n",
 398:	79c0a3e1 	ldrsh	w1, [sp, #80]
  if(type == T_DIR) return "directory";
 39c:	7100043f 	cmp	w1, #0x1
 3a0:	540001e0 	b.eq	3dc <main+0xcc>  // b.none
  if(type == T_FILE) return "regular file";
 3a4:	7100083f 	cmp	w1, #0x2
 3a8:	540001e0 	b.eq	3e4 <main+0xd4>  // b.none
  return "unknown";
 3ac:	71000c3f 	cmp	w1, #0x3
 3b0:	90000000 	adrp	x0, 0 <.plt-0x2b0>
 3b4:	91101c00 	add	x0, x0, #0x407
 3b8:	90000002 	adrp	x2, 0 <.plt-0x2b0>
 3bc:	91103c42 	add	x2, x2, #0x40f
 3c0:	9a800042 	csel	x2, x2, x0, eq	// eq = none
    printf("%s: %s, inode %d, %d bytes\n",
 3c4:	f9402fe4 	ldr	x4, [sp, #88]
 3c8:	aa0503e1 	mov	x1, x5
 3cc:	b9404fe3 	ldr	w3, [sp, #76]
 3d0:	aa1403e0 	mov	x0, x20
 3d4:	97ffffbf 	bl	2d0 <printf@plt>
 3d8:	17ffffeb 	b	384 <main+0x74>
  if(type == T_DIR) return "directory";
 3dc:	910fc2e2 	add	x2, x23, #0x3f0
 3e0:	17fffff9 	b	3c4 <main+0xb4>
  if(type == T_FILE) return "regular file";
 3e4:	90000002 	adrp	x2, 0 <.plt-0x2b0>
 3e8:	910fe842 	add	x2, x2, #0x3fa
 3ec:	17fffff6 	b	3c4 <main+0xb4>
