
user/_pcsched:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000480 <.plt>:
 480:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 484:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 488:	f9410611 	ldr	x17, [x16, #520]
 48c:	91082210 	add	x16, x16, #0x208
 490:	d61f0220 	br	x17
 494:	d503201f 	nop
 498:	d503201f 	nop
 49c:	d503201f 	nop

00000000000004a0 <printf@plt>:
 4a0:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 4a4:	f9410a11 	ldr	x17, [x16, #528]
 4a8:	91084210 	add	x16, x16, #0x210
 4ac:	d61f0220 	br	x17

00000000000004b0 <getpid@plt>:
 4b0:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 4b4:	f9410e11 	ldr	x17, [x16, #536]
 4b8:	91086210 	add	x16, x16, #0x218
 4bc:	d61f0220 	br	x17

00000000000004c0 <pipe@plt>:
 4c0:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 4c4:	f9411211 	ldr	x17, [x16, #544]
 4c8:	91088210 	add	x16, x16, #0x220
 4cc:	d61f0220 	br	x17

00000000000004d0 <write@plt>:
 4d0:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 4d4:	f9411611 	ldr	x17, [x16, #552]
 4d8:	9108a210 	add	x16, x16, #0x228
 4dc:	d61f0220 	br	x17

00000000000004e0 <fprintf@plt>:
 4e0:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 4e4:	f9411a11 	ldr	x17, [x16, #560]
 4e8:	9108c210 	add	x16, x16, #0x230
 4ec:	d61f0220 	br	x17

00000000000004f0 <wait@plt>:
 4f0:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 4f4:	f9411e11 	ldr	x17, [x16, #568]
 4f8:	9108e210 	add	x16, x16, #0x238
 4fc:	d61f0220 	br	x17

0000000000000500 <read@plt>:
 500:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 504:	f9412211 	ldr	x17, [x16, #576]
 508:	91090210 	add	x16, x16, #0x240
 50c:	d61f0220 	br	x17

0000000000000510 <fork@plt>:
 510:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 514:	f9412611 	ldr	x17, [x16, #584]
 518:	91092210 	add	x16, x16, #0x248
 51c:	d61f0220 	br	x17

0000000000000520 <getcpu@plt>:
 520:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 524:	f9412a11 	ldr	x17, [x16, #592]
 528:	91094210 	add	x16, x16, #0x250
 52c:	d61f0220 	br	x17

0000000000000530 <clock_us@plt>:
 530:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 534:	f9412e11 	ldr	x17, [x16, #600]
 538:	91096210 	add	x16, x16, #0x258
 53c:	d61f0220 	br	x17

0000000000000540 <exit@plt>:
 540:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 544:	f9413211 	ldr	x17, [x16, #608]
 548:	91098210 	add	x16, x16, #0x260
 54c:	d61f0220 	br	x17

0000000000000550 <close@plt>:
 550:	d0000010 	adrp	x16, 2000 <rec+0x1218>
 554:	f9413611 	ldr	x17, [x16, #616]
 558:	9109a210 	add	x16, x16, #0x268
 55c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000560 <main>:
  put_u(l, v, 1);
}

int
main(int argc, char *argv[])
{
 560:	a9ac7bfd 	stp	x29, x30, [sp, #-320]!
 564:	2a0003e7 	mov	w7, w0
  int items = 8, cons_ms = 30, prod_ms = 0, data[2], back[2], pid;
 568:	52800100 	mov	w0, #0x8                   	// #8
{
 56c:	910003fd 	mov	x29, sp
 570:	a90153f3 	stp	x19, x20, [sp, #16]
 574:	a9025bf5 	stp	x21, x22, [sp, #32]
 578:	a90363f7 	stp	x23, x24, [sp, #48]
 57c:	a9046bf9 	stp	x25, x26, [sp, #64]
 580:	a90573fb 	stp	x27, x28, [sp, #80]
  int items = 8, cons_ms = 30, prod_ms = 0, data[2], back[2], pid;
 584:	b90067e0 	str	w0, [sp, #100]
 588:	528003c0 	mov	w0, #0x1e                  	// #30
 58c:	b9006be0 	str	w0, [sp, #104]
 590:	b9006fff 	str	wzr, [sp, #108]
  static struct ev cev[MAXEV];
  int ncev = 0;

  if(argc > 4 || (argc > 1 && !parse_num(argv[1], &items)) ||
 594:	710010ff 	cmp	w7, #0x4
 598:	5400030c 	b.gt	5f8 <main+0x98>
 59c:	710004ff 	cmp	w7, #0x1
 5a0:	5400024d 	b.le	5e8 <main+0x88>
 5a4:	aa0103e8 	mov	x8, x1
 5a8:	910193e1 	add	x1, sp, #0x64
 5ac:	f9400500 	ldr	x0, [x8, #8]
 5b0:	94000196 	bl	c08 <parse_num>
 5b4:	34000220 	cbz	w0, 5f8 <main+0x98>
 5b8:	710008ff 	cmp	w7, #0x2
 5bc:	54000160 	b.eq	5e8 <main+0x88>  // b.none
     (argc > 2 && !parse_num(argv[2], &cons_ms)) ||
 5c0:	f9400900 	ldr	x0, [x8, #16]
 5c4:	9101a3e1 	add	x1, sp, #0x68
 5c8:	94000190 	bl	c08 <parse_num>
 5cc:	34000160 	cbz	w0, 5f8 <main+0x98>
 5d0:	710010ff 	cmp	w7, #0x4
 5d4:	540000a1 	b.ne	5e8 <main+0x88>  // b.any
     (argc > 3 && !parse_num(argv[3], &prod_ms)) || items < 1 || items > 20){
 5d8:	f9400d00 	ldr	x0, [x8, #24]
 5dc:	9101b3e1 	add	x1, sp, #0x6c
 5e0:	9400018a 	bl	c08 <parse_num>
 5e4:	340000a0 	cbz	w0, 5f8 <main+0x98>
 5e8:	b94067f9 	ldr	w25, [sp, #100]
 5ec:	51000720 	sub	w0, w25, #0x1
 5f0:	71004c1f 	cmp	w0, #0x13
 5f4:	540000e9 	b.ls	610 <main+0xb0>  // b.plast
    fprintf(2, "usage: pcsched [ITEMS 1..20] [CONSUMER_MS] [PRODUCER_MS]\n");
 5f8:	90000001 	adrp	x1, 0 <.plt-0x480>
 5fc:	913ba421 	add	x1, x1, #0xee9
    exit(1);
  }
  if(pipe(data) < 0 || pipe(back) < 0){
    fprintf(2, "pcsched: pipe failed\n");
 600:	52800040 	mov	w0, #0x2                   	// #2
 604:	97ffffb7 	bl	4e0 <fprintf@plt>
    exit(1);
 608:	52800020 	mov	w0, #0x1                   	// #1
 60c:	97ffffcd 	bl	540 <exit@plt>
  if(pipe(data) < 0 || pipe(back) < 0){
 610:	9101c3e0 	add	x0, sp, #0x70
 614:	97ffffab 	bl	4c0 <pipe@plt>
 618:	37f80080 	tbnz	w0, #31, 628 <main+0xc8>
 61c:	9101e3e0 	add	x0, sp, #0x78
 620:	97ffffa8 	bl	4c0 <pipe@plt>
 624:	36f80080 	tbz	w0, #31, 634 <main+0xd4>
    fprintf(2, "pcsched: pipe failed\n");
 628:	90000001 	adrp	x1, 0 <.plt-0x480>
 62c:	913c8c21 	add	x1, x1, #0xf23
 630:	17fffff4 	b	600 <main+0xa0>
  }
  printf("pcsched: %d items x %d bytes, pipe holds %d; consumer works %d ms,"
 634:	294d6bf7 	ldp	w23, w26, [sp, #104]
 638:	2a1903e1 	mov	w1, w25
 63c:	52800083 	mov	w3, #0x4                   	// #4
 640:	52801002 	mov	w2, #0x80                  	// #128
 644:	2a1a03e5 	mov	w5, w26
 648:	2a1703e4 	mov	w4, w23
         " producer %d ms per item\n", items, ITEM_SIZE, SLOTS, cons_ms, prod_ms);
  t0 = clock_us();
 64c:	d0000016 	adrp	x22, 2000 <rec+0x1218>
 650:	9109c2d4 	add	x20, x22, #0x270
  printf("pcsched: %d items x %d bytes, pipe holds %d; consumer works %d ms,"
 654:	90000000 	adrp	x0, 0 <.plt-0x480>
 658:	913ce400 	add	x0, x0, #0xf39
 65c:	97ffff91 	bl	4a0 <printf@plt>
  t0 = clock_us();
 660:	97ffffb4 	bl	530 <clock_us@plt>
 664:	f9010680 	str	x0, [x20, #520]

  pid = fork();
 668:	97ffffaa 	bl	510 <fork@plt>
 66c:	2a0003f8 	mov	w24, w0
  if(pid < 0){
 670:	36f80080 	tbz	w0, #31, 680 <main+0x120>
    fprintf(2, "pcsched: fork failed\n");
 674:	90000001 	adrp	x1, 0 <.plt-0x480>
 678:	913e5421 	add	x1, x1, #0xf95
 67c:	17ffffe1 	b	600 <main+0xa0>
    exit(1);
  }
  if(pid == 0){                        // child = consumer
 680:	910263f3 	add	x19, sp, #0x98
 684:	35000680 	cbnz	w0, 754 <main+0x1f4>
    close(data[1]); close(back[0]);
 688:	b94077e0 	ldr	w0, [sp, #116]
    while(got < ITEM_SIZE && (n = read(rfd, item + got, ITEM_SIZE - got)) > 0)
 68c:	5280101a 	mov	w26, #0x80                  	// #128
    close(data[1]); close(back[0]);
 690:	97ffffb0 	bl	550 <close@plt>
 694:	b9407be0 	ldr	w0, [sp, #120]
 698:	97ffffae 	bl	550 <close@plt>
    consumer(data[0], cons_ms);
 69c:	b94073f9 	ldr	w25, [sp, #112]
  rec('C', E_START, 0);
 6a0:	52800002 	mov	w2, #0x0                   	// #0
 6a4:	52800021 	mov	w1, #0x1                   	// #1
 6a8:	52800860 	mov	w0, #0x43                  	// #67
 6ac:	940001cf 	bl	de8 <rec>
    int got = 0, n;
 6b0:	2a1803f5 	mov	w21, w24
    rec('C', E_GET_BEGIN, 0);
 6b4:	52800002 	mov	w2, #0x0                   	// #0
 6b8:	52800081 	mov	w1, #0x4                   	// #4
 6bc:	52800860 	mov	w0, #0x43                  	// #67
 6c0:	940001ca 	bl	de8 <rec>
    while(got < ITEM_SIZE && (n = read(rfd, item + got, ITEM_SIZE - got)) > 0)
 6c4:	4b150342 	sub	w2, w26, w21
 6c8:	8b35c261 	add	x1, x19, w21, sxtw
 6cc:	2a1903e0 	mov	w0, w25
 6d0:	97ffff8c 	bl	500 <read@plt>
 6d4:	7100001f 	cmp	w0, #0x0
 6d8:	5400020c 	b.gt	718 <main+0x1b8>
      rec('C', E_EOF, 0);
 6dc:	52800002 	mov	w2, #0x0                   	// #0
 6e0:	528000c1 	mov	w1, #0x6                   	// #6
 6e4:	52800860 	mov	w0, #0x43                  	// #67
 6e8:	940001c0 	bl	de8 <rec>
    rec('C', E_DONE, 0);
 6ec:	52800002 	mov	w2, #0x0                   	// #0
 6f0:	52800101 	mov	w1, #0x8                   	// #8
 6f4:	52800860 	mov	w0, #0x43                  	// #67
 6f8:	940001bc 	bl	de8 <rec>
    write(back[1], evs, nev * sizeof(struct ev));
 6fc:	b9407fe0 	ldr	w0, [sp, #124]
 700:	91001281 	add	x1, x20, #0x4
 704:	b94272c2 	ldr	w2, [x22, #624]
 708:	531d7042 	lsl	w2, w2, #3
 70c:	97ffff71 	bl	4d0 <write@plt>
    lastcpu[w] = e->cpu;
    l.b[l.n++] = '\n';
    write(1, l.b, l.n);
  }
  printf("pcsched: done\n");
  exit(0);
 710:	52800000 	mov	w0, #0x0                   	// #0
 714:	17ffffbe 	b	60c <main+0xac>
      got += n;
 718:	0b0002b5 	add	w21, w21, w0
    while(got < ITEM_SIZE && (n = read(rfd, item + got, ITEM_SIZE - got)) > 0)
 71c:	7101febf 	cmp	w21, #0x7f
 720:	54fffd2d 	b.le	6c4 <main+0x164>
    rec('C', E_GET_END, (uchar)item[0]);
 724:	394263e2 	ldrb	w2, [sp, #152]
 728:	528000a1 	mov	w1, #0x5                   	// #5
 72c:	52800860 	mov	w0, #0x43                  	// #67
 730:	940001ae 	bl	de8 <rec>
    if(work_ms){
 734:	34fffbf7 	cbz	w23, 6b0 <main+0x150>
      busy_ms(work_ms);
 738:	2a1703e0 	mov	w0, w23
 73c:	9400019e 	bl	db4 <busy_ms>
      rec('C', E_WORK_END, (uchar)item[0]);
 740:	394263e2 	ldrb	w2, [sp, #152]
 744:	528000e1 	mov	w1, #0x7                   	// #7
 748:	52800860 	mov	w0, #0x43                  	// #67
 74c:	940001a7 	bl	de8 <rec>
 750:	17ffffd8 	b	6b0 <main+0x150>
  close(data[0]); close(back[1]);      // parent = producer
 754:	b94073e0 	ldr	w0, [sp, #112]
  for(int i = 1; i <= items; i++){
 758:	52800035 	mov	w21, #0x1                   	// #1
  close(data[0]); close(back[1]);      // parent = producer
 75c:	97ffff7d 	bl	550 <close@plt>
 760:	b9407fe0 	ldr	w0, [sp, #124]
 764:	97ffff7b 	bl	550 <close@plt>
  int ppid = getpid();
 768:	97ffff52 	bl	4b0 <getpid@plt>
  producer(data[1], items, prod_ms);
 76c:	b94077fc 	ldr	w28, [sp, #116]
  int ppid = getpid();
 770:	2a0003fb 	mov	w27, w0
  rec('P', E_START, 0);
 774:	52800002 	mov	w2, #0x0                   	// #0
 778:	52800021 	mov	w1, #0x1                   	// #1
 77c:	52800a00 	mov	w0, #0x50                  	// #80
 780:	9400019a 	bl	de8 <rec>
    if(work_ms) busy_ms(work_ms);
 784:	3400007a 	cbz	w26, 790 <main+0x230>
 788:	2a1a03e0 	mov	w0, w26
 78c:	9400018a 	bl	db4 <busy_ms>
    for(int k = 0; k < ITEM_SIZE; k++) item[k] = (char)i;
 790:	2a1503e0 	mov	w0, w21
  for(int i = 1; i <= items; i++){
 794:	d2800016 	mov	x22, #0x0                   	// #0
    for(int k = 0; k < ITEM_SIZE; k++) item[k] = (char)i;
 798:	38366a60 	strb	w0, [x19, x22]
 79c:	910006d6 	add	x22, x22, #0x1
 7a0:	f10202df 	cmp	x22, #0x80
 7a4:	54ffffa1 	b.ne	798 <main+0x238>  // b.any
    rec('P', E_PUT_BEGIN, i);
 7a8:	2a1503e2 	mov	w2, w21
 7ac:	52800041 	mov	w1, #0x2                   	// #2
 7b0:	52800a00 	mov	w0, #0x50                  	// #80
 7b4:	9400018d 	bl	de8 <rec>
    if(write(wfd, item, ITEM_SIZE) != ITEM_SIZE)
 7b8:	2a1603e2 	mov	w2, w22
 7bc:	aa1303e1 	mov	x1, x19
 7c0:	2a1c03e0 	mov	w0, w28
 7c4:	97ffff43 	bl	4d0 <write@plt>
 7c8:	7102001f 	cmp	w0, #0x80
 7cc:	54fff1e1 	b.ne	608 <main+0xa8>  // b.any
    rec('P', E_PUT_END, i);
 7d0:	2a1503e2 	mov	w2, w21
 7d4:	52800061 	mov	w1, #0x3                   	// #3
 7d8:	52800a00 	mov	w0, #0x50                  	// #80
  for(int i = 1; i <= items; i++){
 7dc:	110006b5 	add	w21, w21, #0x1
    rec('P', E_PUT_END, i);
 7e0:	94000182 	bl	de8 <rec>
  for(int i = 1; i <= items; i++){
 7e4:	6b15033f 	cmp	w25, w21
 7e8:	54fffcea 	b.ge	784 <main+0x224>  // b.tcont
  while((n = read(back[0], (char *)cev + ncev * sizeof(struct ev),
 7ec:	91084295 	add	x21, x20, #0x210
  int ncev = 0;
 7f0:	52800016 	mov	w22, #0x0                   	// #0
                  (MAXEV - ncev) * sizeof(struct ev))) > 0)
 7f4:	52800819 	mov	w25, #0x40                  	// #64
  close(wfd);
 7f8:	2a1c03e0 	mov	w0, w28
 7fc:	97ffff55 	bl	550 <close@plt>
  rec('P', E_DONE, 0);
 800:	52800002 	mov	w2, #0x0                   	// #0
 804:	52800101 	mov	w1, #0x8                   	// #8
 808:	52800a00 	mov	w0, #0x50                  	// #80
 80c:	94000177 	bl	de8 <rec>
  while((n = read(back[0], (char *)cev + ncev * sizeof(struct ev),
 810:	b9407be0 	ldr	w0, [sp, #120]
                  (MAXEV - ncev) * sizeof(struct ev))) > 0)
 814:	4b160322 	sub	w2, w25, w22
  while((n = read(back[0], (char *)cev + ncev * sizeof(struct ev),
 818:	8b36cea1 	add	x1, x21, w22, sxtw #3
 81c:	531d7042 	lsl	w2, w2, #3
 820:	97ffff38 	bl	500 <read@plt>
                  (MAXEV - ncev) * sizeof(struct ev))) > 0)
 824:	7100001f 	cmp	w0, #0x0
 828:	540003cc 	b.gt	8a0 <main+0x340>
  wait(0);
 82c:	d2800000 	mov	x0, #0x0                   	// #0
 830:	97ffff30 	bl	4f0 <wait@plt>
  printf("producer = pid %d, consumer = pid %d; time ms since fork\n", ppid, pid);
 834:	2a1803e2 	mov	w2, w24
 838:	2a1b03e1 	mov	w1, w27
 83c:	90000000 	adrp	x0, 0 <.plt-0x480>
 840:	913eac00 	add	x0, x0, #0xfab
 844:	97ffff17 	bl	4a0 <printf@plt>
  while(d++ < w) put_s(l, " ");
 848:	9000001b 	adrp	x27, 0 <.plt-0x480>
 84c:	9139db7b 	add	x27, x27, #0xe76
  printf("    time   cpu  who  event\n");
 850:	90000000 	adrp	x0, 0 <.plt-0x480>
 854:	913f9400 	add	x0, x0, #0xfe5
 858:	97ffff12 	bl	4a0 <printf@plt>
  int i = 0, j = 0, lastcpu[2] = { -1, -1 };
 85c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
  int wdone = 0, rdone = 0, pipe_wait[2] = { 0, 0 };   // items written / read so far
 860:	5280001a 	mov	w26, #0x0                   	// #0
 864:	52800019 	mov	w25, #0x0                   	// #0
  int i = 0, j = 0, lastcpu[2] = { -1, -1 };
 868:	52800015 	mov	w21, #0x0                   	// #0
 86c:	52800018 	mov	w24, #0x0                   	// #0
  int d = 1; for(uint64 x = v; x >= 10; x /= 10) d++;
 870:	d280015c 	mov	x28, #0xa                   	// #10
  uint32 begin_t[2] = { 0, 0 };
 874:	a9087fe0 	stp	x0, xzr, [sp, #128]
  int wdone = 0, rdone = 0, pipe_wait[2] = { 0, 0 };   // items written / read so far
 878:	f9004bff 	str	xzr, [sp, #144]
  while(i < nev || j < ncev){
 87c:	b9400280 	ldr	w0, [x20]
 880:	6b18001f 	cmp	w0, w24
 884:	5400012c 	b.gt	8a8 <main+0x348>
 888:	6b1502df 	cmp	w22, w21
 88c:	540008cc 	b.gt	9a4 <main+0x444>
  printf("pcsched: done\n");
 890:	b0000000 	adrp	x0, 1000 <rec+0x218>
 894:	9102c000 	add	x0, x0, #0xb0
 898:	97ffff02 	bl	4a0 <printf@plt>
 89c:	17ffff9d 	b	710 <main+0x1b0>
    ncev += n / sizeof(struct ev);
 8a0:	0b400ed6 	add	w22, w22, w0, lsr #3
 8a4:	17ffffdb 	b	810 <main+0x2b0>
    struct ev *e = (j >= ncev || (i < nev && evs[i].t_us <= cev[j].t_us)) ? &evs[i++] : &cev[j++];
 8a8:	6b1502df 	cmp	w22, w21
 8ac:	2a1803e8 	mov	w8, w24
 8b0:	5400010d 	b.le	8d0 <main+0x370>
 8b4:	8b080e82 	add	x2, x20, x8, lsl #3
 8b8:	91084281 	add	x1, x20, #0x210
 8bc:	d37d7ea0 	ubfiz	x0, x21, #3, #32
 8c0:	b9400442 	ldr	w2, [x2, #4]
 8c4:	b8606820 	ldr	w0, [x1, x0]
 8c8:	6b00005f 	cmp	w2, w0
 8cc:	540006c8 	b.hi	9a4 <main+0x444>  // b.pmore
 8d0:	91001280 	add	x0, x20, #0x4
 8d4:	11000718 	add	w24, w24, #0x1
 8d8:	8b080c08 	add	x8, x0, x8, lsl #3
    put_pad(&l, e->t_us / 1000, 5); put_s(&l, "."); put_u(&l, e->t_us % 1000, 3);
 8dc:	b9400109 	ldr	w9, [x8]
 8e0:	52807d05 	mov	w5, #0x3e8                 	// #1000
    int w = e->role == 'C';
 8e4:	3940150b 	ldrb	w11, [x8, #5]
  int d = 1; for(uint64 x = v; x >= 10; x /= 10) d++;
 8e8:	52800024 	mov	w4, #0x1                   	// #1
    struct line l; l.n = 0;
 8ec:	b9013bff 	str	wzr, [sp, #312]
    int w = e->role == 'C';
 8f0:	71010d7f 	cmp	w11, #0x43
    put_pad(&l, e->t_us / 1000, 5); put_s(&l, "."); put_u(&l, e->t_us % 1000, 3);
 8f4:	1ac50925 	udiv	w5, w9, w5
    int w = e->role == 'C';
 8f8:	1a9f17ea 	cset	w10, eq	// eq = none
  int d = 1; for(uint64 x = v; x >= 10; x /= 10) d++;
 8fc:	aa0503e0 	mov	x0, x5
 900:	f100241f 	cmp	x0, #0x9
 904:	54000588 	b.hi	9b4 <main+0x454>  // b.pmore
  while(d++ < w) put_s(l, " ");
 908:	7100109f 	cmp	w4, #0x4
 90c:	540005ad 	b.le	9c0 <main+0x460>
  put_u(l, v, 1);
 910:	52800022 	mov	w2, #0x1                   	// #1
 914:	aa1303e0 	mov	x0, x19
 918:	aa0503e1 	mov	x1, x5
 91c:	94000102 	bl	d24 <put_u>
    put_pad(&l, e->t_us / 1000, 5); put_s(&l, "."); put_u(&l, e->t_us % 1000, 3);
 920:	b0000001 	adrp	x1, 1000 <rec+0x218>
 924:	91007021 	add	x1, x1, #0x1c
 928:	940000f4 	bl	cf8 <put_s>
 92c:	52807d01 	mov	w1, #0x3e8                 	// #1000
 930:	52800062 	mov	w2, #0x3                   	// #3
 934:	1ac10923 	udiv	w3, w9, w1
 938:	1b01a461 	msub	w1, w3, w1, w9
 93c:	940000fa 	bl	d24 <put_u>
    put_s(&l, "  cpu"); put_u(&l, e->cpu, 1);
 940:	b0000001 	adrp	x1, 1000 <rec+0x218>
 944:	91000421 	add	x1, x1, #0x1
 948:	940000ec 	bl	cf8 <put_s>
 94c:	3940110d 	ldrb	w13, [x8, #4]
 950:	52800022 	mov	w2, #0x1                   	// #1
 954:	3940110c 	ldrb	w12, [x8, #4]
 958:	aa0d03e1 	mov	x1, x13
 95c:	940000f2 	bl	d24 <put_u>
    put_s(&l, w ? "  C    " : "  P  ");
 960:	71010d7f 	cmp	w11, #0x43
 964:	90000002 	adrp	x2, 0 <.plt-0x480>
 968:	9139c042 	add	x2, x2, #0xe70
 96c:	90000001 	adrp	x1, 0 <.plt-0x480>
 970:	9139e021 	add	x1, x1, #0xe78
 974:	9a821021 	csel	x1, x1, x2, ne	// ne = any
 978:	940000e0 	bl	cf8 <put_s>
    switch(e->kind){
 97c:	3940190e 	ldrb	w14, [x8, #6]
 980:	510005c1 	sub	w1, w14, #0x1
 984:	71001c3f 	cmp	w1, #0x7
 988:	54000548 	b.hi	a30 <main+0x4d0>  // b.pmore
 98c:	b0000000 	adrp	x0, 1000 <rec+0x218>
 990:	91030000 	add	x0, x0, #0xc0
 994:	78615800 	ldrh	w0, [x0, w1, uxtw #1]
 998:	10000061 	adr	x1, 9a4 <main+0x444>
 99c:	8b20a820 	add	x0, x1, w0, sxth #2
 9a0:	d61f0000 	br	x0
    struct ev *e = (j >= ncev || (i < nev && evs[i].t_us <= cev[j].t_us)) ? &evs[i++] : &cev[j++];
 9a4:	91084288 	add	x8, x20, #0x210
 9a8:	8b354d08 	add	x8, x8, w21, uxtw #3
 9ac:	110006b5 	add	w21, w21, #0x1
 9b0:	17ffffcb 	b	8dc <main+0x37c>
  int d = 1; for(uint64 x = v; x >= 10; x /= 10) d++;
 9b4:	9adc0800 	udiv	x0, x0, x28
 9b8:	11000484 	add	w4, w4, #0x1
 9bc:	17ffffd1 	b	900 <main+0x3a0>
  while(d++ < w) put_s(l, " ");
 9c0:	11000484 	add	w4, w4, #0x1
 9c4:	aa1b03e1 	mov	x1, x27
 9c8:	aa1303e0 	mov	x0, x19
 9cc:	940000cb 	bl	cf8 <put_s>
 9d0:	17ffffce 	b	908 <main+0x3a8>
    case E_START:     put_s(&l, w ? "start (forked child)" : "start"); break;
 9d4:	71010d7f 	cmp	w11, #0x43
 9d8:	90000000 	adrp	x0, 0 <.plt-0x480>
 9dc:	9139f800 	add	x0, x0, #0xe7e
 9e0:	90000001 	adrp	x1, 0 <.plt-0x480>
 9e4:	913a4c21 	add	x1, x1, #0xe93
 9e8:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    case E_DONE:      put_s(&l, "done"); break;
 9ec:	aa1303e0 	mov	x0, x19
 9f0:	1400007b 	b	bdc <main+0x67c>
    case E_PUT_BEGIN: put_s(&l, "write #"); put_u(&l, e->item, 1); put_s(&l, " ..."); begin_t[0] = e->t_us; pipe_wait[0] = wdone - rdone >= SLOTS; break;
 9f4:	aa1303e0 	mov	x0, x19
 9f8:	b0000001 	adrp	x1, 1000 <rec+0x218>
 9fc:	91001c21 	add	x1, x1, #0x7
 a00:	940000be 	bl	cf8 <put_s>
 a04:	39401d01 	ldrb	w1, [x8, #7]
 a08:	52800022 	mov	w2, #0x1                   	// #1
 a0c:	940000c6 	bl	d24 <put_u>
 a10:	b0000001 	adrp	x1, 1000 <rec+0x218>
 a14:	91006421 	add	x1, x1, #0x19
 a18:	940000b8 	bl	cf8 <put_s>
 a1c:	4b1a0320 	sub	w0, w25, w26
 a20:	71000c1f 	cmp	w0, #0x3
 a24:	b9008be9 	str	w9, [sp, #136]
 a28:	1a9fd7e0 	cset	w0, gt
 a2c:	b90093e0 	str	w0, [sp, #144]
    if((e->kind == E_PUT_END || e->kind == E_GET_END || e->kind == E_EOF) &&
 a30:	510015c0 	sub	w0, w14, #0x5
 a34:	12001c00 	and	w0, w0, #0xff
 a38:	7100041f 	cmp	w0, #0x1
 a3c:	7a4389c4 	ccmp	w14, #0x3, #0x4, hi	// hi = pmore
 a40:	54000301 	b.ne	aa0 <main+0x540>  // b.any
       e->t_us - begin_t[w] >= 2000){
 a44:	910223e0 	add	x0, sp, #0x88
 a48:	b86a7800 	ldr	w0, [x0, x10, lsl #2]
 a4c:	4b000129 	sub	w9, w9, w0
    if((e->kind == E_PUT_END || e->kind == E_GET_END || e->kind == E_EOF) &&
 a50:	711f3d3f 	cmp	w9, #0x7cf
 a54:	54000269 	b.ls	aa0 <main+0x540>  // b.plast
      put_s(&l, "   <- ~"); put_u(&l, (e->t_us - begin_t[w]) / 1000, 1);
 a58:	aa1303e0 	mov	x0, x19
 a5c:	b0000001 	adrp	x1, 1000 <rec+0x218>
 a60:	91016821 	add	x1, x1, #0x5a
 a64:	940000a5 	bl	cf8 <put_s>
 a68:	52807d01 	mov	w1, #0x3e8                 	// #1000
 a6c:	52800022 	mov	w2, #0x1                   	// #1
 a70:	1ac10921 	udiv	w1, w9, w1
 a74:	940000ac 	bl	d24 <put_u>
      if(pipe_wait[w])
 a78:	910243e1 	add	x1, sp, #0x90
 a7c:	b86a7821 	ldr	w1, [x1, x10, lsl #2]
 a80:	34000be1 	cbz	w1, bfc <main+0x69c>
        put_s(&l, w ? " ms asleep in piperead (pipe was empty)"
 a84:	71010d7f 	cmp	w11, #0x43
 a88:	90000002 	adrp	x2, 0 <.plt-0x480>
 a8c:	913a6442 	add	x2, x2, #0xe99
 a90:	90000001 	adrp	x1, 0 <.plt-0x480>
 a94:	913b0421 	add	x1, x1, #0xec1
 a98:	9a821021 	csel	x1, x1, x2, ne	// ne = any
        put_s(&l, " ms, pipe was not full/empty: preempt/fault/trace print");
 a9c:	94000097 	bl	cf8 <put_s>
    if(lastcpu[w] >= 0 && lastcpu[w] != e->cpu){
 aa0:	910203e9 	add	x9, sp, #0x80
 aa4:	b86a7924 	ldr	w4, [x9, x10, lsl #2]
 aa8:	37f80264 	tbnz	w4, #31, af4 <main+0x594>
 aac:	6b0c009f 	cmp	w4, w12
 ab0:	54000220 	b.eq	af4 <main+0x594>  // b.none
      put_s(&l, "   [moved cpu"); put_u(&l, lastcpu[w], 1); put_s(&l, "->cpu");
 ab4:	aa1303e0 	mov	x0, x19
 ab8:	b0000001 	adrp	x1, 1000 <rec+0x218>
 abc:	91026821 	add	x1, x1, #0x9a
 ac0:	9400008e 	bl	cf8 <put_s>
 ac4:	52800022 	mov	w2, #0x1                   	// #1
 ac8:	2a0403e1 	mov	w1, w4
 acc:	94000096 	bl	d24 <put_u>
 ad0:	b0000001 	adrp	x1, 1000 <rec+0x218>
 ad4:	9102a021 	add	x1, x1, #0xa8
 ad8:	94000088 	bl	cf8 <put_s>
      put_u(&l, e->cpu, 1); put_s(&l, "]");
 adc:	52800022 	mov	w2, #0x1                   	// #1
 ae0:	aa0d03e1 	mov	x1, x13
 ae4:	94000090 	bl	d24 <put_u>
 ae8:	b0000001 	adrp	x1, 1000 <rec+0x218>
 aec:	9102b821 	add	x1, x1, #0xae
 af0:	94000082 	bl	cf8 <put_s>
    l.b[l.n++] = '\n';
 af4:	b9413be0 	ldr	w0, [sp, #312]
 af8:	52800141 	mov	w1, #0xa                   	// #10
    lastcpu[w] = e->cpu;
 afc:	b82a792c 	str	w12, [x9, x10, lsl #2]
    l.b[l.n++] = '\n';
 b00:	11000402 	add	w2, w0, #0x1
 b04:	b9013be2 	str	w2, [sp, #312]
 b08:	3820ca61 	strb	w1, [x19, w0, sxtw]
    write(1, l.b, l.n);
 b0c:	aa1303e1 	mov	x1, x19
 b10:	52800020 	mov	w0, #0x1                   	// #1
 b14:	97fffe6f 	bl	4d0 <write@plt>
 b18:	17ffff59 	b	87c <main+0x31c>
    case E_PUT_END:   put_s(&l, "write #"); put_u(&l, e->item, 1); put_s(&l, " done"); wdone++; break;
 b1c:	aa1303e0 	mov	x0, x19
 b20:	b0000001 	adrp	x1, 1000 <rec+0x218>
 b24:	91001c21 	add	x1, x1, #0x7
 b28:	94000074 	bl	cf8 <put_s>
 b2c:	39401d01 	ldrb	w1, [x8, #7]
 b30:	52800022 	mov	w2, #0x1                   	// #1
 b34:	11000739 	add	w25, w25, #0x1
 b38:	9400007b 	bl	d24 <put_u>
 b3c:	b0000001 	adrp	x1, 1000 <rec+0x218>
 b40:	91003c21 	add	x1, x1, #0xf
 b44:	9400006d 	bl	cf8 <put_s>
 b48:	17ffffba 	b	a30 <main+0x4d0>
    case E_GET_BEGIN: put_s(&l, "read ..."); begin_t[1] = e->t_us; pipe_wait[1] = wdone == rdone; break;
 b4c:	aa1303e0 	mov	x0, x19
 b50:	b0000001 	adrp	x1, 1000 <rec+0x218>
 b54:	91005421 	add	x1, x1, #0x15
 b58:	94000068 	bl	cf8 <put_s>
 b5c:	6b1a033f 	cmp	w25, w26
 b60:	b9008fe9 	str	w9, [sp, #140]
 b64:	1a9f17e0 	cset	w0, eq	// eq = none
 b68:	b90097e0 	str	w0, [sp, #148]
 b6c:	17ffffb1 	b	a30 <main+0x4d0>
    case E_GET_END:   put_s(&l, "read  #"); put_u(&l, e->item, 1); put_s(&l, " done"); rdone++; break;
 b70:	aa1303e0 	mov	x0, x19
 b74:	b0000001 	adrp	x1, 1000 <rec+0x218>
 b78:	91007821 	add	x1, x1, #0x1e
 b7c:	9400005f 	bl	cf8 <put_s>
 b80:	39401d01 	ldrb	w1, [x8, #7]
 b84:	52800022 	mov	w2, #0x1                   	// #1
 b88:	1100075a 	add	w26, w26, #0x1
 b8c:	94000066 	bl	d24 <put_u>
 b90:	b0000001 	adrp	x1, 1000 <rec+0x218>
 b94:	91003c21 	add	x1, x1, #0xf
 b98:	94000058 	bl	cf8 <put_s>
 b9c:	17ffffa5 	b	a30 <main+0x4d0>
    case E_WORK_END:  put_s(&l, "worked on #"); put_u(&l, e->item, 1); put_s(&l, " ("); put_u(&l, cons_ms, 1); put_s(&l, " ms busy)"); break;
 ba0:	aa1303e0 	mov	x0, x19
 ba4:	b0000001 	adrp	x1, 1000 <rec+0x218>
 ba8:	91009821 	add	x1, x1, #0x26
 bac:	94000053 	bl	cf8 <put_s>
 bb0:	39401d01 	ldrb	w1, [x8, #7]
 bb4:	52800022 	mov	w2, #0x1                   	// #1
 bb8:	9400005b 	bl	d24 <put_u>
 bbc:	b0000001 	adrp	x1, 1000 <rec+0x218>
 bc0:	9100c821 	add	x1, x1, #0x32
 bc4:	9400004d 	bl	cf8 <put_s>
 bc8:	93407ee1 	sxtw	x1, w23
 bcc:	52800022 	mov	w2, #0x1                   	// #1
 bd0:	94000055 	bl	d24 <put_u>
 bd4:	b0000001 	adrp	x1, 1000 <rec+0x218>
 bd8:	9100d421 	add	x1, x1, #0x35
    case E_DONE:      put_s(&l, "done"); break;
 bdc:	94000047 	bl	cf8 <put_s>
 be0:	17ffff94 	b	a30 <main+0x4d0>
    case E_EOF:       put_s(&l, "read EOF (producer closed)"); break;
 be4:	b0000001 	adrp	x1, 1000 <rec+0x218>
 be8:	9100fc21 	add	x1, x1, #0x3f
 bec:	17ffff80 	b	9ec <main+0x48c>
    case E_DONE:      put_s(&l, "done"); break;
 bf0:	b0000001 	adrp	x1, 1000 <rec+0x218>
 bf4:	91004021 	add	x1, x1, #0x10
 bf8:	17ffff7d 	b	9ec <main+0x48c>
        put_s(&l, " ms, pipe was not full/empty: preempt/fault/trace print");
 bfc:	b0000001 	adrp	x1, 1000 <rec+0x218>
 c00:	91018821 	add	x1, x1, #0x62
 c04:	17ffffa6 	b	a9c <main+0x53c>

0000000000000c08 <parse_num>:

// Parse decimal (optionally negative) or 0x-prefixed hex.  Returns 1 with
// *out set, or 0 on a malformed number.
static __attribute__((unused)) int
parse_num(const char *s, int *out)
{
 c08:	aa0003e2 	mov	x2, x0
  int neg = 0, v = 0, any = 0;

  if(*s == '-'){
 c0c:	39400000 	ldrb	w0, [x0]
 c10:	7100b41f 	cmp	w0, #0x2d
 c14:	540002c1 	b.ne	c6c <parse_num+0x64>  // b.any
    neg = 1;
    s++;
 c18:	91000442 	add	x2, x2, #0x1
    neg = 1;
 c1c:	52800025 	mov	w5, #0x1                   	// #1
  }
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 c20:	39400040 	ldrb	w0, [x2]
 c24:	7100c01f 	cmp	w0, #0x30
 c28:	540000c1 	b.ne	c40 <parse_num+0x38>  // b.any
 c2c:	39400440 	ldrb	w0, [x2, #1]
 c30:	121a7800 	and	w0, w0, #0xffffffdf
 c34:	12001c00 	and	w0, w0, #0xff
 c38:	7101601f 	cmp	w0, #0x58
 c3c:	540001c0 	b.eq	c74 <parse_num+0x6c>  // b.none
 c40:	52800000 	mov	w0, #0x0                   	// #0
 c44:	52800003 	mov	w3, #0x0                   	// #0
    }
  } else {
    for(; *s; s++, any = 1){
      if(*s < '0' || *s > '9')
        return 0;
      v = v * 10 + (*s - '0');
 c48:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
 c4c:	39400044 	ldrb	w4, [x2]
 c50:	340001c4 	cbz	w4, c88 <parse_num+0x80>
      if(*s < '0' || *s > '9')
 c54:	5100c084 	sub	w4, w4, #0x30
 c58:	12001c80 	and	w0, w4, #0xff
 c5c:	7100241f 	cmp	w0, #0x9
 c60:	54000449 	b.ls	ce8 <parse_num+0xe0>  // b.plast
      else return 0;
 c64:	52800000 	mov	w0, #0x0                   	// #0
  }
  if(!any)
    return 0;
  *out = neg ? -v : v;
  return 1;
}
 c68:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
 c6c:	52800005 	mov	w5, #0x0                   	// #0
 c70:	17ffffec 	b	c20 <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
 c74:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
 c78:	52800000 	mov	w0, #0x0                   	// #0
 c7c:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 c80:	39400044 	ldrb	w4, [x2]
 c84:	350000c4 	cbnz	w4, c9c <parse_num+0x94>
  if(!any)
 c88:	34ffff00 	cbz	w0, c68 <parse_num+0x60>
  *out = neg ? -v : v;
 c8c:	710000bf 	cmp	w5, #0x0
 c90:	5a830463 	cneg	w3, w3, ne	// ne = any
 c94:	b9000023 	str	w3, [x1]
  return 1;
 c98:	17fffff4 	b	c68 <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 c9c:	5100c080 	sub	w0, w4, #0x30
 ca0:	12001c06 	and	w6, w0, #0xff
 ca4:	710024df 	cmp	w6, #0x9
 ca8:	540000c9 	b.ls	cc0 <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 cac:	51018480 	sub	w0, w4, #0x61
 cb0:	12001c00 	and	w0, w0, #0xff
 cb4:	7100141f 	cmp	w0, #0x5
 cb8:	540000c8 	b.hi	cd0 <parse_num+0xc8>  // b.pmore
 cbc:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
 cc0:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
 cc4:	91000442 	add	x2, x2, #0x1
 cc8:	52800020 	mov	w0, #0x1                   	// #1
 ccc:	17ffffed 	b	c80 <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 cd0:	51010480 	sub	w0, w4, #0x41
 cd4:	12001c00 	and	w0, w0, #0xff
 cd8:	7100141f 	cmp	w0, #0x5
 cdc:	54fffc48 	b.hi	c64 <parse_num+0x5c>  // b.pmore
 ce0:	5100dc80 	sub	w0, w4, #0x37
 ce4:	17fffff7 	b	cc0 <parse_num+0xb8>
      v = v * 10 + (*s - '0');
 ce8:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
 cec:	91000442 	add	x2, x2, #0x1
 cf0:	52800020 	mov	w0, #0x1                   	// #1
 cf4:	17ffffd6 	b	c4c <parse_num+0x44>

0000000000000cf8 <put_s>:
{ while(*s && l->n < (int)sizeof(l->b) - 1) l->b[l->n++] = *s++; }
 cf8:	39400022 	ldrb	w2, [x1]
 cfc:	34000082 	cbz	w2, d0c <put_s+0x14>
 d00:	b940a002 	ldr	w2, [x0, #160]
 d04:	7102785f 	cmp	w2, #0x9e
 d08:	5400004d 	b.le	d10 <put_s+0x18>
 d0c:	d65f03c0 	ret
 d10:	11000443 	add	w3, w2, #0x1
 d14:	b900a003 	str	w3, [x0, #160]
 d18:	38401423 	ldrb	w3, [x1], #1
 d1c:	3822c803 	strb	w3, [x0, w2, sxtw]
 d20:	17fffff6 	b	cf8 <put_s>

0000000000000d24 <put_u>:
{
 d24:	d10083ff 	sub	sp, sp, #0x20
 d28:	d2800004 	mov	x4, #0x0                   	// #0
  do { t[i++] = '0' + v % 10; v /= 10; } while(v);
 d2c:	910023e5 	add	x5, sp, #0x8
 d30:	d2800147 	mov	x7, #0xa                   	// #10
 d34:	9ac70826 	udiv	x6, x1, x7
 d38:	f100243f 	cmp	x1, #0x9
 d3c:	9b0784c3 	msub	x3, x6, x7, x1
 d40:	aa0603e1 	mov	x1, x6
 d44:	1100c063 	add	w3, w3, #0x30
 d48:	38256883 	strb	w3, [x4, x5]
 d4c:	aa0403e3 	mov	x3, x4
 d50:	91000484 	add	x4, x4, #0x1
 d54:	54ffff08 	b.hi	d34 <put_u+0x10>  // b.pmore
 d58:	11000464 	add	w4, w3, #0x1
 d5c:	11000461 	add	w1, w3, #0x1
  while(i < w) t[i++] = '0';
 d60:	52800603 	mov	w3, #0x30                  	// #48
 d64:	6b01005f 	cmp	w2, w1
 d68:	5400020c 	b.gt	da8 <put_u+0x84>
 d6c:	6b02009f 	cmp	w4, w2
 d70:	1a84d042 	csel	w2, w2, w4, le
 d74:	51000442 	sub	w2, w2, #0x1
  while(i > 0 && l->n < (int)sizeof(l->b) - 1) l->b[l->n++] = t[--i];
 d78:	b940a001 	ldr	w1, [x0, #160]
 d7c:	7102783f 	cmp	w1, #0x9e
 d80:	5400010c 	b.gt	da0 <put_u+0x7c>
 d84:	11000423 	add	w3, w1, #0x1
 d88:	b900a003 	str	w3, [x0, #160]
 d8c:	386268a3 	ldrb	w3, [x5, x2]
 d90:	d1000442 	sub	x2, x2, #0x1
 d94:	3821c803 	strb	w3, [x0, w1, sxtw]
 d98:	3100045f 	cmn	w2, #0x1
 d9c:	54fffee1 	b.ne	d78 <put_u+0x54>  // b.any
}
 da0:	910083ff 	add	sp, sp, #0x20
 da4:	d65f03c0 	ret
  while(i < w) t[i++] = '0';
 da8:	382168a3 	strb	w3, [x5, x1]
 dac:	91000421 	add	x1, x1, #0x1
 db0:	17ffffed 	b	d64 <put_u+0x40>

0000000000000db4 <busy_ms>:
{
 db4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 db8:	910003fd 	mov	x29, sp
 dbc:	f9000bf3 	str	x19, [sp, #16]
 dc0:	2a0003f3 	mov	w19, w0
  uint64 until = clock_us() + (uint64)ms * 1000;
 dc4:	97fffddb 	bl	530 <clock_us@plt>
 dc8:	52807d01 	mov	w1, #0x3e8                 	// #1000
 dcc:	9b210273 	smaddl	x19, w19, w1, x0
  while(clock_us() < until)
 dd0:	97fffdd8 	bl	530 <clock_us@plt>
 dd4:	eb13001f 	cmp	x0, x19
 dd8:	54ffffc3 	b.cc	dd0 <busy_ms+0x1c>  // b.lo, b.ul, b.last
}
 ddc:	f9400bf3 	ldr	x19, [sp, #16]
 de0:	a8c27bfd 	ldp	x29, x30, [sp], #32
 de4:	d65f03c0 	ret

0000000000000de8 <rec>:
{
 de8:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 dec:	910003fd 	mov	x29, sp
 df0:	a90153f3 	stp	x19, x20, [sp, #16]
 df4:	a90363f7 	stp	x23, x24, [sp, #48]
 df8:	2a0003f7 	mov	w23, w0
  if(nev < MAXEV){
 dfc:	d0000014 	adrp	x20, 2000 <rec+0x1218>
 e00:	b9427280 	ldr	w0, [x20, #624]
{
 e04:	a9025bf5 	stp	x21, x22, [sp, #32]
  if(nev < MAXEV){
 e08:	7100fc1f 	cmp	w0, #0x3f
 e0c:	5400028c 	b.gt	e5c <rec+0x74>
 e10:	9109c298 	add	x24, x20, #0x270
    evs[nev].t_us = (uint32)(clock_us() - t0);
 e14:	2a0103f6 	mov	w22, w1
 e18:	2a0203f5 	mov	w21, w2
 e1c:	97fffdc5 	bl	530 <clock_us@plt>
 e20:	b9827281 	ldrsw	x1, [x20, #624]
 e24:	91001313 	add	x19, x24, #0x4
 e28:	f9410702 	ldr	x2, [x24, #520]
 e2c:	d37df021 	lsl	x1, x1, #3
 e30:	4b020000 	sub	w0, w0, w2
 e34:	b8216a60 	str	w0, [x19, x1]
    evs[nev].cpu = (uint8)getcpu();
 e38:	97fffdba 	bl	520 <getcpu@plt>
 e3c:	b9427284 	ldr	w4, [x20, #624]
 e40:	8b24ce63 	add	x3, x19, w4, sxtw #3
    nev++;
 e44:	11000484 	add	w4, w4, #0x1
 e48:	b9027284 	str	w4, [x20, #624]
    evs[nev].cpu = (uint8)getcpu();
 e4c:	39001060 	strb	w0, [x3, #4]
    evs[nev].role = (uint8)role;
 e50:	39001477 	strb	w23, [x3, #5]
    evs[nev].kind = (uint8)kind;
 e54:	39001876 	strb	w22, [x3, #6]
    evs[nev].item = (uint8)item;
 e58:	39001c75 	strb	w21, [x3, #7]
}
 e5c:	a94153f3 	ldp	x19, x20, [sp, #16]
 e60:	a9425bf5 	ldp	x21, x22, [sp, #32]
 e64:	a94363f7 	ldp	x23, x24, [sp, #48]
 e68:	a8c47bfd 	ldp	x29, x30, [sp], #64
 e6c:	d65f03c0 	ret
