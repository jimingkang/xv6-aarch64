
user/_cat:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000328 <.plt>:
 328:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 32c:	b0000010 	adrp	x16, 1000 <cat+0xbd8>
 330:	f9431211 	ldr	x17, [x16, #1568]
 334:	91188210 	add	x16, x16, #0x620
 338:	d61f0220 	br	x17
 33c:	d503201f 	nop
 340:	d503201f 	nop
 344:	d503201f 	nop

0000000000000348 <write@plt>:
 348:	b0000010 	adrp	x16, 1000 <cat+0xbd8>
 34c:	f9431611 	ldr	x17, [x16, #1576]
 350:	9118a210 	add	x16, x16, #0x628
 354:	d61f0220 	br	x17

0000000000000358 <fprintf@plt>:
 358:	b0000010 	adrp	x16, 1000 <cat+0xbd8>
 35c:	f9431a11 	ldr	x17, [x16, #1584]
 360:	9118c210 	add	x16, x16, #0x630
 364:	d61f0220 	br	x17

0000000000000368 <read@plt>:
 368:	b0000010 	adrp	x16, 1000 <cat+0xbd8>
 36c:	f9431e11 	ldr	x17, [x16, #1592]
 370:	9118e210 	add	x16, x16, #0x638
 374:	d61f0220 	br	x17

0000000000000378 <exit@plt>:
 378:	b0000010 	adrp	x16, 1000 <cat+0xbd8>
 37c:	f9432211 	ldr	x17, [x16, #1600]
 380:	91190210 	add	x16, x16, #0x640
 384:	d61f0220 	br	x17

0000000000000388 <open@plt>:
 388:	b0000010 	adrp	x16, 1000 <cat+0xbd8>
 38c:	f9432611 	ldr	x17, [x16, #1608]
 390:	91192210 	add	x16, x16, #0x648
 394:	d61f0220 	br	x17

0000000000000398 <close@plt>:
 398:	b0000010 	adrp	x16, 1000 <cat+0xbd8>
 39c:	f9432a11 	ldr	x17, [x16, #1616]
 3a0:	91194210 	add	x16, x16, #0x650
 3a4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000003a8 <main>:
  }
}

int
main(int argc, char *argv[])
{
 3a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 3ac:	910003fd 	mov	x29, sp
 3b0:	a90153f3 	stp	x19, x20, [sp, #16]
 3b4:	a9025bf5 	stp	x21, x22, [sp, #32]
  int fd, i;

  if(argc <= 1){
 3b8:	7100041f 	cmp	w0, #0x1
 3bc:	540000ac 	b.gt	3d0 <main+0x28>
    cat(0);
 3c0:	52800000 	mov	w0, #0x0                   	// #0
 3c4:	94000019 	bl	428 <cat>
      exit(1);
    }
    cat(fd);
    close(fd);
  }
  exit(0);
 3c8:	52800000 	mov	w0, #0x0                   	// #0
 3cc:	1400000f 	b	408 <main+0x60>
 3d0:	2a0003f4 	mov	w20, w0
 3d4:	aa0103f6 	mov	x22, x1
  if(argc <= 1){
 3d8:	d2800033 	mov	x19, #0x1                   	// #1
    if((fd = open(argv[i], 0)) < 0){
 3dc:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
 3e0:	52800001 	mov	w1, #0x0                   	// #0
 3e4:	97ffffe9 	bl	388 <open@plt>
 3e8:	2a0003f5 	mov	w21, w0
 3ec:	36f80100 	tbz	w0, #31, 40c <main+0x64>
      fprintf(2, "cat: cannot open %s\n", argv[i]);
 3f0:	f8735ac2 	ldr	x2, [x22, w19, uxtw #3]
 3f4:	90000001 	adrp	x1, 0 <.plt-0x328>
 3f8:	91134c21 	add	x1, x1, #0x4d3
 3fc:	52800040 	mov	w0, #0x2                   	// #2
 400:	97ffffd6 	bl	358 <fprintf@plt>
      exit(1);
 404:	52800020 	mov	w0, #0x1                   	// #1
 408:	97ffffdc 	bl	378 <exit@plt>
    cat(fd);
 40c:	94000007 	bl	428 <cat>
  for(i = 1; i < argc; i++){
 410:	91000673 	add	x19, x19, #0x1
    close(fd);
 414:	2a1503e0 	mov	w0, w21
 418:	97ffffe0 	bl	398 <close@plt>
  for(i = 1; i < argc; i++){
 41c:	6b13029f 	cmp	w20, w19
 420:	54fffdec 	b.gt	3dc <main+0x34>
 424:	17ffffe9 	b	3c8 <main+0x20>

0000000000000428 <cat>:
{
 428:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 42c:	910003fd 	mov	x29, sp
 430:	a90153f3 	stp	x19, x20, [sp, #16]
  while((n = read(fd, buf, sizeof(buf))) > 0) {
 434:	b0000013 	adrp	x19, 1000 <cat+0xbd8>
 438:	91196273 	add	x19, x19, #0x658
{
 43c:	f90013f5 	str	x21, [sp, #32]
 440:	2a0003f5 	mov	w21, w0
  while((n = read(fd, buf, sizeof(buf))) > 0) {
 444:	aa1303e1 	mov	x1, x19
 448:	2a1503e0 	mov	w0, w21
 44c:	52804002 	mov	w2, #0x200                 	// #512
 450:	97ffffc6 	bl	368 <read@plt>
 454:	2a0003f4 	mov	w20, w0
 458:	7100001f 	cmp	w0, #0x0
 45c:	540000ac 	b.gt	470 <cat+0x48>
  if(n < 0){
 460:	54000200 	b.eq	4a0 <cat+0x78>  // b.none
    fprintf(2, "cat: read error\n");
 464:	90000001 	adrp	x1, 0 <.plt-0x328>
 468:	91130821 	add	x1, x1, #0x4c2
 46c:	14000009 	b	490 <cat+0x68>
    if (write(1, buf, n) != n) {
 470:	2a1403e2 	mov	w2, w20
 474:	aa1303e1 	mov	x1, x19
 478:	52800020 	mov	w0, #0x1                   	// #1
 47c:	97ffffb3 	bl	348 <write@plt>
 480:	6b14001f 	cmp	w0, w20
 484:	54fffe00 	b.eq	444 <cat+0x1c>  // b.none
      fprintf(2, "cat: write error\n");
 488:	90000001 	adrp	x1, 0 <.plt-0x328>
 48c:	9112c021 	add	x1, x1, #0x4b0
    fprintf(2, "cat: read error\n");
 490:	52800040 	mov	w0, #0x2                   	// #2
 494:	97ffffb1 	bl	358 <fprintf@plt>
    exit(1);
 498:	52800020 	mov	w0, #0x1                   	// #1
 49c:	97ffffb7 	bl	378 <exit@plt>
}
 4a0:	f94013f5 	ldr	x21, [sp, #32]
 4a4:	a94153f3 	ldp	x19, x20, [sp, #16]
 4a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
 4ac:	d65f03c0 	ret
