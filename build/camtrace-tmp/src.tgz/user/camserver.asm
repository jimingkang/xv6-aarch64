
user/_camserver:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000898 <.plt>:
 898:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 89c:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 8a0:	f941d611 	ldr	x17, [x16, #936]
 8a4:	910ea210 	add	x16, x16, #0x3a8
 8a8:	d61f0220 	br	x17
 8ac:	d503201f 	nop
 8b0:	d503201f 	nop
 8b4:	d503201f 	nop

00000000000008b8 <socket_accept@plt>:
 8b8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 8bc:	f941da11 	ldr	x17, [x16, #944]
 8c0:	910ec210 	add	x16, x16, #0x3b0
 8c4:	d61f0220 	br	x17

00000000000008c8 <printf@plt>:
 8c8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 8cc:	f941de11 	ldr	x17, [x16, #952]
 8d0:	910ee210 	add	x16, x16, #0x3b8
 8d4:	d61f0220 	br	x17

00000000000008d8 <epoll_wait@plt>:
 8d8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 8dc:	f941e211 	ldr	x17, [x16, #960]
 8e0:	910f0210 	add	x16, x16, #0x3c0
 8e4:	d61f0220 	br	x17

00000000000008e8 <memmove@plt>:
 8e8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 8ec:	f941e611 	ldr	x17, [x16, #968]
 8f0:	910f2210 	add	x16, x16, #0x3c8
 8f4:	d61f0220 	br	x17

00000000000008f8 <memcpy@plt>:
 8f8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 8fc:	f941ea11 	ldr	x17, [x16, #976]
 900:	910f4210 	add	x16, x16, #0x3d0
 904:	d61f0220 	br	x17

0000000000000908 <malloc@plt>:
 908:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 90c:	f941ee11 	ldr	x17, [x16, #984]
 910:	910f6210 	add	x16, x16, #0x3d8
 914:	d61f0220 	br	x17

0000000000000918 <sleep@plt>:
 918:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 91c:	f941f211 	ldr	x17, [x16, #992]
 920:	910f8210 	add	x16, x16, #0x3e0
 924:	d61f0220 	br	x17

0000000000000928 <mmap@plt>:
 928:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 92c:	f941f611 	ldr	x17, [x16, #1000]
 930:	910fa210 	add	x16, x16, #0x3e8
 934:	d61f0220 	br	x17

0000000000000938 <epoll_ctl@plt>:
 938:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 93c:	f941fa11 	ldr	x17, [x16, #1008]
 940:	910fc210 	add	x16, x16, #0x3f0
 944:	d61f0220 	br	x17

0000000000000948 <write@plt>:
 948:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 94c:	f941fe11 	ldr	x17, [x16, #1016]
 950:	910fe210 	add	x16, x16, #0x3f8
 954:	d61f0220 	br	x17

0000000000000958 <fprintf@plt>:
 958:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 95c:	f9420211 	ldr	x17, [x16, #1024]
 960:	91100210 	add	x16, x16, #0x400
 964:	d61f0220 	br	x17

0000000000000968 <sync_create@plt>:
 968:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 96c:	f9420611 	ldr	x17, [x16, #1032]
 970:	91102210 	add	x16, x16, #0x408
 974:	d61f0220 	br	x17

0000000000000978 <read@plt>:
 978:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 97c:	f9420a11 	ldr	x17, [x16, #1040]
 980:	91104210 	add	x16, x16, #0x410
 984:	d61f0220 	br	x17

0000000000000988 <strncmp@plt>:
 988:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 98c:	f9420e11 	ldr	x17, [x16, #1048]
 990:	91106210 	add	x16, x16, #0x418
 994:	d61f0220 	br	x17

0000000000000998 <epoll_create@plt>:
 998:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 99c:	f9421211 	ldr	x17, [x16, #1056]
 9a0:	91108210 	add	x16, x16, #0x420
 9a4:	d61f0220 	br	x17

00000000000009a8 <memset@plt>:
 9a8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 9ac:	f9421611 	ldr	x17, [x16, #1064]
 9b0:	9110a210 	add	x16, x16, #0x428
 9b4:	d61f0220 	br	x17

00000000000009b8 <socket_listen@plt>:
 9b8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 9bc:	f9421a11 	ldr	x17, [x16, #1072]
 9c0:	9110c210 	add	x16, x16, #0x430
 9c4:	d61f0220 	br	x17

00000000000009c8 <strcmp@plt>:
 9c8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 9cc:	f9421e11 	ldr	x17, [x16, #1080]
 9d0:	9110e210 	add	x16, x16, #0x438
 9d4:	d61f0220 	br	x17

00000000000009d8 <clock_us@plt>:
 9d8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 9dc:	f9422211 	ldr	x17, [x16, #1088]
 9e0:	91110210 	add	x16, x16, #0x440
 9e4:	d61f0220 	br	x17

00000000000009e8 <exit@plt>:
 9e8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 9ec:	f9422611 	ldr	x17, [x16, #1096]
 9f0:	91112210 	add	x16, x16, #0x448
 9f4:	d61f0220 	br	x17

00000000000009f8 <atoi@plt>:
 9f8:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 9fc:	f9422a11 	ldr	x17, [x16, #1104]
 a00:	91114210 	add	x16, x16, #0x450
 a04:	d61f0220 	br	x17

0000000000000a08 <strlen@plt>:
 a08:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 a0c:	f9422e11 	ldr	x17, [x16, #1112]
 a10:	91116210 	add	x16, x16, #0x458
 a14:	d61f0220 	br	x17

0000000000000a18 <open@plt>:
 a18:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 a1c:	f9423211 	ldr	x17, [x16, #1120]
 a20:	91118210 	add	x16, x16, #0x460
 a24:	d61f0220 	br	x17

0000000000000a28 <sync_signal@plt>:
 a28:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 a2c:	f9423611 	ldr	x17, [x16, #1128]
 a30:	9111a210 	add	x16, x16, #0x468
 a34:	d61f0220 	br	x17

0000000000000a38 <thread_create@plt>:
 a38:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 a3c:	f9423a11 	ldr	x17, [x16, #1136]
 a40:	9111c210 	add	x16, x16, #0x470
 a44:	d61f0220 	br	x17

0000000000000a48 <close@plt>:
 a48:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 a4c:	f9423e11 	ldr	x17, [x16, #1144]
 a50:	9111e210 	add	x16, x16, #0x478
 a54:	d61f0220 	br	x17

0000000000000a58 <sync_wait@plt>:
 a58:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 a5c:	f9424211 	ldr	x17, [x16, #1152]
 a60:	91120210 	add	x16, x16, #0x480
 a64:	d61f0220 	br	x17

0000000000000a68 <free@plt>:
 a68:	b0000030 	adrp	x16, 5000 <qbase_c+0xdd0>
 a6c:	f9424611 	ldr	x17, [x16, #1160]
 a70:	91122210 	add	x16, x16, #0x488
 a74:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000a78 <main>:
  return clock_us() - begin;
}

int
main(int argc, char **argv)
{
     a78:	a9a97bfd 	stp	x29, x30, [sp, #-368]!
     a7c:	910003fd 	mov	x29, sp
     a80:	a9025bf5 	stp	x21, x22, [sp, #32]
     a84:	aa0103f5 	mov	x21, x1
     a88:	a90363f7 	stp	x23, x24, [sp, #48]
  for(int i = 1; i < argc; i++){
    if(strcmp(argv[i], "-p") == 0 && i + 1 < argc) port = atoi(argv[++i]);
     a8c:	f0000018 	adrp	x24, 3000 <jpeg_encode_to+0x104>
     a90:	912d7318 	add	x24, x24, #0xb5c
{
     a94:	2a0003f7 	mov	w23, w0
     a98:	a9046bf9 	stp	x25, x26, [sp, #64]
    else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc) quality = atoi(argv[++i]);
     a9c:	f0000019 	adrp	x25, 3000 <jpeg_encode_to+0x104>
     aa0:	912d7f39 	add	x25, x25, #0xb5f
    else if(strcmp(argv[i], "-n") == 0 && i + 1 < argc) maxclients = atoi(argv[++i]);
     aa4:	f000001a 	adrp	x26, 3000 <jpeg_encode_to+0x104>
{
     aa8:	a90153f3 	stp	x19, x20, [sp, #16]
  for(int i = 1; i < argc; i++){
     aac:	52800033 	mov	w19, #0x1                   	// #1
{
     ab0:	a90573fb 	stp	x27, x28, [sp, #80]
  for(int i = 1; i < argc; i++){
     ab4:	6b17027f 	cmp	w19, w23
     ab8:	5400026b 	b.lt	b04 <main+0x8c>  // b.tstop
      fprintf(2, "usage: camserver [-p PORT] [-q QUALITY] [-s] [-w] "
                 "[-n CLIENTS]\n");
      exit(1);
    }
  }
  if(port < 1 || port > 65535 || quality < 1 || quality > 100 ||
     abc:	b0000035 	adrp	x21, 5000 <qbase_c+0xdd0>
     ac0:	911242b5 	add	x21, x21, #0x490
     ac4:	529fffc1 	mov	w1, #0xfffe                	// #65534
     ac8:	b94012a0 	ldr	w0, [x21, #16]
     acc:	51000400 	sub	w0, w0, #0x1
     ad0:	6b01001f 	cmp	w0, w1
     ad4:	54000128 	b.hi	af8 <main+0x80>  // b.pmore
     ad8:	b9400aa0 	ldr	w0, [x21, #8]
     adc:	51000400 	sub	w0, w0, #0x1
     ae0:	71018c1f 	cmp	w0, #0x63
     ae4:	540000a8 	b.hi	af8 <main+0x80>  // b.pmore
     ae8:	b94006a0 	ldr	w0, [x21, #4]
     aec:	51000400 	sub	w0, w0, #0x1
     af0:	71000c1f 	cmp	w0, #0x3
     af4:	54000869 	b.ls	c00 <main+0x188>  // b.plast
     maxclients < 1 || maxclients > MAXCLIENTS){
    fprintf(2, "camserver: bad port, quality or client count\n");
     af8:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     afc:	912eac21 	add	x1, x1, #0xbab
     b00:	1400003c 	b	bf0 <main+0x178>
    if(strcmp(argv[i], "-p") == 0 && i + 1 < argc) port = atoi(argv[++i]);
     b04:	937d7e76 	sbfiz	x22, x19, #3, #32
     b08:	8b33cebb 	add	x27, x21, w19, sxtw #3
     b0c:	aa1803e1 	mov	x1, x24
     b10:	f8766aa0 	ldr	x0, [x21, x22]
     b14:	97ffffad 	bl	9c8 <strcmp@plt>
     b18:	35000140 	cbnz	w0, b40 <main+0xc8>
     b1c:	11000674 	add	w20, w19, #0x1
     b20:	6b17029f 	cmp	w20, w23
     b24:	540000ea 	b.ge	b40 <main+0xc8>  // b.tcont
     b28:	f9400760 	ldr	x0, [x27, #8]
     b2c:	97ffffb3 	bl	9f8 <atoi@plt>
     b30:	b0000021 	adrp	x1, 5000 <qbase_c+0xdd0>
     b34:	b904a020 	str	w0, [x1, #1184]
  for(int i = 1; i < argc; i++){
     b38:	11000693 	add	w19, w20, #0x1
     b3c:	17ffffde 	b	ab4 <main+0x3c>
    else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc) quality = atoi(argv[++i]);
     b40:	f8766aa0 	ldr	x0, [x21, x22]
     b44:	aa1903e1 	mov	x1, x25
     b48:	97ffffa0 	bl	9c8 <strcmp@plt>
     b4c:	35000120 	cbnz	w0, b70 <main+0xf8>
     b50:	11000674 	add	w20, w19, #0x1
     b54:	6b17029f 	cmp	w20, w23
     b58:	540000ca 	b.ge	b70 <main+0xf8>  // b.tcont
     b5c:	f9400760 	ldr	x0, [x27, #8]
     b60:	97ffffa6 	bl	9f8 <atoi@plt>
     b64:	b0000021 	adrp	x1, 5000 <qbase_c+0xdd0>
     b68:	b9049820 	str	w0, [x1, #1176]
     b6c:	17fffff3 	b	b38 <main+0xc0>
    else if(strcmp(argv[i], "-n") == 0 && i + 1 < argc) maxclients = atoi(argv[++i]);
     b70:	f8766aa0 	ldr	x0, [x21, x22]
     b74:	912d8b41 	add	x1, x26, #0xb62
     b78:	97ffff94 	bl	9c8 <strcmp@plt>
     b7c:	35000120 	cbnz	w0, ba0 <main+0x128>
     b80:	11000674 	add	w20, w19, #0x1
     b84:	6b17029f 	cmp	w20, w23
     b88:	540000ca 	b.ge	ba0 <main+0x128>  // b.tcont
     b8c:	f9400760 	ldr	x0, [x27, #8]
     b90:	97ffff9a 	bl	9f8 <atoi@plt>
     b94:	b0000021 	adrp	x1, 5000 <qbase_c+0xdd0>
     b98:	b9049420 	str	w0, [x1, #1172]
     b9c:	17ffffe7 	b	b38 <main+0xc0>
    else if(strcmp(argv[i], "-s") == 0) half = 1;
     ba0:	f8766aa0 	ldr	x0, [x21, x22]
     ba4:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     ba8:	912d9421 	add	x1, x1, #0xb65
     bac:	97ffff87 	bl	9c8 <strcmp@plt>
     bb0:	350000c0 	cbnz	w0, bc8 <main+0x150>
     bb4:	b0000020 	adrp	x0, 5000 <qbase_c+0xdd0>
     bb8:	52800021 	mov	w1, #0x1                   	// #1
     bbc:	b9052401 	str	w1, [x0, #1316]
{
     bc0:	2a1303f4 	mov	w20, w19
     bc4:	17ffffdd 	b	b38 <main+0xc0>
    else if(strcmp(argv[i], "-w") == 0) wb = 0;
     bc8:	f8766aa0 	ldr	x0, [x21, x22]
     bcc:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     bd0:	912da021 	add	x1, x1, #0xb68
     bd4:	97ffff7d 	bl	9c8 <strcmp@plt>
     bd8:	35000080 	cbnz	w0, be8 <main+0x170>
     bdc:	b0000020 	adrp	x0, 5000 <qbase_c+0xdd0>
     be0:	b9049c1f 	str	wzr, [x0, #1180]
     be4:	17fffff7 	b	bc0 <main+0x148>
      fprintf(2, "usage: camserver [-p PORT] [-q QUALITY] [-s] [-w] "
     be8:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     bec:	912dac21 	add	x1, x1, #0xb6b
    fprintf(2, "camserver: bad port, quality or client count\n");
     bf0:	52800040 	mov	w0, #0x2                   	// #2
     bf4:	97ffff59 	bl	958 <fprintf@plt>
    exit(1);
     bf8:	52800020 	mov	w0, #0x1                   	// #1
     bfc:	97ffff7b 	bl	9e8 <exit@plt>
  }

  frame = malloc(CAM_READ_MAX);
     c00:	b0000033 	adrp	x19, 5000 <qbase_c+0xdd0>
     c04:	9112a273 	add	x19, x19, #0x4a8
     c08:	52800500 	mov	w0, #0x28                  	// #40
     c0c:	72a00100 	movk	w0, #0x8, lsl #16
     c10:	97ffff3e 	bl	908 <malloc@plt>
     c14:	f9003a60 	str	x0, [x19, #112]
  jpeg = malloc(JPEG_CAP);
     c18:	52a00080 	mov	w0, #0x40000               	// #262144
     c1c:	97ffff3b 	bl	908 <malloc@plt>
     c20:	f9004260 	str	x0, [x19, #128]
  encoded_buf[0] = malloc(JPEG_CAP);
     c24:	52a00080 	mov	w0, #0x40000               	// #262144
     c28:	97ffff38 	bl	908 <malloc@plt>
     c2c:	f900a260 	str	x0, [x19, #320]
  encoded_buf[1] = malloc(JPEG_CAP);
     c30:	52a00080 	mov	w0, #0x40000               	// #262144
     c34:	97ffff35 	bl	908 <malloc@plt>
     c38:	f900a660 	str	x0, [x19, #328]
  int listener = socket_listen(port, BACKLOG);
     c3c:	b94012a0 	ldr	w0, [x21, #16]
     c40:	52800081 	mov	w1, #0x4                   	// #4
     c44:	97ffff5d 	bl	9b8 <socket_listen@plt>
     c48:	2a0003f4 	mov	w20, w0
  int accept_ep = epoll_create();     // watches the listener
     c4c:	97ffff53 	bl	998 <epoll_create@plt>
     c50:	2a0003f7 	mov	w23, w0
  int req_ep = epoll_create();        // bounded waits for request headers
     c54:	97ffff51 	bl	998 <epoll_create@plt>
     c58:	2a0003f9 	mov	w25, w0
  if(frame == 0 || jpeg == 0 || encoded_buf[0] == 0 || encoded_buf[1] == 0 ||
     c5c:	f9403a60 	ldr	x0, [x19, #112]
     c60:	b4000140 	cbz	x0, c88 <main+0x210>
     c64:	f9404260 	ldr	x0, [x19, #128]
     c68:	b4000100 	cbz	x0, c88 <main+0x210>
     c6c:	f940a260 	ldr	x0, [x19, #320]
     c70:	b40000c0 	cbz	x0, c88 <main+0x210>
     c74:	f940a660 	ldr	x0, [x19, #328]
     c78:	b4000080 	cbz	x0, c88 <main+0x210>
     listener < 0 || accept_ep < 0 || req_ep < 0){
     c7c:	2a170280 	orr	w0, w20, w23
     c80:	2a190000 	orr	w0, w0, w25
     c84:	36f800e0 	tbz	w0, #31, ca0 <main+0x228>
    fprintf(2, "camserver: setup failed (memory, port %d or epoll)\n", port);
     c88:	b94012a2 	ldr	w2, [x21, #16]
     c8c:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     c90:	912f6421 	add	x1, x1, #0xbd9
     c94:	52800040 	mov	w0, #0x2                   	// #2
     c98:	97ffff30 	bl	958 <fprintf@plt>
    exit(1);
     c9c:	17ffffd7 	b	bf8 <main+0x180>
  }
  struct epoll_event ev, ready[BACKLOG];
  ev.events = EPOLLIN;
     ca0:	52800021 	mov	w1, #0x1                   	// #1
  ev.data.fd = listener;
  if(epoll_ctl(accept_ep, EPOLL_CTL_ADD, listener, &ev) < 0){
     ca4:	910283e3 	add	x3, sp, #0xa0
     ca8:	2a1403e2 	mov	w2, w20
     cac:	2a1703e0 	mov	w0, w23
  ev.events = EPOLLIN;
     cb0:	b900a3e1 	str	w1, [sp, #160]
  ev.data.fd = listener;
     cb4:	b900abf4 	str	w20, [sp, #168]
  if(epoll_ctl(accept_ep, EPOLL_CTL_ADD, listener, &ev) < 0){
     cb8:	97ffff20 	bl	938 <epoll_ctl@plt>
     cbc:	36f80080 	tbz	w0, #31, ccc <main+0x254>
    fprintf(2, "camserver: epoll_ctl failed\n");
     cc0:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     cc4:	91303421 	add	x1, x1, #0xc0d
     cc8:	17ffffca 	b	bf0 <main+0x178>
    exit(1);
  }
  if(sem_init(&pipeline_start, 0) < 0 ||
     ccc:	91047260 	add	x0, x19, #0x11c
     cd0:	52800001 	mov	w1, #0x0                   	// #0
     cd4:	94000129 	bl	1178 <sem_init>
     cd8:	3100041f 	cmn	w0, #0x1
     cdc:	54000081 	b.ne	cec <main+0x274>  // b.any
     sem_init(&encoded_free, PIPE_DEPTH) < 0 ||
     sem_init(&encoded_ready, 0) < 0 ||
     mutex_init(&convert_lock) < 0 ||
     thread_create(&capture_thread, capture_worker, 0) < 0 ||
     thread_create(&jpeg_thread, jpeg_worker, 0) < 0){
    fprintf(2, "camserver: cannot create pipeline workers\n");
     ce0:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     ce4:	9130a821 	add	x1, x1, #0xc2a
     ce8:	17ffffc2 	b	bf0 <main+0x178>
     sem_init(&camera_free[0], 1) < 0 ||
     cec:	9104a260 	add	x0, x19, #0x128
     cf0:	52800021 	mov	w1, #0x1                   	// #1
     cf4:	94000121 	bl	1178 <sem_init>
  if(sem_init(&pipeline_start, 0) < 0 ||
     cf8:	3100041f 	cmn	w0, #0x1
     cfc:	54ffff20 	b.eq	ce0 <main+0x268>  // b.none
     sem_init(&camera_free[1], 1) < 0 ||
     d00:	9104b260 	add	x0, x19, #0x12c
     d04:	52800021 	mov	w1, #0x1                   	// #1
     d08:	9400011c 	bl	1178 <sem_init>
     sem_init(&camera_free[0], 1) < 0 ||
     d0c:	3100041f 	cmn	w0, #0x1
     d10:	54fffe80 	b.eq	ce0 <main+0x268>  // b.none
     sem_init(&raw_free, PIPE_DEPTH) < 0 ||
     d14:	91023260 	add	x0, x19, #0x8c
     d18:	52800041 	mov	w1, #0x2                   	// #2
     d1c:	94000117 	bl	1178 <sem_init>
     sem_init(&camera_free[1], 1) < 0 ||
     d20:	3100041f 	cmn	w0, #0x1
     d24:	54fffde0 	b.eq	ce0 <main+0x268>  // b.none
     sem_init(&raw_ready, 0) < 0 ||
     d28:	91046260 	add	x0, x19, #0x118
     d2c:	52800001 	mov	w1, #0x0                   	// #0
     d30:	94000112 	bl	1178 <sem_init>
     sem_init(&raw_free, PIPE_DEPTH) < 0 ||
     d34:	3100041f 	cmn	w0, #0x1
     d38:	54fffd40 	b.eq	ce0 <main+0x268>  // b.none
     sem_init(&encoded_free, PIPE_DEPTH) < 0 ||
     d3c:	9104d260 	add	x0, x19, #0x134
     d40:	52800041 	mov	w1, #0x2                   	// #2
     d44:	9400010d 	bl	1178 <sem_init>
     sem_init(&raw_ready, 0) < 0 ||
     d48:	3100041f 	cmn	w0, #0x1
     d4c:	54fffca0 	b.eq	ce0 <main+0x268>  // b.none
     sem_init(&encoded_ready, 0) < 0 ||
     d50:	91064260 	add	x0, x19, #0x190
     d54:	52800001 	mov	w1, #0x0                   	// #0
     d58:	94000108 	bl	1178 <sem_init>
     sem_init(&encoded_free, PIPE_DEPTH) < 0 ||
     d5c:	3100041f 	cmn	w0, #0x1
     d60:	54fffc00 	b.eq	ce0 <main+0x268>  // b.none
typedef int mutex_t;
typedef int semaphore_t;
typedef int event_t;
typedef int katomic_t;

static inline int mutex_init(mutex_t *m) { return (*m = sync_create(SYNC_MUTEX, 1)) < 0 ? -1 : 0; }
     d64:	52800021 	mov	w1, #0x1                   	// #1
     d68:	2a0103e0 	mov	w0, w1
     d6c:	97fffeff 	bl	968 <sync_create@plt>
     d70:	b9007a60 	str	w0, [x19, #120]
     d74:	37fffb60 	tbnz	w0, #31, ce0 <main+0x268>
     thread_create(&capture_thread, capture_worker, 0) < 0 ||
     d78:	b0000001 	adrp	x1, 1000 <main+0x588>
     d7c:	91363021 	add	x1, x1, #0xd8c
     d80:	91066260 	add	x0, x19, #0x198
     d84:	d2800002 	mov	x2, #0x0                   	// #0
     d88:	97ffff2c 	bl	a38 <thread_create@plt>
     mutex_init(&convert_lock) < 0 ||
     d8c:	37fffaa0 	tbnz	w0, #31, ce0 <main+0x268>
     thread_create(&jpeg_thread, jpeg_worker, 0) < 0){
     d90:	b0000001 	adrp	x1, 1000 <main+0x588>
     d94:	913f2021 	add	x1, x1, #0xfc8
     d98:	9106a260 	add	x0, x19, #0x1a8
     d9c:	d2800002 	mov	x2, #0x0                   	// #0
     da0:	97ffff26 	bl	a38 <thread_create@plt>
     thread_create(&capture_thread, capture_worker, 0) < 0 ||
     da4:	37fff9e0 	tbnz	w0, #31, ce0 <main+0x268>
    exit(1);
  }
  printf("camserver: listening on port %d (%s, quality %d, max %d viewers)\n",
     da8:	b9407e60 	ldr	w0, [x19, #124]
     dac:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     db0:	912d3021 	add	x1, x1, #0xb4c
     db4:	f0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
     db8:	912d5042 	add	x2, x2, #0xb54
     dbc:	7100001f 	cmp	w0, #0x0
     dc0:	9a810042 	csel	x2, x2, x1, eq	// eq = none
     dc4:	b94012a1 	ldr	w1, [x21, #16]
     dc8:	29408ea4 	ldp	w4, w3, [x21, #4]
     dcc:	f0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
     dd0:	91315400 	add	x0, x0, #0xc55
     dd4:	97fffebd 	bl	8c8 <printf@plt>
         port, half ? "320x240" : "640x480", quality, maxclients);
  printf("camserver: pipeline double-buffer-v1, JPEG/camproc fast-v3\n");
     dd8:	f0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
     ddc:	91325c00 	add	x0, x0, #0xc97
     de0:	97fffeba 	bl	8c8 <printf@plt>
  printf("camserver: open http://<ip>:%d/  (stream: /stream, "
     de4:	b94012a1 	ldr	w1, [x21, #16]
     de8:	f0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
     dec:	91334c00 	add	x0, x0, #0xcd3
     df0:	97fffeb6 	bl	8c8 <printf@plt>
      // A completed frame from a stream generation whose last viewer left.
      sem_post(&encoded_free);
      continue;
    }
    if(job.error || job.len == 0 || job.len > JPEG_CAP){
      printf("camserver: stream pipeline failed; keeping viewers and "
     df4:	f0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
     df8:	9134c400 	add	x0, x0, #0xd31
     dfc:	f90043e0 	str	x0, [sp, #128]
  cat(head, &n, "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ");
     e00:	f0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
     e04:	9135e400 	add	x0, x0, #0xd79
     e08:	f90047e0 	str	x0, [sp, #136]
    if(nclients == 0){
     e0c:	b9405660 	ldr	w0, [x19, #84]
     e10:	35000060 	cbnz	w0, e1c <main+0x3a4>
      pipeline_stop_stream();
     e14:	940000c4 	bl	1124 <pipeline_stop_stream>
      camera_close();
     e18:	940000c7 	bl	1134 <camera_close>
    int n = epoll_wait(accept_ep, ready, BACKLOG, nclients ? 0 : -1);
     e1c:	b9405660 	ldr	w0, [x19, #84]
     e20:	9102c3e1 	add	x1, sp, #0xb0
     e24:	52800082 	mov	w2, #0x4                   	// #4
    for(int i = 0; i < n; i++)
     e28:	52800015 	mov	w21, #0x0                   	// #0
    int n = epoll_wait(accept_ep, ready, BACKLOG, nclients ? 0 : -1);
     e2c:	7100001f 	cmp	w0, #0x0
     e30:	2a1703e0 	mov	w0, w23
     e34:	5a9f13e3 	csetm	w3, eq	// eq = none
     e38:	97fffea8 	bl	8d8 <epoll_wait@plt>
     e3c:	2a0003f6 	mov	w22, w0
    for(int i = 0; i < n; i++)
     e40:	6b1602bf 	cmp	w21, w22
     e44:	5400046b 	b.lt	ed0 <main+0x458>  // b.tstop
    if(nclients == 0)
     e48:	b9405660 	ldr	w0, [x19, #84]
     e4c:	34fffe00 	cbz	w0, e0c <main+0x394>
  if(!pipeline_running()){
     e50:	940000a0 	bl	10d0 <pipeline_running>
     e54:	35000160 	cbnz	w0, e80 <main+0x408>
    uint next = pipeline_current_generation() + 1;
     e58:	940000a2 	bl	10e0 <pipeline_current_generation>
     e5c:	11000400 	add	w0, w0, #0x1
    __atomic_store_n(&pipeline_generation, next, __ATOMIC_RELEASE);
     e60:	91001261 	add	x1, x19, #0x4
     e64:	889ffc20 	stlr	w0, [x1]
    __atomic_store_n(&pipeline_run, 1, __ATOMIC_RELEASE);
     e68:	52800020 	mov	w0, #0x1                   	// #1
     e6c:	889ffe60 	stlr	w0, [x19]
    jpeg_len = 0;
     e70:	b9006e7f 	str	wzr, [x19, #108]
    stats_reset();
     e74:	940000a0 	bl	10f4 <stats_reset>
    sem_post(&pipeline_start);
     e78:	b9411e60 	ldr	w0, [x19, #284]
     e7c:	940001e8 	bl	161c <mutex_unlock.isra.0>
  sem_wait(&encoded_ready);
     e80:	b9419260 	ldr	w0, [x19, #400]
     e84:	940001e8 	bl	1624 <mutex_lock.isra.0>
  uint head = __atomic_load_n(&encoded_head, __ATOMIC_RELAXED);
     e88:	9106e263 	add	x3, x19, #0x1b8
     e8c:	b9400061 	ldr	w1, [x3]
  struct encoded_job job = encodedq[head % PIPE_DEPTH];
     e90:	d37b0024 	ubfiz	x4, x1, #5, #1
     e94:	91054262 	add	x2, x19, #0x150
     e98:	8b040040 	add	x0, x2, x4
  __atomic_store_n(&encoded_head, head + 1, __ATOMIC_RELEASE);
     e9c:	11000421 	add	w1, w1, #0x1
  struct encoded_job job = encodedq[head % PIPE_DEPTH];
     ea0:	f8646842 	ldr	x2, [x2, x4]
     ea4:	f9003be2 	str	x2, [sp, #112]
     ea8:	f940041b 	ldr	x27, [x0, #8]
     eac:	29425402 	ldp	w2, w21, [x0, #16]
     eb0:	29435818 	ldp	w24, w22, [x0, #24]
  __atomic_store_n(&encoded_head, head + 1, __ATOMIC_RELEASE);
     eb4:	889ffc61 	stlr	w1, [x3]
    if(job.generation != pipeline_current_generation()){
     eb8:	9400008a 	bl	10e0 <pipeline_current_generation>
     ebc:	6b02001f 	cmp	w0, w2
     ec0:	54000120 	b.eq	ee4 <main+0x46c>  // b.none
      sem_post(&encoded_free);
     ec4:	b9413660 	ldr	w0, [x19, #308]
     ec8:	940001d5 	bl	161c <mutex_unlock.isra.0>
      continue;
     ecc:	17ffffd0 	b	e0c <main+0x394>
      handle_connection(listener, req_ep);
     ed0:	2a1903e1 	mov	w1, w25
     ed4:	2a1403e0 	mov	w0, w20
    for(int i = 0; i < n; i++)
     ed8:	110006b5 	add	w21, w21, #0x1
      handle_connection(listener, req_ep);
     edc:	940001d3 	bl	1628 <handle_connection>
    for(int i = 0; i < n; i++)
     ee0:	17ffffd8 	b	e40 <main+0x3c8>
    if(job.error || job.len == 0 || job.len > JPEG_CAP){
     ee4:	350000b6 	cbnz	w22, ef8 <main+0x480>
     ee8:	510006a1 	sub	w1, w21, #0x1
     eec:	12bfff80 	mov	w0, #0x3ffff               	// #262143
     ef0:	6b00003f 	cmp	w1, w0
     ef4:	54000129 	b.ls	f18 <main+0x4a0>  // b.plast
      printf("camserver: stream pipeline failed; keeping viewers and "
     ef8:	f94043e0 	ldr	x0, [sp, #128]
     efc:	97fffe73 	bl	8c8 <printf@plt>
             "retrying camera\n");
      sem_post(&encoded_free);
     f00:	b9413660 	ldr	w0, [x19, #308]
     f04:	940001c6 	bl	161c <mutex_unlock.isra.0>
      pipeline_stop_stream();
     f08:	94000087 	bl	1124 <pipeline_stop_stream>
      // The capture worker closes both video fds and powers the sensor down
      // after publishing the error.  Leave the multipart HTTP connections
      // open: the next main-loop iteration starts a new generation and a
      // recovered camera can resume without forcing the browser to reconnect.
      sleep(10);
     f0c:	52800140 	mov	w0, #0xa                   	// #10
     f10:	97fffe82 	bl	918 <sleep@plt>
      continue;
     f14:	17ffffbe 	b	e0c <main+0x394>
    }
    // Preserve the most recent JPEG for /snapshot.jpg.  This is only a small
    // encoded-frame copy; the large RAW10 frame stays in the mmap DMA slot.
    memmove(jpeg, encoded_buf[job.buffer_index], job.len);
     f18:	8b38ce78 	add	x24, x19, w24, sxtw #3
     f1c:	2a1503e2 	mov	w2, w21
     f20:	f9404260 	ldr	x0, [x19, #128]
     f24:	f940a301 	ldr	x1, [x24, #320]
     f28:	97fffe70 	bl	8e8 <memmove@plt>
    jpeg_len = job.len;
     f2c:	b9006e75 	str	w21, [x19, #108]
    uint64 send_us = broadcast(encoded_buf[job.buffer_index], job.len);
     f30:	f940a300 	ldr	x0, [x24, #320]
     f34:	f90037e0 	str	x0, [sp, #104]
  uint64 begin = clock_us();
     f38:	97fffea8 	bl	9d8 <clock_us@plt>
     f3c:	aa0003fc 	mov	x28, x0
  cat(head, &n, "\r\n\r\n");
     f40:	f0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
     f44:	911fc800 	add	x0, x0, #0x7f2
     f48:	f9003fe0 	str	x0, [sp, #120]
  for(int i = 0; i < nclients; ){
     f4c:	b9405660 	ldr	w0, [x19, #84]
     f50:	6b0002df 	cmp	w22, w0
     f54:	540001cb 	b.lt	f8c <main+0x514>  // b.tstop
  return clock_us() - begin;
     f58:	97fffea0 	bl	9d8 <clock_us@plt>
    stats_frame(job.capture_us, job.jpeg_us, send_us, job.len, 1);
     f5c:	cb1c0002 	sub	x2, x0, x28
     f60:	f9403be0 	ldr	x0, [sp, #112]
     f64:	2a1503e3 	mov	w3, w21
     f68:	aa1b03e1 	mov	x1, x27
     f6c:	52800024 	mov	w4, #0x1                   	// #1
     f70:	940000eb 	bl	131c <stats_frame>
    sem_post(&encoded_free);
     f74:	b9413660 	ldr	w0, [x19, #308]
     f78:	940001a9 	bl	161c <mutex_unlock.isra.0>
    if(nclients == 0)
     f7c:	b9405660 	ldr	w0, [x19, #84]
     f80:	35fff460 	cbnz	w0, e0c <main+0x394>
      pipeline_stop_stream();
     f84:	94000068 	bl	1124 <pipeline_stop_stream>
     f88:	17ffffa1 	b	e0c <main+0x394>
  cat(head, &n, "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ");
     f8c:	f94047e2 	ldr	x2, [sp, #136]
    if(send_jpeg_part(clients[i], data, len) < 0){
     f90:	8b364a60 	add	x0, x19, w22, uxtw #2
  cat(head, &n, "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ");
     f94:	910273e1 	add	x1, sp, #0x9c
  int n = 0;
     f98:	b9009fff 	str	wzr, [sp, #156]
    if(send_jpeg_part(clients[i], data, len) < 0){
     f9c:	2a1603fa 	mov	w26, w22
     fa0:	b9405818 	ldr	w24, [x0, #88]
  cat(head, &n, "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ");
     fa4:	9103c3e0 	add	x0, sp, #0xf0
     fa8:	94000098 	bl	1208 <cat>
  cat_uint(head, &n, len);
     fac:	910273e1 	add	x1, sp, #0x9c
     fb0:	2a1503e2 	mov	w2, w21
     fb4:	9103c3e0 	add	x0, sp, #0xf0
     fb8:	94000027 	bl	1054 <cat_uint>
  cat(head, &n, "\r\n\r\n");
     fbc:	f9403fe2 	ldr	x2, [sp, #120]
     fc0:	9103c3e0 	add	x0, sp, #0xf0
     fc4:	94000091 	bl	1208 <cat>
  if(write_all(fd, head, n) < 0 || write_all(fd, data, len) < 0 ||
     fc8:	b9409fe2 	ldr	w2, [sp, #156]
     fcc:	9103c3e1 	add	x1, sp, #0xf0
     fd0:	2a1803e0 	mov	w0, w24
     fd4:	94000074 	bl	11a4 <write_all>
     fd8:	3100041f 	cmn	w0, #0x1
     fdc:	540001c0 	b.eq	1014 <main+0x59c>  // b.none
     fe0:	f94037e1 	ldr	x1, [sp, #104]
     fe4:	2a1503e2 	mov	w2, w21
     fe8:	2a1803e0 	mov	w0, w24
     fec:	9400006e 	bl	11a4 <write_all>
     ff0:	3100041f 	cmn	w0, #0x1
     ff4:	54000100 	b.eq	1014 <main+0x59c>  // b.none
     write_all(fd, "\r\n", 2) < 0)
     ff8:	f0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
     ffc:	911fd021 	add	x1, x1, #0x7f4
    1000:	2a1803e0 	mov	w0, w24
    1004:	52800042 	mov	w2, #0x2                   	// #2
    1008:	94000067 	bl	11a4 <write_all>
  if(write_all(fd, head, n) < 0 || write_all(fd, data, len) < 0 ||
    100c:	3100041f 	cmn	w0, #0x1
    1010:	540001e1 	b.ne	104c <main+0x5d4>  // b.any
      printf("camserver: viewer fd=%d left\n", clients[i]);
    1014:	8b1a0a78 	add	x24, x19, x26, lsl #2
    1018:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    101c:	9136b400 	add	x0, x0, #0xdad
    1020:	b9405b01 	ldr	w1, [x24, #88]
    1024:	97fffe29 	bl	8c8 <printf@plt>
      close(clients[i]);
    1028:	b9405b00 	ldr	w0, [x24, #88]
    102c:	97fffe87 	bl	a48 <close@plt>
      clients[i] = clients[--nclients];
    1030:	b9405660 	ldr	w0, [x19, #84]
    1034:	51000400 	sub	w0, w0, #0x1
    1038:	b9005660 	str	w0, [x19, #84]
    103c:	8b20ca60 	add	x0, x19, w0, sxtw #2
    1040:	b9405800 	ldr	w0, [x0, #88]
    1044:	b9005b00 	str	w0, [x24, #88]
      continue;
    1048:	17ffffc1 	b	f4c <main+0x4d4>
    i++;
    104c:	110006d6 	add	w22, w22, #0x1
    1050:	17ffffbf 	b	f4c <main+0x4d4>

0000000000001054 <cat_uint>:
  *n += put_uint(buf + *n, v);
    1054:	b9800023 	ldrsw	x3, [x1]
{
    1058:	d10043ff 	sub	sp, sp, #0x10
  *n += put_uint(buf + *n, v);
    105c:	d2800004 	mov	x4, #0x0                   	// #0
    tmp[n++] = '0' + v % 10;
    1060:	52800147 	mov	w7, #0xa                   	// #10
  *n += put_uint(buf + *n, v);
    1064:	8b030000 	add	x0, x0, x3
    tmp[n++] = '0' + v % 10;
    1068:	910003e3 	mov	x3, sp
    106c:	1ac70846 	udiv	w6, w2, w7
  } while(v);
    1070:	7100245f 	cmp	w2, #0x9
    tmp[n++] = '0' + v % 10;
    1074:	1b0788c5 	msub	w5, w6, w7, w2
    v /= 10;
    1078:	2a0603e2 	mov	w2, w6
    tmp[n++] = '0' + v % 10;
    107c:	1100c0a5 	add	w5, w5, #0x30
    1080:	38236885 	strb	w5, [x4, x3]
  } while(v);
    1084:	aa0403e5 	mov	x5, x4
    1088:	91000484 	add	x4, x4, #0x1
    108c:	54ffff08 	b.hi	106c <cat_uint+0x18>  // b.pmore
    tmp[n++] = '0' + v % 10;
    1090:	110004a4 	add	w4, w5, #0x1
    dst[i] = tmp[n - 1 - i];
    1094:	8b254063 	add	x3, x3, w5, uxtw
    tmp[n++] = '0' + v % 10;
    1098:	d2800002 	mov	x2, #0x0                   	// #0
    dst[i] = tmp[n - 1 - i];
    109c:	cb0203e6 	neg	x6, x2
    10a0:	38666866 	ldrb	w6, [x3, x6]
    10a4:	38226806 	strb	w6, [x0, x2]
  for(int i = 0; i < n; i++)
    10a8:	91000442 	add	x2, x2, #0x1
    10ac:	51000446 	sub	w6, w2, #0x1
    10b0:	6b0600bf 	cmp	w5, w6
    10b4:	54ffff4c 	b.gt	109c <cat_uint+0x48>
  dst[n] = 0;
    10b8:	3824481f 	strb	wzr, [x0, w4, uxtw]
  *n += put_uint(buf + *n, v);
    10bc:	b9400020 	ldr	w0, [x1]
    10c0:	0b040000 	add	w0, w0, w4
    10c4:	b9000020 	str	w0, [x1]
}
    10c8:	910043ff 	add	sp, sp, #0x10
    10cc:	d65f03c0 	ret

00000000000010d0 <pipeline_running>:
  return __atomic_load_n(&pipeline_run, __ATOMIC_ACQUIRE);
    10d0:	90000020 	adrp	x0, 5000 <qbase_c+0xdd0>
    10d4:	9112a000 	add	x0, x0, #0x4a8
    10d8:	88dffc00 	ldar	w0, [x0]
}
    10dc:	d65f03c0 	ret

00000000000010e0 <pipeline_current_generation>:
  return __atomic_load_n(&pipeline_generation, __ATOMIC_ACQUIRE);
    10e0:	90000020 	adrp	x0, 5000 <qbase_c+0xdd0>
    10e4:	9112a000 	add	x0, x0, #0x4a8
    10e8:	91001000 	add	x0, x0, #0x4
    10ec:	88dffc00 	ldar	w0, [x0]
}
    10f0:	d65f03c0 	ret

00000000000010f4 <stats_reset>:
{
    10f4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    10f8:	910003fd 	mov	x29, sp
  window_start_us = clock_us();
    10fc:	97fffe37 	bl	9d8 <clock_us@plt>
    1100:	90000021 	adrp	x1, 5000 <qbase_c+0xdd0>
    1104:	9112a021 	add	x1, x1, #0x4a8
}
    1108:	a8c17bfd 	ldp	x29, x30, [sp], #16
  window_start_us = clock_us();
    110c:	f9000420 	str	x0, [x1, #8]
  window_frames = 0;
    1110:	b900103f 	str	wzr, [x1, #16]
  window_capture_us = window_jpeg_us = window_send_us = 0;
    1114:	a901fc3f 	stp	xzr, xzr, [x1, #24]
  window_jpeg_bytes = 0;
    1118:	a902fc3f 	stp	xzr, xzr, [x1, #40]
  window_send_frames = 0;
    111c:	b900383f 	str	wzr, [x1, #56]
}
    1120:	d65f03c0 	ret

0000000000001124 <pipeline_stop_stream>:
  __atomic_store_n(&pipeline_run, 0, __ATOMIC_RELEASE);
    1124:	90000020 	adrp	x0, 5000 <qbase_c+0xdd0>
    1128:	9112a000 	add	x0, x0, #0x4a8
    112c:	889ffc1f 	stlr	wzr, [x0]
}
    1130:	d65f03c0 	ret

0000000000001134 <camera_close>:
{
    1134:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1138:	910003fd 	mov	x29, sp
    113c:	f9000bf3 	str	x19, [sp, #16]
  if(cam >= 0){
    1140:	90000033 	adrp	x19, 5000 <qbase_c+0xdd0>
    1144:	b9449260 	ldr	w0, [x19, #1168]
    1148:	37f80120 	tbnz	w0, #31, 116c <camera_close+0x38>
    close(cam);                       // last reference: kernel stops sensor
    114c:	97fffe3f 	bl	a48 <close@plt>
    cam = -1;
    1150:	12800000 	mov	w0, #0xffffffff            	// #-1
    1154:	b9049260 	str	w0, [x19, #1168]
}
    1158:	f9400bf3 	ldr	x19, [sp, #16]
    printf("camserver: no viewers, camera stopped\n");
    115c:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1160:	911ca000 	add	x0, x0, #0x728
}
    1164:	a8c27bfd 	ldp	x29, x30, [sp], #32
    printf("camserver: no viewers, camera stopped\n");
    1168:	17fffdd8 	b	8c8 <printf@plt>
}
    116c:	f9400bf3 	ldr	x19, [sp, #16]
    1170:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1174:	d65f03c0 	ret

0000000000001178 <sem_init>:
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
static inline int mutex_destroy(mutex_t *m) { return sync_destroy(*m); }

static inline int sem_init(semaphore_t *s, int value) { return (*s = sync_create(SYNC_SEM, value)) < 0 ? -1 : 0; }
    1178:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    117c:	910003fd 	mov	x29, sp
    1180:	f9000bf3 	str	x19, [sp, #16]
    1184:	aa0003f3 	mov	x19, x0
    1188:	52800040 	mov	w0, #0x2                   	// #2
    118c:	97fffdf7 	bl	968 <sync_create@plt>
    1190:	b9000260 	str	w0, [x19]
    1194:	131f7c00 	asr	w0, w0, #31
    1198:	f9400bf3 	ldr	x19, [sp, #16]
    119c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    11a0:	d65f03c0 	ret

00000000000011a4 <write_all>:
{
    11a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    11a8:	910003fd 	mov	x29, sp
    11ac:	a90153f3 	stp	x19, x20, [sp, #16]
    11b0:	2a0203f4 	mov	w20, w2
  int done = 0;
    11b4:	52800013 	mov	w19, #0x0                   	// #0
{
    11b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    11bc:	2a0003f6 	mov	w22, w0
    11c0:	aa0103f5 	mov	x21, x1
  while(done < n){
    11c4:	6b14027f 	cmp	w19, w20
    11c8:	540000cb 	b.lt	11e0 <write_all+0x3c>  // b.tstop
  return 0;
    11cc:	52800000 	mov	w0, #0x0                   	// #0
}
    11d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    11d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    11d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    11dc:	d65f03c0 	ret
    int m = write(fd, (const char *)buf + done, n - done);
    11e0:	4b130282 	sub	w2, w20, w19
    11e4:	8b33c2a1 	add	x1, x21, w19, sxtw
    11e8:	2a1603e0 	mov	w0, w22
    11ec:	97fffdd7 	bl	948 <write@plt>
    if(m <= 0)
    11f0:	7100001f 	cmp	w0, #0x0
    11f4:	5400006d 	b.le	1200 <write_all+0x5c>
    done += m;
    11f8:	0b000273 	add	w19, w19, w0
    11fc:	17fffff2 	b	11c4 <write_all+0x20>
      return -1;
    1200:	12800000 	mov	w0, #0xffffffff            	// #-1
    1204:	17fffff3 	b	11d0 <write_all+0x2c>

0000000000001208 <cat>:
{
    1208:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    120c:	910003fd 	mov	x29, sp
    1210:	a90153f3 	stp	x19, x20, [sp, #16]
    1214:	aa0103f3 	mov	x19, x1
    1218:	aa0003f4 	mov	x20, x0
  int len = strlen(s);
    121c:	aa0203e0 	mov	x0, x2
    1220:	f90017e2 	str	x2, [sp, #40]
    1224:	97fffdf9 	bl	a08 <strlen@plt>
    1228:	2a0003e2 	mov	w2, w0
  memmove(buf + *n, s, len);
    122c:	f94017e1 	ldr	x1, [sp, #40]
    1230:	b90027e2 	str	w2, [sp, #36]
    1234:	b9800260 	ldrsw	x0, [x19]
    1238:	8b000280 	add	x0, x20, x0
    123c:	97fffdab 	bl	8e8 <memmove@plt>
  *n += len;
    1240:	b9400260 	ldr	w0, [x19]
    1244:	b94027e2 	ldr	w2, [sp, #36]
    1248:	0b000042 	add	w2, w2, w0
    124c:	b9000262 	str	w2, [x19]
  buf[*n] = 0;
    1250:	3822ca9f 	strb	wzr, [x20, w2, sxtw]
}
    1254:	a94153f3 	ldp	x19, x20, [sp, #16]
    1258:	a8c37bfd 	ldp	x29, x30, [sp], #48
    125c:	d65f03c0 	ret

0000000000001260 <cat_fps>:
{
    1260:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1264:	910003fd 	mov	x29, sp
    1268:	a90153f3 	stp	x19, x20, [sp, #16]
  cat_uint(buf, n, fps10 / 10);
    126c:	90000033 	adrp	x19, 5000 <qbase_c+0xdd0>
    1270:	9112a273 	add	x19, x19, #0x4a8
{
    1274:	a9025bf5 	stp	x21, x22, [sp, #32]
  cat_uint(buf, n, fps10 / 10);
    1278:	52800154 	mov	w20, #0xa                   	// #10
{
    127c:	aa0003f5 	mov	x21, x0
  cat_uint(buf, n, fps10 / 10);
    1280:	b9403e62 	ldr	w2, [x19, #60]
{
    1284:	aa0103f6 	mov	x22, x1
  cat_uint(buf, n, fps10 / 10);
    1288:	1ad40842 	udiv	w2, w2, w20
    128c:	97ffff72 	bl	1054 <cat_uint>
  cat(buf, n, ".");
    1290:	aa1503e0 	mov	x0, x21
    1294:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1298:	911d3c42 	add	x2, x2, #0x74f
    129c:	97ffffdb 	bl	1208 <cat>
  cat_uint(buf, n, fps10 % 10);
    12a0:	b9403e60 	ldr	w0, [x19, #60]
    12a4:	aa1603e1 	mov	x1, x22
    12a8:	1ad40802 	udiv	w2, w0, w20
    12ac:	1b148042 	msub	w2, w2, w20, w0
    12b0:	aa1503e0 	mov	x0, x21
}
    12b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    12b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    12bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
  cat_uint(buf, n, fps10 % 10);
    12c0:	17ffff65 	b	1054 <cat_uint>

00000000000012c4 <cat_ms10>:
{
    12c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    12c8:	910003fd 	mov	x29, sp
    12cc:	a90153f3 	stp	x19, x20, [sp, #16]
  cat_uint(buf, n, v / 10);
    12d0:	52800154 	mov	w20, #0xa                   	// #10
{
    12d4:	aa0003f3 	mov	x19, x0
    12d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    12dc:	2a0203f6 	mov	w22, w2
  cat_uint(buf, n, v / 10);
    12e0:	1ad40855 	udiv	w21, w2, w20
{
    12e4:	f9001fe1 	str	x1, [sp, #56]
  cat_uint(buf, n, v / 10);
    12e8:	2a1503e2 	mov	w2, w21
    12ec:	97ffff5a 	bl	1054 <cat_uint>
  cat(buf, n, ".");
    12f0:	aa1303e0 	mov	x0, x19
    12f4:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    12f8:	911d3c42 	add	x2, x2, #0x74f
    12fc:	97ffffc3 	bl	1208 <cat>
  cat_uint(buf, n, v % 10);
    1300:	f9401fe1 	ldr	x1, [sp, #56]
    1304:	1b14daa2 	msub	w2, w21, w20, w22
    1308:	aa1303e0 	mov	x0, x19
}
    130c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1310:	a94153f3 	ldp	x19, x20, [sp, #16]
    1314:	a8c47bfd 	ldp	x29, x30, [sp], #64
  cat_uint(buf, n, v % 10);
    1318:	17ffff4f 	b	1054 <cat_uint>

000000000000131c <stats_frame>:
{
    131c:	a9af7bfd 	stp	x29, x30, [sp, #-272]!
    1320:	910003fd 	mov	x29, sp
    1324:	a90153f3 	stp	x19, x20, [sp, #16]
  frames++;
    1328:	90000033 	adrp	x19, 5000 <qbase_c+0xdd0>
    132c:	9112a273 	add	x19, x19, #0x4a8
{
    1330:	2a0303f4 	mov	w20, w3
  frames++;
    1334:	b9404263 	ldr	w3, [x19, #64]
    1338:	11000463 	add	w3, w3, #0x1
    133c:	b9004263 	str	w3, [x19, #64]
  window_frames++;
    1340:	b9401263 	ldr	w3, [x19, #16]
    1344:	11000463 	add	w3, w3, #0x1
    1348:	b9001263 	str	w3, [x19, #16]
  window_capture_us += capture_us;
    134c:	f9401663 	ldr	x3, [x19, #40]
    1350:	8b000063 	add	x3, x3, x0
  window_jpeg_us += jpeg_us;
    1354:	f9401260 	ldr	x0, [x19, #32]
    1358:	8b010000 	add	x0, x0, x1
  window_capture_us += capture_us;
    135c:	a9020e60 	stp	x0, x3, [x19, #32]
  window_jpeg_bytes += bytes;
    1360:	f9401a60 	ldr	x0, [x19, #48]
    1364:	8b344000 	add	x0, x0, w20, uxtw
    1368:	f9001a60 	str	x0, [x19, #48]
  if(sent){
    136c:	340000e4 	cbz	w4, 1388 <stats_frame+0x6c>
    window_send_us += send_us;
    1370:	f9400e60 	ldr	x0, [x19, #24]
    1374:	8b020000 	add	x0, x0, x2
    1378:	f9000e60 	str	x0, [x19, #24]
    window_send_frames++;
    137c:	b9403a60 	ldr	w0, [x19, #56]
    1380:	11000400 	add	w0, w0, #0x1
    1384:	b9003a60 	str	w0, [x19, #56]
  uint64 now = clock_us();
    1388:	97fffd94 	bl	9d8 <clock_us@plt>
  if(now - window_start_us < 3000000ULL)
    138c:	f9400661 	ldr	x1, [x19, #8]
    1390:	cb010002 	sub	x2, x0, x1
    1394:	d298d7e0 	mov	x0, #0xc6bf                	// #50879
    1398:	f2a005a0 	movk	x0, #0x2d, lsl #16
    139c:	eb00005f 	cmp	x2, x0
    13a0:	54000c69 	b.ls	152c <stats_frame+0x210>  // b.plast
  fps10 = (uint)(window_frames * 10000000ULL / elapsed);
    13a4:	b9401261 	ldr	w1, [x19, #16]
    13a8:	5292d000 	mov	w0, #0x9680                	// #38528
    13ac:	72a01300 	movk	w0, #0x98, lsl #16
  capture_ms10 = (uint)(window_capture_us * 10 /
    13b0:	d2800143 	mov	x3, #0xa                   	// #10
                        (window_frames * 1000ULL));
    13b4:	52807d04 	mov	w4, #0x3e8                 	// #1000
  fps10 = (uint)(window_frames * 10000000ULL / elapsed);
    13b8:	9ba07c20 	umull	x0, w1, w0
                        (window_frames * 1000ULL));
    13bc:	9ba47c21 	umull	x1, w1, w4
  fps10 = (uint)(window_frames * 10000000ULL / elapsed);
    13c0:	9ac20800 	udiv	x0, x0, x2
    13c4:	b9003e60 	str	w0, [x19, #60]
  capture_ms10 = (uint)(window_capture_us * 10 /
    13c8:	f9401660 	ldr	x0, [x19, #40]
    13cc:	9b037c00 	mul	x0, x0, x3
    13d0:	9ac10800 	udiv	x0, x0, x1
    13d4:	b9004660 	str	w0, [x19, #68]
  jpeg_ms10 = (uint)(window_jpeg_us * 10 /
    13d8:	f9401260 	ldr	x0, [x19, #32]
    13dc:	9b037c00 	mul	x0, x0, x3
    13e0:	9ac10800 	udiv	x0, x0, x1
  send_ms10 = window_send_frames ?
    13e4:	b9403a61 	ldr	w1, [x19, #56]
  jpeg_ms10 = (uint)(window_jpeg_us * 10 /
    13e8:	b9004a60 	str	w0, [x19, #72]
    (uint)(window_send_us * 10 / (window_send_frames * 1000ULL)) : 0;
    13ec:	340000a1 	cbz	w1, 1400 <stats_frame+0xe4>
    13f0:	f9400e60 	ldr	x0, [x19, #24]
    13f4:	9ba47c21 	umull	x1, w1, w4
    13f8:	9b037c00 	mul	x0, x0, x3
    13fc:	9ac10801 	udiv	x1, x0, x1
  payload_kbps = (uint)(window_jpeg_bytes * 8000ULL / elapsed);
    1400:	f9401a60 	ldr	x0, [x19, #48]
  send_ms10 = window_send_frames ?
    1404:	b9004e61 	str	w1, [x19, #76]
  payload_kbps = (uint)(window_jpeg_bytes * 8000ULL / elapsed);
    1408:	d283e801 	mov	x1, #0x1f40                	// #8000
  int k = 0;
    140c:	b9002fff 	str	wzr, [sp, #44]
  payload_kbps = (uint)(window_jpeg_bytes * 8000ULL / elapsed);
    1410:	9b017c00 	mul	x0, x0, x1
  cat(line, &k, "camserver: ");
    1414:	9100b3e1 	add	x1, sp, #0x2c
  payload_kbps = (uint)(window_jpeg_bytes * 8000ULL / elapsed);
    1418:	9ac20800 	udiv	x0, x0, x2
  cat(line, &k, "camserver: ");
    141c:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1420:	911d4442 	add	x2, x2, #0x751
  payload_kbps = (uint)(window_jpeg_bytes * 8000ULL / elapsed);
    1424:	b9005260 	str	w0, [x19, #80]
  cat(line, &k, "camserver: ");
    1428:	9100c3e0 	add	x0, sp, #0x30
    142c:	97ffff77 	bl	1208 <cat>
  cat_fps(line, &k);
    1430:	9100b3e1 	add	x1, sp, #0x2c
    1434:	9100c3e0 	add	x0, sp, #0x30
    1438:	97ffff8a 	bl	1260 <cat_fps>
  cat(line, &k, " fps, ");
    143c:	9100b3e1 	add	x1, sp, #0x2c
    1440:	9100c3e0 	add	x0, sp, #0x30
    1444:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1448:	911d7442 	add	x2, x2, #0x75d
    144c:	97ffff6f 	bl	1208 <cat>
  cat_uint(line, &k, bytes);
    1450:	2a1403e2 	mov	w2, w20
    1454:	9100b3e1 	add	x1, sp, #0x2c
    1458:	9100c3e0 	add	x0, sp, #0x30
    145c:	97fffefe 	bl	1054 <cat_uint>
  cat(line, &k, " bytes/frame, ");
    1460:	9100c3e0 	add	x0, sp, #0x30
    1464:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1468:	911d9042 	add	x2, x2, #0x764
    146c:	97ffff67 	bl	1208 <cat>
  cat_uint(line, &k, nclients);
    1470:	b9405662 	ldr	w2, [x19, #84]
    1474:	9100b3e1 	add	x1, sp, #0x2c
    1478:	9100c3e0 	add	x0, sp, #0x30
    147c:	97fffef6 	bl	1054 <cat_uint>
  cat(line, &k, " viewer(s), capture/jpeg/send ");
    1480:	9100c3e0 	add	x0, sp, #0x30
    1484:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1488:	911dcc42 	add	x2, x2, #0x773
    148c:	97ffff5f 	bl	1208 <cat>
  cat_ms10(line, &k, capture_ms10);
    1490:	b9404662 	ldr	w2, [x19, #68]
    1494:	9100b3e1 	add	x1, sp, #0x2c
    1498:	9100c3e0 	add	x0, sp, #0x30
    149c:	97ffff8a 	bl	12c4 <cat_ms10>
  cat(line, &k, "/");
    14a0:	9100b3e1 	add	x1, sp, #0x2c
    14a4:	9100c3e0 	add	x0, sp, #0x30
    14a8:	d0000014 	adrp	x20, 3000 <jpeg_encode_to+0x104>
    14ac:	911e4a82 	add	x2, x20, #0x792
    14b0:	97ffff56 	bl	1208 <cat>
  cat_ms10(line, &k, jpeg_ms10);
    14b4:	b9404a62 	ldr	w2, [x19, #72]
    14b8:	9100b3e1 	add	x1, sp, #0x2c
    14bc:	9100c3e0 	add	x0, sp, #0x30
    14c0:	97ffff81 	bl	12c4 <cat_ms10>
  cat(line, &k, "/");
    14c4:	911e4a82 	add	x2, x20, #0x792
    14c8:	9100b3e1 	add	x1, sp, #0x2c
    14cc:	9100c3e0 	add	x0, sp, #0x30
    14d0:	97ffff4e 	bl	1208 <cat>
  cat_ms10(line, &k, send_ms10);
    14d4:	b9404e62 	ldr	w2, [x19, #76]
    14d8:	9100b3e1 	add	x1, sp, #0x2c
    14dc:	9100c3e0 	add	x0, sp, #0x30
    14e0:	97ffff79 	bl	12c4 <cat_ms10>
  cat(line, &k, " ms, payload ");
    14e4:	9100b3e1 	add	x1, sp, #0x2c
    14e8:	9100c3e0 	add	x0, sp, #0x30
    14ec:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    14f0:	911e5042 	add	x2, x2, #0x794
    14f4:	97ffff45 	bl	1208 <cat>
  cat_uint(line, &k, payload_kbps);
    14f8:	b9405262 	ldr	w2, [x19, #80]
    14fc:	9100b3e1 	add	x1, sp, #0x2c
    1500:	9100c3e0 	add	x0, sp, #0x30
    1504:	97fffed4 	bl	1054 <cat_uint>
  cat(line, &k, " kbit/s\n");
    1508:	9100c3e0 	add	x0, sp, #0x30
    150c:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1510:	911e8842 	add	x2, x2, #0x7a2
    1514:	97ffff3d 	bl	1208 <cat>
  write(1, line, k);
    1518:	b9402fe2 	ldr	w2, [sp, #44]
    151c:	9100c3e1 	add	x1, sp, #0x30
    1520:	52800020 	mov	w0, #0x1                   	// #1
    1524:	97fffd09 	bl	948 <write@plt>
  stats_reset();
    1528:	97fffef3 	bl	10f4 <stats_reset>
}
    152c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1530:	a8d17bfd 	ldp	x29, x30, [sp], #272
    1534:	d65f03c0 	ret

0000000000001538 <send_simple>:
{
    1538:	a9ac7bfd 	stp	x29, x30, [sp, #-320]!
    153c:	910003fd 	mov	x29, sp
    1540:	a90153f3 	stp	x19, x20, [sp, #16]
    1544:	aa0303f3 	mov	x19, x3
    1548:	2a0003f4 	mov	w20, w0
  cat(head, &n, "HTTP/1.1 ");
    154c:	910103e0 	add	x0, sp, #0x40
{
    1550:	a9025bf5 	stp	x21, x22, [sp, #32]
    1554:	aa0103f5 	mov	x21, x1
    1558:	aa0203f6 	mov	x22, x2
  cat(head, &n, "HTTP/1.1 ");
    155c:	9100f3e1 	add	x1, sp, #0x3c
    1560:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1564:	911eac42 	add	x2, x2, #0x7ab
  int n = 0;
    1568:	b9003fff 	str	wzr, [sp, #60]
  cat(head, &n, "HTTP/1.1 ");
    156c:	97ffff27 	bl	1208 <cat>
  cat(head, &n, status);
    1570:	aa1503e2 	mov	x2, x21
    1574:	9100f3e1 	add	x1, sp, #0x3c
    1578:	910103e0 	add	x0, sp, #0x40
    157c:	97ffff23 	bl	1208 <cat>
  cat(head, &n, "\r\nContent-Type: ");
    1580:	9100f3e1 	add	x1, sp, #0x3c
    1584:	910103e0 	add	x0, sp, #0x40
    1588:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    158c:	911ed442 	add	x2, x2, #0x7b5
    1590:	97ffff1e 	bl	1208 <cat>
  cat(head, &n, type);
    1594:	aa1603e2 	mov	x2, x22
    1598:	9100f3e1 	add	x1, sp, #0x3c
    159c:	910103e0 	add	x0, sp, #0x40
    15a0:	97ffff1a 	bl	1208 <cat>
  cat(head, &n, "\r\nContent-Length: ");
    15a4:	9100f3e1 	add	x1, sp, #0x3c
    15a8:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    15ac:	91268042 	add	x2, x2, #0x9a0
    15b0:	910103e0 	add	x0, sp, #0x40
    15b4:	97ffff15 	bl	1208 <cat>
  cat_uint(head, &n, strlen(body));
    15b8:	aa1303e0 	mov	x0, x19
    15bc:	97fffd13 	bl	a08 <strlen@plt>
    15c0:	2a0003e2 	mov	w2, w0
    15c4:	9100f3e1 	add	x1, sp, #0x3c
    15c8:	910103e0 	add	x0, sp, #0x40
    15cc:	97fffea2 	bl	1054 <cat_uint>
  cat(head, &n, "\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n");
    15d0:	910103e0 	add	x0, sp, #0x40
    15d4:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    15d8:	911f1842 	add	x2, x2, #0x7c6
    15dc:	97ffff0b 	bl	1208 <cat>
  if(write_all(fd, head, n) == 0)
    15e0:	b9403fe2 	ldr	w2, [sp, #60]
    15e4:	910103e1 	add	x1, sp, #0x40
    15e8:	2a1403e0 	mov	w0, w20
    15ec:	97fffeee 	bl	11a4 <write_all>
    15f0:	350000e0 	cbnz	w0, 160c <send_simple+0xd4>
    write_all(fd, body, strlen(body));
    15f4:	aa1303e0 	mov	x0, x19
    15f8:	97fffd04 	bl	a08 <strlen@plt>
    15fc:	aa1303e1 	mov	x1, x19
    1600:	2a0003e2 	mov	w2, w0
    1604:	2a1403e0 	mov	w0, w20
    1608:	97fffee7 	bl	11a4 <write_all>
}
    160c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1610:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1614:	a8d47bfd 	ldp	x29, x30, [sp], #320
    1618:	d65f03c0 	ret

000000000000161c <mutex_unlock.isra.0>:
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
    161c:	52800021 	mov	w1, #0x1                   	// #1
    1620:	17fffd02 	b	a28 <sync_signal@plt>

0000000000001624 <mutex_lock.isra.0>:
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
    1624:	17fffd0d 	b	a58 <sync_wait@plt>

0000000000001628 <handle_connection>:
{
    1628:	d11d83ff 	sub	sp, sp, #0x760
    162c:	a9007bfd 	stp	x29, x30, [sp]
    1630:	910003fd 	mov	x29, sp
    1634:	a90153f3 	stp	x19, x20, [sp, #16]
    1638:	a9025bf5 	stp	x21, x22, [sp, #32]
    163c:	a90363f7 	stp	x23, x24, [sp, #48]
    1640:	2a0103f7 	mov	w23, w1
    1644:	a9046bf9 	stp	x25, x26, [sp, #64]
  int fd = socket_accept(listener);
    1648:	97fffc9c 	bl	8b8 <socket_accept@plt>
  if(fd < 0)
    164c:	37f81200 	tbnz	w0, #31, 188c <handle_connection+0x264>
    1650:	2a0003f3 	mov	w19, w0
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0)
    1654:	910183f4 	add	x20, sp, #0x60
    int got = read(fd, buf + n, cap - 1 - n);
    1658:	910d83f6 	add	x22, sp, #0x360
  int n = 0;
    165c:	52800015 	mov	w21, #0x0                   	// #0
  ev.events = EPOLLIN;
    1660:	52800038 	mov	w24, #0x1                   	// #1
  buf[0] = 0;
    1664:	390d83ff 	strb	wzr, [sp, #864]
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0)
    1668:	aa1403e3 	mov	x3, x20
    166c:	2a1303e2 	mov	w2, w19
    1670:	2a1703e0 	mov	w0, w23
    1674:	52800021 	mov	w1, #0x1                   	// #1
  ev.events = EPOLLIN;
    1678:	b90063f8 	str	w24, [sp, #96]
  ev.data.fd = fd;
    167c:	b9006bf3 	str	w19, [sp, #104]
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0)
    1680:	97fffcae 	bl	938 <epoll_ctl@plt>
    1684:	37f80a00 	tbnz	w0, #31, 17c4 <handle_connection+0x19c>
  int r = epoll_wait(epfd, &out, 1, timeout_ms);
    1688:	910383e1 	add	x1, sp, #0xe0
    168c:	5280fa03 	mov	w3, #0x7d0                 	// #2000
    1690:	52800022 	mov	w2, #0x1                   	// #1
    1694:	2a1703e0 	mov	w0, w23
    1698:	97fffc90 	bl	8d8 <epoll_wait@plt>
    169c:	2a0003f9 	mov	w25, w0
  epoll_ctl(epfd, EPOLL_CTL_DEL, fd, &ev);
    16a0:	aa1403e3 	mov	x3, x20
    16a4:	2a1303e2 	mov	w2, w19
    16a8:	2a1703e0 	mov	w0, w23
    16ac:	52800041 	mov	w1, #0x2                   	// #2
    16b0:	97fffca2 	bl	938 <epoll_ctl@plt>
    if(!wait_readable(epfd, fd, REQ_TIMEOUT_MS))
    16b4:	7100033f 	cmp	w25, #0x0
    16b8:	5400086d 	b.le	17c4 <handle_connection+0x19c>
    int got = read(fd, buf + n, cap - 1 - n);
    16bc:	52807fe2 	mov	w2, #0x3ff                 	// #1023
    16c0:	8b35c2c1 	add	x1, x22, w21, sxtw
    16c4:	4b150042 	sub	w2, w2, w21
    16c8:	2a1303e0 	mov	w0, w19
    16cc:	97fffcab 	bl	978 <read@plt>
    if(got <= 0)
    16d0:	7100001f 	cmp	w0, #0x0
    16d4:	5400078d 	b.le	17c4 <handle_connection+0x19c>
    n += got;
    16d8:	0b0002b5 	add	w21, w21, w0
  for(const char *p = s; *p; p++)
    16dc:	aa1603e0 	mov	x0, x22
    buf[n] = 0;
    16e0:	3835cadf 	strb	wzr, [x22, w21, sxtw]
  for(const char *p = s; *p; p++)
    16e4:	39400001 	ldrb	w1, [x0]
    16e8:	35000521 	cbnz	w1, 178c <handle_connection+0x164>
  while(n < cap - 1){
    16ec:	710ffabf 	cmp	w21, #0x3fe
    16f0:	54fffbcd 	b.le	1668 <handle_connection+0x40>
  if(strncmp(req, "GET ", 4) != 0)
    16f4:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    16f8:	91206821 	add	x1, x1, #0x81a
    16fc:	aa1603e0 	mov	x0, x22
    1700:	52800082 	mov	w2, #0x4                   	// #4
    1704:	97fffca1 	bl	988 <strncmp@plt>
    1708:	350005e0 	cbnz	w0, 17c4 <handle_connection+0x19c>
    170c:	d2800000 	mov	x0, #0x0                   	// #0
  while(*p && *p != ' ' && *p != '?' && n < cap - 1)
    1710:	8b0002c2 	add	x2, x22, x0
    1714:	2a0003e1 	mov	w1, w0
    1718:	39401042 	ldrb	w2, [x2, #4]
    171c:	121a7843 	and	w3, w2, #0xffffffdf
    1720:	340000a3 	cbz	w3, 1734 <handle_connection+0x10c>
    1724:	7100fc5f 	cmp	w2, #0x3f
    1728:	54000060 	b.eq	1734 <handle_connection+0x10c>  // b.none
    172c:	f101fc1f 	cmp	x0, #0x7f
    1730:	54000501 	b.ne	17d0 <handle_connection+0x1a8>  // b.any
  path[n] = 0;
    1734:	38214a9f 	strb	wzr, [x20, w1, uxtw]
  return n > 0 ? 0 : -1;
    1738:	34000461 	cbz	w1, 17c4 <handle_connection+0x19c>
  if(strcmp(path, "/") == 0 || strcmp(path, "/index.html") == 0)
    173c:	d0000016 	adrp	x22, 3000 <jpeg_encode_to+0x104>
    1740:	911e4ad6 	add	x22, x22, #0x792
    1744:	aa1603e1 	mov	x1, x22
    1748:	aa1403e0 	mov	x0, x20
    174c:	97fffc9f 	bl	9c8 <strcmp@plt>
    1750:	340000c0 	cbz	w0, 1768 <handle_connection+0x140>
    1754:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    1758:	91207c21 	add	x1, x1, #0x81f
    175c:	aa1403e0 	mov	x0, x20
    1760:	97fffc9a 	bl	9c8 <strcmp@plt>
    1764:	350003c0 	cbnz	w0, 17dc <handle_connection+0x1b4>
  send_simple(fd, "200 OK", "text/html; charset=utf-8", page);
    1768:	d0000003 	adrp	x3, 3000 <jpeg_encode_to+0x104>
    176c:	91372c63 	add	x3, x3, #0xdcb
    1770:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1774:	9120ac42 	add	x2, x2, #0x82b
    1778:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    177c:	91211021 	add	x1, x1, #0x844
    send_simple(fd, "404 Not Found", "text/plain", "not found\n");
    1780:	2a1303e0 	mov	w0, w19
    1784:	97ffff6d 	bl	1538 <send_simple>
    1788:	1400000f 	b	17c4 <handle_connection+0x19c>
    if(p[0] == '\r' && p[1] == '\n' && p[2] == '\r' && p[3] == '\n')
    178c:	7100343f 	cmp	w1, #0xd
    1790:	54000141 	b.ne	17b8 <handle_connection+0x190>  // b.any
    1794:	39400401 	ldrb	w1, [x0, #1]
    1798:	7100283f 	cmp	w1, #0xa
    179c:	540000e1 	b.ne	17b8 <handle_connection+0x190>  // b.any
    17a0:	39400801 	ldrb	w1, [x0, #2]
    17a4:	7100343f 	cmp	w1, #0xd
    17a8:	54000081 	b.ne	17b8 <handle_connection+0x190>  // b.any
    17ac:	39400c01 	ldrb	w1, [x0, #3]
    17b0:	7100283f 	cmp	w1, #0xa
    17b4:	54000060 	b.eq	17c0 <handle_connection+0x198>  // b.none
  for(const char *p = s; *p; p++)
    17b8:	91000400 	add	x0, x0, #0x1
    17bc:	17ffffca 	b	16e4 <handle_connection+0xbc>
  if(read_request(epfd, fd, req, sizeof(req)) < 0 ||
    17c0:	36fff9b5 	tbz	w21, #31, 16f4 <handle_connection+0xcc>
  close(fd);
    17c4:	2a1303e0 	mov	w0, w19
    17c8:	97fffca0 	bl	a48 <close@plt>
    17cc:	14000030 	b	188c <handle_connection+0x264>
    path[n++] = *p++;
    17d0:	38206a82 	strb	w2, [x20, x0]
    17d4:	91000400 	add	x0, x0, #0x1
    17d8:	17ffffce 	b	1710 <handle_connection+0xe8>
  else if(strcmp(path, "/stream") == 0 || strcmp(path, "/stream.mjpg") == 0){
    17dc:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    17e0:	91212c21 	add	x1, x1, #0x84b
    17e4:	aa1403e0 	mov	x0, x20
    17e8:	97fffc78 	bl	9c8 <strcmp@plt>
    17ec:	340000c0 	cbz	w0, 1804 <handle_connection+0x1dc>
    17f0:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    17f4:	91214c21 	add	x1, x1, #0x853
    17f8:	aa1403e0 	mov	x0, x20
    17fc:	97fffc73 	bl	9c8 <strcmp@plt>
    1800:	35000540 	cbnz	w0, 18a8 <handle_connection+0x280>
  if(nclients >= maxclients){
    1804:	90000034 	adrp	x20, 5000 <qbase_c+0xdd0>
    1808:	9112a294 	add	x20, x20, #0x4a8
    180c:	90000020 	adrp	x0, 5000 <qbase_c+0xdd0>
    1810:	b9449400 	ldr	w0, [x0, #1172]
    1814:	b9405681 	ldr	w1, [x20, #84]
    1818:	6b00003f 	cmp	w1, w0
    181c:	5400010b 	b.lt	183c <handle_connection+0x214>  // b.tstop
    send_simple(fd, "503 Service Unavailable", "text/plain",
    1820:	d0000003 	adrp	x3, 3000 <jpeg_encode_to+0x104>
    1824:	91218063 	add	x3, x3, #0x860
      send_simple(fd, "503 Service Unavailable", "text/plain", "no camera\n");
    1828:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    182c:	9121c842 	add	x2, x2, #0x872
    1830:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    1834:	9121f421 	add	x1, x1, #0x87d
    1838:	17ffffd2 	b	1780 <handle_connection+0x158>
  if(write_all(fd, head, sizeof(head) - 1) < 0)
    183c:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    1840:	91372c21 	add	x1, x1, #0xdcb
    1844:	9107f021 	add	x1, x1, #0x1fc
    1848:	2a1303e0 	mov	w0, w19
    184c:	528014a2 	mov	w2, #0xa5                  	// #165
    1850:	97fffe55 	bl	11a4 <write_all>
    1854:	3100041f 	cmn	w0, #0x1
    1858:	54fffb60 	b.eq	17c4 <handle_connection+0x19c>  // b.none
  clients[nclients++] = fd;
    185c:	b9405680 	ldr	w0, [x20, #84]
  printf("camserver: viewer fd=%d joined (%d watching)\n", fd, nclients);
    1860:	2a1303e1 	mov	w1, w19
  clients[nclients++] = fd;
    1864:	11000402 	add	w2, w0, #0x1
    1868:	b9005682 	str	w2, [x20, #84]
    186c:	8b20ca80 	add	x0, x20, w0, sxtw #2
    1870:	b9005813 	str	w19, [x0, #88]
  total_viewers++;
    1874:	b9406a80 	ldr	w0, [x20, #104]
    1878:	11000400 	add	w0, w0, #0x1
    187c:	b9006a80 	str	w0, [x20, #104]
  printf("camserver: viewer fd=%d joined (%d watching)\n", fd, nclients);
    1880:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1884:	91225400 	add	x0, x0, #0x895
    1888:	97fffc10 	bl	8c8 <printf@plt>
}
    188c:	a9407bfd 	ldp	x29, x30, [sp]
    1890:	a94153f3 	ldp	x19, x20, [sp, #16]
    1894:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1898:	a94363f7 	ldp	x23, x24, [sp, #48]
    189c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    18a0:	911d83ff 	add	sp, sp, #0x760
    18a4:	d65f03c0 	ret
  } else if(strcmp(path, "/snapshot.jpg") == 0)
    18a8:	aa1403e0 	mov	x0, x20
    18ac:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    18b0:	91230c21 	add	x1, x1, #0x8c3
    18b4:	97fffc45 	bl	9c8 <strcmp@plt>
    18b8:	2a0003f5 	mov	w21, w0
    18bc:	35000f40 	cbnz	w0, 1aa4 <handle_connection+0x47c>
  int fresh = !pipeline_running() && cam < 0;
    18c0:	97fffe04 	bl	10d0 <pipeline_running>
    18c4:	35000080 	cbnz	w0, 18d4 <handle_connection+0x2ac>
    18c8:	90000035 	adrp	x21, 5000 <qbase_c+0xdd0>
    18cc:	b94492b5 	ldr	w21, [x21, #1168]
    18d0:	531f7eb5 	lsr	w21, w21, #31
  if(pipeline_running() && jpeg_len == 0){
    18d4:	97fffdff 	bl	10d0 <pipeline_running>
    18d8:	340000e0 	cbz	w0, 18f4 <handle_connection+0x2cc>
    18dc:	90000020 	adrp	x0, 5000 <qbase_c+0xdd0>
    18e0:	b9451400 	ldr	w0, [x0, #1300]
    18e4:	35000080 	cbnz	w0, 18f4 <handle_connection+0x2cc>
    send_simple(fd, "503 Service Unavailable", "text/plain",
    18e8:	d0000003 	adrp	x3, 3000 <jpeg_encode_to+0x104>
    18ec:	91234463 	add	x3, x3, #0x8d1
    18f0:	17ffffce 	b	1828 <handle_connection+0x200>
  if(!pipeline_running() && (cam < 0 || jpeg_len == 0)){
    18f4:	97fffdf7 	bl	10d0 <pipeline_running>
    18f8:	350000e0 	cbnz	w0, 1914 <handle_connection+0x2ec>
    18fc:	90000036 	adrp	x22, 5000 <qbase_c+0xdd0>
    1900:	b94492c0 	ldr	w0, [x22, #1168]
    1904:	37f804a0 	tbnz	w0, #31, 1998 <handle_connection+0x370>
    1908:	90000020 	adrp	x0, 5000 <qbase_c+0xdd0>
    190c:	b9451400 	ldr	w0, [x0, #1300]
    1910:	34000600 	cbz	w0, 19d0 <handle_connection+0x3a8>
  cat_uint(head, &n, jpeg_len);
    1914:	90000034 	adrp	x20, 5000 <qbase_c+0xdd0>
    1918:	9112a294 	add	x20, x20, #0x4a8
  cat(head, &n, "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\n"
    191c:	910173e1 	add	x1, sp, #0x5c
    1920:	910383e0 	add	x0, sp, #0xe0
    1924:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1928:	9125dc42 	add	x2, x2, #0x977
  int n = 0;
    192c:	b9005fff 	str	wzr, [sp, #92]
  cat(head, &n, "HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\n"
    1930:	97fffe36 	bl	1208 <cat>
  cat_uint(head, &n, jpeg_len);
    1934:	b9406e82 	ldr	w2, [x20, #108]
    1938:	910173e1 	add	x1, sp, #0x5c
    193c:	910383e0 	add	x0, sp, #0xe0
    1940:	97fffdc5 	bl	1054 <cat_uint>
  cat(head, &n, "\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n");
    1944:	910383e0 	add	x0, sp, #0xe0
    1948:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    194c:	911f1842 	add	x2, x2, #0x7c6
    1950:	97fffe2e 	bl	1208 <cat>
  if(write_all(fd, head, n) == 0)
    1954:	b9405fe2 	ldr	w2, [sp, #92]
    1958:	910383e1 	add	x1, sp, #0xe0
    195c:	2a1303e0 	mov	w0, w19
    1960:	97fffe11 	bl	11a4 <write_all>
    1964:	350000a0 	cbnz	w0, 1978 <handle_connection+0x350>
    write_all(fd, jpeg, jpeg_len);
    1968:	f9404281 	ldr	x1, [x20, #128]
    196c:	2a1303e0 	mov	w0, w19
    1970:	b9406e82 	ldr	w2, [x20, #108]
    1974:	97fffe0c 	bl	11a4 <write_all>
  served_snapshots++;
    1978:	b9408a80 	ldr	w0, [x20, #136]
    197c:	11000400 	add	w0, w0, #0x1
    1980:	b9008a80 	str	w0, [x20, #136]
  if(fresh && nclients == 0)
    1984:	34fff215 	cbz	w21, 17c4 <handle_connection+0x19c>
    1988:	b9405680 	ldr	w0, [x20, #84]
    198c:	35fff1c0 	cbnz	w0, 17c4 <handle_connection+0x19c>
    camera_close();
    1990:	97fffde9 	bl	1134 <camera_close>
    1994:	17ffff8c 	b	17c4 <handle_connection+0x19c>
    cam = open("/dev/video0", O_RDWR);
    1998:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    199c:	91239000 	add	x0, x0, #0x8e4
    19a0:	52800041 	mov	w1, #0x2                   	// #2
    19a4:	97fffc1d 	bl	a18 <open@plt>
    19a8:	b90492c0 	str	w0, [x22, #1168]
    if(cam < 0){
    19ac:	36f800a0 	tbz	w0, #31, 19c0 <handle_connection+0x398>
      printf("camserver: cannot open /dev/video0\n");
    19b0:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    19b4:	9123c000 	add	x0, x0, #0x8f0
    printf("camserver: JPEG conversion failed\n");
    19b8:	97fffbc4 	bl	8c8 <printf@plt>
    return -1;
    19bc:	14000018 	b	1a1c <handle_connection+0x3f4>
    printf("camserver: camera opened\n");
    19c0:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    19c4:	91245000 	add	x0, x0, #0x914
    19c8:	97fffbc0 	bl	8c8 <printf@plt>
    stats_reset();
    19cc:	97fffdca 	bl	10f4 <stats_reset>
  int n = read(cam, frame, CAM_READ_MAX);
    19d0:	90000034 	adrp	x20, 5000 <qbase_c+0xdd0>
    19d4:	9112a294 	add	x20, x20, #0x4a8
  uint64 capture_begin = clock_us();
    19d8:	97fffc00 	bl	9d8 <clock_us@plt>
    19dc:	aa0003f8 	mov	x24, x0
  int n = read(cam, frame, CAM_READ_MAX);
    19e0:	b94492c0 	ldr	w0, [x22, #1168]
    19e4:	52800502 	mov	w2, #0x28                  	// #40
    19e8:	72a00102 	movk	w2, #0x8, lsl #16
    19ec:	911242d7 	add	x23, x22, #0x490
    19f0:	f9403a81 	ldr	x1, [x20, #112]
    19f4:	97fffbe1 	bl	978 <read@plt>
    19f8:	2a0003f6 	mov	w22, w0
  uint64 capture_end = clock_us();
    19fc:	97fffbf7 	bl	9d8 <clock_us@plt>
    1a00:	aa0003f9 	mov	x25, x0
  if(n <= 0){
    1a04:	710002df 	cmp	w22, #0x0
    1a08:	5400010c 	b.gt	1a28 <handle_connection+0x400>
    printf("camserver: capture failed\n");
    1a0c:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1a10:	9124b800 	add	x0, x0, #0x92e
    1a14:	97fffbad 	bl	8c8 <printf@plt>
    camera_close();
    1a18:	97fffdc7 	bl	1134 <camera_close>
      send_simple(fd, "503 Service Unavailable", "text/plain", "no camera\n");
    1a1c:	d0000003 	adrp	x3, 3000 <jpeg_encode_to+0x104>
    1a20:	9125b063 	add	x3, x3, #0x96c
    1a24:	17ffff81 	b	1828 <handle_connection+0x200>
  uint len = 0;
    1a28:	b900e3ff 	str	wzr, [sp, #224]
  uint64 jpeg_begin = clock_us();
    1a2c:	97fffbeb 	bl	9d8 <clock_us@plt>
    1a30:	aa0003fa 	mov	x26, x0
  mutex_lock(&convert_lock);
    1a34:	b9407a80 	ldr	w0, [x20, #120]
    1a38:	97fffefb 	bl	1624 <mutex_lock.isra.0>
  int convert_result = camproc_jpeg(jpeg, JPEG_CAP, frame, n, half, wb,
    1a3c:	f9403a82 	ldr	x2, [x20, #112]
    1a40:	2a1603e3 	mov	w3, w22
    1a44:	f9404280 	ldr	x0, [x20, #128]
    1a48:	910383e7 	add	x7, sp, #0xe0
    1a4c:	b9407e84 	ldr	w4, [x20, #124]
    1a50:	52a00081 	mov	w1, #0x40000               	// #262144
    1a54:	294116e6 	ldp	w6, w5, [x23, #8]
    1a58:	9400036b 	bl	2804 <camproc_jpeg>
    1a5c:	2a0003f6 	mov	w22, w0
  mutex_unlock(&convert_lock);
    1a60:	b9407a80 	ldr	w0, [x20, #120]
    1a64:	97fffeee 	bl	161c <mutex_unlock.isra.0>
  if(convert_result < 0 || len == 0){
    1a68:	37f80076 	tbnz	w22, #31, 1a74 <handle_connection+0x44c>
    1a6c:	b940e3e0 	ldr	w0, [sp, #224]
    1a70:	35000080 	cbnz	w0, 1a80 <handle_connection+0x458>
    printf("camserver: JPEG conversion failed\n");
    1a74:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1a78:	91252400 	add	x0, x0, #0x949
    1a7c:	17ffffcf 	b	19b8 <handle_connection+0x390>
  uint64 jpeg_end = clock_us();
    1a80:	97fffbd6 	bl	9d8 <clock_us@plt>
  stats_frame(capture_end - capture_begin, jpeg_end - jpeg_begin, 0,
    1a84:	cb1a0001 	sub	x1, x0, x26
  jpeg_len = len;
    1a88:	b940e3e3 	ldr	w3, [sp, #224]
  stats_frame(capture_end - capture_begin, jpeg_end - jpeg_begin, 0,
    1a8c:	cb180320 	sub	x0, x25, x24
    1a90:	52800004 	mov	w4, #0x0                   	// #0
    1a94:	d2800002 	mov	x2, #0x0                   	// #0
  jpeg_len = len;
    1a98:	b9006e83 	str	w3, [x20, #108]
  stats_frame(capture_end - capture_begin, jpeg_end - jpeg_begin, 0,
    1a9c:	97fffe20 	bl	131c <stats_frame>
  return 0;
    1aa0:	17ffff9d 	b	1914 <handle_connection+0x2ec>
  else if(strcmp(path, "/status") == 0)
    1aa4:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    1aa8:	9126cc21 	add	x1, x1, #0x9b3
    1aac:	aa1403e0 	mov	x0, x20
    1ab0:	97fffbc6 	bl	9c8 <strcmp@plt>
    1ab4:	350012e0 	cbnz	w0, 1d10 <handle_connection+0x6e8>
  cat(body, &n, "camera: ");
    1ab8:	910383e0 	add	x0, sp, #0xe0
    1abc:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1ac0:	9126ec42 	add	x2, x2, #0x9bb
    1ac4:	910173e1 	add	x1, sp, #0x5c
    1ac8:	90000035 	adrp	x21, 5000 <qbase_c+0xdd0>
  int n = 0;
    1acc:	b9005fff 	str	wzr, [sp, #92]
  body[0] = 0;
    1ad0:	390383ff 	strb	wzr, [sp, #224]
  cat(body, &n, "camera: ");
    1ad4:	97fffdcd 	bl	1208 <cat>
  cat(body, &n, (pipeline_running() || cam >= 0) ? "streaming\n" : "idle\n");
    1ad8:	97fffd7e 	bl	10d0 <pipeline_running>
    1adc:	35001140 	cbnz	w0, 1d04 <handle_connection+0x6dc>
    1ae0:	b94492a1 	ldr	w1, [x21, #1168]
    1ae4:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1ae8:	911fdc00 	add	x0, x0, #0x7f7
    1aec:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1af0:	911ff442 	add	x2, x2, #0x7fd
    1af4:	7100003f 	cmp	w1, #0x0
    1af8:	9a80a042 	csel	x2, x2, x0, ge	// ge = tcont
  cat(body, &n, half ? "320x240\n" : "640x480\n");
    1afc:	90000034 	adrp	x20, 5000 <qbase_c+0xdd0>
    1b00:	9112a294 	add	x20, x20, #0x4a8
  cat(body, &n, (pipeline_running() || cam >= 0) ? "streaming\n" : "idle\n");
    1b04:	910173e1 	add	x1, sp, #0x5c
    1b08:	910383e0 	add	x0, sp, #0xe0
    1b0c:	97fffdbf 	bl	1208 <cat>
  cat_uint(body, &n, quality);
    1b10:	911242b5 	add	x21, x21, #0x490
  cat(body, &n, "size: ");
    1b14:	910173e1 	add	x1, sp, #0x5c
    1b18:	910383e0 	add	x0, sp, #0xe0
    1b1c:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1b20:	91271042 	add	x2, x2, #0x9c4
    1b24:	97fffdb9 	bl	1208 <cat>
  cat(body, &n, half ? "320x240\n" : "640x480\n");
    1b28:	b9407e81 	ldr	w1, [x20, #124]
    1b2c:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1b30:	91202000 	add	x0, x0, #0x808
    1b34:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1b38:	91204442 	add	x2, x2, #0x811
    1b3c:	7100003f 	cmp	w1, #0x0
    1b40:	9a800042 	csel	x2, x2, x0, eq	// eq = none
    1b44:	910173e1 	add	x1, sp, #0x5c
    1b48:	910383e0 	add	x0, sp, #0xe0
    1b4c:	97fffdaf 	bl	1208 <cat>
  cat(body, &n, "quality: ");
    1b50:	910173e1 	add	x1, sp, #0x5c
    1b54:	910383e0 	add	x0, sp, #0xe0
    1b58:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1b5c:	91272c42 	add	x2, x2, #0x9cb
    1b60:	97fffdaa 	bl	1208 <cat>
  cat_uint(body, &n, quality);
    1b64:	b9400aa2 	ldr	w2, [x21, #8]
    1b68:	910173e1 	add	x1, sp, #0x5c
    1b6c:	910383e0 	add	x0, sp, #0xe0
    1b70:	97fffd39 	bl	1054 <cat_uint>
  cat(body, &n, "\nviewers: ");
    1b74:	910383e0 	add	x0, sp, #0xe0
    1b78:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1b7c:	91275442 	add	x2, x2, #0x9d5
    1b80:	97fffda2 	bl	1208 <cat>
  cat_uint(body, &n, nclients);
    1b84:	b9405682 	ldr	w2, [x20, #84]
    1b88:	910173e1 	add	x1, sp, #0x5c
    1b8c:	910383e0 	add	x0, sp, #0xe0
    1b90:	97fffd31 	bl	1054 <cat_uint>
  cat(body, &n, "/");
    1b94:	aa1603e2 	mov	x2, x22
    1b98:	910383e0 	add	x0, sp, #0xe0
    1b9c:	97fffd9b 	bl	1208 <cat>
  cat_uint(body, &n, maxclients);
    1ba0:	b94006a2 	ldr	w2, [x21, #4]
    1ba4:	910173e1 	add	x1, sp, #0x5c
    1ba8:	910383e0 	add	x0, sp, #0xe0
    1bac:	97fffd2a 	bl	1054 <cat_uint>
  cat(body, &n, "\nviewers served: ");
    1bb0:	910383e0 	add	x0, sp, #0xe0
    1bb4:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1bb8:	91278042 	add	x2, x2, #0x9e0
    1bbc:	97fffd93 	bl	1208 <cat>
  cat_uint(body, &n, total_viewers);
    1bc0:	b9406a82 	ldr	w2, [x20, #104]
    1bc4:	910173e1 	add	x1, sp, #0x5c
    1bc8:	910383e0 	add	x0, sp, #0xe0
    1bcc:	97fffd22 	bl	1054 <cat_uint>
  cat(body, &n, "\nframes: ");
    1bd0:	910383e0 	add	x0, sp, #0xe0
    1bd4:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1bd8:	9127c842 	add	x2, x2, #0x9f2
    1bdc:	97fffd8b 	bl	1208 <cat>
  cat_uint(body, &n, frames);
    1be0:	b9404282 	ldr	w2, [x20, #64]
    1be4:	910173e1 	add	x1, sp, #0x5c
    1be8:	910383e0 	add	x0, sp, #0xe0
    1bec:	97fffd1a 	bl	1054 <cat_uint>
  cat(body, &n, "\nfps: ");
    1bf0:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1bf4:	9127f042 	add	x2, x2, #0x9fc
    1bf8:	910383e0 	add	x0, sp, #0xe0
    1bfc:	97fffd83 	bl	1208 <cat>
  cat_fps(body, &n);
    1c00:	910173e1 	add	x1, sp, #0x5c
    1c04:	910383e0 	add	x0, sp, #0xe0
    1c08:	97fffd96 	bl	1260 <cat_fps>
  cat(body, &n, "\nlast frame bytes: ");
    1c0c:	910173e1 	add	x1, sp, #0x5c
    1c10:	910383e0 	add	x0, sp, #0xe0
    1c14:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1c18:	91280c42 	add	x2, x2, #0xa03
    1c1c:	97fffd7b 	bl	1208 <cat>
  cat_uint(body, &n, jpeg_len);
    1c20:	b9406e82 	ldr	w2, [x20, #108]
    1c24:	910173e1 	add	x1, sp, #0x5c
    1c28:	910383e0 	add	x0, sp, #0xe0
    1c2c:	97fffd0a 	bl	1054 <cat_uint>
  cat(body, &n, "\navg capture ms: ");
    1c30:	910383e0 	add	x0, sp, #0xe0
    1c34:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1c38:	91285c42 	add	x2, x2, #0xa17
    1c3c:	97fffd73 	bl	1208 <cat>
  cat_ms10(body, &n, capture_ms10);
    1c40:	b9404682 	ldr	w2, [x20, #68]
    1c44:	910173e1 	add	x1, sp, #0x5c
    1c48:	910383e0 	add	x0, sp, #0xe0
    1c4c:	97fffd9e 	bl	12c4 <cat_ms10>
  cat(body, &n, "\navg jpeg ms: ");
    1c50:	910173e1 	add	x1, sp, #0x5c
    1c54:	910383e0 	add	x0, sp, #0xe0
    1c58:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1c5c:	9128a442 	add	x2, x2, #0xa29
    1c60:	97fffd6a 	bl	1208 <cat>
  cat_ms10(body, &n, jpeg_ms10);
    1c64:	b9404a82 	ldr	w2, [x20, #72]
    1c68:	910173e1 	add	x1, sp, #0x5c
    1c6c:	910383e0 	add	x0, sp, #0xe0
    1c70:	97fffd95 	bl	12c4 <cat_ms10>
  cat(body, &n, "\navg send ms: ");
    1c74:	910173e1 	add	x1, sp, #0x5c
    1c78:	910383e0 	add	x0, sp, #0xe0
    1c7c:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1c80:	9128e042 	add	x2, x2, #0xa38
    1c84:	97fffd61 	bl	1208 <cat>
  cat_ms10(body, &n, send_ms10);
    1c88:	b9404e82 	ldr	w2, [x20, #76]
    1c8c:	910173e1 	add	x1, sp, #0x5c
    1c90:	910383e0 	add	x0, sp, #0xe0
    1c94:	97fffd8c 	bl	12c4 <cat_ms10>
  cat(body, &n, "\npayload kbit/s per viewer: ");
    1c98:	910173e1 	add	x1, sp, #0x5c
    1c9c:	910383e0 	add	x0, sp, #0xe0
    1ca0:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1ca4:	91291c42 	add	x2, x2, #0xa47
    1ca8:	97fffd58 	bl	1208 <cat>
  cat_uint(body, &n, payload_kbps);
    1cac:	b9405282 	ldr	w2, [x20, #80]
    1cb0:	910173e1 	add	x1, sp, #0x5c
    1cb4:	910383e0 	add	x0, sp, #0xe0
    1cb8:	97fffce7 	bl	1054 <cat_uint>
  cat(body, &n, "\nsnapshots: ");
    1cbc:	910383e0 	add	x0, sp, #0xe0
    1cc0:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1cc4:	91299042 	add	x2, x2, #0xa64
    1cc8:	97fffd50 	bl	1208 <cat>
  cat_uint(body, &n, served_snapshots);
    1ccc:	b9408a82 	ldr	w2, [x20, #136]
    1cd0:	910173e1 	add	x1, sp, #0x5c
    1cd4:	910383e0 	add	x0, sp, #0xe0
    1cd8:	97fffcdf 	bl	1054 <cat_uint>
  cat(body, &n, "\n");
    1cdc:	910383e0 	add	x0, sp, #0xe0
    1ce0:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1ce4:	911fd442 	add	x2, x2, #0x7f5
    1ce8:	97fffd48 	bl	1208 <cat>
  send_simple(fd, "200 OK", "text/plain; charset=utf-8", body);
    1cec:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1cf0:	9129c442 	add	x2, x2, #0xa71
    1cf4:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    1cf8:	91211021 	add	x1, x1, #0x844
    1cfc:	910383e3 	add	x3, sp, #0xe0
    1d00:	17fffea0 	b	1780 <handle_connection+0x158>
  cat(body, &n, (pipeline_running() || cam >= 0) ? "streaming\n" : "idle\n");
    1d04:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1d08:	911ff442 	add	x2, x2, #0x7fd
    1d0c:	17ffff7c 	b	1afc <handle_connection+0x4d4>
    send_simple(fd, "404 Not Found", "text/plain", "not found\n");
    1d10:	d0000003 	adrp	x3, 3000 <jpeg_encode_to+0x104>
    1d14:	912a2c63 	add	x3, x3, #0xa8b
    1d18:	d0000002 	adrp	x2, 3000 <jpeg_encode_to+0x104>
    1d1c:	9121c842 	add	x2, x2, #0x872
    1d20:	d0000001 	adrp	x1, 3000 <jpeg_encode_to+0x104>
    1d24:	912a5821 	add	x1, x1, #0xa96
    1d28:	17fffe96 	b	1780 <handle_connection+0x158>

0000000000001d2c <raw_push>:
{
    1d2c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1d30:	910003fd 	mov	x29, sp
    1d34:	a90153f3 	stp	x19, x20, [sp, #16]
  sem_wait(&raw_free);
    1d38:	90000033 	adrp	x19, 5000 <qbase_c+0xdd0>
    1d3c:	9112a273 	add	x19, x19, #0x4a8
{
    1d40:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d44:	aa0003f6 	mov	x22, x0
  uint tail = __atomic_load_n(&raw_tail, __ATOMIC_RELAXED);
    1d48:	91024275 	add	x21, x19, #0x90
  sem_wait(&raw_free);
    1d4c:	b9408e60 	ldr	w0, [x19, #140]
    1d50:	97fffe35 	bl	1624 <mutex_lock.isra.0>
  uint tail = __atomic_load_n(&raw_tail, __ATOMIC_RELAXED);
    1d54:	b94002b4 	ldr	w20, [x21]
  rawq[tail % PIPE_DEPTH] = *job;
    1d58:	91026263 	add	x3, x19, #0x98
    1d5c:	d37a0280 	ubfiz	x0, x20, #6, #1
    1d60:	aa1603e1 	mov	x1, x22
    1d64:	8b000060 	add	x0, x3, x0
    1d68:	d2800802 	mov	x2, #0x40                  	// #64
  __atomic_store_n(&raw_tail, tail + 1, __ATOMIC_RELEASE);
    1d6c:	11000694 	add	w20, w20, #0x1
  rawq[tail % PIPE_DEPTH] = *job;
    1d70:	97fffae2 	bl	8f8 <memcpy@plt>
  __atomic_store_n(&raw_tail, tail + 1, __ATOMIC_RELEASE);
    1d74:	889ffeb4 	stlr	w20, [x21]
}
    1d78:	a9425bf5 	ldp	x21, x22, [sp, #32]
  sem_post(&raw_ready);
    1d7c:	b9411a60 	ldr	w0, [x19, #280]
}
    1d80:	a94153f3 	ldp	x19, x20, [sp, #16]
    1d84:	a8c37bfd 	ldp	x29, x30, [sp], #48
  sem_post(&raw_ready);
    1d88:	17fffe25 	b	161c <mutex_unlock.isra.0>

0000000000001d8c <capture_worker>:
{
    1d8c:	a9b17bfd 	stp	x29, x30, [sp, #-240]!
    1d90:	910003fd 	mov	x29, sp
    1d94:	a90153f3 	stp	x19, x20, [sp, #16]
    sem_wait(&pipeline_start);
    1d98:	90000033 	adrp	x19, 5000 <qbase_c+0xdd0>
    1d9c:	9112a273 	add	x19, x19, #0x4a8
{
    1da0:	a90363f7 	stp	x23, x24, [sp, #48]
        printf("camserver: pipeline capture failed\n");
    1da4:	d0000018 	adrp	x24, 3000 <jpeg_encode_to+0x104>
    1da8:	912ca318 	add	x24, x24, #0xb28
{
    1dac:	a9025bf5 	stp	x21, x22, [sp, #32]
    1db0:	a9046bf9 	stp	x25, x26, [sp, #64]
    1db4:	a90573fb 	stp	x27, x28, [sp, #80]
    sem_wait(&pipeline_start);
    1db8:	b9411e60 	ldr	w0, [x19, #284]
    1dbc:	97fffe1a 	bl	1624 <mutex_lock.isra.0>
    if(!pipeline_running())
    1dc0:	97fffcc4 	bl	10d0 <pipeline_running>
    1dc4:	34ffffa0 	cbz	w0, 1db8 <capture_worker+0x2c>
    uint generation = pipeline_current_generation();
    1dc8:	97fffcc6 	bl	10e0 <pipeline_current_generation>
    memset(&failure, 0, sizeof(failure));
    1dcc:	52800802 	mov	w2, #0x40                  	// #64
    uint generation = pipeline_current_generation();
    1dd0:	2a0003f6 	mov	w22, w0
    memset(&failure, 0, sizeof(failure));
    1dd4:	52800001 	mov	w1, #0x0                   	// #0
    1dd8:	9101c3e0 	add	x0, sp, #0x70
    1ddc:	97fffaf3 	bl	9a8 <memset@plt>
    failure.camera_index = -1;
    1de0:	b24083e0 	mov	x0, #0x1ffffffff           	// #8589934591
    fd[0] = open("/dev/video0", O_RDWR);
    1de4:	d0000015 	adrp	x21, 3000 <jpeg_encode_to+0x104>
    1de8:	52800041 	mov	w1, #0x2                   	// #2
    failure.generation = generation;
    1dec:	b900a3f6 	str	w22, [sp, #160]
    failure.camera_index = -1;
    1df0:	f80a43e0 	stur	x0, [sp, #164]
    fd[0] = open("/dev/video0", O_RDWR);
    1df4:	912392a0 	add	x0, x21, #0x8e4
    1df8:	97fffb08 	bl	a18 <open@plt>
    1dfc:	2a0003f4 	mov	w20, w0
    fd[1] = open("/dev/video0", O_RDWR);
    1e00:	52800041 	mov	w1, #0x2                   	// #2
    1e04:	912392a0 	add	x0, x21, #0x8e4
    fd[0] = open("/dev/video0", O_RDWR);
    1e08:	b9006bf4 	str	w20, [sp, #104]
    fd[1] = open("/dev/video0", O_RDWR);
    1e0c:	97fffb03 	bl	a18 <open@plt>
    1e10:	2a0003f5 	mov	w21, w0
    1e14:	b9006ff5 	str	w21, [sp, #108]
    if(fd[0] < 0 || fd[1] < 0){
    1e18:	2a000280 	orr	w0, w20, w0
    1e1c:	36f801a0 	tbz	w0, #31, 1e50 <capture_worker+0xc4>
      printf("camserver: pipeline cannot open two camera files\n");
    1e20:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1e24:	912a9000 	add	x0, x0, #0xaa4
    1e28:	97fffaa8 	bl	8c8 <printf@plt>
      raw_push(&failure);
    1e2c:	9101c3e0 	add	x0, sp, #0x70
    1e30:	97ffffbf 	bl	1d2c <raw_push>
      if(fd[0] >= 0) close(fd[0]);
    1e34:	37f80074 	tbnz	w20, #31, 1e40 <capture_worker+0xb4>
    1e38:	2a1403e0 	mov	w0, w20
    1e3c:	97fffb03 	bl	a48 <close@plt>
      if(fd[1] >= 0) close(fd[1]);
    1e40:	37fffbd5 	tbnz	w21, #31, 1db8 <capture_worker+0x2c>
        close(fd[1]);
    1e44:	2a1503e0 	mov	w0, w21
    1e48:	97fffb00 	bl	a48 <close@plt>
        continue;
    1e4c:	17ffffdb 	b	1db8 <capture_worker+0x2c>
    if(camera_dma == 0){
    1e50:	f9409260 	ldr	x0, [x19, #288]
    1e54:	b5000240 	cbnz	x0, 1e9c <capture_worker+0x110>
      void *p = mmap(0, CAM_MMAP_BYTES, PROT_READ, MAP_SHARED, fd[0], 0);
    1e58:	52800023 	mov	w3, #0x1                   	// #1
    1e5c:	2a1403e4 	mov	w4, w20
    1e60:	2a0303e2 	mov	w2, w3
    1e64:	d2800005 	mov	x5, #0x0                   	// #0
    1e68:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1e6c:	97fffaaf 	bl	928 <mmap@plt>
      if(p == MAP_FAILED){
    1e70:	b100041f 	cmn	x0, #0x1
    1e74:	54000121 	b.ne	1e98 <capture_worker+0x10c>  // b.any
        printf("camserver: camera DMA mmap failed\n");
    1e78:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1e7c:	912b5800 	add	x0, x0, #0xad6
    1e80:	97fffa92 	bl	8c8 <printf@plt>
        raw_push(&failure);
    1e84:	9101c3e0 	add	x0, sp, #0x70
    1e88:	97ffffa9 	bl	1d2c <raw_push>
        close(fd[0]);
    1e8c:	2a1403e0 	mov	w0, w20
    1e90:	97fffaee 	bl	a48 <close@plt>
    1e94:	17ffffec 	b	1e44 <capture_worker+0xb8>
      camera_dma = p;
    1e98:	f9009260 	str	x0, [x19, #288]
      if(n != sizeof(job.hdr) || job.hdr.magic != CAM_MAGIC ||
    1e9c:	5288287a 	mov	w26, #0x4143                	// #16707
    1ea0:	72a629ba 	movk	w26, #0x314d, lsl #16
    uint sequence = 0;
    1ea4:	52800017 	mov	w23, #0x0                   	// #0
    printf("camserver: capture/JPEG/send pipeline started\n");
    1ea8:	d0000000 	adrp	x0, 3000 <jpeg_encode_to+0x104>
    1eac:	912be400 	add	x0, x0, #0xaf9
    1eb0:	97fffa86 	bl	8c8 <printf@plt>
    while(pipeline_running() &&
    1eb4:	97fffc87 	bl	10d0 <pipeline_running>
    1eb8:	34000240 	cbz	w0, 1f00 <capture_worker+0x174>
          generation == pipeline_current_generation()){
    1ebc:	97fffc89 	bl	10e0 <pipeline_current_generation>
    while(pipeline_running() &&
    1ec0:	6b16001f 	cmp	w0, w22
    1ec4:	540001e1 	b.ne	1f00 <capture_worker+0x174>  // b.any
      sem_wait(&camera_free[ci]);
    1ec8:	d37e02fc 	ubfiz	x28, x23, #2, #1
      int ci = sequence++ % PIPE_DEPTH;
    1ecc:	120002fb 	and	w27, w23, #0x1
      sem_wait(&camera_free[ci]);
    1ed0:	8b1c0260 	add	x0, x19, x28
    1ed4:	924002f9 	and	x25, x23, #0x1
    1ed8:	b9412800 	ldr	w0, [x0, #296]
    1edc:	97fffdd2 	bl	1624 <mutex_lock.isra.0>
      if(!pipeline_running() || generation != pipeline_current_generation()){
    1ee0:	97fffc7c 	bl	10d0 <pipeline_running>
    1ee4:	34000080 	cbz	w0, 1ef4 <capture_worker+0x168>
    1ee8:	97fffc7e 	bl	10e0 <pipeline_current_generation>
    1eec:	6b16001f 	cmp	w0, w22
    1ef0:	54000220 	b.eq	1f34 <capture_worker+0x1a8>  // b.none
        sem_post(&camera_free[ci]);
    1ef4:	8b190a79 	add	x25, x19, x25, lsl #2
    1ef8:	b9412b20 	ldr	w0, [x25, #296]
    1efc:	97fffdc8 	bl	161c <mutex_unlock.isra.0>
    sem_wait(&camera_free[0]);
    1f00:	b9412a60 	ldr	w0, [x19, #296]
    1f04:	97fffdc8 	bl	1624 <mutex_lock.isra.0>
    sem_wait(&camera_free[1]);
    1f08:	b9412e60 	ldr	w0, [x19, #300]
    1f0c:	97fffdc6 	bl	1624 <mutex_lock.isra.0>
    close(fd[0]);
    1f10:	2a1403e0 	mov	w0, w20
    1f14:	97fffacd 	bl	a48 <close@plt>
    close(fd[1]);
    1f18:	2a1503e0 	mov	w0, w21
    1f1c:	97fffacb 	bl	a48 <close@plt>
    sem_post(&camera_free[0]);
    1f20:	b9412a60 	ldr	w0, [x19, #296]
    1f24:	97fffdbe 	bl	161c <mutex_unlock.isra.0>
    sem_post(&camera_free[1]);
    1f28:	b9412e60 	ldr	w0, [x19, #300]
    1f2c:	97fffdbc 	bl	161c <mutex_unlock.isra.0>
    1f30:	17ffffa2 	b	1db8 <capture_worker+0x2c>
      memset(&job, 0, sizeof(job));
    1f34:	52800802 	mov	w2, #0x40                  	// #64
    1f38:	52800001 	mov	w1, #0x0                   	// #0
    1f3c:	9102c3e0 	add	x0, sp, #0xb0
    1f40:	97fffa9a 	bl	9a8 <memset@plt>
      job.generation = generation;
    1f44:	291c6ff6 	stp	w22, w27, [sp, #224]
      uint64 begin = clock_us();
    1f48:	97fffaa4 	bl	9d8 <clock_us@plt>
    1f4c:	aa0003fb 	mov	x27, x0
      int n = read(fd[ci], &job.hdr, sizeof(job.hdr));
    1f50:	9101a3e0 	add	x0, sp, #0x68
    1f54:	9102c3e1 	add	x1, sp, #0xb0
    1f58:	52800502 	mov	w2, #0x28                  	// #40
    1f5c:	b87c6800 	ldr	w0, [x0, x28]
    1f60:	97fffa86 	bl	978 <read@plt>
    1f64:	2a0003f9 	mov	w25, w0
      job.capture_us = clock_us() - begin;
    1f68:	97fffa9c 	bl	9d8 <clock_us@plt>
    1f6c:	cb1b0000 	sub	x0, x0, x27
    1f70:	f9006fe0 	str	x0, [sp, #216]
      if(n != sizeof(job.hdr) || job.hdr.magic != CAM_MAGIC ||
    1f74:	7100a33f 	cmp	w25, #0x28
    1f78:	54000141 	b.ne	1fa0 <capture_worker+0x214>  // b.any
    1f7c:	b940b3e0 	ldr	w0, [sp, #176]
    1f80:	6b1a001f 	cmp	w0, w26
    1f84:	540000e1 	b.ne	1fa0 <capture_worker+0x214>  // b.any
    1f88:	b940cfe0 	ldr	w0, [sp, #204]
    1f8c:	7100041f 	cmp	w0, #0x1
    1f90:	54000088 	b.hi	1fa0 <capture_worker+0x214>  // b.pmore
         job.hdr.reserved >= CAM_BUFFER_COUNT ||
    1f94:	b940c7e0 	ldr	w0, [sp, #196]
    1f98:	7142001f 	cmp	w0, #0x80, lsl #12
    1f9c:	540000a9 	b.ls	1fb0 <capture_worker+0x224>  // b.plast
        printf("camserver: pipeline capture failed\n");
    1fa0:	aa1803e0 	mov	x0, x24
    1fa4:	97fffa49 	bl	8c8 <printf@plt>
        job.error = 1;
    1fa8:	52800020 	mov	w0, #0x1                   	// #1
    1fac:	b900ebe0 	str	w0, [sp, #232]
      raw_push(&job);
    1fb0:	9102c3e0 	add	x0, sp, #0xb0
    1fb4:	97ffff5e 	bl	1d2c <raw_push>
      if(job.error)
    1fb8:	b940ebe0 	ldr	w0, [sp, #232]
    1fbc:	35fffa20 	cbnz	w0, 1f00 <capture_worker+0x174>
      int ci = sequence++ % PIPE_DEPTH;
    1fc0:	110006f7 	add	w23, w23, #0x1
    1fc4:	17ffffbc 	b	1eb4 <capture_worker+0x128>

0000000000001fc8 <jpeg_worker>:
{
    1fc8:	a9b47bfd 	stp	x29, x30, [sp, #-192]!
    1fcc:	910003fd 	mov	x29, sp
    1fd0:	a90153f3 	stp	x19, x20, [sp, #16]
  sem_wait(&raw_ready);
    1fd4:	90000033 	adrp	x19, 5000 <qbase_c+0xdd0>
    1fd8:	9112a273 	add	x19, x19, #0x4a8
{
    1fdc:	a9025bf5 	stp	x21, x22, [sp, #32]
  uint head = __atomic_load_n(&raw_head, __ATOMIC_RELAXED);
    1fe0:	9104c276 	add	x22, x19, #0x130
  uint tail = __atomic_load_n(&encoded_tail, __ATOMIC_RELAXED);
    1fe4:	9104e275 	add	x21, x19, #0x138
{
    1fe8:	a90363f7 	stp	x23, x24, [sp, #48]
  sem_wait(&raw_ready);
    1fec:	b9411a60 	ldr	w0, [x19, #280]
    1ff0:	97fffd8d 	bl	1624 <mutex_lock.isra.0>
  uint head = __atomic_load_n(&raw_head, __ATOMIC_RELAXED);
    1ff4:	b94002d4 	ldr	w20, [x22]
  struct raw_job job = rawq[head % PIPE_DEPTH];
    1ff8:	d37a0280 	ubfiz	x0, x20, #6, #1
    1ffc:	91026261 	add	x1, x19, #0x98
    2000:	8b000021 	add	x1, x1, x0
    2004:	d2800802 	mov	x2, #0x40                  	// #64
    2008:	910203e0 	add	x0, sp, #0x80
  __atomic_store_n(&raw_head, head + 1, __ATOMIC_RELEASE);
    200c:	11000694 	add	w20, w20, #0x1
  struct raw_job job = rawq[head % PIPE_DEPTH];
    2010:	97fffa3a 	bl	8f8 <memcpy@plt>
  __atomic_store_n(&raw_head, head + 1, __ATOMIC_RELEASE);
    2014:	889ffed4 	stlr	w20, [x22]
  sem_post(&raw_free);
    2018:	b9408e60 	ldr	w0, [x19, #140]
    201c:	97fffd80 	bl	161c <mutex_unlock.isra.0>
  return job;
    2020:	d2800802 	mov	x2, #0x40                  	// #64
    2024:	910203e1 	add	x1, sp, #0x80
    2028:	8b2263e0 	add	x0, sp, x2
    202c:	97fffa33 	bl	8f8 <memcpy@plt>
    sem_wait(&encoded_free);
    2030:	b9413660 	ldr	w0, [x19, #308]
    2034:	97fffd7c 	bl	1624 <mutex_lock.isra.0>
    uint tail = __atomic_load_n(&encoded_tail, __ATOMIC_RELAXED);
    2038:	9104e260 	add	x0, x19, #0x138
    203c:	b9400014 	ldr	w20, [x0]
    memset(&out, 0, sizeof(out));
    2040:	52800402 	mov	w2, #0x20                  	// #32
    2044:	910203e0 	add	x0, sp, #0x80
    2048:	52800001 	mov	w1, #0x0                   	// #0
    204c:	97fffa57 	bl	9a8 <memset@plt>
    out.capture_us = raw.capture_us;
    2050:	f94037e0 	ldr	x0, [sp, #104]
    2054:	f90043e0 	str	x0, [sp, #128]
    out.generation = raw.generation;
    2058:	b94073e0 	ldr	w0, [sp, #112]
    int bi = tail % PIPE_DEPTH;
    205c:	12000294 	and	w20, w20, #0x1
    out.generation = raw.generation;
    2060:	b90093e0 	str	w0, [sp, #144]
    out.error = raw.error;
    2064:	b9407be0 	ldr	w0, [sp, #120]
    2068:	291303f4 	stp	w20, w0, [sp, #152]
    if(!out.error){
    206c:	35000400 	cbnz	w0, 20ec <jpeg_worker+0x124>
      const uchar *pixels = camera_dma + raw.hdr.reserved * CAM_SLOT_BYTES;
    2070:	b9405fe0 	ldr	w0, [sp, #92]
      int result = camproc_jpeg_raw(encoded_buf[bi], JPEG_CAP, &raw.hdr,
    2074:	d37d0294 	ubfiz	x20, x20, #3, #1
      const uchar *pixels = camera_dma + raw.hdr.reserved * CAM_SLOT_BYTES;
    2078:	f9409278 	ldr	x24, [x19, #288]
      int result = camproc_jpeg_raw(encoded_buf[bi], JPEG_CAP, &raw.hdr,
    207c:	8b140274 	add	x20, x19, x20
      const uchar *pixels = camera_dma + raw.hdr.reserved * CAM_SLOT_BYTES;
    2080:	530d3000 	lsl	w0, w0, #19
    2084:	8b000318 	add	x24, x24, x0
      uint64 begin = clock_us();
    2088:	97fffa54 	bl	9d8 <clock_us@plt>
    208c:	aa0003f7 	mov	x23, x0
      mutex_lock(&convert_lock);
    2090:	b9407a60 	ldr	w0, [x19, #120]
    2094:	97fffd64 	bl	1624 <mutex_lock.isra.0>
      int result = camproc_jpeg_raw(encoded_buf[bi], JPEG_CAP, &raw.hdr,
    2098:	f0000000 	adrp	x0, 5000 <qbase_c+0xdd0>
    209c:	91124000 	add	x0, x0, #0x490
    20a0:	b9407e64 	ldr	w4, [x19, #124]
    20a4:	910253e7 	add	x7, sp, #0x94
    20a8:	aa1803e3 	mov	x3, x24
    20ac:	910103e2 	add	x2, sp, #0x40
    20b0:	29411406 	ldp	w6, w5, [x0, #8]
    20b4:	52a00081 	mov	w1, #0x40000               	// #262144
    20b8:	f940a280 	ldr	x0, [x20, #320]
    20bc:	940000e4 	bl	244c <camproc_jpeg_raw>
    20c0:	2a0003f4 	mov	w20, w0
      mutex_unlock(&convert_lock);
    20c4:	b9407a60 	ldr	w0, [x19, #120]
    20c8:	97fffd55 	bl	161c <mutex_unlock.isra.0>
      if(result < 0 || out.len == 0)
    20cc:	37f80074 	tbnz	w20, #31, 20d8 <jpeg_worker+0x110>
    20d0:	b94097e0 	ldr	w0, [sp, #148]
    20d4:	35000060 	cbnz	w0, 20e0 <jpeg_worker+0x118>
        out.error = 1;
    20d8:	52800020 	mov	w0, #0x1                   	// #1
    20dc:	b9009fe0 	str	w0, [sp, #156]
      out.jpeg_us = clock_us() - begin;
    20e0:	97fffa3e 	bl	9d8 <clock_us@plt>
    20e4:	cb170000 	sub	x0, x0, x23
    20e8:	f90047e0 	str	x0, [sp, #136]
    if(raw.camera_index >= 0)
    20ec:	b94077e0 	ldr	w0, [sp, #116]
    20f0:	37f80080 	tbnz	w0, #31, 2100 <jpeg_worker+0x138>
      sem_post(&camera_free[raw.camera_index]);
    20f4:	8b204a60 	add	x0, x19, w0, uxtw #2
    20f8:	b9412800 	ldr	w0, [x0, #296]
    20fc:	97fffd48 	bl	161c <mutex_unlock.isra.0>
  uint tail = __atomic_load_n(&encoded_tail, __ATOMIC_RELAXED);
    2100:	b94002a1 	ldr	w1, [x21]
  encodedq[tail % PIPE_DEPTH] = *job;
    2104:	d37b0022 	ubfiz	x2, x1, #5, #1
    2108:	91054260 	add	x0, x19, #0x150
  __atomic_store_n(&encoded_tail, tail + 1, __ATOMIC_RELEASE);
    210c:	11000421 	add	w1, w1, #0x1
  encodedq[tail % PIPE_DEPTH] = *job;
    2110:	8b020000 	add	x0, x0, x2
    2114:	a94817e4 	ldp	x4, x5, [sp, #128]
    2118:	a9490fe2 	ldp	x2, x3, [sp, #144]
    211c:	a9001404 	stp	x4, x5, [x0]
    2120:	a9010c02 	stp	x2, x3, [x0, #16]
  __atomic_store_n(&encoded_tail, tail + 1, __ATOMIC_RELEASE);
    2124:	889ffea1 	stlr	w1, [x21]
  sem_post(&encoded_ready);
    2128:	b9419260 	ldr	w0, [x19, #400]
    212c:	97fffd3c 	bl	161c <mutex_unlock.isra.0>
  for(;;){
    2130:	17ffffaf 	b	1fec <jpeg_worker+0x24>

0000000000002134 <P>:
// Reflect at the borders so the neighbour keeps the same Bayer colour.
static inline int
P(int x, int y)
{
  if(x < 0) x = -x;
  if(x >= W) x = 2 * W - 2 - x;
    2134:	f0000002 	adrp	x2, 5000 <qbase_c+0xdd0>
    2138:	b9466843 	ldr	w3, [x2, #1640]
  if(x < 0) x = -x;
    213c:	7100001f 	cmp	w0, #0x0
  if(x >= W) x = 2 * W - 2 - x;
    2140:	51000464 	sub	w4, w3, #0x1
  if(x < 0) x = -x;
    2144:	5a80a400 	cneg	w0, w0, lt	// lt = tstop
  if(x >= W) x = 2 * W - 2 - x;
    2148:	6b00007f 	cmp	w3, w0
    214c:	531f7884 	lsl	w4, w4, #1
    2150:	4b000084 	sub	w4, w4, w0
    2154:	1a84c000 	csel	w0, w0, w4, gt
  if(y < 0) y = -y;
  if(y >= H) y = 2 * H - 2 - y;
    2158:	9119a044 	add	x4, x2, #0x668
  if(y < 0) y = -y;
    215c:	7100003f 	cmp	w1, #0x0
    2160:	5a81a421 	cneg	w1, w1, lt	// lt = tstop
  if(y >= H) y = 2 * H - 2 - y;
    2164:	b9400482 	ldr	w2, [x4, #4]
    2168:	6b02003f 	cmp	w1, w2
    216c:	51000442 	sub	w2, w2, #0x1
    2170:	531f7842 	lsl	w2, w2, #1
    2174:	4b010042 	sub	w2, w2, w1
    2178:	1a82b021 	csel	w1, w1, w2, lt	// lt = tstop
  return px[y * W + x];
    217c:	1b010063 	madd	w3, w3, w1, w0
    2180:	f9400480 	ldr	x0, [x4, #8]
}
    2184:	7863d800 	ldrh	w0, [x0, w3, sxtw #1]
    2188:	d65f03c0 	ret

000000000000218c <output_pixel>:
  int half;
};

static void
output_pixel(void *arg, int x, int y, uchar *red, uchar *green, uchar *blue)
{
    218c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2190:	2a0103ed 	mov	w13, w1
    2194:	2a0203e6 	mov	w6, w2
    2198:	910003fd 	mov	x29, sp
    219c:	a90153f3 	stp	x19, x20, [sp, #16]
    21a0:	aa0303e9 	mov	x9, x3
    21a4:	aa0403e8 	mov	x8, x4
  struct convert *c = arg;
  int r, g, b;
  if(c->half){
    21a8:	b9400001 	ldr	w1, [x0]
    21ac:	f0000000 	adrp	x0, 5000 <qbase_c+0xdd0>
    21b0:	9119a00a 	add	x10, x0, #0x668
{
    21b4:	f90013f5 	str	x21, [sp, #32]
  if(c->half){
    21b8:	34000581 	cbz	w1, 2268 <output_pixel+0xdc>
    int v[3] = { 0, 0, 0 };
    for(int i = 0; i < 4; i++)
      v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
    21bc:	531f79ad 	lsl	w13, w13, #1
    21c0:	531f7846 	lsl	w6, w2, #1
    21c4:	9100414c 	add	x12, x10, #0x10
    21c8:	9100c3eb 	add	x11, sp, #0x30
    21cc:	d2800007 	mov	x7, #0x0                   	// #0
    int v[3] = { 0, 0, 0 };
    21d0:	f9001bff 	str	xzr, [sp, #48]
    21d4:	b9003bff 	str	wzr, [sp, #56]
      v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
    21d8:	120000e0 	and	w0, w7, #0x1
    21dc:	0b8704c1 	add	w1, w6, w7, asr #1
    21e0:	0b0d0000 	add	w0, w0, w13
    21e4:	97ffffd4 	bl	2134 <P>
    21e8:	b8a77981 	ldrsw	x1, [x12, x7, lsl #2]
    for(int i = 0; i < 4; i++)
    21ec:	910004e7 	add	x7, x7, #0x1
      v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
    21f0:	d37ef421 	lsl	x1, x1, #2
    21f4:	b8616962 	ldr	w2, [x11, x1]
    21f8:	0b000042 	add	w2, w2, w0
    21fc:	b8216962 	str	w2, [x11, x1]
    for(int i = 0; i < 4; i++)
    2200:	f10010ff 	cmp	x7, #0x4
    2204:	54fffea1 	b.ne	21d8 <output_pixel+0x4c>  // b.any
    r = v[R];
    g = v[G] / 2;
    2208:	29461be1 	ldp	w1, w6, [sp, #48]
    220c:	52800042 	mov	w2, #0x2                   	// #2
    2210:	1ac20ccc 	sdiv	w12, w6, w2
    b = v[B];
    2214:	b9403be2 	ldr	w2, [sp, #56]
    demosaic(x, y, &r, &g, &b);
  }
  // The per-frame gains, level and gamma curve are already folded into these
  // tables.  This removes six variable multiplies/shifts from every output
  // pixel while preserving the old integer truncation order exactly.
  *red = tone[R][r > 1023 ? 1023 : r];
    2218:	52807fe3 	mov	w3, #0x3ff                 	// #1023
    221c:	6b03003f 	cmp	w1, w3
    2220:	9100814a 	add	x10, x10, #0x20
    2224:	1a83d021 	csel	w1, w1, w3, le
  *green = tone[G][g > 1023 ? 1023 : g];
    2228:	6b03019f 	cmp	w12, w3
  *red = tone[R][r > 1023 ? 1023 : r];
    222c:	3861c940 	ldrb	w0, [x10, w1, sxtw]
    2230:	39000120 	strb	w0, [x9]
  *green = tone[G][g > 1023 ? 1023 : g];
    2234:	1a83d180 	csel	w0, w12, w3, le
  *blue = tone[B][b > 1023 ? 1023 : b];
    2238:	6b03005f 	cmp	w2, w3
    223c:	1a83d042 	csel	w2, w2, w3, le
  *green = tone[G][g > 1023 ? 1023 : g];
    2240:	8b20c140 	add	x0, x10, w0, sxtw
  *blue = tone[B][b > 1023 ? 1023 : b];
    2244:	8b22c142 	add	x2, x10, w2, sxtw
  *green = tone[G][g > 1023 ? 1023 : g];
    2248:	39500000 	ldrb	w0, [x0, #1024]
    224c:	39000100 	strb	w0, [x8]
  *blue = tone[B][b > 1023 ? 1023 : b];
    2250:	39600040 	ldrb	w0, [x2, #2048]
    2254:	390000a0 	strb	w0, [x5]
}
    2258:	f94013f5 	ldr	x21, [sp, #32]
    225c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2260:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2264:	d65f03c0 	ret
  return bayer[(x & 1) + 2 * (y & 1)];
    2268:	531f004c 	ubfiz	w12, w2, #1, #1
    226c:	120001a2 	and	w2, w13, #0x1
    2270:	0b0c0042 	add	w2, w2, w12
  if(x > 0 && x + 1 < W && y > 0 && y + 1 < H){
    2274:	110005a7 	add	w7, w13, #0x1
    2278:	110004d3 	add	w19, w6, #0x1
    const ushort *up = px + (y - 1) * W;
    227c:	510004d2 	sub	w18, w6, #0x1
  return bayer[(x & 1) + 2 * (y & 1)];
    2280:	d37e0842 	ubfiz	x2, x2, #2, #3
    2284:	8b020142 	add	x2, x10, x2
    2288:	b940104b 	ldr	w11, [x2, #16]
    if(type == R || type == B){
    228c:	121e7974 	and	w20, w11, #0xfffffffd
  if(x > 0 && x + 1 < W && y > 0 && y + 1 < H){
    2290:	710001bf 	cmp	w13, #0x0
    2294:	540006ad 	b.le	2368 <output_pixel+0x1dc>
    2298:	b9466802 	ldr	w2, [x0, #1640]
    229c:	6b07005f 	cmp	w2, w7
    22a0:	5400064d 	b.le	2368 <output_pixel+0x1dc>
    22a4:	710000df 	cmp	w6, #0x0
    22a8:	5400060d 	b.le	2368 <output_pixel+0x1dc>
    22ac:	b9400540 	ldr	w0, [x10, #4]
    22b0:	6b13001f 	cmp	w0, w19
    22b4:	540005ad 	b.le	2368 <output_pixel+0x1dc>
    const ushort *up = px + (y - 1) * W;
    22b8:	f9400540 	ldr	x0, [x10, #8]
    22bc:	1b127c44 	mul	w4, w2, w18
    const ushort *row = up + W;
    22c0:	d37f7c42 	ubfiz	x2, x2, #1, #32
      horiz = (row[x-1] + row[x+1]) / 2;
    22c4:	510005ae 	sub	w14, w13, #0x1
    22c8:	110005a6 	add	w6, w13, #0x1
    const ushort *up = px + (y - 1) * W;
    22cc:	8b040404 	add	x4, x0, x4, lsl #1
    const ushort *row = up + W;
    22d0:	8b020081 	add	x1, x4, x2
    const ushort *down = row + W;
    22d4:	8b020483 	add	x3, x4, x2, lsl #1
    c = row[x];
    22d8:	786d5820 	ldrh	w0, [x1, w13, uxtw #1]
      horiz = (row[x-1] + row[x+1]) / 2;
    22dc:	78667822 	ldrh	w2, [x1, x6, lsl #1]
    22e0:	786e7821 	ldrh	w1, [x1, x14, lsl #1]
    22e4:	0b010042 	add	w2, w2, w1
      vert = (up[x] + down[x]) / 2;
    22e8:	786d5881 	ldrh	w1, [x4, w13, uxtw #1]
    22ec:	786d586d 	ldrh	w13, [x3, w13, uxtw #1]
    if(type == R || type == B){
    22f0:	35000214 	cbnz	w20, 2330 <output_pixel+0x1a4>
      cross = (row[x-1] + row[x+1] + up[x] + down[x]) / 4;
    22f4:	0b020021 	add	w1, w1, w2
      diag = (up[x-1] + up[x+1] + down[x-1] + down[x+1]) / 4;
    22f8:	78667882 	ldrh	w2, [x4, x6, lsl #1]
      cross = (row[x-1] + row[x+1] + up[x] + down[x]) / 4;
    22fc:	0b0d0021 	add	w1, w1, w13
    2300:	13027c2c 	asr	w12, w1, #2
      diag = (up[x-1] + up[x+1] + down[x-1] + down[x+1]) / 4;
    2304:	786e7881 	ldrh	w1, [x4, x14, lsl #1]
    2308:	0b020021 	add	w1, w1, w2
    230c:	786e7862 	ldrh	w2, [x3, x14, lsl #1]
    2310:	0b020021 	add	w1, w1, w2
    2314:	78667862 	ldrh	w2, [x3, x6, lsl #1]
    2318:	0b020021 	add	w1, w1, w2
    231c:	13027c21 	asr	w1, w1, #2
      if(type == R){ *r = c; *g = cross; *b = diag; }
    2320:	3500020b 	cbnz	w11, 2360 <output_pixel+0x1d4>
    2324:	2a0103e2 	mov	w2, w1
    2328:	2a0003e1 	mov	w1, w0
    232c:	17ffffbb 	b	2218 <output_pixel+0x8c>
  return bayer[(x & 1) + 2 * (y & 1)];
    2330:	120000e7 	and	w7, w7, #0x1
      vert = (up[x] + down[x]) / 2;
    2334:	0b0d0021 	add	w1, w1, w13
  return bayer[(x & 1) + 2 * (y & 1)];
    2338:	0b0c00e7 	add	w7, w7, w12
      horiz = (row[x-1] + row[x+1]) / 2;
    233c:	13017c42 	asr	w2, w2, #1
      vert = (up[x] + down[x]) / 2;
    2340:	13017c21 	asr	w1, w1, #1
      *g = c;
    2344:	2a0003ec 	mov	w12, w0
  return bayer[(x & 1) + 2 * (y & 1)];
    2348:	d37e08e7 	ubfiz	x7, x7, #2, #3
    234c:	8b070147 	add	x7, x10, x7
      if(colour(x + 1, y) == R){ *r = horiz; *b = vert; }
    2350:	b94010e3 	ldr	w3, [x7, #16]
    2354:	35fff623 	cbnz	w3, 2218 <output_pixel+0x8c>
    if(colour(x + 1, y) == R){ *r = horiz; *b = vert; }
    2358:	2a0103e0 	mov	w0, w1
    235c:	2a0203e1 	mov	w1, w2
      else { *b = c; *g = cross; *r = diag; }
    2360:	2a0003e2 	mov	w2, w0
    2364:	17ffffad 	b	2218 <output_pixel+0x8c>
  c = P(x, y);
    2368:	2a0603e1 	mov	w1, w6
    236c:	2a0d03e0 	mov	w0, w13
    2370:	97ffff71 	bl	2134 <P>
    2374:	2a0003ee 	mov	w14, w0
    cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
    2378:	2a0603e1 	mov	w1, w6
    237c:	510005a0 	sub	w0, w13, #0x1
    2380:	97ffff6d 	bl	2134 <P>
    2384:	2a0003ef 	mov	w15, w0
    2388:	2a0603e1 	mov	w1, w6
    238c:	2a0703e0 	mov	w0, w7
    2390:	97ffff69 	bl	2134 <P>
    horiz = (P(x-1,y) + P(x+1,y)) / 2;
    2394:	0b0f000f 	add	w15, w0, w15
    cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
    2398:	2a1203e1 	mov	w1, w18
    239c:	2a0d03e0 	mov	w0, w13
    23a0:	97ffff65 	bl	2134 <P>
    23a4:	2a0003e6 	mov	w6, w0
    23a8:	2a1303e1 	mov	w1, w19
    23ac:	2a0d03e0 	mov	w0, w13
    23b0:	97ffff61 	bl	2134 <P>
  if(type == R || type == B){
    23b4:	35000334 	cbnz	w20, 2418 <output_pixel+0x28c>
    cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
    23b8:	0b0f00c6 	add	w6, w6, w15
    diag = (P(x-1,y-1) + P(x+1,y-1) +
    23bc:	2a1203e1 	mov	w1, w18
    cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
    23c0:	0b0000c6 	add	w6, w6, w0
    diag = (P(x-1,y-1) + P(x+1,y-1) +
    23c4:	510005a0 	sub	w0, w13, #0x1
    23c8:	97ffff5b 	bl	2134 <P>
    cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
    23cc:	13027ccc 	asr	w12, w6, #2
    diag = (P(x-1,y-1) + P(x+1,y-1) +
    23d0:	2a0003e6 	mov	w6, w0
    23d4:	2a1203e1 	mov	w1, w18
    23d8:	2a0703e0 	mov	w0, w7
    23dc:	97ffff56 	bl	2134 <P>
    23e0:	0b0000c6 	add	w6, w6, w0
            P(x-1,y+1) + P(x+1,y+1)) / 4;
    23e4:	2a1303e1 	mov	w1, w19
    23e8:	510005a0 	sub	w0, w13, #0x1
    23ec:	97ffff52 	bl	2134 <P>
    diag = (P(x-1,y-1) + P(x+1,y-1) +
    23f0:	0b0000c6 	add	w6, w6, w0
            P(x-1,y+1) + P(x+1,y+1)) / 4;
    23f4:	2a1303e1 	mov	w1, w19
    23f8:	2a0703e0 	mov	w0, w7
    23fc:	97ffff4e 	bl	2134 <P>
    2400:	0b0000c6 	add	w6, w6, w0
    diag = (P(x-1,y-1) + P(x+1,y-1) +
    2404:	13027cc1 	asr	w1, w6, #2
    if(type == R){ *r = c; *g = cross; *b = diag; }
    2408:	350001eb 	cbnz	w11, 2444 <output_pixel+0x2b8>
    240c:	2a0103e2 	mov	w2, w1
    2410:	2a0e03e1 	mov	w1, w14
    2414:	17ffff81 	b	2218 <output_pixel+0x8c>
  return bayer[(x & 1) + 2 * (y & 1)];
    2418:	120000e7 	and	w7, w7, #0x1
    vert = (P(x,y-1) + P(x,y+1)) / 2;
    241c:	0b060000 	add	w0, w0, w6
  return bayer[(x & 1) + 2 * (y & 1)];
    2420:	0b0c00e7 	add	w7, w7, w12
    horiz = (P(x-1,y) + P(x+1,y)) / 2;
    2424:	13017de2 	asr	w2, w15, #1
    vert = (P(x,y-1) + P(x,y+1)) / 2;
    2428:	13017c01 	asr	w1, w0, #1
    *g = c;
    242c:	2a0e03ec 	mov	w12, w14
  return bayer[(x & 1) + 2 * (y & 1)];
    2430:	d37e08e7 	ubfiz	x7, x7, #2, #3
    2434:	8b070147 	add	x7, x10, x7
    if(colour(x + 1, y) == R){ *r = horiz; *b = vert; }
    2438:	b94010e0 	ldr	w0, [x7, #16]
    243c:	35ffeee0 	cbnz	w0, 2218 <output_pixel+0x8c>
    2440:	17ffffc6 	b	2358 <output_pixel+0x1cc>
    else { *b = c; *g = cross; *r = diag; }
    2444:	2a0e03e2 	mov	w2, w14
    2448:	17ffff74 	b	2218 <output_pixel+0x8c>

000000000000244c <camproc_jpeg_raw>:
int
camproc_jpeg_raw(uchar *dst, int cap, const struct cam_frame_hdr *hdr,
                 const uchar *raw, int half, int wb, int quality,
                 uint *written)
{
  if(dst == 0 || cap <= 0 || hdr == 0 || raw == 0 ||
    244c:	f100001f 	cmp	x0, #0x0
    2450:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    2454:	5400008d 	b.le	2464 <camproc_jpeg_raw+0x18>
    2458:	f100005f 	cmp	x2, #0x0
    245c:	fa401864 	ccmp	x3, #0x0, #0x4, ne	// ne = any
    2460:	54000061 	b.ne	246c <camproc_jpeg_raw+0x20>  // b.any
     hdr->magic != CAM_MAGIC)
    return -1;
    2464:	12800000 	mov	w0, #0xffffffff            	// #-1
  build_tone(gain_r, gain_b, level);
  int ow = half ? W / 2 : W, oh = half ? H / 2 : H;
  struct convert conversion = { half };
  return jpeg_encode_mem(dst, cap, ow, oh, quality, output_pixel,
                         &conversion, written);
}
    2468:	d65f03c0 	ret
{
    246c:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
    2470:	910003fd 	mov	x29, sp
    2474:	a90153f3 	stp	x19, x20, [sp, #16]
    2478:	a9025bf5 	stp	x21, x22, [sp, #32]
    247c:	a90363f7 	stp	x23, x24, [sp, #48]
    2480:	a9046bf9 	stp	x25, x26, [sp, #64]
    2484:	2a0403f9 	mov	w25, w4
  if(dst == 0 || cap <= 0 || hdr == 0 || raw == 0 ||
    2488:	52882864 	mov	w4, #0x4143                	// #16707
    248c:	72a629a4 	movk	w4, #0x314d, lsl #16
{
    2490:	a90573fb 	stp	x27, x28, [sp, #80]
  if(dst == 0 || cap <= 0 || hdr == 0 || raw == 0 ||
    2494:	b9400048 	ldr	w8, [x2]
    2498:	6b04011f 	cmp	w8, w4
    249c:	54000721 	b.ne	2580 <camproc_jpeg_raw+0x134>  // b.any
  W = hdr->width;
    24a0:	f0000018 	adrp	x24, 5000 <qbase_c+0xdd0>
    24a4:	9119a313 	add	x19, x24, #0x668
  H = hdr->height;
    24a8:	2940a844 	ldp	w4, w10, [x2, #4]
  W = hdr->width;
    24ac:	b9066b04 	str	w4, [x24, #1640]
  H = hdr->height;
    24b0:	b900066a 	str	w10, [x19, #4]
  if(W < 4 || H < 4 || W % 4 || H % 2 ||
    24b4:	71000c9f 	cmp	w4, #0x3
    24b8:	5400064d 	b.le	2580 <camproc_jpeg_raw+0x134>
    24bc:	71000d5f 	cmp	w10, #0x3
    24c0:	5400060d 	b.le	2580 <camproc_jpeg_raw+0x134>
    24c4:	12000495 	and	w21, w4, #0x3
    24c8:	12000148 	and	w8, w10, #0x1
    24cc:	2a0802b5 	orr	w21, w21, w8
    24d0:	35000595 	cbnz	w21, 2580 <camproc_jpeg_raw+0x134>
     hdr->data_bytes > CAM_SLOT_BYTES ||
    24d4:	b940144c 	ldr	w12, [x2, #20]
  if(W < 4 || H < 4 || W % 4 || H % 2 ||
    24d8:	7142019f 	cmp	w12, #0x80, lsl #12
    24dc:	54000528 	b.hi	2580 <camproc_jpeg_raw+0x134>  // b.pmore
     hdr->bytesperline < W * 10 / 8 ||
    24e0:	5280014b 	mov	w11, #0xa                   	// #10
    24e4:	b9400c48 	ldr	w8, [x2, #12]
    24e8:	1b0b7c8b 	mul	w11, w4, w11
     hdr->data_bytes > CAM_SLOT_BYTES ||
    24ec:	6b8b0d1f 	cmp	w8, w11, asr #3
    24f0:	54000483 	b.cc	2580 <camproc_jpeg_raw+0x134>  // b.lo, b.ul, b.last
     hdr->data_bytes < hdr->bytesperline * H || set_bayer(hdr->format) < 0)
    24f4:	1b087d48 	mul	w8, w10, w8
     hdr->bytesperline < W * 10 / 8 ||
    24f8:	6b08019f 	cmp	w12, w8
    24fc:	54000423 	b.cc	2580 <camproc_jpeg_raw+0x134>  // b.lo, b.ul, b.last
  if(format < CAM_FMT_SBGGR10P || format > CAM_FMT_SRGGB10P)
    2500:	b9401048 	ldr	w8, [x2, #16]
    2504:	51000508 	sub	w8, w8, #0x1
    2508:	71000d1f 	cmp	w8, #0x3
    250c:	540003a8 	b.hi	2580 <camproc_jpeg_raw+0x134>  // b.pmore
    2510:	d37c7d08 	ubfiz	x8, x8, #4, #32
    2514:	d0000014 	adrp	x20, 4000 <head.0+0x39>
    2518:	9101c294 	add	x20, x20, #0x70
    251c:	290d1be1 	stp	w1, w6, [sp, #104]
    2520:	8b080281 	add	x1, x20, x8
    2524:	f90033e0 	str	x0, [sp, #96]
    bayer[i] = orders[format - CAM_FMT_SBGGR10P][i];
    2528:	aa0703fa 	mov	x26, x7
    252c:	2a0503fb 	mov	w27, w5
    2530:	f8686a80 	ldr	x0, [x20, x8]
    2534:	aa0303f6 	mov	x22, x3
    2538:	f9400421 	ldr	x1, [x1, #8]
    253c:	a9010660 	stp	x0, x1, [x19, #16]
  if(px == 0 || px_size != W * H){
    2540:	aa0203fc 	mov	x28, x2
    2544:	f9400660 	ldr	x0, [x19, #8]
    2548:	b40000a0 	cbz	x0, 255c <camproc_jpeg_raw+0x110>
    254c:	1b0a7c84 	mul	w4, w4, w10
    2550:	b94c2261 	ldr	w1, [x19, #3104]
    2554:	6b01009f 	cmp	w4, w1
    2558:	540002c0 	b.eq	25b0 <camproc_jpeg_raw+0x164>  // b.none
    free(px);
    255c:	97fff943 	bl	a68 <free@plt>
    px = malloc(W * H * sizeof(ushort));
    2560:	b9466b00 	ldr	w0, [x24, #1640]
    2564:	b9400661 	ldr	w1, [x19, #4]
    2568:	1b017c00 	mul	w0, w0, w1
    256c:	531f7800 	lsl	w0, w0, #1
    2570:	97fff8e6 	bl	908 <malloc@plt>
    2574:	f9000660 	str	x0, [x19, #8]
    px_size = px ? W * H : 0;
    2578:	b5000140 	cbnz	x0, 25a0 <camproc_jpeg_raw+0x154>
    257c:	b90c227f 	str	wzr, [x19, #3104]
    return -1;
    2580:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    2584:	a94153f3 	ldp	x19, x20, [sp, #16]
    2588:	a9425bf5 	ldp	x21, x22, [sp, #32]
    258c:	a94363f7 	ldp	x23, x24, [sp, #48]
    2590:	a9446bf9 	ldp	x25, x26, [sp, #64]
    2594:	a94573fb 	ldp	x27, x28, [sp, #80]
    2598:	a8c97bfd 	ldp	x29, x30, [sp], #144
    259c:	d65f03c0 	ret
    px_size = px ? W * H : 0;
    25a0:	b9466b00 	ldr	w0, [x24, #1640]
    25a4:	b9400661 	ldr	w1, [x19, #4]
    25a8:	1b017c00 	mul	w0, w0, w1
    25ac:	b90c2260 	str	w0, [x19, #3104]
  unpack_raw10_analyze(raw, hdr->bytesperline, sum);
    25b0:	b9400f97 	ldr	w23, [x28, #12]
  memset(hist, 0, sizeof(hist));
    25b4:	9000003c 	adrp	x28, 6000 <tone+0x978>
    25b8:	910a339c 	add	x28, x28, #0x28c
    25bc:	52820002 	mov	w2, #0x1000                	// #4096
    25c0:	aa1c03e0 	mov	x0, x28
    25c4:	52800001 	mov	w1, #0x0                   	// #0
  sum[R] = sum[G] = sum[B] = 0;
    25c8:	a907ffff 	stp	xzr, xzr, [sp, #120]
    25cc:	f90047ff 	str	xzr, [sp, #136]
  memset(hist, 0, sizeof(hist));
    25d0:	97fff8f6 	bl	9a8 <memset@plt>
    ushort *d = px + y * W;
    25d4:	b9466b02 	ldr	w2, [x24, #1640]
        sum[c] += v;
    25d8:	9101e3e9 	add	x9, sp, #0x78
    ushort *d = px + y * W;
    25dc:	f940066e 	ldr	x14, [x19, #8]
  for(int y = 0; y < H; y++){
    25e0:	d2800007 	mov	x7, #0x0                   	// #0
    25e4:	b9400663 	ldr	w3, [x19, #4]
    25e8:	93407c4f 	sxtw	x15, w2
    25ec:	52800000 	mov	w0, #0x0                   	// #0
        v = v > BLACK ? v - BLACK : 0;
    25f0:	52800210 	mov	w16, #0x10                  	// #16
  for(int y = 0; y < H; y++){
    25f4:	6b03001f 	cmp	w0, w3
    25f8:	5400088b 	b.lt	2708 <camproc_jpeg_raw+0x2bc>  // b.tstop
  uint64 sum_r = sum[R], sum_g = sum[G], sum_b = sum[B];
    25fc:	f9403fe4 	ldr	x4, [sp, #120]
  if(wb && sum_r && sum_b){
    2600:	7100037f 	cmp	w27, #0x0
    2604:	fa401884 	ccmp	x4, #0x0, #0x4, ne	// ne = any
    2608:	54000060 	b.eq	2614 <camproc_jpeg_raw+0x1c8>  // b.none
  uint64 sum_r = sum[R], sum_g = sum[G], sum_b = sum[B];
    260c:	f94047e6 	ldr	x6, [sp, #136]
  if(wb && sum_r && sum_b){
    2610:	b5000d46 	cbnz	x6, 27b8 <camproc_jpeg_raw+0x36c>
  *gain_r = *gain_b = 256;
    2614:	52802000 	mov	w0, #0x100                 	// #256
    2618:	2a0003e4 	mov	w4, w0
  uint want = (W * H / 2) / 100, seen = 0;
    261c:	1b037c46 	mul	w6, w2, w3
    2620:	52801901 	mov	w1, #0xc8                  	// #200
    2624:	52800005 	mov	w5, #0x0                   	// #0
    2628:	1ac10cc6 	sdiv	w6, w6, w1
    262c:	d2807fe1 	mov	x1, #0x3ff                 	// #1023
  while(p99 > 0 && seen + hist[p99] < want)
    2630:	b8617b87 	ldr	w7, [x28, x1, lsl #2]
    2634:	0b0700a5 	add	w5, w5, w7
    2638:	6b0500df 	cmp	w6, w5
    263c:	54000dc8 	b.hi	27f4 <camproc_jpeg_raw+0x3a8>  // b.pmore
  if(p99 < 128)
    2640:	7102003f 	cmp	w1, #0x80
    2644:	52801005 	mov	w5, #0x80                  	// #128
    2648:	1a85a021 	csel	w1, w1, w5, ge	// ge = tcont
  *level = 1023 * 256 / p99;                      // 8.8
    264c:	321827e5 	mov	w5, #0x3ff00               	// #261888
    2650:	91008273 	add	x19, x19, #0x20
    tone[R][v] = gamma22[lr > 255 ? 255 : lr];
    2654:	91010294 	add	x20, x20, #0x40
  *level = 1023 * 256 / p99;                      // 8.8
    2658:	52800006 	mov	w6, #0x0                   	// #0
    265c:	52800007 	mov	w7, #0x0                   	// #0
    2660:	1ac108a5 	udiv	w5, w5, w1
    2664:	52800008 	mov	w8, #0x0                   	// #0
    tone[R][v] = gamma22[lr > 255 ? 255 : lr];
    2668:	52801fe9 	mov	w9, #0xff                  	// #255
    uint lr = (v * gain_r / 256) * level / 256 / 4;
    266c:	53087d01 	lsr	w1, w8, #8
  for(uint v = 0; v < 1024; v++){
    2670:	110006b5 	add	w21, w21, #0x1
    2674:	0b040108 	add	w8, w8, w4
    2678:	91000673 	add	x19, x19, #0x1
    uint lr = (v * gain_r / 256) * level / 256 / 4;
    267c:	1b057c21 	mul	w1, w1, w5
    2680:	530a7c21 	lsr	w1, w1, #10
    tone[R][v] = gamma22[lr > 255 ? 255 : lr];
    2684:	7103fc3f 	cmp	w1, #0xff
    2688:	1a899021 	csel	w1, w1, w9, ls	// ls = plast
    268c:	38616a81 	ldrb	w1, [x20, x1]
    2690:	381ff261 	sturb	w1, [x19, #-1]
    uint lg = v * level / 256 / 4;
    2694:	530a7ce1 	lsr	w1, w7, #10
    tone[G][v] = gamma22[lg > 255 ? 255 : lg];
    2698:	7103fc3f 	cmp	w1, #0xff
  for(uint v = 0; v < 1024; v++){
    269c:	0b0500e7 	add	w7, w7, w5
    tone[G][v] = gamma22[lg > 255 ? 255 : lg];
    26a0:	1a899021 	csel	w1, w1, w9, ls	// ls = plast
    26a4:	38616a81 	ldrb	w1, [x20, x1]
    26a8:	390ffe61 	strb	w1, [x19, #1023]
    uint lb = (v * gain_b / 256) * level / 256 / 4;
    26ac:	53087cc1 	lsr	w1, w6, #8
  for(uint v = 0; v < 1024; v++){
    26b0:	0b0000c6 	add	w6, w6, w0
    uint lb = (v * gain_b / 256) * level / 256 / 4;
    26b4:	1b057c21 	mul	w1, w1, w5
    26b8:	530a7c21 	lsr	w1, w1, #10
    tone[B][v] = gamma22[lb > 255 ? 255 : lb];
    26bc:	7103fc3f 	cmp	w1, #0xff
    26c0:	1a899021 	csel	w1, w1, w9, ls	// ls = plast
    26c4:	38616a81 	ldrb	w1, [x20, x1]
    26c8:	391ffe61 	strb	w1, [x19, #2047]
  for(uint v = 0; v < 1024; v++){
    26cc:	711002bf 	cmp	w21, #0x400
    26d0:	54fffce1 	b.ne	266c <camproc_jpeg_raw+0x220>  // b.any
  int ow = half ? W / 2 : W, oh = half ? H / 2 : H;
    26d4:	34000099 	cbz	w25, 26e4 <camproc_jpeg_raw+0x298>
    26d8:	52800040 	mov	w0, #0x2                   	// #2
    26dc:	1ac00c42 	sdiv	w2, w2, w0
    26e0:	1ac00c63 	sdiv	w3, w3, w0
  return jpeg_encode_mem(dst, cap, ow, oh, quality, output_pixel,
    26e4:	f94033e0 	ldr	x0, [sp, #96]
    26e8:	aa1a03e7 	mov	x7, x26
    26ec:	294d13e1 	ldp	w1, w4, [sp, #104]
    26f0:	9101c3e6 	add	x6, sp, #0x70
    26f4:	90000005 	adrp	x5, 2000 <jpeg_worker+0x38>
    26f8:	910630a5 	add	x5, x5, #0x18c
  struct convert conversion = { half };
    26fc:	b90073f9 	str	w25, [sp, #112]
  return jpeg_encode_mem(dst, cap, ow, oh, quality, output_pixel,
    2700:	940003df 	bl	367c <jpeg_encode_mem>
    2704:	17ffffa0 	b	2584 <camproc_jpeg_raw+0x138>
    const uchar *s = src + y * bpl;
    2708:	aa1603e5 	mov	x5, x22
        int c = bayer[((x + i) & 1) + 2 * (y & 1)];
    270c:	531f0011 	ubfiz	w17, w0, #1, #1
    2710:	8b0705c8 	add	x8, x14, x7, lsl #1
    for(int x = 0; x < W; x += 4, s += 5){
    2714:	52800004 	mov	w4, #0x0                   	// #0
    2718:	6b04005f 	cmp	w2, w4
    271c:	540000ac 	b.gt	2730 <camproc_jpeg_raw+0x2e4>
  for(int y = 0; y < H; y++){
    2720:	11000400 	add	w0, w0, #0x1
    2724:	8b37c2d6 	add	x22, x22, w23, sxtw
    2728:	8b0f00e7 	add	x7, x7, x15
    272c:	17ffffb2 	b	25f4 <camproc_jpeg_raw+0x1a8>
        int v = (s[i] << 2) | ((lo >> (2 * i)) & 3);
    2730:	394010b2 	ldrb	w18, [x5, #4]
    2734:	d2800001 	mov	x1, #0x0                   	// #0
    2738:	386168a6 	ldrb	w6, [x5, x1]
    273c:	531f782a 	lsl	w10, w1, #1
    2740:	1aca2a4a 	asr	w10, w18, w10
    2744:	1200054a 	and	w10, w10, #0x3
    2748:	2a060946 	orr	w6, w10, w6, lsl #2
        int c = bayer[((x + i) & 1) + 2 * (y & 1)];
    274c:	0b01008a 	add	w10, w4, w1
    2750:	1200014a 	and	w10, w10, #0x1
        v = v > BLACK ? v - BLACK : 0;
    2754:	710040df 	cmp	w6, #0x10
        int c = bayer[((x + i) & 1) + 2 * (y & 1)];
    2758:	0b11014a 	add	w10, w10, w17
        v = v > BLACK ? v - BLACK : 0;
    275c:	1a90a0c6 	csel	w6, w6, w16, ge	// ge = tcont
    2760:	510040c6 	sub	w6, w6, #0x10
        d[x + i] = v;
    2764:	78217906 	strh	w6, [x8, x1, lsl #1]
        int c = bayer[((x + i) & 1) + 2 * (y & 1)];
    2768:	d37e094a 	ubfiz	x10, x10, #2, #3
    276c:	8b0a026a 	add	x10, x19, x10
    2770:	b940114b 	ldr	w11, [x10, #16]
        sum[c] += v;
    2774:	2a0603ea 	mov	w10, w6
    2778:	937d7d6d 	sbfiz	x13, x11, #3, #32
    277c:	f86d693e 	ldr	x30, [x9, x13]
    2780:	8b2643c6 	add	x6, x30, w6, uxtw
    2784:	f82d6926 	str	x6, [x9, x13]
        if(c == G)
    2788:	7100057f 	cmp	w11, #0x1
    278c:	54000081 	b.ne	279c <camproc_jpeg_raw+0x350>  // b.any
          hist[v]++;
    2790:	b86a7b86 	ldr	w6, [x28, x10, lsl #2]
    2794:	110004c6 	add	w6, w6, #0x1
    2798:	b82a7b86 	str	w6, [x28, x10, lsl #2]
      for(int i = 0; i < 4; i++){
    279c:	91000421 	add	x1, x1, #0x1
    27a0:	f100103f 	cmp	x1, #0x4
    27a4:	54fffca1 	b.ne	2738 <camproc_jpeg_raw+0x2ec>  // b.any
    for(int x = 0; x < W; x += 4, s += 5){
    27a8:	11001084 	add	w4, w4, #0x4
    27ac:	910014a5 	add	x5, x5, #0x5
    27b0:	91002108 	add	x8, x8, #0x8
    27b4:	17ffffd9 	b	2718 <camproc_jpeg_raw+0x2cc>
    *gain_r = (uint)(sum_g * 128 / sum_r);        // G counts 2 pixels
    27b8:	f94043e0 	ldr	x0, [sp, #128]
    if(*gain_r > 1024) *gain_r = 1024;
    27bc:	52808005 	mov	w5, #0x400                 	// #1024
    if(*gain_r < 128) *gain_r = 128;
    27c0:	52801001 	mov	w1, #0x80                  	// #128
    *gain_r = (uint)(sum_g * 128 / sum_r);        // G counts 2 pixels
    27c4:	d379e000 	lsl	x0, x0, #7
    27c8:	9ac40804 	udiv	x4, x0, x4
    *gain_b = (uint)(sum_g * 128 / sum_b);
    27cc:	9ac60800 	udiv	x0, x0, x6
    if(*gain_r > 1024) *gain_r = 1024;
    27d0:	6b05009f 	cmp	w4, w5
    27d4:	1a859084 	csel	w4, w4, w5, ls	// ls = plast
    if(*gain_r < 128) *gain_r = 128;
    27d8:	6b01009f 	cmp	w4, w1
    27dc:	1a812084 	csel	w4, w4, w1, cs	// cs = hs, nlast
    if(*gain_b > 1024) *gain_b = 1024;
    27e0:	6b05001f 	cmp	w0, w5
    27e4:	1a859000 	csel	w0, w0, w5, ls	// ls = plast
    if(*gain_b < 128) *gain_b = 128;
    27e8:	6b01001f 	cmp	w0, w1
    27ec:	1a812000 	csel	w0, w0, w1, cs	// cs = hs, nlast
    27f0:	17ffff8b 	b	261c <camproc_jpeg_raw+0x1d0>
  while(p99 > 0 && seen + hist[p99] < want)
    27f4:	f1000421 	subs	x1, x1, #0x1
    27f8:	54fff1c1 	b.ne	2630 <camproc_jpeg_raw+0x1e4>  // b.any
    27fc:	52800001 	mov	w1, #0x0                   	// #0
    2800:	17ffff90 	b	2640 <camproc_jpeg_raw+0x1f4>

0000000000002804 <camproc_jpeg>:
int
camproc_jpeg(uchar *dst, int cap, const uchar *frame, int n,
             int half, int wb, int quality, uint *written)
{
  const struct cam_frame_hdr *hdr = (const struct cam_frame_hdr *)frame;
  if(frame == 0 || n < (int)sizeof(*hdr) ||
    2804:	71009c7f 	cmp	w3, #0x27
    2808:	fa40c844 	ccmp	x2, #0x0, #0x4, gt
    280c:	540000e0 	b.eq	2828 <camproc_jpeg+0x24>  // b.none
     n != (int)(sizeof(*hdr) + hdr->data_bytes))
    2810:	b9401449 	ldr	w9, [x2, #20]
    2814:	1100a129 	add	w9, w9, #0x28
  if(frame == 0 || n < (int)sizeof(*hdr) ||
    2818:	6b03013f 	cmp	w9, w3
    281c:	54000061 	b.ne	2828 <camproc_jpeg+0x24>  // b.any
    return -1;
  return camproc_jpeg_raw(dst, cap, hdr, frame + sizeof(*hdr),
    2820:	9100a043 	add	x3, x2, #0x28
    2824:	17ffff0a 	b	244c <camproc_jpeg_raw>
                          half, wb, quality, written);
}
    2828:	12800000 	mov	w0, #0xffffffff            	// #-1
    282c:	d65f03c0 	ret

0000000000002830 <make_quant>:
}

static void
make_quant(uchar out[64], const uchar base[64], int quality)
{
  int scale = quality < 50 ? 5000 / quality : 200 - quality * 2;
    2830:	7100c45f 	cmp	w2, #0x31
    2834:	5400026c 	b.gt	2880 <make_quant+0x50>
    2838:	52827104 	mov	w4, #0x1388                	// #5000
    283c:	1ac20882 	udiv	w2, w4, w2
{
    2840:	d2800004 	mov	x4, #0x0                   	// #0
  for(int i = 0; i < 64; i++){
    int q = (base[i] * scale + 50) / 100;
    if(q < 1) q = 1;
    if(q > 255) q = 255;
    2844:	528c79a5 	mov	w5, #0x63cd                	// #25549
    int q = (base[i] * scale + 50) / 100;
    2848:	52800c86 	mov	w6, #0x64                  	// #100
    284c:	38646823 	ldrb	w3, [x1, x4]
    2850:	1b027c63 	mul	w3, w3, w2
    if(q < 1) q = 1;
    2854:	7100c47f 	cmp	w3, #0x31
    2858:	540001cd 	b.le	2890 <make_quant+0x60>
    if(q > 255) q = 255;
    285c:	6b05007f 	cmp	w3, w5
    2860:	540001cc 	b.gt	2898 <make_quant+0x68>
    int q = (base[i] * scale + 50) / 100;
    2864:	1100c863 	add	w3, w3, #0x32
    2868:	1ac60863 	udiv	w3, w3, w6
    out[i] = q;
    286c:	38246803 	strb	w3, [x0, x4]
  for(int i = 0; i < 64; i++){
    2870:	91000484 	add	x4, x4, #0x1
    2874:	f101009f 	cmp	x4, #0x40
    2878:	54fffea1 	b.ne	284c <make_quant+0x1c>  // b.any
  }
}
    287c:	d65f03c0 	ret
  int scale = quality < 50 ? 5000 / quality : 200 - quality * 2;
    2880:	52800c83 	mov	w3, #0x64                  	// #100
    2884:	4b020062 	sub	w2, w3, w2
    2888:	531f7842 	lsl	w2, w2, #1
    288c:	17ffffed 	b	2840 <make_quant+0x10>
    if(q < 1) q = 1;
    2890:	52800023 	mov	w3, #0x1                   	// #1
    2894:	17fffff6 	b	286c <make_quant+0x3c>
    if(q > 255) q = 255;
    2898:	52801fe3 	mov	w3, #0xff                  	// #255
    289c:	17fffff4 	b	286c <make_quant+0x3c>

00000000000028a0 <jflush>:
{
    28a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    28a4:	910003fd 	mov	x29, sp
    28a8:	a90153f3 	stp	x19, x20, [sp, #16]
    28ac:	aa0003f3 	mov	x19, x0
  if(w->mem)
    28b0:	f9400400 	ldr	x0, [x0, #8]
{
    28b4:	f90013f5 	str	x21, [sp, #32]
  if(w->mem)
    28b8:	b4000360 	cbz	x0, 2924 <jflush+0x84>
    return w->error ? -1 : 0;   // memory mode: jbyte() wrote directly
    28bc:	b9401660 	ldr	w0, [x19, #20]
    28c0:	7100001f 	cmp	w0, #0x0
    28c4:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    28c8:	f94013f5 	ldr	x21, [sp, #32]
    28cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    28d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    28d4:	d65f03c0 	ret
    int n = write(w->fd, w->out + done, w->used - done);
    28d8:	b9400260 	ldr	w0, [x19]
    28dc:	4b140042 	sub	w2, w2, w20
    28e0:	8b34c2a1 	add	x1, x21, w20, sxtw
    28e4:	97fff819 	bl	948 <write@plt>
    if(n <= 0){
    28e8:	7100001f 	cmp	w0, #0x0
    28ec:	540000ac 	b.gt	2900 <jflush+0x60>
      w->error = 1;
    28f0:	52800020 	mov	w0, #0x1                   	// #1
    28f4:	b9001660 	str	w0, [x19, #20]
      return -1;
    28f8:	12800000 	mov	w0, #0xffffffff            	// #-1
    28fc:	17fffff3 	b	28c8 <jflush+0x28>
    done += n;
    2900:	0b000294 	add	w20, w20, w0
  while(done < w->used){
    2904:	b9401e62 	ldr	w2, [x19, #28]
    2908:	6b02029f 	cmp	w20, w2
    290c:	54fffe6b 	b.lt	28d8 <jflush+0x38>  // b.tstop
  w->total += w->used;
    2910:	b9401a60 	ldr	w0, [x19, #24]
    2914:	0b020000 	add	w0, w0, w2
    2918:	29037e60 	stp	w0, wzr, [x19, #24]
  return 0;
    291c:	52800000 	mov	w0, #0x0                   	// #0
    2920:	17ffffea 	b	28c8 <jflush+0x28>
    int n = write(w->fd, w->out + done, w->used - done);
    2924:	91008275 	add	x21, x19, #0x20
  int done = 0;
    2928:	52800014 	mov	w20, #0x0                   	// #0
    292c:	17fffff6 	b	2904 <jflush+0x64>

0000000000002930 <jbyte>:
{
    2930:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2934:	910003fd 	mov	x29, sp
    2938:	a90153f3 	stp	x19, x20, [sp, #16]
    293c:	2a0103f4 	mov	w20, w1
  if(w->error)
    2940:	b9401401 	ldr	w1, [x0, #20]
    2944:	35000141 	cbnz	w1, 296c <jbyte+0x3c>
  if(w->mem){
    2948:	f9400401 	ldr	x1, [x0, #8]
    294c:	aa0003f3 	mov	x19, x0
    2950:	b40001c1 	cbz	x1, 2988 <jbyte+0x58>
    if(w->total >= w->cap){
    2954:	b9401002 	ldr	w2, [x0, #16]
    2958:	b9401800 	ldr	w0, [x0, #24]
    295c:	6b02001f 	cmp	w0, w2
    2960:	540000c3 	b.cc	2978 <jbyte+0x48>  // b.lo, b.ul, b.last
      w->error = 1;
    2964:	52800020 	mov	w0, #0x1                   	// #1
    2968:	b9001660 	str	w0, [x19, #20]
}
    296c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2970:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2974:	d65f03c0 	ret
    w->mem[w->total++] = value;
    2978:	11000402 	add	w2, w0, #0x1
    297c:	b9001a62 	str	w2, [x19, #24]
    2980:	38204834 	strb	w20, [x1, w0, uxtw]
    return;
    2984:	17fffffa 	b	296c <jbyte+0x3c>
  if(w->used == OUTBUF && jflush(w) < 0)
    2988:	b9401c01 	ldr	w1, [x0, #28]
    298c:	7140043f 	cmp	w1, #0x1, lsl #12
    2990:	540000e0 	b.eq	29ac <jbyte+0x7c>  // b.none
  w->out[w->used++] = value;
    2994:	b9401e60 	ldr	w0, [x19, #28]
    2998:	11000401 	add	w1, w0, #0x1
    299c:	b9001e61 	str	w1, [x19, #28]
    29a0:	8b20c260 	add	x0, x19, w0, sxtw
    29a4:	39008014 	strb	w20, [x0, #32]
    29a8:	17fffff1 	b	296c <jbyte+0x3c>
  if(w->used == OUTBUF && jflush(w) < 0)
    29ac:	97ffffbd 	bl	28a0 <jflush>
    29b0:	3100041f 	cmn	w0, #0x1
    29b4:	54ffff01 	b.ne	2994 <jbyte+0x64>  // b.any
    29b8:	17ffffed 	b	296c <jbyte+0x3c>

00000000000029bc <jword>:
{
    29bc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    29c0:	910003fd 	mov	x29, sp
    29c4:	a90153f3 	stp	x19, x20, [sp, #16]
    29c8:	aa0003f4 	mov	x20, x0
    29cc:	2a0103f3 	mov	w19, w1
  jbyte(w, value >> 8);
    29d0:	13087c21 	asr	w1, w1, #8
    29d4:	97ffffd7 	bl	2930 <jbyte>
  jbyte(w, value);
    29d8:	2a1303e1 	mov	w1, w19
    29dc:	aa1403e0 	mov	x0, x20
}
    29e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    29e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
  jbyte(w, value);
    29e8:	17ffffd2 	b	2930 <jbyte>

00000000000029ec <jmarker>:
{
    29ec:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    29f0:	910003fd 	mov	x29, sp
    29f4:	f9000bf3 	str	x19, [sp, #16]
    29f8:	2a0103f3 	mov	w19, w1
  jbyte(w, 0xff);
    29fc:	52801fe1 	mov	w1, #0xff                  	// #255
{
    2a00:	f90017e0 	str	x0, [sp, #40]
  jbyte(w, 0xff);
    2a04:	97ffffcb 	bl	2930 <jbyte>
  jbyte(w, marker);
    2a08:	f94017e0 	ldr	x0, [sp, #40]
    2a0c:	2a1303e1 	mov	w1, w19
}
    2a10:	f9400bf3 	ldr	x19, [sp, #16]
    2a14:	a8c37bfd 	ldp	x29, x30, [sp], #48
  jbyte(w, marker);
    2a18:	17ffffc6 	b	2930 <jbyte>

0000000000002a1c <put_bits>:
  if(count <= 0 || w->error)
    2a1c:	7100005f 	cmp	w2, #0x0
    2a20:	540005ad 	b.le	2ad4 <put_bits+0xb8>
{
    2a24:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2a28:	910003fd 	mov	x29, sp
    2a2c:	a90153f3 	stp	x19, x20, [sp, #16]
    2a30:	aa0003f3 	mov	x19, x0
  if(count <= 0 || w->error)
    2a34:	b9401400 	ldr	w0, [x0, #20]
{
    2a38:	f90013f5 	str	x21, [sp, #32]
  if(count <= 0 || w->error)
    2a3c:	350003a0 	cbnz	w0, 2ab0 <put_bits+0x94>
  value &= (1U << count) - 1;
    2a40:	12800015 	mov	w21, #0xffffffff            	// #-1
    2a44:	1ac222a0 	lsl	w0, w21, w2
    2a48:	0a200021 	bic	w1, w1, w0
  w->bits = (w->bits << count) | value;
    2a4c:	b9502260 	ldr	w0, [x19, #4128]
    2a50:	1ac22000 	lsl	w0, w0, w2
    2a54:	2a000021 	orr	w1, w1, w0
  w->nbits += count;
    2a58:	b9502660 	ldr	w0, [x19, #4132]
  w->bits = (w->bits << count) | value;
    2a5c:	b9102261 	str	w1, [x19, #4128]
  w->nbits += count;
    2a60:	0b000042 	add	w2, w2, w0
    2a64:	b9102662 	str	w2, [x19, #4132]
  while(w->nbits >= 8){
    2a68:	71001c5f 	cmp	w2, #0x7
    2a6c:	5400022d 	b.le	2ab0 <put_bits+0x94>
    w->nbits -= 8;
    2a70:	51002042 	sub	w2, w2, #0x8
    entropy_byte(w, w->bits >> w->nbits);
    2a74:	b9502274 	ldr	w20, [x19, #4128]
    w->nbits -= 8;
    2a78:	b9102662 	str	w2, [x19, #4132]
  jbyte(w, value);
    2a7c:	aa1303e0 	mov	x0, x19
    entropy_byte(w, w->bits >> w->nbits);
    2a80:	1ac22694 	lsr	w20, w20, w2
  jbyte(w, value);
    2a84:	2a1403e1 	mov	w1, w20
  if((value & 255) == 255)
    2a88:	12001e94 	and	w20, w20, #0xff
  jbyte(w, value);
    2a8c:	97ffffa9 	bl	2930 <jbyte>
  if((value & 255) == 255)
    2a90:	7103fe9f 	cmp	w20, #0xff
    2a94:	54000081 	b.ne	2aa4 <put_bits+0x88>  // b.any
    jbyte(w, 0);                    // JPEG byte stuffing
    2a98:	aa1303e0 	mov	x0, x19
    2a9c:	52800001 	mov	w1, #0x0                   	// #0
    2aa0:	97ffffa4 	bl	2930 <jbyte>
    if(w->nbits)
    2aa4:	b9502662 	ldr	w2, [x19, #4132]
    2aa8:	350000c2 	cbnz	w2, 2ac0 <put_bits+0xa4>
    2aac:	b910227f 	str	wzr, [x19, #4128]
}
    2ab0:	f94013f5 	ldr	x21, [sp, #32]
    2ab4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ab8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2abc:	d65f03c0 	ret
      w->bits &= (1U << w->nbits) - 1;
    2ac0:	b9502260 	ldr	w0, [x19, #4128]
    2ac4:	1ac222a1 	lsl	w1, w21, w2
    2ac8:	0a210000 	bic	w0, w0, w1
    2acc:	b9102260 	str	w0, [x19, #4128]
    2ad0:	17ffffe6 	b	2a68 <put_bits+0x4c>
    2ad4:	d65f03c0 	ret

0000000000002ad8 <encode_block>:
// AC uses one eight-bit code per useful baseline symbol: EOB, ZRL, then all
// (run 0..15, size 1..10) combinations.  162/256 of the code space is used.
static void
encode_block(struct jw *w, const short input[64], const uchar quant[64],
             int *previous_dc)
{
    2ad8:	d10883ff 	sub	sp, sp, #0x220
  o[2] = 15137 * a + 6270 * b;
    2adc:	52830fd1 	mov	w17, #0x187e                	// #6270
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2ae0:	5286a6eb 	mov	w11, #0x3537                	// #13623
    2ae4:	528471d0 	mov	w16, #0x238e                	// #9102
    2ae8:	52818f8d 	mov	w13, #0xc7c                 	// #3196
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    2aec:	1287d88c 	mov	w12, #0xffffc13b            	// #-16069
{
    2af0:	a9007bfd 	stp	x29, x30, [sp]
    2af4:	910003fd 	mov	x29, sp
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    2af8:	128471af 	mov	w15, #0xffffdc72            	// #-9102
{
    2afc:	a90153f3 	stp	x19, x20, [sp, #16]
    2b00:	aa0003f3 	mov	x19, x0
  short coefficient[64];
  fdct_quant(input, quant, coefficient);
    2b04:	910483e0 	add	x0, sp, #0x120
{
    2b08:	aa0003e9 	mov	x9, x0
    2b0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2b10:	91020035 	add	x21, x1, #0x80
    2b14:	a90573fb 	stp	x27, x28, [sp, #80]
    2b18:	aa0203fb 	mov	x27, x2
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2b1c:	5285a834 	mov	w20, #0x2d41                	// #11585
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    2b20:	12818f76 	mov	w22, #0xfffff384            	// #-3196
{
    2b24:	a90363f7 	stp	x23, x24, [sp, #48]
  o[6] = 6270 * a - 15137 * b;
    2b28:	12876418 	mov	w24, #0xffffc4df            	// #-15137
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2b2c:	5287d8b7 	mov	w23, #0x3ec5                	// #16069
{
    2b30:	a9046bf9 	stp	x25, x26, [sp, #64]
  o[2] = 15137 * a + 6270 * b;
    2b34:	52876439 	mov	w25, #0x3b21                	// #15137
  int s0 = x[0] + x[7], d0 = x[0] - x[7];
    2b38:	79c01c24 	ldrsh	w4, [x1, #14]
  for(int y = 0; y < 8; y++)
    2b3c:	91004021 	add	x1, x1, #0x10
  int s0 = x[0] + x[7], d0 = x[0] - x[7];
    2b40:	78df0026 	ldursh	w6, [x1, #-16]
  for(int y = 0; y < 8; y++)
    2b44:	91008129 	add	x9, x9, #0x20
  int s1 = x[1] + x[6], d1 = x[1] - x[6];
    2b48:	78df2027 	ldursh	w7, [x1, #-14]
  int s0 = x[0] + x[7], d0 = x[0] - x[7];
    2b4c:	0b0400c2 	add	w2, w6, w4
    2b50:	4b0400c6 	sub	w6, w6, w4
  int s1 = x[1] + x[6], d1 = x[1] - x[6];
    2b54:	78dfc024 	ldursh	w4, [x1, #-4]
  int s2 = x[2] + x[5], d2 = x[2] - x[5];
    2b58:	78df4025 	ldursh	w5, [x1, #-12]
  int s1 = x[1] + x[6], d1 = x[1] - x[6];
    2b5c:	0b0400fe 	add	w30, w7, w4
    2b60:	4b0400e7 	sub	w7, w7, w4
  int s2 = x[2] + x[5], d2 = x[2] - x[5];
    2b64:	78dfa024 	ldursh	w4, [x1, #-6]
  int s3 = x[3] + x[4], d3 = x[3] - x[4];
    2b68:	78df8028 	ldursh	w8, [x1, #-8]
  int s2 = x[2] + x[5], d2 = x[2] - x[5];
    2b6c:	0b0400bc 	add	w28, w5, w4
    2b70:	4b0400a5 	sub	w5, w5, w4
  int s3 = x[3] + x[4], d3 = x[3] - x[4];
    2b74:	78df6024 	ldursh	w4, [x1, #-10]
  int a = s0 - s3, b = s1 - s2;
    2b78:	4b1c03ca 	sub	w10, w30, w28
  int s3 = x[3] + x[4], d3 = x[3] - x[4];
    2b7c:	0b08009a 	add	w26, w4, w8
    2b80:	4b080084 	sub	w4, w4, w8
  int a = s0 - s3, b = s1 - s2;
    2b84:	4b1a0052 	sub	w18, w2, w26
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2b88:	0b1e0048 	add	w8, w2, w30
  o[2] = 15137 * a + 6270 * b;
    2b8c:	1b117d4e 	mul	w14, w10, w17
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2b90:	0b1c0108 	add	w8, w8, w28
  o[6] = 6270 * a - 15137 * b;
    2b94:	1b187d4a 	mul	w10, w10, w24
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2b98:	0b1a0108 	add	w8, w8, w26
  o[2] = 15137 * a + 6270 * b;
    2b9c:	1b193a4e 	madd	w14, w18, w25, w14
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2ba0:	4b1e0042 	sub	w2, w2, w30
  o[6] = 6270 * a - 15137 * b;
    2ba4:	1b112a4a 	madd	w10, w18, w17, w10
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2ba8:	4b1c0042 	sub	w2, w2, w28
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2bac:	1b0b7cf2 	mul	w18, w7, w11
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2bb0:	0b1a0042 	add	w2, w2, w26
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2bb4:	1b1748d2 	madd	w18, w6, w23, w18
    2bb8:	1b1048b2 	madd	w18, w5, w16, w18
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2bbc:	1b147d08 	mul	w8, w8, w20
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2bc0:	1b0d4892 	madd	w18, w4, w13, w18
    2bc4:	293c4928 	stp	w8, w18, [x9, #-32]
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    2bc8:	1b167ce8 	mul	w8, w7, w22
    2bcc:	1b0b20c8 	madd	w8, w6, w11, w8
    2bd0:	1b0c20a8 	madd	w8, w5, w12, w8
    2bd4:	1b0f2088 	madd	w8, w4, w15, w8
    2bd8:	293d212e 	stp	w14, w8, [x9, #-24]
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2bdc:	1b0c7ce8 	mul	w8, w7, w12
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2be0:	1b0f7ce7 	mul	w7, w7, w15
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2be4:	1b1020c8 	madd	w8, w6, w16, w8
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2be8:	1b0d1cc6 	madd	w6, w6, w13, w7
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2bec:	1b0d20a8 	madd	w8, w5, w13, w8
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2bf0:	1b0b18a5 	madd	w5, w5, w11, w6
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2bf4:	1b0b2088 	madd	w8, w4, w11, w8
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2bf8:	1b147c42 	mul	w2, w2, w20
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2bfc:	1b0c1484 	madd	w4, w4, w12, w5
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2c00:	293e2122 	stp	w2, w8, [x9, #-16]
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2c04:	293f112a 	stp	w10, w4, [x9, #-8]
  for(int y = 0; y < 8; y++)
    2c08:	eb0102bf 	cmp	x21, x1
    2c0c:	54fff961 	b.ne	2b38 <encode_block+0x60>  // b.any
    2c10:	910283ea 	add	x10, sp, #0xa0
      long long sum = coefficient[v];
    2c14:	910183fc 	add	x28, sp, #0x60
  for(int y = 0; y < 8; y++)
    2c18:	d2800009 	mov	x9, #0x0                   	// #0
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2c1c:	d285a83e 	mov	x30, #0x2d41                	// #11585
  o[2] = 15137 * a + 6270 * b;
    2c20:	d2876437 	mov	x23, #0x3b21                	// #15137
    2c24:	d2830fc2 	mov	x2, #0x187e                	// #6270
  o[6] = 6270 * a - 15137 * b;
    2c28:	92876418 	mov	x24, #0xffffffffffffc4df    	// #-15137
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2c2c:	d287d8b9 	mov	x25, #0x3ec5                	// #16069
    2c30:	d286a6eb 	mov	x11, #0x3537                	// #13623
    2c34:	d28471d4 	mov	x20, #0x238e                	// #9102
    2c38:	d2818f8e 	mov	x14, #0xc7c                 	// #3196
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    2c3c:	92818f7a 	mov	x26, #0xfffffffffffff384    	// #-3196
    2c40:	9287d88f 	mov	x15, #0xffffffffffffc13b    	// #-16069
    2c44:	928471b5 	mov	x21, #0xffffffffffffdc72    	// #-9102
    2c48:	d2a40016 	mov	x22, #0x20000000            	// #536870912
  long long s0 = (long long)x[0]  + x[56];
    2c4c:	b980e004 	ldrsw	x4, [x0, #224]
    2c50:	b9800006 	ldrsw	x6, [x0]
  long long s1 = (long long)x[8]  + x[48];
    2c54:	b9802007 	ldrsw	x7, [x0, #32]
  long long s0 = (long long)x[0]  + x[56];
    2c58:	8b0400c1 	add	x1, x6, x4
  long long d0 = (long long)x[0]  - x[56];
    2c5c:	cb0400c6 	sub	x6, x6, x4
  long long s1 = (long long)x[8]  + x[48];
    2c60:	b980c004 	ldrsw	x4, [x0, #192]
  long long s2 = (long long)x[16] + x[40];
    2c64:	b9804005 	ldrsw	x5, [x0, #64]
  long long s1 = (long long)x[8]  + x[48];
    2c68:	8b0400f2 	add	x18, x7, x4
  long long d1 = (long long)x[8]  - x[48];
    2c6c:	cb0400e7 	sub	x7, x7, x4
  long long s2 = (long long)x[16] + x[40];
    2c70:	b980a004 	ldrsw	x4, [x0, #160]
  long long s3 = (long long)x[24] + x[32];
    2c74:	b9808008 	ldrsw	x8, [x0, #128]
  long long s2 = (long long)x[16] + x[40];
    2c78:	8b0400b1 	add	x17, x5, x4
  long long d2 = (long long)x[16] - x[40];
    2c7c:	cb0400a5 	sub	x5, x5, x4
  long long s3 = (long long)x[24] + x[32];
    2c80:	b9806004 	ldrsw	x4, [x0, #96]
  long long a = s0 - s3, b = s1 - s2;
    2c84:	cb11024d 	sub	x13, x18, x17
  long long s3 = (long long)x[24] + x[32];
    2c88:	8b080090 	add	x16, x4, x8
  long long d3 = (long long)x[24] - x[32];
    2c8c:	cb080084 	sub	x4, x4, x8
  long long a = s0 - s3, b = s1 - s2;
    2c90:	cb10002c 	sub	x12, x1, x16
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2c94:	8b120028 	add	x8, x1, x18
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2c98:	cb120021 	sub	x1, x1, x18
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2c9c:	8b110108 	add	x8, x8, x17
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2ca0:	cb110021 	sub	x1, x1, x17
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2ca4:	8b100108 	add	x8, x8, x16
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2ca8:	8b100021 	add	x1, x1, x16
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2cac:	9b1e7d08 	mul	x8, x8, x30
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2cb0:	9b1e7c21 	mul	x1, x1, x30
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    2cb4:	f90033e8 	str	x8, [sp, #96]
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    2cb8:	f90043e1 	str	x1, [sp, #128]
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2cbc:	9b0b7ce1 	mul	x1, x7, x11
    2cc0:	9b1904c1 	madd	x1, x6, x25, x1
  o[2] = 15137 * a + 6270 * b;
    2cc4:	9b027da8 	mul	x8, x13, x2
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2cc8:	9b1404a1 	madd	x1, x5, x20, x1
    2ccc:	9b0e0481 	madd	x1, x4, x14, x1
  o[2] = 15137 * a + 6270 * b;
    2cd0:	9b172188 	madd	x8, x12, x23, x8
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    2cd4:	a906a3e1 	stp	x1, x8, [sp, #104]
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    2cd8:	9b1a7ce1 	mul	x1, x7, x26
    2cdc:	9b0b04c1 	madd	x1, x6, x11, x1
    2ce0:	9b0f04a1 	madd	x1, x5, x15, x1
    2ce4:	9b150481 	madd	x1, x4, x21, x1
    2ce8:	f9003fe1 	str	x1, [sp, #120]
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2cec:	9b0f7ce1 	mul	x1, x7, x15
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2cf0:	9b157ce7 	mul	x7, x7, x21
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2cf4:	9b1404c1 	madd	x1, x6, x20, x1
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2cf8:	9b0e1cc6 	madd	x6, x6, x14, x7
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2cfc:	9b0e04a1 	madd	x1, x5, x14, x1
  o[6] = 6270 * a - 15137 * b;
    2d00:	9b187dad 	mul	x13, x13, x24
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2d04:	9b0b18a5 	madd	x5, x5, x11, x6
      int q = quant[v * 8 + u];
    2d08:	8b090366 	add	x6, x27, x9
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    2d0c:	9b0b0481 	madd	x1, x4, x11, x1
  o[6] = 6270 * a - 15137 * b;
    2d10:	9b02358c 	madd	x12, x12, x2, x13
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2d14:	9b0f1484 	madd	x4, x4, x15, x5
    2d18:	d2800005 	mov	x5, #0x0                   	// #0
    2d1c:	a908b3e1 	stp	x1, x12, [sp, #136]
    2d20:	f9004fe4 	str	x4, [sp, #152]
      long long sum = coefficient[v];
    2d24:	f87c68a7 	ldr	x7, [x5, x28]
        value = (sum + ((long long)1 << 29)) >> 30;
    2d28:	8b1600e1 	add	x1, x7, x22
    2d2c:	cb0702c4 	sub	x4, x22, x7
    2d30:	f10000ff 	cmp	x7, #0x0
      int q = quant[v * 8 + u];
    2d34:	386568c7 	ldrb	w7, [x6, x5]
        value = (sum + ((long long)1 << 29)) >> 30;
    2d38:	935efc21 	asr	x1, x1, #30
    2d3c:	935efc84 	asr	x4, x4, #30
    2d40:	5a84a424 	csneg	w4, w1, w4, ge	// ge = tcont
        value = (value + q / 2) / q;
    2d44:	13017ce1 	asr	w1, w7, #1
      if(value >= 0)
    2d48:	37f80824 	tbnz	w4, #31, 2e4c <encode_block+0x374>
        value = (value + q / 2) / q;
    2d4c:	0b010084 	add	w4, w4, w1
    2d50:	1ac70881 	udiv	w1, w4, w7
      output[v * 8 + u] = value;
    2d54:	78257941 	strh	w1, [x10, x5, lsl #1]
    for(int v = 0; v < 8; v++){
    2d58:	910020a5 	add	x5, x5, #0x8
    2d5c:	f10100bf 	cmp	x5, #0x40
    2d60:	54fffe21 	b.ne	2d24 <encode_block+0x24c>  // b.any
  for(int u = 0; u < 8; u++){
    2d64:	91000529 	add	x9, x9, #0x1
    2d68:	91001000 	add	x0, x0, #0x4
    2d6c:	9100094a 	add	x10, x10, #0x2
    2d70:	f100213f 	cmp	x9, #0x8
    2d74:	54fff6c1 	b.ne	2c4c <encode_block+0x174>  // b.any

  int dc = coefficient[0];
  int diff = dc - *previous_dc;
    2d78:	b9400060 	ldr	w0, [x3]
  *previous_dc = dc;
  int size = category(diff);
  if(size > 11) size = 11;
    2d7c:	52800415 	mov	w21, #0x20                  	// #32
  int dc = coefficient[0];
    2d80:	79c143f4 	ldrsh	w20, [sp, #160]
  put_bits(w, size, 4);
    2d84:	52800082 	mov	w2, #0x4                   	// #4
  *previous_dc = dc;
    2d88:	b9000074 	str	w20, [x3]
  uint v = value < 0 ? -value : value;
    2d8c:	6b000294 	subs	w20, w20, w0
  if(size > 11) size = 11;
    2d90:	52800160 	mov	w0, #0xb                   	// #11
  uint v = value < 0 ? -value : value;
    2d94:	5a945696 	cneg	w22, w20, mi	// mi = first
    2d98:	5ac012d6 	clz	w22, w22
  if(size > 11) size = 11;
    2d9c:	4b1602b5 	sub	w21, w21, w22
    2da0:	71002ebf 	cmp	w21, #0xb
    2da4:	1a80d2b5 	csel	w21, w21, w0, le
  put_bits(w, size, 4);
    2da8:	aa1303e0 	mov	x0, x19
    2dac:	2a1503e1 	mov	w1, w21
    2db0:	97ffff1b 	bl	2a1c <put_bits>
  if(size)
    2db4:	710082df 	cmp	w22, #0x20
    2db8:	54000140 	b.eq	2de0 <encode_block+0x308>  // b.none
  if(value >= 0)
    2dbc:	7100029f 	cmp	w20, #0x0
  return value + (1U << size) - 1;
    2dc0:	51000680 	sub	w0, w20, #0x1
    2dc4:	52800021 	mov	w1, #0x1                   	// #1
    put_bits(w, amplitude(diff, size), size);
    2dc8:	2a1503e2 	mov	w2, w21
  return value + (1U << size) - 1;
    2dcc:	1ad52021 	lsl	w1, w1, w21
    2dd0:	0b000021 	add	w1, w1, w0
    put_bits(w, amplitude(diff, size), size);
    2dd4:	1a81a281 	csel	w1, w20, w1, ge	// ge = tcont
    2dd8:	aa1303e0 	mov	x0, x19
    2ddc:	97ffff10 	bl	2a1c <put_bits>
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    2de0:	d2800036 	mov	x22, #0x1                   	// #1

  int run = 0;
  for(int k = 1; k < 64; k++){
    int value = coefficient[zigzag[k]];
    2de4:	d0000017 	adrp	x23, 4000 <head.0+0x39>
    2de8:	9106c2f7 	add	x23, x23, #0x1b0
    if(value == 0){
      run++;
      continue;
    }
    while(run >= 16){
      put_bits(w, 1, 8);            // symbol index 1 is ZRL (0xf0)
    2dec:	2a1603f8 	mov	w24, w22
  int run = 0;
    2df0:	52800014 	mov	w20, #0x0                   	// #0
      run -= 16;
    }
    if(value > 1023) value = 1023;
    if(value < -1023) value = -1023;
    2df4:	12807fd9 	mov	w25, #0xfffffc01            	// #-1023
    if(value > 1023) value = 1023;
    2df8:	52807ffa 	mov	w26, #0x3ff                 	// #1023
    int value = coefficient[zigzag[k]];
    2dfc:	38766ae0 	ldrb	w0, [x23, x22]
    2e00:	910283e1 	add	x1, sp, #0xa0
    2e04:	78e0783c 	ldrsh	w28, [x1, x0, lsl #1]
    if(value == 0){
    2e08:	3500035c 	cbnz	w28, 2e70 <encode_block+0x398>
      run++;
    2e0c:	11000694 	add	w20, w20, #0x1
  for(int k = 1; k < 64; k++){
    2e10:	910006d6 	add	x22, x22, #0x1
    2e14:	f10102df 	cmp	x22, #0x40
    2e18:	54ffff21 	b.ne	2dfc <encode_block+0x324>  // b.any
    int code = 2 + run * 10 + size - 1;
    put_bits(w, code, 8);
    put_bits(w, amplitude(value, size), size);
    run = 0;
  }
  if(run)
    2e1c:	34000614 	cbz	w20, 2edc <encode_block+0x404>
    put_bits(w, 0, 8);              // symbol index 0 is EOB
}
    2e20:	a9407bfd 	ldp	x29, x30, [sp]
    put_bits(w, 0, 8);              // symbol index 0 is EOB
    2e24:	aa1303e0 	mov	x0, x19
}
    2e28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    put_bits(w, 0, 8);              // symbol index 0 is EOB
    2e2c:	52800102 	mov	w2, #0x8                   	// #8
}
    2e30:	a94153f3 	ldp	x19, x20, [sp, #16]
    put_bits(w, 0, 8);              // symbol index 0 is EOB
    2e34:	52800001 	mov	w1, #0x0                   	// #0
}
    2e38:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e3c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    2e40:	a94573fb 	ldp	x27, x28, [sp, #80]
    2e44:	910883ff 	add	sp, sp, #0x220
    put_bits(w, 0, 8);              // symbol index 0 is EOB
    2e48:	17fffef5 	b	2a1c <put_bits>
        value = -((-value + q / 2) / q);
    2e4c:	4b040021 	sub	w1, w1, w4
    2e50:	1ac70821 	udiv	w1, w1, w7
    2e54:	4b0103e1 	neg	w1, w1
    2e58:	17ffffbf 	b	2d54 <encode_block+0x27c>
      run -= 16;
    2e5c:	51004294 	sub	w20, w20, #0x10
      put_bits(w, 1, 8);            // symbol index 1 is ZRL (0xf0)
    2e60:	aa1303e0 	mov	x0, x19
    2e64:	52800102 	mov	w2, #0x8                   	// #8
    2e68:	52800021 	mov	w1, #0x1                   	// #1
    2e6c:	97fffeec 	bl	2a1c <put_bits>
    while(run >= 16){
    2e70:	71003e9f 	cmp	w20, #0xf
    2e74:	54ffff4c 	b.gt	2e5c <encode_block+0x384>
    if(value < -1023) value = -1023;
    2e78:	310fff9f 	cmn	w28, #0x3ff
    2e7c:	5280041b 	mov	w27, #0x20                  	// #32
    2e80:	1a99a395 	csel	w21, w28, w25, ge	// ge = tcont
    put_bits(w, code, 8);
    2e84:	52800102 	mov	w2, #0x8                   	// #8
    if(value > 1023) value = 1023;
    2e88:	710ffebf 	cmp	w21, #0x3ff
    2e8c:	1a9ad2b5 	csel	w21, w21, w26, le
  uint v = value < 0 ? -value : value;
    2e90:	710002bf 	cmp	w21, #0x0
    2e94:	5a95a6a0 	cneg	w0, w21, lt	// lt = tstop
    2e98:	5ac01000 	clz	w0, w0
    2e9c:	4b00037b 	sub	w27, w27, w0
    int code = 2 + run * 10 + size - 1;
    2ea0:	52800140 	mov	w0, #0xa                   	// #10
    2ea4:	1b006e81 	madd	w1, w20, w0, w27
    put_bits(w, code, 8);
    2ea8:	aa1303e0 	mov	x0, x19
    run = 0;
    2eac:	52800014 	mov	w20, #0x0                   	// #0
    put_bits(w, code, 8);
    2eb0:	11000421 	add	w1, w1, #0x1
    2eb4:	97fffeda 	bl	2a1c <put_bits>
  if(value >= 0)
    2eb8:	7100039f 	cmp	w28, #0x0
  return value + (1U << size) - 1;
    2ebc:	510006a0 	sub	w0, w21, #0x1
    2ec0:	1adb2301 	lsl	w1, w24, w27
    2ec4:	0b000021 	add	w1, w1, w0
    put_bits(w, amplitude(value, size), size);
    2ec8:	2a1b03e2 	mov	w2, w27
    2ecc:	1a81a2a1 	csel	w1, w21, w1, ge	// ge = tcont
    2ed0:	aa1303e0 	mov	x0, x19
    2ed4:	97fffed2 	bl	2a1c <put_bits>
    run = 0;
    2ed8:	17ffffce 	b	2e10 <encode_block+0x338>
}
    2edc:	a9407bfd 	ldp	x29, x30, [sp]
    2ee0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ee4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ee8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2eec:	a9446bf9 	ldp	x25, x26, [sp, #64]
    2ef0:	a94573fb 	ldp	x27, x28, [sp, #80]
    2ef4:	910883ff 	add	sp, sp, #0x220
    2ef8:	d65f03c0 	ret

0000000000002efc <jpeg_encode_to>:
}

static int
jpeg_encode_to(struct jw *w, int width, int height, int quality,
               jpeg_pixel_fn pixel, void *arg, uint *written)
{
    2efc:	d116c3ff 	sub	sp, sp, #0x5b0
    2f00:	a9007bfd 	stp	x29, x30, [sp]
    2f04:	910003fd 	mov	x29, sp
    2f08:	a90153f3 	stp	x19, x20, [sp, #16]
    2f0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f10:	a90363f7 	stp	x23, x24, [sp, #48]
    2f14:	aa0403f7 	mov	x23, x4
  uchar qy[64], qc[64];
  uchar rgb[16][16][3];
  short yblock[64], cb[64], cr[64];
  int pred_y = 0, pred_cb = 0, pred_cr = 0;

  if(width <= 0 || height <= 0 || width > 65535 ||
    2f18:	529fffc4 	mov	w4, #0xfffe                	// #65534
{
    2f1c:	a9046bf9 	stp	x25, x26, [sp, #64]
    2f20:	a90573fb 	stp	x27, x28, [sp, #80]
  if(width <= 0 || height <= 0 || width > 65535 ||
    2f24:	5100043c 	sub	w28, w1, #0x1
    2f28:	5100045b 	sub	w27, w2, #0x1
{
    2f2c:	f90037e6 	str	x6, [sp, #104]
  if(width <= 0 || height <= 0 || width > 65535 ||
    2f30:	6b04039f 	cmp	w28, w4
  int pred_y = 0, pred_cb = 0, pred_cr = 0;
    2f34:	2914ffff 	stp	wzr, wzr, [sp, #164]
  if(width <= 0 || height <= 0 || width > 65535 ||
    2f38:	7a449362 	ccmp	w27, w4, #0x2, ls	// ls = plast
  int pred_y = 0, pred_cb = 0, pred_cr = 0;
    2f3c:	b900afff 	str	wzr, [sp, #172]
  if(width <= 0 || height <= 0 || width > 65535 ||
    2f40:	54000088 	b.hi	2f50 <jpeg_encode_to+0x54>  // b.pmore
     height > 65535 || quality < 1 || quality > 100 || pixel == 0)
    2f44:	51000464 	sub	w4, w3, #0x1
    2f48:	71018c9f 	cmp	w4, #0x63
    2f4c:	54000149 	b.ls	2f74 <jpeg_encode_to+0x78>  // b.plast
    return -1;
    2f50:	12800000 	mov	w0, #0xffffffff            	// #-1
  if(jflush(w) < 0 || w->error)
    return -1;
  if(written)
    *written = w->total;
  return 0;
}
    2f54:	a9407bfd 	ldp	x29, x30, [sp]
    2f58:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f60:	a94363f7 	ldp	x23, x24, [sp, #48]
    2f64:	a9446bf9 	ldp	x25, x26, [sp, #64]
    2f68:	a94573fb 	ldp	x27, x28, [sp, #80]
    2f6c:	9116c3ff 	add	sp, sp, #0x5b0
    2f70:	d65f03c0 	ret
     height > 65535 || quality < 1 || quality > 100 || pixel == 0)
    2f74:	b4fffef7 	cbz	x23, 2f50 <jpeg_encode_to+0x54>
  make_quant(qy, qbase_y, quality);
    2f78:	9102c3f9 	add	x25, sp, #0xb0
    2f7c:	d0000016 	adrp	x22, 4000 <head.0+0x39>
    2f80:	9106c2d6 	add	x22, x22, #0x1b0
    2f84:	2a0303e7 	mov	w7, w3
    2f88:	aa0003f3 	mov	x19, x0
    2f8c:	2a0203f5 	mov	w21, w2
    2f90:	aa1903e0 	mov	x0, x25
    2f94:	2a0303e2 	mov	w2, w3
    2f98:	2a0103f4 	mov	w20, w1
    2f9c:	910102c1 	add	x1, x22, #0x40
    2fa0:	f9003be5 	str	x5, [sp, #112]
    2fa4:	97fffe23 	bl	2830 <make_quant>
  make_quant(qc, qbase_c, quality);
    2fa8:	2a0703e2 	mov	w2, w7
    2fac:	9103c3f8 	add	x24, sp, #0xf0
    2fb0:	910202c1 	add	x1, x22, #0x80
    2fb4:	aa1803e0 	mov	x0, x24
    2fb8:	97fffe1e 	bl	2830 <make_quant>
  jmarker(w, 0xd8);                 // SOI
    2fbc:	aa1303e0 	mov	x0, x19
    2fc0:	52801b01 	mov	w1, #0xd8                  	// #216
    2fc4:	97fffe8a 	bl	29ec <jmarker>
  jmarker(w, 0xe0);                 // JFIF APP0
    2fc8:	aa1303e0 	mov	x0, x19
    2fcc:	52801c01 	mov	w1, #0xe0                  	// #224
    2fd0:	97fffe87 	bl	29ec <jmarker>
  jbyte(w, 0);
    2fd4:	d280001a 	mov	x26, #0x0                   	// #0
  jword(w, 16);
    2fd8:	aa1303e0 	mov	x0, x19
    2fdc:	52800201 	mov	w1, #0x10                  	// #16
    2fe0:	97fffe77 	bl	29bc <jword>
  jbyte(w, 'J'); jbyte(w, 'F'); jbyte(w, 'I'); jbyte(w, 'F'); jbyte(w, 0);
    2fe4:	aa1303e0 	mov	x0, x19
    2fe8:	52800941 	mov	w1, #0x4a                  	// #74
    2fec:	97fffe51 	bl	2930 <jbyte>
    2ff0:	aa1303e0 	mov	x0, x19
    2ff4:	528008c1 	mov	w1, #0x46                  	// #70
    2ff8:	97fffe4e 	bl	2930 <jbyte>
    2ffc:	aa1303e0 	mov	x0, x19
    3000:	52800921 	mov	w1, #0x49                  	// #73
    3004:	97fffe4b 	bl	2930 <jbyte>
    3008:	aa1303e0 	mov	x0, x19
    300c:	528008c1 	mov	w1, #0x46                  	// #70
    3010:	97fffe48 	bl	2930 <jbyte>
    3014:	aa1303e0 	mov	x0, x19
    3018:	52800001 	mov	w1, #0x0                   	// #0
    301c:	97fffe45 	bl	2930 <jbyte>
  jbyte(w, 1); jbyte(w, 1); jbyte(w, 0);
    3020:	aa1303e0 	mov	x0, x19
    3024:	52800021 	mov	w1, #0x1                   	// #1
    3028:	97fffe42 	bl	2930 <jbyte>
    302c:	aa1303e0 	mov	x0, x19
    3030:	52800021 	mov	w1, #0x1                   	// #1
    3034:	97fffe3f 	bl	2930 <jbyte>
    3038:	aa1303e0 	mov	x0, x19
    303c:	52800001 	mov	w1, #0x0                   	// #0
    3040:	97fffe3c 	bl	2930 <jbyte>
  jword(w, 1); jword(w, 1); jbyte(w, 0); jbyte(w, 0);
    3044:	aa1303e0 	mov	x0, x19
    3048:	52800021 	mov	w1, #0x1                   	// #1
    304c:	97fffe5c 	bl	29bc <jword>
    3050:	aa1303e0 	mov	x0, x19
    3054:	52800021 	mov	w1, #0x1                   	// #1
    3058:	97fffe59 	bl	29bc <jword>
    305c:	aa1303e0 	mov	x0, x19
    3060:	52800001 	mov	w1, #0x0                   	// #0
    3064:	97fffe33 	bl	2930 <jbyte>
    3068:	aa1303e0 	mov	x0, x19
    306c:	52800001 	mov	w1, #0x0                   	// #0
    3070:	97fffe30 	bl	2930 <jbyte>
  jmarker(w, 0xdb);                 // two 8-bit quantization tables
    3074:	aa1303e0 	mov	x0, x19
    3078:	52801b61 	mov	w1, #0xdb                  	// #219
    307c:	97fffe5c 	bl	29ec <jmarker>
  jword(w, 132);
    3080:	aa1303e0 	mov	x0, x19
    3084:	52801081 	mov	w1, #0x84                  	// #132
    3088:	97fffe4d 	bl	29bc <jword>
  jbyte(w, 0);
    308c:	aa1303e0 	mov	x0, x19
    3090:	52800001 	mov	w1, #0x0                   	// #0
    3094:	97fffe27 	bl	2930 <jbyte>
  for(int i = 0; i < 64; i++) jbyte(w, qy[zigzag[i]]);
    3098:	387a6ac0 	ldrb	w0, [x22, x26]
    309c:	9100075a 	add	x26, x26, #0x1
    30a0:	38606b21 	ldrb	w1, [x25, x0]
    30a4:	aa1303e0 	mov	x0, x19
    30a8:	97fffe22 	bl	2930 <jbyte>
    30ac:	f101035f 	cmp	x26, #0x40
    30b0:	54ffff41 	b.ne	3098 <jpeg_encode_to+0x19c>  // b.any
  jbyte(w, 1);
    30b4:	d280001a 	mov	x26, #0x0                   	// #0
    30b8:	aa1303e0 	mov	x0, x19
    30bc:	52800021 	mov	w1, #0x1                   	// #1
    30c0:	97fffe1c 	bl	2930 <jbyte>
  for(int i = 0; i < 64; i++) jbyte(w, qc[zigzag[i]]);
    30c4:	387a6ac0 	ldrb	w0, [x22, x26]
    30c8:	9100075a 	add	x26, x26, #0x1
    30cc:	38606b01 	ldrb	w1, [x24, x0]
    30d0:	aa1303e0 	mov	x0, x19
    30d4:	97fffe17 	bl	2930 <jbyte>
    30d8:	f101035f 	cmp	x26, #0x40
    30dc:	54ffff41 	b.ne	30c4 <jpeg_encode_to+0x1c8>  // b.any
  jmarker(w, 0xc0);                 // baseline SOF, Y 2x2 and Cb/Cr 1x1
    30e0:	aa1303e0 	mov	x0, x19
    30e4:	52801801 	mov	w1, #0xc0                  	// #192
    30e8:	97fffe41 	bl	29ec <jmarker>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 4 ? 12 : 0);
    30ec:	52800036 	mov	w22, #0x1                   	// #1
  jword(w, 17); jbyte(w, 8); jword(w, height); jword(w, width); jbyte(w, 3);
    30f0:	aa1303e0 	mov	x0, x19
    30f4:	52800221 	mov	w1, #0x11                  	// #17
    30f8:	97fffe31 	bl	29bc <jword>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 4 ? 12 : 0);
    30fc:	52800198 	mov	w24, #0xc                   	// #12
  jword(w, 17); jbyte(w, 8); jword(w, height); jword(w, width); jbyte(w, 3);
    3100:	aa1303e0 	mov	x0, x19
    3104:	52800101 	mov	w1, #0x8                   	// #8
    3108:	97fffe0a 	bl	2930 <jbyte>
    310c:	2a1503e1 	mov	w1, w21
    3110:	aa1303e0 	mov	x0, x19
    3114:	97fffe2a 	bl	29bc <jword>
    3118:	2a1403e1 	mov	w1, w20
    311c:	aa1303e0 	mov	x0, x19
    3120:	97fffe27 	bl	29bc <jword>
    3124:	aa1303e0 	mov	x0, x19
    3128:	52800061 	mov	w1, #0x3                   	// #3
    312c:	97fffe01 	bl	2930 <jbyte>
  jbyte(w, 1); jbyte(w, 0x22); jbyte(w, 0);
    3130:	aa1303e0 	mov	x0, x19
    3134:	52800021 	mov	w1, #0x1                   	// #1
    3138:	97fffdfe 	bl	2930 <jbyte>
    313c:	aa1303e0 	mov	x0, x19
    3140:	52800441 	mov	w1, #0x22                  	// #34
    3144:	97fffdfb 	bl	2930 <jbyte>
    3148:	aa1303e0 	mov	x0, x19
    314c:	52800001 	mov	w1, #0x0                   	// #0
    3150:	97fffdf8 	bl	2930 <jbyte>
  jbyte(w, 2); jbyte(w, 0x11); jbyte(w, 1);
    3154:	aa1303e0 	mov	x0, x19
    3158:	52800041 	mov	w1, #0x2                   	// #2
    315c:	97fffdf5 	bl	2930 <jbyte>
    3160:	aa1303e0 	mov	x0, x19
    3164:	52800221 	mov	w1, #0x11                  	// #17
    3168:	97fffdf2 	bl	2930 <jbyte>
    316c:	aa1303e0 	mov	x0, x19
    3170:	52800021 	mov	w1, #0x1                   	// #1
    3174:	97fffdef 	bl	2930 <jbyte>
  jbyte(w, 3); jbyte(w, 0x11); jbyte(w, 1);
    3178:	aa1303e0 	mov	x0, x19
    317c:	52800061 	mov	w1, #0x3                   	// #3
    3180:	97fffdec 	bl	2930 <jbyte>
    3184:	aa1303e0 	mov	x0, x19
    3188:	52800221 	mov	w1, #0x11                  	// #17
    318c:	97fffde9 	bl	2930 <jbyte>
    3190:	aa1303e0 	mov	x0, x19
    3194:	52800021 	mov	w1, #0x1                   	// #1
    3198:	97fffde6 	bl	2930 <jbyte>
  jmarker(w, 0xc4);                 // one DC and one AC Huffman table
    319c:	aa1303e0 	mov	x0, x19
    31a0:	52801881 	mov	w1, #0xc4                  	// #196
    31a4:	97fffe12 	bl	29ec <jmarker>
  jword(w, 210);
    31a8:	aa1303e0 	mov	x0, x19
    31ac:	52801a41 	mov	w1, #0xd2                  	// #210
    31b0:	97fffe03 	bl	29bc <jword>
  jbyte(w, 0x00);                   // DC table 0
    31b4:	52800001 	mov	w1, #0x0                   	// #0
    31b8:	aa1303e0 	mov	x0, x19
    31bc:	97fffddd 	bl	2930 <jbyte>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 4 ? 12 : 0);
    31c0:	52800001 	mov	w1, #0x0                   	// #0
    31c4:	aa1303e0 	mov	x0, x19
    31c8:	110006d6 	add	w22, w22, #0x1
    31cc:	97fffdd9 	bl	2930 <jbyte>
    31d0:	710046df 	cmp	w22, #0x11
    31d4:	54000981 	b.ne	3304 <jpeg_encode_to+0x408>  // b.any
  for(int i = 0; i < 12; i++) jbyte(w, i);
    31d8:	52800016 	mov	w22, #0x0                   	// #0
    31dc:	2a1603e1 	mov	w1, w22
    31e0:	aa1303e0 	mov	x0, x19
    31e4:	110006d6 	add	w22, w22, #0x1
    31e8:	97fffdd2 	bl	2930 <jbyte>
    31ec:	710032df 	cmp	w22, #0xc
    31f0:	54ffff61 	b.ne	31dc <jpeg_encode_to+0x2e0>  // b.any
  jbyte(w, 0x10);                   // AC table 0
    31f4:	52800201 	mov	w1, #0x10                  	// #16
    31f8:	aa1303e0 	mov	x0, x19
    31fc:	97fffdcd 	bl	2930 <jbyte>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 8 ? 162 : 0);
    3200:	52800036 	mov	w22, #0x1                   	// #1
    3204:	52800001 	mov	w1, #0x0                   	// #0
    3208:	52801458 	mov	w24, #0xa2                  	// #162
    320c:	aa1303e0 	mov	x0, x19
    3210:	110006d6 	add	w22, w22, #0x1
    3214:	97fffdc7 	bl	2930 <jbyte>
    3218:	710046df 	cmp	w22, #0x11
    321c:	540007a1 	b.ne	3310 <jpeg_encode_to+0x414>  // b.any
  jbyte(w, 0xf0);                   // ZRL
    3220:	52800018 	mov	w24, #0x0                   	// #0
  jbyte(w, 0x00);                   // EOB
    3224:	aa1303e0 	mov	x0, x19
    3228:	52800001 	mov	w1, #0x0                   	// #0
    322c:	97fffdc1 	bl	2930 <jbyte>
  jbyte(w, 0xf0);                   // ZRL
    3230:	aa1303e0 	mov	x0, x19
    3234:	52801e01 	mov	w1, #0xf0                  	// #240
    3238:	97fffdbe 	bl	2930 <jbyte>
    for(int size = 1; size <= 10; size++)
    323c:	52800036 	mov	w22, #0x1                   	// #1
      jbyte(w, (run << 4) | size);
    3240:	2a160301 	orr	w1, w24, w22
    3244:	aa1303e0 	mov	x0, x19
    for(int size = 1; size <= 10; size++)
    3248:	110006d6 	add	w22, w22, #0x1
      jbyte(w, (run << 4) | size);
    324c:	97fffdb9 	bl	2930 <jbyte>
    for(int size = 1; size <= 10; size++)
    3250:	71002edf 	cmp	w22, #0xb
    3254:	54ffff61 	b.ne	3240 <jpeg_encode_to+0x344>  // b.any
  for(int run = 0; run < 16; run++)
    3258:	11004318 	add	w24, w24, #0x10
    325c:	7104031f 	cmp	w24, #0x100
    3260:	54fffee1 	b.ne	323c <jpeg_encode_to+0x340>  // b.any
  jmarker(w, 0xda);                 // SOS
    3264:	aa1303e0 	mov	x0, x19
    3268:	52801b41 	mov	w1, #0xda                  	// #218
    326c:	97fffde0 	bl	29ec <jmarker>
  for(int my = 0; my < height; my += 16){
    3270:	52800016 	mov	w22, #0x0                   	// #0
  jword(w, 12); jbyte(w, 3);
    3274:	aa1303e0 	mov	x0, x19
    3278:	52800181 	mov	w1, #0xc                   	// #12
    327c:	97fffdd0 	bl	29bc <jword>
    3280:	aa1303e0 	mov	x0, x19
    3284:	52800061 	mov	w1, #0x3                   	// #3
    3288:	97fffdaa 	bl	2930 <jbyte>
  jbyte(w, 1); jbyte(w, 0x00);
    328c:	aa1303e0 	mov	x0, x19
    3290:	52800021 	mov	w1, #0x1                   	// #1
    3294:	97fffda7 	bl	2930 <jbyte>
    3298:	aa1303e0 	mov	x0, x19
    329c:	52800001 	mov	w1, #0x0                   	// #0
    32a0:	97fffda4 	bl	2930 <jbyte>
  jbyte(w, 2); jbyte(w, 0x00);
    32a4:	aa1303e0 	mov	x0, x19
    32a8:	52800041 	mov	w1, #0x2                   	// #2
    32ac:	97fffda1 	bl	2930 <jbyte>
    32b0:	aa1303e0 	mov	x0, x19
    32b4:	52800001 	mov	w1, #0x0                   	// #0
    32b8:	97fffd9e 	bl	2930 <jbyte>
  jbyte(w, 3); jbyte(w, 0x00);
    32bc:	aa1303e0 	mov	x0, x19
    32c0:	52800061 	mov	w1, #0x3                   	// #3
    32c4:	97fffd9b 	bl	2930 <jbyte>
    32c8:	aa1303e0 	mov	x0, x19
    32cc:	52800001 	mov	w1, #0x0                   	// #0
    32d0:	97fffd98 	bl	2930 <jbyte>
  jbyte(w, 0); jbyte(w, 63); jbyte(w, 0);
    32d4:	aa1303e0 	mov	x0, x19
    32d8:	52800001 	mov	w1, #0x0                   	// #0
    32dc:	97fffd95 	bl	2930 <jbyte>
    32e0:	aa1303e0 	mov	x0, x19
    32e4:	528007e1 	mov	w1, #0x3f                  	// #63
    32e8:	97fffd92 	bl	2930 <jbyte>
    32ec:	aa1303e0 	mov	x0, x19
    32f0:	52800001 	mov	w1, #0x0                   	// #0
    32f4:	97fffd8f 	bl	2930 <jbyte>
    for(int mx = 0; mx < width; mx += 16){
    32f8:	910ac3f8 	add	x24, sp, #0x2b0
    32fc:	52800009 	mov	w9, #0x0                   	// #0
    3300:	140000a0 	b	3580 <jpeg_encode_to+0x684>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 4 ? 12 : 0);
    3304:	710012df 	cmp	w22, #0x4
    3308:	1a9813e1 	csel	w1, wzr, w24, ne	// ne = any
    330c:	17ffffae 	b	31c4 <jpeg_encode_to+0x2c8>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 8 ? 162 : 0);
    3310:	710022df 	cmp	w22, #0x8
    3314:	1a9813e1 	csel	w1, wzr, w24, ne	// ne = any
    3318:	17ffffbd 	b	320c <jpeg_encode_to+0x310>
          pixel(arg, sx, sy, &rgb[y][x][0], &rgb[y][x][1], &rgb[y][x][2]);
    331c:	f9403be0 	ldr	x0, [sp, #112]
          int sx = mx + x < width ? mx + x : width - 1;
    3320:	6b1400df 	cmp	w6, w20
          pixel(arg, sx, sy, &rgb[y][x][0], &rgb[y][x][1], &rgb[y][x][2]);
    3324:	b9007be6 	str	w6, [sp, #120]
    3328:	1a9cb0c1 	csel	w1, w6, w28, lt	// lt = tstop
    332c:	b90083e2 	str	w2, [sp, #128]
    3330:	91000865 	add	x5, x3, #0x2
    3334:	a9089fe3 	stp	x3, x7, [sp, #136]
    3338:	91000464 	add	x4, x3, #0x1
    333c:	291323e9 	stp	w9, w8, [sp, #152]
    3340:	d63f02e0 	blr	x23
        for(int x = 0; x < 16; x++){
    3344:	a9489fe3 	ldp	x3, x7, [sp, #136]
    3348:	b9407be6 	ldr	w6, [sp, #120]
    334c:	b94083e2 	ldr	w2, [sp, #128]
    3350:	110004c6 	add	w6, w6, #0x1
    3354:	295323e9 	ldp	w9, w8, [sp, #152]
    3358:	6b06035f 	cmp	w26, w6
    335c:	91000c63 	add	x3, x3, #0x3
    3360:	54fffde1 	b.ne	331c <jpeg_encode_to+0x420>  // b.any
      for(int y = 0; y < 16; y++)
    3364:	9100c0e7 	add	x7, x7, #0x30
    3368:	11000508 	add	w8, w8, #0x1
    336c:	f10c00ff 	cmp	x7, #0x300
    3370:	54000780 	b.eq	3460 <jpeg_encode_to+0x564>  // b.none
        for(int x = 0; x < 16; x++){
    3374:	6b15011f 	cmp	w8, w21
    3378:	8b1800e3 	add	x3, x7, x24
    337c:	1a9bb102 	csel	w2, w8, w27, lt	// lt = tstop
          int sy = my + y < height ? my + y : height - 1;
    3380:	2a0903e6 	mov	w6, w9
    3384:	17ffffe6 	b	331c <jpeg_encode_to+0x420>
              yblock[y * 8 + x] = ((77*p[0] + 150*p[1] + 29*p[2]) >> 8)-128;
    3388:	39400420 	ldrb	w0, [x1, #1]
            for(int x = 0; x < 8; x++){
    338c:	91000c21 	add	x1, x1, #0x3
              yblock[y * 8 + x] = ((77*p[0] + 150*p[1] + 29*p[2]) >> 8)-128;
    3390:	385fd02d 	ldurb	w13, [x1, #-3]
    3394:	1b077c00 	mul	w0, w0, w7
    3398:	1b0801ad 	madd	w13, w13, w8, w0
    339c:	385ff020 	ldurb	w0, [x1, #-1]
    33a0:	1b063400 	madd	w0, w0, w6, w13
    33a4:	13087c00 	asr	w0, w0, #8
    33a8:	51020000 	sub	w0, w0, #0x80
    33ac:	78237840 	strh	w0, [x2, x3, lsl #1]
            for(int x = 0; x < 8; x++){
    33b0:	91000463 	add	x3, x3, #0x1
    33b4:	f100207f 	cmp	x3, #0x8
    33b8:	54fffe81 	b.ne	3388 <jpeg_encode_to+0x48c>  // b.any
          for(int y = 0; y < 8; y++)
    33bc:	1100216b 	add	w11, w11, #0x8
    33c0:	9100c18c 	add	x12, x12, #0x30
    33c4:	91004042 	add	x2, x2, #0x10
    33c8:	7101017f 	cmp	w11, #0x40
    33cc:	54000080 	b.eq	33dc <jpeg_encode_to+0x4e0>  // b.none
            for(int x = 0; x < 8; x++){
    33d0:	8b0c01c1 	add	x1, x14, x12
          int sy = my + y < height ? my + y : height - 1;
    33d4:	d2800003 	mov	x3, #0x0                   	// #0
    33d8:	17ffffec 	b	3388 <jpeg_encode_to+0x48c>
          encode_block(w, yblock, qy, &pred_y);
    33dc:	910293e3 	add	x3, sp, #0xa4
    33e0:	aa1903e2 	mov	x2, x25
    33e4:	9104c3e1 	add	x1, sp, #0x130
    33e8:	aa1303e0 	mov	x0, x19
    33ec:	a90797e9 	stp	x9, x5, [sp, #120]
    33f0:	f90047e4 	str	x4, [sp, #136]
    33f4:	97fffdb9 	bl	2ad8 <encode_block>
        for(int bx = 0; bx < 2; bx++){
    33f8:	a94813e5 	ldp	x5, x4, [sp, #128]
    33fc:	5280300a 	mov	w10, #0x180                 	// #384
    3400:	f100609f 	cmp	x4, #0x18
    3404:	54000160 	b.eq	3430 <jpeg_encode_to+0x534>  // b.none
    3408:	f9403fe9 	ldr	x9, [sp, #120]
    340c:	d2800304 	mov	x4, #0x18                  	// #24
    3410:	528003a6 	mov	w6, #0x1d                  	// #29
    3414:	528012c7 	mov	w7, #0x96                  	// #150
    3418:	528009a8 	mov	w8, #0x4d                  	// #77
          for(int y = 0; y < 8; y++)
    341c:	9104c3e2 	add	x2, sp, #0x130
          int sy = my + y < height ? my + y : height - 1;
    3420:	aa0903ec 	mov	x12, x9
    3424:	8b04030e 	add	x14, x24, x4
    3428:	5280000b 	mov	w11, #0x0                   	// #0
    342c:	17ffffe9 	b	33d0 <jpeg_encode_to+0x4d4>
      for(int by = 0; by < 2; by++)
    3430:	b4000285 	cbz	x5, 3480 <jpeg_encode_to+0x584>
    3434:	9106c3e6 	add	x6, sp, #0x1b0
    3438:	9108c3e5 	add	x5, sp, #0x230
    343c:	d2800008 	mov	x8, #0x0                   	// #0
    3440:	52800009 	mov	w9, #0x0                   	// #0
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    3444:	1280054a 	mov	w10, #0xffffffd5            	// #-43
    3448:	12800a8b 	mov	w11, #0xffffffab            	// #-85
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    344c:	12800d4c 	mov	w12, #0xffffff95            	// #-107
    3450:	1280028d 	mov	w13, #0xffffffeb            	// #-21
        for(int x = 0; x < 8; x++){
    3454:	8b080307 	add	x7, x24, x8
          int sr = 0, sg = 0, sb = 0;
    3458:	d2800001 	mov	x1, #0x0                   	// #0
    345c:	1400002e 	b	3514 <jpeg_encode_to+0x618>
      for(int y = 0; y < 16; y++)
    3460:	d2800005 	mov	x5, #0x0                   	// #0
    3464:	5280300a 	mov	w10, #0x180                 	// #384
        for(int bx = 0; bx < 2; bx++){
    3468:	9baa7ca9 	umull	x9, w5, w10
    346c:	d2800004 	mov	x4, #0x0                   	// #0
              yblock[y * 8 + x] = ((77*p[0] + 150*p[1] + 29*p[2]) >> 8)-128;
    3470:	528009a8 	mov	w8, #0x4d                  	// #77
    3474:	528012c7 	mov	w7, #0x96                  	// #150
    3478:	528003a6 	mov	w6, #0x1d                  	// #29
    347c:	17ffffe8 	b	341c <jpeg_encode_to+0x520>
      for(int by = 0; by < 2; by++)
    3480:	d2800025 	mov	x5, #0x1                   	// #1
    3484:	17fffff9 	b	3468 <jpeg_encode_to+0x56c>
          for(int dy = 0; dy < 2; dy++)
    3488:	52800024 	mov	w4, #0x1                   	// #1
              sr += p[0]; sg += p[1]; sb += p[2];
    348c:	394001cf 	ldrb	w15, [x14]
          for(int dy = 0; dy < 2; dy++)
    3490:	9100c1ce 	add	x14, x14, #0x30
              sr += p[0]; sg += p[1]; sb += p[2];
    3494:	385d11d0 	ldurb	w16, [x14, #-47]
    3498:	0b0301e3 	add	w3, w15, w3
    349c:	385d21cf 	ldurb	w15, [x14, #-46]
    34a0:	0b020210 	add	w16, w16, w2
    34a4:	385d41c2 	ldurb	w2, [x14, #-44]
    34a8:	0b0001ef 	add	w15, w15, w0
    34ac:	385d31c0 	ldurb	w0, [x14, #-45]
    34b0:	0b100042 	add	w2, w2, w16
    34b4:	0b030003 	add	w3, w0, w3
    34b8:	385d51c0 	ldurb	w0, [x14, #-43]
    34bc:	0b0f0000 	add	w0, w0, w15
          for(int dy = 0; dy < 2; dy++)
    34c0:	34fffe44 	cbz	w4, 3488 <jpeg_encode_to+0x58c>
          int r = (sr + 2) >> 2, g = (sg + 2) >> 2, b = (sb + 2) >> 2;
    34c4:	11000842 	add	w2, w2, #0x2
    34c8:	11000863 	add	w3, w3, #0x2
    34cc:	11000800 	add	w0, w0, #0x2
        for(int x = 0; x < 8; x++){
    34d0:	910018e7 	add	x7, x7, #0x6
          int r = (sr + 2) >> 2, g = (sg + 2) >> 2, b = (sb + 2) >> 2;
    34d4:	13027c42 	asr	w2, w2, #2
    34d8:	13027c63 	asr	w3, w3, #2
    34dc:	13027c00 	asr	w0, w0, #2
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    34e0:	1b0b7c4e 	mul	w14, w2, w11
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    34e4:	1b0c7c42 	mul	w2, w2, w12
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    34e8:	1b0a386e 	madd	w14, w3, w10, w14
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    34ec:	0b031c43 	add	w3, w2, w3, lsl #7
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    34f0:	0b001dce 	add	w14, w14, w0, lsl #7
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    34f4:	1b0d0c00 	madd	w0, w0, w13, w3
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    34f8:	13087dce 	asr	w14, w14, #8
    34fc:	782168ce 	strh	w14, [x6, x1]
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    3500:	13087c00 	asr	w0, w0, #8
    3504:	782168a0 	strh	w0, [x5, x1]
        for(int x = 0; x < 8; x++){
    3508:	91000821 	add	x1, x1, #0x2
    350c:	f100403f 	cmp	x1, #0x10
    3510:	540000e0 	b.eq	352c <jpeg_encode_to+0x630>  // b.none
          for(int dy = 0; dy < 2; dy++)
    3514:	aa0703ee 	mov	x14, x7
    3518:	52800004 	mov	w4, #0x0                   	// #0
          int sr = 0, sg = 0, sb = 0;
    351c:	52800000 	mov	w0, #0x0                   	// #0
    3520:	52800002 	mov	w2, #0x0                   	// #0
    3524:	52800003 	mov	w3, #0x0                   	// #0
    3528:	17ffffd9 	b	348c <jpeg_encode_to+0x590>
      for(int y = 0; y < 8; y++)
    352c:	11000929 	add	w9, w9, #0x2
    3530:	910040c6 	add	x6, x6, #0x10
    3534:	910040a5 	add	x5, x5, #0x10
    3538:	91018108 	add	x8, x8, #0x60
    353c:	7100413f 	cmp	w9, #0x10
    3540:	54fff8a1 	b.ne	3454 <jpeg_encode_to+0x558>  // b.any
      encode_block(w, cb, qc, &pred_cb);
    3544:	9102a3e3 	add	x3, sp, #0xa8
    3548:	9103c3e2 	add	x2, sp, #0xf0
    354c:	9106c3e1 	add	x1, sp, #0x1b0
    3550:	aa1303e0 	mov	x0, x19
    3554:	b9007be4 	str	w4, [sp, #120]
    3558:	97fffd60 	bl	2ad8 <encode_block>
      encode_block(w, cr, qc, &pred_cr);
    355c:	9102b3e3 	add	x3, sp, #0xac
    3560:	9103c3e2 	add	x2, sp, #0xf0
    3564:	9108c3e1 	add	x1, sp, #0x230
    3568:	aa1303e0 	mov	x0, x19
    356c:	97fffd5b 	bl	2ad8 <encode_block>
    for(int mx = 0; mx < width; mx += 16){
    3570:	b9407be4 	ldr	w4, [sp, #120]
    3574:	2a1a03e9 	mov	w9, w26
    3578:	6b1a029f 	cmp	w20, w26
    357c:	540000ad 	b.le	3590 <jpeg_encode_to+0x694>
      for(int y = 0; y < 16; y++)
    3580:	2a1603e8 	mov	w8, w22
        for(int x = 0; x < 16; x++){
    3584:	1100413a 	add	w26, w9, #0x10
          int sy = my + y < height ? my + y : height - 1;
    3588:	d2800007 	mov	x7, #0x0                   	// #0
    358c:	17ffff7a 	b	3374 <jpeg_encode_to+0x478>
  for(int my = 0; my < height; my += 16){
    3590:	110042d6 	add	w22, w22, #0x10
    3594:	6b1602bf 	cmp	w21, w22
    3598:	54ffeb0c 	b.gt	32f8 <jpeg_encode_to+0x3fc>
  if(w->nbits)
    359c:	b9502660 	ldr	w0, [x19, #4132]
    35a0:	340000e0 	cbz	w0, 35bc <jpeg_encode_to+0x6c0>
    put_bits(w, (1U << (8 - w->nbits)) - 1, 8 - w->nbits);
    35a4:	52800102 	mov	w2, #0x8                   	// #8
    35a8:	4b000042 	sub	w2, w2, w0
    35ac:	aa1303e0 	mov	x0, x19
    35b0:	1ac22081 	lsl	w1, w4, w2
    35b4:	51000421 	sub	w1, w1, #0x1
    35b8:	97fffd19 	bl	2a1c <put_bits>
  jmarker(w, 0xd9);                // EOI
    35bc:	52801b21 	mov	w1, #0xd9                  	// #217
    35c0:	aa1303e0 	mov	x0, x19
    35c4:	97fffd0a 	bl	29ec <jmarker>
  if(jflush(w) < 0 || w->error)
    35c8:	aa1303e0 	mov	x0, x19
    35cc:	97fffcb5 	bl	28a0 <jflush>
    35d0:	3100041f 	cmn	w0, #0x1
    35d4:	54ffcc00 	b.eq	2f54 <jpeg_encode_to+0x58>  // b.none
    35d8:	b9401660 	ldr	w0, [x19, #20]
    35dc:	35ffcba0 	cbnz	w0, 2f50 <jpeg_encode_to+0x54>
  if(written)
    35e0:	f94037e1 	ldr	x1, [sp, #104]
    35e4:	b4ffcb81 	cbz	x1, 2f54 <jpeg_encode_to+0x58>
    *written = w->total;
    35e8:	f94037e2 	ldr	x2, [sp, #104]
    35ec:	b9401a61 	ldr	w1, [x19, #24]
    35f0:	b9000041 	str	w1, [x2]
    35f4:	17fffe58 	b	2f54 <jpeg_encode_to+0x58>

00000000000035f8 <jpeg_encode>:
int
jpeg_encode(int fd, int width, int height, int quality,
            jpeg_pixel_fn pixel, void *arg, uint *written)
{
  struct jw w;
  if(fd < 0)
    35f8:	37f803e0 	tbnz	w0, #31, 3674 <jpeg_encode+0x7c>
{
    35fc:	d282100c 	mov	x12, #0x1080                	// #4224
    3600:	cb2c63ff 	sub	sp, sp, x12
    3604:	a9007bfd 	stp	x29, x30, [sp]
    3608:	910003fd 	mov	x29, sp
    360c:	a90153f3 	stp	x19, x20, [sp, #16]
    3610:	2a0003f3 	mov	w19, w0
    3614:	2a0103f4 	mov	w20, w1
    return -1;
  memset(&w, 0, sizeof(w));
    3618:	910163e0 	add	x0, sp, #0x58
    361c:	52800001 	mov	w1, #0x0                   	// #0
{
    3620:	a9025bf5 	stp	x21, x22, [sp, #32]
    3624:	2a0303f6 	mov	w22, w3
    3628:	2a0203f5 	mov	w21, w2
  memset(&w, 0, sizeof(w));
    362c:	52820502 	mov	w2, #0x1028                	// #4136
    3630:	a90397e4 	stp	x4, x5, [sp, #56]
    3634:	f90027e6 	str	x6, [sp, #72]
    3638:	97fff4dc 	bl	9a8 <memset@plt>
  w.fd = fd;
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    363c:	a94397e4 	ldp	x4, x5, [sp, #56]
    3640:	2a1603e3 	mov	w3, w22
    3644:	f94027e6 	ldr	x6, [sp, #72]
    3648:	2a1503e2 	mov	w2, w21
    364c:	2a1403e1 	mov	w1, w20
    3650:	910163e0 	add	x0, sp, #0x58
  w.fd = fd;
    3654:	b9005bf3 	str	w19, [sp, #88]
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    3658:	97fffe29 	bl	2efc <jpeg_encode_to>
}
    365c:	a9407bfd 	ldp	x29, x30, [sp]
    3660:	d282100c 	mov	x12, #0x1080                	// #4224
    3664:	a94153f3 	ldp	x19, x20, [sp, #16]
    3668:	a9425bf5 	ldp	x21, x22, [sp, #32]
    366c:	8b2c63ff 	add	sp, sp, x12
    3670:	d65f03c0 	ret
    return -1;
    3674:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    3678:	d65f03c0 	ret

000000000000367c <jpeg_encode_mem>:
int
jpeg_encode_mem(uchar *dst, int cap, int width, int height, int quality,
                jpeg_pixel_fn pixel, void *arg, uint *written)
{
  struct jw w;
  if(dst == 0 || cap <= 0)
    367c:	f100001f 	cmp	x0, #0x0
    3680:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    3684:	540004ed 	b.le	3720 <jpeg_encode_mem+0xa4>
{
    3688:	d282100c 	mov	x12, #0x1080                	// #4224
    368c:	cb2c63ff 	sub	sp, sp, x12
    3690:	a9007bfd 	stp	x29, x30, [sp]
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	2a0103f3 	mov	w19, w1
    return -1;
  memset(&w, 0, sizeof(w));
    36a4:	910163e0 	add	x0, sp, #0x58
    36a8:	52800001 	mov	w1, #0x0                   	// #0
{
    36ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    36b0:	2a0303f6 	mov	w22, w3
    36b4:	2a0203f5 	mov	w21, w2
  memset(&w, 0, sizeof(w));
    36b8:	52820502 	mov	w2, #0x1028                	// #4136
{
    36bc:	a90363f7 	stp	x23, x24, [sp, #48]
    36c0:	aa0703f8 	mov	x24, x7
    36c4:	aa0603f7 	mov	x23, x6
    36c8:	b90047e4 	str	w4, [sp, #68]
    36cc:	f90027e5 	str	x5, [sp, #72]
  memset(&w, 0, sizeof(w));
    36d0:	97fff4b6 	bl	9a8 <memset@plt>
  w.fd = -1;
  w.mem = dst;
  w.cap = cap;
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    36d4:	f94027e4 	ldr	x4, [sp, #72]
  w.fd = -1;
    36d8:	12800000 	mov	w0, #0xffffffff            	// #-1
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    36dc:	b94047e3 	ldr	w3, [sp, #68]
    36e0:	aa1803e6 	mov	x6, x24
    36e4:	aa1703e5 	mov	x5, x23
    36e8:	2a1603e2 	mov	w2, w22
    36ec:	2a1503e1 	mov	w1, w21
  w.fd = -1;
    36f0:	b9005be0 	str	w0, [sp, #88]
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    36f4:	910163e0 	add	x0, sp, #0x58
  w.mem = dst;
    36f8:	f90033f4 	str	x20, [sp, #96]
  w.cap = cap;
    36fc:	b9006bf3 	str	w19, [sp, #104]
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    3700:	97fffdff 	bl	2efc <jpeg_encode_to>
}
    3704:	a9407bfd 	ldp	x29, x30, [sp]
    3708:	d282100c 	mov	x12, #0x1080                	// #4224
    370c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3710:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3714:	a94363f7 	ldp	x23, x24, [sp, #48]
    3718:	8b2c63ff 	add	sp, sp, x12
    371c:	d65f03c0 	ret
    return -1;
    3720:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    3724:	d65f03c0 	ret
