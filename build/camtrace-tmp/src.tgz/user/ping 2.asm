
user/_ping:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000004d0 <.plt>:
 4d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 4d4:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 4d8:	f9461611 	ldr	x17, [x16, #3112]
 4dc:	9130a210 	add	x16, x16, #0xc28
 4e0:	d61f0220 	br	x17
 4e4:	d503201f 	nop
 4e8:	d503201f 	nop
 4ec:	d503201f 	nop

00000000000004f0 <printf@plt>:
 4f0:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 4f4:	f9461a11 	ldr	x17, [x16, #3120]
 4f8:	9130c210 	add	x16, x16, #0xc30
 4fc:	d61f0220 	br	x17

0000000000000500 <getpid@plt>:
 500:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 504:	f9461e11 	ldr	x17, [x16, #3128]
 508:	9130e210 	add	x16, x16, #0xc38
 50c:	d61f0220 	br	x17

0000000000000510 <fprintf@plt>:
 510:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 514:	f9462211 	ldr	x17, [x16, #3136]
 518:	91310210 	add	x16, x16, #0xc40
 51c:	d61f0220 	br	x17

0000000000000520 <sleep_ticks@plt>:
 520:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 524:	f9462611 	ldr	x17, [x16, #3144]
 528:	91312210 	add	x16, x16, #0xc48
 52c:	d61f0220 	br	x17

0000000000000530 <udp_recv@plt>:
 530:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 534:	f9462a11 	ldr	x17, [x16, #3152]
 538:	91314210 	add	x16, x16, #0xc50
 53c:	d61f0220 	br	x17

0000000000000540 <uptime@plt>:
 540:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 544:	f9462e11 	ldr	x17, [x16, #3160]
 548:	91316210 	add	x16, x16, #0xc58
 54c:	d61f0220 	br	x17

0000000000000550 <memset@plt>:
 550:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 554:	f9463211 	ldr	x17, [x16, #3168]
 558:	91318210 	add	x16, x16, #0xc60
 55c:	d61f0220 	br	x17

0000000000000560 <udp_bind@plt>:
 560:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 564:	f9463611 	ldr	x17, [x16, #3176]
 568:	9131a210 	add	x16, x16, #0xc68
 56c:	d61f0220 	br	x17

0000000000000570 <udp_send@plt>:
 570:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 574:	f9463a11 	ldr	x17, [x16, #3184]
 578:	9131c210 	add	x16, x16, #0xc70
 57c:	d61f0220 	br	x17

0000000000000580 <udp_unbind@plt>:
 580:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 584:	f9463e11 	ldr	x17, [x16, #3192]
 588:	9131e210 	add	x16, x16, #0xc78
 58c:	d61f0220 	br	x17

0000000000000590 <icmp_send@plt>:
 590:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 594:	f9464211 	ldr	x17, [x16, #3200]
 598:	91320210 	add	x16, x16, #0xc80
 59c:	d61f0220 	br	x17

00000000000005a0 <exit@plt>:
 5a0:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 5a4:	f9464611 	ldr	x17, [x16, #3208]
 5a8:	91322210 	add	x16, x16, #0xc88
 5ac:	d61f0220 	br	x17

00000000000005b0 <icmp_recv@plt>:
 5b0:	b0000010 	adrp	x16, 1000 <print_ip+0x5c8>
 5b4:	f9464a11 	ldr	x17, [x16, #3216]
 5b8:	91324210 	add	x16, x16, #0xc90
 5bc:	d61f0220 	br	x17

Disassembly of section .text:

00000000000005c0 <main>:
         (ip >> 8) & 255, ip & 255);
}

int
main(int argc, char **argv)
{
 5c0:	d10dc3ff 	sub	sp, sp, #0x370
 5c4:	a9007bfd 	stp	x29, x30, [sp]
 5c8:	910003fd 	mov	x29, sp
 5cc:	a90153f3 	stp	x19, x20, [sp, #16]
 5d0:	a9025bf5 	stp	x21, x22, [sp, #32]
 5d4:	a90363f7 	stp	x23, x24, [sp, #48]
 5d8:	a9046bf9 	stp	x25, x26, [sp, #64]
 5dc:	f9002bfb 	str	x27, [sp, #80]
  uchar tx[32], rx[64];
  uint32 dst, src;
  uint16 rseq;
  int id, seq, n, before, after;

  if(argc != 2){
 5e0:	7100081f 	cmp	w0, #0x2
 5e4:	540000c0 	b.eq	5fc <main+0x3c>  // b.none
    fprintf(2, "usage: ping host\n");
 5e8:	90000001 	adrp	x1, 0 <.plt-0x4d0>
 5ec:	91299021 	add	x1, x1, #0xa64
    for(n = 0; n < (int)sizeof(tx); n++)
      tx[n] = n + seq;
    before = uptime();
    if(icmp_send(dst, id, seq, tx, sizeof(tx)) < 0 ||
       (n = icmp_recv(id, &src, &rseq, rx, sizeof(rx))) < 0){
      fprintf(2, "ping: send/receive failed\n");
 5f0:	52800040 	mov	w0, #0x2                   	// #2
 5f4:	97ffffc7 	bl	510 <fprintf@plt>
      exit(1);
 5f8:	14000064 	b	788 <main+0x1c8>
  if(parse_ip(argv[1], &dst) < 0 && resolve(argv[1], &dst) < 0){
 5fc:	f9400436 	ldr	x22, [x1, #8]
 600:	aa0103f5 	mov	x21, x1
  int part = 0, dots = 0, digit = 0;
 604:	52800004 	mov	w4, #0x0                   	// #0
 608:	52800002 	mov	w2, #0x0                   	// #0
  if(parse_ip(argv[1], &dst) < 0 && resolve(argv[1], &dst) < 0){
 60c:	aa1603e3 	mov	x3, x22
  int part = 0, dots = 0, digit = 0;
 610:	52800000 	mov	w0, #0x0                   	// #0
  uint32 v = 0;
 614:	52800013 	mov	w19, #0x0                   	// #0
      part = part * 10 + *s - '0';
 618:	52800146 	mov	w6, #0xa                   	// #10
    if(*s >= '0' && *s <= '9'){
 61c:	39400061 	ldrb	w1, [x3]
 620:	5100c025 	sub	w5, w1, #0x30
 624:	12001ca5 	and	w5, w5, #0xff
 628:	710024bf 	cmp	w5, #0x9
 62c:	54000108 	b.hi	64c <main+0x8c>  // b.pmore
      part = part * 10 + *s - '0';
 630:	1b060400 	madd	w0, w0, w6, w1
 634:	5100c000 	sub	w0, w0, #0x30
      if(part > 255)
 638:	7103fc1f 	cmp	w0, #0xff
 63c:	5400020c 	b.gt	67c <main+0xbc>
      digit = 1;
 640:	52800024 	mov	w4, #0x1                   	// #1
  for(;; s++){
 644:	91000463 	add	x3, x3, #0x1
    if(*s >= '0' && *s <= '9'){
 648:	17fffff5 	b	61c <main+0x5c>
    } else if(*s == '.' || *s == 0){
 64c:	7100b83f 	cmp	w1, #0x2e
 650:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
 654:	54000141 	b.ne	67c <main+0xbc>  // b.any
      if(!digit)
 658:	34000124 	cbz	w4, 67c <main+0xbc>
      v = (v << 8) | part;
 65c:	2a132013 	orr	w19, w0, w19, lsl #8
      if(*s == 0)
 660:	340000a1 	cbz	w1, 674 <main+0xb4>
      dots++;
 664:	11000442 	add	w2, w2, #0x1
      part = digit = 0;
 668:	52800004 	mov	w4, #0x0                   	// #0
 66c:	52800000 	mov	w0, #0x0                   	// #0
 670:	17fffff5 	b	644 <main+0x84>
  if(dots != 3)
 674:	71000c5f 	cmp	w2, #0x3
 678:	540012e0 	b.eq	8d4 <main+0x314>  // b.none
  memset(query, 0, sizeof(query));
 67c:	9101c3f3 	add	x19, sp, #0x70
 680:	52802002 	mov	w2, #0x100                 	// #256
 684:	aa1303e0 	mov	x0, x19
 688:	52800001 	mov	w1, #0x0                   	// #0
 68c:	97ffffb1 	bl	550 <memset@plt>
  int q = 12, start, n, off, answers, rdlen;
 690:	52800194 	mov	w20, #0xc                   	// #12
  query[0] = 0x51;
 694:	528e2a20 	mov	w0, #0x7151                	// #29009
 698:	7900e3e0 	strh	w0, [sp, #112]
  query[2] = 0x01;
 69c:	52800020 	mov	w0, #0x1                   	// #1
 6a0:	3901cbe0 	strb	w0, [sp, #114]
  query[5] = 0x01;
 6a4:	3901d7e0 	strb	w0, [sp, #117]
  while(*p){
 6a8:	394002c0 	ldrb	w0, [x22]
    start = q++;
 6ac:	11000682 	add	w2, w20, #0x1
 6b0:	93407e84 	sxtw	x4, w20
 6b4:	93407c41 	sxtw	x1, w2
  while(*p){
 6b8:	34000300 	cbz	w0, 718 <main+0x158>
 6bc:	52800000 	mov	w0, #0x0                   	// #0
 6c0:	1400000c 	b	6f0 <main+0x130>
      if(q >= (int)sizeof(query) - 5 || query[start] == 63)
 6c4:	7103e85f 	cmp	w2, #0xfa
 6c8:	5400056c 	b.gt	774 <main+0x1b4>
 6cc:	7100fc1f 	cmp	w0, #0x3f
 6d0:	54000520 	b.eq	774 <main+0x1b4>  // b.none
      query[q++] = *p++;
 6d4:	38216a63 	strb	w3, [x19, x1]
 6d8:	910006d6 	add	x22, x22, #0x1
 6dc:	11000442 	add	w2, w2, #0x1
      query[start]++;
 6e0:	91000421 	add	x1, x1, #0x1
 6e4:	38646a60 	ldrb	w0, [x19, x4]
 6e8:	11000400 	add	w0, w0, #0x1
 6ec:	12001c00 	and	w0, w0, #0xff
    query[start] = 0;
 6f0:	38246a60 	strb	w0, [x19, x4]
    while(*p && *p != '.'){
 6f4:	394002c3 	ldrb	w3, [x22]
 6f8:	7100b87f 	cmp	w3, #0x2e
 6fc:	7a401864 	ccmp	w3, #0x0, #0x4, ne	// ne = any
 700:	54fffe21 	b.ne	6c4 <main+0x104>  // b.any
      p++;
 704:	7100b87f 	cmp	w3, #0x2e
 708:	9a9616d6 	cinc	x22, x22, eq	// eq = none
    if(query[start] == 0)
 70c:	34000340 	cbz	w0, 774 <main+0x1b4>
 710:	2a0203f4 	mov	w20, w2
 714:	17ffffe5 	b	6a8 <main+0xe8>
  query[q++] = 0;
 718:	11000a80 	add	w0, w20, #0x2
  query[q++] = 0;
 71c:	38246a7f 	strb	wzr, [x19, x4]
  query[q++] = 0;
 720:	38216a7f 	strb	wzr, [x19, x1]
  query[q++] = 1; // A
 724:	52800021 	mov	w1, #0x1                   	// #1
 728:	3820ca61 	strb	w1, [x19, w0, sxtw]
 72c:	11000e80 	add	w0, w20, #0x3
  query[q++] = 0;
 730:	3820ca7f 	strb	wzr, [x19, w0, sxtw]
 734:	11001280 	add	w0, w20, #0x4
  query[q++] = 1; // IN
 738:	3820ca61 	strb	w1, [x19, w0, sxtw]
  if(udp_bind(DNS_PORT) < 0)
 73c:	5299e120 	mov	w0, #0xcf09                	// #53001
 740:	97ffff88 	bl	560 <udp_bind@plt>
 744:	37f80180 	tbnz	w0, #31, 774 <main+0x1b4>
  if(udp_send(QEMU_DNS, DNS_PORT, 53, query, q) < 0){
 748:	52804076 	mov	w22, #0x203                 	// #515
 74c:	72a14016 	movk	w22, #0xa00, lsl #16
 750:	11001684 	add	w4, w20, #0x5
 754:	aa1303e3 	mov	x3, x19
 758:	2a1603e0 	mov	w0, w22
 75c:	528006a2 	mov	w2, #0x35                  	// #53
 760:	5299e121 	mov	w1, #0xcf09                	// #53001
 764:	97ffff83 	bl	570 <udp_send@plt>
 768:	36f80140 	tbz	w0, #31, 790 <main+0x1d0>
    udp_unbind(DNS_PORT);
 76c:	5299e120 	mov	w0, #0xcf09                	// #53001
 770:	97ffff84 	bl	580 <udp_unbind@plt>
    fprintf(2, "ping: cannot resolve %s\n", argv[1]);
 774:	f94006a2 	ldr	x2, [x21, #8]
 778:	90000001 	adrp	x1, 0 <.plt-0x4d0>
 77c:	9129d821 	add	x1, x1, #0xa76
 780:	52800040 	mov	w0, #0x2                   	// #2
 784:	97ffff63 	bl	510 <fprintf@plt>
    exit(1);
 788:	52800020 	mov	w0, #0x1                   	// #1
 78c:	97ffff85 	bl	5a0 <exit@plt>
  sleep_ticks(5);
 790:	528000a0 	mov	w0, #0x5                   	// #5
 794:	97ffff63 	bl	520 <sleep_ticks@plt>
  if(udp_send(QEMU_DNS, DNS_PORT, 53, query, q) < 0){
 798:	11001684 	add	w4, w20, #0x5
 79c:	aa1303e3 	mov	x3, x19
 7a0:	2a1603e0 	mov	w0, w22
 7a4:	528006a2 	mov	w2, #0x35                  	// #53
 7a8:	5299e121 	mov	w1, #0xcf09                	// #53001
 7ac:	97ffff71 	bl	570 <udp_send@plt>
 7b0:	37fffde0 	tbnz	w0, #31, 76c <main+0x1ac>
  n = udp_recv(DNS_PORT, &src, &sport, reply, sizeof(reply));
 7b4:	9105c3f3 	add	x19, sp, #0x170
 7b8:	9101abe2 	add	x2, sp, #0x6a
 7bc:	aa1303e3 	mov	x3, x19
 7c0:	9101b3e1 	add	x1, sp, #0x6c
 7c4:	52804004 	mov	w4, #0x200                 	// #512
 7c8:	5299e120 	mov	w0, #0xcf09                	// #53001
 7cc:	97ffff59 	bl	530 <udp_recv@plt>
 7d0:	2a0003f4 	mov	w20, w0
  udp_unbind(DNS_PORT);
 7d4:	5299e120 	mov	w0, #0xcf09                	// #53001
 7d8:	97ffff6a 	bl	580 <udp_unbind@plt>
  if(n < 12 || src != QEMU_DNS || sport != 53 ||
 7dc:	71002e9f 	cmp	w20, #0xb
 7e0:	54fffcad 	b.le	774 <main+0x1b4>
 7e4:	b9406fe0 	ldr	w0, [sp, #108]
 7e8:	6b16001f 	cmp	w0, w22
 7ec:	54fffc41 	b.ne	774 <main+0x1b4>  // b.any
 7f0:	7940d7e0 	ldrh	w0, [sp, #106]
 7f4:	7100d41f 	cmp	w0, #0x35
 7f8:	54fffbe1 	b.ne	774 <main+0x1b4>  // b.any
 7fc:	3945c3e0 	ldrb	w0, [sp, #368]
 800:	7101441f 	cmp	w0, #0x51
 804:	54fffb81 	b.ne	774 <main+0x1b4>  // b.any
     reply[0] != 0x51 || reply[1] != 0x71 || (reply[3] & 15) != 0)
 808:	3945c7e0 	ldrb	w0, [sp, #369]
 80c:	7101c41f 	cmp	w0, #0x71
 810:	54fffb21 	b.ne	774 <main+0x1b4>  // b.any
 814:	3945cfe0 	ldrb	w0, [sp, #371]
 818:	f2400c1f 	tst	x0, #0xf
 81c:	54fffac1 	b.ne	774 <main+0x1b4>  // b.any
  off = skip_name(reply, n, 12);
 820:	2a1403e1 	mov	w1, w20
 824:	aa1303e0 	mov	x0, x19
 828:	52800182 	mov	w2, #0xc                   	// #12
 82c:	9400006e 	bl	9e4 <skip_name>
  if(off < 0 || off + 4 > n)
 830:	37fffa20 	tbnz	w0, #31, 774 <main+0x1b4>
 834:	11000c01 	add	w1, w0, #0x3
 838:	6b01029f 	cmp	w20, w1
 83c:	54fff9cd 	b.le	774 <main+0x1b4>
 840:	7942efe6 	ldrh	w6, [sp, #374]
  off += 4;
 844:	11001002 	add	w2, w0, #0x4
 848:	5ac004c6 	rev16	w6, w6
 84c:	12003cc6 	and	w6, w6, #0xffff
  while(answers-- > 0){
 850:	34fff926 	cbz	w6, 774 <main+0x1b4>
    off = skip_name(reply, n, off);
 854:	2a1403e1 	mov	w1, w20
 858:	aa1303e0 	mov	x0, x19
 85c:	94000062 	bl	9e4 <skip_name>
    if(off < 0 || off + 10 > n)
 860:	37fff8a0 	tbnz	w0, #31, 774 <main+0x1b4>
 864:	11002401 	add	w1, w0, #0x9
 868:	6b01029f 	cmp	w20, w1
 86c:	54fff84d 	b.le	774 <main+0x1b4>
    rdlen = ((int)reply[off + 8] << 8) | reply[off + 9];
 870:	11002002 	add	w2, w0, #0x8
 874:	38614a61 	ldrb	w1, [x19, w1, uxtw]
 878:	38626a64 	ldrb	w4, [x19, x2]
 87c:	2a042024 	orr	w4, w1, w4, lsl #8
    if(off + 10 + rdlen > n)
 880:	11002801 	add	w1, w0, #0xa
 884:	0b010082 	add	w2, w4, w1
 888:	6b02029f 	cmp	w20, w2
 88c:	54fff74b 	b.lt	774 <main+0x1b4>  // b.tstop
    if(reply[off] == 0 && reply[off + 1] == 1 &&
 890:	38604a62 	ldrb	w2, [x19, w0, uxtw]
 894:	35000782 	cbnz	w2, 984 <main+0x3c4>
 898:	11000402 	add	w2, w0, #0x1
 89c:	38626a62 	ldrb	w2, [x19, x2]
 8a0:	7100045f 	cmp	w2, #0x1
 8a4:	54000701 	b.ne	984 <main+0x3c4>  // b.any
       reply[off + 2] == 0 && reply[off + 3] == 1 && rdlen == 4){
 8a8:	11000802 	add	w2, w0, #0x2
    if(reply[off] == 0 && reply[off + 1] == 1 &&
 8ac:	38626a62 	ldrb	w2, [x19, x2]
 8b0:	350006a2 	cbnz	w2, 984 <main+0x3c4>
       reply[off + 2] == 0 && reply[off + 3] == 1 && rdlen == 4){
 8b4:	11000c02 	add	w2, w0, #0x3
 8b8:	38626a62 	ldrb	w2, [x19, x2]
 8bc:	7100045f 	cmp	w2, #0x1
 8c0:	54000621 	b.ne	984 <main+0x3c4>  // b.any
 8c4:	7100109f 	cmp	w4, #0x4
 8c8:	540005e1 	b.ne	984 <main+0x3c4>  // b.any
      *ip = ((uint32)a[0] << 24) | ((uint32)a[1] << 16) |
 8cc:	b8614a73 	ldr	w19, [x19, w1, uxtw]
 8d0:	5ac00a73 	rev	w19, w19
  printf("PING %s (", argv[1]);
 8d4:	f94006a1 	ldr	x1, [x21, #8]
 8d8:	90000000 	adrp	x0, 0 <.plt-0x4d0>
 8dc:	912a3c00 	add	x0, x0, #0xa8f
    }
    after = uptime();
    printf("%d bytes from ", n);
 8e0:	90000017 	adrp	x23, 0 <.plt-0x4d0>
 8e4:	912b1af7 	add	x23, x23, #0xac6
    print_ip(src);
    printf(": icmp_seq=%d time=%d ms\n", rseq, (after - before) * 100);
 8e8:	90000018 	adrp	x24, 0 <.plt-0x4d0>
 8ec:	912b5718 	add	x24, x24, #0xad5
  printf("PING %s (", argv[1]);
 8f0:	97ffff00 	bl	4f0 <printf@plt>
  print_ip(dst);
 8f4:	2a1303e0 	mov	w0, w19
 8f8:	94000050 	bl	a38 <print_ip>
  printf("): %d data bytes\n", (int)sizeof(tx));
 8fc:	52800401 	mov	w1, #0x20                  	// #32
 900:	90000000 	adrp	x0, 0 <.plt-0x4d0>
 904:	912a6400 	add	x0, x0, #0xa99
 908:	97fffefa 	bl	4f0 <printf@plt>
  id = getpid() & 0xffff;
 90c:	97fffefd 	bl	500 <getpid@plt>
      tx[n] = n + seq;
 910:	9101c3f9 	add	x25, sp, #0x70
  id = getpid() & 0xffff;
 914:	12003c16 	and	w22, w0, #0xffff
  for(seq = 1; seq <= 4; seq++){
 918:	52800035 	mov	w21, #0x1                   	// #1
    if(query[start] == 0)
 91c:	d2800014 	mov	x20, #0x0                   	// #0
      tx[n] = n + seq;
 920:	0b1402a0 	add	w0, w21, w20
 924:	38396a80 	strb	w0, [x20, x25]
    for(n = 0; n < (int)sizeof(tx); n++)
 928:	91000694 	add	x20, x20, #0x1
 92c:	f100829f 	cmp	x20, #0x20
 930:	54ffff81 	b.ne	920 <main+0x360>  // b.any
    before = uptime();
 934:	97ffff03 	bl	540 <uptime@plt>
 938:	2a0003fb 	mov	w27, w0
    if(icmp_send(dst, id, seq, tx, sizeof(tx)) < 0 ||
 93c:	2a1403e4 	mov	w4, w20
 940:	aa1903e3 	mov	x3, x25
 944:	2a1503e2 	mov	w2, w21
 948:	2a1603e1 	mov	w1, w22
 94c:	2a1303e0 	mov	w0, w19
 950:	97ffff10 	bl	590 <icmp_send@plt>
 954:	37f80120 	tbnz	w0, #31, 978 <main+0x3b8>
       (n = icmp_recv(id, &src, &rseq, rx, sizeof(rx))) < 0){
 958:	9105c3e3 	add	x3, sp, #0x170
 95c:	9101abe2 	add	x2, sp, #0x6a
 960:	9101b3e1 	add	x1, sp, #0x6c
 964:	2a1603e0 	mov	w0, w22
 968:	52800804 	mov	w4, #0x40                  	// #64
 96c:	97ffff11 	bl	5b0 <icmp_recv@plt>
 970:	2a0003fa 	mov	w26, w0
    if(icmp_send(dst, id, seq, tx, sizeof(tx)) < 0 ||
 974:	36f80100 	tbz	w0, #31, 994 <main+0x3d4>
      fprintf(2, "ping: send/receive failed\n");
 978:	90000001 	adrp	x1, 0 <.plt-0x4d0>
 97c:	912aac21 	add	x1, x1, #0xaab
 980:	17ffff1c 	b	5f0 <main+0x30>
    off += 10 + rdlen;
 984:	11002882 	add	w2, w4, #0xa
  while(answers-- > 0){
 988:	510004c6 	sub	w6, w6, #0x1
    off += 10 + rdlen;
 98c:	0b000042 	add	w2, w2, w0
 990:	17ffffb0 	b	850 <main+0x290>
    after = uptime();
 994:	97fffeeb 	bl	540 <uptime@plt>
    printf(": icmp_seq=%d time=%d ms\n", rseq, (after - before) * 100);
 998:	4b1b0014 	sub	w20, w0, w27
    printf("%d bytes from ", n);
 99c:	2a1a03e1 	mov	w1, w26
 9a0:	aa1703e0 	mov	x0, x23
 9a4:	97fffed3 	bl	4f0 <printf@plt>
    print_ip(src);
 9a8:	b9406fe0 	ldr	w0, [sp, #108]
 9ac:	94000023 	bl	a38 <print_ip>
    printf(": icmp_seq=%d time=%d ms\n", rseq, (after - before) * 100);
 9b0:	52800c82 	mov	w2, #0x64                  	// #100
 9b4:	7940d7e1 	ldrh	w1, [sp, #106]
 9b8:	aa1803e0 	mov	x0, x24
 9bc:	1b027e82 	mul	w2, w20, w2
 9c0:	97fffecc 	bl	4f0 <printf@plt>
    if(seq != 4)
 9c4:	710012bf 	cmp	w21, #0x4
 9c8:	54000061 	b.ne	9d4 <main+0x414>  // b.any
      sleep_ticks(10);
  }
  exit(0);
 9cc:	52800000 	mov	w0, #0x0                   	// #0
 9d0:	17ffff6f 	b	78c <main+0x1cc>
      sleep_ticks(10);
 9d4:	52800140 	mov	w0, #0xa                   	// #10
  for(seq = 1; seq <= 4; seq++){
 9d8:	110006b5 	add	w21, w21, #0x1
      sleep_ticks(10);
 9dc:	97fffed1 	bl	520 <sleep_ticks@plt>
  for(seq = 1; seq <= 4; seq++){
 9e0:	17ffffcf 	b	91c <main+0x35c>

00000000000009e4 <skip_name>:
{
 9e4:	aa0003e4 	mov	x4, x0
  while(off < len){
 9e8:	6b01005f 	cmp	w2, w1
 9ec:	5400010a 	b.ge	a0c <skip_name+0x28>  // b.tcont
    int n = msg[off++];
 9f0:	3862c883 	ldrb	w3, [x4, w2, sxtw]
 9f4:	11000440 	add	w0, w2, #0x1
    if((n & 0xc0) == 0xc0)
 9f8:	121a0465 	and	w5, w3, #0xc0
 9fc:	710300bf 	cmp	w5, #0xc0
 a00:	540000e1 	b.ne	a1c <skip_name+0x38>  // b.any
      return off < len ? off + 1 : -1;
 a04:	6b00003f 	cmp	w1, w0
 a08:	5400006c 	b.gt	a14 <skip_name+0x30>
 a0c:	12800000 	mov	w0, #0xffffffff            	// #-1
}
 a10:	d65f03c0 	ret
      return off < len ? off + 1 : -1;
 a14:	11000840 	add	w0, w2, #0x2
 a18:	17fffffe 	b	a10 <skip_name+0x2c>
    if(n == 0)
 a1c:	34ffffa3 	cbz	w3, a10 <skip_name+0x2c>
    if(n > 63 || off + n > len)
 a20:	7100fc7f 	cmp	w3, #0x3f
 a24:	54ffff4c 	b.gt	a0c <skip_name+0x28>
 a28:	0b030002 	add	w2, w0, w3
 a2c:	6b01005f 	cmp	w2, w1
 a30:	54fffdcd 	b.le	9e8 <skip_name+0x4>
 a34:	17fffff6 	b	a0c <skip_name+0x28>

0000000000000a38 <print_ip>:
{
 a38:	2a0003e1 	mov	w1, w0
  printf("%d.%d.%d.%d", (ip >> 24) & 255, (ip >> 16) & 255,
 a3c:	90000000 	adrp	x0, 0 <.plt-0x4d0>
 a40:	91296000 	add	x0, x0, #0xa58
 a44:	12001c24 	and	w4, w1, #0xff
 a48:	d3483c23 	ubfx	x3, x1, #8, #8
 a4c:	d3505c22 	ubfx	x2, x1, #16, #8
 a50:	53187c21 	lsr	w1, w1, #24
 a54:	17fffea7 	b	4f0 <printf@plt>
