
user/_prodcons:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000003e8 <.plt>:
 3e8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 3ec:	b0000010 	adrp	x16, 1000 <main+0xb68>
 3f0:	f9445e11 	ldr	x17, [x16, #2232]
 3f4:	9122e210 	add	x16, x16, #0x8b8
 3f8:	d61f0220 	br	x17
 3fc:	d503201f 	nop
 400:	d503201f 	nop
 404:	d503201f 	nop

0000000000000408 <printf@plt>:
 408:	b0000010 	adrp	x16, 1000 <main+0xb68>
 40c:	f9446211 	ldr	x17, [x16, #2240]
 410:	91230210 	add	x16, x16, #0x8c0
 414:	d61f0220 	br	x17

0000000000000418 <sync_destroy@plt>:
 418:	b0000010 	adrp	x16, 1000 <main+0xb68>
 41c:	f9446611 	ldr	x17, [x16, #2248]
 420:	91232210 	add	x16, x16, #0x8c8
 424:	d61f0220 	br	x17

0000000000000428 <wait@plt>:
 428:	b0000010 	adrp	x16, 1000 <main+0xb68>
 42c:	f9446a11 	ldr	x17, [x16, #2256]
 430:	91234210 	add	x16, x16, #0x8d0
 434:	d61f0220 	br	x17

0000000000000438 <sync_create@plt>:
 438:	b0000010 	adrp	x16, 1000 <main+0xb68>
 43c:	f9446e11 	ldr	x17, [x16, #2264]
 440:	91236210 	add	x16, x16, #0x8d8
 444:	d61f0220 	br	x17

0000000000000448 <sync_atomic@plt>:
 448:	b0000010 	adrp	x16, 1000 <main+0xb68>
 44c:	f9447211 	ldr	x17, [x16, #2272]
 450:	91238210 	add	x16, x16, #0x8e0
 454:	d61f0220 	br	x17

0000000000000458 <fork@plt>:
 458:	b0000010 	adrp	x16, 1000 <main+0xb68>
 45c:	f9447611 	ldr	x17, [x16, #2280]
 460:	9123a210 	add	x16, x16, #0x8e8
 464:	d61f0220 	br	x17

0000000000000468 <exit@plt>:
 468:	b0000010 	adrp	x16, 1000 <main+0xb68>
 46c:	f9447a11 	ldr	x17, [x16, #2288]
 470:	9123c210 	add	x16, x16, #0x8f0
 474:	d61f0220 	br	x17

0000000000000478 <sync_signal@plt>:
 478:	b0000010 	adrp	x16, 1000 <main+0xb68>
 47c:	f9447e11 	ldr	x17, [x16, #2296]
 480:	9123e210 	add	x16, x16, #0x8f8
 484:	d61f0220 	br	x17

0000000000000488 <sync_wait@plt>:
 488:	b0000010 	adrp	x16, 1000 <main+0xb68>
 48c:	f9448211 	ldr	x17, [x16, #2304]
 490:	91240210 	add	x16, x16, #0x900
 494:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000498 <main>:
  return value;
}

int
main(void)
{
 498:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
static inline int mutex_init(mutex_t *m) { return (*m = sync_create(SYNC_MUTEX, 1)) < 0 ? -1 : 0; }
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
static inline int mutex_destroy(mutex_t *m) { return sync_destroy(*m); }

static inline int sem_init(semaphore_t *s, int value) { return (*s = sync_create(SYNC_SEM, value)) < 0 ? -1 : 0; }
 49c:	52800081 	mov	w1, #0x4                   	// #4
 4a0:	52800040 	mov	w0, #0x2                   	// #2
 4a4:	910003fd 	mov	x29, sp
 4a8:	a90153f3 	stp	x19, x20, [sp, #16]
 4ac:	a9025bf5 	stp	x21, x22, [sp, #32]
 4b0:	a90363f7 	stp	x23, x24, [sp, #48]
 4b4:	a9046bf9 	stp	x25, x26, [sp, #64]
 4b8:	a90573fb 	stp	x27, x28, [sp, #80]
 4bc:	97ffffdf 	bl	438 <sync_create@plt>
 4c0:	36f800c0 	tbz	w0, #31, 4d8 <main+0x40>
  struct shared_queue q;
  int i, pid;

  if(queue_init(&q) < 0){
    printf("prodcons: initialization failed\n");
 4c4:	90000000 	adrp	x0, 0 <.plt-0x3e8>
 4c8:	911c6000 	add	x0, x0, #0x718
    exit(1);
  }

  pid = fork();
  if(pid < 0){
    printf("prodcons: fork failed\n");
 4cc:	97ffffcf 	bl	408 <printf@plt>
    exit(1);
 4d0:	52800020 	mov	w0, #0x1                   	// #1
 4d4:	97ffffe5 	bl	468 <exit@plt>
 4d8:	2a0003f4 	mov	w20, w0
 4dc:	52800001 	mov	w1, #0x0                   	// #0
 4e0:	52800040 	mov	w0, #0x2                   	// #2
 4e4:	97ffffd5 	bl	438 <sync_create@plt>
 4e8:	2a0003f5 	mov	w21, w0
 4ec:	37fffec0 	tbnz	w0, #31, 4c4 <main+0x2c>
static inline int mutex_init(mutex_t *m) { return (*m = sync_create(SYNC_MUTEX, 1)) < 0 ? -1 : 0; }
 4f0:	52800021 	mov	w1, #0x1                   	// #1
 4f4:	2a0103e0 	mov	w0, w1
 4f8:	97ffffd0 	bl	438 <sync_create@plt>
 4fc:	2a0003f3 	mov	w19, w0
 500:	37fffe20 	tbnz	w0, #31, 4c4 <main+0x2c>
static inline int event_notify(event_t *e) { return sync_signal(*e, 1); }
static inline int event_signal(event_t *e) { return sync_signal(*e, 1); }
static inline int event_reset(event_t *e) { return sync_reset(*e); }
static inline int event_destroy(event_t *e) { return sync_destroy(*e); }

static inline int katomic_init(katomic_t *a, int value) { return (*a = sync_create(SYNC_ATOMIC, value)) < 0 ? -1 : 0; }
 504:	52800001 	mov	w1, #0x0                   	// #0
 508:	52800080 	mov	w0, #0x4                   	// #4
 50c:	97ffffcb 	bl	438 <sync_create@plt>
 510:	2a0003f6 	mov	w22, w0
 514:	37fffd80 	tbnz	w0, #31, 4c4 <main+0x2c>
 518:	52800001 	mov	w1, #0x0                   	// #0
 51c:	52800080 	mov	w0, #0x4                   	// #4
 520:	97ffffc6 	bl	438 <sync_create@plt>
 524:	2a0003f7 	mov	w23, w0
 528:	37fffce0 	tbnz	w0, #31, 4c4 <main+0x2c>
 52c:	9101e3f9 	add	x25, sp, #0x78
 530:	d2800018 	mov	x24, #0x0                   	// #0
 534:	52800001 	mov	w1, #0x0                   	// #0
 538:	52800080 	mov	w0, #0x4                   	// #4
 53c:	97ffffbf 	bl	438 <sync_create@plt>
 540:	8b180b21 	add	x1, x25, x24, lsl #2
 544:	b9001420 	str	w0, [x1, #20]
 548:	37fffbe0 	tbnz	w0, #31, 4c4 <main+0x2c>
  for(i = 0; i < NBUF; i++)
 54c:	91000718 	add	x24, x24, #0x1
 550:	f100131f 	cmp	x24, #0x4
 554:	54ffff01 	b.ne	534 <main+0x9c>  // b.any
  pid = fork();
 558:	97ffffc0 	bl	458 <fork@plt>
  if(pid < 0){
 55c:	36f80080 	tbz	w0, #31, 56c <main+0xd4>
    printf("prodcons: fork failed\n");
 560:	90000000 	adrp	x0, 0 <.plt-0x3e8>
 564:	911ce400 	add	x0, x0, #0x739
 568:	17ffffd9 	b	4cc <main+0x34>
  }
  if(pid == 0){
 56c:	9101f3fa 	add	x26, sp, #0x7c
 570:	35000560 	cbnz	w0, 61c <main+0x184>
    for(i = 1; i <= NITEM; i++){
      printf("producer: %d\n", i);
 574:	90000019 	adrp	x25, 0 <.plt-0x3e8>
 578:	911d4339 	add	x25, x25, #0x750
    for(i = 1; i <= NITEM; i++){
 57c:	52800038 	mov	w24, #0x1                   	// #1
      printf("producer: %d\n", i);
 580:	2a1803e1 	mov	w1, w24
 584:	aa1903e0 	mov	x0, x25
 588:	97ffffa0 	bl	408 <printf@plt>
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
 58c:	2a1403e0 	mov	w0, w20
 590:	97ffffbe 	bl	488 <sync_wait@plt>
 594:	2a1303e0 	mov	w0, w19
 598:	97ffffbc 	bl	488 <sync_wait@plt>
static inline int katomic_load(katomic_t *a) { return sync_atomic(*a, ATOMIC_LOAD, 0, 0); }
 59c:	52800003 	mov	w3, #0x0                   	// #0
 5a0:	52800002 	mov	w2, #0x0                   	// #0
 5a4:	52800021 	mov	w1, #0x1                   	// #1
 5a8:	2a1603e0 	mov	w0, w22
 5ac:	97ffffa7 	bl	448 <sync_atomic@plt>
 5b0:	2a0003f7 	mov	w23, w0
static inline int katomic_store(katomic_t *a, int value) { return sync_atomic(*a, ATOMIC_STORE, value, 0); }
 5b4:	8b20cb40 	add	x0, x26, w0, sxtw #2
 5b8:	2a1803e2 	mov	w2, w24
 5bc:	52800003 	mov	w3, #0x0                   	// #0
 5c0:	52800041 	mov	w1, #0x2                   	// #2
    for(i = 1; i <= NITEM; i++){
 5c4:	11000718 	add	w24, w24, #0x1
 5c8:	b9401000 	ldr	w0, [x0, #16]
 5cc:	97ffff9f 	bl	448 <sync_atomic@plt>
  katomic_store(&q->put, (pos + 1) % NBUF);
 5d0:	110006e1 	add	w1, w23, #0x1
 5d4:	52800003 	mov	w3, #0x0                   	// #0
 5d8:	6b0103e2 	negs	w2, w1
 5dc:	12000421 	and	w1, w1, #0x3
 5e0:	12000442 	and	w2, w2, #0x3
 5e4:	2a1603e0 	mov	w0, w22
 5e8:	5a824422 	csneg	w2, w1, w2, mi	// mi = first
 5ec:	52800041 	mov	w1, #0x2                   	// #2
 5f0:	97ffff96 	bl	448 <sync_atomic@plt>
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
 5f4:	52800021 	mov	w1, #0x1                   	// #1
 5f8:	2a1303e0 	mov	w0, w19
 5fc:	97ffff9f 	bl	478 <sync_signal@plt>
 600:	2a1503e0 	mov	w0, w21
 604:	52800021 	mov	w1, #0x1                   	// #1
 608:	97ffff9c 	bl	478 <sync_signal@plt>
    for(i = 1; i <= NITEM; i++){
 60c:	71002f1f 	cmp	w24, #0xb
 610:	54fffb81 	b.ne	580 <main+0xe8>  // b.any
  for(i = 0; i < NITEM; i++)
    printf("consumer: %d\n", consume(&q));
  wait(0);
  queue_destroy(&q);
  printf("prodcons: ok\n");
  exit(0);
 614:	52800000 	mov	w0, #0x0                   	// #0
 618:	17ffffaf 	b	4d4 <main+0x3c>
    printf("consumer: %d\n", consume(&q));
 61c:	90000018 	adrp	x24, 0 <.plt-0x3e8>
 620:	911d7b18 	add	x24, x24, #0x75e
  if(pid == 0){
 624:	5280015c 	mov	w28, #0xa                   	// #10
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
 628:	2a1503e0 	mov	w0, w21
 62c:	97ffff97 	bl	488 <sync_wait@plt>
 630:	2a1303e0 	mov	w0, w19
 634:	97ffff95 	bl	488 <sync_wait@plt>
static inline int katomic_load(katomic_t *a) { return sync_atomic(*a, ATOMIC_LOAD, 0, 0); }
 638:	52800003 	mov	w3, #0x0                   	// #0
 63c:	52800002 	mov	w2, #0x0                   	// #0
 640:	52800021 	mov	w1, #0x1                   	// #1
 644:	2a1703e0 	mov	w0, w23
 648:	97ffff80 	bl	448 <sync_atomic@plt>
 64c:	2a0003fb 	mov	w27, w0
 650:	8b20cb40 	add	x0, x26, w0, sxtw #2
 654:	52800003 	mov	w3, #0x0                   	// #0
 658:	52800002 	mov	w2, #0x0                   	// #0
 65c:	52800021 	mov	w1, #0x1                   	// #1
 660:	b9401000 	ldr	w0, [x0, #16]
 664:	97ffff79 	bl	448 <sync_atomic@plt>
 668:	b9006fe0 	str	w0, [sp, #108]
  katomic_store(&q->get, (pos + 1) % NBUF);
 66c:	11000761 	add	w1, w27, #0x1
static inline int katomic_store(katomic_t *a, int value) { return sync_atomic(*a, ATOMIC_STORE, value, 0); }
 670:	52800003 	mov	w3, #0x0                   	// #0
 674:	6b0103e2 	negs	w2, w1
 678:	12000421 	and	w1, w1, #0x3
 67c:	12000442 	and	w2, w2, #0x3
 680:	2a1703e0 	mov	w0, w23
 684:	5a824422 	csneg	w2, w1, w2, mi	// mi = first
 688:	52800041 	mov	w1, #0x2                   	// #2
 68c:	97ffff6f 	bl	448 <sync_atomic@plt>
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
 690:	52800021 	mov	w1, #0x1                   	// #1
 694:	2a1303e0 	mov	w0, w19
 698:	97ffff78 	bl	478 <sync_signal@plt>
 69c:	52800021 	mov	w1, #0x1                   	// #1
 6a0:	2a1403e0 	mov	w0, w20
 6a4:	97ffff75 	bl	478 <sync_signal@plt>
    printf("consumer: %d\n", consume(&q));
 6a8:	b9406fe1 	ldr	w1, [sp, #108]
 6ac:	aa1803e0 	mov	x0, x24
 6b0:	97ffff56 	bl	408 <printf@plt>
  for(i = 0; i < NITEM; i++)
 6b4:	7100079c 	subs	w28, w28, #0x1
 6b8:	54fffb81 	b.ne	628 <main+0x190>  // b.any
  wait(0);
 6bc:	d2800000 	mov	x0, #0x0                   	// #0
 6c0:	97ffff5a 	bl	428 <wait@plt>
static inline int mutex_destroy(mutex_t *m) { return sync_destroy(*m); }
 6c4:	2a1403e0 	mov	w0, w20
 6c8:	97ffff54 	bl	418 <sync_destroy@plt>
 6cc:	2a1503e0 	mov	w0, w21
 6d0:	97ffff52 	bl	418 <sync_destroy@plt>
 6d4:	2a1303e0 	mov	w0, w19
 6d8:	d2800013 	mov	x19, #0x0                   	// #0
 6dc:	97ffff4f 	bl	418 <sync_destroy@plt>
 6e0:	2a1603e0 	mov	w0, w22
 6e4:	97ffff4d 	bl	418 <sync_destroy@plt>
 6e8:	2a1703e0 	mov	w0, w23
 6ec:	97ffff4b 	bl	418 <sync_destroy@plt>
 6f0:	8b130b20 	add	x0, x25, x19, lsl #2
  for(i = 0; i < NBUF; i++)
 6f4:	91000673 	add	x19, x19, #0x1
 6f8:	b9401400 	ldr	w0, [x0, #20]
 6fc:	97ffff47 	bl	418 <sync_destroy@plt>
 700:	f100127f 	cmp	x19, #0x4
 704:	54ffff61 	b.ne	6f0 <main+0x258>  // b.any
  printf("prodcons: ok\n");
 708:	90000000 	adrp	x0, 0 <.plt-0x3e8>
 70c:	911db000 	add	x0, x0, #0x76c
 710:	97ffff3e 	bl	408 <printf@plt>
 714:	17ffffc0 	b	614 <main+0x17c>
