
user/_tftpd:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000510 <.plt>:
 510:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 514:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 518:	f9409e11 	ldr	x17, [x16, #312]
 51c:	9104e210 	add	x16, x16, #0x138
 520:	d61f0220 	br	x17
 524:	d503201f 	nop
 528:	d503201f 	nop
 52c:	d503201f 	nop

0000000000000530 <printf@plt>:
 530:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 534:	f940a211 	ldr	x17, [x16, #320]
 538:	91050210 	add	x16, x16, #0x140
 53c:	d61f0220 	br	x17

0000000000000540 <memmove@plt>:
 540:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 544:	f940a611 	ldr	x17, [x16, #328]
 548:	91052210 	add	x16, x16, #0x148
 54c:	d61f0220 	br	x17

0000000000000550 <udp_recv@plt>:
 550:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 554:	f940aa11 	ldr	x17, [x16, #336]
 558:	91054210 	add	x16, x16, #0x150
 55c:	d61f0220 	br	x17

0000000000000560 <read@plt>:
 560:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 564:	f940ae11 	ldr	x17, [x16, #344]
 568:	91056210 	add	x16, x16, #0x158
 56c:	d61f0220 	br	x17

0000000000000570 <uptime@plt>:
 570:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 574:	f940b211 	ldr	x17, [x16, #352]
 578:	91058210 	add	x16, x16, #0x160
 57c:	d61f0220 	br	x17

0000000000000580 <udp_bind@plt>:
 580:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 584:	f940b611 	ldr	x17, [x16, #360]
 588:	9105a210 	add	x16, x16, #0x168
 58c:	d61f0220 	br	x17

0000000000000590 <strcmp@plt>:
 590:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 594:	f940ba11 	ldr	x17, [x16, #368]
 598:	9105c210 	add	x16, x16, #0x170
 59c:	d61f0220 	br	x17

00000000000005a0 <udp_recv_timeout@plt>:
 5a0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 5a4:	f940be11 	ldr	x17, [x16, #376]
 5a8:	9105e210 	add	x16, x16, #0x178
 5ac:	d61f0220 	br	x17

00000000000005b0 <udp_send@plt>:
 5b0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 5b4:	f940c211 	ldr	x17, [x16, #384]
 5b8:	91060210 	add	x16, x16, #0x180
 5bc:	d61f0220 	br	x17

00000000000005c0 <udp_unbind@plt>:
 5c0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 5c4:	f940c611 	ldr	x17, [x16, #392]
 5c8:	91062210 	add	x16, x16, #0x188
 5cc:	d61f0220 	br	x17

00000000000005d0 <exit@plt>:
 5d0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 5d4:	f940ca11 	ldr	x17, [x16, #400]
 5d8:	91064210 	add	x16, x16, #0x190
 5dc:	d61f0220 	br	x17

00000000000005e0 <strlen@plt>:
 5e0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 5e4:	f940ce11 	ldr	x17, [x16, #408]
 5e8:	91066210 	add	x16, x16, #0x198
 5ec:	d61f0220 	br	x17

00000000000005f0 <open@plt>:
 5f0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 5f4:	f940d211 	ldr	x17, [x16, #416]
 5f8:	91068210 	add	x16, x16, #0x1a0
 5fc:	d61f0220 	br	x17

0000000000000600 <close@plt>:
 600:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 604:	f940d611 	ldr	x17, [x16, #424]
 608:	9106a210 	add	x16, x16, #0x1a8
 60c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000610 <main>:
  return -1;
}

int
main(int argc, char **argv)
{
 610:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
 614:	910003fd 	mov	x29, sp
 618:	a90153f3 	stp	x19, x20, [sp, #16]
 61c:	a9025bf5 	stp	x21, x22, [sp, #32]
 620:	a90363f7 	stp	x23, x24, [sp, #48]
 624:	a9046bf9 	stp	x25, x26, [sp, #64]
 628:	a90573fb 	stp	x27, x28, [sp, #80]
  const char *root = "/mnt/ext2/video";
  if(argc > 2){
 62c:	7100081f 	cmp	w0, #0x2
 630:	540000cd 	b.le	648 <main+0x38>
    printf("usage: tftpd [service-directory]\n");
 634:	90000000 	adrp	x0, 0 <.plt-0x510>
 638:	9132e000 	add	x0, x0, #0xcb8
    exit(1);
  }
  if(argc == 2)
    root = argv[1];
  if(root[0] != '/'){
    printf("tftpd: service directory must be an absolute path\n");
 63c:	97ffffbd 	bl	530 <printf@plt>
    exit(1);
 640:	52800020 	mov	w0, #0x1                   	// #1
 644:	97ffffe3 	bl	5d0 <exit@plt>
  if(argc == 2)
 648:	54000101 	b.ne	668 <main+0x58>  // b.any
    root = argv[1];
 64c:	f9400436 	ldr	x22, [x1, #8]
  if(root[0] != '/'){
 650:	394002c0 	ldrb	w0, [x22]
 654:	7100bc1f 	cmp	w0, #0x2f
 658:	540000c0 	b.eq	670 <main+0x60>  // b.none
    printf("tftpd: service directory must be an absolute path\n");
 65c:	90000000 	adrp	x0, 0 <.plt-0x510>
 660:	91336800 	add	x0, x0, #0xcda
 664:	17fffff6 	b	63c <main+0x2c>
  const char *root = "/mnt/ext2/video";
 668:	90000016 	adrp	x22, 0 <.plt-0x510>
 66c:	9132a2d6 	add	x22, x22, #0xca8
  }
  if(udp_bind(TFTP_PORT) < 0){
 670:	528008a0 	mov	w0, #0x45                  	// #69
 674:	97ffffc3 	bl	580 <udp_bind@plt>
 678:	36f80080 	tbz	w0, #31, 688 <main+0x78>
    printf("tftpd: cannot bind UDP port 69\n");
 67c:	90000000 	adrp	x0, 0 <.plt-0x510>
 680:	91343400 	add	x0, x0, #0xd0d
 684:	17ffffee 	b	63c <main+0x2c>
    exit(1);
  }
  printf("tftpd: serving %s read-only on UDP port 69\n", root);
 688:	aa1603e1 	mov	x1, x22
 68c:	90000000 	adrp	x0, 0 <.plt-0x510>
 690:	9134b400 	add	x0, x0, #0xd2d
 694:	97ffffa7 	bl	530 <printf@plt>
      send_error(source, source_port, tid, 5, "unknown transfer ID");
 698:	90000000 	adrp	x0, 0 <.plt-0x510>
 69c:	91388400 	add	x0, x0, #0xe21
 6a0:	f90043e0 	str	x0, [sp, #128]

  for(;;){
    uint32 client;
    uint16 client_port;
    int n = udp_recv(TFTP_PORT, &client, &client_port,
 6a4:	b0000013 	adrp	x19, 1000 <_DYNAMIC>
 6a8:	9106d273 	add	x19, x19, #0x1b4
 6ac:	aa1303e3 	mov	x3, x19
 6b0:	910253e2 	add	x2, sp, #0x94
 6b4:	910263e1 	add	x1, sp, #0x98
 6b8:	52804084 	mov	w4, #0x204                 	// #516
 6bc:	528008a0 	mov	w0, #0x45                  	// #69
 6c0:	97ffffa4 	bl	550 <udp_recv@plt>
                     request_packet, sizeof(request_packet));
    if(n < 0){
 6c4:	36f800e0 	tbz	w0, #31, 6e0 <main+0xd0>
      printf("tftpd: UDP receive failed\n");
 6c8:	90000000 	adrp	x0, 0 <.plt-0x510>
 6cc:	91356400 	add	x0, x0, #0xd59
 6d0:	97ffff98 	bl	530 <printf@plt>
                 "only basename octet RRQ is supported");
      continue;
    }
    serve_file(root, client, client_port);
  }
  udp_unbind(TFTP_PORT);
 6d4:	528008a0 	mov	w0, #0x45                  	// #69
 6d8:	97ffffba 	bl	5c0 <udp_unbind@plt>
  exit(1);
 6dc:	17ffffd9 	b	640 <main+0x30>
  if(n < 4 || get16(packet) != 1)
 6e0:	71000c1f 	cmp	w0, #0x3
 6e4:	5400058d 	b.le	794 <main+0x184>
 6e8:	79400261 	ldrh	w1, [x19]
 6ec:	7104003f 	cmp	w1, #0x100
 6f0:	54000521 	b.ne	794 <main+0x184>  // b.any
    request_name[name_length++] = packet[p++];
 6f4:	91081263 	add	x3, x19, #0x204
  if(n < 4 || get16(packet) != 1)
 6f8:	d2800041 	mov	x1, #0x2                   	// #2
  while(p < n && packet[p] && name_length < (int)sizeof(request_name) - 1)
 6fc:	38616a62 	ldrb	w2, [x19, x1]
 700:	2a0103e4 	mov	w4, w1
 704:	35000582 	cbnz	w2, 7b4 <main+0x1a4>
 708:	2a0103e3 	mov	w3, w1
 70c:	51000821 	sub	w1, w1, #0x2
 710:	14000008 	b	730 <main+0x120>
    request_name[name_length++] = packet[p++];
 714:	8b010065 	add	x5, x3, x1
  while(p < n && packet[p] && name_length < (int)sizeof(request_name) - 1)
 718:	91000421 	add	x1, x1, #0x1
    request_name[name_length++] = packet[p++];
 71c:	381fe0a2 	sturb	w2, [x5, #-2]
  while(p < n && packet[p] && name_length < (int)sizeof(request_name) - 1)
 720:	6b01001f 	cmp	w0, w1
 724:	54fffecc 	b.gt	6fc <main+0xec>
    request_name[name_length++] = packet[p++];
 728:	11000483 	add	w3, w4, #0x1
 72c:	51000481 	sub	w1, w4, #0x1
  if(p >= n || packet[p] != 0)
 730:	6b03001f 	cmp	w0, w3
 734:	5400030d 	b.le	794 <main+0x184>
 738:	38634a62 	ldrb	w2, [x19, w3, uxtw]
 73c:	8b234266 	add	x6, x19, w3, uxtw
 740:	350002a2 	cbnz	w2, 794 <main+0x184>
  request_name[name_length] = 0;
 744:	91081262 	add	x2, x19, #0x204
    mode[mode_length++] = c;
 748:	910283e7 	add	x7, sp, #0xa0
  request_name[name_length] = 0;
 74c:	3821485f 	strb	wzr, [x2, w1, uxtw]
  while(p < n && packet[p] && mode_length < (int)sizeof(mode) - 1){
 750:	d2800021 	mov	x1, #0x1                   	// #1
 754:	0b010065 	add	w5, w3, w1
 758:	6b05001f 	cmp	w0, w5
 75c:	540001cd 	b.le	794 <main+0x184>
 760:	386168c2 	ldrb	w2, [x6, x1]
 764:	35000462 	cbnz	w2, 7f0 <main+0x1e0>
 768:	51000420 	sub	w0, w1, #0x1
  if(p >= n || packet[p] != 0)
 76c:	38654a61 	ldrb	w1, [x19, w5, uxtw]
 770:	35000121 	cbnz	w1, 794 <main+0x184>
  mode[mode_length] = 0;
 774:	910283e1 	add	x1, sp, #0xa0
 778:	3820483f 	strb	wzr, [x1, w0, uxtw]
  if(strcmp(mode, "octet") != 0 || !safe_basename(request_name))
 77c:	910283e0 	add	x0, sp, #0xa0
 780:	90000001 	adrp	x1, 0 <.plt-0x510>
 784:	9135d021 	add	x1, x1, #0xd74
 788:	97ffff82 	bl	590 <strcmp@plt>
 78c:	2a0003f7 	mov	w23, w0
 790:	34000380 	cbz	w0, 800 <main+0x1f0>
      send_error(client, client_port, TFTP_PORT, 4,
 794:	79412be1 	ldrh	w1, [sp, #148]
 798:	90000004 	adrp	x4, 0 <.plt-0x510>
 79c:	9135e884 	add	x4, x4, #0xd7a
 7a0:	b9409be0 	ldr	w0, [sp, #152]
 7a4:	52800083 	mov	w3, #0x4                   	// #4
 7a8:	528008a2 	mov	w2, #0x45                  	// #69
    send_error(client, client_port, TFTP_PORT, 2, "invalid path");
 7ac:	94000119 	bl	c10 <send_error.isra.0>
    return -1;
 7b0:	17ffffbd 	b	6a4 <main+0x94>
  while(p < n && packet[p] && name_length < (int)sizeof(request_name) - 1)
 7b4:	f102043f 	cmp	x1, #0x81
 7b8:	54fffae1 	b.ne	714 <main+0x104>  // b.any
 7bc:	2a0103e3 	mov	w3, w1
 7c0:	52800fe1 	mov	w1, #0x7f                  	// #127
 7c4:	17ffffdb 	b	730 <main+0x120>
    if(c >= 'A' && c <= 'Z')
 7c8:	51010444 	sub	w4, w2, #0x41
 7cc:	12001c84 	and	w4, w4, #0xff
 7d0:	7100649f 	cmp	w4, #0x19
      c += 'a' - 'A';
 7d4:	11008044 	add	w4, w2, #0x20
 7d8:	12001c84 	and	w4, w4, #0xff
 7dc:	1a848042 	csel	w2, w2, w4, hi	// hi = pmore
    mode[mode_length++] = c;
 7e0:	8b070024 	add	x4, x1, x7
 7e4:	91000421 	add	x1, x1, #0x1
 7e8:	381ff082 	sturb	w2, [x4, #-1]
 7ec:	17ffffda 	b	754 <main+0x144>
  while(p < n && packet[p] && mode_length < (int)sizeof(mode) - 1){
 7f0:	f100403f 	cmp	x1, #0x10
 7f4:	54fffea1 	b.ne	7c8 <main+0x1b8>  // b.any
 7f8:	528001e0 	mov	w0, #0xf                   	// #15
 7fc:	17ffffdc 	b	76c <main+0x15c>
  int length = strlen(name);
 800:	91081274 	add	x20, x19, #0x204
 804:	aa1403e0 	mov	x0, x20
 808:	97ffff76 	bl	5e0 <strlen@plt>
  if(length == 0 || length >= (int)sizeof(request_name) ||
 80c:	7101fc1f 	cmp	w0, #0x7f
  int length = strlen(name);
 810:	2a0003f5 	mov	w21, w0
  if(length == 0 || length >= (int)sizeof(request_name) ||
 814:	7a40d804 	ccmp	w0, #0x0, #0x4, le
 818:	54fffbe0 	b.eq	794 <main+0x184>  // b.none
     strcmp(name, ".") == 0 || strcmp(name, "..") == 0)
 81c:	90000001 	adrp	x1, 0 <.plt-0x510>
 820:	91368021 	add	x1, x1, #0xda0
 824:	aa1403e0 	mov	x0, x20
 828:	97ffff5a 	bl	590 <strcmp@plt>
  if(length == 0 || length >= (int)sizeof(request_name) ||
 82c:	34fffb40 	cbz	w0, 794 <main+0x184>
     strcmp(name, ".") == 0 || strcmp(name, "..") == 0)
 830:	90000001 	adrp	x1, 0 <.plt-0x510>
 834:	91367c21 	add	x1, x1, #0xd9f
 838:	aa1403e0 	mov	x0, x20
 83c:	97ffff55 	bl	590 <strcmp@plt>
 840:	34fffaa0 	cbz	w0, 794 <main+0x184>
 844:	d2800001 	mov	x1, #0x0                   	// #0
    if(name[i] == '/' || name[i] == '\\' ||
 848:	52800b82 	mov	w2, #0x5c                  	// #92
  for(int i = 0; i < length; i++)
 84c:	6b0102bf 	cmp	w21, w1
 850:	540002ac 	b.gt	8a4 <main+0x294>
      send_error(client, client_port, TFTP_PORT, 4,
 854:	79412bf8 	ldrh	w24, [sp, #148]
 858:	b9409bf4 	ldr	w20, [sp, #152]
  int started = uptime();
 85c:	97ffff45 	bl	570 <uptime@plt>
 860:	b9008fe0 	str	w0, [sp, #140]
  int root_length = strlen(root), name_length = strlen(name);
 864:	aa1603e0 	mov	x0, x22
 868:	97ffff5e 	bl	5e0 <strlen@plt>
 86c:	2a0003f5 	mov	w21, w0
 870:	91081260 	add	x0, x19, #0x204
 874:	97ffff5b 	bl	5e0 <strlen@plt>
 878:	2a0003f9 	mov	w25, w0
  int slash = root_length > 0 && root[root_length - 1] != '/';
 87c:	710002bf 	cmp	w21, #0x0
 880:	5400026c 	b.gt	8cc <main+0x2bc>
  if(root_length == 0 || root_length + slash + name_length + 1 >
 884:	540002c1 	b.ne	8dc <main+0x2cc>  // b.any
    send_error(client, client_port, TFTP_PORT, 2, "invalid path");
 888:	90000004 	adrp	x4, 0 <.plt-0x510>
 88c:	91368884 	add	x4, x4, #0xda2
 890:	2a1803e1 	mov	w1, w24
 894:	2a1403e0 	mov	w0, w20
 898:	52800043 	mov	w3, #0x2                   	// #2
 89c:	528008a2 	mov	w2, #0x45                  	// #69
 8a0:	17ffffc3 	b	7ac <main+0x19c>
    if(name[i] == '/' || name[i] == '\\' ||
 8a4:	38616a80 	ldrb	w0, [x20, x1]
 8a8:	7100bc1f 	cmp	w0, #0x2f
 8ac:	7a421004 	ccmp	w0, w2, #0x4, ne	// ne = any
 8b0:	54fff720 	b.eq	794 <main+0x184>  // b.none
 8b4:	51008000 	sub	w0, w0, #0x20
 8b8:	91000421 	add	x1, x1, #0x1
 8bc:	12001c00 	and	w0, w0, #0xff
 8c0:	7101781f 	cmp	w0, #0x5e
 8c4:	54fffc49 	b.ls	84c <main+0x23c>  // b.plast
 8c8:	17ffffb3 	b	794 <main+0x184>
  int slash = root_length > 0 && root[root_length - 1] != '/';
 8cc:	8b3542c0 	add	x0, x22, w21, uxtw
 8d0:	385ff000 	ldurb	w0, [x0, #-1]
 8d4:	7100bc1f 	cmp	w0, #0x2f
 8d8:	1a9f07f7 	cset	w23, ne	// ne = any
  if(root_length == 0 || root_length + slash + name_length + 1 >
 8dc:	0b1702a0 	add	w0, w21, w23
 8e0:	0b190000 	add	w0, w0, w25
 8e4:	7102fc1f 	cmp	w0, #0xbf
 8e8:	54fffd0c 	b.gt	888 <main+0x278>
  memmove(serve_path, root, root_length);
 8ec:	910a127a 	add	x26, x19, #0x284
 8f0:	2a1503e2 	mov	w2, w21
 8f4:	aa1603e1 	mov	x1, x22
 8f8:	aa1a03e0 	mov	x0, x26
 8fc:	97ffff11 	bl	540 <memmove@plt>
  if(slash)
 900:	34000097 	cbz	w23, 910 <main+0x300>
    serve_path[root_length++] = '/';
 904:	528005e0 	mov	w0, #0x2f                  	// #47
 908:	3835cb40 	strb	w0, [x26, w21, sxtw]
 90c:	110006b5 	add	w21, w21, #0x1
  memmove(serve_path + root_length, name, name_length + 1);
 910:	11000722 	add	w2, w25, #0x1
 914:	910a1277 	add	x23, x19, #0x284
 918:	91081261 	add	x1, x19, #0x204
 91c:	8b35c2e0 	add	x0, x23, w21, sxtw
 920:	97ffff08 	bl	540 <memmove@plt>
  fd = open(serve_path, O_RDONLY);
 924:	aa1703e0 	mov	x0, x23
 928:	52800001 	mov	w1, #0x0                   	// #0
 92c:	97ffff31 	bl	5f0 <open@plt>
 930:	2a0003fa 	mov	w26, w0
  if(fd < 0){
 934:	37f80340 	tbnz	w0, #31, 99c <main+0x38c>
    int tid = next_tid++;
 938:	b0000017 	adrp	x23, 1000 <_DYNAMIC>
 93c:	9106c2f7 	add	x23, x23, #0x1b0
  if(fd < 0){
 940:	52800cb9 	mov	w25, #0x65                  	// #101
    if(next_tid > TFTP_TID_LAST)
 944:	5298769b 	mov	w27, #0xc3b4                	// #50100
 948:	52986a1c 	mov	w28, #0xc350                	// #50000
    int tid = next_tid++;
 94c:	b94002f5 	ldr	w21, [x23]
 950:	110006a0 	add	w0, w21, #0x1
    if(next_tid > TFTP_TID_LAST)
 954:	6b1b001f 	cmp	w0, w27
 958:	1a9cd000 	csel	w0, w0, w28, le
    int tid = next_tid++;
 95c:	b90002e0 	str	w0, [x23]
    if(udp_bind(tid) == 0)
 960:	2a1503e0 	mov	w0, w21
 964:	97ffff07 	bl	580 <udp_bind@plt>
 968:	34000320 	cbz	w0, 9cc <main+0x3bc>
  for(int i = TFTP_TID_FIRST; i <= TFTP_TID_LAST; i++){
 96c:	71000739 	subs	w25, w25, #0x1
 970:	54fffee1 	b.ne	94c <main+0x33c>  // b.any
    send_error(client, client_port, TFTP_PORT, 0, "no transfer port");
 974:	2a1803e1 	mov	w1, w24
 978:	90000004 	adrp	x4, 0 <.plt-0x510>
 97c:	91374c84 	add	x4, x4, #0xdd3
 980:	52800003 	mov	w3, #0x0                   	// #0
 984:	528008a2 	mov	w2, #0x45                  	// #69
 988:	2a1403e0 	mov	w0, w20
 98c:	940000a1 	bl	c10 <send_error.isra.0>
    close(fd);
 990:	2a1a03e0 	mov	w0, w26
 994:	97ffff1b 	bl	600 <close@plt>
    return -1;
 998:	17ffff43 	b	6a4 <main+0x94>
    send_error(client, client_port, TFTP_PORT, 1, "file not found");
 99c:	90000004 	adrp	x4, 0 <.plt-0x510>
 9a0:	9136bc84 	add	x4, x4, #0xdaf
 9a4:	52800023 	mov	w3, #0x1                   	// #1
 9a8:	528008a2 	mov	w2, #0x45                  	// #69
 9ac:	2a1803e1 	mov	w1, w24
 9b0:	2a1403e0 	mov	w0, w20
 9b4:	94000097 	bl	c10 <send_error.isra.0>
    printf("tftpd: not found %s\n", serve_path);
 9b8:	aa1703e1 	mov	x1, x23
 9bc:	90000000 	adrp	x0, 0 <.plt-0x510>
 9c0:	9136f800 	add	x0, x0, #0xdbe
 9c4:	97fffedb 	bl	530 <printf@plt>
    return -1;
 9c8:	17ffff37 	b	6a4 <main+0x94>
  if(tid < 0){
 9cc:	37fffd55 	tbnz	w21, #31, 974 <main+0x364>
  printf("tftpd: RRQ %s from ", serve_path);
 9d0:	910a1261 	add	x1, x19, #0x284
 9d4:	90000000 	adrp	x0, 0 <.plt-0x510>
 9d8:	91379000 	add	x0, x0, #0xde4
 9dc:	97fffed5 	bl	530 <printf@plt>
  printf("%d.%d.%d.%d", (ip >> 24) & 255, (ip >> 16) & 255,
 9e0:	12001e84 	and	w4, w20, #0xff
 9e4:	d3483e83 	ubfx	x3, x20, #8, #8
 9e8:	d3505e82 	ubfx	x2, x20, #16, #8
 9ec:	53187e81 	lsr	w1, w20, #24
 9f0:	90000000 	adrp	x0, 0 <.plt-0x510>
 9f4:	9137e000 	add	x0, x0, #0xdf8
 9f8:	97fffece 	bl	530 <printf@plt>
  int fd = -1, tid = -1, total = 0, last_progress = 0;
 9fc:	52800019 	mov	w25, #0x0                   	// #0
  printf(":%d tid=%d\n", client_port, tid);
 a00:	2a1503e2 	mov	w2, w21
 a04:	2a1803e1 	mov	w1, w24
 a08:	90000000 	adrp	x0, 0 <.plt-0x510>
 a0c:	91381000 	add	x0, x0, #0xe04
 a10:	97fffec8 	bl	530 <printf@plt>
  uint16 block = 1;
 a14:	52800037 	mov	w23, #0x1                   	// #1
    int count = read(fd, data_packet + 4, TFTP_BLOCK_SIZE);
 a18:	910d1260 	add	x0, x19, #0x344
 a1c:	f90033e0 	str	x0, [sp, #96]
  int fd = -1, tid = -1, total = 0, last_progress = 0;
 a20:	b90073ff 	str	wzr, [sp, #112]
    int count = read(fd, data_packet + 4, TFTP_BLOCK_SIZE);
 a24:	910d2261 	add	x1, x19, #0x348
 a28:	2a1a03e0 	mov	w0, w26
 a2c:	52804002 	mov	w2, #0x200                 	// #512
 a30:	97fffecc 	bl	560 <read@plt>
 a34:	2a0003fb 	mov	w27, w0
    if(count < 0){
 a38:	36f80240 	tbz	w0, #31, a80 <main+0x470>
      send_error(client, client_port, tid, 0, "file read failed");
 a3c:	90000004 	adrp	x4, 0 <.plt-0x510>
 a40:	91384084 	add	x4, x4, #0xe10
 a44:	2a1503e2 	mov	w2, w21
 a48:	2a1803e1 	mov	w1, w24
 a4c:	2a1403e0 	mov	w0, w20
 a50:	52800003 	mov	w3, #0x0                   	// #0
 a54:	9400006f 	bl	c10 <send_error.isra.0>
    close(fd);
 a58:	2a1a03e0 	mov	w0, w26
 a5c:	97fffee9 	bl	600 <close@plt>
    udp_unbind(tid);
 a60:	2a1503e0 	mov	w0, w21
 a64:	97fffed7 	bl	5c0 <udp_unbind@plt>
  printf("tftpd: transfer of %s failed after %d bytes\n",
 a68:	2a1903e2 	mov	w2, w25
 a6c:	91081261 	add	x1, x19, #0x204
 a70:	90000000 	adrp	x0, 0 <.plt-0x510>
 a74:	913ae400 	add	x0, x0, #0xeb9
 a78:	97fffeae 	bl	530 <printf@plt>
  return -1;
 a7c:	17ffff0a 	b	6a4 <main+0x94>
  p[0] = value >> 8;
 a80:	f94033e1 	ldr	x1, [sp, #96]
 a84:	52806000 	mov	w0, #0x300                 	// #768
    for(int retry = 0; retry < TFTP_RETRIES; retry++){
 a88:	5280001c 	mov	w28, #0x0                   	// #0
  p[0] = value >> 8;
 a8c:	79000020 	strh	w0, [x1]
 a90:	5ac006e0 	rev16	w0, w23
 a94:	79000420 	strh	w0, [x1, #2]
      if(udp_send(client, tid, client_port, data_packet, count + 4) !=
 a98:	11001360 	add	w0, w27, #0x4
 a9c:	b9006fe0 	str	w0, [sp, #108]
      printf("tftpd: retry block %d (%d/%d)\n",
 aa0:	90000000 	adrp	x0, 0 <.plt-0x510>
 aa4:	9138d400 	add	x0, x0, #0xe35
 aa8:	f9003fe0 	str	x0, [sp, #120]
      if(udp_send(client, tid, client_port, data_packet, count + 4) !=
 aac:	f94033e3 	ldr	x3, [sp, #96]
 ab0:	2a1503e1 	mov	w1, w21
 ab4:	b9406fe4 	ldr	w4, [sp, #108]
 ab8:	2a1803e2 	mov	w2, w24
 abc:	2a1403e0 	mov	w0, w20
 ac0:	97fffebc 	bl	5b0 <udp_send@plt>
 ac4:	b9406fe1 	ldr	w1, [sp, #108]
 ac8:	6b00003f 	cmp	w1, w0
 acc:	54fffc61 	b.ne	a58 <main+0x448>  // b.any
    int n = udp_recv_timeout(tid, &source, &source_port, ack, sizeof(ack),
 ad0:	12003ea0 	and	w0, w21, #0xffff
      int ack = wait_ack(client, client_port, tid, block);
 ad4:	b90077f5 	str	w21, [sp, #116]
    int n = udp_recv_timeout(tid, &source, &source_port, ack, sizeof(ack),
 ad8:	b9008be0 	str	w0, [sp, #136]
 adc:	b9408be0 	ldr	w0, [sp, #136]
 ae0:	91025be2 	add	x2, sp, #0x96
 ae4:	910283e3 	add	x3, sp, #0xa0
 ae8:	910273e1 	add	x1, sp, #0x9c
 aec:	52800145 	mov	w5, #0xa                   	// #10
 af0:	52800804 	mov	w4, #0x40                  	// #64
 af4:	97fffeab 	bl	5a0 <udp_recv_timeout@plt>
 af8:	2a0003e2 	mov	w2, w0
    if(n <= 0)
 afc:	7100001f 	cmp	w0, #0x0
 b00:	540006cd 	b.le	bd8 <main+0x5c8>
    if(source == client && source_port == client_port && n >= 4 &&
 b04:	b9409fe0 	ldr	w0, [sp, #156]
 b08:	79412fe1 	ldrh	w1, [sp, #150]
 b0c:	6b14001f 	cmp	w0, w20
 b10:	540005a1 	b.ne	bc4 <main+0x5b4>  // b.any
 b14:	6b01031f 	cmp	w24, w1
 b18:	54000561 	b.ne	bc4 <main+0x5b4>  // b.any
 b1c:	71000c5f 	cmp	w2, #0x3
 b20:	54fffded 	b.le	adc <main+0x4cc>
 b24:	794143e0 	ldrh	w0, [sp, #160]
 b28:	7110001f 	cmp	w0, #0x400
 b2c:	54fffd81 	b.ne	adc <main+0x4cc>  // b.any
       get16(ack) == 4 && get16(ack + 2) == block)
 b30:	794147e0 	ldrh	w0, [sp, #162]
 b34:	5ac00400 	rev16	w0, w0
 b38:	6b2022ff 	cmp	w23, w0, uxth
 b3c:	54fffd01 	b.ne	adc <main+0x4cc>  // b.any
    if(total - last_progress >= TFTP_PROGRESS_BYTES){
 b40:	b94073e0 	ldr	w0, [sp, #112]
    total += count;
 b44:	0b1b0339 	add	w25, w25, w27
    if(total - last_progress >= TFTP_PROGRESS_BYTES){
 b48:	4b000321 	sub	w1, w25, w0
 b4c:	5287ffe0 	mov	w0, #0x3fff                	// #16383
 b50:	6b00003f 	cmp	w1, w0
 b54:	540000cd 	b.le	b6c <main+0x55c>
      printf("tftpd: sent %d bytes\n", total);
 b58:	2a1903e1 	mov	w1, w25
 b5c:	90000000 	adrp	x0, 0 <.plt-0x510>
 b60:	9139e400 	add	x0, x0, #0xe79
 b64:	97fffe73 	bl	530 <printf@plt>
      last_progress = total;
 b68:	b90073f9 	str	w25, [sp, #112]
    block++;
 b6c:	110006f7 	add	w23, w23, #0x1
 b70:	12003ef7 	and	w23, w23, #0xffff
    if(count < TFTP_BLOCK_SIZE)
 b74:	7107ff7f 	cmp	w27, #0x1ff
 b78:	54fff56c 	b.gt	a24 <main+0x414>
  close(fd);
 b7c:	2a1a03e0 	mov	w0, w26
 b80:	97fffea0 	bl	600 <close@plt>
  udp_unbind(tid);
 b84:	2a1503e0 	mov	w0, w21
 b88:	97fffe8e 	bl	5c0 <udp_unbind@plt>
  int elapsed = uptime() - started;
 b8c:	97fffe79 	bl	570 <uptime@plt>
 b90:	b9408fe1 	ldr	w1, [sp, #140]
  printf("tftpd: completed %s, %d bytes in %d.%d s\n",
 b94:	52800144 	mov	w4, #0xa                   	// #10
 b98:	2a1903e2 	mov	w2, w25
  int elapsed = uptime() - started;
 b9c:	4b010001 	sub	w1, w0, w1
  printf("tftpd: completed %s, %d bytes in %d.%d s\n",
 ba0:	90000000 	adrp	x0, 0 <.plt-0x510>
 ba4:	913a3c00 	add	x0, x0, #0xe8f
 ba8:	1ac40c23 	sdiv	w3, w1, w4
 bac:	1b048464 	msub	w4, w3, w4, w1
 bb0:	b0000001 	adrp	x1, 1000 <_DYNAMIC>
 bb4:	9106d021 	add	x1, x1, #0x1b4
 bb8:	91081021 	add	x1, x1, #0x204
 bbc:	97fffe5d 	bl	530 <printf@plt>
  return 0;
 bc0:	17fffeb9 	b	6a4 <main+0x94>
      send_error(source, source_port, tid, 5, "unknown transfer ID");
 bc4:	f94043e4 	ldr	x4, [sp, #128]
 bc8:	528000a3 	mov	w3, #0x5                   	// #5
 bcc:	7940ebe2 	ldrh	w2, [sp, #116]
 bd0:	94000010 	bl	c10 <send_error.isra.0>
  for(;;){
 bd4:	17ffffc2 	b	adc <main+0x4cc>
      if(ack < 0)
 bd8:	54fff401 	b.ne	a58 <main+0x448>  // b.any
      printf("tftpd: retry block %d (%d/%d)\n",
 bdc:	f9403fe0 	ldr	x0, [sp, #120]
 be0:	1100079c 	add	w28, w28, #0x1
 be4:	2a1c03e2 	mov	w2, w28
 be8:	2a1703e1 	mov	w1, w23
 bec:	528000a3 	mov	w3, #0x5                   	// #5
 bf0:	97fffe50 	bl	530 <printf@plt>
    for(int retry = 0; retry < TFTP_RETRIES; retry++){
 bf4:	7100179f 	cmp	w28, #0x5
 bf8:	54fff5a1 	b.ne	aac <main+0x49c>  // b.any
      printf("tftpd: client timed out at block %d\n", block);
 bfc:	2a1703e1 	mov	w1, w23
 c00:	90000000 	adrp	x0, 0 <.plt-0x510>
 c04:	91395000 	add	x0, x0, #0xe54
 c08:	97fffe4a 	bl	530 <printf@plt>
      goto failed;
 c0c:	17ffff93 	b	a58 <main+0x448>

0000000000000c10 <send_error.isra.0>:
send_error(uint32 client, uint16 client_port, uint16 local_port,
 c10:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
 c14:	910003fd 	mov	x29, sp
 c18:	a90153f3 	stp	x19, x20, [sp, #16]
 c1c:	2a0303f3 	mov	w19, w3
 c20:	aa0403f4 	mov	x20, x4
 c24:	a9025bf5 	stp	x21, x22, [sp, #32]
 c28:	12003c36 	and	w22, w1, #0xffff
 c2c:	12003c55 	and	w21, w2, #0xffff
 c30:	f9001bf7 	str	x23, [sp, #48]
 c34:	2a0003f7 	mov	w23, w0
  int length = strlen(message);
 c38:	aa0403e0 	mov	x0, x4
 c3c:	97fffe69 	bl	5e0 <strlen@plt>
  if(length > (int)sizeof(packet) - 5)
 c40:	7101fc1f 	cmp	w0, #0x7f
 c44:	52800fe1 	mov	w1, #0x7f                  	// #127
 c48:	1a81d002 	csel	w2, w0, w1, le
  p[0] = value >> 8;
 c4c:	5280a000 	mov	w0, #0x500                 	// #1280
  memmove(packet + 4, message, length);
 c50:	aa1403e1 	mov	x1, x20
 c54:	b9004fe2 	str	w2, [sp, #76]
  p[0] = value >> 8;
 c58:	7900b3e0 	strh	w0, [sp, #88]
  memmove(packet + 4, message, length);
 c5c:	910173e0 	add	x0, sp, #0x5c
  p[0] = value >> 8;
 c60:	39016bff 	strb	wzr, [sp, #90]
  p[1] = value;
 c64:	39016ff3 	strb	w19, [sp, #91]
  memmove(packet + 4, message, length);
 c68:	97fffe36 	bl	540 <memmove@plt>
  packet[4 + length] = 0;
 c6c:	b9404fe2 	ldr	w2, [sp, #76]
  memmove(packet + 4, message, length);
 c70:	910163f3 	add	x19, sp, #0x58
  return udp_send(client, local_port, client_port, packet, 5 + length);
 c74:	aa1303e3 	mov	x3, x19
 c78:	2a1503e1 	mov	w1, w21
  packet[4 + length] = 0;
 c7c:	11001040 	add	w0, w2, #0x4
  return udp_send(client, local_port, client_port, packet, 5 + length);
 c80:	11001444 	add	w4, w2, #0x5
 c84:	2a1603e2 	mov	w2, w22
  packet[4 + length] = 0;
 c88:	3820ca7f 	strb	wzr, [x19, w0, sxtw]
  return udp_send(client, local_port, client_port, packet, 5 + length);
 c8c:	2a1703e0 	mov	w0, w23
 c90:	97fffe48 	bl	5b0 <udp_send@plt>
}
 c94:	f9401bf7 	ldr	x23, [sp, #48]
 c98:	a94153f3 	ldp	x19, x20, [sp, #16]
 c9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 ca0:	a8ce7bfd 	ldp	x29, x30, [sp], #224
 ca4:	d65f03c0 	ret
