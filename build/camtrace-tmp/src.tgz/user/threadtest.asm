
user/_threadtest:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000004e0 <.plt>:
 4e0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 4e4:	b0000010 	adrp	x16, 1000 <worker+0x920>
 4e8:	f944ca11 	ldr	x17, [x16, #2448]
 4ec:	91264210 	add	x16, x16, #0x990
 4f0:	d61f0220 	br	x17
 4f4:	d503201f 	nop
 4f8:	d503201f 	nop
 4fc:	d503201f 	nop

0000000000000500 <printf@plt>:
 500:	b0000010 	adrp	x16, 1000 <worker+0x920>
 504:	f944ce11 	ldr	x17, [x16, #2456]
 508:	91266210 	add	x16, x16, #0x998
 50c:	d61f0220 	br	x17

0000000000000510 <sync_destroy@plt>:
 510:	b0000010 	adrp	x16, 1000 <worker+0x920>
 514:	f944d211 	ldr	x17, [x16, #2464]
 518:	91268210 	add	x16, x16, #0x9a0
 51c:	d61f0220 	br	x17

0000000000000520 <gettid@plt>:
 520:	b0000010 	adrp	x16, 1000 <worker+0x920>
 524:	f944d611 	ldr	x17, [x16, #2472]
 528:	9126a210 	add	x16, x16, #0x9a8
 52c:	d61f0220 	br	x17

0000000000000530 <getpid@plt>:
 530:	b0000010 	adrp	x16, 1000 <worker+0x920>
 534:	f944da11 	ldr	x17, [x16, #2480]
 538:	9126c210 	add	x16, x16, #0x9b0
 53c:	d61f0220 	br	x17

0000000000000540 <texit@plt>:
 540:	b0000010 	adrp	x16, 1000 <worker+0x920>
 544:	f944de11 	ldr	x17, [x16, #2488]
 548:	9126e210 	add	x16, x16, #0x9b8
 54c:	d61f0220 	br	x17

0000000000000550 <sync_create@plt>:
 550:	b0000010 	adrp	x16, 1000 <worker+0x920>
 554:	f944e211 	ldr	x17, [x16, #2496]
 558:	91270210 	add	x16, x16, #0x9c0
 55c:	d61f0220 	br	x17

0000000000000560 <getcpu@plt>:
 560:	b0000010 	adrp	x16, 1000 <worker+0x920>
 564:	f944e611 	ldr	x17, [x16, #2504]
 568:	91272210 	add	x16, x16, #0x9c8
 56c:	d61f0220 	br	x17

0000000000000570 <exit@plt>:
 570:	b0000010 	adrp	x16, 1000 <worker+0x920>
 574:	f944ea11 	ldr	x17, [x16, #2512]
 578:	91274210 	add	x16, x16, #0x9d0
 57c:	d61f0220 	br	x17

0000000000000580 <sync_signal@plt>:
 580:	b0000010 	adrp	x16, 1000 <worker+0x920>
 584:	f944ee11 	ldr	x17, [x16, #2520]
 588:	91276210 	add	x16, x16, #0x9d8
 58c:	d61f0220 	br	x17

0000000000000590 <thread_create@plt>:
 590:	b0000010 	adrp	x16, 1000 <worker+0x920>
 594:	f944f211 	ldr	x17, [x16, #2528]
 598:	91278210 	add	x16, x16, #0x9e0
 59c:	d61f0220 	br	x17

00000000000005a0 <sched_yield@plt>:
 5a0:	b0000010 	adrp	x16, 1000 <worker+0x920>
 5a4:	f944f611 	ldr	x17, [x16, #2536]
 5a8:	9127a210 	add	x16, x16, #0x9e8
 5ac:	d61f0220 	br	x17

00000000000005b0 <thread_join@plt>:
 5b0:	b0000010 	adrp	x16, 1000 <worker+0x920>
 5b4:	f944fa11 	ldr	x17, [x16, #2544]
 5b8:	9127c210 	add	x16, x16, #0x9f0
 5bc:	d61f0220 	br	x17

00000000000005c0 <sync_wait@plt>:
 5c0:	b0000010 	adrp	x16, 1000 <worker+0x920>
 5c4:	f944fe11 	ldr	x17, [x16, #2552]
 5c8:	9127e210 	add	x16, x16, #0x9f8
 5cc:	d61f0220 	br	x17

Disassembly of section .text:

00000000000005d0 <main>:
  texit(0);
}

int
main(void)
{
 5d0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
  thread_t a, b;
  int loops = 1000;
 5d4:	52807d00 	mov	w0, #0x3e8                 	// #1000
  int sa = -1, sb = -1;

  counter_lock = sync_create(SYNC_MUTEX, 1);
 5d8:	52800021 	mov	w1, #0x1                   	// #1
{
 5dc:	910003fd 	mov	x29, sp
 5e0:	a90153f3 	stp	x19, x20, [sp, #16]
  counter_lock = sync_create(SYNC_MUTEX, 1);
 5e4:	b0000014 	adrp	x20, 1000 <worker+0x920>
  int loops = 1000;
 5e8:	b90027e0 	str	w0, [sp, #36]
  int sa = -1, sb = -1;
 5ec:	12800000 	mov	w0, #0xffffffff            	// #-1
 5f0:	290503e0 	stp	w0, w0, [sp, #40]
  counter_lock = sync_create(SYNC_MUTEX, 1);
 5f4:	2a0103e0 	mov	w0, w1
 5f8:	97ffffd6 	bl	550 <sync_create@plt>
 5fc:	b90a0280 	str	w0, [x20, #2560]
  if(counter_lock < 0){
 600:	36f800c0 	tbz	w0, #31, 618 <main+0x48>
    printf("threadtest: cannot create mutex\n");
 604:	90000000 	adrp	x0, 0 <.plt-0x4e0>
 608:	911ecc00 	add	x0, x0, #0x7b3
    exit(1);
  }
  if(thread_create(&a, worker, &loops) < 0 ||
     thread_create(&b, worker, &loops) < 0){
    printf("threadtest: create failed\n");
 60c:	97ffffbd 	bl	500 <printf@plt>
    exit(1);
 610:	52800020 	mov	w0, #0x1                   	// #1
 614:	97ffffd7 	bl	570 <exit@plt>
  if(thread_create(&a, worker, &loops) < 0 ||
 618:	90000001 	adrp	x1, 0 <.plt-0x4e0>
 61c:	911b8021 	add	x1, x1, #0x6e0
 620:	910093e2 	add	x2, sp, #0x24
 624:	9100c3e0 	add	x0, sp, #0x30
 628:	97ffffda 	bl	590 <thread_create@plt>
 62c:	37f800e0 	tbnz	w0, #31, 648 <main+0x78>
     thread_create(&b, worker, &loops) < 0){
 630:	90000000 	adrp	x0, 0 <.plt-0x4e0>
 634:	911b8001 	add	x1, x0, #0x6e0
 638:	910093e2 	add	x2, sp, #0x24
 63c:	910103e0 	add	x0, sp, #0x40
 640:	97ffffd4 	bl	590 <thread_create@plt>
  if(thread_create(&a, worker, &loops) < 0 ||
 644:	36f80080 	tbz	w0, #31, 654 <main+0x84>
    printf("threadtest: create failed\n");
 648:	90000000 	adrp	x0, 0 <.plt-0x4e0>
 64c:	911f5000 	add	x0, x0, #0x7d4
 650:	17ffffef 	b	60c <main+0x3c>
  }
  if(thread_join(&a, &sa) < 0 || thread_join(&b, &sb) < 0){
 654:	9100a3e1 	add	x1, sp, #0x28
 658:	9100c3e0 	add	x0, sp, #0x30
 65c:	97ffffd5 	bl	5b0 <thread_join@plt>
 660:	37f800a0 	tbnz	w0, #31, 674 <main+0xa4>
 664:	9100b3e1 	add	x1, sp, #0x2c
 668:	910103e0 	add	x0, sp, #0x40
 66c:	97ffffd1 	bl	5b0 <thread_join@plt>
 670:	36f80080 	tbz	w0, #31, 680 <main+0xb0>
    printf("threadtest: join failed\n");
 674:	90000000 	adrp	x0, 0 <.plt-0x4e0>
 678:	911fbc00 	add	x0, x0, #0x7ef
 67c:	17ffffe4 	b	60c <main+0x3c>
    exit(1);
  }
  sync_destroy(counter_lock);
 680:	b94a0280 	ldr	w0, [x20, #2560]
 684:	91280293 	add	x19, x20, #0xa00
 688:	97ffffa2 	bl	510 <sync_destroy@plt>
  if(counter != 2 * loops || sa != 0 || sb != 0){
 68c:	29448be1 	ldp	w1, w2, [sp, #36]
 690:	b9400660 	ldr	w0, [x19, #4]
 694:	b9402fe3 	ldr	w3, [sp, #44]
 698:	6b01041f 	cmp	w0, w1, lsl #1
 69c:	54000061 	b.ne	6a8 <main+0xd8>  // b.any
 6a0:	2a030040 	orr	w0, w2, w3
 6a4:	340000c0 	cbz	w0, 6bc <main+0xec>
    printf("threadtest: FAIL counter=%d status=%d,%d\n", counter, sa, sb);
 6a8:	b9400661 	ldr	w1, [x19, #4]
 6ac:	90000000 	adrp	x0, 0 <.plt-0x4e0>
 6b0:	91202000 	add	x0, x0, #0x808
 6b4:	97ffff93 	bl	500 <printf@plt>
    exit(1);
 6b8:	17ffffd6 	b	610 <main+0x40>
  }
  printf("threadtest: PASS counter=%d tgid=%d\n", counter, getpid());
 6bc:	b9400673 	ldr	w19, [x19, #4]
 6c0:	97ffff9c 	bl	530 <getpid@plt>
 6c4:	2a0003e2 	mov	w2, w0
 6c8:	90000000 	adrp	x0, 0 <.plt-0x4e0>
 6cc:	9120c800 	add	x0, x0, #0x832
 6d0:	2a1303e1 	mov	w1, w19
 6d4:	97ffff8b 	bl	500 <printf@plt>
  exit(0);
 6d8:	52800000 	mov	w0, #0x0                   	// #0
 6dc:	17ffffce 	b	614 <main+0x44>

00000000000006e0 <worker>:
{
 6e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 6e4:	910003fd 	mov	x29, sp
 6e8:	a90153f3 	stp	x19, x20, [sp, #16]
 6ec:	f90013f5 	str	x21, [sp, #32]
  int loops = *(int *)arg;
 6f0:	b9400015 	ldr	w21, [x0]
  printf("threadtest: tid=%d tgid=%d cpu=%d started\n",
 6f4:	97ffff8b 	bl	520 <gettid@plt>
 6f8:	2a0003f3 	mov	w19, w0
 6fc:	97ffff8d 	bl	530 <getpid@plt>
 700:	2a0003f4 	mov	w20, w0
 704:	97ffff97 	bl	560 <getcpu@plt>
 708:	2a1303e1 	mov	w1, w19
    if(sync_wait(counter_lock) < 0)
 70c:	b0000013 	adrp	x19, 1000 <worker+0x920>
 710:	91280273 	add	x19, x19, #0xa00
  printf("threadtest: tid=%d tgid=%d cpu=%d started\n",
 714:	2a1403e2 	mov	w2, w20
  for(int i = 0; i < loops; i++){
 718:	52800014 	mov	w20, #0x0                   	// #0
  printf("threadtest: tid=%d tgid=%d cpu=%d started\n",
 71c:	2a0003e3 	mov	w3, w0
 720:	90000000 	adrp	x0, 0 <.plt-0x4e0>
 724:	911e2000 	add	x0, x0, #0x788
 728:	97ffff76 	bl	500 <printf@plt>
  for(int i = 0; i < loops; i++){
 72c:	6b15029f 	cmp	w20, w21
 730:	5400006b 	b.lt	73c <worker+0x5c>  // b.tstop
  texit(0);
 734:	52800000 	mov	w0, #0x0                   	// #0
 738:	14000005 	b	74c <worker+0x6c>
    if(sync_wait(counter_lock) < 0)
 73c:	b9400260 	ldr	w0, [x19]
 740:	97ffffa0 	bl	5c0 <sync_wait@plt>
 744:	36f80060 	tbz	w0, #31, 750 <worker+0x70>
      texit(2);
 748:	52800040 	mov	w0, #0x2                   	// #2
      texit(3);
 74c:	97ffff7d 	bl	540 <texit@plt>
    counter++;
 750:	b9400660 	ldr	w0, [x19, #4]
    if(sync_signal(counter_lock, 1) < 0)
 754:	52800021 	mov	w1, #0x1                   	// #1
    counter++;
 758:	11000400 	add	w0, w0, #0x1
 75c:	b9000660 	str	w0, [x19, #4]
    if(sync_signal(counter_lock, 1) < 0)
 760:	b9400260 	ldr	w0, [x19]
 764:	97ffff87 	bl	580 <sync_signal@plt>
 768:	36f80060 	tbz	w0, #31, 774 <worker+0x94>
      texit(3);
 76c:	52800060 	mov	w0, #0x3                   	// #3
 770:	17fffff7 	b	74c <worker+0x6c>
    if((i & 127) == 0)
 774:	f2401a9f 	tst	x20, #0x7f
 778:	54000041 	b.ne	780 <worker+0xa0>  // b.any
      sched_yield();
 77c:	97ffff89 	bl	5a0 <sched_yield@plt>
  for(int i = 0; i < loops; i++){
 780:	11000694 	add	w20, w20, #0x1
 784:	17ffffea 	b	72c <worker+0x4c>
