
user/_ps:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002b0 <.plt>:
 2b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2b4:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2b8:	f9426611 	ldr	x17, [x16, #1224]
 2bc:	91132210 	add	x16, x16, #0x4c8
 2c0:	d61f0220 	br	x17
 2c4:	d503201f 	nop
 2c8:	d503201f 	nop
 2cc:	d503201f 	nop

00000000000002d0 <ps@plt>:
 2d0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2d4:	f9426a11 	ldr	x17, [x16, #1232]
 2d8:	91134210 	add	x16, x16, #0x4d0
 2dc:	d61f0220 	br	x17

00000000000002e0 <write@plt>:
 2e0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2e4:	f9426e11 	ldr	x17, [x16, #1240]
 2e8:	91136210 	add	x16, x16, #0x4d8
 2ec:	d61f0220 	br	x17

00000000000002f0 <fprintf@plt>:
 2f0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2f4:	f9427211 	ldr	x17, [x16, #1248]
 2f8:	91138210 	add	x16, x16, #0x4e0
 2fc:	d61f0220 	br	x17

0000000000000300 <exit@plt>:
 300:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 304:	f9427611 	ldr	x17, [x16, #1256]
 308:	9113a210 	add	x16, x16, #0x4e8
 30c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000310 <main>:
#include <uapi/types.h>
#include "user/user.h"

int
main(void)
{
 310:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  static char buf[4096];
  int n = ps(buf, sizeof(buf));
 314:	52820001 	mov	w1, #0x1000                	// #4096
{
 318:	910003fd 	mov	x29, sp
 31c:	a90153f3 	stp	x19, x20, [sp, #16]
  int n = ps(buf, sizeof(buf));
 320:	b0000013 	adrp	x19, 1000 <main+0xcf0>
 324:	9113c260 	add	x0, x19, #0x4f0
 328:	97ffffea 	bl	2d0 <ps@plt>
  if(n < 0 || write(1, buf, n) != n){
 32c:	36f800e0 	tbz	w0, #31, 348 <main+0x38>
    fprintf(2, "ps: cannot read process table\n");
 330:	90000001 	adrp	x1, 0 <.plt-0x2b0>
 334:	910db021 	add	x1, x1, #0x36c
 338:	52800040 	mov	w0, #0x2                   	// #2
 33c:	97ffffed 	bl	2f0 <fprintf@plt>
    exit(1);
 340:	52800020 	mov	w0, #0x1                   	// #1
  }
  exit(0);
 344:	97ffffef 	bl	300 <exit@plt>
 348:	2a0003f4 	mov	w20, w0
  if(n < 0 || write(1, buf, n) != n){
 34c:	2a0003e2 	mov	w2, w0
 350:	9113c261 	add	x1, x19, #0x4f0
 354:	52800020 	mov	w0, #0x1                   	// #1
 358:	97ffffe2 	bl	2e0 <write@plt>
 35c:	6b14001f 	cmp	w0, w20
 360:	54fffe81 	b.ne	330 <main+0x20>  // b.any
  exit(0);
 364:	52800000 	mov	w0, #0x0                   	// #0
 368:	17fffff7 	b	344 <main+0x34>
