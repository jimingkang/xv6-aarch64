
user/_nettest:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000003a8 <.plt>:
 3a8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 3ac:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 3b0:	f9439611 	ldr	x17, [x16, #1832]
 3b4:	911ca210 	add	x16, x16, #0x728
 3b8:	d61f0220 	br	x17
 3bc:	d503201f 	nop
 3c0:	d503201f 	nop
 3c4:	d503201f 	nop

00000000000003c8 <printf@plt>:
 3c8:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 3cc:	f9439a11 	ldr	x17, [x16, #1840]
 3d0:	911cc210 	add	x16, x16, #0x730
 3d4:	d61f0220 	br	x17

00000000000003d8 <udp_recv@plt>:
 3d8:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 3dc:	f9439e11 	ldr	x17, [x16, #1848]
 3e0:	911ce210 	add	x16, x16, #0x738
 3e4:	d61f0220 	br	x17

00000000000003e8 <wait@plt>:
 3e8:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 3ec:	f943a211 	ldr	x17, [x16, #1856]
 3f0:	911d0210 	add	x16, x16, #0x740
 3f4:	d61f0220 	br	x17

00000000000003f8 <fork@plt>:
 3f8:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 3fc:	f943a611 	ldr	x17, [x16, #1864]
 400:	911d2210 	add	x16, x16, #0x748
 404:	d61f0220 	br	x17

0000000000000408 <udp_bind@plt>:
 408:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 40c:	f943aa11 	ldr	x17, [x16, #1872]
 410:	911d4210 	add	x16, x16, #0x750
 414:	d61f0220 	br	x17

0000000000000418 <udp_send@plt>:
 418:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 41c:	f943ae11 	ldr	x17, [x16, #1880]
 420:	911d6210 	add	x16, x16, #0x758
 424:	d61f0220 	br	x17

0000000000000428 <udp_unbind@plt>:
 428:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 42c:	f943b211 	ldr	x17, [x16, #1888]
 430:	911d8210 	add	x16, x16, #0x760
 434:	d61f0220 	br	x17

0000000000000438 <exit@plt>:
 438:	b0000010 	adrp	x16, 1000 <main+0xbb8>
 43c:	f943b611 	ldr	x17, [x16, #1896]
 440:	911da210 	add	x16, x16, #0x768
 444:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000448 <main>:
#define IP_LOOPBACK 0x7f000001U

int
main(void)
{
  char tx[] = "hello from xv6 UDP";
 448:	90000000 	adrp	x0, 0 <.plt-0x3a8>
 44c:	91176c00 	add	x0, x0, #0x5db
{
 450:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
 454:	910003fd 	mov	x29, sp
  char tx[] = "hello from xv6 UDP";
 458:	a9400c02 	ldp	x2, x3, [x0]
 45c:	a9018fe2 	stp	x2, x3, [sp, #24]
 460:	b840f000 	ldur	w0, [x0, #15]
 464:	b80273e0 	stur	w0, [sp, #39]
  char rx[64];
  uint32 src;
  uint16 sport;
  int pid, n;

  if(udp_bind(2000) < 0){
 468:	5280fa00 	mov	w0, #0x7d0                 	// #2000
 46c:	97ffffe7 	bl	408 <udp_bind@plt>
 470:	36f800c0 	tbz	w0, #31, 488 <main+0x40>
    printf("nettest: bind failed\n");
 474:	90000000 	adrp	x0, 0 <.plt-0x3a8>
 478:	91152000 	add	x0, x0, #0x548
    exit(1);
  }
  pid = fork();
  if(pid < 0){
    printf("nettest: fork failed\n");
 47c:	97ffffd3 	bl	3c8 <printf@plt>
    exit(1);
 480:	52800020 	mov	w0, #0x1                   	// #1
 484:	97ffffed 	bl	438 <exit@plt>
  pid = fork();
 488:	97ffffdc 	bl	3f8 <fork@plt>
  if(pid < 0){
 48c:	36f80080 	tbz	w0, #31, 49c <main+0x54>
    printf("nettest: fork failed\n");
 490:	90000000 	adrp	x0, 0 <.plt-0x3a8>
 494:	91157800 	add	x0, x0, #0x55e
 498:	17fffff9 	b	47c <main+0x34>
  }
  if(pid == 0){
 49c:	35000180 	cbnz	w0, 4cc <main+0x84>
    if(udp_send(IP_LOOPBACK, 1000, 2000, tx, sizeof(tx)) < 0){
 4a0:	52800020 	mov	w0, #0x1                   	// #1
 4a4:	72afe000 	movk	w0, #0x7f00, lsl #16
 4a8:	910063e3 	add	x3, sp, #0x18
 4ac:	52800264 	mov	w4, #0x13                  	// #19
 4b0:	5280fa02 	mov	w2, #0x7d0                 	// #2000
 4b4:	52807d01 	mov	w1, #0x3e8                 	// #1000
 4b8:	97ffffd8 	bl	418 <udp_send@plt>
 4bc:	36f80420 	tbz	w0, #31, 540 <main+0xf8>
      printf("nettest: send failed\n");
 4c0:	90000000 	adrp	x0, 0 <.plt-0x3a8>
 4c4:	9115d000 	add	x0, x0, #0x574
 4c8:	17ffffed 	b	47c <main+0x34>
      exit(1);
    }
    exit(0);
  }

  n = udp_recv(2000, &src, &sport, rx, sizeof(rx) - 1);
 4cc:	9100c3e3 	add	x3, sp, #0x30
 4d0:	91004be2 	add	x2, sp, #0x12
 4d4:	910053e1 	add	x1, sp, #0x14
 4d8:	528007e4 	mov	w4, #0x3f                  	// #63
 4dc:	5280fa00 	mov	w0, #0x7d0                 	// #2000
 4e0:	97ffffbe 	bl	3d8 <udp_recv@plt>
  if(n < 0){
 4e4:	9100c3e7 	add	x7, sp, #0x30
  n = udp_recv(2000, &src, &sport, rx, sizeof(rx) - 1);
 4e8:	2a0003e6 	mov	w6, w0
  if(n < 0){
 4ec:	36f80080 	tbz	w0, #31, 4fc <main+0xb4>
    printf("nettest: recv failed\n");
 4f0:	90000000 	adrp	x0, 0 <.plt-0x3a8>
 4f4:	91162800 	add	x0, x0, #0x58a
 4f8:	17ffffe1 	b	47c <main+0x34>
    exit(1);
  }
  rx[n] = 0;
  printf("nettest: src=%d.%d.%d.%d:%d len=%d data='%s'\n",
 4fc:	b94017e1 	ldr	w1, [sp, #20]
 500:	794027e5 	ldrh	w5, [sp, #18]
 504:	12001c24 	and	w4, w1, #0xff
  rx[n] = 0;
 508:	382048ff 	strb	wzr, [x7, w0, uxtw]
  printf("nettest: src=%d.%d.%d.%d:%d len=%d data='%s'\n",
 50c:	d3483c23 	ubfx	x3, x1, #8, #8
 510:	d3505c22 	ubfx	x2, x1, #16, #8
 514:	53187c21 	lsr	w1, w1, #24
 518:	90000000 	adrp	x0, 0 <.plt-0x3a8>
 51c:	91168000 	add	x0, x0, #0x5a0
 520:	97ffffaa 	bl	3c8 <printf@plt>
         (src >> 24) & 255, (src >> 16) & 255,
         (src >> 8) & 255, src & 255, sport, n, rx);
  wait(0);
 524:	d2800000 	mov	x0, #0x0                   	// #0
 528:	97ffffb0 	bl	3e8 <wait@plt>
  udp_unbind(2000);
 52c:	5280fa00 	mov	w0, #0x7d0                 	// #2000
 530:	97ffffbe 	bl	428 <udp_unbind@plt>
  printf("nettest: ok\n");
 534:	90000000 	adrp	x0, 0 <.plt-0x3a8>
 538:	91173800 	add	x0, x0, #0x5ce
 53c:	97ffffa3 	bl	3c8 <printf@plt>
  exit(0);
 540:	52800000 	mov	w0, #0x0                   	// #0
 544:	17ffffd0 	b	484 <main+0x3c>
