
user/_rm:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000278 <.plt>:
 278:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 27c:	b0000010 	adrp	x16, 1000 <main+0xd38>
 280:	f9425611 	ldr	x17, [x16, #1192]
 284:	9112a210 	add	x16, x16, #0x4a8
 288:	d61f0220 	br	x17
 28c:	d503201f 	nop
 290:	d503201f 	nop
 294:	d503201f 	nop

0000000000000298 <fprintf@plt>:
 298:	b0000010 	adrp	x16, 1000 <main+0xd38>
 29c:	f9425a11 	ldr	x17, [x16, #1200]
 2a0:	9112c210 	add	x16, x16, #0x4b0
 2a4:	d61f0220 	br	x17

00000000000002a8 <unlink@plt>:
 2a8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2ac:	f9425e11 	ldr	x17, [x16, #1208]
 2b0:	9112e210 	add	x16, x16, #0x4b8
 2b4:	d61f0220 	br	x17

00000000000002b8 <exit@plt>:
 2b8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2bc:	f9426211 	ldr	x17, [x16, #1216]
 2c0:	91130210 	add	x16, x16, #0x4c0
 2c4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000002c8 <main>:
#include <uapi/stat.h>
#include "user/user.h"

int
main(int argc, char *argv[])
{
 2c8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 2cc:	910003fd 	mov	x29, sp
 2d0:	a90153f3 	stp	x19, x20, [sp, #16]
 2d4:	f90013f5 	str	x21, [sp, #32]
  int i;

  if(argc < 2){
 2d8:	7100041f 	cmp	w0, #0x1
 2dc:	540000ec 	b.gt	2f8 <main+0x30>
    fprintf(2, "Usage: rm files...\n");
 2e0:	90000001 	adrp	x1, 0 <.plt-0x278>
 2e4:	910cf021 	add	x1, x1, #0x33c
 2e8:	52800040 	mov	w0, #0x2                   	// #2
 2ec:	97ffffeb 	bl	298 <fprintf@plt>
    exit(1);
 2f0:	52800020 	mov	w0, #0x1                   	// #1
      fprintf(2, "rm: %s failed to delete\n", argv[i]);
      break;
    }
  }

  exit(0);
 2f4:	97fffff1 	bl	2b8 <exit@plt>
 2f8:	2a0003f4 	mov	w20, w0
 2fc:	aa0103f5 	mov	x21, x1
  if(argc < 2){
 300:	d2800033 	mov	x19, #0x1                   	// #1
    if(unlink(argv[i]) < 0){
 304:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
 308:	97ffffe8 	bl	2a8 <unlink@plt>
 30c:	36f80100 	tbz	w0, #31, 32c <main+0x64>
      fprintf(2, "rm: %s failed to delete\n", argv[i]);
 310:	f8735aa2 	ldr	x2, [x21, w19, uxtw #3]
 314:	90000001 	adrp	x1, 0 <.plt-0x278>
 318:	910d4021 	add	x1, x1, #0x350
 31c:	52800040 	mov	w0, #0x2                   	// #2
 320:	97ffffde 	bl	298 <fprintf@plt>
  exit(0);
 324:	52800000 	mov	w0, #0x0                   	// #0
 328:	17fffff3 	b	2f4 <main+0x2c>
  for(i = 1; i < argc; i++){
 32c:	91000673 	add	x19, x19, #0x1
 330:	6b13029f 	cmp	w20, w19
 334:	54fffe8c 	b.gt	304 <main+0x3c>
 338:	17fffffb 	b	324 <main+0x5c>
