
user/_touch:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002b0 <.plt>:
 2b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2b4:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2b8:	f9427e11 	ldr	x17, [x16, #1272]
 2bc:	9113e210 	add	x16, x16, #0x4f8
 2c0:	d61f0220 	br	x17
 2c4:	d503201f 	nop
 2c8:	d503201f 	nop
 2cc:	d503201f 	nop

00000000000002d0 <fprintf@plt>:
 2d0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2d4:	f9428211 	ldr	x17, [x16, #1280]
 2d8:	91140210 	add	x16, x16, #0x500
 2dc:	d61f0220 	br	x17

00000000000002e0 <exit@plt>:
 2e0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2e4:	f9428611 	ldr	x17, [x16, #1288]
 2e8:	91142210 	add	x16, x16, #0x508
 2ec:	d61f0220 	br	x17

00000000000002f0 <open@plt>:
 2f0:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 2f4:	f9428a11 	ldr	x17, [x16, #1296]
 2f8:	91144210 	add	x16, x16, #0x510
 2fc:	d61f0220 	br	x17

0000000000000300 <close@plt>:
 300:	b0000010 	adrp	x16, 1000 <main+0xcf0>
 304:	f9428e11 	ldr	x17, [x16, #1304]
 308:	91146210 	add	x16, x16, #0x518
 30c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000310 <main>:
#include <fcntl.h>
#include "user/user.h"

int
main(int argc, char **argv)
{
 310:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 314:	910003fd 	mov	x29, sp
 318:	a90153f3 	stp	x19, x20, [sp, #16]
 31c:	f90013f5 	str	x21, [sp, #32]
  if(argc < 2){
 320:	7100041f 	cmp	w0, #0x1
 324:	540000ec 	b.gt	340 <main+0x30>
    fprintf(2, "usage: touch file...\n");
 328:	90000001 	adrp	x1, 0 <.plt-0x2b0>
 32c:	910e3021 	add	x1, x1, #0x38c
 330:	52800040 	mov	w0, #0x2                   	// #2
 334:	97ffffe7 	bl	2d0 <fprintf@plt>
  }
  for(int i = 1; i < argc; i++){
    int fd = open(argv[i], O_CREATE | O_WRONLY);
    if(fd < 0){
      fprintf(2, "touch: cannot create %s\n", argv[i]);
      exit(1);
 338:	52800020 	mov	w0, #0x1                   	// #1
 33c:	97ffffe9 	bl	2e0 <exit@plt>
 340:	2a0003f4 	mov	w20, w0
 344:	aa0103f5 	mov	x21, x1
  if(argc < 2){
 348:	d2800033 	mov	x19, #0x1                   	// #1
    int fd = open(argv[i], O_CREATE | O_WRONLY);
 34c:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
 350:	52804021 	mov	w1, #0x201                 	// #513
 354:	97ffffe7 	bl	2f0 <open@plt>
    if(fd < 0){
 358:	36f800e0 	tbz	w0, #31, 374 <main+0x64>
      fprintf(2, "touch: cannot create %s\n", argv[i]);
 35c:	f8735aa2 	ldr	x2, [x21, w19, uxtw #3]
 360:	90000001 	adrp	x1, 0 <.plt-0x2b0>
 364:	910e8821 	add	x1, x1, #0x3a2
 368:	52800040 	mov	w0, #0x2                   	// #2
 36c:	97ffffd9 	bl	2d0 <fprintf@plt>
 370:	17fffff2 	b	338 <main+0x28>
  for(int i = 1; i < argc; i++){
 374:	91000673 	add	x19, x19, #0x1
    }
    close(fd);
 378:	97ffffe2 	bl	300 <close@plt>
  for(int i = 1; i < argc; i++){
 37c:	6b13029f 	cmp	w20, w19
 380:	54fffe6c 	b.gt	34c <main+0x3c>
  }
  exit(0);
 384:	52800000 	mov	w0, #0x0                   	// #0
 388:	17ffffed 	b	33c <main+0x2c>
