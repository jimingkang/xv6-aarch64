
user/_dhcp:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000278 <.plt>:
 278:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 27c:	b0000010 	adrp	x16, 1000 <main+0xd38>
 280:	f9424211 	ldr	x17, [x16, #1152]
 284:	91120210 	add	x16, x16, #0x480
 288:	d61f0220 	br	x17
 28c:	d503201f 	nop
 290:	d503201f 	nop
 294:	d503201f 	nop

0000000000000298 <net_dhcp@plt>:
 298:	b0000010 	adrp	x16, 1000 <main+0xd38>
 29c:	f9424611 	ldr	x17, [x16, #1160]
 2a0:	91122210 	add	x16, x16, #0x488
 2a4:	d61f0220 	br	x17

00000000000002a8 <printf@plt>:
 2a8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2ac:	f9424a11 	ldr	x17, [x16, #1168]
 2b0:	91124210 	add	x16, x16, #0x490
 2b4:	d61f0220 	br	x17

00000000000002b8 <exit@plt>:
 2b8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2bc:	f9424e11 	ldr	x17, [x16, #1176]
 2c0:	91126210 	add	x16, x16, #0x498
 2c4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000002c8 <main>:
#include <uapi/types.h>
#include "user/user.h"

int
main(int argc, char **argv)
{
 2c8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 2cc:	910003fd 	mov	x29, sp
  if(argc != 2){
 2d0:	7100081f 	cmp	w0, #0x2
 2d4:	540000c0 	b.eq	2ec <main+0x24>  // b.none
    printf("usage: dhcp interface\n");
 2d8:	90000000 	adrp	x0, 0 <.plt-0x278>
 2dc:	910c7000 	add	x0, x0, #0x31c
 2e0:	97fffff2 	bl	2a8 <printf@plt>
    exit(1);
  }
  if(net_dhcp(argv[1]) < 0){
    printf("dhcp: failed on %s\n", argv[1]);
    exit(1);
 2e4:	52800020 	mov	w0, #0x1                   	// #1
 2e8:	97fffff4 	bl	2b8 <exit@plt>
  if(net_dhcp(argv[1]) < 0){
 2ec:	f9400420 	ldr	x0, [x1, #8]
 2f0:	f9000fe1 	str	x1, [sp, #24]
 2f4:	97ffffe9 	bl	298 <net_dhcp@plt>
 2f8:	36f800e0 	tbz	w0, #31, 314 <main+0x4c>
    printf("dhcp: failed on %s\n", argv[1]);
 2fc:	f9400fe1 	ldr	x1, [sp, #24]
 300:	90000000 	adrp	x0, 0 <.plt-0x278>
 304:	910ccc00 	add	x0, x0, #0x333
 308:	f9400421 	ldr	x1, [x1, #8]
 30c:	97ffffe7 	bl	2a8 <printf@plt>
 310:	17fffff5 	b	2e4 <main+0x1c>
  }
  exit(0);
 314:	52800000 	mov	w0, #0x0                   	// #0
 318:	17fffff4 	b	2e8 <main+0x20>
