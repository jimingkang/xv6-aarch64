
user/_sshd:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000d00 <.plt>:
 d00:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 d04:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d08:	f9452611 	ldr	x17, [x16, #2632]
 d0c:	91292210 	add	x16, x16, #0xa48
 d10:	d61f0220 	br	x17
 d14:	d503201f 	nop
 d18:	d503201f 	nop
 d1c:	d503201f 	nop

0000000000000d20 <ssh_x25519@plt>:
 d20:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d24:	f9452a11 	ldr	x17, [x16, #2640]
 d28:	91294210 	add	x16, x16, #0xa50
 d2c:	d61f0220 	br	x17

0000000000000d30 <strcpy@plt>:
 d30:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d34:	f9452e11 	ldr	x17, [x16, #2648]
 d38:	91296210 	add	x16, x16, #0xa58
 d3c:	d61f0220 	br	x17

0000000000000d40 <socket_accept@plt>:
 d40:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d44:	f9453211 	ldr	x17, [x16, #2656]
 d48:	91298210 	add	x16, x16, #0xa60
 d4c:	d61f0220 	br	x17

0000000000000d50 <printf@plt>:
 d50:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d54:	f9453611 	ldr	x17, [x16, #2664]
 d58:	9129a210 	add	x16, x16, #0xa68
 d5c:	d61f0220 	br	x17

0000000000000d60 <epoll_wait@plt>:
 d60:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d64:	f9453a11 	ldr	x17, [x16, #2672]
 d68:	9129c210 	add	x16, x16, #0xa70
 d6c:	d61f0220 	br	x17

0000000000000d70 <memmove@plt>:
 d70:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d74:	f9453e11 	ldr	x17, [x16, #2680]
 d78:	9129e210 	add	x16, x16, #0xa78
 d7c:	d61f0220 	br	x17

0000000000000d80 <getpid@plt>:
 d80:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d84:	f9454211 	ldr	x17, [x16, #2688]
 d88:	912a0210 	add	x16, x16, #0xa80
 d8c:	d61f0220 	br	x17

0000000000000d90 <memcpy@plt>:
 d90:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 d94:	f9454611 	ldr	x17, [x16, #2696]
 d98:	912a2210 	add	x16, x16, #0xa88
 d9c:	d61f0220 	br	x17

0000000000000da0 <ssh_ed25519_keypair@plt>:
 da0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 da4:	f9454a11 	ldr	x17, [x16, #2704]
 da8:	912a4210 	add	x16, x16, #0xa90
 dac:	d61f0220 	br	x17

0000000000000db0 <malloc@plt>:
 db0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 db4:	f9454e11 	ldr	x17, [x16, #2712]
 db8:	912a6210 	add	x16, x16, #0xa98
 dbc:	d61f0220 	br	x17

0000000000000dc0 <ssh_hmac_sha256@plt>:
 dc0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 dc4:	f9455211 	ldr	x17, [x16, #2720]
 dc8:	912a8210 	add	x16, x16, #0xaa0
 dcc:	d61f0220 	br	x17

0000000000000dd0 <ssh_sha256@plt>:
 dd0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 dd4:	f9455611 	ldr	x17, [x16, #2728]
 dd8:	912aa210 	add	x16, x16, #0xaa8
 ddc:	d61f0220 	br	x17

0000000000000de0 <epoll_ctl@plt>:
 de0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 de4:	f9455a11 	ldr	x17, [x16, #2736]
 de8:	912ac210 	add	x16, x16, #0xab0
 dec:	d61f0220 	br	x17

0000000000000df0 <write@plt>:
 df0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 df4:	f9455e11 	ldr	x17, [x16, #2744]
 df8:	912ae210 	add	x16, x16, #0xab8
 dfc:	d61f0220 	br	x17

0000000000000e00 <kill@plt>:
 e00:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e04:	f9456211 	ldr	x17, [x16, #2752]
 e08:	912b0210 	add	x16, x16, #0xac0
 e0c:	d61f0220 	br	x17

0000000000000e10 <ssh_random@plt>:
 e10:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e14:	f9456611 	ldr	x17, [x16, #2760]
 e18:	912b2210 	add	x16, x16, #0xac8
 e1c:	d61f0220 	br	x17

0000000000000e20 <chdir@plt>:
 e20:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e24:	f9456a11 	ldr	x17, [x16, #2768]
 e28:	912b4210 	add	x16, x16, #0xad0
 e2c:	d61f0220 	br	x17

0000000000000e30 <ssh_x25519_public@plt>:
 e30:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e34:	f9456e11 	ldr	x17, [x16, #2776]
 e38:	912b6210 	add	x16, x16, #0xad8
 e3c:	d61f0220 	br	x17

0000000000000e40 <exec@plt>:
 e40:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e44:	f9457211 	ldr	x17, [x16, #2784]
 e48:	912b8210 	add	x16, x16, #0xae0
 e4c:	d61f0220 	br	x17

0000000000000e50 <wait@plt>:
 e50:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e54:	f9457611 	ldr	x17, [x16, #2792]
 e58:	912ba210 	add	x16, x16, #0xae8
 e5c:	d61f0220 	br	x17

0000000000000e60 <read@plt>:
 e60:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e64:	f9457a11 	ldr	x17, [x16, #2800]
 e68:	912bc210 	add	x16, x16, #0xaf0
 e6c:	d61f0220 	br	x17

0000000000000e70 <ssh_aes128_ctr_xor@plt>:
 e70:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e74:	f9457e11 	ldr	x17, [x16, #2808]
 e78:	912be210 	add	x16, x16, #0xaf8
 e7c:	d61f0220 	br	x17

0000000000000e80 <strncpy@plt>:
 e80:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e84:	f9458211 	ldr	x17, [x16, #2816]
 e88:	912c0210 	add	x16, x16, #0xb00
 e8c:	d61f0220 	br	x17

0000000000000e90 <epoll_create@plt>:
 e90:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 e94:	f9458611 	ldr	x17, [x16, #2824]
 e98:	912c2210 	add	x16, x16, #0xb08
 e9c:	d61f0220 	br	x17

0000000000000ea0 <memcmp@plt>:
 ea0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 ea4:	f9458a11 	ldr	x17, [x16, #2832]
 ea8:	912c4210 	add	x16, x16, #0xb10
 eac:	d61f0220 	br	x17

0000000000000eb0 <fork@plt>:
 eb0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 eb4:	f9458e11 	ldr	x17, [x16, #2840]
 eb8:	912c6210 	add	x16, x16, #0xb18
 ebc:	d61f0220 	br	x17

0000000000000ec0 <uptime@plt>:
 ec0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 ec4:	f9459211 	ldr	x17, [x16, #2848]
 ec8:	912c8210 	add	x16, x16, #0xb20
 ecc:	d61f0220 	br	x17

0000000000000ed0 <ssh_aes128_ctr_init@plt>:
 ed0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 ed4:	f9459611 	ldr	x17, [x16, #2856]
 ed8:	912ca210 	add	x16, x16, #0xb28
 edc:	d61f0220 	br	x17

0000000000000ee0 <memset@plt>:
 ee0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 ee4:	f9459a11 	ldr	x17, [x16, #2864]
 ee8:	912cc210 	add	x16, x16, #0xb30
 eec:	d61f0220 	br	x17

0000000000000ef0 <socket_listen@plt>:
 ef0:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 ef4:	f9459e11 	ldr	x17, [x16, #2872]
 ef8:	912ce210 	add	x16, x16, #0xb38
 efc:	d61f0220 	br	x17

0000000000000f00 <dup@plt>:
 f00:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f04:	f945a211 	ldr	x17, [x16, #2880]
 f08:	912d0210 	add	x16, x16, #0xb40
 f0c:	d61f0220 	br	x17

0000000000000f10 <pty_open@plt>:
 f10:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f14:	f945a611 	ldr	x17, [x16, #2888]
 f18:	912d2210 	add	x16, x16, #0xb48
 f1c:	d61f0220 	br	x17

0000000000000f20 <exit@plt>:
 f20:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f24:	f945aa11 	ldr	x17, [x16, #2896]
 f28:	912d4210 	add	x16, x16, #0xb50
 f2c:	d61f0220 	br	x17

0000000000000f30 <ssh_ed25519_sign@plt>:
 f30:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f34:	f945ae11 	ldr	x17, [x16, #2904]
 f38:	912d6210 	add	x16, x16, #0xb58
 f3c:	d61f0220 	br	x17

0000000000000f40 <atoi@plt>:
 f40:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f44:	f945b211 	ldr	x17, [x16, #2912]
 f48:	912d8210 	add	x16, x16, #0xb60
 f4c:	d61f0220 	br	x17

0000000000000f50 <strlen@plt>:
 f50:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f54:	f945b611 	ldr	x17, [x16, #2920]
 f58:	912da210 	add	x16, x16, #0xb68
 f5c:	d61f0220 	br	x17

0000000000000f60 <open@plt>:
 f60:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f64:	f945ba11 	ldr	x17, [x16, #2928]
 f68:	912dc210 	add	x16, x16, #0xb70
 f6c:	d61f0220 	br	x17

0000000000000f70 <strchr@plt>:
 f70:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f74:	f945be11 	ldr	x17, [x16, #2936]
 f78:	912de210 	add	x16, x16, #0xb78
 f7c:	d61f0220 	br	x17

0000000000000f80 <close@plt>:
 f80:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f84:	f945c211 	ldr	x17, [x16, #2944]
 f88:	912e0210 	add	x16, x16, #0xb80
 f8c:	d61f0220 	br	x17

0000000000000f90 <free@plt>:
 f90:	90000030 	adrp	x16, 4000 <serve_connection+0x18ac>
 f94:	f945c611 	ldr	x17, [x16, #2952]
 f98:	912e2210 	add	x16, x16, #0xb88
 f9c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000fa0 <main>:
  free(payload);
}

int
main(int argc, char **argv)
{
     fa0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     fa4:	910003fd 	mov	x29, sp
     fa8:	a90153f3 	stp	x19, x20, [sp, #16]
  int port = 22;
  if(argc > 1)
     fac:	7100041f 	cmp	w0, #0x1
     fb0:	5400020d 	b.le	ff0 <main+0x50>
    port = atoi(argv[1]);
     fb4:	f9400420 	ldr	x0, [x1, #8]
     fb8:	97ffffe2 	bl	f40 <atoi@plt>
     fbc:	2a0003f3 	mov	w19, w0
  ssh_listener = socket_listen(port, 4);
     fc0:	90000034 	adrp	x20, 4000 <serve_connection+0x18ac>
     fc4:	2a1303e0 	mov	w0, w19
     fc8:	52800081 	mov	w1, #0x4                   	// #4
     fcc:	97ffffc9 	bl	ef0 <socket_listen@plt>
     fd0:	b90b9280 	str	w0, [x20, #2960]
  if(ssh_listener < 0){
     fd4:	36f80120 	tbz	w0, #31, ff8 <main+0x58>
    printf("sshd: cannot listen on port %d\n", port);
     fd8:	2a1303e1 	mov	w1, w19
     fdc:	f0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
     fe0:	911fd400 	add	x0, x0, #0x7f5
     fe4:	97ffff5b 	bl	d50 <printf@plt>
    exit(1);
     fe8:	52800020 	mov	w0, #0x1                   	// #1
     fec:	97ffffcd 	bl	f20 <exit@plt>
  int port = 22;
     ff0:	528002d3 	mov	w19, #0x16                  	// #22
     ff4:	17fffff3 	b	fc0 <main+0x20>
  }
  printf("sshd: SSH-2 transport bring-up listening on port %d\n", port);
  for(;;){
    int connection = socket_accept(ssh_listener);
     ff8:	912e4294 	add	x20, x20, #0xb90
  printf("sshd: SSH-2 transport bring-up listening on port %d\n", port);
     ffc:	2a1303e1 	mov	w1, w19
    1000:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1004:	91205400 	add	x0, x0, #0x815
    1008:	97ffff52 	bl	d50 <printf@plt>
    int connection = socket_accept(ssh_listener);
    100c:	b9400280 	ldr	w0, [x20]
    1010:	97ffff4c 	bl	d40 <socket_accept@plt>
    1014:	2a0003f3 	mov	w19, w0
    if(connection < 0)
    1018:	37ffffa0 	tbnz	w0, #31, 100c <main+0x6c>
      continue;
    serve_connection(connection);
    101c:	940005ce 	bl	2754 <serve_connection>
    close(connection);
    1020:	2a1303e0 	mov	w0, w19
    1024:	97ffffd7 	bl	f80 <close@plt>
    1028:	17fffff9 	b	100c <main+0x6c>

000000000000102c <get32>:
  return ((uint32)p[0] << 24) | ((uint32)p[1] << 16) |
    102c:	b9400000 	ldr	w0, [x0]
}
    1030:	5ac00800 	rev	w0, w0
    1034:	d65f03c0 	ret

0000000000001038 <parse_u32>:
  if(*offset < 0 || *offset + 4 > length)
    1038:	b9400044 	ldr	w4, [x2]
    103c:	36f80064 	tbz	w4, #31, 1048 <parse_u32+0x10>
    return -1;
    1040:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    1044:	d65f03c0 	ret
  if(*offset < 0 || *offset + 4 > length)
    1048:	11000c85 	add	w5, w4, #0x3
    104c:	6b0100bf 	cmp	w5, w1
    1050:	54ffff8a 	b.ge	1040 <parse_u32+0x8>  // b.tcont
{
    1054:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  *value = get32(p + *offset);
    1058:	8b244000 	add	x0, x0, w4, uxtw
{
    105c:	910003fd 	mov	x29, sp
  *value = get32(p + *offset);
    1060:	97fffff3 	bl	102c <get32>
}
    1064:	a8c17bfd 	ldp	x29, x30, [sp], #16
  *value = get32(p + *offset);
    1068:	b9000060 	str	w0, [x3]
  *offset += 4;
    106c:	b9400040 	ldr	w0, [x2]
    1070:	11001000 	add	w0, w0, #0x4
    1074:	b9000040 	str	w0, [x2]
  return 0;
    1078:	52800000 	mov	w0, #0x0                   	// #0
}
    107c:	d65f03c0 	ret

0000000000001080 <parse_string>:
{
    1080:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1084:	aa0303e8 	mov	x8, x3
    1088:	aa0003e9 	mov	x9, x0
    108c:	910003fd 	mov	x29, sp
    1090:	aa0403e7 	mov	x7, x4
  if(parse_u32(p, length, offset, &n) < 0 ||
    1094:	910073e3 	add	x3, sp, #0x1c
    1098:	97ffffe8 	bl	1038 <parse_u32>
    109c:	3100041f 	cmn	w0, #0x1
    10a0:	540001c0 	b.eq	10d8 <parse_string+0x58>  // b.none
    10a4:	aa0203e6 	mov	x6, x2
     n > (uint32)(length - *offset))
    10a8:	b9400042 	ldr	w2, [x2]
    10ac:	b9401fe5 	ldr	w5, [sp, #28]
    10b0:	4b020021 	sub	w1, w1, w2
  if(parse_u32(p, length, offset, &n) < 0 ||
    10b4:	6b05003f 	cmp	w1, w5
    10b8:	54000143 	b.cc	10e0 <parse_string+0x60>  // b.lo, b.ul, b.last
  *value = p + *offset;
    10bc:	8b22c122 	add	x2, x9, w2, sxtw
    10c0:	f9000102 	str	x2, [x8]
  *value_length = n;
    10c4:	b90000e5 	str	w5, [x7]
  *offset += n;
    10c8:	b94000c0 	ldr	w0, [x6]
    10cc:	0b050000 	add	w0, w0, w5
    10d0:	b90000c0 	str	w0, [x6]
  return 0;
    10d4:	52800000 	mov	w0, #0x0                   	// #0
}
    10d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    10dc:	d65f03c0 	ret
    return -1;
    10e0:	12800000 	mov	w0, #0xffffffff            	// #-1
    10e4:	17fffffd 	b	10d8 <parse_string+0x58>

00000000000010e8 <append_bytes>:
  if(n < 0 || *offset + n > capacity)
    10e8:	36f800e4 	tbz	w4, #31, 1104 <append_bytes+0x1c>
    return -1;
    10ec:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    10f0:	d65f03c0 	ret
    return -1;
    10f4:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    10f8:	f9400bf3 	ldr	x19, [sp, #16]
    10fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1100:	d65f03c0 	ret
{
    1104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1108:	910003fd 	mov	x29, sp
  if(n < 0 || *offset + n > capacity)
    110c:	b9400045 	ldr	w5, [x2]
{
    1110:	f9000bf3 	str	x19, [sp, #16]
    1114:	aa0203f3 	mov	x19, x2
  if(n < 0 || *offset + n > capacity)
    1118:	0b0400a2 	add	w2, w5, w4
    111c:	6b01005f 	cmp	w2, w1
    1120:	54fffeac 	b.gt	10f4 <append_bytes+0xc>
  memmove(p + *offset, src, n);
    1124:	2a0403e2 	mov	w2, w4
    1128:	aa0303e1 	mov	x1, x3
    112c:	8b25c000 	add	x0, x0, w5, sxtw
    1130:	b9002fe4 	str	w4, [sp, #44]
    1134:	97ffff0f 	bl	d70 <memmove@plt>
  *offset += n;
    1138:	b9400260 	ldr	w0, [x19]
    113c:	b9402fe4 	ldr	w4, [sp, #44]
    1140:	0b040000 	add	w0, w0, w4
    1144:	b9000260 	str	w0, [x19]
  return 0;
    1148:	52800000 	mov	w0, #0x0                   	// #0
    114c:	17ffffeb 	b	10f8 <append_bytes+0x10>

0000000000001150 <string_is>:
{
    1150:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1154:	910003fd 	mov	x29, sp
    1158:	a90153f3 	stp	x19, x20, [sp, #16]
    115c:	aa0003f4 	mov	x20, x0
    1160:	aa0203f3 	mov	x19, x2
  int n = strlen(expected);
    1164:	aa0203e0 	mov	x0, x2
{
    1168:	b9002fe1 	str	w1, [sp, #44]
  int n = strlen(expected);
    116c:	97ffff79 	bl	f50 <strlen@plt>
  return length == (uint32)n && memcmp(value, expected, n) == 0;
    1170:	b9402fe1 	ldr	w1, [sp, #44]
    1174:	6b01001f 	cmp	w0, w1
    1178:	54000141 	b.ne	11a0 <string_is+0x50>  // b.any
    117c:	2a0003e2 	mov	w2, w0
    1180:	aa1303e1 	mov	x1, x19
    1184:	aa1403e0 	mov	x0, x20
    1188:	97ffff46 	bl	ea0 <memcmp@plt>
    118c:	7100001f 	cmp	w0, #0x0
    1190:	1a9f17e0 	cset	w0, eq	// eq = none
}
    1194:	a94153f3 	ldp	x19, x20, [sp, #16]
    1198:	a8c37bfd 	ldp	x29, x30, [sp], #48
    119c:	d65f03c0 	ret
  return length == (uint32)n && memcmp(value, expected, n) == 0;
    11a0:	52800000 	mov	w0, #0x0                   	// #0
    11a4:	17fffffc 	b	1194 <string_is+0x44>

00000000000011a8 <writen>:
{
    11a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    11ac:	910003fd 	mov	x29, sp
    11b0:	a90153f3 	stp	x19, x20, [sp, #16]
    11b4:	2a0203f4 	mov	w20, w2
  int done = 0;
    11b8:	52800013 	mov	w19, #0x0                   	// #0
{
    11bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    11c0:	2a0003f6 	mov	w22, w0
    11c4:	aa0103f5 	mov	x21, x1
  while(done < n){
    11c8:	6b14027f 	cmp	w19, w20
    11cc:	540000cb 	b.lt	11e4 <writen+0x3c>  // b.tstop
  return 0;
    11d0:	52800000 	mov	w0, #0x0                   	// #0
}
    11d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    11d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    11dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    11e0:	d65f03c0 	ret
    int r = write(fd, p + done, n - done);
    11e4:	4b130282 	sub	w2, w20, w19
    11e8:	8b33c2a1 	add	x1, x21, w19, sxtw
    11ec:	2a1603e0 	mov	w0, w22
    11f0:	97ffff00 	bl	df0 <write@plt>
    if(r <= 0)
    11f4:	7100001f 	cmp	w0, #0x0
    11f8:	5400006d 	b.le	1204 <writen+0x5c>
    done += r;
    11fc:	0b000273 	add	w19, w19, w0
    1200:	17fffff2 	b	11c8 <writen+0x20>
      return -1;
    1204:	12800000 	mov	w0, #0xffffffff            	// #-1
    1208:	17fffff3 	b	11d4 <writen+0x2c>

000000000000120c <readn>:
{
    120c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1210:	910003fd 	mov	x29, sp
    1214:	a90153f3 	stp	x19, x20, [sp, #16]
    1218:	2a0203f4 	mov	w20, w2
  int done = 0;
    121c:	52800013 	mov	w19, #0x0                   	// #0
{
    1220:	a9025bf5 	stp	x21, x22, [sp, #32]
    1224:	2a0003f6 	mov	w22, w0
    1228:	aa0103f5 	mov	x21, x1
  while(done < n){
    122c:	6b14027f 	cmp	w19, w20
    1230:	540000cb 	b.lt	1248 <readn+0x3c>  // b.tstop
  return 0;
    1234:	52800000 	mov	w0, #0x0                   	// #0
}
    1238:	a94153f3 	ldp	x19, x20, [sp, #16]
    123c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1240:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1244:	d65f03c0 	ret
    int r = read(fd, p + done, n - done);
    1248:	4b130282 	sub	w2, w20, w19
    124c:	8b33c2a1 	add	x1, x21, w19, sxtw
    1250:	2a1603e0 	mov	w0, w22
    1254:	97ffff03 	bl	e60 <read@plt>
    if(r <= 0)
    1258:	7100001f 	cmp	w0, #0x0
    125c:	5400006d 	b.le	1268 <readn+0x5c>
    done += r;
    1260:	0b000273 	add	w19, w19, w0
    1264:	17fffff2 	b	122c <readn+0x20>
      return -1;
    1268:	12800000 	mov	w0, #0xffffffff            	// #-1
    126c:	17fffff3 	b	1238 <readn+0x2c>

0000000000001270 <append_u32>:
{
    1270:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  p[3] = v;
    1274:	5ac00863 	rev	w3, w3
  return append_bytes(p, capacity, offset, b, sizeof(b));
    1278:	52800084 	mov	w4, #0x4                   	// #4
{
    127c:	910003fd 	mov	x29, sp
  p[0] = v >> 24;
    1280:	b9001be3 	str	w3, [sp, #24]
  return append_bytes(p, capacity, offset, b, sizeof(b));
    1284:	910063e3 	add	x3, sp, #0x18
    1288:	97ffff98 	bl	10e8 <append_bytes>
}
    128c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1290:	d65f03c0 	ret

0000000000001294 <append_string>:
{
    1294:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1298:	910003fd 	mov	x29, sp
    129c:	a90153f3 	stp	x19, x20, [sp, #16]
    12a0:	aa0003f3 	mov	x19, x0
    12a4:	2a0103f4 	mov	w20, w1
  int n = strlen(s);
    12a8:	aa0303e0 	mov	x0, x3
{
    12ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    12b0:	aa0203f5 	mov	x21, x2
    12b4:	aa0303f6 	mov	x22, x3
  int n = strlen(s);
    12b8:	97ffff26 	bl	f50 <strlen@plt>
  if(append_u32(p, capacity, offset, n) < 0)
    12bc:	aa1503e2 	mov	x2, x21
    12c0:	2a0003e3 	mov	w3, w0
    12c4:	2a1403e1 	mov	w1, w20
    12c8:	b9003fe0 	str	w0, [sp, #60]
    12cc:	aa1303e0 	mov	x0, x19
    12d0:	97ffffe8 	bl	1270 <append_u32>
    12d4:	3100041f 	cmn	w0, #0x1
    12d8:	54000140 	b.eq	1300 <append_string+0x6c>  // b.none
  return append_bytes(p, capacity, offset, s, n);
    12dc:	b9403fe4 	ldr	w4, [sp, #60]
    12e0:	aa1603e3 	mov	x3, x22
    12e4:	aa1503e2 	mov	x2, x21
    12e8:	2a1403e1 	mov	w1, w20
}
    12ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
  return append_bytes(p, capacity, offset, s, n);
    12f0:	aa1303e0 	mov	x0, x19
}
    12f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    12f8:	a8c47bfd 	ldp	x29, x30, [sp], #64
  return append_bytes(p, capacity, offset, s, n);
    12fc:	17ffff7b 	b	10e8 <append_bytes>
}
    1300:	a94153f3 	ldp	x19, x20, [sp, #16]
    1304:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1308:	a8c47bfd 	ldp	x29, x30, [sp], #64
    130c:	d65f03c0 	ret

0000000000001310 <append_blob>:
{
    1310:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1314:	910003fd 	mov	x29, sp
    1318:	a90153f3 	stp	x19, x20, [sp, #16]
    131c:	aa0303f4 	mov	x20, x3
    1320:	aa0003f3 	mov	x19, x0
  if(append_u32(p, capacity, offset, length) < 0)
    1324:	2a0403e3 	mov	w3, w4
{
    1328:	f90013e2 	str	x2, [sp, #32]
  if(append_u32(p, capacity, offset, length) < 0)
    132c:	290507e4 	stp	w4, w1, [sp, #40]
    1330:	97ffffd0 	bl	1270 <append_u32>
    1334:	3100041f 	cmn	w0, #0x1
    1338:	54000100 	b.eq	1358 <append_blob+0x48>  // b.none
  return append_bytes(p, capacity, offset, data, length);
    133c:	f94013e2 	ldr	x2, [sp, #32]
    1340:	aa1403e3 	mov	x3, x20
    1344:	294507e4 	ldp	w4, w1, [sp, #40]
    1348:	aa1303e0 	mov	x0, x19
}
    134c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1350:	a8c37bfd 	ldp	x29, x30, [sp], #48
  return append_bytes(p, capacity, offset, data, length);
    1354:	17ffff65 	b	10e8 <append_bytes>
}
    1358:	a94153f3 	ldp	x19, x20, [sp, #16]
    135c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1360:	d65f03c0 	ret

0000000000001364 <append_shared_secret_mpint>:
{
    1364:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    1368:	910003fd 	mov	x29, sp
    136c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1370:	aa0003f6 	mov	x22, x0
    1374:	a90363f7 	stp	x23, x24, [sp, #48]
    1378:	2a0103f7 	mov	w23, w1
    137c:	aa0203f8 	mov	x24, x2
    1380:	a90153f3 	stp	x19, x20, [sp, #16]
    1384:	f90023f9 	str	x25, [sp, #64]
    1388:	aa0303f9 	mov	x25, x3
    138c:	d2800003 	mov	x3, #0x0                   	// #0
  while(first < 32 && shared[first] == 0)
    1390:	38636b20 	ldrb	w0, [x25, x3]
    1394:	35000080 	cbnz	w0, 13a4 <append_shared_secret_mpint+0x40>
    1398:	91000463 	add	x3, x3, #0x1
    139c:	f100807f 	cmp	x3, #0x20
    13a0:	54ffff81 	b.ne	1390 <append_shared_secret_mpint+0x2c>  // b.any
  int length = 32 - first;
    13a4:	52800415 	mov	w21, #0x20                  	// #32
  while(first < 32 && shared[first] == 0)
    13a8:	2a0303f3 	mov	w19, w3
  int length = 32 - first;
    13ac:	4b0302b5 	sub	w21, w21, w3
  int zero_prefix = length > 0 && (shared[first] & 0x80);
    13b0:	7100807f 	cmp	w3, #0x20
    13b4:	540003e0 	b.eq	1430 <append_shared_secret_mpint+0xcc>  // b.none
    13b8:	38e34b34 	ldrsb	w20, [x25, w3, uxtw]
    13bc:	531f7e94 	lsr	w20, w20, #31
  if(append_u32(p, capacity, offset, length + zero_prefix) < 0)
    13c0:	0b150283 	add	w3, w20, w21
    13c4:	aa1803e2 	mov	x2, x24
    13c8:	2a1703e1 	mov	w1, w23
    13cc:	aa1603e0 	mov	x0, x22
    13d0:	97ffffa8 	bl	1270 <append_u32>
    13d4:	3100041f 	cmn	w0, #0x1
    13d8:	54000300 	b.eq	1438 <append_shared_secret_mpint+0xd4>  // b.none
  if(zero_prefix){
    13dc:	34000154 	cbz	w20, 1404 <append_shared_secret_mpint+0xa0>
    if(append_bytes(p, capacity, offset, &zero, 1) < 0)
    13e0:	91017fe3 	add	x3, sp, #0x5f
    13e4:	aa1803e2 	mov	x2, x24
    13e8:	2a1703e1 	mov	w1, w23
    13ec:	aa1603e0 	mov	x0, x22
    13f0:	52800024 	mov	w4, #0x1                   	// #1
    uchar zero = 0;
    13f4:	39017fff 	strb	wzr, [sp, #95]
    if(append_bytes(p, capacity, offset, &zero, 1) < 0)
    13f8:	97ffff3c 	bl	10e8 <append_bytes>
    13fc:	3100041f 	cmn	w0, #0x1
    1400:	540001c0 	b.eq	1438 <append_shared_secret_mpint+0xd4>  // b.none
  return append_bytes(p, capacity, offset, shared + first, length);
    1404:	8b334323 	add	x3, x25, w19, uxtw
    1408:	2a1503e4 	mov	w4, w21
}
    140c:	f94023f9 	ldr	x25, [sp, #64]
  return append_bytes(p, capacity, offset, shared + first, length);
    1410:	aa1803e2 	mov	x2, x24
}
    1414:	a94153f3 	ldp	x19, x20, [sp, #16]
  return append_bytes(p, capacity, offset, shared + first, length);
    1418:	2a1703e1 	mov	w1, w23
    141c:	aa1603e0 	mov	x0, x22
}
    1420:	a94363f7 	ldp	x23, x24, [sp, #48]
    1424:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1428:	a8c67bfd 	ldp	x29, x30, [sp], #96
  return append_bytes(p, capacity, offset, shared + first, length);
    142c:	17ffff2f 	b	10e8 <append_bytes>
  int zero_prefix = length > 0 && (shared[first] & 0x80);
    1430:	52800014 	mov	w20, #0x0                   	// #0
    1434:	17ffffe3 	b	13c0 <append_shared_secret_mpint+0x5c>
}
    1438:	f94023f9 	ldr	x25, [sp, #64]
    143c:	12800000 	mov	w0, #0xffffffff            	// #-1
    1440:	a94153f3 	ldp	x19, x20, [sp, #16]
    1444:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1448:	a94363f7 	ldp	x23, x24, [sp, #48]
    144c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    1450:	d65f03c0 	ret

0000000000001454 <derive_key>:
{
    1454:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
    1458:	910003fd 	mov	x29, sp
    145c:	a90153f3 	stp	x19, x20, [sp, #16]
    1460:	aa0003f3 	mov	x19, x0
    1464:	2a0103f4 	mov	w20, w1
     append_shared_secret_mpint(encoded, sizeof(encoded), &off, shared) < 0 ||
    1468:	910183e0 	add	x0, sp, #0x60
    146c:	52801001 	mov	w1, #0x80                  	// #128
{
    1470:	a9025bf5 	stp	x21, x22, [sp, #32]
    1474:	aa0303f5 	mov	x21, x3
    1478:	aa0503f6 	mov	x22, x5
     append_shared_secret_mpint(encoded, sizeof(encoded), &off, shared) < 0 ||
    147c:	aa0203e3 	mov	x3, x2
    1480:	9100f3e2 	add	x2, sp, #0x3c
  uchar letter_byte = letter;
    1484:	3900efe4 	strb	w4, [sp, #59]
  int off = 0;
    1488:	b9003fff 	str	wzr, [sp, #60]
     append_shared_secret_mpint(encoded, sizeof(encoded), &off, shared) < 0 ||
    148c:	97ffffb6 	bl	1364 <append_shared_secret_mpint>
  if(length > 32 ||
    1490:	3100041f 	cmn	w0, #0x1
    1494:	54000560 	b.eq	1540 <derive_key+0xec>  // b.none
     append_bytes(encoded, sizeof(encoded), &off, hash, 32) < 0 ||
    1498:	aa1503e3 	mov	x3, x21
    149c:	9100f3e2 	add	x2, sp, #0x3c
    14a0:	910183e0 	add	x0, sp, #0x60
    14a4:	52800404 	mov	w4, #0x20                  	// #32
    14a8:	52801001 	mov	w1, #0x80                  	// #128
    14ac:	97ffff0f 	bl	10e8 <append_bytes>
     append_shared_secret_mpint(encoded, sizeof(encoded), &off, shared) < 0 ||
    14b0:	3100041f 	cmn	w0, #0x1
    14b4:	54000460 	b.eq	1540 <derive_key+0xec>  // b.none
     append_bytes(encoded, sizeof(encoded), &off, &letter_byte, 1) < 0 ||
    14b8:	9100efe3 	add	x3, sp, #0x3b
    14bc:	9100f3e2 	add	x2, sp, #0x3c
    14c0:	910183e0 	add	x0, sp, #0x60
    14c4:	52800024 	mov	w4, #0x1                   	// #1
    14c8:	52801001 	mov	w1, #0x80                  	// #128
    14cc:	97ffff07 	bl	10e8 <append_bytes>
     append_bytes(encoded, sizeof(encoded), &off, hash, 32) < 0 ||
    14d0:	3100041f 	cmn	w0, #0x1
    14d4:	54000360 	b.eq	1540 <derive_key+0xec>  // b.none
     append_bytes(encoded, sizeof(encoded), &off, session_id, 32) < 0 ||
    14d8:	aa1603e3 	mov	x3, x22
    14dc:	9100f3e2 	add	x2, sp, #0x3c
    14e0:	910183e0 	add	x0, sp, #0x60
    14e4:	52800404 	mov	w4, #0x20                  	// #32
    14e8:	52801001 	mov	w1, #0x80                  	// #128
    14ec:	97fffeff 	bl	10e8 <append_bytes>
     append_bytes(encoded, sizeof(encoded), &off, &letter_byte, 1) < 0 ||
    14f0:	3100041f 	cmn	w0, #0x1
    14f4:	54000260 	b.eq	1540 <derive_key+0xec>  // b.none
     ssh_sha256(digest, encoded, off) < 0)
    14f8:	b9803fe2 	ldrsw	x2, [sp, #60]
    14fc:	910183e1 	add	x1, sp, #0x60
    1500:	910103e0 	add	x0, sp, #0x40
    1504:	97fffe33 	bl	dd0 <ssh_sha256@plt>
     append_bytes(encoded, sizeof(encoded), &off, session_id, 32) < 0 ||
    1508:	37f80240 	tbnz	w0, #31, 1550 <derive_key+0xfc>
  memmove(out, digest, length);
    150c:	2a1403e2 	mov	w2, w20
    1510:	910103e1 	add	x1, sp, #0x40
    1514:	aa1303e0 	mov	x0, x19
    1518:	97fffe16 	bl	d70 <memmove@plt>
  memset(encoded, 0, sizeof(encoded));
    151c:	52801002 	mov	w2, #0x80                  	// #128
    1520:	52800001 	mov	w1, #0x0                   	// #0
    1524:	910183e0 	add	x0, sp, #0x60
    1528:	97fffe6e 	bl	ee0 <memset@plt>
  memset(digest, 0, sizeof(digest));
    152c:	910103e0 	add	x0, sp, #0x40
    1530:	52800402 	mov	w2, #0x20                  	// #32
    1534:	52800001 	mov	w1, #0x0                   	// #0
    1538:	97fffe6a 	bl	ee0 <memset@plt>
  return 0;
    153c:	52800000 	mov	w0, #0x0                   	// #0
}
    1540:	a94153f3 	ldp	x19, x20, [sp, #16]
    1544:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1548:	a8ce7bfd 	ldp	x29, x30, [sp], #224
    154c:	d65f03c0 	ret
    return -1;
    1550:	12800000 	mov	w0, #0xffffffff            	// #-1
    1554:	17fffffb 	b	1540 <derive_key+0xec>

0000000000001558 <packet_write>:
{
    1558:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
    155c:	910003fd 	mov	x29, sp
    1560:	a90153f3 	stp	x19, x20, [sp, #16]
    1564:	a9025bf5 	stp	x21, x22, [sp, #32]
    1568:	aa0403f5 	mov	x21, x4
    156c:	a90363f7 	stp	x23, x24, [sp, #48]
  padding = block_size - ((payload_len + 5) % block_size);
    1570:	11001458 	add	w24, w2, #0x5
{
    1574:	a9046bf9 	stp	x25, x26, [sp, #64]
    1578:	aa0303f9 	mov	x25, x3
  block_size = transport->encrypt_out ? 16 : 8;
    157c:	b9400883 	ldr	w3, [x4, #8]
    1580:	52800104 	mov	w4, #0x8                   	// #8
{
    1584:	f9002bfb 	str	x27, [sp, #80]
  block_size = transport->encrypt_out ? 16 : 8;
    1588:	7100007f 	cmp	w3, #0x0
    158c:	52800203 	mov	w3, #0x10                  	// #16
    1590:	1a830084 	csel	w4, w4, w3, eq	// eq = none
  padding = block_size - ((payload_len + 5) % block_size);
    1594:	1ac40f14 	sdiv	w20, w24, w4
    1598:	1b04e294 	msub	w20, w20, w4, w24
    159c:	4b140094 	sub	w20, w4, w20
    padding += block_size;
    15a0:	71000e9f 	cmp	w20, #0x3
    15a4:	1a9fd084 	csel	w4, w4, wzr, le
    15a8:	0b040294 	add	w20, w20, w4
  packet_len = payload_len + padding + 1;
    15ac:	0b02029b 	add	w27, w20, w2
  total = packet_len + 4;
    15b0:	11001777 	add	w23, w27, #0x5
  if(total > SSH_PACKET_MAX || (packet = malloc(total)) == 0)
    15b4:	714006ff 	cmp	w23, #0x1, lsl #12
    15b8:	5400054c 	b.gt	1660 <packet_write+0x108>
    15bc:	aa0103fa 	mov	x26, x1
    15c0:	2a0003f6 	mov	w22, w0
    15c4:	2a1703e0 	mov	w0, w23
    15c8:	b9006fe2 	str	w2, [sp, #108]
    15cc:	97fffdf9 	bl	db0 <malloc@plt>
    15d0:	aa0003f3 	mov	x19, x0
    15d4:	b4000460 	cbz	x0, 1660 <packet_write+0x108>
  memmove(packet + 5, payload, payload_len);
    15d8:	b9406fe2 	ldr	w2, [sp, #108]
  packet_len = payload_len + padding + 1;
    15dc:	11000760 	add	w0, w27, #0x1
    15e0:	5ac00800 	rev	w0, w0
  p[0] = v >> 24;
    15e4:	b9000260 	str	w0, [x19]
  packet[4] = padding;
    15e8:	39001274 	strb	w20, [x19, #4]
  memmove(packet + 5, payload, payload_len);
    15ec:	aa1a03e1 	mov	x1, x26
  if(ssh_random(packet + 5 + payload_len, padding) < 0)
    15f0:	8b38c278 	add	x24, x19, w24, sxtw
  memmove(packet + 5, payload, payload_len);
    15f4:	91001660 	add	x0, x19, #0x5
    15f8:	97fffdde 	bl	d70 <memmove@plt>
  if(ssh_random(packet + 5 + payload_len, padding) < 0)
    15fc:	2a1403e1 	mov	w1, w20
    1600:	aa1803e0 	mov	x0, x24
    1604:	97fffe03 	bl	e10 <ssh_random@plt>
    1608:	36f80160 	tbz	w0, #31, 1634 <packet_write+0xdc>
    160c:	d2800000 	mov	x0, #0x0                   	// #0
  uint32 x = *state;
    1610:	b9400321 	ldr	w1, [x25]
  x ^= x << 13;
    1614:	4a013421 	eor	w1, w1, w1, lsl #13
  x ^= x >> 17;
    1618:	4a414421 	eor	w1, w1, w1, lsr #17
  x ^= x << 5;
    161c:	4a011421 	eor	w1, w1, w1, lsl #5
  *state = x;
    1620:	b9000321 	str	w1, [x25]
      packet[5 + payload_len + i] = prng_next(random);
    1624:	38206b01 	strb	w1, [x24, x0]
    for(int i = 0; i < padding; i++)
    1628:	91000400 	add	x0, x0, #0x1
    162c:	6b00029f 	cmp	w20, w0
    1630:	54ffff0c 	b.gt	1610 <packet_write+0xb8>
  if(transport->encrypt_out){
    1634:	b9400aa0 	ldr	w0, [x21, #8]
    1638:	340007e0 	cbz	w0, 1734 <packet_write+0x1dc>
    put32(mac_input, transport->send_sequence);
    163c:	b94002a0 	ldr	w0, [x21]
    1640:	5ac00800 	rev	w0, w0
  p[0] = v >> 24;
    1644:	b9007be0 	str	w0, [sp, #120]
    uchar *authenticated = malloc(4 + total);
    1648:	11002760 	add	w0, w27, #0x9
    164c:	97fffdd9 	bl	db0 <malloc@plt>
    1650:	aa0003f8 	mov	x24, x0
    if(authenticated == 0){
    1654:	b5000180 	cbnz	x0, 1684 <packet_write+0x12c>
      free(packet);
    1658:	aa1303e0 	mov	x0, x19
    165c:	97fffe4d 	bl	f90 <free@plt>
    return -1;
    1660:	12800014 	mov	w20, #0xffffffff            	// #-1
}
    1664:	f9402bfb 	ldr	x27, [sp, #80]
    1668:	2a1403e0 	mov	w0, w20
    166c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1670:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1674:	a94363f7 	ldp	x23, x24, [sp, #48]
    1678:	a9446bf9 	ldp	x25, x26, [sp, #64]
    167c:	a8ca7bfd 	ldp	x29, x30, [sp], #160
    1680:	d65f03c0 	ret
    memmove(authenticated, mac_input, 4);
    1684:	9101e3e1 	add	x1, sp, #0x78
    1688:	52800082 	mov	w2, #0x4                   	// #4
    168c:	97fffdb9 	bl	d70 <memmove@plt>
    memmove(authenticated + 4, packet, total);
    1690:	2a1703e2 	mov	w2, w23
    1694:	aa1303e1 	mov	x1, x19
    1698:	91001300 	add	x0, x24, #0x4
    169c:	97fffdb5 	bl	d70 <memmove@plt>
    if(ssh_hmac_sha256(mac, transport->mac_out, 32,
    16a0:	11002764 	add	w4, w27, #0x9
    16a4:	aa1803e3 	mov	x3, x24
    16a8:	9106e2a1 	add	x1, x21, #0x1b8
    16ac:	910203e0 	add	x0, sp, #0x80
    16b0:	52800402 	mov	w2, #0x20                  	// #32
    16b4:	97fffdc3 	bl	dc0 <ssh_hmac_sha256@plt>
    16b8:	36f80080 	tbz	w0, #31, 16c8 <packet_write+0x170>
      free(authenticated);
    16bc:	aa1803e0 	mov	x0, x24
    16c0:	97fffe34 	bl	f90 <free@plt>
      free(packet);
    16c4:	17ffffe5 	b	1658 <packet_write+0x100>
    free(authenticated);
    16c8:	aa1803e0 	mov	x0, x24
    16cc:	97fffe31 	bl	f90 <free@plt>
    ssh_aes128_ctr_xor(&transport->cipher_out, packet, total);
    16d0:	2a1703e2 	mov	w2, w23
    16d4:	aa1303e1 	mov	x1, x19
    16d8:	910042a0 	add	x0, x21, #0x10
    16dc:	97fffde5 	bl	e70 <ssh_aes128_ctr_xor@plt>
    result = writen(fd, packet, total) < 0 || writen(fd, mac, 32) < 0 ? -1 : 0;
    16e0:	2a1703e2 	mov	w2, w23
    16e4:	aa1303e1 	mov	x1, x19
    16e8:	2a1603e0 	mov	w0, w22
    16ec:	97fffeaf 	bl	11a8 <writen>
    16f0:	2a0003f4 	mov	w20, w0
    16f4:	3100041f 	cmn	w0, #0x1
    16f8:	54000180 	b.eq	1728 <packet_write+0x1d0>  // b.none
    16fc:	910203e1 	add	x1, sp, #0x80
    1700:	2a1603e0 	mov	w0, w22
    1704:	52800402 	mov	w2, #0x20                  	// #32
    1708:	97fffea8 	bl	11a8 <writen>
    170c:	2a0003f4 	mov	w20, w0
    1710:	3100041f 	cmn	w0, #0x1
    1714:	540000a0 	b.eq	1728 <packet_write+0x1d0>  // b.none
    transport->send_sequence++;
    1718:	b94002a0 	ldr	w0, [x21]
    171c:	52800014 	mov	w20, #0x0                   	// #0
    1720:	11000400 	add	w0, w0, #0x1
    1724:	b90002a0 	str	w0, [x21]
  free(packet);
    1728:	aa1303e0 	mov	x0, x19
    172c:	97fffe19 	bl	f90 <free@plt>
  return result;
    1730:	17ffffcd 	b	1664 <packet_write+0x10c>
    result = writen(fd, packet, total);
    1734:	2a1703e2 	mov	w2, w23
    1738:	aa1303e1 	mov	x1, x19
    173c:	2a1603e0 	mov	w0, w22
    1740:	97fffe9a 	bl	11a8 <writen>
  if(result == 0)
    1744:	34fffea0 	cbz	w0, 1718 <packet_write+0x1c0>
    1748:	12800014 	mov	w20, #0xffffffff            	// #-1
    174c:	17fffff7 	b	1728 <packet_write+0x1d0>

0000000000001750 <send_disconnect>:
{
    1750:	a9ac7bfd 	stp	x29, x30, [sp, #-320]!
    1754:	910003fd 	mov	x29, sp
    1758:	a90153f3 	stp	x19, x20, [sp, #16]
    175c:	2a0003f3 	mov	w19, w0
  payload[off++] = SSH_MSG_DISCONNECT;
    1760:	52800020 	mov	w0, #0x1                   	// #1
{
    1764:	aa0103f4 	mov	x20, x1
  if(append_u32(payload, sizeof(payload), &off,
    1768:	52802001 	mov	w1, #0x100                 	// #256
{
    176c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1770:	aa0203f5 	mov	x21, x2
    1774:	aa0303f6 	mov	x22, x3
  if(append_u32(payload, sizeof(payload), &off,
    1778:	9100f3e2 	add	x2, sp, #0x3c
    177c:	52800063 	mov	w3, #0x3                   	// #3
  payload[off++] = SSH_MSG_DISCONNECT;
    1780:	b9003fe0 	str	w0, [sp, #60]
    1784:	390103e0 	strb	w0, [sp, #64]
  if(append_u32(payload, sizeof(payload), &off,
    1788:	910103e0 	add	x0, sp, #0x40
    178c:	97fffeb9 	bl	1270 <append_u32>
    1790:	3100041f 	cmn	w0, #0x1
    1794:	540002c0 	b.eq	17ec <send_disconnect+0x9c>  // b.none
     append_string(payload, sizeof(payload), &off, description) < 0 ||
    1798:	aa1403e3 	mov	x3, x20
    179c:	9100f3e2 	add	x2, sp, #0x3c
    17a0:	910103e0 	add	x0, sp, #0x40
    17a4:	52802001 	mov	w1, #0x100                 	// #256
    17a8:	97fffebb 	bl	1294 <append_string>
                SSH_DISCONNECT_KEY_EXCHANGE_FAILED) < 0 ||
    17ac:	3100041f 	cmn	w0, #0x1
    17b0:	540001e0 	b.eq	17ec <send_disconnect+0x9c>  // b.none
     append_string(payload, sizeof(payload), &off, "") < 0)
    17b4:	d0000003 	adrp	x3, 3000 <serve_connection+0x8ac>
    17b8:	91147063 	add	x3, x3, #0x51c
    17bc:	9100f3e2 	add	x2, sp, #0x3c
    17c0:	910103e0 	add	x0, sp, #0x40
    17c4:	52802001 	mov	w1, #0x100                 	// #256
    17c8:	97fffeb3 	bl	1294 <append_string>
     append_string(payload, sizeof(payload), &off, description) < 0 ||
    17cc:	3100041f 	cmn	w0, #0x1
    17d0:	540000e0 	b.eq	17ec <send_disconnect+0x9c>  // b.none
  packet_write(fd, payload, off, random, transport);
    17d4:	b9403fe2 	ldr	w2, [sp, #60]
    17d8:	aa1603e4 	mov	x4, x22
    17dc:	aa1503e3 	mov	x3, x21
    17e0:	910103e1 	add	x1, sp, #0x40
    17e4:	2a1303e0 	mov	w0, w19
    17e8:	97ffff5c 	bl	1558 <packet_write>
}
    17ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    17f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    17f4:	a8d47bfd 	ldp	x29, x30, [sp], #320
    17f8:	d65f03c0 	ret

00000000000017fc <send_channel_status>:
{
    17fc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  p[0] = success ? SSH_MSG_CHANNEL_SUCCESS : SSH_MSG_CHANNEL_FAILURE;
    1800:	52800c85 	mov	w5, #0x64                  	// #100
    1804:	4b0100a5 	sub	w5, w5, w1
{
    1808:	910003fd 	mov	x29, sp
    180c:	5ac00842 	rev	w2, w2
  return packet_write(fd, p, sizeof(p), random, transport);
    1810:	910063e1 	add	x1, sp, #0x18
  p[0] = success ? SSH_MSG_CHANNEL_SUCCESS : SSH_MSG_CHANNEL_FAILURE;
    1814:	390063e5 	strb	w5, [sp, #24]
  p[0] = v >> 24;
    1818:	b80193e2 	stur	w2, [sp, #25]
  return packet_write(fd, p, sizeof(p), random, transport);
    181c:	528000a2 	mov	w2, #0x5                   	// #5
    1820:	97ffff4e 	bl	1558 <packet_write>
}
    1824:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1828:	d65f03c0 	ret

000000000000182c <packet_read.constprop.0>:
packet_read(int fd, uchar *payload, int capacity,
    182c:	a9b47bfd 	stp	x29, x30, [sp, #-192]!
    1830:	910003fd 	mov	x29, sp
    1834:	a90153f3 	stp	x19, x20, [sp, #16]
    1838:	aa0203f4 	mov	x20, x2
    183c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1840:	aa0103f6 	mov	x22, x1
    1844:	a90363f7 	stp	x23, x24, [sp, #48]
    1848:	a9046bf9 	stp	x25, x26, [sp, #64]
    184c:	2a0003f9 	mov	w25, w0
  if(transport->encrypt_in){
    1850:	b9400c41 	ldr	w1, [x2, #12]
packet_read(int fd, uchar *payload, int capacity,
    1854:	f9002bfb 	str	x27, [sp, #80]
  if(transport->encrypt_in){
    1858:	34000d21 	cbz	w1, 19fc <packet_read.constprop.0+0x1d0>
    if(readn(fd, header, 16) < 0)
    185c:	9101c3e1 	add	x1, sp, #0x70
    1860:	52800202 	mov	w2, #0x10                  	// #16
    1864:	97fffe6a 	bl	120c <readn>
    1868:	2a0003f3 	mov	w19, w0
    186c:	3100041f 	cmn	w0, #0x1
    1870:	54000d20 	b.eq	1a14 <packet_read.constprop.0+0x1e8>  // b.none
    ssh_aes128_ctr_xor(&transport->cipher_in, header, 16);
    1874:	9101c3e1 	add	x1, sp, #0x70
    1878:	91039280 	add	x0, x20, #0xe4
    187c:	52800202 	mov	w2, #0x10                  	// #16
    1880:	97fffd7c 	bl	e70 <ssh_aes128_ctr_xor@plt>
  packet_len = get32(header);
    1884:	9101c3e0 	add	x0, sp, #0x70
    1888:	97fffde9 	bl	102c <get32>
  total = packet_len + 4;
    188c:	11001017 	add	w23, w0, #0x4
  packet_len = get32(header);
    1890:	2a0003f3 	mov	w19, w0
  if(packet_len < 5 || total > SSH_PACKET_MAX ||
    1894:	714006ff 	cmp	w23, #0x1, lsl #12
    1898:	7a44d800 	ccmp	w0, #0x4, #0x0, le
    189c:	54000ac9 	b.ls	19f4 <packet_read.constprop.0+0x1c8>  // b.plast
     total % (transport->encrypt_in ? 16 : 8) != 0)
    18a0:	b9400e80 	ldr	w0, [x20, #12]
    18a4:	52800218 	mov	w24, #0x10                  	// #16
    18a8:	7100001f 	cmp	w0, #0x0
    18ac:	52800100 	mov	w0, #0x8                   	// #8
    18b0:	1a980000 	csel	w0, w0, w24, eq	// eq = none
    18b4:	1ac00ee1 	sdiv	w1, w23, w0
    18b8:	1b00dc20 	msub	w0, w1, w0, w23
  if(packet_len < 5 || total > SSH_PACKET_MAX ||
    18bc:	350009c0 	cbnz	w0, 19f4 <packet_read.constprop.0+0x1c8>
  if((body = malloc(total)) == 0)
    18c0:	2a1703e0 	mov	w0, w23
    18c4:	97fffd3b 	bl	db0 <malloc@plt>
    18c8:	aa0003f5 	mov	x21, x0
    18cc:	b4000940 	cbz	x0, 19f4 <packet_read.constprop.0+0x1c8>
  memmove(body, header, transport->encrypt_in ? 16 : 4);
    18d0:	b9400e81 	ldr	w1, [x20, #12]
    18d4:	7100003f 	cmp	w1, #0x0
    18d8:	52800081 	mov	w1, #0x4                   	// #4
    18dc:	1a980022 	csel	w2, w1, w24, eq	// eq = none
    18e0:	9101c3e1 	add	x1, sp, #0x70
    18e4:	97fffd23 	bl	d70 <memmove@plt>
  int have = transport->encrypt_in ? 16 : 4;
    18e8:	b9400e80 	ldr	w0, [x20, #12]
    18ec:	7100001f 	cmp	w0, #0x0
    18f0:	52800080 	mov	w0, #0x4                   	// #4
    18f4:	1a980001 	csel	w1, w0, w24, eq	// eq = none
  if(readn(fd, body + have, total - have) < 0)
    18f8:	2a1903e0 	mov	w0, w25
    18fc:	4b0102e2 	sub	w2, w23, w1
    1900:	8b2142a1 	add	x1, x21, w1, uxtw
    1904:	97fffe42 	bl	120c <readn>
    1908:	3100041f 	cmn	w0, #0x1
    190c:	54000700 	b.eq	19ec <packet_read.constprop.0+0x1c0>  // b.none
  if(transport->encrypt_in){
    1910:	b9400e80 	ldr	w0, [x20, #12]
    1914:	34000940 	cbz	w0, 1a3c <packet_read.constprop.0+0x210>
    ssh_aes128_ctr_xor(&transport->cipher_in, body + 16, total - 16);
    1918:	51003262 	sub	w2, w19, #0xc
    191c:	910042a1 	add	x1, x21, #0x10
    1920:	91039280 	add	x0, x20, #0xe4
    if(readn(fd, received_mac, sizeof(received_mac)) < 0)
    1924:	910203f8 	add	x24, sp, #0x80
    ssh_aes128_ctr_xor(&transport->cipher_in, body + 16, total - 16);
    1928:	97fffd52 	bl	e70 <ssh_aes128_ctr_xor@plt>
    if(readn(fd, received_mac, sizeof(received_mac)) < 0)
    192c:	aa1803e1 	mov	x1, x24
    1930:	2a1903e0 	mov	w0, w25
    1934:	52800402 	mov	w2, #0x20                  	// #32
    1938:	97fffe35 	bl	120c <readn>
    193c:	3100041f 	cmn	w0, #0x1
    1940:	54000560 	b.eq	19ec <packet_read.constprop.0+0x1c0>  // b.none
    put32(sequence, transport->receive_sequence);
    1944:	b9400680 	ldr	w0, [x20, #4]
    1948:	5ac00800 	rev	w0, w0
  p[0] = v >> 24;
    194c:	b9006be0 	str	w0, [sp, #104]
    uchar *authenticated = malloc(4 + total);
    1950:	11002260 	add	w0, w19, #0x8
    1954:	97fffd17 	bl	db0 <malloc@plt>
    1958:	aa0003f9 	mov	x25, x0
    if(authenticated == 0)
    195c:	b4000480 	cbz	x0, 19ec <packet_read.constprop.0+0x1c0>
    memmove(authenticated, sequence, 4);
    1960:	9101a3e1 	add	x1, sp, #0x68
    1964:	52800082 	mov	w2, #0x4                   	// #4
    1968:	97fffd02 	bl	d70 <memmove@plt>
    int failed = ssh_hmac_sha256(computed_mac, transport->mac_in, 32,
    196c:	910283fa 	add	x26, sp, #0xa0
    memmove(authenticated + 4, body, total);
    1970:	2a1703e2 	mov	w2, w23
    1974:	aa1503e1 	mov	x1, x21
    1978:	91001320 	add	x0, x25, #0x4
    197c:	97fffcfd 	bl	d70 <memmove@plt>
    int failed = ssh_hmac_sha256(computed_mac, transport->mac_in, 32,
    1980:	11002264 	add	w4, w19, #0x8
    1984:	aa1903e3 	mov	x3, x25
    1988:	91076281 	add	x1, x20, #0x1d8
    198c:	52800402 	mov	w2, #0x20                  	// #32
    1990:	aa1a03e0 	mov	x0, x26
    1994:	97fffd0b 	bl	dc0 <ssh_hmac_sha256@plt>
    1998:	2a0003f7 	mov	w23, w0
    free(authenticated);
    199c:	aa1903e0 	mov	x0, x25
    19a0:	97fffd7c 	bl	f90 <free@plt>
    if(failed == 0)
    19a4:	35000497 	cbnz	w23, 1a34 <packet_read.constprop.0+0x208>
    19a8:	d2800001 	mov	x1, #0x0                   	// #0
    uchar difference = 0;
    19ac:	52800000 	mov	w0, #0x0                   	// #0
        difference |= computed_mac[i] ^ received_mac[i];
    19b0:	38616b42 	ldrb	w2, [x26, x1]
    19b4:	38616b03 	ldrb	w3, [x24, x1]
      for(int i = 0; i < 32; i++)
    19b8:	91000421 	add	x1, x1, #0x1
        difference |= computed_mac[i] ^ received_mac[i];
    19bc:	4a030042 	eor	w2, w2, w3
    19c0:	2a020000 	orr	w0, w0, w2
    19c4:	12001c00 	and	w0, w0, #0xff
      for(int i = 0; i < 32; i++)
    19c8:	f100803f 	cmp	x1, #0x20
    19cc:	54ffff21 	b.ne	19b0 <packet_read.constprop.0+0x184>  // b.any
    if(failed < 0 || difference){
    19d0:	710002ff 	cmp	w23, #0x0
    19d4:	7a40a800 	ccmp	w0, #0x0, #0x0, ge	// ge = tcont
    19d8:	54000320 	b.eq	1a3c <packet_read.constprop.0+0x210>  // b.none
      printf("sshd: encrypted packet MAC failure seq=%d\n",
    19dc:	b9400681 	ldr	w1, [x20, #4]
    19e0:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    19e4:	910a8000 	add	x0, x0, #0x2a0
    19e8:	97fffcda 	bl	d50 <printf@plt>
  free(body);
    19ec:	aa1503e0 	mov	x0, x21
    19f0:	97fffd68 	bl	f90 <free@plt>
      return -1;
    19f4:	12800013 	mov	w19, #0xffffffff            	// #-1
    19f8:	14000007 	b	1a14 <packet_read.constprop.0+0x1e8>
  } else if(readn(fd, header, 4) < 0){
    19fc:	9101c3e1 	add	x1, sp, #0x70
    1a00:	52800082 	mov	w2, #0x4                   	// #4
    1a04:	97fffe02 	bl	120c <readn>
    1a08:	2a0003f3 	mov	w19, w0
    1a0c:	3100041f 	cmn	w0, #0x1
    1a10:	54fff3a1 	b.ne	1884 <packet_read.constprop.0+0x58>  // b.any
}
    1a14:	f9402bfb 	ldr	x27, [sp, #80]
    1a18:	2a1303e0 	mov	w0, w19
    1a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1a20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1a24:	a94363f7 	ldp	x23, x24, [sp, #48]
    1a28:	a9446bf9 	ldp	x25, x26, [sp, #64]
    1a2c:	a8cc7bfd 	ldp	x29, x30, [sp], #192
    1a30:	d65f03c0 	ret
    uchar difference = 0;
    1a34:	52800000 	mov	w0, #0x0                   	// #0
    1a38:	17ffffe6 	b	19d0 <packet_read.constprop.0+0x1a4>
  padding = body[4];
    1a3c:	394012a0 	ldrb	w0, [x21, #4]
  payload_len = packet_len - padding - 1;
    1a40:	4b000273 	sub	w19, w19, w0
  if(padding < 4 || payload_len <= 0 || payload_len > capacity){
    1a44:	51000a61 	sub	w1, w19, #0x2
    1a48:	713ffc3f 	cmp	w1, #0xfff
    1a4c:	7a439800 	ccmp	w0, #0x3, #0x0, ls	// ls = plast
    1a50:	54fffce9 	b.ls	19ec <packet_read.constprop.0+0x1c0>  // b.plast
  payload_len = packet_len - padding - 1;
    1a54:	51000673 	sub	w19, w19, #0x1
  memmove(payload, body + 5, payload_len);
    1a58:	910016a1 	add	x1, x21, #0x5
    1a5c:	2a1303e2 	mov	w2, w19
    1a60:	aa1603e0 	mov	x0, x22
    1a64:	97fffcc3 	bl	d70 <memmove@plt>
  transport->receive_sequence++;
    1a68:	b9400680 	ldr	w0, [x20, #4]
    1a6c:	11000400 	add	w0, w0, #0x1
    1a70:	b9000680 	str	w0, [x20, #4]
  free(body);
    1a74:	aa1503e0 	mov	x0, x21
    1a78:	97fffd46 	bl	f90 <free@plt>
  return payload_len;
    1a7c:	17ffffe6 	b	1a14 <packet_read.constprop.0+0x1e8>

0000000000001a80 <channel_session>:
{
    1a80:	a9ac7bfd 	stp	x29, x30, [sp, #-320]!
    1a84:	910003fd 	mov	x29, sp
    1a88:	a90153f3 	stp	x19, x20, [sp, #16]
    1a8c:	2a0003f4 	mov	w20, w0
    1a90:	aa0103f3 	mov	x19, x1
    1a94:	a9025bf5 	stp	x21, x22, [sp, #32]
    1a98:	aa0203f6 	mov	x22, x2
    1a9c:	aa0303f5 	mov	x21, x3
  int n = packet_read(fd, payload, SSH_PACKET_MAX, transport), off = 1;
    1aa0:	aa0303e2 	mov	x2, x3
{
    1aa4:	a90363f7 	stp	x23, x24, [sp, #48]
    1aa8:	a9046bf9 	stp	x25, x26, [sp, #64]
    1aac:	aa0403fa 	mov	x26, x4
    1ab0:	a90573fb 	stp	x27, x28, [sp, #80]
    1ab4:	f9003fe5 	str	x5, [sp, #120]
  int n = packet_read(fd, payload, SSH_PACKET_MAX, transport), off = 1;
    1ab8:	97ffff5d 	bl	182c <packet_read.constprop.0>
    1abc:	2a0003ea 	mov	w10, w0
    1ac0:	52800020 	mov	w0, #0x1                   	// #1
    1ac4:	b900a7e0 	str	w0, [sp, #164]
  if(n < 1 || payload[0] != SSH_MSG_CHANNEL_OPEN ||
    1ac8:	7100015f 	cmp	w10, #0x0
    1acc:	540000cc 	b.gt	1ae4 <channel_session+0x64>
    printf("sshd: expected session channel open\n");
    1ad0:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1ad4:	910b2c00 	add	x0, x0, #0x2cb
    1ad8:	97fffc9e 	bl	d50 <printf@plt>
      return -1;
    1adc:	12800017 	mov	w23, #0xffffffff            	// #-1
    1ae0:	14000103 	b	1eec <channel_session+0x46c>
  if(n < 1 || payload[0] != SSH_MSG_CHANNEL_OPEN ||
    1ae4:	39400260 	ldrb	w0, [x19]
    1ae8:	7101681f 	cmp	w0, #0x5a
    1aec:	54ffff21 	b.ne	1ad0 <channel_session+0x50>  // b.any
     parse_string(payload, n, &off, &type, &type_len) < 0 ||
    1af0:	9102a3e4 	add	x4, sp, #0xa8
    1af4:	910343e3 	add	x3, sp, #0xd0
    1af8:	910293e2 	add	x2, sp, #0xa4
    1afc:	2a0a03e1 	mov	w1, w10
    1b00:	aa1303e0 	mov	x0, x19
    1b04:	97fffd5f 	bl	1080 <parse_string>
  if(n < 1 || payload[0] != SSH_MSG_CHANNEL_OPEN ||
    1b08:	3100041f 	cmn	w0, #0x1
    1b0c:	54fffe20 	b.eq	1ad0 <channel_session+0x50>  // b.none
     parse_u32(payload, n, &off, &remote_channel) < 0 ||
    1b10:	9102b3e3 	add	x3, sp, #0xac
    1b14:	910293e2 	add	x2, sp, #0xa4
    1b18:	2a0a03e1 	mov	w1, w10
    1b1c:	aa1303e0 	mov	x0, x19
    1b20:	97fffd46 	bl	1038 <parse_u32>
     parse_string(payload, n, &off, &type, &type_len) < 0 ||
    1b24:	3100041f 	cmn	w0, #0x1
    1b28:	54fffd40 	b.eq	1ad0 <channel_session+0x50>  // b.none
     parse_u32(payload, n, &off, &remote_window) < 0 ||
    1b2c:	9102c3e3 	add	x3, sp, #0xb0
    1b30:	aa1303e0 	mov	x0, x19
    1b34:	97fffd41 	bl	1038 <parse_u32>
     parse_u32(payload, n, &off, &remote_channel) < 0 ||
    1b38:	3100041f 	cmn	w0, #0x1
    1b3c:	54fffca0 	b.eq	1ad0 <channel_session+0x50>  // b.none
     parse_u32(payload, n, &off, &remote_max_packet) < 0 || off != n ||
    1b40:	9102d3e3 	add	x3, sp, #0xb4
    1b44:	aa1303e0 	mov	x0, x19
    1b48:	97fffd3c 	bl	1038 <parse_u32>
     parse_u32(payload, n, &off, &remote_window) < 0 ||
    1b4c:	3100041f 	cmn	w0, #0x1
    1b50:	54fffc00 	b.eq	1ad0 <channel_session+0x50>  // b.none
     parse_u32(payload, n, &off, &remote_max_packet) < 0 || off != n ||
    1b54:	b940a7e0 	ldr	w0, [sp, #164]
    1b58:	6b0a001f 	cmp	w0, w10
    1b5c:	54fffba1 	b.ne	1ad0 <channel_session+0x50>  // b.any
     remote_max_packet == 0 ||
    1b60:	b940b7e0 	ldr	w0, [sp, #180]
    1b64:	b90083e0 	str	w0, [sp, #128]
     parse_u32(payload, n, &off, &remote_max_packet) < 0 || off != n ||
    1b68:	34fffb40 	cbz	w0, 1ad0 <channel_session+0x50>
     !string_is(type, type_len, "session")){
    1b6c:	f9406be0 	ldr	x0, [sp, #208]
    1b70:	d0000002 	adrp	x2, 3000 <serve_connection+0x8ac>
    1b74:	910bc042 	add	x2, x2, #0x2f0
    1b78:	b940abe1 	ldr	w1, [sp, #168]
    1b7c:	97fffd75 	bl	1150 <string_is>
     remote_max_packet == 0 ||
    1b80:	34fffa80 	cbz	w0, 1ad0 <channel_session+0x50>
  p[0] = v >> 24;
    1b84:	910427e1 	add	x1, sp, #0x109
    1b88:	b940aff8 	ldr	w24, [sp, #172]
  confirmation[0] = SSH_MSG_CHANNEL_OPEN_CONFIRMATION;
    1b8c:	52800b60 	mov	w0, #0x5b                  	// #91
    1b90:	390423e0 	strb	w0, [sp, #264]
  put32(confirmation + 1, remote_channel);
    1b94:	5ac00b00 	rev	w0, w24
    1b98:	b90093e0 	str	w0, [sp, #144]
  p[0] = v >> 24;
    1b9c:	b9000020 	str	w0, [x1]
    1ba0:	910437e1 	add	x1, sp, #0x10d
    1ba4:	d2c02000 	mov	x0, #0x10000000000         	// #1099511627776
  if(packet_write(fd, confirmation, sizeof(confirmation), random, transport) < 0)
    1ba8:	aa1503e4 	mov	x4, x21
    1bac:	aa1603e3 	mov	x3, x22
    1bb0:	52800222 	mov	w2, #0x11                  	// #17
  p[0] = v >> 24;
    1bb4:	f9000020 	str	x0, [x1]
    1bb8:	910457e1 	add	x1, sp, #0x115
    1bbc:	52a00100 	mov	w0, #0x80000               	// #524288
    1bc0:	b9000020 	str	w0, [x1]
  if(packet_write(fd, confirmation, sizeof(confirmation), random, transport) < 0)
    1bc4:	910423e1 	add	x1, sp, #0x108
    1bc8:	2a1403e0 	mov	w0, w20
    1bcc:	97fffe63 	bl	1558 <packet_write>
    1bd0:	2a0003f7 	mov	w23, w0
    1bd4:	3100041f 	cmn	w0, #0x1
    1bd8:	540018a0 	b.eq	1eec <channel_session+0x46c>  // b.none
  printf("sshd: session channel opened local=%d remote=%d\n",
    1bdc:	2a1803e2 	mov	w2, w24
    1be0:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1be4:	910be000 	add	x0, x0, #0x2f8
    1be8:	52800001 	mov	w1, #0x0                   	// #0
    1bec:	97fffc59 	bl	d50 <printf@plt>
    off = 1;
    1bf0:	5280003c 	mov	w28, #0x1                   	// #1
    if(string_is(request, request_len, "pty-req")){
    1bf4:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1bf8:	910ca400 	add	x0, x0, #0x329
    1bfc:	f90037e0 	str	x0, [sp, #104]
    } else if(string_is(request, request_len, "shell") && off == n){
    1c00:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1c04:	910d3400 	add	x0, x0, #0x34d
    1c08:	f9003be0 	str	x0, [sp, #112]
    n = packet_read(fd, payload, SSH_PACKET_MAX, transport);
    1c0c:	aa1503e2 	mov	x2, x21
    1c10:	aa1303e1 	mov	x1, x19
    1c14:	2a1403e0 	mov	w0, w20
    1c18:	97ffff05 	bl	182c <packet_read.constprop.0>
    off = 1;
    1c1c:	b900a7fc 	str	w28, [sp, #164]
    n = packet_read(fd, payload, SSH_PACKET_MAX, transport);
    1c20:	2a0003f9 	mov	w25, w0
    if(n < 1)
    1c24:	7100001f 	cmp	w0, #0x0
    1c28:	54fff5ad 	b.le	1adc <channel_session+0x5c>
    if(payload[0] == SSH_MSG_CHANNEL_CLOSE)
    1c2c:	39400260 	ldrb	w0, [x19]
    1c30:	7101841f 	cmp	w0, #0x61
    1c34:	54003640 	b.eq	22fc <channel_session+0x87c>  // b.none
    if(payload[0] != SSH_MSG_CHANNEL_REQUEST ||
    1c38:	7101881f 	cmp	w0, #0x62
    1c3c:	54fff501 	b.ne	1adc <channel_session+0x5c>  // b.any
       parse_u32(payload, n, &off, &recipient) < 0 ||
    1c40:	9102e3e3 	add	x3, sp, #0xb8
    1c44:	910293e2 	add	x2, sp, #0xa4
    1c48:	2a1903e1 	mov	w1, w25
    1c4c:	aa1303e0 	mov	x0, x19
    1c50:	97fffcfa 	bl	1038 <parse_u32>
    1c54:	2a0003f7 	mov	w23, w0
    if(payload[0] != SSH_MSG_CHANNEL_REQUEST ||
    1c58:	3100041f 	cmn	w0, #0x1
    1c5c:	54001480 	b.eq	1eec <channel_session+0x46c>  // b.none
       parse_string(payload, n, &off, &request, &request_len) < 0 ||
    1c60:	9102f3e4 	add	x4, sp, #0xbc
    1c64:	910363e3 	add	x3, sp, #0xd8
    1c68:	aa1303e0 	mov	x0, x19
    1c6c:	97fffd05 	bl	1080 <parse_string>
    1c70:	2a0003f7 	mov	w23, w0
       parse_u32(payload, n, &off, &recipient) < 0 ||
    1c74:	3100041f 	cmn	w0, #0x1
    1c78:	540013a0 	b.eq	1eec <channel_session+0x46c>  // b.none
       off >= n || recipient != local_channel)
    1c7c:	b940a7e0 	ldr	w0, [sp, #164]
       parse_string(payload, n, &off, &request, &request_len) < 0 ||
    1c80:	6b19001f 	cmp	w0, w25
    1c84:	54fff2ca 	b.ge	1adc <channel_session+0x5c>  // b.tcont
       off >= n || recipient != local_channel)
    1c88:	b940bbe1 	ldr	w1, [sp, #184]
    1c8c:	35fff281 	cbnz	w1, 1adc <channel_session+0x5c>
    if(string_is(request, request_len, "pty-req")){
    1c90:	f94037e2 	ldr	x2, [sp, #104]
    int want_reply = payload[off++] != 0;
    1c94:	1100041b 	add	w27, w0, #0x1
    if(string_is(request, request_len, "pty-req")){
    1c98:	f9406fe3 	ldr	x3, [sp, #216]
    1c9c:	f90047e3 	str	x3, [sp, #136]
    1ca0:	b940bfe1 	ldr	w1, [sp, #188]
    int want_reply = payload[off++] != 0;
    1ca4:	3860ca77 	ldrb	w23, [x19, w0, sxtw]
    if(string_is(request, request_len, "pty-req")){
    1ca8:	aa0303e0 	mov	x0, x3
    1cac:	b90097e1 	str	w1, [sp, #148]
    int want_reply = payload[off++] != 0;
    1cb0:	b900a7fb 	str	w27, [sp, #164]
    if(string_is(request, request_len, "pty-req")){
    1cb4:	97fffd27 	bl	1150 <string_is>
    1cb8:	b90087e0 	str	w0, [sp, #132]
    1cbc:	b94097e1 	ldr	w1, [sp, #148]
    1cc0:	34000620 	cbz	w0, 1d84 <channel_session+0x304>
      int valid = parse_string(payload, n, &off, &term, &term_len) == 0 &&
    1cc4:	910303e4 	add	x4, sp, #0xc0
    1cc8:	9103e3e3 	add	x3, sp, #0xf8
    1ccc:	910293e2 	add	x2, sp, #0xa4
    1cd0:	2a1903e1 	mov	w1, w25
    1cd4:	aa1303e0 	mov	x0, x19
    1cd8:	97fffcea 	bl	1080 <parse_string>
                  parse_string(payload, n, &off, &modes, &modes_len) == 0 &&
    1cdc:	35003140 	cbnz	w0, 2304 <channel_session+0x884>
                  parse_u32(payload, n, &off, &columns) == 0 &&
    1ce0:	910313e3 	add	x3, sp, #0xc4
    1ce4:	910293e2 	add	x2, sp, #0xa4
    1ce8:	2a1903e1 	mov	w1, w25
    1cec:	aa1303e0 	mov	x0, x19
    1cf0:	97fffcd2 	bl	1038 <parse_u32>
      int valid = parse_string(payload, n, &off, &term, &term_len) == 0 &&
    1cf4:	35003080 	cbnz	w0, 2304 <channel_session+0x884>
                  parse_u32(payload, n, &off, &rows) == 0 &&
    1cf8:	910323e3 	add	x3, sp, #0xc8
    1cfc:	aa1303e0 	mov	x0, x19
    1d00:	97fffcce 	bl	1038 <parse_u32>
                  parse_u32(payload, n, &off, &columns) == 0 &&
    1d04:	35003000 	cbnz	w0, 2304 <channel_session+0x884>
                  parse_u32(payload, n, &off, &width) == 0 &&
    1d08:	910333e3 	add	x3, sp, #0xcc
    1d0c:	aa1303e0 	mov	x0, x19
    1d10:	97fffcca 	bl	1038 <parse_u32>
                  parse_u32(payload, n, &off, &rows) == 0 &&
    1d14:	35002f80 	cbnz	w0, 2304 <channel_session+0x884>
                  parse_u32(payload, n, &off, &height) == 0 &&
    1d18:	910383e3 	add	x3, sp, #0xe0
    1d1c:	aa1303e0 	mov	x0, x19
    1d20:	97fffcc6 	bl	1038 <parse_u32>
                  parse_u32(payload, n, &off, &width) == 0 &&
    1d24:	35002f00 	cbnz	w0, 2304 <channel_session+0x884>
                  parse_string(payload, n, &off, &modes, &modes_len) == 0 &&
    1d28:	9103a3e4 	add	x4, sp, #0xe8
    1d2c:	910483e3 	add	x3, sp, #0x120
    1d30:	aa1303e0 	mov	x0, x19
    1d34:	97fffcd3 	bl	1080 <parse_string>
                  parse_u32(payload, n, &off, &height) == 0 &&
    1d38:	35002e60 	cbnz	w0, 2304 <channel_session+0x884>
                  parse_string(payload, n, &off, &modes, &modes_len) == 0 &&
    1d3c:	b940a7e0 	ldr	w0, [sp, #164]
    1d40:	6b19001f 	cmp	w0, w25
    1d44:	1a9f17f9 	cset	w25, eq	// eq = none
      if(want_reply && send_channel_status(fd, valid, remote_channel, random,
    1d48:	34000157 	cbz	w23, 1d70 <channel_session+0x2f0>
    1d4c:	aa1503e4 	mov	x4, x21
    1d50:	aa1603e3 	mov	x3, x22
    1d54:	2a1803e2 	mov	w2, w24
    1d58:	2a1903e1 	mov	w1, w25
    1d5c:	2a1403e0 	mov	w0, w20
    1d60:	97fffea7 	bl	17fc <send_channel_status>
    1d64:	2a0003f7 	mov	w23, w0
    1d68:	3100041f 	cmn	w0, #0x1
    1d6c:	54000c00 	b.eq	1eec <channel_session+0x46c>  // b.none
      if(valid)
    1d70:	34fff4f9 	cbz	w25, 1c0c <channel_session+0x18c>
        printf("sshd: PTY request accepted\n");
    1d74:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1d78:	910cc400 	add	x0, x0, #0x331
    1d7c:	97fffbf5 	bl	d50 <printf@plt>
    1d80:	17ffffa3 	b	1c0c <channel_session+0x18c>
    } else if(string_is(request, request_len, "shell") && off == n){
    1d84:	f9403be2 	ldr	x2, [sp, #112]
    1d88:	f94047e0 	ldr	x0, [sp, #136]
    1d8c:	97fffcf1 	bl	1150 <string_is>
    1d90:	34002a00 	cbz	w0, 22d0 <channel_session+0x850>
    1d94:	6b19037f 	cmp	w27, w25
    1d98:	540029c1 	b.ne	22d0 <channel_session+0x850>  // b.any
      if(pty_open(pty_fd) < 0){
    1d9c:	910383e0 	add	x0, sp, #0xe0
    1da0:	97fffc5c 	bl	f10 <pty_open@plt>
    1da4:	36f80120 	tbz	w0, #31, 1dc8 <channel_session+0x348>
        if(want_reply)
    1da8:	34ffe9b7 	cbz	w23, 1adc <channel_session+0x5c>
          send_channel_status(fd, 0, remote_channel, random, transport);
    1dac:	aa1503e4 	mov	x4, x21
    1db0:	aa1603e3 	mov	x3, x22
    1db4:	2a1803e2 	mov	w2, w24
    1db8:	2a1403e0 	mov	w0, w20
    1dbc:	52800001 	mov	w1, #0x0                   	// #0
    1dc0:	97fffe8f 	bl	17fc <send_channel_status>
    1dc4:	17ffff46 	b	1adc <channel_session+0x5c>
  int pid = fork();
    1dc8:	97fffc3a 	bl	eb0 <fork@plt>
    1dcc:	b9006be0 	str	w0, [sp, #104]
  if(pid != 0)
    1dd0:	7100001f 	cmp	w0, #0x0
    1dd4:	340000e0 	cbz	w0, 1df0 <channel_session+0x370>
      if(child < 0){
    1dd8:	5400066a 	b.ge	1ea4 <channel_session+0x424>  // b.tcont
        close(pty_fd[0]);
    1ddc:	b940e3e0 	ldr	w0, [sp, #224]
    1de0:	97fffc68 	bl	f80 <close@plt>
        close(pty_fd[1]);
    1de4:	b940e7e0 	ldr	w0, [sp, #228]
    1de8:	97fffc66 	bl	f80 <close@plt>
        return -1;
    1dec:	17ffff3c 	b	1adc <channel_session+0x5c>
  close(pty_fd[0]);
    1df0:	b940e3e0 	ldr	w0, [sp, #224]
    1df4:	97fffc63 	bl	f80 <close@plt>
  close(network_fd);
    1df8:	2a1403e0 	mov	w0, w20
    1dfc:	97fffc61 	bl	f80 <close@plt>
  if(ssh_listener >= 0)
    1e00:	f0000000 	adrp	x0, 4000 <serve_connection+0x18ac>
    1e04:	b94b9000 	ldr	w0, [x0, #2960]
    1e08:	37f80040 	tbnz	w0, #31, 1e10 <channel_session+0x390>
    close(ssh_listener);
    1e0c:	97fffc5d 	bl	f80 <close@plt>
  close(0);
    1e10:	52800000 	mov	w0, #0x0                   	// #0
    1e14:	97fffc5b 	bl	f80 <close@plt>
  dup(pty_fd[1]);
    1e18:	b940e7e0 	ldr	w0, [sp, #228]
    1e1c:	97fffc39 	bl	f00 <dup@plt>
  close(1);
    1e20:	52800020 	mov	w0, #0x1                   	// #1
    1e24:	97fffc57 	bl	f80 <close@plt>
  dup(pty_fd[1]);
    1e28:	b940e7e0 	ldr	w0, [sp, #228]
    1e2c:	97fffc35 	bl	f00 <dup@plt>
  close(2);
    1e30:	52800040 	mov	w0, #0x2                   	// #2
    1e34:	97fffc53 	bl	f80 <close@plt>
  dup(pty_fd[1]);
    1e38:	b940e7e0 	ldr	w0, [sp, #228]
    1e3c:	97fffc31 	bl	f00 <dup@plt>
  if(pty_fd[1] > 2)
    1e40:	b940e7e0 	ldr	w0, [sp, #228]
    1e44:	7100081f 	cmp	w0, #0x2
    1e48:	5400004d 	b.le	1e50 <channel_session+0x3d0>
    close(pty_fd[1]);
    1e4c:	97fffc4d 	bl	f80 <close@plt>
  if(home[0] && chdir(home) < 0)
    1e50:	39400340 	ldrb	w0, [x26]
    1e54:	340000e0 	cbz	w0, 1e70 <channel_session+0x3f0>
    1e58:	aa1a03e0 	mov	x0, x26
    1e5c:	97fffbf1 	bl	e20 <chdir@plt>
    1e60:	36f80080 	tbz	w0, #31, 1e70 <channel_session+0x3f0>
    chdir("/");
    1e64:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1e68:	910d4c00 	add	x0, x0, #0x353
    1e6c:	97fffbed 	bl	e20 <chdir@plt>
  char *argv[] = { "-sh", home, 0 };
    1e70:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1e74:	910d5400 	add	x0, x0, #0x355
    1e78:	a9126be0 	stp	x0, x26, [sp, #288]
  exec(shell, argv);
    1e7c:	910483e1 	add	x1, sp, #0x120
    1e80:	f9403fe0 	ldr	x0, [sp, #120]
  char *argv[] = { "-sh", home, 0 };
    1e84:	f9009bff 	str	xzr, [sp, #304]
  exec(shell, argv);
    1e88:	97fffbee 	bl	e40 <exec@plt>
  exec("/bin/sh", argv);
    1e8c:	910483e1 	add	x1, sp, #0x120
    1e90:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1e94:	910d6400 	add	x0, x0, #0x359
    1e98:	97fffbea 	bl	e40 <exec@plt>
  exit(127);
    1e9c:	52800fe0 	mov	w0, #0x7f                  	// #127
    1ea0:	97fffc20 	bl	f20 <exit@plt>
      close(pty_fd[1]);
    1ea4:	b940e7e0 	ldr	w0, [sp, #228]
    1ea8:	97fffc36 	bl	f80 <close@plt>
      if(want_reply && send_channel_status(fd, 1, remote_channel, random,
    1eac:	34000317 	cbz	w23, 1f0c <channel_session+0x48c>
    1eb0:	aa1503e4 	mov	x4, x21
    1eb4:	aa1603e3 	mov	x3, x22
    1eb8:	2a1803e2 	mov	w2, w24
    1ebc:	2a1403e0 	mov	w0, w20
    1ec0:	52800021 	mov	w1, #0x1                   	// #1
    1ec4:	97fffe4e 	bl	17fc <send_channel_status>
    1ec8:	2a0003f7 	mov	w23, w0
    1ecc:	3100041f 	cmn	w0, #0x1
    1ed0:	540001e1 	b.ne	1f0c <channel_session+0x48c>  // b.any
        close(pty_fd[0]);
    1ed4:	b940e3e0 	ldr	w0, [sp, #224]
    1ed8:	97fffc2a 	bl	f80 <close@plt>
        kill(child);
    1edc:	b9406be0 	ldr	w0, [sp, #104]
    1ee0:	97fffbc8 	bl	e00 <kill@plt>
        wait(0);
    1ee4:	d2800000 	mov	x0, #0x0                   	// #0
    1ee8:	97fffbda 	bl	e50 <wait@plt>
}
    1eec:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ef0:	2a1703e0 	mov	w0, w23
    1ef4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1ef8:	a94363f7 	ldp	x23, x24, [sp, #48]
    1efc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    1f00:	a94573fb 	ldp	x27, x28, [sp, #80]
    1f04:	a8d47bfd 	ldp	x29, x30, [sp], #320
    1f08:	d65f03c0 	ret
      printf("sshd: PTY shell started pid=%d\n", child);
    1f0c:	b9406be1 	ldr	w1, [sp, #104]
    1f10:	d0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    1f14:	910d8400 	add	x0, x0, #0x361
    1f18:	97fffb8e 	bl	d50 <printf@plt>
      int result = relay_shell(fd, pty_fd[0], child, local_channel,
    1f1c:	b940b3f7 	ldr	w23, [sp, #176]
    1f20:	b940e3fa 	ldr	w26, [sp, #224]
  uchar *terminal = malloc(SSH_CHANNEL_PACKET);
    1f24:	52810000 	mov	w0, #0x800                 	// #2048
    1f28:	97fffba2 	bl	db0 <malloc@plt>
    1f2c:	aa0003f9 	mov	x25, x0
  if(terminal == 0)
    1f30:	b50000e0 	cbnz	x0, 1f4c <channel_session+0x4cc>
    return -1;
    1f34:	12800000 	mov	w0, #0xffffffff            	// #-1
    1f38:	b90087e0 	str	w0, [sp, #132]
      close(pty_fd[0]);
    1f3c:	b940e3e0 	ldr	w0, [sp, #224]
    1f40:	97fffc10 	bl	f80 <close@plt>
      return result;
    1f44:	b94087f7 	ldr	w23, [sp, #132]
    1f48:	17ffffe9 	b	1eec <channel_session+0x46c>
  int epfd = epoll_create();
    1f4c:	97fffbd1 	bl	e90 <epoll_create@plt>
    1f50:	b90073e0 	str	w0, [sp, #112]
  if(epfd < 0){
    1f54:	36f80080 	tbz	w0, #31, 1f64 <channel_session+0x4e4>
  free(terminal);
    1f58:	aa1903e0 	mov	x0, x25
    1f5c:	97fffc0d 	bl	f90 <free@plt>
  return -1;
    1f60:	17fffff5 	b	1f34 <channel_session+0x4b4>
  event.events = EPOLLIN;
    1f64:	5280003c 	mov	w28, #0x1                   	// #1
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event) < 0)
    1f68:	9103e3e3 	add	x3, sp, #0xf8
    1f6c:	2a1403e2 	mov	w2, w20
    1f70:	2a1c03e1 	mov	w1, w28
  event.events = EPOLLIN;
    1f74:	b900fbfc 	str	w28, [sp, #248]
  event.data.fd = fd;
    1f78:	b90103f4 	str	w20, [sp, #256]
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event) < 0)
    1f7c:	97fffb99 	bl	de0 <epoll_ctl@plt>
    1f80:	37f81a20 	tbnz	w0, #31, 22c4 <channel_session+0x844>
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, master, &event) < 0)
    1f84:	b94073e0 	ldr	w0, [sp, #112]
    1f88:	9103e3e3 	add	x3, sp, #0xf8
    1f8c:	2a1a03e2 	mov	w2, w26
    1f90:	2a1c03e1 	mov	w1, w28
  event.data.fd = master;
    1f94:	b90103fa 	str	w26, [sp, #256]
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, master, &event) < 0)
    1f98:	97fffb92 	bl	de0 <epoll_ctl@plt>
    1f9c:	37f81940 	tbnz	w0, #31, 22c4 <channel_session+0x844>
  p[off++] = SSH_MSG_CHANNEL_DATA;
    1fa0:	b9009bfc 	str	w28, [sp, #152]
    int ready = epoll_wait(epfd, events, 2, -1);
    1fa4:	b94073e0 	ldr	w0, [sp, #112]
    1fa8:	910483e1 	add	x1, sp, #0x120
    1fac:	12800003 	mov	w3, #0xffffffff            	// #-1
    1fb0:	52800042 	mov	w2, #0x2                   	// #2
    1fb4:	97fffb6b 	bl	d60 <epoll_wait@plt>
    1fb8:	b90097e0 	str	w0, [sp, #148]
    if(ready < 0)
    1fbc:	37f81640 	tbnz	w0, #31, 2284 <channel_session+0x804>
    1fc0:	910483e0 	add	x0, sp, #0x120
    1fc4:	f9003fe0 	str	x0, [sp, #120]
    for(int i = 0; i < ready; i++){
    1fc8:	b9008bff 	str	wzr, [sp, #136]
    1fcc:	b9408be1 	ldr	w1, [sp, #136]
    1fd0:	b94097e0 	ldr	w0, [sp, #148]
    1fd4:	6b01001f 	cmp	w0, w1
    1fd8:	54fffe60 	b.eq	1fa4 <channel_session+0x524>  // b.none
      if(events[i].data.fd == fd){
    1fdc:	f9403fe0 	ldr	x0, [sp, #120]
    1fe0:	b940081c 	ldr	w28, [x0, #8]
    1fe4:	6b1c029f 	cmp	w20, w28
    1fe8:	54000d21 	b.ne	218c <channel_session+0x70c>  // b.any
        int n = packet_read(fd, payload, SSH_PACKET_MAX, transport);
    1fec:	aa1503e2 	mov	x2, x21
    1ff0:	aa1303e1 	mov	x1, x19
    1ff4:	2a1403e0 	mov	w0, w20
    1ff8:	97fffe0d 	bl	182c <packet_read.constprop.0>
    1ffc:	2a0003e2 	mov	w2, w0
        if(n < 1)
    2000:	7100001f 	cmp	w0, #0x0
    2004:	5400076d 	b.le	20f0 <channel_session+0x670>
        if(payload[0] == SSH_MSG_CHANNEL_WINDOW_ADJUST && n == 9 &&
    2008:	39400261 	ldrb	w1, [x19]
    200c:	7101743f 	cmp	w1, #0x5d
    2010:	54000281 	b.ne	2060 <channel_session+0x5e0>  // b.any
    2014:	7100241f 	cmp	w0, #0x9
    2018:	54000121 	b.ne	203c <channel_session+0x5bc>  // b.any
           get32(payload + 1) == local_channel){
    201c:	91000660 	add	x0, x19, #0x1
    2020:	97fffc03 	bl	102c <get32>
        if(payload[0] == SSH_MSG_CHANNEL_WINDOW_ADJUST && n == 9 &&
    2024:	350000c0 	cbnz	w0, 203c <channel_session+0x5bc>
          uint32 added = get32(payload + 5);
    2028:	91001660 	add	x0, x19, #0x5
    202c:	97fffc00 	bl	102c <get32>
          if(0xffffffffU - remote_window < added)
    2030:	2b0002e1 	adds	w1, w23, w0
    2034:	54000122 	b.cs	2058 <channel_session+0x5d8>  // b.hs, b.nlast
            remote_window += added;
    2038:	2a0103f7 	mov	w23, w1
    for(int i = 0; i < ready; i++){
    203c:	b9408be0 	ldr	w0, [sp, #136]
    2040:	11000400 	add	w0, w0, #0x1
    2044:	b9008be0 	str	w0, [sp, #136]
    2048:	f9403fe0 	ldr	x0, [sp, #120]
    204c:	91004000 	add	x0, x0, #0x10
    2050:	f9003fe0 	str	x0, [sp, #120]
    2054:	17ffffde 	b	1fcc <channel_session+0x54c>
            remote_window = 0xffffffffU;
    2058:	12800017 	mov	w23, #0xffffffff            	// #-1
    205c:	17fffff8 	b	203c <channel_session+0x5bc>
        } else if(payload[0] == SSH_MSG_CHANNEL_DATA && n >= 9 &&
    2060:	7101783f 	cmp	w1, #0x5e
    2064:	54000581 	b.ne	2114 <channel_session+0x694>  // b.any
    2068:	7100201f 	cmp	w0, #0x8
    206c:	54fffe8d 	b.le	203c <channel_session+0x5bc>
                  get32(payload + 1) == local_channel){
    2070:	91000660 	add	x0, x19, #0x1
    2074:	97fffbee 	bl	102c <get32>
        } else if(payload[0] == SSH_MSG_CHANNEL_DATA && n >= 9 &&
    2078:	35fffe20 	cbnz	w0, 203c <channel_session+0x5bc>
          uint32 length = get32(payload + 5);
    207c:	91001660 	add	x0, x19, #0x5
    2080:	97fffbeb 	bl	102c <get32>
    2084:	2a0003fb 	mov	w27, w0
          if(length > SSH_CHANNEL_PACKET || length > (uint32)(n - 9) ||
    2088:	7120001f 	cmp	w0, #0x800
    208c:	54000328 	b.hi	20f0 <channel_session+0x670>  // b.pmore
    2090:	51002440 	sub	w0, w2, #0x9
    2094:	6b00037f 	cmp	w27, w0
    2098:	540002c8 	b.hi	20f0 <channel_session+0x670>  // b.pmore
             writen(master, payload + 9, length) < 0 ||
    209c:	2a1b03e2 	mov	w2, w27
    20a0:	91002661 	add	x1, x19, #0x9
    20a4:	2a1a03e0 	mov	w0, w26
    20a8:	97fffc40 	bl	11a8 <writen>
          if(length > SSH_CHANNEL_PACKET || length > (uint32)(n - 9) ||
    20ac:	3100041f 	cmn	w0, #0x1
    20b0:	54000200 	b.eq	20f0 <channel_session+0x670>  // b.none
  p[0] = SSH_MSG_CHANNEL_WINDOW_ADJUST;
    20b4:	52800ba0 	mov	w0, #0x5d                  	// #93
  p[2] = v >> 8;
    20b8:	5ac00763 	rev16	w3, w27
  p[0] = SSH_MSG_CHANNEL_WINDOW_ADJUST;
    20bc:	3903a3e0 	strb	w0, [sp, #232]
  return packet_write(fd, p, sizeof(p), random, transport);
    20c0:	aa1503e4 	mov	x4, x21
  p[0] = v >> 24;
    20c4:	b94093e0 	ldr	w0, [sp, #144]
  return packet_write(fd, p, sizeof(p), random, transport);
    20c8:	9103a3e1 	add	x1, sp, #0xe8
    20cc:	52800122 	mov	w2, #0x9                   	// #9
  p[0] = v >> 24;
    20d0:	b80e93e0 	stur	w0, [sp, #233]
  return packet_write(fd, p, sizeof(p), random, transport);
    20d4:	2a1c03e0 	mov	w0, w28
  p[0] = v >> 24;
    20d8:	780ed3ff 	sturh	wzr, [sp, #237]
  p[2] = v >> 8;
    20dc:	780ef3e3 	sturh	w3, [sp, #239]
  return packet_write(fd, p, sizeof(p), random, transport);
    20e0:	aa1603e3 	mov	x3, x22
    20e4:	97fffd1d 	bl	1558 <packet_write>
             writen(master, payload + 9, length) < 0 ||
    20e8:	3100041f 	cmn	w0, #0x1
    20ec:	54fffa81 	b.ne	203c <channel_session+0x5bc>  // b.any
  close(epfd);
    20f0:	b94073e0 	ldr	w0, [sp, #112]
    20f4:	97fffba3 	bl	f80 <close@plt>
  free(terminal);
    20f8:	aa1903e0 	mov	x0, x25
    20fc:	97fffba5 	bl	f90 <free@plt>
  kill(child);
    2100:	b9406be0 	ldr	w0, [sp, #104]
    2104:	97fffb3f 	bl	e00 <kill@plt>
  wait(0);
    2108:	d2800000 	mov	x0, #0x0                   	// #0
    210c:	97fffb51 	bl	e50 <wait@plt>
  return 0;
    2110:	17ffff8b 	b	1f3c <channel_session+0x4bc>
        } else if(payload[0] == SSH_MSG_CHANNEL_EOF && n == 5 &&
    2114:	7101803f 	cmp	w1, #0x60
    2118:	540001a1 	b.ne	214c <channel_session+0x6cc>  // b.any
    211c:	7100141f 	cmp	w0, #0x5
    2120:	54fff8e1 	b.ne	203c <channel_session+0x5bc>  // b.any
                  get32(payload + 1) == local_channel){
    2124:	91000660 	add	x0, x19, #0x1
    2128:	97fffbc1 	bl	102c <get32>
        } else if(payload[0] == SSH_MSG_CHANNEL_EOF && n == 5 &&
    212c:	35fff880 	cbnz	w0, 203c <channel_session+0x5bc>
          uchar eof = 4;
    2130:	52800080 	mov	w0, #0x4                   	// #4
          write(master, &eof, 1);
    2134:	9103a3e1 	add	x1, sp, #0xe8
    2138:	52800022 	mov	w2, #0x1                   	// #1
          uchar eof = 4;
    213c:	3903a3e0 	strb	w0, [sp, #232]
          write(master, &eof, 1);
    2140:	2a1a03e0 	mov	w0, w26
    2144:	97fffb2b 	bl	df0 <write@plt>
                  get32(payload + 1) == local_channel){
    2148:	17ffffbd 	b	203c <channel_session+0x5bc>
        } else if(payload[0] == SSH_MSG_CHANNEL_CLOSE && n == 5 &&
    214c:	7101843f 	cmp	w1, #0x61
    2150:	54fff761 	b.ne	203c <channel_session+0x5bc>  // b.any
    2154:	7100141f 	cmp	w0, #0x5
    2158:	54fff721 	b.ne	203c <channel_session+0x5bc>  // b.any
                  get32(payload + 1) == local_channel){
    215c:	91000660 	add	x0, x19, #0x1
    2160:	97fffbb3 	bl	102c <get32>
        } else if(payload[0] == SSH_MSG_CHANNEL_CLOSE && n == 5 &&
    2164:	35fff6c0 	cbnz	w0, 203c <channel_session+0x5bc>
  p[0] = v >> 24;
    2168:	b94093e0 	ldr	w0, [sp, #144]
          packet_write(fd, close_packet, sizeof(close_packet), random,
    216c:	aa1503e4 	mov	x4, x21
    2170:	aa1603e3 	mov	x3, x22
          close_packet[0] = SSH_MSG_CHANNEL_CLOSE;
    2174:	3903a3e1 	strb	w1, [sp, #232]
  p[0] = v >> 24;
    2178:	b80e93e0 	stur	w0, [sp, #233]
    packet_write(fd, p, sizeof(p), random, transport);
    217c:	9103a3e1 	add	x1, sp, #0xe8
    2180:	2a1403e0 	mov	w0, w20
    2184:	97fffcf5 	bl	1558 <packet_write>
    2188:	17ffffda 	b	20f0 <channel_session+0x670>
      } else if(events[i].data.fd == master){
    218c:	6b1c035f 	cmp	w26, w28
    2190:	54fff561 	b.ne	203c <channel_session+0x5bc>  // b.any
        if(events[i].events & EPOLLERR)
    2194:	f9403fe0 	ldr	x0, [sp, #120]
    2198:	b9400000 	ldr	w0, [x0]
    219c:	37180740 	tbnz	w0, #3, 2284 <channel_session+0x804>
        if(limit > SSH_CHANNEL_PACKET)
    21a0:	b94083e0 	ldr	w0, [sp, #128]
    21a4:	52810001 	mov	w1, #0x800                 	// #2048
    21a8:	7120001f 	cmp	w0, #0x800
    21ac:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
        if(limit > remote_window)
    21b0:	6b17005f 	cmp	w2, w23
    21b4:	1a979042 	csel	w2, w2, w23, ls	// ls = plast
        if(limit == 0)
    21b8:	34fff422 	cbz	w2, 203c <channel_session+0x5bc>
        int n = read(master, terminal, limit);
    21bc:	aa1903e1 	mov	x1, x25
    21c0:	2a1a03e0 	mov	w0, w26
    21c4:	97fffb27 	bl	e60 <read@plt>
    21c8:	2a0003fb 	mov	w27, w0
        if(n <= 0)
    21cc:	7100001f 	cmp	w0, #0x0
    21d0:	540005ad 	b.le	2284 <channel_session+0x804>
  if(length < 0 || length > SSH_CHANNEL_PACKET ||
    21d4:	7120001f 	cmp	w0, #0x800
    21d8:	54fff8c8 	b.hi	20f0 <channel_session+0x670>  // b.pmore
     (p = malloc(9 + length)) == 0)
    21dc:	11002401 	add	w1, w0, #0x9
    21e0:	b9009fe1 	str	w1, [sp, #156]
    21e4:	2a0103e0 	mov	w0, w1
    21e8:	97fffaf2 	bl	db0 <malloc@plt>
    21ec:	aa0003fc 	mov	x28, x0
  if(length < 0 || length > SSH_CHANNEL_PACKET ||
    21f0:	b4fff800 	cbz	x0, 20f0 <channel_session+0x670>
  p[off++] = SSH_MSG_CHANNEL_DATA;
    21f4:	b9409be1 	ldr	w1, [sp, #152]
  if(append_u32(p, 9 + length, &off, remote_channel) < 0 ||
    21f8:	2a1803e3 	mov	w3, w24
  p[off++] = SSH_MSG_CHANNEL_DATA;
    21fc:	b900ebe1 	str	w1, [sp, #232]
  if(append_u32(p, 9 + length, &off, remote_channel) < 0 ||
    2200:	9103a3e2 	add	x2, sp, #0xe8
  p[off++] = SSH_MSG_CHANNEL_DATA;
    2204:	52800bc1 	mov	w1, #0x5e                  	// #94
    2208:	39000001 	strb	w1, [x0]
  if(append_u32(p, 9 + length, &off, remote_channel) < 0 ||
    220c:	b9409fe1 	ldr	w1, [sp, #156]
    2210:	b9009fe1 	str	w1, [sp, #156]
    2214:	97fffc17 	bl	1270 <append_u32>
    2218:	3100041f 	cmn	w0, #0x1
    221c:	b9409fe1 	ldr	w1, [sp, #156]
    2220:	54000081 	b.ne	2230 <channel_session+0x7b0>  // b.any
    free(p);
    2224:	aa1c03e0 	mov	x0, x28
    2228:	97fffb5a 	bl	f90 <free@plt>
    return -1;
    222c:	17ffffb1 	b	20f0 <channel_session+0x670>
     append_blob(p, 9 + length, &off, data, length) < 0){
    2230:	2a1b03e4 	mov	w4, w27
    2234:	aa1903e3 	mov	x3, x25
    2238:	9103a3e2 	add	x2, sp, #0xe8
    223c:	aa1c03e0 	mov	x0, x28
    2240:	97fffc34 	bl	1310 <append_blob>
  if(append_u32(p, 9 + length, &off, remote_channel) < 0 ||
    2244:	3100041f 	cmn	w0, #0x1
    2248:	54fffee0 	b.eq	2224 <channel_session+0x7a4>  // b.none
  int result = packet_write(fd, p, off, random, transport);
    224c:	b940ebe2 	ldr	w2, [sp, #232]
    2250:	aa1503e4 	mov	x4, x21
    2254:	aa1603e3 	mov	x3, x22
    2258:	aa1c03e1 	mov	x1, x28
    225c:	2a1403e0 	mov	w0, w20
    2260:	97fffcbe 	bl	1558 <packet_write>
    2264:	b9009fe0 	str	w0, [sp, #156]
  free(p);
    2268:	aa1c03e0 	mov	x0, x28
    226c:	97fffb49 	bl	f90 <free@plt>
        if(send_channel_data(fd, remote_channel, terminal, n, random,
    2270:	b9409fe0 	ldr	w0, [sp, #156]
    2274:	3100041f 	cmn	w0, #0x1
    2278:	54fff3c0 	b.eq	20f0 <channel_session+0x670>  // b.none
        remote_window -= n;
    227c:	4b1b02f7 	sub	w23, w23, w27
    2280:	17ffff6f 	b	203c <channel_session+0x5bc>
    p[0] = SSH_MSG_CHANNEL_EOF;
    2284:	52800c00 	mov	w0, #0x60                  	// #96
    2288:	3903a3e0 	strb	w0, [sp, #232]
  p[0] = v >> 24;
    228c:	b94093e0 	ldr	w0, [sp, #144]
    packet_write(fd, p, sizeof(p), random, transport);
    2290:	aa1503e4 	mov	x4, x21
    2294:	aa1603e3 	mov	x3, x22
    2298:	528000a2 	mov	w2, #0x5                   	// #5
    229c:	9103a3e1 	add	x1, sp, #0xe8
  p[0] = v >> 24;
    22a0:	b80e93e0 	stur	w0, [sp, #233]
    packet_write(fd, p, sizeof(p), random, transport);
    22a4:	2a1403e0 	mov	w0, w20
    22a8:	97fffcac 	bl	1558 <packet_write>
    p[0] = SSH_MSG_CHANNEL_CLOSE;
    22ac:	52800c20 	mov	w0, #0x61                  	// #97
    packet_write(fd, p, sizeof(p), random, transport);
    22b0:	aa1503e4 	mov	x4, x21
    22b4:	aa1603e3 	mov	x3, x22
    22b8:	528000a2 	mov	w2, #0x5                   	// #5
    p[0] = SSH_MSG_CHANNEL_CLOSE;
    22bc:	3903a3e0 	strb	w0, [sp, #232]
    packet_write(fd, p, sizeof(p), random, transport);
    22c0:	17ffffaf 	b	217c <channel_session+0x6fc>
  close(epfd);
    22c4:	b94073e0 	ldr	w0, [sp, #112]
    22c8:	97fffb2e 	bl	f80 <close@plt>
    22cc:	17ffff23 	b	1f58 <channel_session+0x4d8>
      if(want_reply && send_channel_status(fd, 0, remote_channel, random,
    22d0:	34ffc9f7 	cbz	w23, 1c0c <channel_session+0x18c>
    22d4:	aa1503e4 	mov	x4, x21
    22d8:	aa1603e3 	mov	x3, x22
    22dc:	2a1803e2 	mov	w2, w24
    22e0:	2a1403e0 	mov	w0, w20
    22e4:	52800001 	mov	w1, #0x0                   	// #0
    22e8:	97fffd45 	bl	17fc <send_channel_status>
    22ec:	2a0003f7 	mov	w23, w0
    22f0:	3100041f 	cmn	w0, #0x1
    22f4:	54ffc8c1 	b.ne	1c0c <channel_session+0x18c>  // b.any
    22f8:	17fffefd 	b	1eec <channel_session+0x46c>
      return 0;
    22fc:	52800017 	mov	w23, #0x0                   	// #0
    2300:	17fffefb 	b	1eec <channel_session+0x46c>
      if(want_reply && send_channel_status(fd, valid, remote_channel, random,
    2304:	34ffc857 	cbz	w23, 1c0c <channel_session+0x18c>
    2308:	52800019 	mov	w25, #0x0                   	// #0
    230c:	17fffe90 	b	1d4c <channel_session+0x2cc>

0000000000002310 <userauth>:
{
    2310:	d10c43ff 	sub	sp, sp, #0x310
    2314:	a9007bfd 	stp	x29, x30, [sp]
    2318:	910003fd 	mov	x29, sp
    231c:	a90153f3 	stp	x19, x20, [sp, #16]
    2320:	aa0103f3 	mov	x19, x1
    2324:	a9046bf9 	stp	x25, x26, [sp, #64]
    2328:	aa0303fa 	mov	x26, x3
    232c:	2a0003f9 	mov	w25, w0
       !string_is(service, service_len, "ssh-connection")){
    2330:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2334:	910e0400 	add	x0, x0, #0x381
{
    2338:	a9025bf5 	stp	x21, x22, [sp, #32]
    233c:	a90363f7 	stp	x23, x24, [sp, #48]
    2340:	a90573fb 	stp	x27, x28, [sp, #80]
    2344:	528000db 	mov	w27, #0x6                   	// #6
    2348:	a90697e4 	stp	x4, x5, [sp, #104]
    234c:	f9003fe2 	str	x2, [sp, #120]
       !string_is(service, service_len, "ssh-connection")){
    2350:	f90047e0 	str	x0, [sp, #136]
    int n = packet_read(fd, payload, SSH_PACKET_MAX, transport);
    2354:	aa1a03e2 	mov	x2, x26
    2358:	aa1303e1 	mov	x1, x19
    235c:	2a1903e0 	mov	w0, w25
    2360:	97fffd33 	bl	182c <packet_read.constprop.0>
    2364:	2a0003f4 	mov	w20, w0
    int off = 1;
    2368:	52800020 	mov	w0, #0x1                   	// #1
    236c:	b900a7e0 	str	w0, [sp, #164]
    if(n < 1 || payload[0] != SSH_MSG_USERAUTH_REQUEST ||
    2370:	7100029f 	cmp	w20, #0x0
    2374:	5400042d 	b.le	23f8 <userauth+0xe8>
    2378:	39400260 	ldrb	w0, [x19]
    237c:	7100c81f 	cmp	w0, #0x32
    2380:	540003c1 	b.ne	23f8 <userauth+0xe8>  // b.any
       parse_string(payload, n, &off, &name, &name_len) < 0 ||
    2384:	9102a3e4 	add	x4, sp, #0xa8
    2388:	9102e3e3 	add	x3, sp, #0xb8
    238c:	910293e2 	add	x2, sp, #0xa4
    2390:	2a1403e1 	mov	w1, w20
    2394:	aa1303e0 	mov	x0, x19
    2398:	97fffb3a 	bl	1080 <parse_string>
    if(n < 1 || payload[0] != SSH_MSG_USERAUTH_REQUEST ||
    239c:	3100041f 	cmn	w0, #0x1
    23a0:	540002c0 	b.eq	23f8 <userauth+0xe8>  // b.none
       parse_string(payload, n, &off, &service, &service_len) < 0 ||
    23a4:	9102b3e4 	add	x4, sp, #0xac
    23a8:	910303e3 	add	x3, sp, #0xc0
    23ac:	910293e2 	add	x2, sp, #0xa4
    23b0:	2a1403e1 	mov	w1, w20
    23b4:	aa1303e0 	mov	x0, x19
    23b8:	97fffb32 	bl	1080 <parse_string>
       parse_string(payload, n, &off, &name, &name_len) < 0 ||
    23bc:	3100041f 	cmn	w0, #0x1
    23c0:	540001c0 	b.eq	23f8 <userauth+0xe8>  // b.none
       parse_string(payload, n, &off, &method, &method_len) < 0 ||
    23c4:	9102c3e4 	add	x4, sp, #0xb0
    23c8:	910323e3 	add	x3, sp, #0xc8
    23cc:	910293e2 	add	x2, sp, #0xa4
    23d0:	2a1403e1 	mov	w1, w20
    23d4:	aa1303e0 	mov	x0, x19
    23d8:	97fffb2a 	bl	1080 <parse_string>
       parse_string(payload, n, &off, &service, &service_len) < 0 ||
    23dc:	3100041f 	cmn	w0, #0x1
    23e0:	540000c0 	b.eq	23f8 <userauth+0xe8>  // b.none
       !string_is(service, service_len, "ssh-connection")){
    23e4:	f94047e2 	ldr	x2, [sp, #136]
    23e8:	f94063e0 	ldr	x0, [sp, #192]
    23ec:	b940afe1 	ldr	w1, [sp, #172]
    23f0:	97fffb58 	bl	1150 <string_is>
       parse_string(payload, n, &off, &method, &method_len) < 0 ||
    23f4:	350000c0 	cbnz	w0, 240c <userauth+0xfc>
      printf("sshd: malformed SSH_MSG_USERAUTH_REQUEST\n");
    23f8:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    23fc:	910e4000 	add	x0, x0, #0x390
    2400:	97fffa54 	bl	d50 <printf@plt>
      return -1;
    2404:	12800000 	mov	w0, #0xffffffff            	// #-1
    2408:	140000c0 	b	2708 <userauth+0x3f8>
    if(string_is(method, method_len, "password")){
    240c:	f94067e0 	ldr	x0, [sp, #200]
    2410:	b0000018 	adrp	x24, 3000 <serve_connection+0x8ac>
    2414:	910eeb18 	add	x24, x24, #0x3ba
    2418:	b940b3e1 	ldr	w1, [sp, #176]
    241c:	aa1803e2 	mov	x2, x24
    2420:	97fffb4c 	bl	1150 <string_is>
    2424:	34000660 	cbz	w0, 24f0 <userauth+0x1e0>
      if(off >= n || payload[off++] != 0 ||
    2428:	b940a7e0 	ldr	w0, [sp, #164]
    242c:	6b14001f 	cmp	w0, w20
    2430:	54fffeaa 	b.ge	2404 <userauth+0xf4>  // b.tcont
    2434:	11000401 	add	w1, w0, #0x1
    2438:	3860ca60 	ldrb	w0, [x19, w0, sxtw]
    243c:	b900a7e1 	str	w1, [sp, #164]
    2440:	35fffe20 	cbnz	w0, 2404 <userauth+0xf4>
         parse_string(payload, n, &off, &password, &password_len) < 0 ||
    2444:	9102d3e4 	add	x4, sp, #0xb4
    2448:	910343e3 	add	x3, sp, #0xd0
    244c:	910293e2 	add	x2, sp, #0xa4
    2450:	2a1403e1 	mov	w1, w20
    2454:	aa1303e0 	mov	x0, x19
    2458:	97fffb0a 	bl	1080 <parse_string>
      if(off >= n || payload[off++] != 0 ||
    245c:	3100041f 	cmn	w0, #0x1
    2460:	54001540 	b.eq	2708 <userauth+0x3f8>  // b.none
         parse_string(payload, n, &off, &password, &password_len) < 0 ||
    2464:	b940a7e0 	ldr	w0, [sp, #164]
    2468:	6b14001f 	cmp	w0, w20
    246c:	54fffcc1 	b.ne	2404 <userauth+0xf4>  // b.any
      if(authenticate(name, name_len, password, password_len, home, shell) == 0){
    2470:	f9405fe0 	ldr	x0, [sp, #184]
    2474:	f90033e0 	str	x0, [sp, #96]
    2478:	f9406be0 	ldr	x0, [sp, #208]
  int fd = open("/etc/passwd", O_RDONLY);
    247c:	52800001 	mov	w1, #0x0                   	// #0
      if(authenticate(name, name_len, password, password_len, home, shell) == 0){
    2480:	b940abf6 	ldr	w22, [sp, #168]
    2484:	b940b7f7 	ldr	w23, [sp, #180]
    2488:	f90043e0 	str	x0, [sp, #128]
  int fd = open("/etc/passwd", O_RDONLY);
    248c:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2490:	910f0c00 	add	x0, x0, #0x3c3
    2494:	97fffab3 	bl	f60 <open@plt>
    2498:	2a0003fc 	mov	w28, w0
  if(fd < 0)
    249c:	37f80240 	tbnz	w0, #31, 24e4 <userauth+0x1d4>
  int n = read(fd, buf, sizeof(buf) - 1);
    24a0:	910443f4 	add	x20, sp, #0x110
    24a4:	52803fe2 	mov	w2, #0x1ff                 	// #511
    24a8:	aa1403e1 	mov	x1, x20
    24ac:	97fffa6d 	bl	e60 <read@plt>
    24b0:	2a0003f5 	mov	w21, w0
  close(fd);
    24b4:	2a1c03e0 	mov	w0, w28
    24b8:	97fffab2 	bl	f80 <close@plt>
  if(n <= 0)
    24bc:	710002bf 	cmp	w21, #0x0
    24c0:	5400012d 	b.le	24e4 <userauth+0x1d4>
  for(line = buf; *line; line = end){
    24c4:	aa1403fc 	mov	x28, x20
  buf[n] = 0;
    24c8:	38354a9f 	strb	wzr, [x20, w21, uxtw]
  for(line = buf; *line; line = end){
    24cc:	39400380 	ldrb	w0, [x28]
    24d0:	35000420 	cbnz	w0, 2554 <userauth+0x244>
  memset(buf, 0, sizeof(buf));
    24d4:	aa1403e0 	mov	x0, x20
    24d8:	52804002 	mov	w2, #0x200                 	// #512
    24dc:	52800001 	mov	w1, #0x0                   	// #0
    24e0:	97fffa80 	bl	ee0 <memset@plt>
      printf("sshd: password authentication rejected\n");
    24e4:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    24e8:	91102c00 	add	x0, x0, #0x40b
    24ec:	97fffa19 	bl	d50 <printf@plt>
  p[off++] = SSH_MSG_USERAUTH_FAILURE;
    24f0:	52800020 	mov	w0, #0x1                   	// #1
  if(append_string(p, sizeof(p), &off, "password") < 0)
    24f4:	910443f4 	add	x20, sp, #0x110
  p[off++] = SSH_MSG_USERAUTH_FAILURE;
    24f8:	b900dbe0 	str	w0, [sp, #216]
    24fc:	52800660 	mov	w0, #0x33                  	// #51
  if(append_string(p, sizeof(p), &off, "password") < 0)
    2500:	aa1803e3 	mov	x3, x24
    2504:	910363e2 	add	x2, sp, #0xd8
    2508:	52800801 	mov	w1, #0x40                  	// #64
  p[off++] = SSH_MSG_USERAUTH_FAILURE;
    250c:	390443e0 	strb	w0, [sp, #272]
  if(append_string(p, sizeof(p), &off, "password") < 0)
    2510:	aa1403e0 	mov	x0, x20
    2514:	97fffb60 	bl	1294 <append_string>
    2518:	3100041f 	cmn	w0, #0x1
    251c:	54000f60 	b.eq	2708 <userauth+0x3f8>  // b.none
  p[off++] = 0; // partial success = false
    2520:	b940dbe2 	ldr	w2, [sp, #216]
  return packet_write(fd, p, off, random, transport);
    2524:	aa1a03e4 	mov	x4, x26
    2528:	f9403fe3 	ldr	x3, [sp, #120]
    252c:	aa1403e1 	mov	x1, x20
    2530:	2a1903e0 	mov	w0, w25
  p[off++] = 0; // partial success = false
    2534:	3822ca9f 	strb	wzr, [x20, w2, sxtw]
  return packet_write(fd, p, off, random, transport);
    2538:	11000442 	add	w2, w2, #0x1
    253c:	97fffc07 	bl	1558 <packet_write>
    if(send_userauth_failure(fd, random, transport) < 0)
    2540:	3100041f 	cmn	w0, #0x1
    2544:	54000e20 	b.eq	2708 <userauth+0x3f8>  // b.none
  for(int attempt = 0; attempt < 6; attempt++){
    2548:	7100077b 	subs	w27, w27, #0x1
    254c:	54fff041 	b.ne	2354 <userauth+0x44>  // b.any
    2550:	17ffffad 	b	2404 <userauth+0xf4>
    end = strchr(line, '\n');
    2554:	aa1c03e0 	mov	x0, x28
    2558:	52800141 	mov	w1, #0xa                   	// #10
    255c:	97fffa85 	bl	f70 <strchr@plt>
    if(end)
    2560:	b40004a0 	cbz	x0, 25f4 <userauth+0x2e4>
      *end++ = 0;
    2564:	aa0003f5 	mov	x21, x0
    2568:	380016bf 	strb	wzr, [x21], #1
    if(*line == 0 || *line == '#')
    256c:	39400380 	ldrb	w0, [x28]
    2570:	71008c1f 	cmp	w0, #0x23
    2574:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    2578:	54000e00 	b.eq	2738 <userauth+0x428>  // b.none
    char *field[7], *cursor = line;
    257c:	aa1c03e0 	mov	x0, x28
    if(*line == 0 || *line == '#')
    2580:	d2800022 	mov	x2, #0x1                   	// #1
      cursor = strchr(cursor, ':');
    2584:	52800741 	mov	w1, #0x3a                  	// #58
    2588:	f9004be2 	str	x2, [sp, #144]
    258c:	97fffa79 	bl	f70 <strchr@plt>
      if(cursor == 0){
    2590:	b4000d40 	cbz	x0, 2738 <userauth+0x428>
      field[i + 1] = cursor;
    2594:	f9404be2 	ldr	x2, [sp, #144]
    2598:	910363e1 	add	x1, sp, #0xd8
      *cursor++ = 0;
    259c:	3800141f 	strb	wzr, [x0], #1
      field[i + 1] = cursor;
    25a0:	f8227820 	str	x0, [x1, x2, lsl #3]
    for(int i = 0; i < 6; i++){
    25a4:	91000442 	add	x2, x2, #0x1
    25a8:	f1001c5f 	cmp	x2, #0x7
    25ac:	54fffec1 	b.ne	2584 <userauth+0x274>  // b.any
    uint32 user_len = strlen(field[0]);
    25b0:	aa1c03e0 	mov	x0, x28
    25b4:	97fffa67 	bl	f50 <strlen@plt>
    uint32 pass_len = strlen(field[1]);
    25b8:	f94073e6 	ldr	x6, [sp, #224]
    uint32 user_len = strlen(field[0]);
    25bc:	2a0003e5 	mov	w5, w0
    uint32 pass_len = strlen(field[1]);
    25c0:	f9004be6 	str	x6, [sp, #144]
    25c4:	aa0603e0 	mov	x0, x6
    uint32 user_len = strlen(field[0]);
    25c8:	b9009fe5 	str	w5, [sp, #156]
    uint32 pass_len = strlen(field[1]);
    25cc:	97fffa61 	bl	f50 <strlen@plt>
    uchar difference = (user_len != name_length) | (pass_len != password_length);
    25d0:	b9409fe5 	ldr	w5, [sp, #156]
    for(uint32 i = 0; i < max; i++){
    25d4:	d2800001 	mov	x1, #0x0                   	// #0
    25d8:	f9404be6 	ldr	x6, [sp, #144]
    uchar difference = (user_len != name_length) | (pass_len != password_length);
    25dc:	6b0502df 	cmp	w22, w5
    25e0:	7a4002e0 	ccmp	w23, w0, #0x0, eq	// eq = none
    25e4:	1a9f07e4 	cset	w4, ne	// ne = any
    uint32 max = pass_len > password_length ? pass_len : password_length;
    25e8:	6b0002ff 	cmp	w23, w0
    25ec:	1a8022e8 	csel	w8, w23, w0, cs	// cs = hs, nlast
    for(uint32 i = 0; i < max; i++){
    25f0:	1400000f 	b	262c <userauth+0x31c>
      end = line + strlen(line);
    25f4:	aa1c03e0 	mov	x0, x28
    25f8:	97fffa56 	bl	f50 <strlen@plt>
    25fc:	8b204395 	add	x21, x28, w0, uxtw
    2600:	17ffffdb 	b	256c <userauth+0x25c>
      uchar a = i < pass_len ? (uchar)field[1][i] : 0;
    2604:	6b00003f 	cmp	w1, w0
    2608:	54000902 	b.cs	2728 <userauth+0x418>  // b.hs, b.nlast
    260c:	386168c2 	ldrb	w2, [x6, x1]
      uchar b = i < password_length ? password[i] : 0;
    2610:	6b0702ff 	cmp	w23, w7
    2614:	540008e9 	b.ls	2730 <userauth+0x420>  // b.plast
    2618:	f94043e3 	ldr	x3, [sp, #128]
    261c:	38616867 	ldrb	w7, [x3, x1]
      difference |= a ^ b;
    2620:	4a070042 	eor	w2, w2, w7
    2624:	91000421 	add	x1, x1, #0x1
    2628:	2a020084 	orr	w4, w4, w2
    for(uint32 i = 0; i < max; i++){
    262c:	2a0103e7 	mov	w7, w1
    2630:	6b08003f 	cmp	w1, w8
    2634:	54fffe83 	b.cc	2604 <userauth+0x2f4>  // b.lo, b.ul, b.last
    if(user_len == name_length && memcmp(field[0], name, name_length) == 0 &&
    2638:	6b0502df 	cmp	w22, w5
    263c:	540007e1 	b.ne	2738 <userauth+0x428>  // b.any
    2640:	f94033e1 	ldr	x1, [sp, #96]
    2644:	2a1603e2 	mov	w2, w22
    2648:	aa1c03e0 	mov	x0, x28
    264c:	b90093e4 	str	w4, [sp, #144]
    2650:	97fffa14 	bl	ea0 <memcmp@plt>
    2654:	35000720 	cbnz	w0, 2738 <userauth+0x428>
    2658:	b94093e4 	ldr	w4, [sp, #144]
    265c:	350006e4 	cbnz	w4, 2738 <userauth+0x428>
      strncpy(home, field[5], 63);
    2660:	f94037e0 	ldr	x0, [sp, #104]
    2664:	528007e2 	mov	w2, #0x3f                  	// #63
    2668:	f94083e1 	ldr	x1, [sp, #256]
    266c:	97fffa05 	bl	e80 <strncpy@plt>
      home[63] = 0;
    2670:	f94037e0 	ldr	x0, [sp, #104]
      strncpy(shell, field[6], 63);
    2674:	528007e2 	mov	w2, #0x3f                  	// #63
    2678:	f94087e1 	ldr	x1, [sp, #264]
      home[63] = 0;
    267c:	3900fc1f 	strb	wzr, [x0, #63]
      strncpy(shell, field[6], 63);
    2680:	f9403be0 	ldr	x0, [sp, #112]
    2684:	97fff9ff 	bl	e80 <strncpy@plt>
      shell[63] = 0;
    2688:	f9403be0 	ldr	x0, [sp, #112]
      memset(buf, 0, sizeof(buf));
    268c:	52804002 	mov	w2, #0x200                 	// #512
    2690:	52800001 	mov	w1, #0x0                   	// #0
      shell[63] = 0;
    2694:	3900fc1f 	strb	wzr, [x0, #63]
      memset(buf, 0, sizeof(buf));
    2698:	aa1403e0 	mov	x0, x20
    269c:	97fffa11 	bl	ee0 <memset@plt>
        if(packet_write(fd, payload, 1, random, transport) < 0)
    26a0:	f9403fe3 	ldr	x3, [sp, #120]
        payload[0] = SSH_MSG_USERAUTH_SUCCESS;
    26a4:	52800680 	mov	w0, #0x34                  	// #52
    26a8:	39000260 	strb	w0, [x19]
        if(packet_write(fd, payload, 1, random, transport) < 0)
    26ac:	aa1a03e4 	mov	x4, x26
    26b0:	aa1303e1 	mov	x1, x19
    26b4:	2a1903e0 	mov	w0, w25
    26b8:	52800022 	mov	w2, #0x1                   	// #1
    26bc:	97fffba7 	bl	1558 <packet_write>
    26c0:	3100041f 	cmn	w0, #0x1
    26c4:	54000220 	b.eq	2708 <userauth+0x3f8>  // b.none
  if(capacity <= 0 || length >= (uint32)capacity)
    26c8:	71007edf 	cmp	w22, #0x1f
    26cc:	540003a8 	b.hi	2740 <userauth+0x430>  // b.pmore
  memmove(dst, src, length);
    26d0:	f94033e1 	ldr	x1, [sp, #96]
    26d4:	2a1603e2 	mov	w2, w22
    26d8:	aa1403e0 	mov	x0, x20
    26dc:	97fff9a5 	bl	d70 <memmove@plt>
  dst[length] = 0;
    26e0:	38364a9f 	strb	wzr, [x20, w22, uxtw]
        printf("sshd: password authentication accepted user=%s\n", user);
    26e4:	aa1403e1 	mov	x1, x20
    26e8:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    26ec:	910f6c00 	add	x0, x0, #0x3db
    26f0:	97fff998 	bl	d50 <printf@plt>
        memset(user, 0, sizeof(user));
    26f4:	aa1403e0 	mov	x0, x20
    26f8:	52800402 	mov	w2, #0x20                  	// #32
    26fc:	52800001 	mov	w1, #0x0                   	// #0
    2700:	97fff9f8 	bl	ee0 <memset@plt>
        return 0;
    2704:	52800000 	mov	w0, #0x0                   	// #0
}
    2708:	a9407bfd 	ldp	x29, x30, [sp]
    270c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2710:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2714:	a94363f7 	ldp	x23, x24, [sp, #48]
    2718:	a9446bf9 	ldp	x25, x26, [sp, #64]
    271c:	a94573fb 	ldp	x27, x28, [sp, #80]
    2720:	910c43ff 	add	sp, sp, #0x310
    2724:	d65f03c0 	ret
      uchar a = i < pass_len ? (uchar)field[1][i] : 0;
    2728:	52800002 	mov	w2, #0x0                   	// #0
    272c:	17ffffb9 	b	2610 <userauth+0x300>
      uchar b = i < password_length ? password[i] : 0;
    2730:	52800007 	mov	w7, #0x0                   	// #0
    2734:	17ffffbb 	b	2620 <userauth+0x310>
  for(line = buf; *line; line = end){
    2738:	aa1503fc 	mov	x28, x21
    273c:	17ffff64 	b	24cc <userauth+0x1bc>
          strcpy(user, "<long-name>");
    2740:	aa1403e0 	mov	x0, x20
    2744:	b0000001 	adrp	x1, 3000 <serve_connection+0x8ac>
    2748:	910f3c21 	add	x1, x1, #0x3cf
    274c:	97fff979 	bl	d30 <strcpy@plt>
    2750:	17ffffe5 	b	26e4 <userauth+0x3d4>

0000000000002754 <serve_connection>:
{
    2754:	a9ac7bfd 	stp	x29, x30, [sp, #-320]!
    2758:	910003fd 	mov	x29, sp
    275c:	a90153f3 	stp	x19, x20, [sp, #16]
    2760:	a9025bf5 	stp	x21, x22, [sp, #32]
    2764:	2a0003f5 	mov	w21, w0
    2768:	a90363f7 	stp	x23, x24, [sp, #48]
    276c:	a9046bf9 	stp	x25, x26, [sp, #64]
    2770:	a90573fb 	stp	x27, x28, [sp, #80]
  uint32 random = (uint32)uptime() ^ ((uint32)getpid() << 16) ^ 0x58d6a73bU;
    2774:	97fff9d3 	bl	ec0 <uptime@plt>
    2778:	2a0003f3 	mov	w19, w0
    277c:	97fff981 	bl	d80 <getpid@plt>
    2780:	4a004260 	eor	w0, w19, w0, lsl #16
    2784:	5294e761 	mov	w1, #0xa73b                	// #42811
    2788:	72ab1ac1 	movk	w1, #0x58d6, lsl #16
    278c:	4a010000 	eor	w0, w0, w1
    2790:	b90087e0 	str	w0, [sp, #132]
  state = malloc(sizeof(*state));
    2794:	5280bb00 	mov	w0, #0x5d8                 	// #1496
    2798:	97fff986 	bl	db0 <malloc@plt>
  if(state == 0)
    279c:	b40005c0 	cbz	x0, 2854 <serve_connection+0x100>
  memset(state, 0, sizeof(*state));
    27a0:	5280bb02 	mov	w2, #0x5d8                 	// #1496
    27a4:	52800001 	mov	w1, #0x0                   	// #0
    27a8:	aa0003f3 	mov	x19, x0
    27ac:	97fff9cd 	bl	ee0 <memset@plt>
  if(writen(fd, server_ident_line, strlen(server_ident_line)) < 0 ||
    27b0:	d0000000 	adrp	x0, 4000 <serve_connection+0x18ac>
    27b4:	912e4000 	add	x0, x0, #0xb90
    27b8:	91001014 	add	x20, x0, #0x4
    27bc:	f90033e0 	str	x0, [sp, #96]
    27c0:	aa1403e0 	mov	x0, x20
    27c4:	97fff9e3 	bl	f50 <strlen@plt>
    27c8:	aa1403e1 	mov	x1, x20
    27cc:	2a0003e2 	mov	w2, w0
    27d0:	2a1503e0 	mov	w0, w21
    27d4:	97fffa75 	bl	11a8 <writen>
    27d8:	3100041f 	cmn	w0, #0x1
    27dc:	54000140 	b.eq	2804 <serve_connection+0xb0>  // b.none
     read_identification(fd, state->client_ident,
    27e0:	9107e278 	add	x24, x19, #0x1f8
      if(readn(fd, &ch, 1) < 0)
    27e4:	9103a3fb 	add	x27, sp, #0xe8
     read_identification(fd, state->client_ident,
    27e8:	52800216 	mov	w22, #0x10                  	// #16
    int n = 0;
    27ec:	52800014 	mov	w20, #0x0                   	// #0
    27f0:	1400023e 	b	30e8 <serve_connection+0x994>
      if(ch == '\n')
    27f4:	2a1403e0 	mov	w0, w20
    27f8:	1400024c 	b	3128 <serve_connection+0x9d4>
  for(int lines = 0; lines < 16; lines++){
    27fc:	710006d6 	subs	w22, w22, #0x1
    2800:	54ffff61 	b.ne	27ec <serve_connection+0x98>  // b.any
  uchar *payload = 0, *client_kexinit = 0, *server_kexinit = 0;
    2804:	d2800016 	mov	x22, #0x0                   	// #0
    2808:	d2800017 	mov	x23, #0x0                   	// #0
    280c:	d2800014 	mov	x20, #0x0                   	// #0
    printf("sshd: invalid client identification\n");
    2810:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2814:	91110400 	add	x0, x0, #0x441
    2818:	97fff94e 	bl	d50 <printf@plt>
    memset(state, 0, sizeof(*state));
    281c:	5280bb02 	mov	w2, #0x5d8                 	// #1496
    2820:	52800001 	mov	w1, #0x0                   	// #0
    2824:	aa1303e0 	mov	x0, x19
    2828:	97fff9ae 	bl	ee0 <memset@plt>
    free(state);
    282c:	aa1303e0 	mov	x0, x19
    2830:	97fff9d8 	bl	f90 <free@plt>
  if(client_kexinit)
    2834:	b4000077 	cbz	x23, 2840 <serve_connection+0xec>
    free(client_kexinit);
    2838:	aa1703e0 	mov	x0, x23
    283c:	97fff9d5 	bl	f90 <free@plt>
  if(server_kexinit)
    2840:	b4000076 	cbz	x22, 284c <serve_connection+0xf8>
    free(server_kexinit);
    2844:	aa1603e0 	mov	x0, x22
    2848:	97fff9d2 	bl	f90 <free@plt>
  free(payload);
    284c:	aa1403e0 	mov	x0, x20
    2850:	97fff9d0 	bl	f90 <free@plt>
}
    2854:	a94153f3 	ldp	x19, x20, [sp, #16]
    2858:	a9425bf5 	ldp	x21, x22, [sp, #32]
    285c:	a94363f7 	ldp	x23, x24, [sp, #48]
    2860:	a9446bf9 	ldp	x25, x26, [sp, #64]
    2864:	a94573fb 	ldp	x27, x28, [sp, #80]
    2868:	a8d47bfd 	ldp	x29, x30, [sp], #320
    286c:	d65f03c0 	ret
  memmove(client_kexinit, payload, n);
    2870:	2a1903e2 	mov	w2, w25
    2874:	aa1403e1 	mov	x1, x20
    2878:	aa1703e0 	mov	x0, x23
    287c:	97fff93d 	bl	d70 <memmove@plt>
  if(*offset + 4 > payload_len)
    2880:	7100533f 	cmp	w25, #0x14
    2884:	5400080d 	b.le	2984 <serve_connection+0x230>
  uint32 n = get32(payload + *offset);
    2888:	91004680 	add	x0, x20, #0x11
    288c:	97fff9e8 	bl	102c <get32>
    2890:	2a0003fa 	mov	w26, w0
  if(n > (uint32)(payload_len - *offset))
    2894:	51005720 	sub	w0, w25, #0x15
    2898:	6b00035f 	cmp	w26, w0
    289c:	54000748 	b.hi	2984 <serve_connection+0x230>  // b.pmore
  int copy = n < (uint32)(dst_size - 1) ? n : dst_size - 1;
    28a0:	71027f5f 	cmp	w26, #0x9f
  if(copy_name_list(state->client_kex, sizeof(state->client_kex),
    28a4:	910be27c 	add	x28, x19, #0x2f8
  memmove(dst, payload + *offset, copy);
    28a8:	91005681 	add	x1, x20, #0x15
    28ac:	aa1c03e0 	mov	x0, x28
  int copy = n < (uint32)(dst_size - 1) ? n : dst_size - 1;
    28b0:	528013e2 	mov	w2, #0x9f                  	// #159
    28b4:	1a829342 	csel	w2, w26, w2, ls	// ls = plast
  memmove(dst, payload + *offset, copy);
    28b8:	b9006be2 	str	w2, [sp, #104]
    28bc:	97fff92d 	bl	d70 <memmove@plt>
  dst[copy] = 0;
    28c0:	b9406be2 	ldr	w2, [sp, #104]
  if(*offset + 4 > payload_len)
    28c4:	11006340 	add	w0, w26, #0x18
  dst[copy] = 0;
    28c8:	38224b9f 	strb	wzr, [x28, w2, uxtw]
  if(*offset + 4 > payload_len)
    28cc:	6b00033f 	cmp	w25, w0
    28d0:	540005ad 	b.le	2984 <serve_connection+0x230>
  uint32 n = get32(payload + *offset);
    28d4:	11006741 	add	w1, w26, #0x19
    28d8:	11005740 	add	w0, w26, #0x15
  if(n > (uint32)(payload_len - *offset))
    28dc:	4b010322 	sub	w2, w25, w1
  uint32 n = get32(payload + *offset);
    28e0:	8b000280 	add	x0, x20, x0
    28e4:	97fff9d2 	bl	102c <get32>
  if(n > (uint32)(payload_len - *offset))
    28e8:	6b02001f 	cmp	w0, w2
    28ec:	540004c8 	b.hi	2984 <serve_connection+0x230>  // b.pmore
  int copy = n < (uint32)(dst_size - 1) ? n : dst_size - 1;
    28f0:	71027c1f 	cmp	w0, #0x9f
     copy_name_list(state->client_hostkey, sizeof(state->client_hostkey),
    28f4:	910e627a 	add	x26, x19, #0x398
  memmove(dst, payload + *offset, copy);
    28f8:	8b214281 	add	x1, x20, w1, uxtw
  int copy = n < (uint32)(dst_size - 1) ? n : dst_size - 1;
    28fc:	528013e2 	mov	w2, #0x9f                  	// #159
    2900:	1a829002 	csel	w2, w0, w2, ls	// ls = plast
  memmove(dst, payload + *offset, copy);
    2904:	aa1a03e0 	mov	x0, x26
    2908:	b9006be2 	str	w2, [sp, #104]
    290c:	97fff919 	bl	d70 <memmove@plt>
  dst[copy] = 0;
    2910:	b9406be2 	ldr	w2, [sp, #104]
  printf("sshd: KEXINIT received\n");
    2914:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2918:	91121800 	add	x0, x0, #0x486
  dst[copy] = 0;
    291c:	38224b5f 	strb	wzr, [x26, w2, uxtw]
  printf("sshd: KEXINIT received\n");
    2920:	97fff90c 	bl	d50 <printf@plt>
  printf("sshd: client kex=%s\n", state->client_kex);
    2924:	aa1c03e1 	mov	x1, x28
    2928:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    292c:	91127800 	add	x0, x0, #0x49e
    2930:	97fff908 	bl	d50 <printf@plt>
  printf("sshd: client hostkey=%s\n", state->client_hostkey);
    2934:	aa1a03e1 	mov	x1, x26
    2938:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    293c:	9112cc00 	add	x0, x0, #0x4b3
    2940:	97fff904 	bl	d50 <printf@plt>
  n = packet_read(fd, payload, SSH_PACKET_MAX, &state->transport);
    2944:	aa1303e2 	mov	x2, x19
    2948:	aa1403e1 	mov	x1, x20
    294c:	2a1503e0 	mov	w0, w21
    2950:	97fffbb7 	bl	182c <packet_read.constprop.0>
  if(payload_len != 1 + 4 + 32 || payload[0] != SSH_MSG_KEX_ECDH_INIT ||
    2954:	7100941f 	cmp	w0, #0x25
    2958:	540001c0 	b.eq	2990 <serve_connection+0x23c>  // b.none
    printf("sshd: malformed SSH_MSG_KEX_ECDH_INIT\n");
    295c:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2960:	91147400 	add	x0, x0, #0x51d
    2964:	97fff8fb 	bl	d50 <printf@plt>
    send_disconnect(fd, "invalid Curve25519 public key", &random,
    2968:	b0000001 	adrp	x1, 3000 <serve_connection+0x8ac>
    296c:	91151021 	add	x1, x1, #0x544
    send_disconnect(fd, "key generation failed", &random, &state->transport);
    2970:	aa1303e3 	mov	x3, x19
    2974:	910213e2 	add	x2, sp, #0x84
    2978:	2a1503e0 	mov	w0, w21
    297c:	97fffb75 	bl	1750 <send_disconnect>
    goto out;
    2980:	17ffffa7 	b	281c <serve_connection+0xc8>
    printf("sshd: malformed KEXINIT\n");
    2984:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2988:	91133000 	add	x0, x0, #0x4cc
    298c:	14000242 	b	3294 <serve_connection+0xb40>
  if(payload_len != 1 + 4 + 32 || payload[0] != SSH_MSG_KEX_ECDH_INIT ||
    2990:	39400280 	ldrb	w0, [x20]
    2994:	7100781f 	cmp	w0, #0x1e
    2998:	54fffe21 	b.ne	295c <serve_connection+0x208>  // b.any
     get32(payload + 1) != 32)
    299c:	91000680 	add	x0, x20, #0x1
    29a0:	f90037e0 	str	x0, [sp, #104]
    29a4:	97fff9a2 	bl	102c <get32>
    29a8:	2a0003fc 	mov	w28, w0
  if(payload_len != 1 + 4 + 32 || payload[0] != SSH_MSG_KEX_ECDH_INIT ||
    29ac:	7100801f 	cmp	w0, #0x20
    29b0:	54fffd61 	b.ne	295c <serve_connection+0x208>  // b.any
  memmove(public_key, payload + 5, 32);
    29b4:	91001680 	add	x0, x20, #0x5
    29b8:	2a1c03e2 	mov	w2, w28
    29bc:	aa0003e1 	mov	x1, x0
    29c0:	f90037e0 	str	x0, [sp, #104]
    29c4:	9110e260 	add	x0, x19, #0x438
    29c8:	97fff8ea 	bl	d70 <memmove@plt>
  printf("sshd: Curve25519 client public key received (32 bytes)\n");
    29cc:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    29d0:	91139400 	add	x0, x0, #0x4e5
    29d4:	97fff8df 	bl	d50 <printf@plt>
  if(load_host_key(state->host_seed, state->host_public,
    29d8:	9112e27a 	add	x26, x19, #0x4b8
  int fd = open(path, O_RDONLY);
    29dc:	f94033e0 	ldr	x0, [sp, #96]
    29e0:	52800001 	mov	w1, #0x0                   	// #0
    29e4:	91007800 	add	x0, x0, #0x1e
    29e8:	f90033e0 	str	x0, [sp, #96]
    29ec:	97fff95d 	bl	f60 <open@plt>
    29f0:	b9006be0 	str	w0, [sp, #104]
  if(fd >= 0){
    29f4:	d0000001 	adrp	x1, 4000 <serve_connection+0x18ac>
    29f8:	912e4021 	add	x1, x1, #0xb90
    29fc:	f9003fe1 	str	x1, [sp, #120]
    2a00:	36f801c0 	tbz	w0, #31, 2a38 <serve_connection+0x2e4>
    if(ssh_random(seed, 32) < 0){
    2a04:	2a1c03e1 	mov	w1, w28
    2a08:	aa1a03e0 	mov	x0, x26
    2a0c:	97fff901 	bl	e10 <ssh_random@plt>
    2a10:	36f803a0 	tbz	w0, #31, 2a84 <serve_connection+0x330>
      printf("sshd: hardware RNG unavailable\n");
    2a14:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2a18:	91163000 	add	x0, x0, #0x58c
    2a1c:	97fff8cd 	bl	d50 <printf@plt>
    printf("sshd: key generation failed\n");
    2a20:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2a24:	9117a400 	add	x0, x0, #0x5e9
    2a28:	97fff8ca 	bl	d50 <printf@plt>
    send_disconnect(fd, "key generation failed", &random, &state->transport);
    2a2c:	b0000001 	adrp	x1, 3000 <serve_connection+0x8ac>
    2a30:	91181821 	add	x1, x1, #0x606
    2a34:	17ffffcf 	b	2970 <serve_connection+0x21c>
    int n = read(fd, seed, 32);
    2a38:	2a1c03e2 	mov	w2, w28
    2a3c:	aa1a03e1 	mov	x1, x26
    2a40:	97fff908 	bl	e60 <read@plt>
    2a44:	2a0003fc 	mov	w28, w0
    int trailing = read(fd, &extra, 1);
    2a48:	b9406be0 	ldr	w0, [sp, #104]
    2a4c:	aa1b03e1 	mov	x1, x27
    2a50:	52800022 	mov	w2, #0x1                   	// #1
    2a54:	97fff903 	bl	e60 <read@plt>
    2a58:	2a0003fb 	mov	w27, w0
    close(fd);
    2a5c:	b9406be0 	ldr	w0, [sp, #104]
    2a60:	97fff948 	bl	f80 <close@plt>
    if(n != 32 || trailing != 0){
    2a64:	7100839f 	cmp	w28, #0x20
    2a68:	7a400b60 	ccmp	w27, #0x0, #0x0, eq	// eq = none
    2a6c:	54000400 	b.eq	2aec <serve_connection+0x398>  // b.none
      printf("sshd: invalid %s (expected 32 raw bytes)\n", path);
    2a70:	f94033e1 	ldr	x1, [sp, #96]
    2a74:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2a78:	91158800 	add	x0, x0, #0x562
      printf("sshd: cannot create %s\n", path);
    2a7c:	97fff8b5 	bl	d50 <printf@plt>
      return -1;
    2a80:	17ffffe8 	b	2a20 <serve_connection+0x2cc>
    fd = open(path, O_CREATE | O_WRONLY | O_TRUNC);
    2a84:	f94033e0 	ldr	x0, [sp, #96]
    2a88:	5280c021 	mov	w1, #0x601                 	// #1537
    2a8c:	97fff935 	bl	f60 <open@plt>
    2a90:	2a0003fb 	mov	w27, w0
    if(fd < 0 || writen(fd, seed, 32) < 0){
    2a94:	37f80100 	tbnz	w0, #31, 2ab4 <serve_connection+0x360>
    2a98:	2a1c03e2 	mov	w2, w28
    2a9c:	aa1a03e1 	mov	x1, x26
    2aa0:	97fff9c2 	bl	11a8 <writen>
    2aa4:	3100041f 	cmn	w0, #0x1
        close(fd);
    2aa8:	2a1b03e0 	mov	w0, w27
    if(fd < 0 || writen(fd, seed, 32) < 0){
    2aac:	54000161 	b.ne	2ad8 <serve_connection+0x384>  // b.any
        close(fd);
    2ab0:	97fff934 	bl	f80 <close@plt>
      memset(seed, 0, 32);
    2ab4:	52800001 	mov	w1, #0x0                   	// #0
    2ab8:	aa1a03e0 	mov	x0, x26
    2abc:	52800402 	mov	w2, #0x20                  	// #32
    2ac0:	97fff908 	bl	ee0 <memset@plt>
      printf("sshd: cannot create %s\n", path);
    2ac4:	f9403fe1 	ldr	x1, [sp, #120]
    2ac8:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2acc:	9116b000 	add	x0, x0, #0x5ac
    2ad0:	91007821 	add	x1, x1, #0x1e
    2ad4:	17ffffea 	b	2a7c <serve_connection+0x328>
    close(fd);
    2ad8:	97fff92a 	bl	f80 <close@plt>
    printf("sshd: generated Ed25519 host key %s\n", path);
    2adc:	f94033e1 	ldr	x1, [sp, #96]
    2ae0:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2ae4:	91171000 	add	x0, x0, #0x5c4
    2ae8:	97fff89a 	bl	d50 <printf@plt>
                   state->host_secret) < 0 ||
    2aec:	9113e260 	add	x0, x19, #0x4f8
  if(ssh_ed25519_keypair(public_key, secret_key, seed) < 0){
    2af0:	aa1a03e2 	mov	x2, x26
    2af4:	aa0003e1 	mov	x1, x0
                   state->host_secret) < 0 ||
    2af8:	f90033e0 	str	x0, [sp, #96]
  if(ssh_ed25519_keypair(public_key, secret_key, seed) < 0){
    2afc:	91136260 	add	x0, x19, #0x4d8
    2b00:	97fff8a8 	bl	da0 <ssh_ed25519_keypair@plt>
    2b04:	36f800c0 	tbz	w0, #31, 2b1c <serve_connection+0x3c8>
    memset(seed, 0, 32);
    2b08:	aa1a03e0 	mov	x0, x26
    2b0c:	52800402 	mov	w2, #0x20                  	// #32
    2b10:	52800001 	mov	w1, #0x0                   	// #0
    2b14:	97fff8f3 	bl	ee0 <memset@plt>
    return -1;
    2b18:	17ffffc2 	b	2a20 <serve_connection+0x2cc>
     ssh_random(state->server_secret, sizeof(state->server_secret)) < 0 ||
    2b1c:	91116260 	add	x0, x19, #0x458
    2b20:	52800401 	mov	w1, #0x20                  	// #32
    2b24:	97fff8bb 	bl	e10 <ssh_random@plt>
                   state->host_secret) < 0 ||
    2b28:	37fff7c0 	tbnz	w0, #31, 2a20 <serve_connection+0x2cc>
     ssh_x25519_public(state->server_ephemeral, state->server_secret) < 0 ||
    2b2c:	9111e260 	add	x0, x19, #0x478
    2b30:	91116261 	add	x1, x19, #0x458
    2b34:	f90033e0 	str	x0, [sp, #96]
    2b38:	97fff8be 	bl	e30 <ssh_x25519_public@plt>
     ssh_random(state->server_secret, sizeof(state->server_secret)) < 0 ||
    2b3c:	37fff720 	tbnz	w0, #31, 2a20 <serve_connection+0x2cc>
     ssh_x25519(state->shared, state->server_secret,
    2b40:	9110e262 	add	x2, x19, #0x438
    2b44:	91116261 	add	x1, x19, #0x458
    2b48:	91126260 	add	x0, x19, #0x498
    2b4c:	97fff875 	bl	d20 <ssh_x25519@plt>
     ssh_x25519_public(state->server_ephemeral, state->server_secret) < 0 ||
    2b50:	37fff680 	tbnz	w0, #31, 2a20 <serve_connection+0x2cc>
  if(append_string(blob, capacity, &off, "ssh-ed25519") < 0 ||
    2b54:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2b58:	91187000 	add	x0, x0, #0x61c
    2b5c:	aa0003e3 	mov	x3, x0
    2b60:	9103a3e2 	add	x2, sp, #0xe8
    2b64:	52800801 	mov	w1, #0x40                  	// #64
    2b68:	f90037e0 	str	x0, [sp, #104]
    2b6c:	9114e260 	add	x0, x19, #0x538
  int off = 0;
    2b70:	b900ebff 	str	wzr, [sp, #232]
  if(append_string(blob, capacity, &off, "ssh-ed25519") < 0 ||
    2b74:	97fff9c8 	bl	1294 <append_string>
    2b78:	3100041f 	cmn	w0, #0x1
    2b7c:	54000b00 	b.eq	2cdc <serve_connection+0x588>  // b.none
     append_blob(blob, capacity, &off, public_key, 32) < 0)
    2b80:	91136263 	add	x3, x19, #0x4d8
    2b84:	9103a3e2 	add	x2, sp, #0xe8
    2b88:	9114e260 	add	x0, x19, #0x538
    2b8c:	52800404 	mov	w4, #0x20                  	// #32
    2b90:	52800801 	mov	w1, #0x40                  	// #64
    2b94:	97fff9df 	bl	1310 <append_blob>
  if(append_string(blob, capacity, &off, "ssh-ed25519") < 0 ||
    2b98:	3100041f 	cmn	w0, #0x1
    2b9c:	54000a00 	b.eq	2cdc <serve_connection+0x588>  // b.none
  return off;
    2ba0:	b940ebe0 	ldr	w0, [sp, #232]
    2ba4:	b90063e0 	str	w0, [sp, #96]
  if(host_blob_len < 0 ||
    2ba8:	37f809a0 	tbnz	w0, #31, 2cdc <serve_connection+0x588>
  uchar *encoded = malloc(SSH_PACKET_MAX);
    2bac:	52820000 	mov	w0, #0x1000                	// #4096
    2bb0:	97fff880 	bl	db0 <malloc@plt>
  int off = 0;
    2bb4:	b900ebff 	str	wzr, [sp, #232]
  uchar *encoded = malloc(SSH_PACKET_MAX);
    2bb8:	aa0003fa 	mov	x26, x0
  if(encoded == 0)
    2bbc:	b4000900 	cbz	x0, 2cdc <serve_connection+0x588>
                 strlen(client_ident)) < 0 ||
    2bc0:	aa1803e0 	mov	x0, x24
    2bc4:	97fff8e3 	bl	f50 <strlen@plt>
  if(append_blob(encoded, SSH_PACKET_MAX, &off, client_ident,
    2bc8:	aa1803e3 	mov	x3, x24
    2bcc:	2a0003e4 	mov	w4, w0
    2bd0:	9103a3e2 	add	x2, sp, #0xe8
    2bd4:	aa1a03e0 	mov	x0, x26
    2bd8:	52820001 	mov	w1, #0x1000                	// #4096
    2bdc:	97fff9cd 	bl	1310 <append_blob>
    2be0:	3100041f 	cmn	w0, #0x1
    2be4:	54000780 	b.eq	2cd4 <serve_connection+0x580>  // b.none
                 strlen(server_ident)) < 0 ||
    2be8:	f9403fe0 	ldr	x0, [sp, #120]
    2bec:	9100e018 	add	x24, x0, #0x38
    2bf0:	aa1803e0 	mov	x0, x24
    2bf4:	97fff8d7 	bl	f50 <strlen@plt>
     append_blob(encoded, SSH_PACKET_MAX, &off, server_ident,
    2bf8:	aa1803e3 	mov	x3, x24
    2bfc:	2a0003e4 	mov	w4, w0
    2c00:	9103a3e2 	add	x2, sp, #0xe8
    2c04:	aa1a03e0 	mov	x0, x26
    2c08:	52820001 	mov	w1, #0x1000                	// #4096
    2c0c:	97fff9c1 	bl	1310 <append_blob>
                 strlen(client_ident)) < 0 ||
    2c10:	3100041f 	cmn	w0, #0x1
    2c14:	54000600 	b.eq	2cd4 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, client_kexinit,
    2c18:	2a1903e4 	mov	w4, w25
    2c1c:	aa1703e3 	mov	x3, x23
    2c20:	9103a3e2 	add	x2, sp, #0xe8
    2c24:	aa1a03e0 	mov	x0, x26
    2c28:	52820001 	mov	w1, #0x1000                	// #4096
    2c2c:	97fff9b9 	bl	1310 <append_blob>
                 strlen(server_ident)) < 0 ||
    2c30:	3100041f 	cmn	w0, #0x1
    2c34:	54000500 	b.eq	2cd4 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, server_kexinit,
    2c38:	b94077e4 	ldr	w4, [sp, #116]
    2c3c:	aa1603e3 	mov	x3, x22
    2c40:	9103a3e2 	add	x2, sp, #0xe8
    2c44:	aa1a03e0 	mov	x0, x26
    2c48:	52820001 	mov	w1, #0x1000                	// #4096
    2c4c:	97fff9b1 	bl	1310 <append_blob>
                 client_kexinit_len) < 0 ||
    2c50:	3100041f 	cmn	w0, #0x1
    2c54:	54000400 	b.eq	2cd4 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, host_blob, host_blob_len) < 0 ||
    2c58:	b94063e4 	ldr	w4, [sp, #96]
    2c5c:	9114e263 	add	x3, x19, #0x538
    2c60:	9103a3e2 	add	x2, sp, #0xe8
    2c64:	aa1a03e0 	mov	x0, x26
    2c68:	52820001 	mov	w1, #0x1000                	// #4096
    2c6c:	97fff9a9 	bl	1310 <append_blob>
                 server_kexinit_len) < 0 ||
    2c70:	3100041f 	cmn	w0, #0x1
    2c74:	54000300 	b.eq	2cd4 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, client_ephemeral, 32) < 0 ||
    2c78:	9110e263 	add	x3, x19, #0x438
    2c7c:	9103a3e2 	add	x2, sp, #0xe8
    2c80:	aa1a03e0 	mov	x0, x26
    2c84:	52800404 	mov	w4, #0x20                  	// #32
    2c88:	52820001 	mov	w1, #0x1000                	// #4096
    2c8c:	97fff9a1 	bl	1310 <append_blob>
     append_blob(encoded, SSH_PACKET_MAX, &off, host_blob, host_blob_len) < 0 ||
    2c90:	3100041f 	cmn	w0, #0x1
    2c94:	54000200 	b.eq	2cd4 <serve_connection+0x580>  // b.none
     append_blob(encoded, SSH_PACKET_MAX, &off, server_ephemeral, 32) < 0 ||
    2c98:	9111e263 	add	x3, x19, #0x478
    2c9c:	9103a3e2 	add	x2, sp, #0xe8
    2ca0:	aa1a03e0 	mov	x0, x26
    2ca4:	52800404 	mov	w4, #0x20                  	// #32
    2ca8:	52820001 	mov	w1, #0x1000                	// #4096
    2cac:	97fff999 	bl	1310 <append_blob>
     append_blob(encoded, SSH_PACKET_MAX, &off, client_ephemeral, 32) < 0 ||
    2cb0:	3100041f 	cmn	w0, #0x1
    2cb4:	54000100 	b.eq	2cd4 <serve_connection+0x580>  // b.none
     append_shared_secret_mpint(encoded, SSH_PACKET_MAX, &off, shared) < 0){
    2cb8:	91126263 	add	x3, x19, #0x498
    2cbc:	9103a3e2 	add	x2, sp, #0xe8
    2cc0:	aa1a03e0 	mov	x0, x26
    2cc4:	52820001 	mov	w1, #0x1000                	// #4096
    2cc8:	97fff9a7 	bl	1364 <append_shared_secret_mpint>
     append_blob(encoded, SSH_PACKET_MAX, &off, server_ephemeral, 32) < 0 ||
    2ccc:	3100041f 	cmn	w0, #0x1
    2cd0:	54000121 	b.ne	2cf4 <serve_connection+0x5a0>  // b.any
    free(encoded);
    2cd4:	aa1a03e0 	mov	x0, x26
    2cd8:	97fff8ae 	bl	f90 <free@plt>
    printf("sshd: exchange hash/signature failed\n");
    2cdc:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2ce0:	9118a000 	add	x0, x0, #0x628
    2ce4:	97fff81b 	bl	d50 <printf@plt>
    send_disconnect(fd, "key exchange signing failed", &random,
    2ce8:	b0000001 	adrp	x1, 3000 <serve_connection+0x8ac>
    2cec:	91193821 	add	x1, x1, #0x64e
    2cf0:	17ffff20 	b	2970 <serve_connection+0x21c>
  int result = ssh_sha256(hash, encoded, off);
    2cf4:	b980ebe2 	ldrsw	x2, [sp, #232]
    2cf8:	aa1a03e1 	mov	x1, x26
    2cfc:	9115e260 	add	x0, x19, #0x578
    2d00:	97fff834 	bl	dd0 <ssh_sha256@plt>
    2d04:	2a0003f9 	mov	w25, w0
  memset(encoded, 0, SSH_PACKET_MAX);
    2d08:	52820002 	mov	w2, #0x1000                	// #4096
    2d0c:	52800001 	mov	w1, #0x0                   	// #0
    2d10:	aa1a03e0 	mov	x0, x26
    2d14:	97fff873 	bl	ee0 <memset@plt>
  free(encoded);
    2d18:	aa1a03e0 	mov	x0, x26
    2d1c:	97fff89d 	bl	f90 <free@plt>
  if(host_blob_len < 0 ||
    2d20:	37fffdf9 	tbnz	w25, #31, 2cdc <serve_connection+0x588>
     ssh_ed25519_sign(state->signature, state->hash,
    2d24:	9113e263 	add	x3, x19, #0x4f8
    2d28:	9115e261 	add	x1, x19, #0x578
    2d2c:	91166260 	add	x0, x19, #0x598
    2d30:	d2800402 	mov	x2, #0x20                  	// #32
    2d34:	97fff87f 	bl	f30 <ssh_ed25519_sign@plt>
                         state->server_ephemeral, state->shared) < 0 ||
    2d38:	37fffd20 	tbnz	w0, #31, 2cdc <serve_connection+0x588>
  if(append_string(signature_blob, sizeof(signature_blob), &signature_len,
    2d3c:	f94037e3 	ldr	x3, [sp, #104]
    2d40:	910263e2 	add	x2, sp, #0x98
    2d44:	9103a3e0 	add	x0, sp, #0xe8
    2d48:	52800a61 	mov	w1, #0x53                  	// #83
  int signature_len = 0, off = 0;
    2d4c:	b9009bff 	str	wzr, [sp, #152]
  if(append_string(signature_blob, sizeof(signature_blob), &signature_len,
    2d50:	97fff951 	bl	1294 <append_string>
    2d54:	3100041f 	cmn	w0, #0x1
    2d58:	54ffd620 	b.eq	281c <serve_connection+0xc8>  // b.none
     append_blob(signature_blob, sizeof(signature_blob), &signature_len,
    2d5c:	91166263 	add	x3, x19, #0x598
    2d60:	910263e2 	add	x2, sp, #0x98
    2d64:	9103a3e0 	add	x0, sp, #0xe8
    2d68:	52800804 	mov	w4, #0x40                  	// #64
    2d6c:	52800a61 	mov	w1, #0x53                  	// #83
    2d70:	97fff968 	bl	1310 <append_blob>
                   "ssh-ed25519") < 0 ||
    2d74:	3100041f 	cmn	w0, #0x1
    2d78:	54ffd520 	b.eq	281c <serve_connection+0xc8>  // b.none
  if(append_blob(reply, capacity, &off, host_blob, host_blob_len) < 0 ||
    2d7c:	b94063e4 	ldr	w4, [sp, #96]
  reply[off++] = SSH_MSG_KEX_ECDH_REPLY;
    2d80:	52800020 	mov	w0, #0x1                   	// #1
    2d84:	b900abe0 	str	w0, [sp, #168]
    2d88:	528003e0 	mov	w0, #0x1f                  	// #31
    2d8c:	39000280 	strb	w0, [x20]
  if(append_blob(reply, capacity, &off, host_blob, host_blob_len) < 0 ||
    2d90:	9114e263 	add	x3, x19, #0x538
    2d94:	9102a3e2 	add	x2, sp, #0xa8
    2d98:	aa1403e0 	mov	x0, x20
    2d9c:	52820001 	mov	w1, #0x1000                	// #4096
    2da0:	97fff95c 	bl	1310 <append_blob>
    2da4:	3100041f 	cmn	w0, #0x1
    2da8:	54ffd3a0 	b.eq	281c <serve_connection+0xc8>  // b.none
     append_blob(reply, capacity, &off, server_ephemeral, 32) < 0 ||
    2dac:	9111e263 	add	x3, x19, #0x478
    2db0:	9102a3e2 	add	x2, sp, #0xa8
    2db4:	aa1403e0 	mov	x0, x20
    2db8:	52800404 	mov	w4, #0x20                  	// #32
    2dbc:	52820001 	mov	w1, #0x1000                	// #4096
    2dc0:	97fff954 	bl	1310 <append_blob>
  if(append_blob(reply, capacity, &off, host_blob, host_blob_len) < 0 ||
    2dc4:	3100041f 	cmn	w0, #0x1
    2dc8:	54ffd2a0 	b.eq	281c <serve_connection+0xc8>  // b.none
     append_blob(reply, capacity, &off, signature_blob, signature_len) < 0)
    2dcc:	b9409be4 	ldr	w4, [sp, #152]
    2dd0:	9103a3e3 	add	x3, sp, #0xe8
    2dd4:	9102a3e2 	add	x2, sp, #0xa8
    2dd8:	aa1403e0 	mov	x0, x20
    2ddc:	52820001 	mov	w1, #0x1000                	// #4096
    2de0:	97fff94c 	bl	1310 <append_blob>
     append_blob(reply, capacity, &off, server_ephemeral, 32) < 0 ||
    2de4:	3100041f 	cmn	w0, #0x1
    2de8:	54ffd1a0 	b.eq	281c <serve_connection+0xc8>  // b.none
  return off;
    2dec:	b940abe2 	ldr	w2, [sp, #168]
  if(reply_len < 0 ||
    2df0:	37ffd162 	tbnz	w2, #31, 281c <serve_connection+0xc8>
     packet_write(fd, payload, reply_len, &random, &state->transport) < 0)
    2df4:	aa1303e4 	mov	x4, x19
    2df8:	910213e3 	add	x3, sp, #0x84
    2dfc:	aa1403e1 	mov	x1, x20
    2e00:	2a1503e0 	mov	w0, w21
    2e04:	97fff9d5 	bl	1558 <packet_write>
  if(reply_len < 0 ||
    2e08:	3100041f 	cmn	w0, #0x1
    2e0c:	54ffd080 	b.eq	281c <serve_connection+0xc8>  // b.none
  printf("sshd: sent SSH_MSG_KEX_ECDH_REPLY type=31\n");
    2e10:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2e14:	9119a800 	add	x0, x0, #0x66a
    2e18:	97fff7ce 	bl	d50 <printf@plt>
  if(derive_key(client_iv, 16, shared, hash, 'A', hash) < 0 ||
    2e1c:	9115e265 	add	x5, x19, #0x578
    2e20:	9115e263 	add	x3, x19, #0x578
    2e24:	91126262 	add	x2, x19, #0x498
    2e28:	910223e0 	add	x0, sp, #0x88
    2e2c:	52800824 	mov	w4, #0x41                  	// #65
    2e30:	52800201 	mov	w1, #0x10                  	// #16
    2e34:	97fff988 	bl	1454 <derive_key>
    2e38:	3100041f 	cmn	w0, #0x1
    2e3c:	54ffcf00 	b.eq	281c <serve_connection+0xc8>  // b.none
     derive_key(server_iv, 16, shared, hash, 'B', hash) < 0 ||
    2e40:	9115e265 	add	x5, x19, #0x578
    2e44:	9115e263 	add	x3, x19, #0x578
    2e48:	91126262 	add	x2, x19, #0x498
    2e4c:	910263e0 	add	x0, sp, #0x98
    2e50:	52800844 	mov	w4, #0x42                  	// #66
    2e54:	52800201 	mov	w1, #0x10                  	// #16
    2e58:	97fff97f 	bl	1454 <derive_key>
  if(derive_key(client_iv, 16, shared, hash, 'A', hash) < 0 ||
    2e5c:	3100041f 	cmn	w0, #0x1
    2e60:	54ffcde0 	b.eq	281c <serve_connection+0xc8>  // b.none
     derive_key(client_key, 16, shared, hash, 'C', hash) < 0 ||
    2e64:	9115e265 	add	x5, x19, #0x578
    2e68:	9115e263 	add	x3, x19, #0x578
    2e6c:	91126262 	add	x2, x19, #0x498
    2e70:	9102a3e0 	add	x0, sp, #0xa8
    2e74:	52800864 	mov	w4, #0x43                  	// #67
    2e78:	52800201 	mov	w1, #0x10                  	// #16
    2e7c:	97fff976 	bl	1454 <derive_key>
     derive_key(server_iv, 16, shared, hash, 'B', hash) < 0 ||
    2e80:	3100041f 	cmn	w0, #0x1
    2e84:	54ffccc0 	b.eq	281c <serve_connection+0xc8>  // b.none
     derive_key(server_key, 16, shared, hash, 'D', hash) < 0 ||
    2e88:	9115e265 	add	x5, x19, #0x578
    2e8c:	9115e263 	add	x3, x19, #0x578
    2e90:	91126262 	add	x2, x19, #0x498
    2e94:	9103a3e0 	add	x0, sp, #0xe8
    2e98:	52800884 	mov	w4, #0x44                  	// #68
    2e9c:	52800201 	mov	w1, #0x10                  	// #16
    2ea0:	97fff96d 	bl	1454 <derive_key>
     derive_key(client_key, 16, shared, hash, 'C', hash) < 0 ||
    2ea4:	3100041f 	cmn	w0, #0x1
    2ea8:	54ffcba0 	b.eq	281c <serve_connection+0xc8>  // b.none
     derive_key(transport->mac_in, 32, shared, hash, 'E', hash) < 0 ||
    2eac:	9115e265 	add	x5, x19, #0x578
    2eb0:	9115e263 	add	x3, x19, #0x578
    2eb4:	91126262 	add	x2, x19, #0x498
    2eb8:	91076260 	add	x0, x19, #0x1d8
    2ebc:	528008a4 	mov	w4, #0x45                  	// #69
    2ec0:	52800401 	mov	w1, #0x20                  	// #32
    2ec4:	97fff964 	bl	1454 <derive_key>
     derive_key(server_key, 16, shared, hash, 'D', hash) < 0 ||
    2ec8:	3100041f 	cmn	w0, #0x1
    2ecc:	54ffca80 	b.eq	281c <serve_connection+0xc8>  // b.none
     derive_key(transport->mac_out, 32, shared, hash, 'F', hash) < 0)
    2ed0:	9115e265 	add	x5, x19, #0x578
    2ed4:	91126262 	add	x2, x19, #0x498
    2ed8:	aa0503e3 	mov	x3, x5
    2edc:	9106e260 	add	x0, x19, #0x1b8
    2ee0:	528008c4 	mov	w4, #0x46                  	// #70
    2ee4:	52800401 	mov	w1, #0x20                  	// #32
    2ee8:	97fff95b 	bl	1454 <derive_key>
     derive_key(transport->mac_in, 32, shared, hash, 'E', hash) < 0 ||
    2eec:	3100041f 	cmn	w0, #0x1
    2ef0:	54ffc960 	b.eq	281c <serve_connection+0xc8>  // b.none
  ssh_aes128_ctr_init(&transport->cipher_in, client_key, client_iv);
    2ef4:	910223e2 	add	x2, sp, #0x88
    2ef8:	9102a3e1 	add	x1, sp, #0xa8
    2efc:	91039260 	add	x0, x19, #0xe4
    2f00:	97fff7f4 	bl	ed0 <ssh_aes128_ctr_init@plt>
  ssh_aes128_ctr_init(&transport->cipher_out, server_key, server_iv);
    2f04:	910263e2 	add	x2, sp, #0x98
    2f08:	9103a3e1 	add	x1, sp, #0xe8
    2f0c:	91004260 	add	x0, x19, #0x10
    2f10:	97fff7f0 	bl	ed0 <ssh_aes128_ctr_init@plt>
  memset(client_iv, 0, sizeof(client_iv));
    2f14:	52800202 	mov	w2, #0x10                  	// #16
    2f18:	52800001 	mov	w1, #0x0                   	// #0
    2f1c:	910223e0 	add	x0, sp, #0x88
    2f20:	97fff7f0 	bl	ee0 <memset@plt>
  memset(server_iv, 0, sizeof(server_iv));
    2f24:	52800202 	mov	w2, #0x10                  	// #16
    2f28:	52800001 	mov	w1, #0x0                   	// #0
    2f2c:	910263e0 	add	x0, sp, #0x98
    2f30:	97fff7ec 	bl	ee0 <memset@plt>
  memset(client_key, 0, sizeof(client_key));
    2f34:	52800202 	mov	w2, #0x10                  	// #16
    2f38:	52800001 	mov	w1, #0x0                   	// #0
    2f3c:	9102a3e0 	add	x0, sp, #0xa8
    2f40:	97fff7e8 	bl	ee0 <memset@plt>
  memset(server_key, 0, sizeof(server_key));
    2f44:	52800202 	mov	w2, #0x10                  	// #16
    2f48:	52800001 	mov	w1, #0x0                   	// #0
    2f4c:	9103a3e0 	add	x0, sp, #0xe8
    2f50:	97fff7e4 	bl	ee0 <memset@plt>
  payload[0] = SSH_MSG_NEWKEYS;
    2f54:	528002a0 	mov	w0, #0x15                  	// #21
    2f58:	39000280 	strb	w0, [x20]
  if(packet_write(fd, payload, 1, &random, &state->transport) < 0)
    2f5c:	aa1303e4 	mov	x4, x19
    2f60:	910213e3 	add	x3, sp, #0x84
    2f64:	aa1403e1 	mov	x1, x20
    2f68:	2a1503e0 	mov	w0, w21
    2f6c:	52800022 	mov	w2, #0x1                   	// #1
    2f70:	97fff97a 	bl	1558 <packet_write>
    2f74:	3100041f 	cmn	w0, #0x1
    2f78:	54ffc520 	b.eq	281c <serve_connection+0xc8>  // b.none
  state->transport.encrypt_out = 1;
    2f7c:	52800020 	mov	w0, #0x1                   	// #1
    2f80:	b9000a60 	str	w0, [x19, #8]
  printf("sshd: sent SSH_MSG_NEWKEYS; outbound encryption active\n");
    2f84:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2f88:	911a5400 	add	x0, x0, #0x695
    2f8c:	97fff771 	bl	d50 <printf@plt>
  n = packet_read(fd, payload, SSH_PACKET_MAX, &state->transport);
    2f90:	aa1303e2 	mov	x2, x19
    2f94:	aa1403e1 	mov	x1, x20
    2f98:	2a1503e0 	mov	w0, w21
    2f9c:	97fffa24 	bl	182c <packet_read.constprop.0>
  if(n != 1 || payload[0] != SSH_MSG_NEWKEYS){
    2fa0:	7100041f 	cmp	w0, #0x1
    2fa4:	54000081 	b.ne	2fb4 <serve_connection+0x860>  // b.any
    2fa8:	39400281 	ldrb	w1, [x20]
    2fac:	7100543f 	cmp	w1, #0x15
    2fb0:	54000080 	b.eq	2fc0 <serve_connection+0x86c>  // b.none
    printf("sshd: expected SSH_MSG_NEWKEYS\n");
    2fb4:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2fb8:	911b3400 	add	x0, x0, #0x6cd
    2fbc:	140000b6 	b	3294 <serve_connection+0xb40>
  state->transport.encrypt_in = 1;
    2fc0:	b9000e60 	str	w0, [x19, #12]
  printf("sshd: received SSH_MSG_NEWKEYS; inbound encryption active\n");
    2fc4:	b0000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    2fc8:	911bb400 	add	x0, x0, #0x6ed
    2fcc:	97fff761 	bl	d50 <printf@plt>
  n = packet_read(fd, payload, SSH_PACKET_MAX, &state->transport);
    2fd0:	aa1303e2 	mov	x2, x19
    2fd4:	aa1403e1 	mov	x1, x20
    2fd8:	2a1503e0 	mov	w0, w21
    2fdc:	97fffa14 	bl	182c <packet_read.constprop.0>
    2fe0:	2a0003f8 	mov	w24, w0
  if(n != 17 || payload[0] != SSH_MSG_SERVICE_REQUEST ||
    2fe4:	7100441f 	cmp	w0, #0x11
    2fe8:	540001c1 	b.ne	3020 <serve_connection+0x8cc>  // b.any
    2fec:	39400280 	ldrb	w0, [x20]
    2ff0:	7100141f 	cmp	w0, #0x5
    2ff4:	54000161 	b.ne	3020 <serve_connection+0x8cc>  // b.any
     get32(payload + 1) != 12 ||
    2ff8:	91000680 	add	x0, x20, #0x1
    2ffc:	97fff80c 	bl	102c <get32>
  if(n != 17 || payload[0] != SSH_MSG_SERVICE_REQUEST ||
    3000:	7100301f 	cmp	w0, #0xc
    3004:	540000e1 	b.ne	3020 <serve_connection+0x8cc>  // b.any
     memcmp(payload + 5, "ssh-userauth", 12) != 0){
    3008:	2a0003e2 	mov	w2, w0
    300c:	90000001 	adrp	x1, 3000 <serve_connection+0x8ac>
    3010:	911ca021 	add	x1, x1, #0x728
    3014:	91001680 	add	x0, x20, #0x5
    3018:	97fff7a2 	bl	ea0 <memcmp@plt>
     get32(payload + 1) != 12 ||
    301c:	34000080 	cbz	w0, 302c <serve_connection+0x8d8>
    printf("sshd: expected encrypted SSH_MSG_SERVICE_REQUEST\n");
    3020:	90000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    3024:	911cd400 	add	x0, x0, #0x735
    3028:	1400009b 	b	3294 <serve_connection+0xb40>
  payload[0] = SSH_MSG_SERVICE_ACCEPT;
    302c:	528000c0 	mov	w0, #0x6                   	// #6
    3030:	39000280 	strb	w0, [x20]
  if(packet_write(fd, payload, n, &random, &state->transport) < 0)
    3034:	aa1303e4 	mov	x4, x19
    3038:	910213e3 	add	x3, sp, #0x84
    303c:	2a1803e2 	mov	w2, w24
    3040:	aa1403e1 	mov	x1, x20
    3044:	2a1503e0 	mov	w0, w21
    3048:	97fff944 	bl	1558 <packet_write>
    304c:	3100041f 	cmn	w0, #0x1
    3050:	54ffbe60 	b.eq	281c <serve_connection+0xc8>  // b.none
  printf("sshd: encrypted transport ready; service accepted\n");
    3054:	90000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    3058:	911d9c00 	add	x0, x0, #0x767
    305c:	97fff73d 	bl	d50 <printf@plt>
  memset(home, 0, sizeof(home));
    3060:	52800802 	mov	w2, #0x40                  	// #64
    3064:	52800001 	mov	w1, #0x0                   	// #0
    3068:	9102a3e0 	add	x0, sp, #0xa8
    306c:	97fff79d 	bl	ee0 <memset@plt>
  memset(shell, 0, sizeof(shell));
    3070:	52800802 	mov	w2, #0x40                  	// #64
    3074:	52800001 	mov	w1, #0x0                   	// #0
    3078:	9103a3e0 	add	x0, sp, #0xe8
    307c:	97fff799 	bl	ee0 <memset@plt>
  if(userauth(fd, payload, &random, &state->transport, home, shell) < 0){
    3080:	9103a3e5 	add	x5, sp, #0xe8
    3084:	9102a3e4 	add	x4, sp, #0xa8
    3088:	aa1303e3 	mov	x3, x19
    308c:	910213e2 	add	x2, sp, #0x84
    3090:	aa1403e1 	mov	x1, x20
    3094:	2a1503e0 	mov	w0, w21
    3098:	97fffc9e 	bl	2310 <userauth>
    309c:	3100041f 	cmn	w0, #0x1
    30a0:	54000081 	b.ne	30b0 <serve_connection+0x95c>  // b.any
    printf("sshd: authentication failed\n");
    30a4:	90000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    30a8:	911e6800 	add	x0, x0, #0x79a
    30ac:	1400007a 	b	3294 <serve_connection+0xb40>
  if(channel_session(fd, payload, &random, &state->transport,
    30b0:	9103a3e5 	add	x5, sp, #0xe8
    30b4:	9102a3e4 	add	x4, sp, #0xa8
    30b8:	aa1303e3 	mov	x3, x19
    30bc:	910213e2 	add	x2, sp, #0x84
    30c0:	aa1403e1 	mov	x1, x20
    30c4:	2a1503e0 	mov	w0, w21
    30c8:	97fffa6e 	bl	1a80 <channel_session>
    30cc:	3100041f 	cmn	w0, #0x1
    30d0:	54ffba61 	b.ne	281c <serve_connection+0xc8>  // b.any
    printf("sshd: channel ended with protocol/I/O error\n");
    30d4:	90000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    30d8:	911edc00 	add	x0, x0, #0x7b7
    30dc:	1400006e 	b	3294 <serve_connection+0xb40>
      if(ch != '\r'){
    30e0:	2a1403e0 	mov	w0, w20
    30e4:	2a0003f4 	mov	w20, w0
      if(readn(fd, &ch, 1) < 0)
    30e8:	aa1b03e1 	mov	x1, x27
    30ec:	2a1503e0 	mov	w0, w21
    30f0:	52800022 	mov	w2, #0x1                   	// #1
    30f4:	97fff846 	bl	120c <readn>
    30f8:	3100041f 	cmn	w0, #0x1
    30fc:	54ffb840 	b.eq	2804 <serve_connection+0xb0>  // b.none
      if(ch == 0)
    3100:	3943a3e1 	ldrb	w1, [sp, #232]
    3104:	34ffb801 	cbz	w1, 2804 <serve_connection+0xb0>
      if(ch == '\n')
    3108:	7100283f 	cmp	w1, #0xa
    310c:	54ffb740 	b.eq	27f4 <serve_connection+0xa0>  // b.none
      if(ch != '\r'){
    3110:	7100343f 	cmp	w1, #0xd
    3114:	54fffe60 	b.eq	30e0 <serve_connection+0x98c>  // b.none
        ident[n++] = ch;
    3118:	38344b01 	strb	w1, [x24, w20, uxtw]
        if(n + 1 >= size)
    311c:	11000680 	add	w0, w20, #0x1
    while(n < 255){
    3120:	7103fa9f 	cmp	w20, #0xfe
    3124:	54fffe01 	b.ne	30e4 <serve_connection+0x990>  // b.any
  while(*prefix)
    3128:	90000001 	adrp	x1, 3000 <serve_connection+0x8ac>
    312c:	9110cc21 	add	x1, x1, #0x433
    ident[n] = 0;
    3130:	38204b1f 	strb	wzr, [x24, w0, uxtw]
    3134:	d2800000 	mov	x0, #0x0                   	// #0
    if(*s++ != *prefix++)
    3138:	38606b03 	ldrb	w3, [x24, x0]
    313c:	38606822 	ldrb	w2, [x1, x0]
    3140:	6b02007f 	cmp	w3, w2
    3144:	54ffb5c1 	b.ne	27fc <serve_connection+0xa8>  // b.any
    3148:	91000400 	add	x0, x0, #0x1
  while(*prefix)
    314c:	f100101f 	cmp	x0, #0x4
    3150:	54ffff41 	b.ne	3138 <serve_connection+0x9e4>  // b.any
    3154:	90000001 	adrp	x1, 3000 <serve_connection+0x8ac>
    3158:	9110e021 	add	x1, x1, #0x438
    315c:	d2800000 	mov	x0, #0x0                   	// #0
    if(*s++ != *prefix++)
    3160:	38606b03 	ldrb	w3, [x24, x0]
    3164:	38606822 	ldrb	w2, [x1, x0]
    3168:	6b02007f 	cmp	w3, w2
    316c:	54ffb4c1 	b.ne	2804 <serve_connection+0xb0>  // b.any
    3170:	91000400 	add	x0, x0, #0x1
  while(*prefix)
    3174:	f100201f 	cmp	x0, #0x8
    3178:	54ffff41 	b.ne	3160 <serve_connection+0xa0c>  // b.any
  printf("sshd: client %s\n", state->client_ident);
    317c:	aa1803e1 	mov	x1, x24
    3180:	90000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    3184:	911f9000 	add	x0, x0, #0x7e4
    3188:	97fff6f2 	bl	d50 <printf@plt>
  payload = malloc(SSH_PACKET_MAX);
    318c:	52820000 	mov	w0, #0x1000                	// #4096
    3190:	97fff708 	bl	db0 <malloc@plt>
    3194:	aa0003f4 	mov	x20, x0
  client_kexinit = malloc(SSH_PACKET_MAX);
    3198:	52820000 	mov	w0, #0x1000                	// #4096
    319c:	97fff705 	bl	db0 <malloc@plt>
    31a0:	aa0003f7 	mov	x23, x0
  server_kexinit = malloc(SSH_PACKET_MAX);
    31a4:	52820000 	mov	w0, #0x1000                	// #4096
    31a8:	97fff702 	bl	db0 <malloc@plt>
    31ac:	aa0003f6 	mov	x22, x0
  if(payload == 0 || client_kexinit == 0 || server_kexinit == 0)
    31b0:	f100029f 	cmp	x20, #0x0
    31b4:	fa401ae4 	ccmp	x23, #0x0, #0x4, ne	// ne = any
    31b8:	54ffb320 	b.eq	281c <serve_connection+0xc8>  // b.none
    31bc:	b4ffb316 	cbz	x22, 281c <serve_connection+0xc8>
  p[off++] = SSH_MSG_KEXINIT;
    31c0:	aa1603e0 	mov	x0, x22
    31c4:	52800281 	mov	w1, #0x14                  	// #20
    31c8:	38001401 	strb	w1, [x0], #1
  if(ssh_random(p + off, 16) < 0)
    31cc:	52800201 	mov	w1, #0x10                  	// #16
    31d0:	97fff710 	bl	e10 <ssh_random@plt>
    31d4:	37ffb240 	tbnz	w0, #31, 281c <serve_connection+0xc8>
  off += 16;
    31d8:	52800220 	mov	w0, #0x11                  	// #17
  char *lists[] = {
    31dc:	90000001 	adrp	x1, 3000 <serve_connection+0x8ac>
    31e0:	91220021 	add	x1, x1, #0x880
    31e4:	d2800a02 	mov	x2, #0x50                  	// #80
    31e8:	d2800019 	mov	x25, #0x0                   	// #0
  off += 16;
    31ec:	b900abe0 	str	w0, [sp, #168]
  char *lists[] = {
    31f0:	aa1b03e0 	mov	x0, x27
    31f4:	97fff6e7 	bl	d90 <memcpy@plt>
    if(append_string(p, capacity, &off, lists[i]) < 0)
    31f8:	f8797b63 	ldr	x3, [x27, x25, lsl #3]
    31fc:	9102a3e2 	add	x2, sp, #0xa8
    3200:	aa1603e0 	mov	x0, x22
    3204:	52820001 	mov	w1, #0x1000                	// #4096
    3208:	97fff823 	bl	1294 <append_string>
    320c:	3100041f 	cmn	w0, #0x1
    3210:	54ffb060 	b.eq	281c <serve_connection+0xc8>  // b.none
  for(int i = 0; i < 10; i++)
    3214:	91000739 	add	x25, x25, #0x1
    3218:	f1002b3f 	cmp	x25, #0xa
    321c:	54fffee1 	b.ne	31f8 <serve_connection+0xaa4>  // b.any
  if(off + 5 > capacity)
    3220:	b940abe0 	ldr	w0, [sp, #168]
    3224:	713fec1f 	cmp	w0, #0xffb
    3228:	54ffafac 	b.gt	281c <serve_connection+0xc8>
  p[off++] = 0;                 // first_kex_packet_follows = false
    322c:	11000401 	add	w1, w0, #0x1
    3230:	3820cadf 	strb	wzr, [x22, w0, sxtw]
  if(server_kexinit_len < 0 ||
    3234:	31001400 	adds	w0, w0, #0x5
    3238:	b90077e0 	str	w0, [sp, #116]
  p[0] = v >> 24;
    323c:	b821cadf 	str	wzr, [x22, w1, sxtw]
  if(server_kexinit_len < 0 ||
    3240:	54ffaee4 	b.mi	281c <serve_connection+0xc8>  // b.first
     packet_write(fd, server_kexinit, server_kexinit_len, &random,
    3244:	2a0003e2 	mov	w2, w0
    3248:	aa1303e4 	mov	x4, x19
    324c:	910213e3 	add	x3, sp, #0x84
    3250:	aa1603e1 	mov	x1, x22
    3254:	2a1503e0 	mov	w0, w21
    3258:	97fff8c0 	bl	1558 <packet_write>
  if(server_kexinit_len < 0 ||
    325c:	3100041f 	cmn	w0, #0x1
    3260:	54ffade0 	b.eq	281c <serve_connection+0xc8>  // b.none
  n = packet_read(fd, payload, SSH_PACKET_MAX, &state->transport);
    3264:	aa1303e2 	mov	x2, x19
    3268:	aa1403e1 	mov	x1, x20
    326c:	2a1503e0 	mov	w0, w21
    3270:	97fff96f 	bl	182c <packet_read.constprop.0>
    3274:	2a0003f9 	mov	w25, w0
  if(n < 0 || payload[0] != SSH_MSG_KEXINIT){
    3278:	3100041f 	cmn	w0, #0x1
    327c:	54000080 	b.eq	328c <serve_connection+0xb38>  // b.none
    3280:	39400280 	ldrb	w0, [x20]
    3284:	7100501f 	cmp	w0, #0x14
    3288:	54ffaf40 	b.eq	2870 <serve_connection+0x11c>  // b.none
    printf("sshd: expected SSH_MSG_KEXINIT\n");
    328c:	90000000 	adrp	x0, 3000 <serve_connection+0x8ac>
    3290:	91119800 	add	x0, x0, #0x466
    printf("sshd: channel ended with protocol/I/O error\n");
    3294:	97fff6af 	bl	d50 <printf@plt>
    3298:	17fffd61 	b	281c <serve_connection+0xc8>
