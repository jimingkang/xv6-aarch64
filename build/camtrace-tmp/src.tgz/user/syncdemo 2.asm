
user/_syncdemo:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000428 <.plt>:
 428:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 42c:	b0000010 	adrp	x16, 1000 <main+0xb18>
 430:	f943fe11 	ldr	x17, [x16, #2040]
 434:	911fe210 	add	x16, x16, #0x7f8
 438:	d61f0220 	br	x17
 43c:	d503201f 	nop
 440:	d503201f 	nop
 444:	d503201f 	nop

0000000000000448 <printf@plt>:
 448:	b0000010 	adrp	x16, 1000 <main+0xb18>
 44c:	f9440211 	ldr	x17, [x16, #2048]
 450:	91200210 	add	x16, x16, #0x800
 454:	d61f0220 	br	x17

0000000000000458 <sync_destroy@plt>:
 458:	b0000010 	adrp	x16, 1000 <main+0xb18>
 45c:	f9440611 	ldr	x17, [x16, #2056]
 460:	91202210 	add	x16, x16, #0x808
 464:	d61f0220 	br	x17

0000000000000468 <wait@plt>:
 468:	b0000010 	adrp	x16, 1000 <main+0xb18>
 46c:	f9440a11 	ldr	x17, [x16, #2064]
 470:	91204210 	add	x16, x16, #0x810
 474:	d61f0220 	br	x17

0000000000000478 <sync_create@plt>:
 478:	b0000010 	adrp	x16, 1000 <main+0xb18>
 47c:	f9440e11 	ldr	x17, [x16, #2072]
 480:	91206210 	add	x16, x16, #0x818
 484:	d61f0220 	br	x17

0000000000000488 <sync_atomic@plt>:
 488:	b0000010 	adrp	x16, 1000 <main+0xb18>
 48c:	f9441211 	ldr	x17, [x16, #2080]
 490:	91208210 	add	x16, x16, #0x820
 494:	d61f0220 	br	x17

0000000000000498 <fork@plt>:
 498:	b0000010 	adrp	x16, 1000 <main+0xb18>
 49c:	f9441611 	ldr	x17, [x16, #2088]
 4a0:	9120a210 	add	x16, x16, #0x828
 4a4:	d61f0220 	br	x17

00000000000004a8 <exit@plt>:
 4a8:	b0000010 	adrp	x16, 1000 <main+0xb18>
 4ac:	f9441a11 	ldr	x17, [x16, #2096]
 4b0:	9120c210 	add	x16, x16, #0x830
 4b4:	d61f0220 	br	x17

00000000000004b8 <sync_signal@plt>:
 4b8:	b0000010 	adrp	x16, 1000 <main+0xb18>
 4bc:	f9441e11 	ldr	x17, [x16, #2104]
 4c0:	9120e210 	add	x16, x16, #0x838
 4c4:	d61f0220 	br	x17

00000000000004c8 <sync_reset@plt>:
 4c8:	b0000010 	adrp	x16, 1000 <main+0xb18>
 4cc:	f9442211 	ldr	x17, [x16, #2112]
 4d0:	91210210 	add	x16, x16, #0x840
 4d4:	d61f0220 	br	x17

00000000000004d8 <sync_wait@plt>:
 4d8:	b0000010 	adrp	x16, 1000 <main+0xb18>
 4dc:	f9442611 	ldr	x17, [x16, #2120]
 4e0:	91212210 	add	x16, x16, #0x848
 4e4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000004e8 <main>:
#include "user/user.h"
#include "user/sync.h"

int
main(void)
{
 4e8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
static inline int mutex_init(mutex_t *m) { return (*m = sync_create(SYNC_MUTEX, 1)) < 0 ? -1 : 0; }
static inline int mutex_lock(mutex_t *m) { return sync_wait(*m); }
static inline int mutex_unlock(mutex_t *m) { return sync_signal(*m, 1); }
static inline int mutex_destroy(mutex_t *m) { return sync_destroy(*m); }

static inline int sem_init(semaphore_t *s, int value) { return (*s = sync_create(SYNC_SEM, value)) < 0 ? -1 : 0; }
 4ec:	52800001 	mov	w1, #0x0                   	// #0
 4f0:	52800040 	mov	w0, #0x2                   	// #2
 4f4:	910003fd 	mov	x29, sp
 4f8:	a90153f3 	stp	x19, x20, [sp, #16]
 4fc:	a9025bf5 	stp	x21, x22, [sp, #32]
 500:	97ffffde 	bl	478 <sync_create@plt>
 504:	36f800c0 	tbz	w0, #31, 51c <main+0x34>
  katomic_t counter;
  int i, pid;

  if(sem_init(&done, 0) < 0 || event_init(&start, 0) < 0 ||
     katomic_init(&counter, 0) < 0){
    printf("syncdemo: create failed\n");
 508:	90000000 	adrp	x0, 0 <.plt-0x428>
 50c:	9118e000 	add	x0, x0, #0x638
      katomic_fetch_add(&counter, 1);
      sem_post(&done);
      exit(0);
    }
    if(pid < 0){
      printf("syncdemo: fork failed\n");
 510:	97ffffce 	bl	448 <printf@plt>
      exit(1);
 514:	52800020 	mov	w0, #0x1                   	// #1
 518:	1400001a 	b	580 <main+0x98>
 51c:	2a0003f3 	mov	w19, w0
static inline int sem_post(semaphore_t *s) { return sync_signal(*s, 1); }
static inline int sem_post_n(semaphore_t *s, int n) { return sync_signal(*s, n); }
static inline int sem_destroy(semaphore_t *s) { return sync_destroy(*s); }

// Manual-reset event: notify wakes all present/future waiters until reset.
static inline int event_init(event_t *e, int signaled) { return (*e = sync_create(SYNC_EVENT, signaled)) < 0 ? -1 : 0; }
 520:	52800001 	mov	w1, #0x0                   	// #0
 524:	52800060 	mov	w0, #0x3                   	// #3
 528:	97ffffd4 	bl	478 <sync_create@plt>
 52c:	2a0003f4 	mov	w20, w0
 530:	37fffec0 	tbnz	w0, #31, 508 <main+0x20>
static inline int event_notify(event_t *e) { return sync_signal(*e, 1); }
static inline int event_signal(event_t *e) { return sync_signal(*e, 1); }
static inline int event_reset(event_t *e) { return sync_reset(*e); }
static inline int event_destroy(event_t *e) { return sync_destroy(*e); }

static inline int katomic_init(katomic_t *a, int value) { return (*a = sync_create(SYNC_ATOMIC, value)) < 0 ? -1 : 0; }
 534:	52800001 	mov	w1, #0x0                   	// #0
 538:	52800080 	mov	w0, #0x4                   	// #4
 53c:	97ffffcf 	bl	478 <sync_create@plt>
 540:	2a0003f5 	mov	w21, w0
 544:	37fffe20 	tbnz	w0, #31, 508 <main+0x20>
 548:	52800076 	mov	w22, #0x3                   	// #3
    pid = fork();
 54c:	97ffffd3 	bl	498 <fork@plt>
    if(pid == 0){
 550:	350001a0 	cbnz	w0, 584 <main+0x9c>
static inline int sem_wait(semaphore_t *s) { return sync_wait(*s); }
 554:	2a1403e0 	mov	w0, w20
 558:	97ffffe0 	bl	4d8 <sync_wait@plt>
static inline int katomic_load(katomic_t *a) { return sync_atomic(*a, ATOMIC_LOAD, 0, 0); }
static inline int katomic_store(katomic_t *a, int value) { return sync_atomic(*a, ATOMIC_STORE, value, 0); }
static inline int katomic_fetch_add(katomic_t *a, int value) { return sync_atomic(*a, ATOMIC_FETCH_ADD, value, 0); }
 55c:	52800003 	mov	w3, #0x0                   	// #0
 560:	52800022 	mov	w2, #0x1                   	// #1
 564:	52800061 	mov	w1, #0x3                   	// #3
 568:	2a1503e0 	mov	w0, w21
 56c:	97ffffc7 	bl	488 <sync_atomic@plt>
static inline int sem_post(semaphore_t *s) { return sync_signal(*s, 1); }
 570:	2a1303e0 	mov	w0, w19
 574:	52800021 	mov	w1, #0x1                   	// #1
 578:	97ffffd0 	bl	4b8 <sync_signal@plt>
      exit(0);
 57c:	52800000 	mov	w0, #0x0                   	// #0
 580:	97ffffca 	bl	4a8 <exit@plt>
    if(pid < 0){
 584:	36f80080 	tbz	w0, #31, 594 <main+0xac>
      printf("syncdemo: fork failed\n");
 588:	90000000 	adrp	x0, 0 <.plt-0x428>
 58c:	91194400 	add	x0, x0, #0x651
 590:	17ffffe0 	b	510 <main+0x28>
  for(i = 0; i < 3; i++){
 594:	710006d6 	subs	w22, w22, #0x1
 598:	54fffda1 	b.ne	54c <main+0x64>  // b.any
    }
  }

  printf("syncdemo: notify children\n");
 59c:	90000000 	adrp	x0, 0 <.plt-0x428>
 5a0:	9119a000 	add	x0, x0, #0x668
 5a4:	97ffffa9 	bl	448 <printf@plt>
 5a8:	52800021 	mov	w1, #0x1                   	// #1
 5ac:	2a1403e0 	mov	w0, w20
 5b0:	97ffffc2 	bl	4b8 <sync_signal@plt>
static inline int sem_wait(semaphore_t *s) { return sync_wait(*s); }
 5b4:	2a1303e0 	mov	w0, w19
 5b8:	97ffffc8 	bl	4d8 <sync_wait@plt>
 5bc:	2a1303e0 	mov	w0, w19
 5c0:	97ffffc6 	bl	4d8 <sync_wait@plt>
 5c4:	2a1303e0 	mov	w0, w19
 5c8:	97ffffc4 	bl	4d8 <sync_wait@plt>
static inline int katomic_load(katomic_t *a) { return sync_atomic(*a, ATOMIC_LOAD, 0, 0); }
 5cc:	52800021 	mov	w1, #0x1                   	// #1
 5d0:	52800003 	mov	w3, #0x0                   	// #0
 5d4:	52800002 	mov	w2, #0x0                   	// #0
 5d8:	2a1503e0 	mov	w0, w21
 5dc:	97ffffab 	bl	488 <sync_atomic@plt>
 5e0:	2a0003e1 	mov	w1, w0
  event_notify(&start);
  for(i = 0; i < 3; i++)
    sem_wait(&done);
  printf("syncdemo: atomic counter=%d (expected 3)\n",
 5e4:	90000000 	adrp	x0, 0 <.plt-0x428>
 5e8:	911a0c00 	add	x0, x0, #0x683
 5ec:	97ffff97 	bl	448 <printf@plt>
         katomic_load(&counter));
  for(i = 0; i < 3; i++)
    wait(0);
 5f0:	d2800000 	mov	x0, #0x0                   	// #0
 5f4:	97ffff9d 	bl	468 <wait@plt>
 5f8:	d2800000 	mov	x0, #0x0                   	// #0
 5fc:	97ffff9b 	bl	468 <wait@plt>
 600:	d2800000 	mov	x0, #0x0                   	// #0
 604:	97ffff99 	bl	468 <wait@plt>
static inline int event_reset(event_t *e) { return sync_reset(*e); }
 608:	2a1403e0 	mov	w0, w20
 60c:	97ffffaf 	bl	4c8 <sync_reset@plt>
static inline int sem_destroy(semaphore_t *s) { return sync_destroy(*s); }
 610:	2a1403e0 	mov	w0, w20
 614:	97ffff91 	bl	458 <sync_destroy@plt>
 618:	2a1303e0 	mov	w0, w19
 61c:	97ffff8f 	bl	458 <sync_destroy@plt>
 620:	2a1503e0 	mov	w0, w21
 624:	97ffff8d 	bl	458 <sync_destroy@plt>

  event_reset(&start);
  event_destroy(&start);
  sem_destroy(&done);
  katomic_destroy(&counter);
  printf("syncdemo: ok\n");
 628:	90000000 	adrp	x0, 0 <.plt-0x428>
 62c:	911ab400 	add	x0, x0, #0x6ad
 630:	97ffff86 	bl	448 <printf@plt>
  exit(0);
 634:	17ffffd2 	b	57c <main+0x94>
