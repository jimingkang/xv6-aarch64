
user/_renice:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002f0 <.plt>:
 2f0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2f4:	b0000010 	adrp	x16, 1000 <parse_num+0xbec>
 2f8:	f9435a11 	ldr	x17, [x16, #1712]
 2fc:	911ac210 	add	x16, x16, #0x6b0
 300:	d61f0220 	br	x17
 304:	d503201f 	nop
 308:	d503201f 	nop
 30c:	d503201f 	nop

0000000000000310 <printf@plt>:
 310:	b0000010 	adrp	x16, 1000 <parse_num+0xbec>
 314:	f9435e11 	ldr	x17, [x16, #1720]
 318:	911ae210 	add	x16, x16, #0x6b8
 31c:	d61f0220 	br	x17

0000000000000320 <fprintf@plt>:
 320:	b0000010 	adrp	x16, 1000 <parse_num+0xbec>
 324:	f9436211 	ldr	x17, [x16, #1728]
 328:	911b0210 	add	x16, x16, #0x6c0
 32c:	d61f0220 	br	x17

0000000000000330 <sched_getinfo@plt>:
 330:	b0000010 	adrp	x16, 1000 <parse_num+0xbec>
 334:	f9436611 	ldr	x17, [x16, #1736]
 338:	911b2210 	add	x16, x16, #0x6c8
 33c:	d61f0220 	br	x17

0000000000000340 <setnice@plt>:
 340:	b0000010 	adrp	x16, 1000 <parse_num+0xbec>
 344:	f9436a11 	ldr	x17, [x16, #1744]
 348:	911b4210 	add	x16, x16, #0x6d0
 34c:	d61f0220 	br	x17

0000000000000350 <exit@plt>:
 350:	b0000010 	adrp	x16, 1000 <parse_num+0xbec>
 354:	f9436e11 	ldr	x17, [x16, #1752]
 358:	911b6210 	add	x16, x16, #0x6d8
 35c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000360 <main>:
#include "user/user.h"
#include "user/schedutil.h"

int
main(int argc, char *argv[])
{
 360:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 364:	910003fd 	mov	x29, sp
 368:	a90153f3 	stp	x19, x20, [sp, #16]
  int n, pid;
  struct sched_info si;

  if(argc != 3 || !parse_num(argv[1], &n) || !parse_num(argv[2], &pid)){
 36c:	71000c1f 	cmp	w0, #0x3
 370:	54000141 	b.ne	398 <main+0x38>  // b.any
 374:	aa0103e7 	mov	x7, x1
 378:	910083e1 	add	x1, sp, #0x20
 37c:	f94004e0 	ldr	x0, [x7, #8]
 380:	94000025 	bl	414 <parse_num>
 384:	340000a0 	cbz	w0, 398 <main+0x38>
 388:	f94008e0 	ldr	x0, [x7, #16]
 38c:	910093e1 	add	x1, sp, #0x24
 390:	94000021 	bl	414 <parse_num>
 394:	350000e0 	cbnz	w0, 3b0 <main+0x50>
    fprintf(2, "usage: renice N PID\n");
 398:	90000001 	adrp	x1, 0 <.plt-0x2f0>
 39c:	91141021 	add	x1, x1, #0x504
 3a0:	52800040 	mov	w0, #0x2                   	// #2
 3a4:	97ffffdf 	bl	320 <fprintf@plt>
    exit(1);
  }
  if(sched_getinfo(pid, &si) < 0 || setnice(pid, n) < 0){
    fprintf(2, "renice: failed to set pid %d to nice %d\n", pid, n);
    exit(1);
 3a8:	52800020 	mov	w0, #0x1                   	// #1
 3ac:	97ffffe9 	bl	350 <exit@plt>
  if(sched_getinfo(pid, &si) < 0 || setnice(pid, n) < 0){
 3b0:	b94027f3 	ldr	w19, [sp, #36]
 3b4:	9100a3e1 	add	x1, sp, #0x28
 3b8:	2a1303e0 	mov	w0, w19
 3bc:	97ffffdd 	bl	330 <sched_getinfo@plt>
 3c0:	b94023f4 	ldr	w20, [sp, #32]
 3c4:	37f800a0 	tbnz	w0, #31, 3d8 <main+0x78>
 3c8:	2a1403e1 	mov	w1, w20
 3cc:	2a1303e0 	mov	w0, w19
 3d0:	97ffffdc 	bl	340 <setnice@plt>
 3d4:	36f80100 	tbz	w0, #31, 3f4 <main+0x94>
    fprintf(2, "renice: failed to set pid %d to nice %d\n", pid, n);
 3d8:	2a1403e3 	mov	w3, w20
 3dc:	2a1303e2 	mov	w2, w19
 3e0:	90000001 	adrp	x1, 0 <.plt-0x2f0>
 3e4:	91146421 	add	x1, x1, #0x519
 3e8:	52800040 	mov	w0, #0x2                   	// #2
 3ec:	97ffffcd 	bl	320 <fprintf@plt>
 3f0:	17ffffee 	b	3a8 <main+0x48>
  }
  printf("%d (process ID) old priority %d, new priority %d\n", pid, si.nice, n);
 3f4:	b94037e2 	ldr	w2, [sp, #52]
 3f8:	2a1403e3 	mov	w3, w20
 3fc:	2a1303e1 	mov	w1, w19
 400:	90000000 	adrp	x0, 0 <.plt-0x2f0>
 404:	91150800 	add	x0, x0, #0x542
 408:	97ffffc2 	bl	310 <printf@plt>
  exit(0);
 40c:	52800000 	mov	w0, #0x0                   	// #0
 410:	17ffffe7 	b	3ac <main+0x4c>

0000000000000414 <parse_num>:

// Parse decimal (optionally negative) or 0x-prefixed hex.  Returns 1 with
// *out set, or 0 on a malformed number.
static __attribute__((unused)) int
parse_num(const char *s, int *out)
{
 414:	aa0003e2 	mov	x2, x0
  int neg = 0, v = 0, any = 0;

  if(*s == '-'){
 418:	39400000 	ldrb	w0, [x0]
 41c:	7100b41f 	cmp	w0, #0x2d
 420:	540002c1 	b.ne	478 <parse_num+0x64>  // b.any
    neg = 1;
    s++;
 424:	91000442 	add	x2, x2, #0x1
    neg = 1;
 428:	52800025 	mov	w5, #0x1                   	// #1
  }
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 42c:	39400040 	ldrb	w0, [x2]
 430:	7100c01f 	cmp	w0, #0x30
 434:	540000c1 	b.ne	44c <parse_num+0x38>  // b.any
 438:	39400440 	ldrb	w0, [x2, #1]
 43c:	121a7800 	and	w0, w0, #0xffffffdf
 440:	12001c00 	and	w0, w0, #0xff
 444:	7101601f 	cmp	w0, #0x58
 448:	540001c0 	b.eq	480 <parse_num+0x6c>  // b.none
 44c:	52800000 	mov	w0, #0x0                   	// #0
 450:	52800003 	mov	w3, #0x0                   	// #0
    }
  } else {
    for(; *s; s++, any = 1){
      if(*s < '0' || *s > '9')
        return 0;
      v = v * 10 + (*s - '0');
 454:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
 458:	39400044 	ldrb	w4, [x2]
 45c:	340001c4 	cbz	w4, 494 <parse_num+0x80>
      if(*s < '0' || *s > '9')
 460:	5100c084 	sub	w4, w4, #0x30
 464:	12001c80 	and	w0, w4, #0xff
 468:	7100241f 	cmp	w0, #0x9
 46c:	54000449 	b.ls	4f4 <parse_num+0xe0>  // b.plast
      else return 0;
 470:	52800000 	mov	w0, #0x0                   	// #0
  }
  if(!any)
    return 0;
  *out = neg ? -v : v;
  return 1;
}
 474:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
 478:	52800005 	mov	w5, #0x0                   	// #0
 47c:	17ffffec 	b	42c <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
 480:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
 484:	52800000 	mov	w0, #0x0                   	// #0
 488:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 48c:	39400044 	ldrb	w4, [x2]
 490:	350000c4 	cbnz	w4, 4a8 <parse_num+0x94>
  if(!any)
 494:	34ffff00 	cbz	w0, 474 <parse_num+0x60>
  *out = neg ? -v : v;
 498:	710000bf 	cmp	w5, #0x0
 49c:	5a830463 	cneg	w3, w3, ne	// ne = any
 4a0:	b9000023 	str	w3, [x1]
  return 1;
 4a4:	17fffff4 	b	474 <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 4a8:	5100c080 	sub	w0, w4, #0x30
 4ac:	12001c06 	and	w6, w0, #0xff
 4b0:	710024df 	cmp	w6, #0x9
 4b4:	540000c9 	b.ls	4cc <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 4b8:	51018480 	sub	w0, w4, #0x61
 4bc:	12001c00 	and	w0, w0, #0xff
 4c0:	7100141f 	cmp	w0, #0x5
 4c4:	540000c8 	b.hi	4dc <parse_num+0xc8>  // b.pmore
 4c8:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
 4cc:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
 4d0:	91000442 	add	x2, x2, #0x1
 4d4:	52800020 	mov	w0, #0x1                   	// #1
 4d8:	17ffffed 	b	48c <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 4dc:	51010480 	sub	w0, w4, #0x41
 4e0:	12001c00 	and	w0, w0, #0xff
 4e4:	7100141f 	cmp	w0, #0x5
 4e8:	54fffc48 	b.hi	470 <parse_num+0x5c>  // b.pmore
 4ec:	5100dc80 	sub	w0, w4, #0x37
 4f0:	17fffff7 	b	4cc <parse_num+0xb8>
      v = v * 10 + (*s - '0');
 4f4:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
 4f8:	91000442 	add	x2, x2, #0x1
 4fc:	52800020 	mov	w0, #0x1                   	// #1
 500:	17ffffd6 	b	458 <parse_num+0x44>
