
user/_ptytest:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000360 <.plt>:
 360:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 364:	b0000010 	adrp	x16, 1000 <main+0xc10>
 368:	f943ea11 	ldr	x17, [x16, #2000]
 36c:	911f4210 	add	x16, x16, #0x7d0
 370:	d61f0220 	br	x17
 374:	d503201f 	nop
 378:	d503201f 	nop
 37c:	d503201f 	nop

0000000000000380 <printf@plt>:
 380:	b0000010 	adrp	x16, 1000 <main+0xc10>
 384:	f943ee11 	ldr	x17, [x16, #2008]
 388:	911f6210 	add	x16, x16, #0x7d8
 38c:	d61f0220 	br	x17

0000000000000390 <write@plt>:
 390:	b0000010 	adrp	x16, 1000 <main+0xc10>
 394:	f943f211 	ldr	x17, [x16, #2016]
 398:	911f8210 	add	x16, x16, #0x7e0
 39c:	d61f0220 	br	x17

00000000000003a0 <read@plt>:
 3a0:	b0000010 	adrp	x16, 1000 <main+0xc10>
 3a4:	f943f611 	ldr	x17, [x16, #2024]
 3a8:	911fa210 	add	x16, x16, #0x7e8
 3ac:	d61f0220 	br	x17

00000000000003b0 <memcmp@plt>:
 3b0:	b0000010 	adrp	x16, 1000 <main+0xc10>
 3b4:	f943fa11 	ldr	x17, [x16, #2032]
 3b8:	911fc210 	add	x16, x16, #0x7f0
 3bc:	d61f0220 	br	x17

00000000000003c0 <pty_open@plt>:
 3c0:	b0000010 	adrp	x16, 1000 <main+0xc10>
 3c4:	f943fe11 	ldr	x17, [x16, #2040]
 3c8:	911fe210 	add	x16, x16, #0x7f8
 3cc:	d61f0220 	br	x17

00000000000003d0 <exit@plt>:
 3d0:	b0000010 	adrp	x16, 1000 <main+0xc10>
 3d4:	f9440211 	ldr	x17, [x16, #2048]
 3d8:	91200210 	add	x16, x16, #0x800
 3dc:	d61f0220 	br	x17

00000000000003e0 <close@plt>:
 3e0:	b0000010 	adrp	x16, 1000 <main+0xc10>
 3e4:	f9440611 	ldr	x17, [x16, #2056]
 3e8:	91202210 	add	x16, x16, #0x808
 3ec:	d61f0220 	br	x17

Disassembly of section .text:

00000000000003f0 <main>:

// Kernel PTY smoke test. It verifies both independent byte streams without
// depending on SSH framing or cryptography.
int
main(void)
{
 3f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 3f4:	910003fd 	mov	x29, sp
  int fd[2];
  char buf[32];
  int n;

  if(pty_open(fd) < 0){
 3f8:	9100a3e0 	add	x0, sp, #0x28
{
 3fc:	a90153f3 	stp	x19, x20, [sp, #16]
  if(pty_open(fd) < 0){
 400:	97fffff0 	bl	3c0 <pty_open@plt>
 404:	36f800c0 	tbz	w0, #31, 41c <main+0x2c>
    printf("ptytest: pty_open failed\n");
 408:	90000000 	adrp	x0, 0 <.plt-0x360>
 40c:	9116a000 	add	x0, x0, #0x5a8
    exit(1);
  }
  if(write(fd[0], "input-to-slave\n", 15) != 15 ||
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
     memcmp(buf, "input-to-slave\n", 15) != 0){
    printf("ptytest: master-to-slave failed\n");
 410:	97ffffdc 	bl	380 <printf@plt>
    exit(1);
 414:	52800020 	mov	w0, #0x1                   	// #1
 418:	97ffffee 	bl	3d0 <exit@plt>
  if(write(fd[0], "input-to-slave\n", 15) != 15 ||
 41c:	b9402be0 	ldr	w0, [sp, #40]
 420:	90000013 	adrp	x19, 0 <.plt-0x360>
 424:	528001e2 	mov	w2, #0xf                   	// #15
 428:	91170a61 	add	x1, x19, #0x5c2
 42c:	97ffffd9 	bl	390 <write@plt>
 430:	71003c1f 	cmp	w0, #0xf
 434:	54000080 	b.eq	444 <main+0x54>  // b.none
    printf("ptytest: master-to-slave failed\n");
 438:	90000000 	adrp	x0, 0 <.plt-0x360>
 43c:	91174800 	add	x0, x0, #0x5d2
 440:	17fffff4 	b	410 <main+0x20>
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
 444:	b9402fe0 	ldr	w0, [sp, #44]
 448:	9100c3e1 	add	x1, sp, #0x30
 44c:	52800402 	mov	w2, #0x20                  	// #32
 450:	97ffffd4 	bl	3a0 <read@plt>
  if(write(fd[0], "input-to-slave\n", 15) != 15 ||
 454:	71003c1f 	cmp	w0, #0xf
 458:	54ffff01 	b.ne	438 <main+0x48>  // b.any
     memcmp(buf, "input-to-slave\n", 15) != 0){
 45c:	2a0003e2 	mov	w2, w0
 460:	91170a61 	add	x1, x19, #0x5c2
 464:	9100c3e0 	add	x0, sp, #0x30
 468:	97ffffd2 	bl	3b0 <memcmp@plt>
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
 46c:	35fffe60 	cbnz	w0, 438 <main+0x48>
  }
  if((n = read(fd[0], buf, sizeof(buf))) != 16 ||
 470:	b9402be0 	ldr	w0, [sp, #40]
 474:	9100c3e1 	add	x1, sp, #0x30
 478:	52800402 	mov	w2, #0x20                  	// #32
 47c:	97ffffc9 	bl	3a0 <read@plt>
 480:	7100401f 	cmp	w0, #0x10
 484:	54000080 	b.eq	494 <main+0xa4>  // b.none
     memcmp(buf, "input-to-slave\r\n", 16) != 0){
    printf("ptytest: input echo failed\n");
 488:	90000000 	adrp	x0, 0 <.plt-0x360>
 48c:	9117cc00 	add	x0, x0, #0x5f3
 490:	17ffffe0 	b	410 <main+0x20>
     memcmp(buf, "input-to-slave\r\n", 16) != 0){
 494:	2a0003e2 	mov	w2, w0
 498:	90000014 	adrp	x20, 0 <.plt-0x360>
 49c:	9100c3e0 	add	x0, sp, #0x30
 4a0:	91183e81 	add	x1, x20, #0x60f
 4a4:	97ffffc3 	bl	3b0 <memcmp@plt>
  if((n = read(fd[0], buf, sizeof(buf))) != 16 ||
 4a8:	35ffff00 	cbnz	w0, 488 <main+0x98>
    exit(1);
  }
  if(write(fd[0], "\033[A\n", 4) != 4 ||
 4ac:	b9402be0 	ldr	w0, [sp, #40]
 4b0:	90000001 	adrp	x1, 0 <.plt-0x360>
 4b4:	91188021 	add	x1, x1, #0x620
 4b8:	52800082 	mov	w2, #0x4                   	// #4
 4bc:	97ffffb5 	bl	390 <write@plt>
 4c0:	7100101f 	cmp	w0, #0x4
 4c4:	54000080 	b.eq	4d4 <main+0xe4>  // b.none
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
     memcmp(buf, "input-to-slave\n", 15) != 0 ||
     (n = read(fd[0], buf, sizeof(buf))) != 16 ||
     memcmp(buf, "input-to-slave\r\n", 16) != 0){
    printf("ptytest: history recall failed\n");
 4c8:	90000000 	adrp	x0, 0 <.plt-0x360>
 4cc:	91189400 	add	x0, x0, #0x625
 4d0:	17ffffd0 	b	410 <main+0x20>
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
 4d4:	b9402fe0 	ldr	w0, [sp, #44]
 4d8:	9100c3e1 	add	x1, sp, #0x30
 4dc:	52800402 	mov	w2, #0x20                  	// #32
 4e0:	97ffffb0 	bl	3a0 <read@plt>
  if(write(fd[0], "\033[A\n", 4) != 4 ||
 4e4:	71003c1f 	cmp	w0, #0xf
 4e8:	54ffff01 	b.ne	4c8 <main+0xd8>  // b.any
     memcmp(buf, "input-to-slave\n", 15) != 0 ||
 4ec:	2a0003e2 	mov	w2, w0
 4f0:	91170a61 	add	x1, x19, #0x5c2
 4f4:	9100c3e0 	add	x0, sp, #0x30
 4f8:	97ffffae 	bl	3b0 <memcmp@plt>
     (n = read(fd[1], buf, sizeof(buf))) != 15 ||
 4fc:	35fffe60 	cbnz	w0, 4c8 <main+0xd8>
     (n = read(fd[0], buf, sizeof(buf))) != 16 ||
 500:	b9402be0 	ldr	w0, [sp, #40]
 504:	9100c3e1 	add	x1, sp, #0x30
 508:	52800402 	mov	w2, #0x20                  	// #32
 50c:	97ffffa5 	bl	3a0 <read@plt>
     memcmp(buf, "input-to-slave\n", 15) != 0 ||
 510:	7100401f 	cmp	w0, #0x10
 514:	54fffda1 	b.ne	4c8 <main+0xd8>  // b.any
     memcmp(buf, "input-to-slave\r\n", 16) != 0){
 518:	91183e81 	add	x1, x20, #0x60f
 51c:	9100c3e0 	add	x0, sp, #0x30
 520:	52800202 	mov	w2, #0x10                  	// #16
 524:	97ffffa3 	bl	3b0 <memcmp@plt>
     (n = read(fd[0], buf, sizeof(buf))) != 16 ||
 528:	35fffd00 	cbnz	w0, 4c8 <main+0xd8>
    exit(1);
  }
  if(write(fd[1], "output-to-master\n", 17) != 17 ||
 52c:	b9402fe0 	ldr	w0, [sp, #44]
 530:	90000001 	adrp	x1, 0 <.plt-0x360>
 534:	91191421 	add	x1, x1, #0x645
 538:	52800222 	mov	w2, #0x11                  	// #17
 53c:	97ffff95 	bl	390 <write@plt>
 540:	7100441f 	cmp	w0, #0x11
 544:	54000080 	b.eq	554 <main+0x164>  // b.none
     (n = read(fd[0], buf, sizeof(buf))) != 18 ||
     memcmp(buf, "output-to-master\r\n", 18) != 0){
    printf("ptytest: slave-to-master failed\n");
 548:	90000000 	adrp	x0, 0 <.plt-0x360>
 54c:	91195c00 	add	x0, x0, #0x657
 550:	17ffffb0 	b	410 <main+0x20>
     (n = read(fd[0], buf, sizeof(buf))) != 18 ||
 554:	b9402be0 	ldr	w0, [sp, #40]
 558:	9100c3e1 	add	x1, sp, #0x30
 55c:	52800402 	mov	w2, #0x20                  	// #32
 560:	97ffff90 	bl	3a0 <read@plt>
  if(write(fd[1], "output-to-master\n", 17) != 17 ||
 564:	7100481f 	cmp	w0, #0x12
 568:	54ffff01 	b.ne	548 <main+0x158>  // b.any
     memcmp(buf, "output-to-master\r\n", 18) != 0){
 56c:	2a0003e2 	mov	w2, w0
 570:	90000001 	adrp	x1, 0 <.plt-0x360>
 574:	9119e021 	add	x1, x1, #0x678
 578:	9100c3e0 	add	x0, sp, #0x30
 57c:	97ffff8d 	bl	3b0 <memcmp@plt>
     (n = read(fd[0], buf, sizeof(buf))) != 18 ||
 580:	35fffe40 	cbnz	w0, 548 <main+0x158>
    exit(1);
  }
  close(fd[0]);
 584:	b9402be0 	ldr	w0, [sp, #40]
 588:	97ffff96 	bl	3e0 <close@plt>
  close(fd[1]);
 58c:	b9402fe0 	ldr	w0, [sp, #44]
 590:	97ffff94 	bl	3e0 <close@plt>
  printf("ptytest: ok\n");
 594:	90000000 	adrp	x0, 0 <.plt-0x360>
 598:	911a2c00 	add	x0, x0, #0x68b
 59c:	97ffff79 	bl	380 <printf@plt>
  exit(0);
 5a0:	52800000 	mov	w0, #0x0                   	// #0
 5a4:	17ffff9d 	b	418 <main+0x28>
