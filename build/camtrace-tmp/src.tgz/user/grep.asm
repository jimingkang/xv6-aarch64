
user/_grep:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000003d0 <.plt>:
 3d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 3d4:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 3d8:	f9445611 	ldr	x17, [x16, #2216]
 3dc:	9122a210 	add	x16, x16, #0x8a8
 3e0:	d61f0220 	br	x17
 3e4:	d503201f 	nop
 3e8:	d503201f 	nop
 3ec:	d503201f 	nop

00000000000003f0 <printf@plt>:
 3f0:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 3f4:	f9445a11 	ldr	x17, [x16, #2224]
 3f8:	9122c210 	add	x16, x16, #0x8b0
 3fc:	d61f0220 	br	x17

0000000000000400 <memmove@plt>:
 400:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 404:	f9445e11 	ldr	x17, [x16, #2232]
 408:	9122e210 	add	x16, x16, #0x8b8
 40c:	d61f0220 	br	x17

0000000000000410 <write@plt>:
 410:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 414:	f9446211 	ldr	x17, [x16, #2240]
 418:	91230210 	add	x16, x16, #0x8c0
 41c:	d61f0220 	br	x17

0000000000000420 <fprintf@plt>:
 420:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 424:	f9446611 	ldr	x17, [x16, #2248]
 428:	91232210 	add	x16, x16, #0x8c8
 42c:	d61f0220 	br	x17

0000000000000430 <read@plt>:
 430:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 434:	f9446a11 	ldr	x17, [x16, #2256]
 438:	91234210 	add	x16, x16, #0x8d0
 43c:	d61f0220 	br	x17

0000000000000440 <exit@plt>:
 440:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 444:	f9446e11 	ldr	x17, [x16, #2264]
 448:	91236210 	add	x16, x16, #0x8d8
 44c:	d61f0220 	br	x17

0000000000000450 <open@plt>:
 450:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 454:	f9447211 	ldr	x17, [x16, #2272]
 458:	91238210 	add	x16, x16, #0x8e0
 45c:	d61f0220 	br	x17

0000000000000460 <strchr@plt>:
 460:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 464:	f9447611 	ldr	x17, [x16, #2280]
 468:	9123a210 	add	x16, x16, #0x8e8
 46c:	d61f0220 	br	x17

0000000000000470 <close@plt>:
 470:	b0000010 	adrp	x16, 1000 <grep+0x9ac>
 474:	f9447a11 	ldr	x17, [x16, #2288]
 478:	9123c210 	add	x16, x16, #0x8f0
 47c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000480 <main>:
  }
}

int
main(int argc, char *argv[])
{
 480:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
 484:	910003fd 	mov	x29, sp
 488:	a90153f3 	stp	x19, x20, [sp, #16]
 48c:	a9025bf5 	stp	x21, x22, [sp, #32]
  int fd, i;
  char *pattern;

  if(argc <= 1){
 490:	7100041f 	cmp	w0, #0x1
 494:	540000ec 	b.gt	4b0 <main+0x30>
    fprintf(2, "usage: grep pattern [file ...]\n");
 498:	90000001 	adrp	x1, 0 <.plt-0x3d0>
 49c:	911ce021 	add	x1, x1, #0x738
 4a0:	52800040 	mov	w0, #0x2                   	// #2
 4a4:	97ffffdf 	bl	420 <fprintf@plt>
  }

  for(i = 2; i < argc; i++){
    if((fd = open(argv[i], 0)) < 0){
      printf("grep: cannot open %s\n", argv[i]);
      exit(1);
 4a8:	52800020 	mov	w0, #0x1                   	// #1
 4ac:	1400000a 	b	4d4 <main+0x54>
  pattern = argv[1];
 4b0:	f9400436 	ldr	x22, [x1, #8]
 4b4:	2a0003f4 	mov	w20, w0
 4b8:	aa0103f5 	mov	x21, x1
  if(argc <= 2){
 4bc:	7100081f 	cmp	w0, #0x2
 4c0:	540000c1 	b.ne	4d8 <main+0x58>  // b.any
    grep(pattern, 0);
 4c4:	aa1603e0 	mov	x0, x22
 4c8:	52800001 	mov	w1, #0x0                   	// #0
 4cc:	94000062 	bl	654 <grep>
    exit(0);
 4d0:	52800000 	mov	w0, #0x0                   	// #0
 4d4:	97ffffdb 	bl	440 <exit@plt>
  if(argc <= 2){
 4d8:	d2800053 	mov	x19, #0x2                   	// #2
    if((fd = open(argv[i], 0)) < 0){
 4dc:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
 4e0:	52800001 	mov	w1, #0x0                   	// #0
 4e4:	97ffffdb 	bl	450 <open@plt>
 4e8:	2a0003e1 	mov	w1, w0
 4ec:	36f800c0 	tbz	w0, #31, 504 <main+0x84>
      printf("grep: cannot open %s\n", argv[i]);
 4f0:	f8735aa1 	ldr	x1, [x21, w19, uxtw #3]
 4f4:	90000000 	adrp	x0, 0 <.plt-0x3d0>
 4f8:	911d6000 	add	x0, x0, #0x758
 4fc:	97ffffbd 	bl	3f0 <printf@plt>
 500:	17ffffea 	b	4a8 <main+0x28>
    }
    grep(pattern, fd);
 504:	aa1603e0 	mov	x0, x22
 508:	b9003fe1 	str	w1, [sp, #60]
 50c:	94000052 	bl	654 <grep>
  for(i = 2; i < argc; i++){
 510:	91000673 	add	x19, x19, #0x1
    close(fd);
 514:	b9403fe0 	ldr	w0, [sp, #60]
 518:	97ffffd6 	bl	470 <close@plt>
  for(i = 2; i < argc; i++){
 51c:	6b13029f 	cmp	w20, w19
 520:	54fffdec 	b.gt	4dc <main+0x5c>
 524:	17ffffeb 	b	4d0 <main+0x50>

0000000000000528 <matchstar>:
  return 0;
}

// matchstar: search for c*re at beginning of text
int matchstar(int c, char *re, char *text)
{
 528:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 52c:	910003fd 	mov	x29, sp
 530:	a90153f3 	stp	x19, x20, [sp, #16]
 534:	2a0003f3 	mov	w19, w0
 538:	aa0203f4 	mov	x20, x2
 53c:	f90013f5 	str	x21, [sp, #32]
 540:	aa0103f5 	mov	x21, x1
  do{  // a * matches zero or more instances
    if(matchhere(re, text))
 544:	aa1403e1 	mov	x1, x20
 548:	aa1503e0 	mov	x0, x21
 54c:	94000010 	bl	58c <matchhere>
 550:	350001a0 	cbnz	w0, 584 <matchstar+0x5c>
      return 1;
  }while(*text!='\0' && (*text++==c || c=='.'));
 554:	39400282 	ldrb	w2, [x20]
 558:	340000a2 	cbz	w2, 56c <matchstar+0x44>
 55c:	6b13005f 	cmp	w2, w19
 560:	540000e0 	b.eq	57c <matchstar+0x54>  // b.none
 564:	7100ba7f 	cmp	w19, #0x2e
 568:	540000a0 	b.eq	57c <matchstar+0x54>  // b.none
  return 0;
}
 56c:	f94013f5 	ldr	x21, [sp, #32]
 570:	a94153f3 	ldp	x19, x20, [sp, #16]
 574:	a8c37bfd 	ldp	x29, x30, [sp], #48
 578:	d65f03c0 	ret
  }while(*text!='\0' && (*text++==c || c=='.'));
 57c:	91000694 	add	x20, x20, #0x1
 580:	17fffff1 	b	544 <matchstar+0x1c>
      return 1;
 584:	52800020 	mov	w0, #0x1                   	// #1
 588:	17fffff9 	b	56c <matchstar+0x44>

000000000000058c <matchhere>:
{
 58c:	aa0003e3 	mov	x3, x0
 590:	aa0103e2 	mov	x2, x1
  if(re[0] == '\0')
 594:	39400060 	ldrb	w0, [x3]
 598:	34000300 	cbz	w0, 5f8 <matchhere+0x6c>
  if(re[1] == '*')
 59c:	39400461 	ldrb	w1, [x3, #1]
 5a0:	7100a83f 	cmp	w1, #0x2a
 5a4:	54000061 	b.ne	5b0 <matchhere+0x24>  // b.any
    return matchstar(re[0], re+2, text);
 5a8:	91000861 	add	x1, x3, #0x2
 5ac:	17ffffdf 	b	528 <matchstar>
  if(re[0] == '$' && re[1] == '\0')
 5b0:	7100901f 	cmp	w0, #0x24
 5b4:	540000c1 	b.ne	5cc <matchhere+0x40>  // b.any
 5b8:	350000a1 	cbnz	w1, 5cc <matchhere+0x40>
    return *text == '\0';
 5bc:	39400040 	ldrb	w0, [x2]
 5c0:	7100001f 	cmp	w0, #0x0
 5c4:	1a9f17e0 	cset	w0, eq	// eq = none
}
 5c8:	d65f03c0 	ret
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
 5cc:	39400041 	ldrb	w1, [x2]
 5d0:	34000101 	cbz	w1, 5f0 <matchhere+0x64>
 5d4:	7100b81f 	cmp	w0, #0x2e
 5d8:	54000060 	b.eq	5e4 <matchhere+0x58>  // b.none
 5dc:	6b01001f 	cmp	w0, w1
 5e0:	54000081 	b.ne	5f0 <matchhere+0x64>  // b.any
    return matchhere(re+1, text+1);
 5e4:	91000463 	add	x3, x3, #0x1
 5e8:	91000442 	add	x2, x2, #0x1
 5ec:	17ffffea 	b	594 <matchhere+0x8>
  return 0;
 5f0:	52800000 	mov	w0, #0x0                   	// #0
 5f4:	17fffff5 	b	5c8 <matchhere+0x3c>
    return 1;
 5f8:	52800020 	mov	w0, #0x1                   	// #1
 5fc:	17fffff3 	b	5c8 <matchhere+0x3c>

0000000000000600 <match>:
{
 600:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 604:	910003fd 	mov	x29, sp
 608:	a90153f3 	stp	x19, x20, [sp, #16]
 60c:	aa0003f4 	mov	x20, x0
  if(re[0] == '^')
 610:	39400000 	ldrb	w0, [x0]
 614:	7101781f 	cmp	w0, #0x5e
 618:	540000a1 	b.ne	62c <match+0x2c>  // b.any
    return matchhere(re+1, text);
 61c:	91000680 	add	x0, x20, #0x1
}
 620:	a94153f3 	ldp	x19, x20, [sp, #16]
 624:	a8c27bfd 	ldp	x29, x30, [sp], #32
    return matchhere(re+1, text);
 628:	17ffffd9 	b	58c <matchhere>
 62c:	aa0103f3 	mov	x19, x1
    if(matchhere(re, text))
 630:	aa1303e1 	mov	x1, x19
 634:	aa1403e0 	mov	x0, x20
 638:	97ffffd5 	bl	58c <matchhere>
 63c:	35000060 	cbnz	w0, 648 <match+0x48>
  }while(*text++ != '\0');
 640:	38401661 	ldrb	w1, [x19], #1
 644:	35ffff61 	cbnz	w1, 630 <match+0x30>
}
 648:	a94153f3 	ldp	x19, x20, [sp, #16]
 64c:	a8c27bfd 	ldp	x29, x30, [sp], #32
 650:	d65f03c0 	ret

0000000000000654 <grep>:
{
 654:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 658:	910003fd 	mov	x29, sp
 65c:	a90153f3 	stp	x19, x20, [sp, #16]
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 660:	b0000014 	adrp	x20, 1000 <grep+0x9ac>
 664:	9123e294 	add	x20, x20, #0x8f8
{
 668:	a90363f7 	stp	x23, x24, [sp, #48]
 66c:	2a0103f8 	mov	w24, w1
  m = 0;
 670:	52800013 	mov	w19, #0x0                   	// #0
{
 674:	f9002bfb 	str	x27, [sp, #80]
 678:	aa0003fb 	mov	x27, x0
 67c:	a9025bf5 	stp	x21, x22, [sp, #32]
 680:	a9046bf9 	stp	x25, x26, [sp, #64]
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 684:	52807ff9 	mov	w25, #0x3ff                 	// #1023
    while((q = strchr(p, '\n')) != 0){
 688:	5280015a 	mov	w26, #0xa                   	// #10
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 68c:	4b130322 	sub	w2, w25, w19
 690:	8b33c281 	add	x1, x20, w19, sxtw
 694:	2a1803e0 	mov	w0, w24
 698:	97ffff66 	bl	430 <read@plt>
 69c:	7100001f 	cmp	w0, #0x0
 6a0:	5400010c 	b.gt	6c0 <grep+0x6c>
}
 6a4:	f9402bfb 	ldr	x27, [sp, #80]
 6a8:	a94153f3 	ldp	x19, x20, [sp, #16]
 6ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
 6b0:	a94363f7 	ldp	x23, x24, [sp, #48]
 6b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
 6b8:	a8c67bfd 	ldp	x29, x30, [sp], #96
 6bc:	d65f03c0 	ret
    m += n;
 6c0:	0b000273 	add	w19, w19, w0
    p = buf;
 6c4:	aa1403f5 	mov	x21, x20
    buf[m] = '\0';
 6c8:	3833ca9f 	strb	wzr, [x20, w19, sxtw]
    while((q = strchr(p, '\n')) != 0){
 6cc:	aa1503e0 	mov	x0, x21
 6d0:	52800141 	mov	w1, #0xa                   	// #10
 6d4:	97ffff63 	bl	460 <strchr@plt>
 6d8:	aa0003f6 	mov	x22, x0
 6dc:	b5000140 	cbnz	x0, 704 <grep+0xb0>
    if(m > 0){
 6e0:	7100027f 	cmp	w19, #0x0
 6e4:	54fffd4d 	b.le	68c <grep+0x38>
      m -= p - buf;
 6e8:	cb1402a0 	sub	x0, x21, x20
      memmove(buf, p, m);
 6ec:	aa1503e1 	mov	x1, x21
      m -= p - buf;
 6f0:	4b000273 	sub	w19, w19, w0
      memmove(buf, p, m);
 6f4:	aa1403e0 	mov	x0, x20
 6f8:	2a1303e2 	mov	w2, w19
 6fc:	97ffff41 	bl	400 <memmove@plt>
 700:	17ffffe3 	b	68c <grep+0x38>
      *q = 0;
 704:	aa1603f7 	mov	x23, x22
      if(match(pattern, p)){
 708:	aa1503e1 	mov	x1, x21
 70c:	aa1b03e0 	mov	x0, x27
      *q = 0;
 710:	380016ff 	strb	wzr, [x23], #1
      if(match(pattern, p)){
 714:	97ffffbb 	bl	600 <match>
 718:	340000c0 	cbz	w0, 730 <grep+0xdc>
        *q = '\n';
 71c:	390002da 	strb	w26, [x22]
        write(1, p, q+1 - p);
 720:	4b1502e2 	sub	w2, w23, w21
 724:	aa1503e1 	mov	x1, x21
 728:	52800020 	mov	w0, #0x1                   	// #1
 72c:	97ffff39 	bl	410 <write@plt>
      p = q+1;
 730:	aa1703f5 	mov	x21, x23
 734:	17ffffe6 	b	6cc <grep+0x78>
