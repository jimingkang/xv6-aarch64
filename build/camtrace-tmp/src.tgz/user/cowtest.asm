
user/_cowtest:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000618 <.plt>:
 618:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 61c:	d0000010 	adrp	x16, 2000 <check+0x114c>
 620:	f941b211 	ldr	x17, [x16, #864]
 624:	910d8210 	add	x16, x16, #0x360
 628:	d61f0220 	br	x17
 62c:	d503201f 	nop
 630:	d503201f 	nop
 634:	d503201f 	nop

0000000000000638 <strcpy@plt>:
 638:	d0000010 	adrp	x16, 2000 <check+0x114c>
 63c:	f941b611 	ldr	x17, [x16, #872]
 640:	910da210 	add	x16, x16, #0x368
 644:	d61f0220 	br	x17

0000000000000648 <printf@plt>:
 648:	d0000010 	adrp	x16, 2000 <check+0x114c>
 64c:	f941ba11 	ldr	x17, [x16, #880]
 650:	910dc210 	add	x16, x16, #0x370
 654:	d61f0220 	br	x17

0000000000000658 <munmap@plt>:
 658:	d0000010 	adrp	x16, 2000 <check+0x114c>
 65c:	f941be11 	ldr	x17, [x16, #888]
 660:	910de210 	add	x16, x16, #0x378
 664:	d61f0220 	br	x17

0000000000000668 <sleep@plt>:
 668:	d0000010 	adrp	x16, 2000 <check+0x114c>
 66c:	f941c211 	ldr	x17, [x16, #896]
 670:	910e0210 	add	x16, x16, #0x380
 674:	d61f0220 	br	x17

0000000000000678 <mmap@plt>:
 678:	d0000010 	adrp	x16, 2000 <check+0x114c>
 67c:	f941c611 	ldr	x17, [x16, #904]
 680:	910e2210 	add	x16, x16, #0x388
 684:	d61f0220 	br	x17

0000000000000688 <pipe@plt>:
 688:	d0000010 	adrp	x16, 2000 <check+0x114c>
 68c:	f941ca11 	ldr	x17, [x16, #912]
 690:	910e4210 	add	x16, x16, #0x390
 694:	d61f0220 	br	x17

0000000000000698 <write@plt>:
 698:	d0000010 	adrp	x16, 2000 <check+0x114c>
 69c:	f941ce11 	ldr	x17, [x16, #920]
 6a0:	910e6210 	add	x16, x16, #0x398
 6a4:	d61f0220 	br	x17

00000000000006a8 <wait@plt>:
 6a8:	d0000010 	adrp	x16, 2000 <check+0x114c>
 6ac:	f941d211 	ldr	x17, [x16, #928]
 6b0:	910e8210 	add	x16, x16, #0x3a0
 6b4:	d61f0220 	br	x17

00000000000006b8 <read@plt>:
 6b8:	d0000010 	adrp	x16, 2000 <check+0x114c>
 6bc:	f941d611 	ldr	x17, [x16, #936]
 6c0:	910ea210 	add	x16, x16, #0x3a8
 6c4:	d61f0220 	br	x17

00000000000006c8 <strncmp@plt>:
 6c8:	d0000010 	adrp	x16, 2000 <check+0x114c>
 6cc:	f941da11 	ldr	x17, [x16, #944]
 6d0:	910ec210 	add	x16, x16, #0x3b0
 6d4:	d61f0220 	br	x17

00000000000006d8 <fork@plt>:
 6d8:	d0000010 	adrp	x16, 2000 <check+0x114c>
 6dc:	f941de11 	ldr	x17, [x16, #952]
 6e0:	910ee210 	add	x16, x16, #0x3b8
 6e4:	d61f0220 	br	x17

00000000000006e8 <sbrk@plt>:
 6e8:	d0000010 	adrp	x16, 2000 <check+0x114c>
 6ec:	f941e211 	ldr	x17, [x16, #960]
 6f0:	910f0210 	add	x16, x16, #0x3c0
 6f4:	d61f0220 	br	x17

00000000000006f8 <strcmp@plt>:
 6f8:	d0000010 	adrp	x16, 2000 <check+0x114c>
 6fc:	f941e611 	ldr	x17, [x16, #968]
 700:	910f2210 	add	x16, x16, #0x3c8
 704:	d61f0220 	br	x17

0000000000000708 <exit@plt>:
 708:	d0000010 	adrp	x16, 2000 <check+0x114c>
 70c:	f941ea11 	ldr	x17, [x16, #976]
 710:	910f4210 	add	x16, x16, #0x3d0
 714:	d61f0220 	br	x17

0000000000000718 <atoi@plt>:
 718:	d0000010 	adrp	x16, 2000 <check+0x114c>
 71c:	f941ee11 	ldr	x17, [x16, #984]
 720:	910f6210 	add	x16, x16, #0x3d8
 724:	d61f0220 	br	x17

0000000000000728 <strlen@plt>:
 728:	d0000010 	adrp	x16, 2000 <check+0x114c>
 72c:	f941f211 	ldr	x17, [x16, #992]
 730:	910f8210 	add	x16, x16, #0x3e0
 734:	d61f0220 	br	x17

0000000000000738 <open@plt>:
 738:	d0000010 	adrp	x16, 2000 <check+0x114c>
 73c:	f941f611 	ldr	x17, [x16, #1000]
 740:	910fa210 	add	x16, x16, #0x3e8
 744:	d61f0220 	br	x17

0000000000000748 <close@plt>:
 748:	d0000010 	adrp	x16, 2000 <check+0x114c>
 74c:	f941fa11 	ldr	x17, [x16, #1008]
 750:	910fc210 	add	x16, x16, #0x3f0
 754:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000758 <main>:
  munmap(p, n * PG);
}

int
main(int argc, char *argv[])
{
 758:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 75c:	910003fd 	mov	x29, sp
 760:	a9025bf5 	stp	x21, x22, [sp, #32]
  long free0 = meminfo("MemFree");
 764:	90000015 	adrp	x21, 0 <.plt-0x618>
 768:	913ce6b5 	add	x21, x21, #0xf39
 76c:	aa1503e0 	mov	x0, x21
{
 770:	a90153f3 	stp	x19, x20, [sp, #16]
 774:	a90363f7 	stp	x23, x24, [sp, #48]
 778:	a9046bf9 	stp	x25, x26, [sp, #64]
  long free0 = meminfo("MemFree");
 77c:	94000192 	bl	dc4 <meminfo>
 780:	aa0003f4 	mov	x20, x0

  // Run the tests in a child so that its page-table pages (sbrk(-n) keeps
  // them until exit) are freed too before the leak check.
  int pid = fork();
 784:	97ffffd5 	bl	6d8 <fork@plt>
  if(pid == 0){
 788:	35002be0 	cbnz	w0, d04 <main+0x5ac>
 78c:	2a0003f6 	mov	w22, w0
  long freekb = meminfo("MemFree");
 790:	aa1503e0 	mov	x0, x21
 794:	9400018c 	bl	dc4 <meminfo>
  long sz = (freekb * 1024 / 3 * 2) & ~(PG - 1);   // two thirds of free RAM
 798:	d376d413 	lsl	x19, x0, #10
 79c:	d2800060 	mov	x0, #0x3                   	// #3
 7a0:	9ac00e73 	sdiv	x19, x19, x0
 7a4:	d37ffa73 	lsl	x19, x19, #1
 7a8:	9274ce75 	and	x21, x19, #0xfffffffffffff000
  char *p = sbrk(sz);
 7ac:	2a1503e0 	mov	w0, w21
 7b0:	97ffffce 	bl	6e8 <sbrk@plt>
  check(p != (char *)-1, "big: sbrk two thirds of free memory");
 7b4:	b100041f 	cmn	x0, #0x1
  char *p = sbrk(sz);
 7b8:	aa0003f4 	mov	x20, x0
  check(p != (char *)-1, "big: sbrk two thirds of free memory");
 7bc:	90000001 	adrp	x1, 0 <.plt-0x618>
 7c0:	913d0421 	add	x1, x1, #0xf41
 7c4:	1a9f07e0 	cset	w0, ne	// ne = any
 7c8:	940001bb 	bl	eb4 <check>
  if(p == (char *)-1)
 7cc:	b100069f 	cmn	x20, #0x1
 7d0:	54000460 	b.eq	85c <main+0x104>  // b.none
  for(long i = 0; i < sz; i += PG)
 7d4:	d2800000 	mov	x0, #0x0                   	// #0
 7d8:	eb0002bf 	cmp	x21, x0
 7dc:	5400096c 	b.gt	908 <main+0x1b0>
  long before = meminfo("CowShared");
 7e0:	90000017 	adrp	x23, 0 <.plt-0x618>
 7e4:	913d96f7 	add	x23, x23, #0xf65
 7e8:	aa1703e0 	mov	x0, x23
 7ec:	94000176 	bl	dc4 <meminfo>
 7f0:	aa0003f9 	mov	x25, x0
  int pid = fork();
 7f4:	97ffffb9 	bl	6d8 <fork@plt>
 7f8:	2a0003f8 	mov	w24, w0
  if(pid == 0){
 7fc:	7100001f 	cmp	w0, #0x0
 800:	34000a20 	cbz	w0, 944 <main+0x1ec>
  check(pid > 0, "big: fork succeeds (would need 2x memory without COW)");
 804:	1a9fd7e0 	cset	w0, gt
 808:	90000001 	adrp	x1, 0 <.plt-0x618>
 80c:	913dbc21 	add	x1, x1, #0xf6f
 810:	940001a9 	bl	eb4 <check>
  if(pid > 0)
 814:	7100031f 	cmp	w24, #0x0
 818:	540000ed 	b.le	834 <main+0xdc>
    check(child_status() == 0, "big: child reads parent's data");
 81c:	94000161 	bl	da0 <child_status>
 820:	7100001f 	cmp	w0, #0x0
 824:	90000001 	adrp	x1, 0 <.plt-0x618>
 828:	913e9421 	add	x1, x1, #0xfa5
 82c:	1a9f17e0 	cset	w0, eq	// eq = none
 830:	940001a1 	bl	eb4 <check>
  check(meminfo("CowShared") - before >= sz / PG, "big: pages were shared");
 834:	aa1703e0 	mov	x0, x23
 838:	94000163 	bl	dc4 <meminfo>
 83c:	cb190000 	sub	x0, x0, x25
 840:	90000001 	adrp	x1, 0 <.plt-0x618>
 844:	913f1021 	add	x1, x1, #0xfc4
 848:	eb93301f 	cmp	x0, x19, asr #12
 84c:	1a9fb7e0 	cset	w0, ge	// ge = tcont
 850:	94000199 	bl	eb4 <check>
  sbrk(-sz);
 854:	4b1503e0 	neg	w0, w21
 858:	97ffffa4 	bl	6e8 <sbrk@plt>
  char *p = sbrk(n * PG);
 85c:	52a00020 	mov	w0, #0x10000               	// #65536
 860:	97ffffa2 	bl	6e8 <sbrk@plt>
 864:	aa0003f3 	mov	x19, x0
  for(int i = 0; i < n; i++)
 868:	91404014 	add	x20, x0, #0x10, lsl #12
    p[i * PG] = 'P';
 86c:	52800a01 	mov	w1, #0x50                  	// #80
 870:	39000001 	strb	w1, [x0]
  for(int i = 0; i < n; i++)
 874:	91400400 	add	x0, x0, #0x1, lsl #12
 878:	eb14001f 	cmp	x0, x20
 87c:	54ffffa1 	b.ne	870 <main+0x118>  // b.any
  pipe(fds);
 880:	910163e0 	add	x0, sp, #0x58
 884:	97ffff81 	bl	688 <pipe@plt>
  int pid = fork();
 888:	97ffff94 	bl	6d8 <fork@plt>
  if(pid == 0){
 88c:	35000600 	cbnz	w0, 94c <main+0x1f4>
    close(fds[0]);
 890:	b9405be0 	ldr	w0, [sp, #88]
    int ok = 1;
 894:	52800035 	mov	w21, #0x1                   	// #1
    close(fds[0]);
 898:	97ffffac 	bl	748 <close@plt>
 89c:	aa1303e0 	mov	x0, x19
      p[i * PG] = 'C';
 8a0:	52800861 	mov	w1, #0x43                  	// #67
      if(p[i * PG] != 'P')
 8a4:	39400002 	ldrb	w2, [x0]
      p[i * PG] = 'C';
 8a8:	39000001 	strb	w1, [x0]
    for(int i = 0; i < n; i++){
 8ac:	91400400 	add	x0, x0, #0x1, lsl #12
      if(p[i * PG] != 'P')
 8b0:	7101405f 	cmp	w2, #0x50
 8b4:	1a9f17e2 	cset	w2, eq	// eq = none
 8b8:	0a0202b5 	and	w21, w21, w2
    for(int i = 0; i < n; i++){
 8bc:	eb14001f 	cmp	x0, x20
 8c0:	54ffff21 	b.ne	8a4 <main+0x14c>  // b.any
    char c = 'x';
 8c4:	52800f00 	mov	w0, #0x78                  	// #120
 8c8:	39015fe0 	strb	w0, [sp, #87]
    write(fds[1], &c, 1);      // parent writes after the child did
 8cc:	b9405fe0 	ldr	w0, [sp, #92]
 8d0:	91015fe1 	add	x1, sp, #0x57
 8d4:	52800022 	mov	w2, #0x1                   	// #1
 8d8:	97ffff70 	bl	698 <write@plt>
    sleep(5);
 8dc:	528000a0 	mov	w0, #0x5                   	// #5
 8e0:	97ffff62 	bl	668 <sleep@plt>
      if(p[i * PG] != 'C')
 8e4:	39400260 	ldrb	w0, [x19]
    for(int i = 0; i < n; i++)
 8e8:	91400673 	add	x19, x19, #0x1, lsl #12
      if(p[i * PG] != 'C')
 8ec:	71010c1f 	cmp	w0, #0x43
 8f0:	1a9f17e0 	cset	w0, eq	// eq = none
 8f4:	0a0002b5 	and	w21, w21, w0
    for(int i = 0; i < n; i++)
 8f8:	eb14027f 	cmp	x19, x20
 8fc:	54ffff41 	b.ne	8e4 <main+0x18c>  // b.any
    exit(ok ? 0 : 1);
 900:	520002a0 	eor	w0, w21, #0x1
 904:	1400000f 	b	940 <main+0x1e8>
    p[i] = (char)(i / PG);
 908:	934cfc01 	asr	x1, x0, #12
 90c:	38206a81 	strb	w1, [x20, x0]
  for(long i = 0; i < sz; i += PG)
 910:	91400400 	add	x0, x0, #0x1, lsl #12
 914:	17ffffb1 	b	7d8 <main+0x80>
      if(p[i] != (char)(i / PG))
 918:	38606a82 	ldrb	w2, [x20, x0]
 91c:	530c4c01 	ubfx	w1, w0, #12, #8
 920:	6b01005f 	cmp	w2, w1
 924:	54000060 	b.eq	930 <main+0x1d8>  // b.none
    exit(n == 6 && strcmp(p, "kernel") == 0 ? 0 : 1);
 928:	52800020 	mov	w0, #0x1                   	// #1
 92c:	14000005 	b	940 <main+0x1e8>
    for(long i = 0; i < sz; i += PG)
 930:	91400400 	add	x0, x0, #0x1, lsl #12
 934:	eb0002bf 	cmp	x21, x0
 938:	54ffff0c 	b.gt	918 <main+0x1c0>
    exit(0);
 93c:	52800000 	mov	w0, #0x0                   	// #0
 940:	97ffff72 	bl	708 <exit@plt>
    for(long i = 0; i < sz; i += PG)
 944:	d2800000 	mov	x0, #0x0                   	// #0
 948:	17fffffb 	b	934 <main+0x1dc>
  close(fds[1]);
 94c:	b9405fe0 	ldr	w0, [sp, #92]
 950:	97ffff7e 	bl	748 <close@plt>
  read(fds[0], &c, 1);
 954:	b9405be0 	ldr	w0, [sp, #88]
 958:	91015fe1 	add	x1, sp, #0x57
 95c:	52800022 	mov	w2, #0x1                   	// #1
 960:	97ffff56 	bl	6b8 <read@plt>
 964:	aa1303e1 	mov	x1, x19
  int ok = 1;
 968:	52800020 	mov	w0, #0x1                   	// #1
    p[i * PG] = 'Q';
 96c:	52800a22 	mov	w2, #0x51                  	// #81
    if(p[i * PG] != 'P')
 970:	39400023 	ldrb	w3, [x1]
    p[i * PG] = 'Q';
 974:	39000022 	strb	w2, [x1]
  for(int i = 0; i < n; i++){
 978:	91400421 	add	x1, x1, #0x1, lsl #12
    if(p[i * PG] != 'P')
 97c:	7101407f 	cmp	w3, #0x50
 980:	1a9f17e3 	cset	w3, eq	// eq = none
 984:	0a030000 	and	w0, w0, w3
  for(int i = 0; i < n; i++){
 988:	eb14003f 	cmp	x1, x20
 98c:	54ffff21 	b.ne	970 <main+0x218>  // b.any
  check(ok, "isolate: parent does not see child's writes");
 990:	90000001 	adrp	x1, 0 <.plt-0x618>
 994:	913f6c21 	add	x1, x1, #0xfdb
 998:	94000147 	bl	eb4 <check>
  check(child_status() == 0, "isolate: child does not see parent's writes");
 99c:	94000101 	bl	da0 <child_status>
 9a0:	7100001f 	cmp	w0, #0x0
 9a4:	1a9f17e0 	cset	w0, eq	// eq = none
 9a8:	b0000001 	adrp	x1, 1000 <check+0x14c>
 9ac:	91001c21 	add	x1, x1, #0x7
 9b0:	94000141 	bl	eb4 <check>
  ok = 1;
 9b4:	52800020 	mov	w0, #0x1                   	// #1
    if(p[i * PG] != 'Q')
 9b8:	39400261 	ldrb	w1, [x19]
  for(int i = 0; i < n; i++)
 9bc:	91400673 	add	x19, x19, #0x1, lsl #12
    if(p[i * PG] != 'Q')
 9c0:	7101443f 	cmp	w1, #0x51
 9c4:	1a9f17e1 	cset	w1, eq	// eq = none
 9c8:	0a010000 	and	w0, w0, w1
  for(int i = 0; i < n; i++)
 9cc:	eb14027f 	cmp	x19, x20
 9d0:	54ffff41 	b.ne	9b8 <main+0x260>  // b.any
  check(ok, "isolate: parent keeps its own writes");
 9d4:	b0000001 	adrp	x1, 1000 <check+0x14c>
 9d8:	9100cc21 	add	x1, x1, #0x33
 9dc:	94000136 	bl	eb4 <check>
  close(fds[0]);
 9e0:	b9405be0 	ldr	w0, [sp, #88]
 9e4:	97ffff59 	bl	748 <close@plt>
  sbrk(-n * PG);
 9e8:	52bfffe0 	mov	w0, #0xffff0000            	// #-65536
 9ec:	97ffff3f 	bl	6e8 <sbrk@plt>
  char *p = sbrk(n * PG);
 9f0:	52900000 	mov	w0, #0x8000                	// #32768
 9f4:	97ffff3d 	bl	6e8 <sbrk@plt>
 9f8:	aa0003f3 	mov	x19, x0
  for(int i = 0; i < n; i++)
 9fc:	91402015 	add	x21, x0, #0x8, lsl #12
    p[i * PG] = 1;
 a00:	52800021 	mov	w1, #0x1                   	// #1
 a04:	39000001 	strb	w1, [x0]
  for(int i = 0; i < n; i++)
 a08:	91400400 	add	x0, x0, #0x1, lsl #12
 a0c:	eb15001f 	cmp	x0, x21
 a10:	54ffffa1 	b.ne	a04 <main+0x2ac>  // b.any
  long copied = meminfo("CowCopied"), reused = meminfo("CowReused");
 a14:	b0000018 	adrp	x24, 1000 <check+0x14c>
 a18:	91016318 	add	x24, x24, #0x58
 a1c:	aa1803e0 	mov	x0, x24
 a20:	b0000017 	adrp	x23, 1000 <check+0x14c>
 a24:	91018af7 	add	x23, x23, #0x62
 a28:	940000e7 	bl	dc4 <meminfo>
 a2c:	aa0003fa 	mov	x26, x0
 a30:	aa1703e0 	mov	x0, x23
 a34:	940000e4 	bl	dc4 <meminfo>
 a38:	aa0003f9 	mov	x25, x0
    int pid = fork();
 a3c:	97ffff27 	bl	6d8 <fork@plt>
 a40:	2a0003f4 	mov	w20, w0
    if(pid == 0){
 a44:	34000940 	cbz	w0, b6c <main+0x414>
    int pid = fork();
 a48:	97ffff24 	bl	6d8 <fork@plt>
    if(pid == 0){
 a4c:	340008e0 	cbz	w0, b68 <main+0x410>
  int ok = child_status() == 0;
 a50:	940000d4 	bl	da0 <child_status>
  ok = ok && child_status() == 0;
 a54:	35000080 	cbnz	w0, a64 <main+0x30c>
 a58:	940000d2 	bl	da0 <child_status>
 a5c:	7100001f 	cmp	w0, #0x0
 a60:	1a9f17f6 	cset	w22, eq	// eq = none
  check(ok, "three: two children see the original and their own writes");
 a64:	2a1603e0 	mov	w0, w22
 a68:	b0000001 	adrp	x1, 1000 <check+0x14c>
 a6c:	9101b021 	add	x1, x1, #0x6c
 a70:	94000111 	bl	eb4 <check>
 a74:	aa1303e0 	mov	x0, x19
    p[i * PG] = 2;
 a78:	52800041 	mov	w1, #0x2                   	// #2
 a7c:	39000001 	strb	w1, [x0]
  for(int i = 0; i < n; i++)
 a80:	91400400 	add	x0, x0, #0x1, lsl #12
 a84:	eb15001f 	cmp	x0, x21
 a88:	54ffffa1 	b.ne	a7c <main+0x324>  // b.any
  ok = 1;
 a8c:	52800020 	mov	w0, #0x1                   	// #1
    if(p[i * PG] != 2)
 a90:	39400261 	ldrb	w1, [x19]
  for(int i = 0; i < n; i++)
 a94:	91400673 	add	x19, x19, #0x1, lsl #12
    if(p[i * PG] != 2)
 a98:	7100083f 	cmp	w1, #0x2
 a9c:	1a9f17e1 	cset	w1, eq	// eq = none
 aa0:	0a010000 	and	w0, w0, w1
  for(int i = 0; i < n; i++)
 aa4:	eb15027f 	cmp	x19, x21
 aa8:	54ffff41 	b.ne	a90 <main+0x338>  // b.any
  check(ok, "three: parent writes after both children exited");
 aac:	b0000001 	adrp	x1, 1000 <check+0x14c>
 ab0:	91029821 	add	x1, x1, #0xa6
 ab4:	94000100 	bl	eb4 <check>
  check(meminfo("CowCopied") - copied >= 2 * n, "three: children copied");
 ab8:	b0000014 	adrp	x20, 1000 <check+0x14c>
 abc:	91045a94 	add	x20, x20, #0x116
 ac0:	aa1803e0 	mov	x0, x24
 ac4:	940000c0 	bl	dc4 <meminfo>
 ac8:	cb1a0000 	sub	x0, x0, x26
 acc:	f1003c1f 	cmp	x0, #0xf
 ad0:	b0000001 	adrp	x1, 1000 <check+0x14c>
 ad4:	91035821 	add	x1, x1, #0xd6
 ad8:	1a9fd7e0 	cset	w0, gt
 adc:	940000f6 	bl	eb4 <check>
  check(meminfo("CowReused") - reused >= n, "three: last owner reused in place");
 ae0:	aa1703e0 	mov	x0, x23
 ae4:	940000b8 	bl	dc4 <meminfo>
 ae8:	cb190000 	sub	x0, x0, x25
 aec:	b0000001 	adrp	x1, 1000 <check+0x14c>
 af0:	9103b421 	add	x1, x1, #0xed
 af4:	f1001c1f 	cmp	x0, #0x7
 af8:	1a9fd7e0 	cset	w0, gt
 afc:	940000ee 	bl	eb4 <check>
  sbrk(-n * PG);
 b00:	128fffe0 	mov	w0, #0xffff8000            	// #-32768
 b04:	97fffef9 	bl	6e8 <sbrk@plt>
  char *p = sbrk(PG);
 b08:	52820000 	mov	w0, #0x1000                	// #4096
 b0c:	97fffef7 	bl	6e8 <sbrk@plt>
  strcpy(p, "parent");
 b10:	b0000013 	adrp	x19, 1000 <check+0x14c>
 b14:	91043e61 	add	x1, x19, #0x10f
  char *p = sbrk(PG);
 b18:	aa0003f5 	mov	x21, x0
  strcpy(p, "parent");
 b1c:	97fffec7 	bl	638 <strcpy@plt>
  pipe(fds);
 b20:	910163e0 	add	x0, sp, #0x58
 b24:	97fffed9 	bl	688 <pipe@plt>
  int pid = fork();
 b28:	97fffeec 	bl	6d8 <fork@plt>
  if(pid == 0){
 b2c:	35000460 	cbnz	w0, bb8 <main+0x460>
    close(fds[1]);
 b30:	b9405fe0 	ldr	w0, [sp, #92]
 b34:	97ffff05 	bl	748 <close@plt>
    int n = read(fds[0], p, 6);
 b38:	b9405be0 	ldr	w0, [sp, #88]
 b3c:	aa1503e1 	mov	x1, x21
 b40:	528000c2 	mov	w2, #0x6                   	// #6
 b44:	97fffedd 	bl	6b8 <read@plt>
    exit(n == 6 && strcmp(p, "kernel") == 0 ? 0 : 1);
 b48:	7100181f 	cmp	w0, #0x6
 b4c:	54ffeee1 	b.ne	928 <main+0x1d0>  // b.any
 b50:	aa1403e1 	mov	x1, x20
 b54:	aa1503e0 	mov	x0, x21
 b58:	97fffee8 	bl	6f8 <strcmp@plt>
 b5c:	7100001f 	cmp	w0, #0x0
 b60:	1a9f0400 	csinc	w0, w0, wzr, eq	// eq = none
 b64:	17ffff77 	b	940 <main+0x1e8>
  for(int k = 0; k < 2; k++){
 b68:	52800034 	mov	w20, #0x1                   	// #1
      sleep(3 * (k + 1));      // exit in a known order
 b6c:	11000680 	add	w0, w20, #0x1
        p[i * PG] = 10 + k;
 b70:	11002a94 	add	w20, w20, #0xa
      sleep(3 * (k + 1));      // exit in a known order
 b74:	0b000400 	add	w0, w0, w0, lsl #1
 b78:	97fffebc 	bl	668 <sleep@plt>
 b7c:	aa1303e0 	mov	x0, x19
        if(p[i * PG] != 1)
 b80:	39400001 	ldrb	w1, [x0]
 b84:	7100043f 	cmp	w1, #0x1
 b88:	54ffed01 	b.ne	928 <main+0x1d0>  // b.any
        p[i * PG] = 10 + k;
 b8c:	39000014 	strb	w20, [x0]
      for(int i = 0; i < n; i++){
 b90:	91400400 	add	x0, x0, #0x1, lsl #12
 b94:	eb15001f 	cmp	x0, x21
 b98:	54ffff41 	b.ne	b80 <main+0x428>  // b.any
        if(p[i * PG] != 10 + k)
 b9c:	39400260 	ldrb	w0, [x19]
 ba0:	6b14001f 	cmp	w0, w20
 ba4:	54ffec21 	b.ne	928 <main+0x1d0>  // b.any
      for(int i = 0; i < n; i++)
 ba8:	91400673 	add	x19, x19, #0x1, lsl #12
 bac:	eb15027f 	cmp	x19, x21
 bb0:	54ffff61 	b.ne	b9c <main+0x444>  // b.any
 bb4:	17ffff62 	b	93c <main+0x1e4>
  close(fds[0]);
 bb8:	b9405be0 	ldr	w0, [sp, #88]
 bbc:	97fffee3 	bl	748 <close@plt>
  write(fds[1], "kernel", 7);
 bc0:	b9405fe0 	ldr	w0, [sp, #92]
 bc4:	528000e2 	mov	w2, #0x7                   	// #7
 bc8:	aa1403e1 	mov	x1, x20
 bcc:	97fffeb3 	bl	698 <write@plt>
  close(fds[1]);
 bd0:	b9405fe0 	ldr	w0, [sp, #92]
 bd4:	97fffedd 	bl	748 <close@plt>
  check(child_status() == 0, "copyout: read() into a COW page");
 bd8:	94000072 	bl	da0 <child_status>
 bdc:	7100001f 	cmp	w0, #0x0
 be0:	1a9f17e0 	cset	w0, eq	// eq = none
 be4:	b0000001 	adrp	x1, 1000 <check+0x14c>
 be8:	91047421 	add	x1, x1, #0x11d
 bec:	940000b2 	bl	eb4 <check>
  check(strcmp(p, "parent") == 0, "copyout: parent page unchanged");
 bf0:	91043e61 	add	x1, x19, #0x10f
 bf4:	aa1503e0 	mov	x0, x21
 bf8:	97fffec0 	bl	6f8 <strcmp@plt>
 bfc:	7100001f 	cmp	w0, #0x0
 c00:	b0000001 	adrp	x1, 1000 <check+0x14c>
 c04:	9104f421 	add	x1, x1, #0x13d
 c08:	1a9f17e0 	cset	w0, eq	// eq = none
 c0c:	940000aa 	bl	eb4 <check>
  sbrk(-PG);
 c10:	1281ffe0 	mov	w0, #0xfffff000            	// #-4096
 c14:	97fffeb5 	bl	6e8 <sbrk@plt>
  char *p = mmap(0, n * PG, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS,
 c18:	d2880001 	mov	x1, #0x4000                	// #16384
 c1c:	d2800005 	mov	x5, #0x0                   	// #0
 c20:	12800004 	mov	w4, #0xffffffff            	// #-1
 c24:	52800443 	mov	w3, #0x22                  	// #34
 c28:	52800062 	mov	w2, #0x3                   	// #3
 c2c:	d2800000 	mov	x0, #0x0                   	// #0
 c30:	97fffe92 	bl	678 <mmap@plt>
  check(p != MAP_FAILED, "mmap: anonymous private mapping");
 c34:	b100041f 	cmn	x0, #0x1
  char *p = mmap(0, n * PG, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS,
 c38:	aa0003f3 	mov	x19, x0
  check(p != MAP_FAILED, "mmap: anonymous private mapping");
 c3c:	b0000001 	adrp	x1, 1000 <check+0x14c>
 c40:	91057021 	add	x1, x1, #0x15c
 c44:	1a9f07e0 	cset	w0, ne	// ne = any
 c48:	9400009b 	bl	eb4 <check>
  if(p == MAP_FAILED)
 c4c:	b100067f 	cmn	x19, #0x1
 c50:	54000540 	b.eq	cf8 <main+0x5a0>  // b.none
    p[i * PG] = 'a';
 c54:	91400661 	add	x1, x19, #0x1, lsl #12
 c58:	52800c20 	mov	w0, #0x61                  	// #97
 c5c:	39000260 	strb	w0, [x19]
 c60:	91401274 	add	x20, x19, #0x4, lsl #12
 c64:	39000020 	strb	w0, [x1]
 c68:	91400a61 	add	x1, x19, #0x2, lsl #12
 c6c:	39000020 	strb	w0, [x1]
 c70:	91400e61 	add	x1, x19, #0x3, lsl #12
 c74:	39000020 	strb	w0, [x1]
  int pid = fork();
 c78:	97fffe98 	bl	6d8 <fork@plt>
  if(pid == 0){
 c7c:	35000140 	cbnz	w0, ca4 <main+0x54c>
      p[i * PG] = 'b';
 c80:	52800c40 	mov	w0, #0x62                  	// #98
      if(p[i * PG] != 'a')
 c84:	39400261 	ldrb	w1, [x19]
 c88:	7101843f 	cmp	w1, #0x61
 c8c:	54ffe4e1 	b.ne	928 <main+0x1d0>  // b.any
      p[i * PG] = 'b';
 c90:	39000260 	strb	w0, [x19]
    for(int i = 0; i < n; i++){
 c94:	91400673 	add	x19, x19, #0x1, lsl #12
 c98:	eb13029f 	cmp	x20, x19
 c9c:	54ffff41 	b.ne	c84 <main+0x52c>  // b.any
 ca0:	17ffff27 	b	93c <main+0x1e4>
  check(child_status() == 0, "mmap: child sees and writes MAP_PRIVATE pages");
 ca4:	9400003f 	bl	da0 <child_status>
 ca8:	7100001f 	cmp	w0, #0x0
 cac:	1a9f17e0 	cset	w0, eq	// eq = none
 cb0:	b0000001 	adrp	x1, 1000 <check+0x14c>
 cb4:	9105f021 	add	x1, x1, #0x17c
 cb8:	9400007f 	bl	eb4 <check>
  for(int i = 0; i < n; i++)
 cbc:	aa1303e1 	mov	x1, x19
  int ok = 1;
 cc0:	52800020 	mov	w0, #0x1                   	// #1
    if(p[i * PG] != 'a')
 cc4:	39400022 	ldrb	w2, [x1]
  for(int i = 0; i < n; i++)
 cc8:	91400421 	add	x1, x1, #0x1, lsl #12
    if(p[i * PG] != 'a')
 ccc:	7101845f 	cmp	w2, #0x61
 cd0:	1a9f17e2 	cset	w2, eq	// eq = none
 cd4:	0a020000 	and	w0, w0, w2
  for(int i = 0; i < n; i++)
 cd8:	eb14003f 	cmp	x1, x20
 cdc:	54ffff41 	b.ne	cc4 <main+0x56c>  // b.any
  check(ok, "mmap: parent's MAP_PRIVATE pages unchanged");
 ce0:	b0000001 	adrp	x1, 1000 <check+0x14c>
 ce4:	9106a821 	add	x1, x1, #0x1aa
 ce8:	94000073 	bl	eb4 <check>
  munmap(p, n * PG);
 cec:	aa1303e0 	mov	x0, x19
 cf0:	d2880001 	mov	x1, #0x4000                	// #16384
 cf4:	97fffe59 	bl	658 <munmap@plt>
    big();
    isolate();
    three();
    copyout_cow();
    mmap_cow();
    exit(failures);
 cf8:	d0000000 	adrp	x0, 2000 <check+0x114c>
 cfc:	b947f800 	ldr	w0, [x0, #2040]
 d00:	17ffff10 	b	940 <main+0x1e8>
  }
  int st = -1;
 d04:	12800000 	mov	w0, #0xffffffff            	// #-1
  wait(&st);
  failures += st != 0;
 d08:	d0000013 	adrp	x19, 2000 <check+0x114c>
 d0c:	910fe273 	add	x19, x19, #0x3f8
  int st = -1;
 d10:	b9005be0 	str	w0, [sp, #88]
  wait(&st);
 d14:	910163e0 	add	x0, sp, #0x58
 d18:	97fffe64 	bl	6a8 <wait@plt>
  failures += st != 0;
 d1c:	b9405be0 	ldr	w0, [sp, #88]
 d20:	7100001f 	cmp	w0, #0x0
 d24:	b9440260 	ldr	w0, [x19, #1024]
 d28:	1a800400 	cinc	w0, w0, ne	// ne = any
 d2c:	b9040260 	str	w0, [x19, #1024]
  long free1 = meminfo("MemFree");
 d30:	aa1503e0 	mov	x0, x21
 d34:	94000024 	bl	dc4 <meminfo>
 d38:	aa0003f5 	mov	x21, x0
  printf("MemFree before %d kB, after %d kB\n", (int)free0, (int)free1);
 d3c:	2a1403e1 	mov	w1, w20
 d40:	2a1503e2 	mov	w2, w21
  // The first run may leave a page or so in kernel caches populated on
  // first use; a second run must come back exactly.
  check(free1 >= free0 - 4 * 4, "no pages leaked");
 d44:	d1004294 	sub	x20, x20, #0x10
  printf("MemFree before %d kB, after %d kB\n", (int)free0, (int)free1);
 d48:	b0000000 	adrp	x0, 1000 <check+0x14c>
 d4c:	91075400 	add	x0, x0, #0x1d5
 d50:	97fffe3e 	bl	648 <printf@plt>
  check(free1 >= free0 - 4 * 4, "no pages leaked");
 d54:	eb15029f 	cmp	x20, x21
 d58:	b0000001 	adrp	x1, 1000 <check+0x14c>
 d5c:	9107e021 	add	x1, x1, #0x1f8
 d60:	1a9fc7e0 	cset	w0, le
 d64:	94000054 	bl	eb4 <check>
  printf("cowtest: %s (%d failures)\n", failures ? "FAILED" : "OK", failures);
 d68:	b9440262 	ldr	w2, [x19, #1024]
 d6c:	90000003 	adrp	x3, 0 <.plt-0x618>
 d70:	913cd863 	add	x3, x3, #0xf36
 d74:	90000001 	adrp	x1, 0 <.plt-0x618>
 d78:	913cbc21 	add	x1, x1, #0xf2f
 d7c:	7100005f 	cmp	w2, #0x0
 d80:	9a810061 	csel	x1, x3, x1, eq	// eq = none
 d84:	b0000000 	adrp	x0, 1000 <check+0x14c>
 d88:	91082000 	add	x0, x0, #0x208
 d8c:	97fffe2f 	bl	648 <printf@plt>
  exit(failures ? 1 : 0);
 d90:	b9440260 	ldr	w0, [x19, #1024]
 d94:	7100001f 	cmp	w0, #0x0
 d98:	1a9f07e0 	cset	w0, ne	// ne = any
 d9c:	17fffee9 	b	940 <main+0x1e8>

0000000000000da0 <child_status>:
{
 da0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  int st = -1;
 da4:	12800000 	mov	w0, #0xffffffff            	// #-1
{
 da8:	910003fd 	mov	x29, sp
  int st = -1;
 dac:	b9001fe0 	str	w0, [sp, #28]
  wait(&st);
 db0:	910073e0 	add	x0, sp, #0x1c
 db4:	97fffe3d 	bl	6a8 <wait@plt>
}
 db8:	b9401fe0 	ldr	w0, [sp, #28]
 dbc:	a8c27bfd 	ldp	x29, x30, [sp], #32
 dc0:	d65f03c0 	ret

0000000000000dc4 <meminfo>:
{
 dc4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  int fd = open("/proc/meminfo", O_RDONLY), n;
 dc8:	52800001 	mov	w1, #0x0                   	// #0
{
 dcc:	910003fd 	mov	x29, sp
 dd0:	a90153f3 	stp	x19, x20, [sp, #16]
 dd4:	a9025bf5 	stp	x21, x22, [sp, #32]
 dd8:	aa0003f6 	mov	x22, x0
  int fd = open("/proc/meminfo", O_RDONLY), n;
 ddc:	90000000 	adrp	x0, 0 <.plt-0x618>
 de0:	913c4000 	add	x0, x0, #0xf10
 de4:	97fffe55 	bl	738 <open@plt>
  if(fd < 0)
 de8:	37f80280 	tbnz	w0, #31, e38 <meminfo+0x74>
  n = read(fd, buf, sizeof(buf) - 1);
 dec:	d0000014 	adrp	x20, 2000 <check+0x114c>
 df0:	910fe294 	add	x20, x20, #0x3f8
 df4:	aa1403e1 	mov	x1, x20
 df8:	52807fe2 	mov	w2, #0x3ff                 	// #1023
 dfc:	2a0003f5 	mov	w21, w0
 e00:	97fffe2e 	bl	6b8 <read@plt>
 e04:	2a0003f3 	mov	w19, w0
  close(fd);
 e08:	2a1503e0 	mov	w0, w21
 e0c:	97fffe4f 	bl	748 <close@plt>
  if(n <= 0)
 e10:	7100027f 	cmp	w19, #0x0
 e14:	5400012d 	b.le	e38 <meminfo+0x74>
  int kl = strlen(key);
 e18:	aa1603e0 	mov	x0, x22
  buf[n] = 0;
 e1c:	38334a9f 	strb	wzr, [x20, w19, uxtw]
  int kl = strlen(key);
 e20:	97fffe42 	bl	728 <strlen@plt>
 e24:	93407c15 	sxtw	x21, w0
 e28:	aa1503e2 	mov	x2, x21
  for(char *p = buf; *p; p++){
 e2c:	aa1403f3 	mov	x19, x20
 e30:	39400260 	ldrb	w0, [x19]
 e34:	35000060 	cbnz	w0, e40 <meminfo+0x7c>
    return -1;
 e38:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
 e3c:	14000016 	b	e94 <meminfo+0xd0>
    if((p == buf || p[-1] == '\n') && strncmp(p, key, kl) == 0 && p[kl] == ':'){
 e40:	eb14027f 	cmp	x19, x20
 e44:	54000080 	b.eq	e54 <meminfo+0x90>  // b.none
 e48:	385ff260 	ldurb	w0, [x19, #-1]
 e4c:	7100281f 	cmp	w0, #0xa
 e50:	540002e1 	b.ne	eac <meminfo+0xe8>  // b.any
 e54:	aa1603e1 	mov	x1, x22
 e58:	aa1303e0 	mov	x0, x19
 e5c:	b9003fe2 	str	w2, [sp, #60]
 e60:	97fffe1a 	bl	6c8 <strncmp@plt>
 e64:	b9403fe2 	ldr	w2, [sp, #60]
 e68:	35000220 	cbnz	w0, eac <meminfo+0xe8>
 e6c:	38756a60 	ldrb	w0, [x19, x21]
 e70:	7100e81f 	cmp	w0, #0x3a
 e74:	540001c1 	b.ne	eac <meminfo+0xe8>  // b.any
      p += kl + 1;
 e78:	910006b5 	add	x21, x21, #0x1
 e7c:	8b150260 	add	x0, x19, x21
      while(*p == ' ')
 e80:	39400001 	ldrb	w1, [x0]
 e84:	7100803f 	cmp	w1, #0x20
 e88:	540000e0 	b.eq	ea4 <meminfo+0xe0>  // b.none
      return atoi(p);
 e8c:	97fffe23 	bl	718 <atoi@plt>
 e90:	93407c00 	sxtw	x0, w0
}
 e94:	a94153f3 	ldp	x19, x20, [sp, #16]
 e98:	a9425bf5 	ldp	x21, x22, [sp, #32]
 e9c:	a8c47bfd 	ldp	x29, x30, [sp], #64
 ea0:	d65f03c0 	ret
        p++;
 ea4:	91000400 	add	x0, x0, #0x1
 ea8:	17fffff6 	b	e80 <meminfo+0xbc>
  for(char *p = buf; *p; p++){
 eac:	91000673 	add	x19, x19, #0x1
 eb0:	17ffffe0 	b	e30 <meminfo+0x6c>

0000000000000eb4 <check>:
{
 eb4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  printf("%s %s\n", ok ? "PASS" : "FAIL", what);
 eb8:	7100001f 	cmp	w0, #0x0
 ebc:	90000003 	adrp	x3, 0 <.plt-0x618>
 ec0:	913c7863 	add	x3, x3, #0xf1e
 ec4:	90000004 	adrp	x4, 0 <.plt-0x618>
{
 ec8:	910003fd 	mov	x29, sp
  printf("%s %s\n", ok ? "PASS" : "FAIL", what);
 ecc:	aa0103e2 	mov	x2, x1
 ed0:	913c8c81 	add	x1, x4, #0xf23
 ed4:	9a830021 	csel	x1, x1, x3, eq	// eq = none
{
 ed8:	f9000bf3 	str	x19, [sp, #16]
 edc:	2a0003f3 	mov	w19, w0
  printf("%s %s\n", ok ? "PASS" : "FAIL", what);
 ee0:	90000000 	adrp	x0, 0 <.plt-0x618>
 ee4:	913ca000 	add	x0, x0, #0xf28
 ee8:	97fffdd8 	bl	648 <printf@plt>
  if(!ok)
 eec:	350000d3 	cbnz	w19, f04 <check+0x50>
    failures++;
 ef0:	d0000000 	adrp	x0, 2000 <check+0x114c>
 ef4:	910fe000 	add	x0, x0, #0x3f8
 ef8:	b9440001 	ldr	w1, [x0, #1024]
 efc:	11000421 	add	w1, w1, #0x1
 f00:	b9040001 	str	w1, [x0, #1024]
}
 f04:	f9400bf3 	ldr	x19, [sp, #16]
 f08:	a8c27bfd 	ldp	x29, x30, [sp], #32
 f0c:	d65f03c0 	ret
