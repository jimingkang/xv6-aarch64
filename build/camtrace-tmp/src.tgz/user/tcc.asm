
user/_tcc:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000004b8 <.plt>:
 4b8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 4bc:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 4c0:	f9409e11 	ldr	x17, [x16, #312]
 4c4:	9104e210 	add	x16, x16, #0x138
 4c8:	d61f0220 	br	x17
 4cc:	d503201f 	nop
 4d0:	d503201f 	nop
 4d4:	d503201f 	nop

00000000000004d8 <strcpy@plt>:
 4d8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 4dc:	f940a211 	ldr	x17, [x16, #320]
 4e0:	91050210 	add	x16, x16, #0x140
 4e4:	d61f0220 	br	x17

00000000000004e8 <printf@plt>:
 4e8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 4ec:	f940a611 	ldr	x17, [x16, #328]
 4f0:	91052210 	add	x16, x16, #0x148
 4f4:	d61f0220 	br	x17

00000000000004f8 <memmove@plt>:
 4f8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 4fc:	f940aa11 	ldr	x17, [x16, #336]
 500:	91054210 	add	x16, x16, #0x150
 504:	d61f0220 	br	x17

0000000000000508 <write@plt>:
 508:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 50c:	f940ae11 	ldr	x17, [x16, #344]
 510:	91056210 	add	x16, x16, #0x158
 514:	d61f0220 	br	x17

0000000000000518 <fprintf@plt>:
 518:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 51c:	f940b211 	ldr	x17, [x16, #352]
 520:	91058210 	add	x16, x16, #0x160
 524:	d61f0220 	br	x17

0000000000000528 <read@plt>:
 528:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 52c:	f940b611 	ldr	x17, [x16, #360]
 530:	9105a210 	add	x16, x16, #0x168
 534:	d61f0220 	br	x17

0000000000000538 <unlink@plt>:
 538:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 53c:	f940ba11 	ldr	x17, [x16, #368]
 540:	9105c210 	add	x16, x16, #0x170
 544:	d61f0220 	br	x17

0000000000000548 <memset@plt>:
 548:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 54c:	f940be11 	ldr	x17, [x16, #376]
 550:	9105e210 	add	x16, x16, #0x178
 554:	d61f0220 	br	x17

0000000000000558 <strcmp@plt>:
 558:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 55c:	f940c211 	ldr	x17, [x16, #384]
 560:	91060210 	add	x16, x16, #0x180
 564:	d61f0220 	br	x17

0000000000000568 <exit@plt>:
 568:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 56c:	f940c611 	ldr	x17, [x16, #392]
 570:	91062210 	add	x16, x16, #0x188
 574:	d61f0220 	br	x17

0000000000000578 <strlen@plt>:
 578:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 57c:	f940ca11 	ldr	x17, [x16, #400]
 580:	91064210 	add	x16, x16, #0x190
 584:	d61f0220 	br	x17

0000000000000588 <open@plt>:
 588:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 58c:	f940ce11 	ldr	x17, [x16, #408]
 590:	91066210 	add	x16, x16, #0x198
 594:	d61f0220 	br	x17

0000000000000598 <close@plt>:
 598:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 59c:	f940d211 	ldr	x17, [x16, #416]
 5a0:	91068210 	add	x16, x16, #0x1a0
 5a4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000005a8 <main>:
  return 0;
}

int
main(int argc, char **argv)
{
     5a8:	a9b27bfd 	stp	x29, x30, [sp, #-224]!
     5ac:	910003fd 	mov	x29, sp
     5b0:	a90153f3 	stp	x19, x20, [sp, #16]
  char *in = 0, *out = "a.out";
     5b4:	b0000014 	adrp	x20, 1000 <next+0x18c>
     5b8:	910f7694 	add	x20, x20, #0x3dd
{
     5bc:	a9025bf5 	stp	x21, x22, [sp, #32]
  int fd, n = 0, r, i;
  for(i = 1; i < argc; i++){
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
     5c0:	b0000016 	adrp	x22, 1000 <next+0x18c>
     5c4:	910f8ed6 	add	x22, x22, #0x3e3
{
     5c8:	a90363f7 	stp	x23, x24, [sp, #48]
     5cc:	2a0003f8 	mov	w24, w0
     5d0:	aa0103f7 	mov	x23, x1
  for(i = 1; i < argc; i++){
     5d4:	52800033 	mov	w19, #0x1                   	// #1
  char *in = 0, *out = "a.out";
     5d8:	d2800015 	mov	x21, #0x0                   	// #0
{
     5dc:	a9046bf9 	stp	x25, x26, [sp, #64]
  for(i = 1; i < argc; i++){
     5e0:	6b18027f 	cmp	w19, w24
     5e4:	540001cb 	b.lt	61c <main+0x74>  // b.tstop
    else if(in == 0) in = argv[i];
    else { fprintf(2, "usage: tcc source.c [-o program]\n"); exit(1); }
  }
  if(in == 0){ fprintf(2, "usage: tcc source.c [-o program]\n"); exit(1); }
     5e8:	b40003b5 	cbz	x21, 65c <main+0xb4>
  fd = open(in, O_RDONLY);
     5ec:	aa1503e0 	mov	x0, x21
     5f0:	52800001 	mov	w1, #0x0                   	// #0
     5f4:	97ffffe5 	bl	588 <open@plt>
     5f8:	2a0003f6 	mov	w22, w0
  if(fd < 0){ fprintf(2, "tcc: cannot open %s\n", in); exit(1); }
     5fc:	36f803a0 	tbz	w0, #31, 670 <main+0xc8>
     600:	b0000001 	adrp	x1, 1000 <next+0x18c>
     604:	91102021 	add	x1, x1, #0x408
     608:	aa1503e2 	mov	x2, x21
     60c:	52800040 	mov	w0, #0x2                   	// #2
     610:	97ffffc2 	bl	518 <fprintf@plt>
     614:	52800020 	mov	w0, #0x1                   	// #1
     618:	97ffffd4 	bl	568 <exit@plt>
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
     61c:	937d7e79 	sbfiz	x25, x19, #3, #32
     620:	8b33cefa 	add	x26, x23, w19, sxtw #3
     624:	aa1603e1 	mov	x1, x22
     628:	f8796ae0 	ldr	x0, [x23, x25]
     62c:	97ffffcb 	bl	558 <strcmp@plt>
     630:	350000e0 	cbnz	w0, 64c <main+0xa4>
     634:	11000660 	add	w0, w19, #0x1
     638:	6b18001f 	cmp	w0, w24
     63c:	5400008a 	b.ge	64c <main+0xa4>  // b.tcont
     640:	f9400754 	ldr	x20, [x26, #8]
  for(i = 1; i < argc; i++){
     644:	11000413 	add	w19, w0, #0x1
     648:	17ffffe6 	b	5e0 <main+0x38>
    else if(in == 0) in = argv[i];
     64c:	b5000095 	cbnz	x21, 65c <main+0xb4>
     650:	f8796af5 	ldr	x21, [x23, x25]
     654:	2a1303e0 	mov	w0, w19
     658:	17fffffb 	b	644 <main+0x9c>
    else { fprintf(2, "usage: tcc source.c [-o program]\n"); exit(1); }
     65c:	b0000001 	adrp	x1, 1000 <next+0x18c>
     660:	910f9821 	add	x1, x1, #0x3e6
  while(n < SRCMAX && (r = read(fd, source + n, SRCMAX - n)) > 0) n += r;
  close(fd);
  if(n == SRCMAX){ fprintf(2, "tcc: source is too large\n"); exit(1); }
     664:	52800040 	mov	w0, #0x2                   	// #2
     668:	97ffffac 	bl	518 <fprintf@plt>
     66c:	17ffffea 	b	614 <main+0x6c>
  while(n < SRCMAX && (r = read(fd, source + n, SRCMAX - n)) > 0) n += r;
     670:	f0000035 	adrp	x21, 7000 <code+0x3564>
     674:	912a72b5 	add	x21, x21, #0xa9c
  int fd, n = 0, r, i;
     678:	52800013 	mov	w19, #0x0                   	// #0
  while(n < SRCMAX && (r = read(fd, source + n, SRCMAX - n)) > 0) n += r;
     67c:	52880017 	mov	w23, #0x4000                	// #16384
     680:	5287fff8 	mov	w24, #0x3fff                	// #16383
     684:	4b1302e2 	sub	w2, w23, w19
     688:	8b33c2a1 	add	x1, x21, w19, sxtw
     68c:	2a1603e0 	mov	w0, w22
     690:	97ffffa6 	bl	528 <read@plt>
     694:	7100001f 	cmp	w0, #0x0
     698:	5400008d 	b.le	6a8 <main+0x100>
     69c:	0b000273 	add	w19, w19, w0
     6a0:	6b18027f 	cmp	w19, w24
     6a4:	54ffff0d 	b.le	684 <main+0xdc>
  close(fd);
     6a8:	2a1603e0 	mov	w0, w22
     6ac:	97ffffbb 	bl	598 <close@plt>
  if(n == SRCMAX){ fprintf(2, "tcc: source is too large\n"); exit(1); }
     6b0:	7140127f 	cmp	w19, #0x4, lsl #12
     6b4:	54000081 	b.ne	6c4 <main+0x11c>  // b.any
     6b8:	b0000001 	adrp	x1, 1000 <next+0x18c>
     6bc:	91107421 	add	x1, x1, #0x41d
     6c0:	17ffffe9 	b	664 <main+0xbc>
  source[n] = 0; cur = source;
     6c4:	3833cabf 	strb	wzr, [x21, w19, sxtw]
     6c8:	d0000013 	adrp	x19, 2000 <_DYNAMIC>
     6cc:	9106c273 	add	x19, x19, #0x1b0
    if(word("main")) sawmain = 1;
     6d0:	b0000016 	adrp	x22, 1000 <next+0x18c>
     6d4:	9110ded6 	add	x22, x22, #0x437
  while(tok != T_EOF && tok != '{'){
     6d8:	52800f77 	mov	w23, #0x7b                  	// #123
  source[n] = 0; cur = source;
     6dc:	f9026a75 	str	x21, [x19, #1232]
  int sawmain = 0;
     6e0:	52800015 	mov	w21, #0x0                   	// #0
  next();
     6e4:	940001e4 	bl	e74 <next>
  while(tok != T_EOF && tok != '{'){
     6e8:	b9400260 	ldr	w0, [x19]
     6ec:	7104001f 	cmp	w0, #0x100
     6f0:	7a571004 	ccmp	w0, w23, #0x4, ne	// ne = any
     6f4:	540007c1 	b.ne	7ec <main+0x244>  // b.any
  if(!sawmain){ error("expected main function"); return; }
     6f8:	35000855 	cbnz	w21, 800 <main+0x258>
     6fc:	b0000000 	adrp	x0, 1000 <next+0x18c>
     700:	9110f000 	add	x0, x0, #0x43c
     704:	94000188 	bl	d24 <error>
  compile();
  if(failed || output(out) < 0) exit(1);
     708:	b944ca76 	ldr	w22, [x19, #1224]
     70c:	35fff856 	cbnz	w22, 614 <main+0x6c>
  int fd, i, payload = ncode * 4 + nstrings;
     710:	b944ce60 	ldr	w0, [x19, #1228]
  memset(&eh, 0, sizeof(eh));
     714:	52800802 	mov	w2, #0x40                  	// #64
  int fd, i, payload = ncode * 4 + nstrings;
     718:	b946e661 	ldr	w1, [x19, #1764]
     71c:	0b000835 	add	w21, w1, w0, lsl #2
  memset(&eh, 0, sizeof(eh));
     720:	52800001 	mov	w1, #0x0                   	// #0
     724:	910283e0 	add	x0, sp, #0xa0
     728:	97ffff88 	bl	548 <memset@plt>
  memset(&ph, 0, sizeof(ph));
     72c:	52800702 	mov	w2, #0x38                  	// #56
     730:	52800001 	mov	w1, #0x0                   	// #0
     734:	9101a3e0 	add	x0, sp, #0x68
     738:	97ffff84 	bl	548 <memset@plt>
  eh.magic = ELF_MAGIC;
     73c:	5288afe0 	mov	w0, #0x457f                	// #17791
     740:	72a8c980 	movk	w0, #0x464c, lsl #16
     744:	b900a3e0 	str	w0, [sp, #160]
  eh.elf[0] = 2; eh.elf[1] = 1; eh.elf[2] = 1;
     748:	52802040 	mov	w0, #0x102                 	// #258
     74c:	79014be0 	strh	w0, [sp, #164]
     750:	52800020 	mov	w0, #0x1                   	// #1
     754:	39029be0 	strb	w0, [sp, #166]
  eh.type = 2; eh.machine = 183; eh.version = 1;
     758:	1281ffa0 	mov	w0, #0xfffff002            	// #-4094
     75c:	916dc400 	add	x0, x0, #0xb71, lsl #12
    int target = ncode * 4 + patches[i].off;
     760:	b944ce66 	ldr	w6, [x19, #1228]
  for(i = 0; i < npatch; i++){
     764:	b946ea65 	ldr	w5, [x19, #1768]
    code[patches[i].insn] = 0x10000001U | (immlo << 29) | (immhi << 5);
     768:	f0000002 	adrp	x2, 3000 <strings+0x564>
     76c:	912a7042 	add	x2, x2, #0xa9c
  eh.type = 2; eh.machine = 183; eh.version = 1;
     770:	a90b7fe0 	stp	x0, xzr, [sp, #176]
  eh.entry = 0; eh.phoff = sizeof(eh);
     774:	d2800800 	mov	x0, #0x40                  	// #64
     778:	f90063e0 	str	x0, [sp, #192]
  eh.ehsize = sizeof(eh); eh.phentsize = sizeof(ph); eh.phnum = 1;
     77c:	114e0000 	add	w0, w0, #0x380, lsl #12
     780:	b900d7e0 	str	w0, [sp, #212]
     784:	52800020 	mov	w0, #0x1                   	// #1
     788:	7901b3e0 	strh	w0, [sp, #216]
  ph.type = ELF_PROG_LOAD;
     78c:	d2800020 	mov	x0, #0x1                   	// #1
     790:	f2c000e0 	movk	x0, #0x7, lsl #32
     794:	f90037e0 	str	x0, [sp, #104]
  ph.off = sizeof(eh) + sizeof(ph);
     798:	d2800f00 	mov	x0, #0x78                  	// #120
     79c:	911bb261 	add	x1, x19, #0x6ec
     7a0:	f9003be0 	str	x0, [sp, #112]
  ph.vaddr = 0; ph.paddr = 0; ph.filesz = payload; ph.memsz = payload; ph.align = 8;
     7a4:	93407ea0 	sxtw	x0, w21
    code[patches[i].insn] = 0x10000001U | (immlo << 29) | (immhi << 5);
     7a8:	52800027 	mov	w7, #0x1                   	// #1
     7ac:	72a20007 	movk	w7, #0x1000, lsl #16
  ph.vaddr = 0; ph.paddr = 0; ph.filesz = payload; ph.memsz = payload; ph.align = 8;
     7b0:	a907ffff 	stp	xzr, xzr, [sp, #120]
     7b4:	a90883e0 	stp	x0, x0, [sp, #136]
     7b8:	d2800100 	mov	x0, #0x8                   	// #8
     7bc:	f9004fe0 	str	x0, [sp, #152]
  for(i = 0; i < npatch; i++){
     7c0:	6b0502df 	cmp	w22, w5
     7c4:	54001ecb 	b.lt	b9c <main+0x5f4>  // b.tstop
  fd = open(path, O_CREATE | O_TRUNC | O_WRONLY);
     7c8:	aa1403e0 	mov	x0, x20
     7cc:	5280c021 	mov	w1, #0x601                 	// #1537
     7d0:	97ffff6e 	bl	588 <open@plt>
     7d4:	2a0003f5 	mov	w21, w0
  if(fd < 0){ fprintf(2, "tcc: cannot create %s\n", path); return -1; }
     7d8:	36f81f80 	tbz	w0, #31, bc8 <main+0x620>
     7dc:	b0000001 	adrp	x1, 1000 <next+0x18c>
     7e0:	9114fc21 	add	x1, x1, #0x53f
     7e4:	aa1403e2 	mov	x2, x20
     7e8:	17ffff89 	b	60c <main+0x64>
    if(word("main")) sawmain = 1;
     7ec:	aa1603e0 	mov	x0, x22
     7f0:	94000124 	bl	c80 <word>
     7f4:	2a0002b5 	orr	w21, w21, w0
    next();
     7f8:	9400019f 	bl	e74 <next>
     7fc:	17ffffbb 	b	6e8 <main+0x140>
  need('{', "expected '{'");
     800:	b0000001 	adrp	x1, 1000 <next+0x18c>
     804:	91114c21 	add	x1, x1, #0x453
  if(word("int")){
     808:	b0000016 	adrp	x22, 1000 <next+0x18c>
     80c:	911182d6 	add	x22, x22, #0x460
  } else if(word("return")){
     810:	b0000017 	adrp	x23, 1000 <next+0x18c>
     814:	9112baf7 	add	x23, x23, #0x4ae
  need('{', "expected '{'");
     818:	52800f60 	mov	w0, #0x7b                  	// #123
     81c:	94000248 	bl	113c <need>
  emit(0xd10403ffU);                       // sub sp, sp, #256
     820:	52807fe0 	mov	w0, #0x3ff                 	// #1023
     824:	72ba2080 	movk	w0, #0xd104, lsl #16
     828:	94000169 	bl	dcc <emit>
  emit(0x910003fdU);                       // mov x29, sp
     82c:	52807fa0 	mov	w0, #0x3fd                 	// #1021
     830:	72b22000 	movk	w0, #0x9100, lsl #16
     834:	94000166 	bl	dcc <emit>
  while(tok != '}' && tok != T_EOF && !failed) statement();
     838:	b9400260 	ldr	w0, [x19]
     83c:	52802001 	mov	w1, #0x100                 	// #256
     840:	7101f41f 	cmp	w0, #0x7d
     844:	7a411004 	ccmp	w0, w1, #0x4, ne	// ne = any
     848:	54000060 	b.eq	854 <main+0x2ac>  // b.none
     84c:	b944ca60 	ldr	w0, [x19, #1224]
     850:	34000200 	cbz	w0, 890 <main+0x2e8>
  need('}', "expected '}'");
     854:	52800fa0 	mov	w0, #0x7d                  	// #125
     858:	b0000001 	adrp	x1, 1000 <next+0x18c>
     85c:	9114c821 	add	x1, x1, #0x532
     860:	94000237 	bl	113c <need>
  if(!returned){ mov64(0, 0); mov64(7, 2); emit(0xd4000001U); }
     864:	b946e260 	ldr	w0, [x19, #1760]
     868:	35fff500 	cbnz	w0, 708 <main+0x160>
     86c:	d2800001 	mov	x1, #0x0                   	// #0
     870:	94000165 	bl	e04 <mov64>
     874:	d2800041 	mov	x1, #0x2                   	// #2
     878:	528000e0 	mov	w0, #0x7                   	// #7
     87c:	94000162 	bl	e04 <mov64>
     880:	52800020 	mov	w0, #0x1                   	// #1
     884:	72ba8000 	movk	w0, #0xd400, lsl #16
     888:	94000151 	bl	dcc <emit>
     88c:	17ffff9f 	b	708 <main+0x160>
  if(word("int")){
     890:	aa1603e0 	mov	x0, x22
     894:	940000fb 	bl	c80 <word>
     898:	34000760 	cbz	w0, 984 <main+0x3dc>
    next();
     89c:	94000176 	bl	e74 <next>
    if(tok != T_ID){ error("expected variable name"); return; }
     8a0:	b9400260 	ldr	w0, [x19]
     8a4:	7104041f 	cmp	w0, #0x101
     8a8:	540000a0 	b.eq	8bc <main+0x314>  // b.none
     8ac:	b0000000 	adrp	x0, 1000 <next+0x18c>
     8b0:	91119000 	add	x0, x0, #0x464
  else error("unsupported statement");
     8b4:	9400011c 	bl	d24 <error>
     8b8:	17ffffe0 	b	838 <main+0x290>
    if(nvar >= NVAR){ error("too many variables"); return; }
     8bc:	b944c660 	ldr	w0, [x19, #1220]
     8c0:	71007c1f 	cmp	w0, #0x1f
     8c4:	5400008d 	b.le	8d4 <main+0x32c>
     8c8:	b0000000 	adrp	x0, 1000 <next+0x18c>
     8cc:	9111ec00 	add	x0, x0, #0x47b
     8d0:	17fffff9 	b	8b4 <main+0x30c>
    strcpy(name, ident); next();
     8d4:	91001261 	add	x1, x19, #0x4
     8d8:	910283e0 	add	x0, sp, #0xa0
     8dc:	97fffeff 	bl	4d8 <strcpy@plt>
     8e0:	94000165 	bl	e74 <next>
    if(findvar(name) >= 0){ error("duplicate variable"); return; }
     8e4:	910283e0 	add	x0, sp, #0xa0
     8e8:	940000f6 	bl	cc0 <findvar>
     8ec:	3100041f 	cmn	w0, #0x1
     8f0:	54000080 	b.eq	900 <main+0x358>  // b.none
     8f4:	b0000000 	adrp	x0, 1000 <next+0x18c>
     8f8:	91123800 	add	x0, x0, #0x48e
     8fc:	17ffffee 	b	8b4 <main+0x30c>
    strcpy(vars[nvar].name, name);
     900:	b944c662 	ldr	w2, [x19, #1220]
     904:	91011278 	add	x24, x19, #0x44
     908:	52800480 	mov	w0, #0x24                  	// #36
     90c:	910283e1 	add	x1, sp, #0xa0
     910:	9b206040 	smaddl	x0, w2, w0, x24
     914:	97fffef1 	bl	4d8 <strcpy@plt>
    vars[nvar].off = nvar * 8;
     918:	b944c660 	ldr	w0, [x19, #1220]
     91c:	d2800481 	mov	x1, #0x24                  	// #36
     920:	93407c15 	sxtw	x21, w0
     924:	531d7002 	lsl	w2, w0, #3
    v = nvar++;
     928:	11000400 	add	w0, w0, #0x1
     92c:	b904c660 	str	w0, [x19, #1220]
    if(tok == '='){ next(); expr(); }
     930:	b9400260 	ldr	w0, [x19]
    vars[nvar].off = nvar * 8;
     934:	9b0162a1 	madd	x1, x21, x1, x24
     938:	b9002022 	str	w2, [x1, #32]
    if(tok == '='){ next(); expr(); }
     93c:	7100f41f 	cmp	w0, #0x3d
     940:	54000081 	b.ne	950 <main+0x3a8>  // b.any
     944:	9400014c 	bl	e74 <next>
    need('=', "expected '='"); expr();
     948:	94000204 	bl	1158 <expr>
     94c:	14000004 	b	95c <main+0x3b4>
    else mov64(0, 0);
     950:	d2800001 	mov	x1, #0x0                   	// #0
     954:	52800000 	mov	w0, #0x0                   	// #0
     958:	9400012b 	bl	e04 <mov64>
    emit(0xf9000000U | ((uint32)(vars[v].off / 8) << 10) | (29 << 5));
     95c:	d2800480 	mov	x0, #0x24                  	// #36
     960:	52800101 	mov	w1, #0x8                   	// #8
     964:	9b004eb5 	madd	x21, x21, x0, x19
     968:	b94066a0 	ldr	w0, [x21, #100]
     96c:	1ac10c00 	sdiv	w0, w0, w1
     970:	52807401 	mov	w1, #0x3a0                 	// #928
     974:	72bf2001 	movk	w1, #0xf900, lsl #16
     978:	2a002820 	orr	w0, w1, w0, lsl #10
     97c:	94000114 	bl	dcc <emit>
     980:	1400003a 	b	a68 <main+0x4c0>
  } else if(word("return")){
     984:	aa1703e0 	mov	x0, x23
     988:	940000be 	bl	c80 <word>
     98c:	34000200 	cbz	w0, 9cc <main+0x424>
    next(); expr(); need(';', "expected ';'");
     990:	94000139 	bl	e74 <next>
     994:	940001f1 	bl	1158 <expr>
     998:	52800760 	mov	w0, #0x3b                  	// #59
     99c:	b0000001 	adrp	x1, 1000 <next+0x18c>
     9a0:	91128421 	add	x1, x1, #0x4a1
     9a4:	940001e6 	bl	113c <need>
    mov64(7, 2);                          // SYS_exit
     9a8:	d2800041 	mov	x1, #0x2                   	// #2
     9ac:	528000e0 	mov	w0, #0x7                   	// #7
     9b0:	94000115 	bl	e04 <mov64>
    emit(0xd4000001U);
     9b4:	52800020 	mov	w0, #0x1                   	// #1
     9b8:	72ba8000 	movk	w0, #0xd400, lsl #16
     9bc:	94000104 	bl	dcc <emit>
    returned = 1;
     9c0:	52800020 	mov	w0, #0x1                   	// #1
     9c4:	b906e260 	str	w0, [x19, #1760]
     9c8:	17ffff9c 	b	838 <main+0x290>
  } else if(word("printf") || word("puts")){
     9cc:	b0000000 	adrp	x0, 1000 <next+0x18c>
     9d0:	9112d400 	add	x0, x0, #0x4b5
     9d4:	b0000015 	adrp	x21, 1000 <next+0x18c>
     9d8:	9112f2b5 	add	x21, x21, #0x4bc
     9dc:	940000a9 	bl	c80 <word>
     9e0:	340004e0 	cbz	w0, a7c <main+0x4d4>
    int nl = word("puts");
     9e4:	aa1503e0 	mov	x0, x21
     9e8:	940000a6 	bl	c80 <word>
     9ec:	2a0003f5 	mov	w21, w0
    next(); need('(', "expected '('");
     9f0:	94000121 	bl	e74 <next>
     9f4:	52800500 	mov	w0, #0x28                  	// #40
     9f8:	b0000001 	adrp	x1, 1000 <next+0x18c>
     9fc:	91130421 	add	x1, x1, #0x4c1
     a00:	940001cf 	bl	113c <need>
    if(tok != T_STR){ error("only a string literal is supported here"); return; }
     a04:	b9400260 	ldr	w0, [x19]
     a08:	71040c1f 	cmp	w0, #0x103
     a0c:	540005a1 	b.ne	ac0 <main+0x518>  // b.any
  int len = strlen(literal), off = nstrings;
     a10:	91138261 	add	x1, x19, #0x4e0
     a14:	f9002fe1 	str	x1, [sp, #88]
     a18:	aa0103e0 	mov	x0, x1
     a1c:	97fffed7 	bl	578 <strlen@plt>
     a20:	b946e67a 	ldr	w26, [x19, #1764]
     a24:	2a0003f8 	mov	w24, w0
  if(nstrings + len + newline > STRMAX || npatch >= NPATCH){
     a28:	0b1a0000 	add	w0, w0, w26
     a2c:	0b150000 	add	w0, w0, w21
     a30:	7140041f 	cmp	w0, #0x1, lsl #12
     a34:	540000ac 	b.gt	a48 <main+0x4a0>
     a38:	b946ea60 	ldr	w0, [x19, #1768]
     a3c:	f9402fe1 	ldr	x1, [sp, #88]
     a40:	7100fc1f 	cmp	w0, #0x3f
     a44:	5400044d 	b.le	acc <main+0x524>
    error("too many string literals");
     a48:	b0000000 	adrp	x0, 1000 <next+0x18c>
     a4c:	9113d800 	add	x0, x0, #0x4f6
     a50:	940000b5 	bl	d24 <error>
    emit_print(nl); next();
     a54:	94000108 	bl	e74 <next>
    need(')', "expected ')'"); need(';', "expected ';'");
     a58:	b0000001 	adrp	x1, 1000 <next+0x18c>
     a5c:	910ef021 	add	x1, x1, #0x3bc
     a60:	52800520 	mov	w0, #0x29                  	// #41
     a64:	940001b6 	bl	113c <need>
    need(';', "expected ';'");
     a68:	b0000001 	adrp	x1, 1000 <next+0x18c>
     a6c:	91128421 	add	x1, x1, #0x4a1
     a70:	52800760 	mov	w0, #0x3b                  	// #59
     a74:	940001b2 	bl	113c <need>
     a78:	17ffff70 	b	838 <main+0x290>
  } else if(word("printf") || word("puts")){
     a7c:	aa1503e0 	mov	x0, x21
     a80:	94000080 	bl	c80 <word>
     a84:	35fffb00 	cbnz	w0, 9e4 <main+0x43c>
  } else if(tok == T_ID){
     a88:	b9400260 	ldr	w0, [x19]
     a8c:	7104041f 	cmp	w0, #0x101
     a90:	54000781 	b.ne	b80 <main+0x5d8>  // b.any
    strcpy(name, ident); next();
     a94:	91001261 	add	x1, x19, #0x4
     a98:	910283e0 	add	x0, sp, #0xa0
     a9c:	97fffe8f 	bl	4d8 <strcpy@plt>
     aa0:	940000f5 	bl	e74 <next>
    v = findvar(name);
     aa4:	910283e0 	add	x0, sp, #0xa0
     aa8:	94000086 	bl	cc0 <findvar>
    if(v < 0){ error("unknown variable"); return; }
     aac:	3100041f 	cmn	w0, #0x1
     ab0:	540005c1 	b.ne	b68 <main+0x5c0>  // b.any
     ab4:	b0000000 	adrp	x0, 1000 <next+0x18c>
     ab8:	910eac00 	add	x0, x0, #0x3ab
     abc:	17ffff7e 	b	8b4 <main+0x30c>
    if(tok != T_STR){ error("only a string literal is supported here"); return; }
     ac0:	b0000000 	adrp	x0, 1000 <next+0x18c>
     ac4:	91133800 	add	x0, x0, #0x4ce
     ac8:	17ffff7b 	b	8b4 <main+0x30c>
  memmove(strings + nstrings, literal, len);
     acc:	d0000019 	adrp	x25, 2000 <_DYNAMIC>
     ad0:	912a7339 	add	x25, x25, #0xa9c
     ad4:	2a1803e2 	mov	w2, w24
     ad8:	8b3ac320 	add	x0, x25, w26, sxtw
     adc:	97fffe87 	bl	4f8 <memmove@plt>
  nstrings += len;
     ae0:	b946e660 	ldr	w0, [x19, #1764]
     ae4:	0b000300 	add	w0, w24, w0
  if(newline) strings[nstrings++] = '\n';
     ae8:	35000375 	cbnz	w21, b54 <main+0x5ac>
  nstrings += len;
     aec:	b906e660 	str	w0, [x19, #1764]
  mov64(0, 1);                            // stdout
     af0:	d2800021 	mov	x1, #0x1                   	// #1
     af4:	52800000 	mov	w0, #0x0                   	// #0
     af8:	940000c3 	bl	e04 <mov64>
  patches[npatch].insn = ncode;
     afc:	b946ea61 	ldr	w1, [x19, #1768]
     b00:	911bb260 	add	x0, x19, #0x6ec
     b04:	b944ce64 	ldr	w4, [x19, #1228]
     b08:	8b21cc02 	add	x2, x0, w1, sxtw #3
     b0c:	937d7c23 	sbfiz	x3, x1, #3, #32
  patches[npatch++].off = off;
     b10:	11000421 	add	w1, w1, #0x1
     b14:	b906ea61 	str	w1, [x19, #1768]
  patches[npatch].insn = ncode;
     b18:	b8236804 	str	w4, [x0, x3]
  emit(0);                                // patched to adr x1, string
     b1c:	52800000 	mov	w0, #0x0                   	// #0
  patches[npatch++].off = off;
     b20:	b900045a 	str	w26, [x2, #4]
  emit(0);                                // patched to adr x1, string
     b24:	940000aa 	bl	dcc <emit>
  mov64(2, len + newline);
     b28:	0b1802a1 	add	w1, w21, w24
     b2c:	52800040 	mov	w0, #0x2                   	// #2
     b30:	93407c21 	sxtw	x1, w1
     b34:	940000b4 	bl	e04 <mov64>
  mov64(7, 16);                           // SYS_write
     b38:	d2800201 	mov	x1, #0x10                  	// #16
     b3c:	528000e0 	mov	w0, #0x7                   	// #7
     b40:	940000b1 	bl	e04 <mov64>
  emit(0xd4000001U);                      // svc #0
     b44:	52800020 	mov	w0, #0x1                   	// #1
     b48:	72ba8000 	movk	w0, #0xd400, lsl #16
     b4c:	940000a0 	bl	dcc <emit>
     b50:	17ffffc1 	b	a54 <main+0x4ac>
  if(newline) strings[nstrings++] = '\n';
     b54:	11000401 	add	w1, w0, #0x1
     b58:	b906e661 	str	w1, [x19, #1764]
     b5c:	52800141 	mov	w1, #0xa                   	// #10
     b60:	3820cb21 	strb	w1, [x25, w0, sxtw]
     b64:	17ffffe3 	b	af0 <main+0x548>
    emit(0xf9000000U | ((uint32)(vars[v].off / 8) << 10) | (29 << 5));
     b68:	2a0003f5 	mov	w21, w0
    need('=', "expected '='"); expr();
     b6c:	b0000001 	adrp	x1, 1000 <next+0x18c>
     b70:	91143c21 	add	x1, x1, #0x50f
     b74:	528007a0 	mov	w0, #0x3d                  	// #61
     b78:	94000171 	bl	113c <need>
     b7c:	17ffff73 	b	948 <main+0x3a0>
  } else if(tok == ';') next();
     b80:	7100ec1f 	cmp	w0, #0x3b
     b84:	54000061 	b.ne	b90 <main+0x5e8>  // b.any
     b88:	940000bb 	bl	e74 <next>
     b8c:	17ffff2b 	b	838 <main+0x290>
  else error("unsupported statement");
     b90:	b0000000 	adrp	x0, 1000 <next+0x18c>
     b94:	91147000 	add	x0, x0, #0x51c
     b98:	17ffff47 	b	8b4 <main+0x30c>
    int target = ncode * 4 + patches[i].off;
     b9c:	28c10c24 	ldp	w4, w3, [x1], #8
  for(i = 0; i < npatch; i++){
     ba0:	110006d6 	add	w22, w22, #0x1
    int target = ncode * 4 + patches[i].off;
     ba4:	0b060863 	add	w3, w3, w6, lsl #2
    int delta = target - at;
     ba8:	4b040863 	sub	w3, w3, w4, lsl #2
    uint32 immhi = ((uint32)(delta >> 2)) & 0x7ffff;
     bac:	13027c60 	asr	w0, w3, #2
    code[patches[i].insn] = 0x10000001U | (immlo << 29) | (immhi << 5);
     bb0:	53030463 	ubfiz	w3, w3, #29, #2
     bb4:	531b4800 	ubfiz	w0, w0, #5, #19
     bb8:	2a030000 	orr	w0, w0, w3
     bbc:	2a070000 	orr	w0, w0, w7
     bc0:	b824d840 	str	w0, [x2, w4, sxtw #2]
  for(i = 0; i < npatch; i++){
     bc4:	17fffeff 	b	7c0 <main+0x218>
  if(writeall(fd, &eh, sizeof(eh)) < 0 || writeall(fd, &ph, sizeof(ph)) < 0 ||
     bc8:	910283e1 	add	x1, sp, #0xa0
     bcc:	52800802 	mov	w2, #0x40                  	// #64
     bd0:	94000068 	bl	d70 <writeall>
     bd4:	3100041f 	cmn	w0, #0x1
     bd8:	54000141 	b.ne	c00 <main+0x658>  // b.any
    fprintf(2, "tcc: write failed\n"); close(fd); unlink(path); return -1;
     bdc:	b0000001 	adrp	x1, 1000 <next+0x18c>
     be0:	91155821 	add	x1, x1, #0x556
     be4:	52800040 	mov	w0, #0x2                   	// #2
     be8:	97fffe4c 	bl	518 <fprintf@plt>
     bec:	2a1503e0 	mov	w0, w21
     bf0:	97fffe6a 	bl	598 <close@plt>
     bf4:	aa1403e0 	mov	x0, x20
     bf8:	97fffe50 	bl	538 <unlink@plt>
     bfc:	17fffe86 	b	614 <main+0x6c>
  if(writeall(fd, &eh, sizeof(eh)) < 0 || writeall(fd, &ph, sizeof(ph)) < 0 ||
     c00:	9101a3e1 	add	x1, sp, #0x68
     c04:	2a1503e0 	mov	w0, w21
     c08:	52800702 	mov	w2, #0x38                  	// #56
     c0c:	94000059 	bl	d70 <writeall>
     c10:	3100041f 	cmn	w0, #0x1
     c14:	54fffe40 	b.eq	bdc <main+0x634>  // b.none
     writeall(fd, code, ncode * 4) < 0 || writeall(fd, strings, nstrings) < 0){
     c18:	b944ce62 	ldr	w2, [x19, #1228]
     c1c:	f0000001 	adrp	x1, 3000 <strings+0x564>
     c20:	912a7021 	add	x1, x1, #0xa9c
     c24:	2a1503e0 	mov	w0, w21
     c28:	531e7442 	lsl	w2, w2, #2
     c2c:	94000051 	bl	d70 <writeall>
  if(writeall(fd, &eh, sizeof(eh)) < 0 || writeall(fd, &ph, sizeof(ph)) < 0 ||
     c30:	3100041f 	cmn	w0, #0x1
     c34:	54fffd40 	b.eq	bdc <main+0x634>  // b.none
     writeall(fd, code, ncode * 4) < 0 || writeall(fd, strings, nstrings) < 0){
     c38:	b946e662 	ldr	w2, [x19, #1764]
     c3c:	d0000001 	adrp	x1, 2000 <_DYNAMIC>
     c40:	912a7021 	add	x1, x1, #0xa9c
     c44:	2a1503e0 	mov	w0, w21
     c48:	9400004a 	bl	d70 <writeall>
     c4c:	3100041f 	cmn	w0, #0x1
     c50:	54fffc60 	b.eq	bdc <main+0x634>  // b.none
  close(fd);
     c54:	2a1503e0 	mov	w0, w21
     c58:	97fffe50 	bl	598 <close@plt>
  printf("tcc: wrote %s (%d bytes code, %d bytes data)\n", out, ncode*4, nstrings);
     c5c:	b946e663 	ldr	w3, [x19, #1764]
     c60:	aa1403e1 	mov	x1, x20
     c64:	b944ce62 	ldr	w2, [x19, #1228]
     c68:	b0000000 	adrp	x0, 1000 <next+0x18c>
     c6c:	9115a400 	add	x0, x0, #0x569
     c70:	531e7442 	lsl	w2, w2, #2
     c74:	97fffe1d 	bl	4e8 <printf@plt>
  exit(0);
     c78:	52800000 	mov	w0, #0x0                   	// #0
     c7c:	17fffe67 	b	618 <main+0x70>

0000000000000c80 <word>:
  return tok == T_ID && strcmp(ident, s) == 0;
     c80:	d0000001 	adrp	x1, 2000 <_DYNAMIC>
     c84:	9106c022 	add	x2, x1, #0x1b0
     c88:	b941b021 	ldr	w1, [x1, #432]
     c8c:	7104043f 	cmp	w1, #0x101
     c90:	54000141 	b.ne	cb8 <word+0x38>  // b.any
{
     c94:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
     c98:	aa0003e1 	mov	x1, x0
  return tok == T_ID && strcmp(ident, s) == 0;
     c9c:	91001040 	add	x0, x2, #0x4
{
     ca0:	910003fd 	mov	x29, sp
  return tok == T_ID && strcmp(ident, s) == 0;
     ca4:	97fffe2d 	bl	558 <strcmp@plt>
     ca8:	7100001f 	cmp	w0, #0x0
     cac:	1a9f17e0 	cset	w0, eq	// eq = none
}
     cb0:	a8c17bfd 	ldp	x29, x30, [sp], #16
     cb4:	d65f03c0 	ret
  return tok == T_ID && strcmp(ident, s) == 0;
     cb8:	52800000 	mov	w0, #0x0                   	// #0
}
     cbc:	d65f03c0 	ret

0000000000000cc0 <findvar>:
{
     cc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     cc4:	910003fd 	mov	x29, sp
     cc8:	a90153f3 	stp	x19, x20, [sp, #16]
     ccc:	d0000014 	adrp	x20, 2000 <_DYNAMIC>
     cd0:	9106c294 	add	x20, x20, #0x1b0
     cd4:	a9025bf5 	stp	x21, x22, [sp, #32]
     cd8:	aa0003f6 	mov	x22, x0
     cdc:	91011295 	add	x21, x20, #0x44
  for(i = 0; i < nvar; i++)
     ce0:	52800013 	mov	w19, #0x0                   	// #0
     ce4:	b944c680 	ldr	w0, [x20, #1220]
     ce8:	6b13001f 	cmp	w0, w19
     cec:	540000ec 	b.gt	d08 <findvar+0x48>
  return -1;
     cf0:	12800013 	mov	w19, #0xffffffff            	// #-1
}
     cf4:	2a1303e0 	mov	w0, w19
     cf8:	a94153f3 	ldp	x19, x20, [sp, #16]
     cfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
     d00:	a8c37bfd 	ldp	x29, x30, [sp], #48
     d04:	d65f03c0 	ret
    if(strcmp(vars[i].name, name) == 0) return i;
     d08:	aa1603e1 	mov	x1, x22
     d0c:	aa1503e0 	mov	x0, x21
     d10:	97fffe12 	bl	558 <strcmp@plt>
     d14:	34ffff00 	cbz	w0, cf4 <findvar+0x34>
     d18:	910092b5 	add	x21, x21, #0x24
  for(i = 0; i < nvar; i++)
     d1c:	11000673 	add	w19, w19, #0x1
     d20:	17fffff1 	b	ce4 <findvar+0x24>

0000000000000d24 <error>:
{
     d24:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     d28:	910003fd 	mov	x29, sp
     d2c:	f9000bf3 	str	x19, [sp, #16]
  if(!failed)
     d30:	d0000013 	adrp	x19, 2000 <_DYNAMIC>
     d34:	9106c273 	add	x19, x19, #0x1b0
     d38:	b944ca61 	ldr	w1, [x19, #1224]
     d3c:	35000101 	cbnz	w1, d5c <error+0x38>
    fprintf(2, "tcc:%d: %s\n", line, s);
     d40:	d0000002 	adrp	x2, 2000 <_DYNAMIC>
     d44:	b941a842 	ldr	w2, [x2, #424]
     d48:	aa0003e3 	mov	x3, x0
     d4c:	b0000001 	adrp	x1, 1000 <next+0x18c>
     d50:	910db021 	add	x1, x1, #0x36c
     d54:	52800040 	mov	w0, #0x2                   	// #2
     d58:	97fffdf0 	bl	518 <fprintf@plt>
  failed = 1;
     d5c:	52800020 	mov	w0, #0x1                   	// #1
     d60:	b904ca60 	str	w0, [x19, #1224]
}
     d64:	f9400bf3 	ldr	x19, [sp, #16]
     d68:	a8c27bfd 	ldp	x29, x30, [sp], #32
     d6c:	d65f03c0 	ret

0000000000000d70 <writeall>:
{
     d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     d74:	910003fd 	mov	x29, sp
     d78:	f9000bf3 	str	x19, [sp, #16]
     d7c:	2a0003f3 	mov	w19, w0
  while(n > 0){
     d80:	7100005f 	cmp	w2, #0x0
     d84:	540000ac 	b.gt	d98 <writeall+0x28>
  return 0;
     d88:	52800000 	mov	w0, #0x0                   	// #0
}
     d8c:	f9400bf3 	ldr	x19, [sp, #16]
     d90:	a8c37bfd 	ldp	x29, x30, [sp], #48
     d94:	d65f03c0 	ret
    m = write(fd, p, n);
     d98:	2a1303e0 	mov	w0, w19
     d9c:	f90013e1 	str	x1, [sp, #32]
     da0:	b9002fe2 	str	w2, [sp, #44]
     da4:	97fffdd9 	bl	508 <write@plt>
    if(m <= 0) return -1;
     da8:	7100001f 	cmp	w0, #0x0
     dac:	540000cd 	b.le	dc4 <writeall+0x54>
    p = (char*)p + m; n -= m;
     db0:	f94013e1 	ldr	x1, [sp, #32]
     db4:	b9402fe2 	ldr	w2, [sp, #44]
     db8:	8b204021 	add	x1, x1, w0, uxtw
     dbc:	4b000042 	sub	w2, w2, w0
     dc0:	17fffff0 	b	d80 <writeall+0x10>
    if(m <= 0) return -1;
     dc4:	12800000 	mov	w0, #0xffffffff            	// #-1
     dc8:	17fffff1 	b	d8c <writeall+0x1c>

0000000000000dcc <emit>:
  if(ncode >= CODEMAX) error("generated program is too large");
     dcc:	d0000001 	adrp	x1, 2000 <_DYNAMIC>
     dd0:	9106c021 	add	x1, x1, #0x1b0
     dd4:	b944cc22 	ldr	w2, [x1, #1228]
     dd8:	713ffc5f 	cmp	w2, #0xfff
     ddc:	5400008d 	b.le	dec <emit+0x20>
     de0:	b0000000 	adrp	x0, 1000 <next+0x18c>
     de4:	910de000 	add	x0, x0, #0x378
     de8:	17ffffcf 	b	d24 <error>
  else code[ncode++] = insn;
     dec:	11000443 	add	w3, w2, #0x1
     df0:	b904cc23 	str	w3, [x1, #1228]
     df4:	f0000001 	adrp	x1, 3000 <strings+0x564>
     df8:	912a7021 	add	x1, x1, #0xa9c
     dfc:	b822d820 	str	w0, [x1, w2, sxtw #2]
}
     e00:	d65f03c0 	ret

0000000000000e04 <mov64>:
{
     e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     e08:	910003fd 	mov	x29, sp
     e0c:	a90153f3 	stp	x19, x20, [sp, #16]
     e10:	2a0003f4 	mov	w20, w0
  emit(0xd2800000U | ((uint32)(v & 0xffff) << 5) | rd); // MOVZ
     e14:	531b3c20 	ubfiz	w0, w1, #5, #16
{
     e18:	f90013f5 	str	x21, [sp, #32]
     e1c:	aa0103f5 	mov	x21, x1
  emit(0xd2800000U | ((uint32)(v & 0xffff) << 5) | rd); // MOVZ
     e20:	52ba5001 	mov	w1, #0xd2800000            	// #-763363328
     e24:	2a140000 	orr	w0, w0, w20
     e28:	2a010000 	orr	w0, w0, w1
     e2c:	52800213 	mov	w19, #0x10                  	// #16
     e30:	97ffffe7 	bl	dcc <emit>
    if((v >> (hw * 16)) & 0xffff)
     e34:	9ad326a0 	lsr	x0, x21, x19
     e38:	72003c1f 	tst	w0, #0xffff
     e3c:	540000e0 	b.eq	e58 <mov64+0x54>  // b.none
           ((uint32)((v >> (hw * 16)) & 0xffff) << 5) | rd); // MOVK
     e40:	52be5001 	mov	w1, #0xf2800000            	// #-226492416
     e44:	531b3c00 	ubfiz	w0, w0, #5, #16
     e48:	2a134421 	orr	w1, w1, w19, lsl #17
     e4c:	2a140000 	orr	w0, w0, w20
      emit(0xf2800000U | ((uint32)hw << 21) |
     e50:	2a010000 	orr	w0, w0, w1
     e54:	97ffffde 	bl	dcc <emit>
  for(hw = 1; hw < 4; hw++)
     e58:	11004273 	add	w19, w19, #0x10
     e5c:	7101027f 	cmp	w19, #0x40
     e60:	54fffea1 	b.ne	e34 <mov64+0x30>  // b.any
}
     e64:	f94013f5 	ldr	x21, [sp, #32]
     e68:	a94153f3 	ldp	x19, x20, [sp, #16]
     e6c:	a8c37bfd 	ldp	x29, x30, [sp], #48
     e70:	d65f03c0 	ret

0000000000000e74 <next>:
{
     e74:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     e78:	d284c006 	mov	x6, #0x2600                	// #9728
    if(*cur++ == '\n') line++;
     e7c:	d0000002 	adrp	x2, 2000 <_DYNAMIC>
     e80:	9106a042 	add	x2, x2, #0x1a8
{
     e84:	910003fd 	mov	x29, sp
again:
     e88:	52800003 	mov	w3, #0x0                   	// #0
{
     e8c:	a90153f3 	stp	x19, x20, [sp, #16]
     e90:	f2c00026 	movk	x6, #0x1, lsl #32
     e94:	f90013f5 	str	x21, [sp, #32]
     e98:	d0000015 	adrp	x21, 2000 <_DYNAMIC>
     e9c:	9106c2b3 	add	x19, x21, #0x1b0
     ea0:	f9426a60 	ldr	x0, [x19, #1232]
    if(*cur++ == '\n') line++;
     ea4:	2a0303e4 	mov	w4, w3
  while(*cur == ' ' || *cur == '\t' || *cur == '\r' || *cur == '\n'){
     ea8:	39400001 	ldrb	w1, [x0]
     eac:	7100803f 	cmp	w1, #0x20
     eb0:	54000208 	b.hi	ef0 <next+0x7c>  // b.pmore
     eb4:	9ac124c5 	lsr	x5, x6, x1
     eb8:	120000a3 	and	w3, w5, #0x1
     ebc:	370000c5 	tbnz	w5, #0, ed4 <next+0x60>
     ec0:	36000044 	tbz	w4, #0, ec8 <next+0x54>
     ec4:	f9026a60 	str	x0, [x19, #1232]
  if(*cur == 0){ tok = T_EOF; return; }
     ec8:	350005c1 	cbnz	w1, f80 <next+0x10c>
     ecc:	52802001 	mov	w1, #0x100                 	// #256
     ed0:	14000044 	b	fe0 <next+0x16c>
    if(*cur++ == '\n') line++;
     ed4:	91000400 	add	x0, x0, #0x1
     ed8:	7100283f 	cmp	w1, #0xa
     edc:	54fffe41 	b.ne	ea4 <next+0x30>  // b.any
     ee0:	b9400041 	ldr	w1, [x2]
     ee4:	11000421 	add	w1, w1, #0x1
     ee8:	b9000041 	str	w1, [x2]
     eec:	17ffffee 	b	ea4 <next+0x30>
  if(cur[0] == '/' && cur[1] == '/'){
     ef0:	7100bc3f 	cmp	w1, #0x2f
     ef4:	54fffe61 	b.ne	ec0 <next+0x4c>  // b.any
     ef8:	39400404 	ldrb	w4, [x0, #1]
     efc:	7100bc9f 	cmp	w4, #0x2f
     f00:	54000121 	b.ne	f24 <next+0xb0>  // b.any
    while(*cur && *cur != '\n') cur++;
     f04:	91000801 	add	x1, x0, #0x2
     f08:	aa0103e0 	mov	x0, x1
     f0c:	38401423 	ldrb	w3, [x1], #1
     f10:	7100007f 	cmp	w3, #0x0
     f14:	7a4a1864 	ccmp	w3, #0xa, #0x4, ne	// ne = any
     f18:	54ffff81 	b.ne	f08 <next+0x94>  // b.any
again:
     f1c:	52800023 	mov	w3, #0x1                   	// #1
  while(*cur == ' ' || *cur == '\t' || *cur == '\r' || *cur == '\n'){
     f20:	17ffffe1 	b	ea4 <next+0x30>
  if(cur[0] == '/' && cur[1] == '*'){
     f24:	7100a89f 	cmp	w4, #0x2a
     f28:	54000281 	b.ne	f78 <next+0x104>  // b.any
    cur += 2;
     f2c:	91000800 	add	x0, x0, #0x2
    while(*cur && !(cur[0] == '*' && cur[1] == '/')){
     f30:	39400001 	ldrb	w1, [x0]
     f34:	34ffff41 	cbz	w1, f1c <next+0xa8>
     f38:	7100a83f 	cmp	w1, #0x2a
     f3c:	54000101 	b.ne	f5c <next+0xe8>  // b.any
     f40:	39400401 	ldrb	w1, [x0, #1]
     f44:	7100bc3f 	cmp	w1, #0x2f
     f48:	54000061 	b.ne	f54 <next+0xe0>  // b.any
    if(*cur) cur += 2;
     f4c:	91000800 	add	x0, x0, #0x2
     f50:	17fffff3 	b	f1c <next+0xa8>
      if(*cur++ == '\n') line++;
     f54:	91000400 	add	x0, x0, #0x1
     f58:	17fffff6 	b	f30 <next+0xbc>
     f5c:	91000400 	add	x0, x0, #0x1
     f60:	7100283f 	cmp	w1, #0xa
     f64:	54fffe61 	b.ne	f30 <next+0xbc>  // b.any
     f68:	b9400041 	ldr	w1, [x2]
     f6c:	11000421 	add	w1, w1, #0x1
     f70:	b9000041 	str	w1, [x2]
     f74:	17ffffef 	b	f30 <next+0xbc>
     f78:	34000043 	cbz	w3, f80 <next+0x10c>
     f7c:	f9026a60 	str	x0, [x19, #1232]
  return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
     f80:	51010422 	sub	w2, w1, #0x41
     f84:	12001c42 	and	w2, w2, #0xff
     f88:	7100e45f 	cmp	w2, #0x39
     f8c:	54000348 	b.hi	ff4 <next+0x180>  // b.pmore
     f90:	92b78006 	mov	x6, #0xffffffff43ffffff    	// #-3154116609
     f94:	f2e07fe6 	movk	x6, #0x3ff, lsl #48
     f98:	9ac224c2 	lsr	x2, x6, x2
     f9c:	36000322 	tbz	w2, #0, 1000 <next+0x18c>
     fa0:	f9426a63 	ldr	x3, [x19, #1232]
      if(i < (int)sizeof(ident)-1) ident[i++] = *cur;
     fa4:	91001267 	add	x7, x19, #0x4
     fa8:	52800005 	mov	w5, #0x0                   	// #0
    for(i = 0; isalpha_(*cur) || isdigit_(*cur); cur++)
     fac:	52800001 	mov	w1, #0x0                   	// #0
     fb0:	39400064 	ldrb	w4, [x3]
  return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
     fb4:	51010480 	sub	w0, w4, #0x41
     fb8:	12001c00 	and	w0, w0, #0xff
     fbc:	7100e41f 	cmp	w0, #0x39
     fc0:	540004e8 	b.hi	105c <next+0x1e8>  // b.pmore
     fc4:	9ac024c0 	lsr	x0, x6, x0
     fc8:	37000500 	tbnz	w0, #0, 1068 <next+0x1f4>
     fcc:	34000045 	cbz	w5, fd4 <next+0x160>
     fd0:	f9026a63 	str	x3, [x19, #1232]
    ident[i] = 0;
     fd4:	91001273 	add	x19, x19, #0x4
     fd8:	38214a7f 	strb	wzr, [x19, w1, uxtw]
    return;
     fdc:	52802021 	mov	w1, #0x101                 	// #257
}
     fe0:	a94153f3 	ldp	x19, x20, [sp, #16]
  if(*cur == 0){ tok = T_EOF; return; }
     fe4:	b901b2a1 	str	w1, [x21, #432]
}
     fe8:	f94013f5 	ldr	x21, [sp, #32]
     fec:	a8c37bfd 	ldp	x29, x30, [sp], #48
     ff0:	d65f03c0 	ret
  return c >= '0' && c <= '9';
     ff4:	5100c022 	sub	w2, w1, #0x30
  if(isdigit_(*cur)){
     ff8:	7100245f 	cmp	w2, #0x9
     ffc:	54000449 	b.ls	1084 <next+0x210>  // b.plast
    cur++;
    1000:	91000400 	add	x0, x0, #0x1
    1004:	f9026a60 	str	x0, [x19, #1232]
  if(*cur == '"'){
    1008:	7100883f 	cmp	w1, #0x22
    100c:	54fffea1 	b.ne	fe0 <next+0x16c>  // b.any
      if(i < (int)sizeof(literal)-1) literal[i++] = c;
    1010:	91138265 	add	x5, x19, #0x4e0
    for(i = 0; *cur && *cur != '"'; cur++){
    1014:	52800002 	mov	w2, #0x0                   	// #0
    1018:	52800014 	mov	w20, #0x0                   	// #0
        else if(c == 't') c = '\t';
    101c:	52800124 	mov	w4, #0x9                   	// #9
    for(i = 0; *cur && *cur != '"'; cur++){
    1020:	39400001 	ldrb	w1, [x0]
    1024:	7100883f 	cmp	w1, #0x22
    1028:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    102c:	1a9f07e3 	cset	w3, ne	// ne = any
    1030:	54000501 	b.ne	10d0 <next+0x25c>  // b.any
    1034:	36000042 	tbz	w2, #0, 103c <next+0x1c8>
    1038:	f9026a60 	str	x0, [x19, #1232]
    if(*cur == '"') cur++;
    103c:	7100883f 	cmp	w1, #0x22
    1040:	54000761 	b.ne	112c <next+0x2b8>  // b.any
    1044:	91000400 	add	x0, x0, #0x1
    1048:	f9026a60 	str	x0, [x19, #1232]
    literal[i] = 0;
    104c:	91138273 	add	x19, x19, #0x4e0
    return;
    1050:	52802061 	mov	w1, #0x103                 	// #259
    literal[i] = 0;
    1054:	38344a7f 	strb	wzr, [x19, w20, uxtw]
    return;
    1058:	17ffffe2 	b	fe0 <next+0x16c>
  return c >= '0' && c <= '9';
    105c:	5100c080 	sub	w0, w4, #0x30
    for(i = 0; isalpha_(*cur) || isdigit_(*cur); cur++)
    1060:	7100241f 	cmp	w0, #0x9
    1064:	54fffb48 	b.hi	fcc <next+0x158>  // b.pmore
      if(i < (int)sizeof(ident)-1) ident[i++] = *cur;
    1068:	7100fc3f 	cmp	w1, #0x3f
    106c:	54000060 	b.eq	1078 <next+0x204>  // b.none
    1070:	382148e4 	strb	w4, [x7, w1, uxtw]
    1074:	11000421 	add	w1, w1, #0x1
    for(i = 0; isalpha_(*cur) || isdigit_(*cur); cur++)
    1078:	91000463 	add	x3, x3, #0x1
    107c:	12000045 	and	w5, w2, #0x1
    1080:	17ffffcc 	b	fb0 <next+0x13c>
    while(isdigit_(*cur)) number = number * 10 + (*cur++ - '0');
    1084:	f9426a61 	ldr	x1, [x19, #1232]
    1088:	d2800002 	mov	x2, #0x0                   	// #0
    108c:	52800003 	mov	w3, #0x0                   	// #0
    1090:	d2800144 	mov	x4, #0xa                   	// #10
    1094:	39400020 	ldrb	w0, [x1]
  return c >= '0' && c <= '9';
    1098:	5100c000 	sub	w0, w0, #0x30
    while(isdigit_(*cur)) number = number * 10 + (*cur++ - '0');
    109c:	7100241f 	cmp	w0, #0x9
    10a0:	540000a9 	b.ls	10b4 <next+0x240>  // b.plast
    10a4:	35000103 	cbnz	w3, 10c4 <next+0x250>
    number = 0;
    10a8:	f9026e7f 	str	xzr, [x19, #1240]
    return;
    10ac:	52802041 	mov	w1, #0x102                 	// #258
    10b0:	17ffffcc 	b	fe0 <next+0x16c>
    while(isdigit_(*cur)) number = number * 10 + (*cur++ - '0');
    10b4:	9b040042 	madd	x2, x2, x4, x0
    10b8:	91000421 	add	x1, x1, #0x1
    10bc:	52800023 	mov	w3, #0x1                   	// #1
    10c0:	17fffff5 	b	1094 <next+0x220>
    10c4:	f9026a61 	str	x1, [x19, #1232]
    10c8:	f9026e62 	str	x2, [x19, #1240]
    10cc:	17fffff8 	b	10ac <next+0x238>
    for(i = 0; *cur && *cur != '"'; cur++){
    10d0:	91000402 	add	x2, x0, #0x1
      if(c == '\\'){
    10d4:	7101703f 	cmp	w1, #0x5c
    10d8:	540001e1 	b.ne	1114 <next+0x2a0>  // b.any
        c = *++cur;
    10dc:	39400401 	ldrb	w1, [x0, #1]
        if(c == 'n') c = '\n';
    10e0:	7101b83f 	cmp	w1, #0x6e
    10e4:	540001c0 	b.eq	111c <next+0x2a8>  // b.none
        else if(c == 'r') c = '\r';
    10e8:	7101c83f 	cmp	w1, #0x72
    10ec:	540001c0 	b.eq	1124 <next+0x2b0>  // b.none
        else if(c == 't') c = '\t';
    10f0:	7101d03f 	cmp	w1, #0x74
    10f4:	1a841021 	csel	w1, w1, w4, ne	// ne = any
      if(i < (int)sizeof(literal)-1) literal[i++] = c;
    10f8:	7107fe9f 	cmp	w20, #0x1ff
    10fc:	54000060 	b.eq	1108 <next+0x294>  // b.none
    1100:	383448a1 	strb	w1, [x5, w20, uxtw]
    1104:	11000694 	add	w20, w20, #0x1
    for(i = 0; *cur && *cur != '"'; cur++){
    1108:	91000440 	add	x0, x2, #0x1
    110c:	2a0303e2 	mov	w2, w3
    1110:	17ffffc4 	b	1020 <next+0x1ac>
      if(c == '\\'){
    1114:	aa0003e2 	mov	x2, x0
    1118:	17fffff8 	b	10f8 <next+0x284>
        if(c == 'n') c = '\n';
    111c:	52800141 	mov	w1, #0xa                   	// #10
    1120:	17fffff6 	b	10f8 <next+0x284>
        else if(c == 'r') c = '\r';
    1124:	528001a1 	mov	w1, #0xd                   	// #13
    1128:	17fffff4 	b	10f8 <next+0x284>
    else error("unterminated string");
    112c:	90000000 	adrp	x0, 1000 <next+0x18c>
    1130:	910e5c00 	add	x0, x0, #0x397
    1134:	97fffefc 	bl	d24 <error>
    1138:	17ffffc5 	b	104c <next+0x1d8>

000000000000113c <need>:
  if(tok != t) error(message);
    113c:	b0000002 	adrp	x2, 2000 <_DYNAMIC>
    1140:	b941b042 	ldr	w2, [x2, #432]
    1144:	6b00005f 	cmp	w2, w0
    1148:	54000060 	b.eq	1154 <need+0x18>  // b.none
    114c:	aa0103e0 	mov	x0, x1
    1150:	17fffef5 	b	d24 <error>
  else next();
    1154:	17ffff48 	b	e74 <next>

0000000000001158 <expr>:
{
    1158:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    115c:	910003fd 	mov	x29, sp
    1160:	a90153f3 	stp	x19, x20, [sp, #16]
    emit(op == '+' ? 0x8b000020U          // add x0, x1, x0
    1164:	52800414 	mov	w20, #0x20                  	// #32
    1168:	72b96014 	movk	w20, #0xcb00, lsl #16
  mul();
    116c:	9400005d 	bl	12e0 <mul>
  while(tok == '+' || tok == '-'){
    1170:	b0000013 	adrp	x19, 2000 <_DYNAMIC>
    1174:	b941b273 	ldr	w19, [x19, #432]
    1178:	528005a0 	mov	w0, #0x2d                  	// #45
    117c:	7100ae7f 	cmp	w19, #0x2b
    1180:	7a401264 	ccmp	w19, w0, #0x4, ne	// ne = any
    1184:	54000080 	b.eq	1194 <expr+0x3c>  // b.none
}
    1188:	a94153f3 	ldp	x19, x20, [sp, #16]
    118c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1190:	d65f03c0 	ret
    op = tok; next();
    1194:	97ffff38 	bl	e74 <next>
    emit(0xd10043ffU);
    1198:	52887fe0 	mov	w0, #0x43ff                	// #17407
    119c:	72ba2000 	movk	w0, #0xd100, lsl #16
    11a0:	97ffff0b 	bl	dcc <emit>
    emit(0xf90003e0U);
    11a4:	52807c00 	mov	w0, #0x3e0                 	// #992
    11a8:	72bf2000 	movk	w0, #0xf900, lsl #16
    11ac:	97ffff08 	bl	dcc <emit>
    mul();
    11b0:	9400004c 	bl	12e0 <mul>
    emit(0xf94003e1U);
    11b4:	52807c20 	mov	w0, #0x3e1                 	// #993
    11b8:	72bf2800 	movk	w0, #0xf940, lsl #16
    11bc:	97ffff04 	bl	dcc <emit>
    emit(0x910043ffU);
    11c0:	52887fe0 	mov	w0, #0x43ff                	// #17407
    11c4:	72b22000 	movk	w0, #0x9100, lsl #16
    11c8:	97ffff01 	bl	dcc <emit>
    emit(op == '+' ? 0x8b000020U          // add x0, x1, x0
    11cc:	7100ae7f 	cmp	w19, #0x2b
    11d0:	52800400 	mov	w0, #0x20                  	// #32
    11d4:	72b16000 	movk	w0, #0x8b00, lsl #16
    11d8:	1a801280 	csel	w0, w20, w0, ne	// ne = any
    11dc:	97fffefc 	bl	dcc <emit>
    11e0:	17ffffe4 	b	1170 <expr+0x18>

00000000000011e4 <unary>:
{
    11e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    11e8:	910003fd 	mov	x29, sp
    11ec:	a90153f3 	stp	x19, x20, [sp, #16]
  if(tok == '-'){
    11f0:	b0000014 	adrp	x20, 2000 <_DYNAMIC>
    11f4:	b941b280 	ldr	w0, [x20, #432]
    11f8:	9106c293 	add	x19, x20, #0x1b0
    11fc:	7100b41f 	cmp	w0, #0x2d
    1200:	54000101 	b.ne	1220 <unary+0x3c>  // b.any
    next(); unary();
    1204:	97ffff1c 	bl	e74 <next>
    1208:	97fffff7 	bl	11e4 <unary>
}
    120c:	a94153f3 	ldp	x19, x20, [sp, #16]
    emit(0xcb0003e0U);                    // sub x0, xzr, x0
    1210:	52807c00 	mov	w0, #0x3e0                 	// #992
    1214:	72b96000 	movk	w0, #0xcb00, lsl #16
}
    1218:	a8c27bfd 	ldp	x29, x30, [sp], #32
    emit(0xcb0003e0U);                    // sub x0, xzr, x0
    121c:	17fffeec 	b	dcc <emit>
  } else if(tok == '+'){
    1220:	7100ac1f 	cmp	w0, #0x2b
    1224:	54000061 	b.ne	1230 <unary+0x4c>  // b.any
    next(); unary();
    1228:	97ffff13 	bl	e74 <next>
    122c:	17fffff2 	b	11f4 <unary+0x10>
  if(tok == T_NUM){
    1230:	7104081f 	cmp	w0, #0x102
    1234:	540000e1 	b.ne	1250 <unary+0x6c>  // b.any
    mov64(0, number);
    1238:	f9426e61 	ldr	x1, [x19, #1240]
    123c:	52800000 	mov	w0, #0x0                   	// #0
    1240:	97fffef1 	bl	e04 <mov64>
}
    1244:	a94153f3 	ldp	x19, x20, [sp, #16]
    1248:	a8c27bfd 	ldp	x29, x30, [sp], #32
    next();
    124c:	17ffff0a 	b	e74 <next>
  } else if(tok == T_ID){
    1250:	7104041f 	cmp	w0, #0x101
    1254:	54000281 	b.ne	12a4 <unary+0xc0>  // b.any
    v = findvar(ident);
    1258:	91001260 	add	x0, x19, #0x4
    125c:	97fffe99 	bl	cc0 <findvar>
    if(v < 0) error("unknown variable");
    1260:	3100041f 	cmn	w0, #0x1
    1264:	540000a1 	b.ne	1278 <unary+0x94>  // b.any
    1268:	90000000 	adrp	x0, 1000 <next+0x18c>
    126c:	910eac00 	add	x0, x0, #0x3ab
    1270:	97fffead 	bl	d24 <error>
    1274:	17fffff4 	b	1244 <unary+0x60>
    else emit(0xf9400000U | ((uint32)(vars[v].off / 8) << 10) | (29 << 5));
    1278:	2a0003e0 	mov	w0, w0
    127c:	d2800481 	mov	x1, #0x24                  	// #36
    1280:	9b014c00 	madd	x0, x0, x1, x19
    1284:	52800101 	mov	w1, #0x8                   	// #8
    1288:	b9406400 	ldr	w0, [x0, #100]
    128c:	1ac10c00 	sdiv	w0, w0, w1
    1290:	52807401 	mov	w1, #0x3a0                 	// #928
    1294:	72bf2801 	movk	w1, #0xf940, lsl #16
    1298:	2a002820 	orr	w0, w1, w0, lsl #10
    129c:	97fffecc 	bl	dcc <emit>
    12a0:	17ffffe9 	b	1244 <unary+0x60>
  } else if(tok == '('){
    12a4:	7100a01f 	cmp	w0, #0x28
    12a8:	54000121 	b.ne	12cc <unary+0xe8>  // b.any
    next(); expr(); need(')', "expected ')'");
    12ac:	97fffef2 	bl	e74 <next>
    12b0:	97ffffaa 	bl	1158 <expr>
}
    12b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    next(); expr(); need(')', "expected ')'");
    12b8:	90000001 	adrp	x1, 1000 <next+0x18c>
    12bc:	910ef021 	add	x1, x1, #0x3bc
    12c0:	52800520 	mov	w0, #0x29                  	// #41
}
    12c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    next(); expr(); need(')', "expected ')'");
    12c8:	17ffff9d 	b	113c <need>
}
    12cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    error("expected expression");
    12d0:	90000000 	adrp	x0, 1000 <next+0x18c>
    12d4:	910f2400 	add	x0, x0, #0x3c9
}
    12d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    error("expected expression");
    12dc:	17fffe92 	b	d24 <error>

00000000000012e0 <mul>:
{
    12e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    12e4:	910003fd 	mov	x29, sp
    12e8:	a90153f3 	stp	x19, x20, [sp, #16]
    emit(op == '*' ? 0x9b007c20U          // mul x0, x1, x0
    12ec:	52818414 	mov	w20, #0xc20                 	// #3104
    12f0:	72b35814 	movk	w20, #0x9ac0, lsl #16
  unary();
    12f4:	97ffffbc 	bl	11e4 <unary>
  while(tok == '*' || tok == '/'){
    12f8:	b0000013 	adrp	x19, 2000 <_DYNAMIC>
    12fc:	b941b273 	ldr	w19, [x19, #432]
    1300:	528005e0 	mov	w0, #0x2f                  	// #47
    1304:	7100aa7f 	cmp	w19, #0x2a
    1308:	7a401264 	ccmp	w19, w0, #0x4, ne	// ne = any
    130c:	54000080 	b.eq	131c <mul+0x3c>  // b.none
}
    1310:	a94153f3 	ldp	x19, x20, [sp, #16]
    1314:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1318:	d65f03c0 	ret
    op = tok; next();
    131c:	97fffed6 	bl	e74 <next>
    emit(0xd10043ffU);                    // sub sp, sp, #16
    1320:	52887fe0 	mov	w0, #0x43ff                	// #17407
    1324:	72ba2000 	movk	w0, #0xd100, lsl #16
    1328:	97fffea9 	bl	dcc <emit>
    emit(0xf90003e0U);                    // str x0, [sp]
    132c:	52807c00 	mov	w0, #0x3e0                 	// #992
    1330:	72bf2000 	movk	w0, #0xf900, lsl #16
    1334:	97fffea6 	bl	dcc <emit>
    unary();
    1338:	97ffffab 	bl	11e4 <unary>
    emit(0xf94003e1U);                    // ldr x1, [sp]
    133c:	52807c20 	mov	w0, #0x3e1                 	// #993
    1340:	72bf2800 	movk	w0, #0xf940, lsl #16
    1344:	97fffea2 	bl	dcc <emit>
    emit(0x910043ffU);                    // add sp, sp, #16
    1348:	52887fe0 	mov	w0, #0x43ff                	// #17407
    134c:	72b22000 	movk	w0, #0x9100, lsl #16
    1350:	97fffe9f 	bl	dcc <emit>
    emit(op == '*' ? 0x9b007c20U          // mul x0, x1, x0
    1354:	7100aa7f 	cmp	w19, #0x2a
    1358:	528f8400 	mov	w0, #0x7c20                	// #31776
    135c:	72b36000 	movk	w0, #0x9b00, lsl #16
    1360:	1a801280 	csel	w0, w20, w0, ne	// ne = any
    1364:	97fffe9a 	bl	dcc <emit>
    1368:	17ffffe4 	b	12f8 <mul+0x18>
