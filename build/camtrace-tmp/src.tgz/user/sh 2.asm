
user/_sh:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000740 <.plt>:
 740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 744:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 748:	f945fe11 	ldr	x17, [x16, #3064]
 74c:	912fe210 	add	x16, x16, #0xbf8
 750:	d61f0220 	br	x17
 754:	d503201f 	nop
 758:	d503201f 	nop
 75c:	d503201f 	nop

0000000000000760 <strcpy@plt>:
 760:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 764:	f9460211 	ldr	x17, [x16, #3072]
 768:	91300210 	add	x16, x16, #0xc00
 76c:	d61f0220 	br	x17

0000000000000770 <printf@plt>:
 770:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 774:	f9460611 	ldr	x17, [x16, #3080]
 778:	91302210 	add	x16, x16, #0xc08
 77c:	d61f0220 	br	x17

0000000000000780 <gets@plt>:
 780:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 784:	f9460a11 	ldr	x17, [x16, #3088]
 788:	91304210 	add	x16, x16, #0xc10
 78c:	d61f0220 	br	x17

0000000000000790 <getpid@plt>:
 790:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 794:	f9460e11 	ldr	x17, [x16, #3096]
 798:	91306210 	add	x16, x16, #0xc18
 79c:	d61f0220 	br	x17

00000000000007a0 <malloc@plt>:
 7a0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 7a4:	f9461211 	ldr	x17, [x16, #3104]
 7a8:	91308210 	add	x16, x16, #0xc20
 7ac:	d61f0220 	br	x17

00000000000007b0 <pipe@plt>:
 7b0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 7b4:	f9461611 	ldr	x17, [x16, #3112]
 7b8:	9130a210 	add	x16, x16, #0xc28
 7bc:	d61f0220 	br	x17

00000000000007c0 <fprintf@plt>:
 7c0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 7c4:	f9461a11 	ldr	x17, [x16, #3120]
 7c8:	9130c210 	add	x16, x16, #0xc30
 7cc:	d61f0220 	br	x17

00000000000007d0 <chdir@plt>:
 7d0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 7d4:	f9461e11 	ldr	x17, [x16, #3128]
 7d8:	9130e210 	add	x16, x16, #0xc38
 7dc:	d61f0220 	br	x17

00000000000007e0 <exec@plt>:
 7e0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 7e4:	f9462211 	ldr	x17, [x16, #3136]
 7e8:	91310210 	add	x16, x16, #0xc40
 7ec:	d61f0220 	br	x17

00000000000007f0 <wait@plt>:
 7f0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 7f4:	f9462611 	ldr	x17, [x16, #3144]
 7f8:	91312210 	add	x16, x16, #0xc48
 7fc:	d61f0220 	br	x17

0000000000000800 <read@plt>:
 800:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 804:	f9462a11 	ldr	x17, [x16, #3152]
 808:	91314210 	add	x16, x16, #0xc50
 80c:	d61f0220 	br	x17

0000000000000810 <strncmp@plt>:
 810:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 814:	f9462e11 	ldr	x17, [x16, #3160]
 818:	91316210 	add	x16, x16, #0xc58
 81c:	d61f0220 	br	x17

0000000000000820 <strncpy@plt>:
 820:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 824:	f9463211 	ldr	x17, [x16, #3168]
 828:	91318210 	add	x16, x16, #0xc60
 82c:	d61f0220 	br	x17

0000000000000830 <fork@plt>:
 830:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 834:	f9463611 	ldr	x17, [x16, #3176]
 838:	9131a210 	add	x16, x16, #0xc68
 83c:	d61f0220 	br	x17

0000000000000840 <memset@plt>:
 840:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 844:	f9463a11 	ldr	x17, [x16, #3184]
 848:	9131c210 	add	x16, x16, #0xc70
 84c:	d61f0220 	br	x17

0000000000000850 <strcmp@plt>:
 850:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 854:	f9463e11 	ldr	x17, [x16, #3192]
 858:	9131e210 	add	x16, x16, #0xc78
 85c:	d61f0220 	br	x17

0000000000000860 <tty_set_foreground@plt>:
 860:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 864:	f9464211 	ldr	x17, [x16, #3200]
 868:	91320210 	add	x16, x16, #0xc80
 86c:	d61f0220 	br	x17

0000000000000870 <dup@plt>:
 870:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 874:	f9464611 	ldr	x17, [x16, #3208]
 878:	91322210 	add	x16, x16, #0xc88
 87c:	d61f0220 	br	x17

0000000000000880 <exit@plt>:
 880:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 884:	f9464a11 	ldr	x17, [x16, #3216]
 888:	91324210 	add	x16, x16, #0xc90
 88c:	d61f0220 	br	x17

0000000000000890 <strlen@plt>:
 890:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 894:	f9464e11 	ldr	x17, [x16, #3224]
 898:	91326210 	add	x16, x16, #0xc98
 89c:	d61f0220 	br	x17

00000000000008a0 <open@plt>:
 8a0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 8a4:	f9465211 	ldr	x17, [x16, #3232]
 8a8:	91328210 	add	x16, x16, #0xca0
 8ac:	d61f0220 	br	x17

00000000000008b0 <strchr@plt>:
 8b0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 8b4:	f9465611 	ldr	x17, [x16, #3240]
 8b8:	9132a210 	add	x16, x16, #0xca8
 8bc:	d61f0220 	br	x17

00000000000008c0 <close@plt>:
 8c0:	d0000010 	adrp	x16, 2000 <parsecmd+0x710>
 8c4:	f9465a11 	ldr	x17, [x16, #3248]
 8c8:	9132c210 	add	x16, x16, #0xcb0
 8cc:	d61f0220 	br	x17

Disassembly of section .text:

00000000000008d0 <main>:
  return 0;
}

int
main(int argc, char **argv)
{
     8d0:	a9a57bfd 	stp	x29, x30, [sp, #-432]!
     8d4:	910003fd 	mov	x29, sp
     8d8:	a90153f3 	stp	x19, x20, [sp, #16]
     8dc:	a9025bf5 	stp	x21, x22, [sp, #32]
     8e0:	a90363f7 	stp	x23, x24, [sp, #48]
  static char cwd[100] = "/";
  int fd;

  // login passes the already-selected home so the logical pwd state matches
  // the cwd inherited across exec (xv6 does not yet provide getcwd()).
  if(argc > 1 && argv[1][0] == '/'){
     8e4:	7100041f 	cmp	w0, #0x1
     8e8:	5400018d 	b.le	918 <main+0x48>
     8ec:	f9400421 	ldr	x1, [x1, #8]
     8f0:	39400020 	ldrb	w0, [x1]
     8f4:	7100bc1f 	cmp	w0, #0x2f
     8f8:	54000101 	b.ne	918 <main+0x48>  // b.any
    strncpy(cwd, argv[1], sizeof(cwd) - 1);
     8fc:	d0000013 	adrp	x19, 2000 <parsecmd+0x710>
     900:	9132e273 	add	x19, x19, #0xcb8
     904:	91023a73 	add	x19, x19, #0x8e
     908:	52800c62 	mov	w2, #0x63                  	// #99
     90c:	aa1303e0 	mov	x0, x19
     910:	97ffffc4 	bl	820 <strncpy@plt>
    cwd[sizeof(cwd) - 1] = 0;
     914:	39018e7f 	strb	wzr, [x19, #99]
  }

  // Ensure that three file descriptors are open.
  while((fd = open("/dev/tty", O_RDWR)) >= 0){
     918:	b0000013 	adrp	x19, 1000 <runcmd+0x1a8>
     91c:	91284e73 	add	x19, x19, #0xa13
     920:	aa1303e0 	mov	x0, x19
     924:	52800041 	mov	w1, #0x2                   	// #2
     928:	97ffffde 	bl	8a0 <open@plt>
     92c:	36f80140 	tbz	w0, #31, 954 <main+0x84>
    }
  }
  // A process without an attached controlling TTY can still use the system
  // console to fill a missing standard descriptor.
  if(fd < 0){
    while((fd = open("/dev/console", O_RDWR)) >= 0){
     930:	b0000013 	adrp	x19, 1000 <runcmd+0x1a8>
     934:	91287273 	add	x19, x19, #0xa1c
     938:	aa1303e0 	mov	x0, x19
     93c:	52800041 	mov	w1, #0x2                   	// #2
     940:	97ffffd8 	bl	8a0 <open@plt>
     944:	37f800e0 	tbnz	w0, #31, 960 <main+0x90>
      if(fd >= 3){
     948:	7100081f 	cmp	w0, #0x2
     94c:	54ffff6d 	b.le	938 <main+0x68>
     950:	14000003 	b	95c <main+0x8c>
    if(fd >= 3){
     954:	7100081f 	cmp	w0, #0x2
     958:	54fffe4d 	b.le	920 <main+0x50>
        close(fd);
     95c:	97ffffd9 	bl	8c0 <close@plt>
  int fd = open("/etc/rc", O_RDONLY);
     960:	b0000000 	adrp	x0, 1000 <runcmd+0x1a8>
     964:	9128a400 	add	x0, x0, #0xa29
     968:	52800001 	mov	w1, #0x0                   	// #0
     96c:	97ffffcd 	bl	8a0 <open@plt>
     970:	2a0003f4 	mov	w20, w0
  if(fd < 0)
     974:	37f80500 	tbnz	w0, #31, a14 <main+0x144>
  n = read(fd, buf, sizeof(buf) - 1);
     978:	9102c3f5 	add	x21, sp, #0xb0
     97c:	52801fe2 	mov	w2, #0xff                  	// #255
     980:	aa1503e1 	mov	x1, x21
     984:	97ffff9f 	bl	800 <read@plt>
     988:	2a0003f3 	mov	w19, w0
  close(fd);
     98c:	2a1403e0 	mov	w0, w20
     990:	97ffffcc 	bl	8c0 <close@plt>
  if(n <= 0)
     994:	7100027f 	cmp	w19, #0x0
     998:	540003ed 	b.le	a14 <main+0x144>
    if(strncmp(buf + start, "export PATH=", 12) == 0)
     99c:	b0000017 	adrp	x23, 1000 <runcmd+0x1a8>
     9a0:	9128c6f7 	add	x23, x23, #0xa31
  strncpy(shell_path, value, sizeof(shell_path) - 1);
     9a4:	d0000016 	adrp	x22, 2000 <parsecmd+0x710>
     9a8:	9132e2d6 	add	x22, x22, #0xcb8
  buf[n] = 0;
     9ac:	d2800034 	mov	x20, #0x1                   	// #1
  int n, start = 0;
     9b0:	52800000 	mov	w0, #0x0                   	// #0
  buf[n] = 0;
     9b4:	38334abf 	strb	wzr, [x21, w19, uxtw]
    if(buf[i] != '\n' && buf[i] != 0)
     9b8:	8b1402a1 	add	x1, x21, x20
     9bc:	385ff022 	ldurb	w2, [x1, #-1]
     9c0:	7100005f 	cmp	w2, #0x0
     9c4:	7a4a1844 	ccmp	w2, #0xa, #0x4, ne	// ne = any
     9c8:	540001e1 	b.ne	a04 <main+0x134>  // b.any
    buf[i] = 0;
     9cc:	381ff03f 	sturb	wzr, [x1, #-1]
    if(strncmp(buf + start, "export PATH=", 12) == 0)
     9d0:	2a0003f8 	mov	w24, w0
     9d4:	aa1703e1 	mov	x1, x23
     9d8:	8b2042a0 	add	x0, x21, w0, uxtw
     9dc:	52800182 	mov	w2, #0xc                   	// #12
     9e0:	97ffff8c 	bl	810 <strncmp@plt>
     9e4:	350000e0 	cbnz	w0, a00 <main+0x130>
      setpath(buf + start + 12);
     9e8:	91003301 	add	x1, x24, #0xc
  strncpy(shell_path, value, sizeof(shell_path) - 1);
     9ec:	aa1603e0 	mov	x0, x22
     9f0:	8b0102a1 	add	x1, x21, x1
     9f4:	52800fe2 	mov	w2, #0x7f                  	// #127
     9f8:	97ffff8a 	bl	820 <strncpy@plt>
  shell_path[sizeof(shell_path) - 1] = 0;
     9fc:	3901fedf 	strb	wzr, [x22, #127]
    start = i + 1;
     a00:	2a1403e0 	mov	w0, w20
  for(int i = 0; i <= n; i++){
     a04:	91000694 	add	x20, x20, #0x1
     a08:	51000681 	sub	w1, w20, #0x1
     a0c:	6b01027f 	cmp	w19, w1
     a10:	54fffd4a 	b.ge	9b8 <main+0xe8>  // b.tcont
  loadrc();

  // Read and run input commands.
  for(;;){
    tty_set_foreground(0);
    if(getcmd(buf, sizeof(buf)) < 0)
     a14:	d0000013 	adrp	x19, 2000 <parsecmd+0x710>
     a18:	9136aa73 	add	x19, x19, #0xdaa
      break;
    if(strncmp(buf, "export PATH=", 12) == 0){
     a1c:	b0000015 	adrp	x21, 1000 <runcmd+0x1a8>
     a20:	9128c6b5 	add	x21, x21, #0xa31
      break;
    if((buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' ') ||
       strcmp(buf, "cd\n") == 0){
      // Chdir must be called by the parent, not the child.
      buf[strlen(buf)-1] = 0;  // chop \n
      char *path = buf[2] == 0 ? "/" : buf+3;
     a24:	91000e76 	add	x22, x19, #0x3
    tty_set_foreground(0);
     a28:	52800000 	mov	w0, #0x0                   	// #0
     a2c:	97ffff8d 	bl	860 <tty_set_foreground@plt>
    if(getcmd(buf, sizeof(buf)) < 0)
     a30:	aa1303e0 	mov	x0, x19
     a34:	52800c81 	mov	w1, #0x64                  	// #100
     a38:	940000df 	bl	db4 <getcmd>
     a3c:	3100041f 	cmn	w0, #0x1
     a40:	54001b60 	b.eq	dac <main+0x4dc>  // b.none
    if(strncmp(buf, "export PATH=", 12) == 0){
     a44:	aa1503e1 	mov	x1, x21
     a48:	aa1303e0 	mov	x0, x19
     a4c:	52800182 	mov	w2, #0xc                   	// #12
     a50:	97ffff70 	bl	810 <strncmp@plt>
     a54:	35000240 	cbnz	w0, a9c <main+0x1cc>
      int n = strlen(buf);
     a58:	aa1303e0 	mov	x0, x19
     a5c:	97ffff8d 	bl	890 <strlen@plt>
      if(n > 0 && buf[n - 1] == '\n')
     a60:	7100001f 	cmp	w0, #0x0
     a64:	540000cd 	b.le	a7c <main+0x1ac>
     a68:	51000400 	sub	w0, w0, #0x1
     a6c:	38606a61 	ldrb	w1, [x19, x0]
     a70:	7100283f 	cmp	w1, #0xa
     a74:	54000041 	b.ne	a7c <main+0x1ac>  // b.any
        buf[n - 1] = 0;
     a78:	38206a7f 	strb	wzr, [x19, x0]
  strncpy(shell_path, value, sizeof(shell_path) - 1);
     a7c:	d0000014 	adrp	x20, 2000 <parsecmd+0x710>
     a80:	9132e294 	add	x20, x20, #0xcb8
     a84:	91003261 	add	x1, x19, #0xc
     a88:	aa1403e0 	mov	x0, x20
     a8c:	52800fe2 	mov	w2, #0x7f                  	// #127
     a90:	97ffff64 	bl	820 <strncpy@plt>
  shell_path[sizeof(shell_path) - 1] = 0;
     a94:	3901fe9f 	strb	wzr, [x20, #127]
      continue;
     a98:	17ffffe4 	b	a28 <main+0x158>
    if(strcmp(buf, "pwd\n") == 0){
     a9c:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     aa0:	9128f821 	add	x1, x1, #0xa3e
     aa4:	aa1303e0 	mov	x0, x19
     aa8:	97ffff6a 	bl	850 <strcmp@plt>
     aac:	35000100 	cbnz	w0, acc <main+0x1fc>
      printf("%s\n", cwd);
     ab0:	d0000001 	adrp	x1, 2000 <parsecmd+0x710>
     ab4:	9132e021 	add	x1, x1, #0xcb8
     ab8:	91023821 	add	x1, x1, #0x8e
     abc:	b0000000 	adrp	x0, 1000 <runcmd+0x1a8>
     ac0:	91283400 	add	x0, x0, #0xa0d
     ac4:	97ffff2b 	bl	770 <printf@plt>
      continue;
     ac8:	17ffffd8 	b	a28 <main+0x158>
    if(strcmp(buf, "exit\n") == 0 || strcmp(buf, "logout\n") == 0)
     acc:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     ad0:	91290c21 	add	x1, x1, #0xa43
     ad4:	aa1303e0 	mov	x0, x19
     ad8:	97ffff5e 	bl	850 <strcmp@plt>
     adc:	34001680 	cbz	w0, dac <main+0x4dc>
     ae0:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     ae4:	91292421 	add	x1, x1, #0xa49
     ae8:	aa1303e0 	mov	x0, x19
     aec:	97ffff59 	bl	850 <strcmp@plt>
     af0:	340015e0 	cbz	w0, dac <main+0x4dc>
    if((buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' ') ||
     af4:	39400260 	ldrb	w0, [x19]
     af8:	71018c1f 	cmp	w0, #0x63
     afc:	540000e1 	b.ne	b18 <main+0x248>  // b.any
     b00:	39400660 	ldrb	w0, [x19, #1]
     b04:	7101901f 	cmp	w0, #0x64
     b08:	54000081 	b.ne	b18 <main+0x248>  // b.any
     b0c:	39400a60 	ldrb	w0, [x19, #2]
     b10:	7100801f 	cmp	w0, #0x20
     b14:	540000c0 	b.eq	b2c <main+0x25c>  // b.none
       strcmp(buf, "cd\n") == 0){
     b18:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     b1c:	91294421 	add	x1, x1, #0xa51
     b20:	aa1303e0 	mov	x0, x19
     b24:	97ffff4b 	bl	850 <strcmp@plt>
    if((buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' ') ||
     b28:	350010a0 	cbnz	w0, d3c <main+0x46c>
      buf[strlen(buf)-1] = 0;  // chop \n
     b2c:	aa1303e0 	mov	x0, x19
     b30:	97ffff58 	bl	890 <strlen@plt>
     b34:	51000400 	sub	w0, w0, #0x1
      char *path = buf[2] == 0 ? "/" : buf+3;
     b38:	b0000014 	adrp	x20, 1000 <runcmd+0x1a8>
     b3c:	91284694 	add	x20, x20, #0xa11
      buf[strlen(buf)-1] = 0;  // chop \n
     b40:	38206a7f 	strb	wzr, [x19, x0]
      char *path = buf[2] == 0 ? "/" : buf+3;
     b44:	39400a60 	ldrb	w0, [x19, #2]
     b48:	7100001f 	cmp	w0, #0x0
     b4c:	9a9412d4 	csel	x20, x22, x20, ne	// ne = any
      if(chdir(path) < 0)
     b50:	aa1403e0 	mov	x0, x20
     b54:	97ffff1f 	bl	7d0 <chdir@plt>
     b58:	36f800e0 	tbz	w0, #31, b74 <main+0x2a4>
        fprintf(2, "cannot cd %s\n", path);
     b5c:	aa1403e2 	mov	x2, x20
     b60:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     b64:	91295421 	add	x1, x1, #0xa55
     b68:	52800040 	mov	w0, #0x2                   	// #2
     b6c:	97ffff15 	bl	7c0 <fprintf@plt>
     b70:	17ffffae 	b	a28 <main+0x158>
  if(path[0] != '/'){
     b74:	39400280 	ldrb	w0, [x20]
     b78:	910123e3 	add	x3, sp, #0x48
     b7c:	7100bc1f 	cmp	w0, #0x2f
     b80:	540002c1 	b.ne	bd8 <main+0x308>  // b.any
  int i = 0, n = 0;
     b84:	52800000 	mov	w0, #0x0                   	// #0
  for(i = 0; path[i] && n < (int)sizeof(input)-1; i++)
     b88:	2a0003e1 	mov	w1, w0
     b8c:	cb204294 	sub	x20, x20, w0, uxtw
     b90:	38616a82 	ldrb	w2, [x20, x1]
     b94:	2a0103e0 	mov	w0, w1
     b98:	350004e2 	cbnz	w2, c34 <main+0x364>
      output[n++] = input[start+j];
     b9c:	9102c3e6 	add	x6, sp, #0xb0
  input[n] = 0;
     ba0:	3820487f 	strb	wzr, [x3, w0, uxtw]
  output[0] = '/';
     ba4:	528005e0 	mov	w0, #0x2f                  	// #47
  i = 0;
     ba8:	d2800004 	mov	x4, #0x0                   	// #0
  output[0] = '/';
     bac:	3902c3e0 	strb	w0, [sp, #176]
  n = 1;
     bb0:	52800020 	mov	w0, #0x1                   	// #1
  while(input[i]){
     bb4:	3864c861 	ldrb	w1, [x3, w4, sxtw]
     bb8:	35000481 	cbnz	w1, c48 <main+0x378>
  output[n] = 0;
     bbc:	9102c3e1 	add	x1, sp, #0xb0
     bc0:	3820c83f 	strb	wzr, [x1, w0, sxtw]
  strcpy(cwd, output);
     bc4:	d0000000 	adrp	x0, 2000 <parsecmd+0x710>
     bc8:	9132e000 	add	x0, x0, #0xcb8
     bcc:	91023800 	add	x0, x0, #0x8e
     bd0:	97fffee4 	bl	760 <strcpy@plt>
     bd4:	17ffff95 	b	a28 <main+0x158>
    while(cwd[i] && n < (int)sizeof(input)-1)
     bd8:	d0000001 	adrp	x1, 2000 <parsecmd+0x710>
     bdc:	9132e021 	add	x1, x1, #0xcb8
     be0:	91023821 	add	x1, x1, #0x8e
     be4:	d2800000 	mov	x0, #0x0                   	// #0
     be8:	14000005 	b	bfc <main+0x32c>
     bec:	f1018c1f 	cmp	x0, #0x63
     bf0:	540000e0 	b.eq	c0c <main+0x33c>  // b.none
      input[n++] = cwd[i++];
     bf4:	38206862 	strb	w2, [x3, x0]
     bf8:	91000400 	add	x0, x0, #0x1
    while(cwd[i] && n < (int)sizeof(input)-1)
     bfc:	38616802 	ldrb	w2, [x0, x1]
     c00:	35ffff62 	cbnz	w2, bec <main+0x31c>
    if(n > 1 && input[n-1] != '/' && n < (int)sizeof(input)-1)
     c04:	7100041f 	cmp	w0, #0x1
     c08:	54fffc0d 	b.le	b88 <main+0x2b8>
     c0c:	51000401 	sub	w1, w0, #0x1
     c10:	38616861 	ldrb	w1, [x3, x1]
     c14:	7100bc3f 	cmp	w1, #0x2f
     c18:	54fffb80 	b.eq	b88 <main+0x2b8>  // b.none
     c1c:	71018c1f 	cmp	w0, #0x63
     c20:	54fffb40 	b.eq	b88 <main+0x2b8>  // b.none
      input[n++] = '/';
     c24:	528005e1 	mov	w1, #0x2f                  	// #47
     c28:	38204861 	strb	w1, [x3, w0, uxtw]
     c2c:	11000400 	add	w0, w0, #0x1
     c30:	17ffffd6 	b	b88 <main+0x2b8>
  for(i = 0; path[i] && n < (int)sizeof(input)-1; i++)
     c34:	71018c3f 	cmp	w1, #0x63
     c38:	54fffb20 	b.eq	b9c <main+0x2cc>  // b.none
    input[n++] = path[i];
     c3c:	38216862 	strb	w2, [x3, x1]
  for(i = 0; path[i] && n < (int)sizeof(input)-1; i++)
     c40:	91000421 	add	x1, x1, #0x1
     c44:	17ffffd3 	b	b90 <main+0x2c0>
    while(input[i] == '/')
     c48:	aa0403e1 	mov	x1, x4
     c4c:	91000484 	add	x4, x4, #0x1
     c50:	38616865 	ldrb	w5, [x3, x1]
     c54:	7100bcbf 	cmp	w5, #0x2f
     c58:	54ffff80 	b.eq	c48 <main+0x378>  // b.none
     c5c:	93407c24 	sxtw	x4, w1
    while(input[i] && input[i] != '/')
     c60:	38646867 	ldrb	w7, [x3, x4]
     c64:	aa0403e2 	mov	x2, x4
     c68:	91000484 	add	x4, x4, #0x1
     c6c:	7100bcff 	cmp	w7, #0x2f
     c70:	7a4018e4 	ccmp	w7, #0x0, #0x4, ne	// ne = any
     c74:	54ffff61 	b.ne	c60 <main+0x390>  // b.any
     c78:	93407c44 	sxtw	x4, w2
    if(len == 0 || (len == 1 && input[start] == '.'))
     c7c:	6b010042 	subs	w2, w2, w1
     c80:	54fff9a0 	b.eq	bb4 <main+0x2e4>  // b.none
     c84:	7100045f 	cmp	w2, #0x1
     c88:	54000321 	b.ne	cec <main+0x41c>  // b.any
     c8c:	7100b8bf 	cmp	w5, #0x2e
     c90:	54fff920 	b.eq	bb4 <main+0x2e4>  // b.none
    if(n > 1 && output[n-1] != '/' && n < (int)sizeof(output)-1)
     c94:	7100041f 	cmp	w0, #0x1
     c98:	5400014d 	b.le	cc0 <main+0x3f0>
     c9c:	51000405 	sub	w5, w0, #0x1
     ca0:	386568c5 	ldrb	w5, [x6, x5]
     ca4:	7100bcbf 	cmp	w5, #0x2f
     ca8:	540000c0 	b.eq	cc0 <main+0x3f0>  // b.none
     cac:	7101881f 	cmp	w0, #0x62
     cb0:	5400008c 	b.gt	cc0 <main+0x3f0>
      output[n++] = '/';
     cb4:	528005e5 	mov	w5, #0x2f                  	// #47
     cb8:	382048c5 	strb	w5, [x6, w0, uxtw]
     cbc:	11000400 	add	w0, w0, #0x1
    for(int j = 0; j < len && n < (int)sizeof(output)-1; j++)
     cc0:	93407c00 	sxtw	x0, w0
      output[n++] = input[start+j];
     cc4:	8b21c061 	add	x1, x3, w1, sxtw
    for(int j = 0; j < len && n < (int)sizeof(output)-1; j++)
     cc8:	d2800005 	mov	x5, #0x0                   	// #0
     ccc:	7101881f 	cmp	w0, #0x62
     cd0:	7a45d044 	ccmp	w2, w5, #0x4, le
     cd4:	54fff70d 	b.le	bb4 <main+0x2e4>
      output[n++] = input[start+j];
     cd8:	38656827 	ldrb	w7, [x1, x5]
     cdc:	910004a5 	add	x5, x5, #0x1
     ce0:	38266807 	strb	w7, [x0, x6]
    for(int j = 0; j < len && n < (int)sizeof(output)-1; j++)
     ce4:	91000400 	add	x0, x0, #0x1
     ce8:	17fffff9 	b	ccc <main+0x3fc>
    if(len == 2 && input[start] == '.' && input[start+1] == '.'){
     cec:	7100085f 	cmp	w2, #0x2
     cf0:	54fffd21 	b.ne	c94 <main+0x3c4>  // b.any
     cf4:	7100b8bf 	cmp	w5, #0x2e
     cf8:	54fffce1 	b.ne	c94 <main+0x3c4>  // b.any
     cfc:	11000425 	add	w5, w1, #0x1
     d00:	3865c865 	ldrb	w5, [x3, w5, sxtw]
     d04:	7100b8bf 	cmp	w5, #0x2e
     d08:	54fffc61 	b.ne	c94 <main+0x3c4>  // b.any
      if(n > 1){
     d0c:	7100041f 	cmp	w0, #0x1
     d10:	54fff52d 	b.le	bb4 <main+0x2e4>
        while(n > 1 && output[n-1] != '/')
     d14:	51000801 	sub	w1, w0, #0x2
     d18:	9102c3e5 	add	x5, sp, #0xb0
     d1c:	11000420 	add	w0, w1, #0x1
     d20:	34fff4a1 	cbz	w1, bb4 <main+0x2e4>
     d24:	d1000421 	sub	x1, x1, #0x1
     d28:	8b050022 	add	x2, x1, x5
     d2c:	39400442 	ldrb	w2, [x2, #1]
     d30:	7100bc5f 	cmp	w2, #0x2f
     d34:	54ffff41 	b.ne	d1c <main+0x44c>  // b.any
     d38:	17ffff9f 	b	bb4 <main+0x2e4>
      else
        setcwd(cwd, path);
      continue;
    }
    int pid = fork1();
     d3c:	9400003d 	bl	e30 <fork1>
    if(pid == 0){
     d40:	35000160 	cbnz	w0, d6c <main+0x49c>
      if(tty_set_foreground(getpid()) < 0)
     d44:	97fffe93 	bl	790 <getpid@plt>
     d48:	97fffec6 	bl	860 <tty_set_foreground@plt>
     d4c:	36f800a0 	tbz	w0, #31, d60 <main+0x490>
        fprintf(2, "sh: cannot set foreground process group\n");
     d50:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     d54:	91298c21 	add	x1, x1, #0xa63
     d58:	52800040 	mov	w0, #0x2                   	// #2
     d5c:	97fffe99 	bl	7c0 <fprintf@plt>
      runcmd(parsecmd(buf));
     d60:	aa1303e0 	mov	x0, x19
     d64:	940002e3 	bl	18f0 <parsecmd>
     d68:	9400003c 	bl	e58 <runcmd>
    }
    if(tty_set_foreground(pid) < 0)
     d6c:	97fffebd 	bl	860 <tty_set_foreground@plt>
     d70:	36f800a0 	tbz	w0, #31, d84 <main+0x4b4>
      fprintf(2, "sh: cannot set foreground process group\n");
     d74:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     d78:	91298c21 	add	x1, x1, #0xa63
     d7c:	52800040 	mov	w0, #0x2                   	// #2
     d80:	97fffe90 	bl	7c0 <fprintf@plt>
    wait(0);
     d84:	d2800000 	mov	x0, #0x0                   	// #0
     d88:	97fffe9a 	bl	7f0 <wait@plt>
    if(tty_set_foreground(getpid()) < 0)
     d8c:	97fffe81 	bl	790 <getpid@plt>
     d90:	97fffeb4 	bl	860 <tty_set_foreground@plt>
     d94:	36ffe4a0 	tbz	w0, #31, a28 <main+0x158>
      fprintf(2, "sh: cannot restore foreground process group\n");
     d98:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     d9c:	912a3021 	add	x1, x1, #0xa8c
     da0:	52800040 	mov	w0, #0x2                   	// #2
     da4:	97fffe87 	bl	7c0 <fprintf@plt>
     da8:	17ffff20 	b	a28 <main+0x158>
  }
  exit(0);
     dac:	52800000 	mov	w0, #0x0                   	// #0
     db0:	97fffeb4 	bl	880 <exit@plt>

0000000000000db4 <getcmd>:
{
     db4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
     db8:	910003fd 	mov	x29, sp
     dbc:	a90153f3 	stp	x19, x20, [sp, #16]
     dc0:	aa0003f3 	mov	x19, x0
     dc4:	2a0103f4 	mov	w20, w1
  fprintf(2, "$ ");
     dc8:	52800040 	mov	w0, #0x2                   	// #2
     dcc:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     dd0:	9125c021 	add	x1, x1, #0x970
     dd4:	97fffe7b 	bl	7c0 <fprintf@plt>
  memset(buf, 0, nbuf);
     dd8:	2a1403e2 	mov	w2, w20
     ddc:	aa1303e0 	mov	x0, x19
     de0:	52800001 	mov	w1, #0x0                   	// #0
     de4:	97fffe97 	bl	840 <memset@plt>
  gets(buf, nbuf);
     de8:	2a1403e1 	mov	w1, w20
     dec:	aa1303e0 	mov	x0, x19
     df0:	97fffe64 	bl	780 <gets@plt>
  if(buf[0] == 0) // EOF
     df4:	39400260 	ldrb	w0, [x19]
}
     df8:	a94153f3 	ldp	x19, x20, [sp, #16]
  if(buf[0] == 0) // EOF
     dfc:	7100001f 	cmp	w0, #0x0
}
     e00:	5a9f13e0 	csetm	w0, eq	// eq = none
     e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
     e08:	d65f03c0 	ret

0000000000000e0c <panic>:
}

void
panic(char *s)
{
     e0c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "%s\n", s);
     e10:	aa0003e2 	mov	x2, x0
     e14:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     e18:	91283421 	add	x1, x1, #0xa0d
{
     e1c:	910003fd 	mov	x29, sp
  fprintf(2, "%s\n", s);
     e20:	52800040 	mov	w0, #0x2                   	// #2
     e24:	97fffe67 	bl	7c0 <fprintf@plt>
  exit(1);
     e28:	52800020 	mov	w0, #0x1                   	// #1
     e2c:	97fffe95 	bl	880 <exit@plt>

0000000000000e30 <fork1>:
}

int
fork1(void)
{
     e30:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
     e34:	910003fd 	mov	x29, sp
  int pid;

  pid = fork();
     e38:	97fffe7e 	bl	830 <fork@plt>
  if(pid == -1)
     e3c:	3100041f 	cmn	w0, #0x1
     e40:	54000081 	b.ne	e50 <fork1+0x20>  // b.any
    panic("fork");
     e44:	b0000000 	adrp	x0, 1000 <runcmd+0x1a8>
     e48:	9125cc00 	add	x0, x0, #0x973
     e4c:	97fffff0 	bl	e0c <panic>
  return pid;
}
     e50:	a8c17bfd 	ldp	x29, x30, [sp], #16
     e54:	d65f03c0 	ret

0000000000000e58 <runcmd>:
{
     e58:	a9b17bfd 	stp	x29, x30, [sp, #-240]!
     e5c:	910003fd 	mov	x29, sp
     e60:	a90153f3 	stp	x19, x20, [sp, #16]
     e64:	a9025bf5 	stp	x21, x22, [sp, #32]
     e68:	a90363f7 	stp	x23, x24, [sp, #48]
     e6c:	f90023f9 	str	x25, [sp, #64]
  if(cmd == 0)
     e70:	b5000060 	cbnz	x0, e7c <runcmd+0x24>
      exit(1);
     e74:	52800020 	mov	w0, #0x1                   	// #1
     e78:	97fffe82 	bl	880 <exit@plt>
  switch(cmd->type){
     e7c:	b9400014 	ldr	w20, [x0]
     e80:	aa0003f3 	mov	x19, x0
     e84:	71000e9f 	cmp	w20, #0x3
     e88:	54000e40 	b.eq	1050 <runcmd+0x1f8>  // b.none
     e8c:	5400010c 	b.gt	eac <runcmd+0x54>
     e90:	7100069f 	cmp	w20, #0x1
     e94:	540001a0 	b.eq	ec8 <runcmd+0x70>  // b.none
     e98:	71000a9f 	cmp	w20, #0x2
     e9c:	54000b20 	b.eq	1000 <runcmd+0x1a8>  // b.none
    panic("runcmd");
     ea0:	b0000000 	adrp	x0, 1000 <runcmd+0x1a8>
     ea4:	9125e000 	add	x0, x0, #0x978
      panic("pipe");
     ea8:	97ffffd9 	bl	e0c <panic>
  switch(cmd->type){
     eac:	7100129f 	cmp	w20, #0x4
     eb0:	54000c00 	b.eq	1030 <runcmd+0x1d8>  // b.none
     eb4:	7100169f 	cmp	w20, #0x5
     eb8:	54ffff41 	b.ne	ea0 <runcmd+0x48>  // b.any
    if(fork1() == 0)
     ebc:	97ffffdd 	bl	e30 <fork1>
     ec0:	35000200 	cbnz	w0, f00 <runcmd+0xa8>
     ec4:	1400005d 	b	1038 <runcmd+0x1e0>
    if(ecmd->argv[0] == 0)
     ec8:	f9400416 	ldr	x22, [x0, #8]
     ecc:	b4fffd56 	cbz	x22, e74 <runcmd+0x1c>
  if(strchr(command, '/')){
     ed0:	aa1603e0 	mov	x0, x22
     ed4:	528005e1 	mov	w1, #0x2f                  	// #47
     ed8:	97fffe76 	bl	8b0 <strchr@plt>
     edc:	b40007c0 	cbz	x0, fd4 <runcmd+0x17c>
    exec(command, argv);
     ee0:	91002261 	add	x1, x19, #0x8
     ee4:	aa1603e0 	mov	x0, x22
  exec(path, argv);
     ee8:	97fffe3e 	bl	7e0 <exec@plt>
    fprintf(2, "exec %s failed\n", ecmd->argv[0]);
     eec:	f9400662 	ldr	x2, [x19, #8]
     ef0:	b0000001 	adrp	x1, 1000 <runcmd+0x1a8>
     ef4:	9125fc21 	add	x1, x1, #0x97f
     ef8:	52800040 	mov	w0, #0x2                   	// #2
     efc:	97fffe31 	bl	7c0 <fprintf@plt>
  exit(0);
     f00:	52800000 	mov	w0, #0x0                   	// #0
     f04:	17ffffdd 	b	e78 <runcmd+0x20>
      path[n++] = *p++;
     f08:	38216a83 	strb	w3, [x20, x1]
     f0c:	91000421 	add	x1, x1, #0x1
    while(*p && *p != ':' && n < (int)sizeof(path) - 2)
     f10:	38616843 	ldrb	w3, [x2, x1]
     f14:	8b010057 	add	x23, x2, x1
     f18:	2a0103e0 	mov	w0, w1
     f1c:	7100e87f 	cmp	w3, #0x3a
     f20:	7a401864 	ccmp	w3, #0x0, #0x4, ne	// ne = any
     f24:	540003e0 	b.eq	fa0 <runcmd+0x148>  // b.none
     f28:	f102783f 	cmp	x1, #0x9e
     f2c:	54fffee1 	b.ne	f08 <runcmd+0xb0>  // b.any
    if(path[n - 1] != '/')
     f30:	51000401 	sub	w1, w0, #0x1
     f34:	38616a81 	ldrb	w1, [x20, x1]
     f38:	7100bc3f 	cmp	w1, #0x2f
     f3c:	540003c1 	b.ne	fb4 <runcmd+0x15c>  // b.any
    for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     f40:	2a0003e1 	mov	w1, w0
     f44:	cb2042c0 	sub	x0, x22, w0, uxtw
     f48:	38616803 	ldrb	w3, [x0, x1]
     f4c:	2a0103e2 	mov	w2, w1
     f50:	35000383 	cbnz	w3, fc0 <runcmd+0x168>
    path[n] = 0;
     f54:	38224a9f 	strb	wzr, [x20, w2, uxtw]
    exec(path, argv);
     f58:	91002261 	add	x1, x19, #0x8
     f5c:	aa1403e0 	mov	x0, x20
     f60:	97fffe20 	bl	7e0 <exec@plt>
     f64:	aa1703e2 	mov	x2, x23
  while(*p){
     f68:	39400040 	ldrb	w0, [x2]
     f6c:	35000160 	cbnz	w0, f98 <runcmd+0x140>
  path[0] = '/';
     f70:	528005e0 	mov	w0, #0x2f                  	// #47
     f74:	390143e0 	strb	w0, [sp, #80]
  for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     f78:	d2800000 	mov	x0, #0x0                   	// #0
     f7c:	38606ac1 	ldrb	w1, [x22, x0]
     f80:	35000361 	cbnz	w1, fec <runcmd+0x194>
     f84:	11000400 	add	w0, w0, #0x1
  exec(path, argv);
     f88:	91002261 	add	x1, x19, #0x8
  path[n] = 0;
     f8c:	38204a9f 	strb	wzr, [x20, w0, uxtw]
  exec(path, argv);
     f90:	aa1403e0 	mov	x0, x20
     f94:	17ffffd5 	b	ee8 <runcmd+0x90>
  while(*p){
     f98:	d2800001 	mov	x1, #0x0                   	// #0
     f9c:	17ffffdd 	b	f10 <runcmd+0xb8>
      p++;
     fa0:	7100e87f 	cmp	w3, #0x3a
     fa4:	9a9716f7 	cinc	x23, x23, eq	// eq = none
    if(n == 0)
     fa8:	35fffc41 	cbnz	w1, f30 <runcmd+0xd8>
      path[n++] = '.';
     fac:	52800020 	mov	w0, #0x1                   	// #1
     fb0:	390143f9 	strb	w25, [sp, #80]
      path[n++] = '/';
     fb4:	38204a98 	strb	w24, [x20, w0, uxtw]
     fb8:	11000400 	add	w0, w0, #0x1
     fbc:	17ffffe1 	b	f40 <runcmd+0xe8>
    for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     fc0:	71027c3f 	cmp	w1, #0x9f
     fc4:	54fffc80 	b.eq	f54 <runcmd+0xfc>  // b.none
      path[n++] = command[i];
     fc8:	38216a83 	strb	w3, [x20, x1]
    for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     fcc:	91000421 	add	x1, x1, #0x1
     fd0:	17ffffde 	b	f48 <runcmd+0xf0>
  char *p = shell_path;
     fd4:	d0000002 	adrp	x2, 2000 <parsecmd+0x710>
     fd8:	9132e042 	add	x2, x2, #0xcb8
     fdc:	910143f4 	add	x20, sp, #0x50
      path[n++] = '/';
     fe0:	528005f8 	mov	w24, #0x2f                  	// #47
      path[n++] = '.';
     fe4:	528005d9 	mov	w25, #0x2e                  	// #46
     fe8:	17ffffe0 	b	f68 <runcmd+0x110>
  for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     fec:	91000400 	add	x0, x0, #0x1
     ff0:	f1027c1f 	cmp	x0, #0x9f
     ff4:	54fffca0 	b.eq	f88 <runcmd+0x130>  // b.none
    path[n++] = command[i];
     ff8:	38206a81 	strb	w1, [x20, x0]
  for(int i = 0; command[i] && n < (int)sizeof(path) - 1; i++)
     ffc:	17ffffe0 	b	f7c <runcmd+0x124>
    close(rcmd->fd);
    1000:	b9402400 	ldr	w0, [x0, #36]
    1004:	97fffe2f 	bl	8c0 <close@plt>
    if(open(rcmd->file, rcmd->mode) < 0){
    1008:	f9400a60 	ldr	x0, [x19, #16]
    100c:	b9402261 	ldr	w1, [x19, #32]
    1010:	97fffe24 	bl	8a0 <open@plt>
    1014:	36f80120 	tbz	w0, #31, 1038 <runcmd+0x1e0>
      fprintf(2, "open %s failed\n", rcmd->file);
    1018:	f9400a62 	ldr	x2, [x19, #16]
    101c:	2a1403e0 	mov	w0, w20
    1020:	90000001 	adrp	x1, 1000 <runcmd+0x1a8>
    1024:	91263c21 	add	x1, x1, #0x98f
    1028:	97fffde6 	bl	7c0 <fprintf@plt>
    102c:	17ffff92 	b	e74 <runcmd+0x1c>
    if(fork1() == 0)
    1030:	97ffff80 	bl	e30 <fork1>
    1034:	35000060 	cbnz	w0, 1040 <runcmd+0x1e8>
      runcmd(bcmd->cmd);
    1038:	f9400660 	ldr	x0, [x19, #8]
    103c:	14000004 	b	104c <runcmd+0x1f4>
    wait(0);
    1040:	d2800000 	mov	x0, #0x0                   	// #0
    1044:	97fffdeb 	bl	7f0 <wait@plt>
      runcmd(pcmd->right);
    1048:	f9400a60 	ldr	x0, [x19, #16]
      runcmd(bcmd->cmd);
    104c:	97ffff83 	bl	e58 <runcmd>
    if(pipe(p) < 0)
    1050:	910143e0 	add	x0, sp, #0x50
    1054:	97fffdd7 	bl	7b0 <pipe@plt>
    1058:	36f80080 	tbz	w0, #31, 1068 <runcmd+0x210>
      panic("pipe");
    105c:	90000000 	adrp	x0, 1000 <runcmd+0x1a8>
    1060:	91267c00 	add	x0, x0, #0x99f
    1064:	17ffff91 	b	ea8 <runcmd+0x50>
    if(fork1() == 0){
    1068:	97ffff72 	bl	e30 <fork1>
    106c:	35000140 	cbnz	w0, 1094 <runcmd+0x23c>
      close(1);
    1070:	52800020 	mov	w0, #0x1                   	// #1
    1074:	97fffe13 	bl	8c0 <close@plt>
      dup(p[1]);
    1078:	b94057e0 	ldr	w0, [sp, #84]
    107c:	97fffdfd 	bl	870 <dup@plt>
      close(p[0]);
    1080:	b94053e0 	ldr	w0, [sp, #80]
    1084:	97fffe0f 	bl	8c0 <close@plt>
      close(p[1]);
    1088:	b94057e0 	ldr	w0, [sp, #84]
    108c:	97fffe0d 	bl	8c0 <close@plt>
      runcmd(pcmd->left);
    1090:	17ffffea 	b	1038 <runcmd+0x1e0>
    if(fork1() == 0){
    1094:	97ffff67 	bl	e30 <fork1>
    1098:	35000120 	cbnz	w0, 10bc <runcmd+0x264>
      close(0);
    109c:	97fffe09 	bl	8c0 <close@plt>
      dup(p[0]);
    10a0:	b94053e0 	ldr	w0, [sp, #80]
    10a4:	97fffdf3 	bl	870 <dup@plt>
      close(p[0]);
    10a8:	b94053e0 	ldr	w0, [sp, #80]
    10ac:	97fffe05 	bl	8c0 <close@plt>
      close(p[1]);
    10b0:	b94057e0 	ldr	w0, [sp, #84]
    10b4:	97fffe03 	bl	8c0 <close@plt>
    10b8:	17ffffe4 	b	1048 <runcmd+0x1f0>
    close(p[0]);
    10bc:	b94053e0 	ldr	w0, [sp, #80]
    10c0:	97fffe00 	bl	8c0 <close@plt>
    close(p[1]);
    10c4:	b94057e0 	ldr	w0, [sp, #84]
    10c8:	97fffdfe 	bl	8c0 <close@plt>
    wait(0);
    10cc:	d2800000 	mov	x0, #0x0                   	// #0
    10d0:	97fffdc8 	bl	7f0 <wait@plt>
    wait(0);
    10d4:	d2800000 	mov	x0, #0x0                   	// #0
    10d8:	97fffdc6 	bl	7f0 <wait@plt>
    break;
    10dc:	17ffff89 	b	f00 <runcmd+0xa8>

00000000000010e0 <execcmd>:
//PAGEBREAK!
// Constructors

struct cmd*
execcmd(void)
{
    10e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  struct execcmd *cmd;

  cmd = malloc(sizeof(*cmd));
    10e4:	52801500 	mov	w0, #0xa8                  	// #168
{
    10e8:	910003fd 	mov	x29, sp
    10ec:	f9000bf3 	str	x19, [sp, #16]
  cmd = malloc(sizeof(*cmd));
    10f0:	97fffdac 	bl	7a0 <malloc@plt>
    10f4:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
    10f8:	52801502 	mov	w2, #0xa8                  	// #168
    10fc:	52800001 	mov	w1, #0x0                   	// #0
    1100:	97fffdd0 	bl	840 <memset@plt>
  cmd->type = EXEC;
    1104:	52800020 	mov	w0, #0x1                   	// #1
    1108:	b9000260 	str	w0, [x19]
  return (struct cmd*)cmd;
}
    110c:	aa1303e0 	mov	x0, x19
    1110:	f9400bf3 	ldr	x19, [sp, #16]
    1114:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1118:	d65f03c0 	ret

000000000000111c <redircmd>:

struct cmd*
redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
    111c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1120:	910003fd 	mov	x29, sp
    1124:	a90153f3 	stp	x19, x20, [sp, #16]
    1128:	2a0303f4 	mov	w20, w3
    112c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1130:	2a0403f5 	mov	w21, w4
    1134:	aa0203f6 	mov	x22, x2
    1138:	a90363f7 	stp	x23, x24, [sp, #48]
    113c:	aa0103f8 	mov	x24, x1
    1140:	aa0003f7 	mov	x23, x0
  struct redircmd *cmd;

  cmd = malloc(sizeof(*cmd));
    1144:	52800500 	mov	w0, #0x28                  	// #40
    1148:	97fffd96 	bl	7a0 <malloc@plt>
    114c:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
    1150:	52800502 	mov	w2, #0x28                  	// #40
    1154:	52800001 	mov	w1, #0x0                   	// #0
    1158:	97fffdba 	bl	840 <memset@plt>
  cmd->type = REDIR;
    115c:	52800040 	mov	w0, #0x2                   	// #2
    1160:	b9000260 	str	w0, [x19]
  cmd->file = file;
  cmd->efile = efile;
  cmd->mode = mode;
  cmd->fd = fd;
  return (struct cmd*)cmd;
}
    1164:	aa1303e0 	mov	x0, x19
  cmd->cmd = subcmd;
    1168:	a900e277 	stp	x23, x24, [x19, #8]
  cmd->efile = efile;
    116c:	f9000e76 	str	x22, [x19, #24]
  cmd->mode = mode;
    1170:	29045674 	stp	w20, w21, [x19, #32]
}
    1174:	a94153f3 	ldp	x19, x20, [sp, #16]
    1178:	a9425bf5 	ldp	x21, x22, [sp, #32]
    117c:	a94363f7 	ldp	x23, x24, [sp, #48]
    1180:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1184:	d65f03c0 	ret

0000000000001188 <pipecmd>:

struct cmd*
pipecmd(struct cmd *left, struct cmd *right)
{
    1188:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    118c:	910003fd 	mov	x29, sp
    1190:	a90153f3 	stp	x19, x20, [sp, #16]
    1194:	aa0003f4 	mov	x20, x0
  struct pipecmd *cmd;

  cmd = malloc(sizeof(*cmd));
    1198:	52800300 	mov	w0, #0x18                  	// #24
{
    119c:	f90013f5 	str	x21, [sp, #32]
    11a0:	aa0103f5 	mov	x21, x1
  cmd = malloc(sizeof(*cmd));
    11a4:	97fffd7f 	bl	7a0 <malloc@plt>
    11a8:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
    11ac:	52800302 	mov	w2, #0x18                  	// #24
    11b0:	52800001 	mov	w1, #0x0                   	// #0
    11b4:	97fffda3 	bl	840 <memset@plt>
  cmd->type = PIPE;
  cmd->left = left;
    11b8:	a900d674 	stp	x20, x21, [x19, #8]
  cmd->type = PIPE;
    11bc:	52800060 	mov	w0, #0x3                   	// #3
  cmd->right = right;
  return (struct cmd*)cmd;
}
    11c0:	f94013f5 	ldr	x21, [sp, #32]
  cmd->type = PIPE;
    11c4:	b9000260 	str	w0, [x19]
}
    11c8:	aa1303e0 	mov	x0, x19
    11cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    11d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    11d4:	d65f03c0 	ret

00000000000011d8 <listcmd>:

struct cmd*
listcmd(struct cmd *left, struct cmd *right)
{
    11d8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    11dc:	910003fd 	mov	x29, sp
    11e0:	a90153f3 	stp	x19, x20, [sp, #16]
    11e4:	aa0003f4 	mov	x20, x0
  struct listcmd *cmd;

  cmd = malloc(sizeof(*cmd));
    11e8:	52800300 	mov	w0, #0x18                  	// #24
{
    11ec:	f90013f5 	str	x21, [sp, #32]
    11f0:	aa0103f5 	mov	x21, x1
  cmd = malloc(sizeof(*cmd));
    11f4:	97fffd6b 	bl	7a0 <malloc@plt>
    11f8:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
    11fc:	52800302 	mov	w2, #0x18                  	// #24
    1200:	52800001 	mov	w1, #0x0                   	// #0
    1204:	97fffd8f 	bl	840 <memset@plt>
  cmd->type = LIST;
  cmd->left = left;
    1208:	a900d674 	stp	x20, x21, [x19, #8]
  cmd->type = LIST;
    120c:	52800080 	mov	w0, #0x4                   	// #4
  cmd->right = right;
  return (struct cmd*)cmd;
}
    1210:	f94013f5 	ldr	x21, [sp, #32]
  cmd->type = LIST;
    1214:	b9000260 	str	w0, [x19]
}
    1218:	aa1303e0 	mov	x0, x19
    121c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1220:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1224:	d65f03c0 	ret

0000000000001228 <backcmd>:

struct cmd*
backcmd(struct cmd *subcmd)
{
    1228:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    122c:	910003fd 	mov	x29, sp
    1230:	a90153f3 	stp	x19, x20, [sp, #16]
    1234:	aa0003f4 	mov	x20, x0
  struct backcmd *cmd;

  cmd = malloc(sizeof(*cmd));
    1238:	52800200 	mov	w0, #0x10                  	// #16
    123c:	97fffd59 	bl	7a0 <malloc@plt>
    1240:	aa0003f3 	mov	x19, x0
  memset(cmd, 0, sizeof(*cmd));
    1244:	52800202 	mov	w2, #0x10                  	// #16
    1248:	52800001 	mov	w1, #0x0                   	// #0
    124c:	97fffd7d 	bl	840 <memset@plt>
  cmd->type = BACK;
    1250:	528000a0 	mov	w0, #0x5                   	// #5
    1254:	b9000260 	str	w0, [x19]
  cmd->cmd = subcmd;
    1258:	f9000674 	str	x20, [x19, #8]
  return (struct cmd*)cmd;
}
    125c:	aa1303e0 	mov	x0, x19
    1260:	a94153f3 	ldp	x19, x20, [sp, #16]
    1264:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1268:	d65f03c0 	ret

000000000000126c <gettoken>:
char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>&;()";

int
gettoken(char **ps, char *es, char **q, char **eq)
{
    126c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1270:	910003fd 	mov	x29, sp
    1274:	a90153f3 	stp	x19, x20, [sp, #16]
  char *s;
  int ret;

  s = *ps;
  while(s < es && strchr(whitespace, *s))
    1278:	b0000014 	adrp	x20, 2000 <parsecmd+0x710>
    127c:	9132e294 	add	x20, x20, #0xcb8
{
    1280:	a9025bf5 	stp	x21, x22, [sp, #32]
  while(s < es && strchr(whitespace, *s))
    1284:	91020294 	add	x20, x20, #0x80
{
    1288:	aa0003f6 	mov	x22, x0
    128c:	a90363f7 	stp	x23, x24, [sp, #48]
    1290:	aa0303f5 	mov	x21, x3
    1294:	aa0103f7 	mov	x23, x1
  s = *ps;
    1298:	f9400013 	ldr	x19, [x0]
{
    129c:	aa0203f8 	mov	x24, x2
  while(s < es && strchr(whitespace, *s))
    12a0:	eb17027f 	cmp	x19, x23
    12a4:	540001a3 	b.cc	12d8 <gettoken+0x6c>  // b.lo, b.ul, b.last
    s++;
  if(q)
    12a8:	b5000258 	cbnz	x24, 12f0 <gettoken+0x84>
    *q = s;
  ret = *s;
    12ac:	39400261 	ldrb	w1, [x19]
  switch(*s){
    12b0:	7100f03f 	cmp	w1, #0x3c
    12b4:	540003a8 	b.hi	1328 <gettoken+0xbc>  // b.pmore
    12b8:	7100943f 	cmp	w1, #0x25
    12bc:	540001e8 	b.hi	12f8 <gettoken+0x8c>  // b.pmore
    12c0:	340006a1 	cbz	w1, 1394 <gettoken+0x128>
      s++;
    }
    break;
  default:
    ret = 'a';
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
    12c4:	b0000001 	adrp	x1, 2000 <parsecmd+0x710>
    12c8:	9132e021 	add	x1, x1, #0xcb8
    12cc:	91020038 	add	x24, x1, #0x80
    12d0:	91021834 	add	x20, x1, #0x86
    12d4:	1400002c 	b	1384 <gettoken+0x118>
  while(s < es && strchr(whitespace, *s))
    12d8:	39400261 	ldrb	w1, [x19]
    12dc:	aa1403e0 	mov	x0, x20
    12e0:	97fffd74 	bl	8b0 <strchr@plt>
    12e4:	b4fffe20 	cbz	x0, 12a8 <gettoken+0x3c>
    s++;
    12e8:	91000673 	add	x19, x19, #0x1
    12ec:	17ffffed 	b	12a0 <gettoken+0x34>
    *q = s;
    12f0:	f9000313 	str	x19, [x24]
    12f4:	17ffffee 	b	12ac <gettoken+0x40>
  switch(*s){
    12f8:	d2c06800 	mov	x0, #0x34000000000         	// #3573412790272
    12fc:	f2e30000 	movk	x0, #0x1800, lsl #48
    1300:	9ac12400 	lsr	x0, x0, x1
    1304:	3607fe00 	tbz	w0, #0, 12c4 <gettoken+0x58>
  ret = *s;
    1308:	2a0103f4 	mov	w20, w1
    s++;
    130c:	91000673 	add	x19, x19, #0x1
      s++;
    break;
  }
  if(eq)
    1310:	b4000055 	cbz	x21, 1318 <gettoken+0xac>
    *eq = s;
    1314:	f90002b3 	str	x19, [x21]

  while(s < es && strchr(whitespace, *s))
    1318:	b0000015 	adrp	x21, 2000 <parsecmd+0x710>
    131c:	9132e2b5 	add	x21, x21, #0xcb8
    1320:	910202b5 	add	x21, x21, #0x80
    1324:	1400001f 	b	13a0 <gettoken+0x134>
  switch(*s){
    1328:	7100f83f 	cmp	w1, #0x3e
    132c:	54000080 	b.eq	133c <gettoken+0xd0>  // b.none
    1330:	7101f03f 	cmp	w1, #0x7c
    1334:	54fffc81 	b.ne	12c4 <gettoken+0x58>  // b.any
    1338:	17fffff4 	b	1308 <gettoken+0x9c>
    if(*s == '>'){
    133c:	39400660 	ldrb	w0, [x19, #1]
    1340:	7100f81f 	cmp	w0, #0x3e
    1344:	54000080 	b.eq	1354 <gettoken+0xe8>  // b.none
    s++;
    1348:	91000673 	add	x19, x19, #0x1
  ret = *s;
    134c:	2a0103f4 	mov	w20, w1
    1350:	17fffff0 	b	1310 <gettoken+0xa4>
      s++;
    1354:	91000a73 	add	x19, x19, #0x2
      ret = '+';
    1358:	52800574 	mov	w20, #0x2b                  	// #43
    135c:	17ffffed 	b	1310 <gettoken+0xa4>
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
    1360:	39400261 	ldrb	w1, [x19]
    1364:	aa1803e0 	mov	x0, x24
    1368:	97fffd52 	bl	8b0 <strchr@plt>
    136c:	b5000100 	cbnz	x0, 138c <gettoken+0x120>
    1370:	39400261 	ldrb	w1, [x19]
    1374:	aa1403e0 	mov	x0, x20
    1378:	97fffd4e 	bl	8b0 <strchr@plt>
    137c:	b5000080 	cbnz	x0, 138c <gettoken+0x120>
      s++;
    1380:	91000673 	add	x19, x19, #0x1
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
    1384:	eb17027f 	cmp	x19, x23
    1388:	54fffec3 	b.cc	1360 <gettoken+0xf4>  // b.lo, b.ul, b.last
    ret = 'a';
    138c:	52800c34 	mov	w20, #0x61                  	// #97
    1390:	17ffffe0 	b	1310 <gettoken+0xa4>
  switch(*s){
    1394:	52800014 	mov	w20, #0x0                   	// #0
    1398:	17ffffde 	b	1310 <gettoken+0xa4>
    s++;
    139c:	91000673 	add	x19, x19, #0x1
  while(s < es && strchr(whitespace, *s))
    13a0:	eb17027f 	cmp	x19, x23
    13a4:	540000a2 	b.cs	13b8 <gettoken+0x14c>  // b.hs, b.nlast
    13a8:	39400261 	ldrb	w1, [x19]
    13ac:	aa1503e0 	mov	x0, x21
    13b0:	97fffd40 	bl	8b0 <strchr@plt>
    13b4:	b5ffff40 	cbnz	x0, 139c <gettoken+0x130>
  *ps = s;
    13b8:	f90002d3 	str	x19, [x22]
  return ret;
}
    13bc:	2a1403e0 	mov	w0, w20
    13c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    13c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    13c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    13cc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    13d0:	d65f03c0 	ret

00000000000013d4 <peek>:

int
peek(char **ps, char *es, char *toks)
{
    13d4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    13d8:	910003fd 	mov	x29, sp
    13dc:	a90153f3 	stp	x19, x20, [sp, #16]
  char *s;

  s = *ps;
  while(s < es && strchr(whitespace, *s))
    13e0:	b0000014 	adrp	x20, 2000 <parsecmd+0x710>
    13e4:	9132e294 	add	x20, x20, #0xcb8
{
    13e8:	a9025bf5 	stp	x21, x22, [sp, #32]
  while(s < es && strchr(whitespace, *s))
    13ec:	91020294 	add	x20, x20, #0x80
{
    13f0:	aa0003f5 	mov	x21, x0
  s = *ps;
    13f4:	f9400013 	ldr	x19, [x0]
{
    13f8:	aa0203f6 	mov	x22, x2
    13fc:	f9001bf7 	str	x23, [sp, #48]
    1400:	aa0103f7 	mov	x23, x1
  while(s < es && strchr(whitespace, *s))
    1404:	eb17027f 	cmp	x19, x23
    1408:	54000143 	b.cc	1430 <peek+0x5c>  // b.lo, b.ul, b.last
    s++;
  *ps = s;
    140c:	f90002b3 	str	x19, [x21]
  return *s && strchr(toks, *s);
    1410:	39400261 	ldrb	w1, [x19]
    1414:	350001a1 	cbnz	w1, 1448 <peek+0x74>
    1418:	52800000 	mov	w0, #0x0                   	// #0
}
    141c:	f9401bf7 	ldr	x23, [sp, #48]
    1420:	a94153f3 	ldp	x19, x20, [sp, #16]
    1424:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    142c:	d65f03c0 	ret
  while(s < es && strchr(whitespace, *s))
    1430:	39400261 	ldrb	w1, [x19]
    1434:	aa1403e0 	mov	x0, x20
    1438:	97fffd1e 	bl	8b0 <strchr@plt>
    143c:	b4fffe80 	cbz	x0, 140c <peek+0x38>
    s++;
    1440:	91000673 	add	x19, x19, #0x1
    1444:	17fffff0 	b	1404 <peek+0x30>
  return *s && strchr(toks, *s);
    1448:	aa1603e0 	mov	x0, x22
    144c:	97fffd19 	bl	8b0 <strchr@plt>
    1450:	f100001f 	cmp	x0, #0x0
    1454:	1a9f07e0 	cset	w0, ne	// ne = any
    1458:	17fffff1 	b	141c <peek+0x48>

000000000000145c <parseredirs>:
  return cmd;
}

struct cmd*
parseredirs(struct cmd *cmd, char **ps, char *es)
{
    145c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    1460:	910003fd 	mov	x29, sp
    1464:	a90153f3 	stp	x19, x20, [sp, #16]
    1468:	aa0103f4 	mov	x20, x1
  int tok;
  char *q, *eq;

  while(peek(ps, es, "<>")){
    146c:	aa0003f3 	mov	x19, x0
{
    1470:	a9025bf5 	stp	x21, x22, [sp, #32]
  while(peek(ps, es, "<>")){
    1474:	90000016 	adrp	x22, 1000 <runcmd+0x1a8>
    1478:	912706d6 	add	x22, x22, #0x9c1
{
    147c:	aa0203f5 	mov	x21, x2
    1480:	f9001bf7 	str	x23, [sp, #48]
  while(peek(ps, es, "<>")){
    1484:	aa1603e2 	mov	x2, x22
    1488:	aa1503e1 	mov	x1, x21
    148c:	aa1403e0 	mov	x0, x20
    1490:	97ffffd1 	bl	13d4 <peek>
    1494:	350000e0 	cbnz	w0, 14b0 <parseredirs+0x54>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
      break;
    }
  }
  return cmd;
}
    1498:	f9401bf7 	ldr	x23, [sp, #48]
    149c:	aa1303e0 	mov	x0, x19
    14a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    14a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    14a8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    14ac:	d65f03c0 	ret
    tok = gettoken(ps, es, 0, 0);
    14b0:	aa1503e1 	mov	x1, x21
    14b4:	d2800003 	mov	x3, #0x0                   	// #0
    14b8:	d2800002 	mov	x2, #0x0                   	// #0
    14bc:	aa1403e0 	mov	x0, x20
    14c0:	97ffff6b 	bl	126c <gettoken>
    14c4:	2a0003f7 	mov	w23, w0
    if(gettoken(ps, es, &q, &eq) != 'a')
    14c8:	910123e3 	add	x3, sp, #0x48
    14cc:	910103e2 	add	x2, sp, #0x40
    14d0:	aa1503e1 	mov	x1, x21
    14d4:	aa1403e0 	mov	x0, x20
    14d8:	97ffff65 	bl	126c <gettoken>
    14dc:	7101841f 	cmp	w0, #0x61
    14e0:	54000080 	b.eq	14f0 <parseredirs+0x94>  // b.none
      panic("missing file for redirection");
    14e4:	90000000 	adrp	x0, 1000 <runcmd+0x1a8>
    14e8:	91269000 	add	x0, x0, #0x9a4
    14ec:	97fffe48 	bl	e0c <panic>
    switch(tok){
    14f0:	7100f2ff 	cmp	w23, #0x3c
    14f4:	54000100 	b.eq	1514 <parseredirs+0xb8>  // b.none
    14f8:	7100faff 	cmp	w23, #0x3e
    14fc:	540001a0 	b.eq	1530 <parseredirs+0xd4>  // b.none
    1500:	7100aeff 	cmp	w23, #0x2b
    1504:	54fffc01 	b.ne	1484 <parseredirs+0x28>  // b.any
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
    1508:	52800024 	mov	w4, #0x1                   	// #1
    150c:	52804023 	mov	w3, #0x201                 	// #513
    1510:	14000003 	b	151c <parseredirs+0xc0>
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
    1514:	52800004 	mov	w4, #0x0                   	// #0
    1518:	52800003 	mov	w3, #0x0                   	// #0
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
    151c:	a9440be1 	ldp	x1, x2, [sp, #64]
    1520:	aa1303e0 	mov	x0, x19
    1524:	97fffefe 	bl	111c <redircmd>
    1528:	aa0003f3 	mov	x19, x0
      break;
    152c:	17ffffd6 	b	1484 <parseredirs+0x28>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE|O_TRUNC, 1);
    1530:	52800024 	mov	w4, #0x1                   	// #1
    1534:	5280c023 	mov	w3, #0x601                 	// #1537
    1538:	17fffff9 	b	151c <parseredirs+0xc0>

000000000000153c <parseexec>:
  return cmd;
}

struct cmd*
parseexec(char **ps, char *es)
{
    153c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;

  if(peek(ps, es, "("))
    1540:	90000002 	adrp	x2, 1000 <runcmd+0x1a8>
    1544:	91271042 	add	x2, x2, #0x9c4
{
    1548:	910003fd 	mov	x29, sp
    154c:	a90153f3 	stp	x19, x20, [sp, #16]
    1550:	a9025bf5 	stp	x21, x22, [sp, #32]
    1554:	aa0003f6 	mov	x22, x0
    1558:	a90363f7 	stp	x23, x24, [sp, #48]
    155c:	aa0103f7 	mov	x23, x1
    1560:	f90023f9 	str	x25, [sp, #64]
  if(peek(ps, es, "("))
    1564:	97ffff9c 	bl	13d4 <peek>
    1568:	34000120 	cbz	w0, 158c <parseexec+0x50>
    ret = parseredirs(ret, ps, es);
  }
  cmd->argv[argc] = 0;
  cmd->eargv[argc] = 0;
  return ret;
}
    156c:	f94023f9 	ldr	x25, [sp, #64]
    return parseblock(ps, es);
    1570:	aa1703e1 	mov	x1, x23
}
    1574:	a94153f3 	ldp	x19, x20, [sp, #16]
    return parseblock(ps, es);
    1578:	aa1603e0 	mov	x0, x22
}
    157c:	a94363f7 	ldp	x23, x24, [sp, #48]
    1580:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1584:	a8c67bfd 	ldp	x29, x30, [sp], #96
    return parseblock(ps, es);
    1588:	14000088 	b	17a8 <parseblock>
    158c:	2a0003f4 	mov	w20, w0
  ret = execcmd();
    1590:	97fffed4 	bl	10e0 <execcmd>
    1594:	aa0003f5 	mov	x21, x0
  ret = parseredirs(ret, ps, es);
    1598:	aa1703e2 	mov	x2, x23
    159c:	aa1603e1 	mov	x1, x22
  while(!peek(ps, es, "|)&;")){
    15a0:	90000019 	adrp	x25, 1000 <runcmd+0x1a8>
    15a4:	91276f39 	add	x25, x25, #0x9db
  ret = parseredirs(ret, ps, es);
    15a8:	97ffffad 	bl	145c <parseredirs>
    15ac:	910022b8 	add	x24, x21, #0x8
    15b0:	aa0003f3 	mov	x19, x0
  while(!peek(ps, es, "|)&;")){
    15b4:	aa1903e2 	mov	x2, x25
    15b8:	aa1703e1 	mov	x1, x23
    15bc:	aa1603e0 	mov	x0, x22
    15c0:	97ffff85 	bl	13d4 <peek>
    15c4:	34000160 	cbz	w0, 15f0 <parseexec+0xb4>
  cmd->argv[argc] = 0;
    15c8:	8b344ea0 	add	x0, x21, w20, uxtw #3
}
    15cc:	f94023f9 	ldr	x25, [sp, #64]
  cmd->argv[argc] = 0;
    15d0:	f900041f 	str	xzr, [x0, #8]
  cmd->eargv[argc] = 0;
    15d4:	f9002c1f 	str	xzr, [x0, #88]
}
    15d8:	aa1303e0 	mov	x0, x19
    15dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    15e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    15e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    15e8:	a8c67bfd 	ldp	x29, x30, [sp], #96
    15ec:	d65f03c0 	ret
    if((tok=gettoken(ps, es, &q, &eq)) == 0)
    15f0:	910163e3 	add	x3, sp, #0x58
    15f4:	910143e2 	add	x2, sp, #0x50
    15f8:	aa1703e1 	mov	x1, x23
    15fc:	aa1603e0 	mov	x0, x22
    1600:	97ffff1b 	bl	126c <gettoken>
    1604:	34fffe20 	cbz	w0, 15c8 <parseexec+0x8c>
    if(tok != 'a')
    1608:	7101841f 	cmp	w0, #0x61
    160c:	54000080 	b.eq	161c <parseexec+0xe0>  // b.none
      panic("syntax");
    1610:	90000000 	adrp	x0, 1000 <runcmd+0x1a8>
    1614:	91271800 	add	x0, x0, #0x9c6
      panic("too many args");
    1618:	97fffdfd 	bl	e0c <panic>
    cmd->argv[argc] = q;
    161c:	f9402be0 	ldr	x0, [sp, #80]
    1620:	f9000300 	str	x0, [x24]
    cmd->eargv[argc] = eq;
    1624:	f9402fe0 	ldr	x0, [sp, #88]
    argc++;
    1628:	11000694 	add	w20, w20, #0x1
    cmd->eargv[argc] = eq;
    162c:	f9002b00 	str	x0, [x24, #80]
    if(argc >= MAXARGS)
    1630:	71002a9f 	cmp	w20, #0xa
    1634:	54000081 	b.ne	1644 <parseexec+0x108>  // b.any
      panic("too many args");
    1638:	90000000 	adrp	x0, 1000 <runcmd+0x1a8>
    163c:	91273400 	add	x0, x0, #0x9cd
    1640:	17fffff6 	b	1618 <parseexec+0xdc>
    ret = parseredirs(ret, ps, es);
    1644:	aa1303e0 	mov	x0, x19
    1648:	aa1703e2 	mov	x2, x23
    164c:	aa1603e1 	mov	x1, x22
    if(argc >= MAXARGS)
    1650:	91002318 	add	x24, x24, #0x8
    ret = parseredirs(ret, ps, es);
    1654:	97ffff82 	bl	145c <parseredirs>
    1658:	aa0003f3 	mov	x19, x0
    165c:	17ffffd6 	b	15b4 <parseexec+0x78>

0000000000001660 <parsepipe>:
{
    1660:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1664:	910003fd 	mov	x29, sp
    1668:	a90153f3 	stp	x19, x20, [sp, #16]
    166c:	aa0003f3 	mov	x19, x0
    1670:	aa0103f4 	mov	x20, x1
    1674:	f90013f5 	str	x21, [sp, #32]
  cmd = parseexec(ps, es);
    1678:	97ffffb1 	bl	153c <parseexec>
  if(peek(ps, es, "|")){
    167c:	90000002 	adrp	x2, 1000 <runcmd+0x1a8>
    1680:	91278042 	add	x2, x2, #0x9e0
  cmd = parseexec(ps, es);
    1684:	aa0003f5 	mov	x21, x0
  if(peek(ps, es, "|")){
    1688:	aa1403e1 	mov	x1, x20
    168c:	aa1303e0 	mov	x0, x19
    1690:	97ffff51 	bl	13d4 <peek>
    1694:	340001e0 	cbz	w0, 16d0 <parsepipe+0x70>
    gettoken(ps, es, 0, 0);
    1698:	d2800003 	mov	x3, #0x0                   	// #0
    169c:	d2800002 	mov	x2, #0x0                   	// #0
    16a0:	aa1403e1 	mov	x1, x20
    16a4:	aa1303e0 	mov	x0, x19
    16a8:	97fffef1 	bl	126c <gettoken>
    cmd = pipecmd(cmd, parsepipe(ps, es));
    16ac:	aa1403e1 	mov	x1, x20
    16b0:	aa1303e0 	mov	x0, x19
    16b4:	97ffffeb 	bl	1660 <parsepipe>
    16b8:	aa0003e1 	mov	x1, x0
}
    16bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    cmd = pipecmd(cmd, parsepipe(ps, es));
    16c0:	aa1503e0 	mov	x0, x21
}
    16c4:	f94013f5 	ldr	x21, [sp, #32]
    16c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    cmd = pipecmd(cmd, parsepipe(ps, es));
    16cc:	17fffeaf 	b	1188 <pipecmd>
}
    16d0:	aa1503e0 	mov	x0, x21
    16d4:	f94013f5 	ldr	x21, [sp, #32]
    16d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    16dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    16e0:	d65f03c0 	ret

00000000000016e4 <parseline>:
{
    16e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    16e8:	910003fd 	mov	x29, sp
    16ec:	a90153f3 	stp	x19, x20, [sp, #16]
    16f0:	aa0003f4 	mov	x20, x0
    16f4:	a9025bf5 	stp	x21, x22, [sp, #32]
    16f8:	aa0103f5 	mov	x21, x1
  while(peek(ps, es, "&")){
    16fc:	90000016 	adrp	x22, 1000 <runcmd+0x1a8>
    1700:	91278ad6 	add	x22, x22, #0x9e2
  cmd = parsepipe(ps, es);
    1704:	97ffffd7 	bl	1660 <parsepipe>
    1708:	aa0003f3 	mov	x19, x0
  while(peek(ps, es, "&")){
    170c:	aa1603e2 	mov	x2, x22
    1710:	aa1503e1 	mov	x1, x21
    1714:	aa1403e0 	mov	x0, x20
    1718:	97ffff2f 	bl	13d4 <peek>
    171c:	350002a0 	cbnz	w0, 1770 <parseline+0x8c>
  if(peek(ps, es, ";")){
    1720:	90000002 	adrp	x2, 1000 <runcmd+0x1a8>
    1724:	91277842 	add	x2, x2, #0x9de
    1728:	aa1503e1 	mov	x1, x21
    172c:	aa1403e0 	mov	x0, x20
    1730:	97ffff29 	bl	13d4 <peek>
    1734:	34000300 	cbz	w0, 1794 <parseline+0xb0>
    gettoken(ps, es, 0, 0);
    1738:	d2800003 	mov	x3, #0x0                   	// #0
    173c:	d2800002 	mov	x2, #0x0                   	// #0
    1740:	aa1503e1 	mov	x1, x21
    1744:	aa1403e0 	mov	x0, x20
    1748:	97fffec9 	bl	126c <gettoken>
    cmd = listcmd(cmd, parseline(ps, es));
    174c:	aa1503e1 	mov	x1, x21
    1750:	aa1403e0 	mov	x0, x20
    1754:	97ffffe4 	bl	16e4 <parseline>
    1758:	aa0003e1 	mov	x1, x0
}
    175c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    cmd = listcmd(cmd, parseline(ps, es));
    1760:	aa1303e0 	mov	x0, x19
}
    1764:	a94153f3 	ldp	x19, x20, [sp, #16]
    1768:	a8c37bfd 	ldp	x29, x30, [sp], #48
    cmd = listcmd(cmd, parseline(ps, es));
    176c:	17fffe9b 	b	11d8 <listcmd>
    gettoken(ps, es, 0, 0);
    1770:	aa1503e1 	mov	x1, x21
    1774:	d2800003 	mov	x3, #0x0                   	// #0
    1778:	d2800002 	mov	x2, #0x0                   	// #0
    177c:	aa1403e0 	mov	x0, x20
    1780:	97fffebb 	bl	126c <gettoken>
    cmd = backcmd(cmd);
    1784:	aa1303e0 	mov	x0, x19
    1788:	97fffea8 	bl	1228 <backcmd>
    178c:	aa0003f3 	mov	x19, x0
    1790:	17ffffdf 	b	170c <parseline+0x28>
}
    1794:	aa1303e0 	mov	x0, x19
    1798:	a94153f3 	ldp	x19, x20, [sp, #16]
    179c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    17a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    17a4:	d65f03c0 	ret

00000000000017a8 <parseblock>:
{
    17a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  if(!peek(ps, es, "("))
    17ac:	90000002 	adrp	x2, 1000 <runcmd+0x1a8>
    17b0:	91271042 	add	x2, x2, #0x9c4
{
    17b4:	910003fd 	mov	x29, sp
    17b8:	a90153f3 	stp	x19, x20, [sp, #16]
    17bc:	aa0003f3 	mov	x19, x0
    17c0:	aa0103f4 	mov	x20, x1
    17c4:	f90013f5 	str	x21, [sp, #32]
  if(!peek(ps, es, "("))
    17c8:	97ffff03 	bl	13d4 <peek>
    17cc:	35000080 	cbnz	w0, 17dc <parseblock+0x34>
    panic("parseblock");
    17d0:	90000000 	adrp	x0, 1000 <runcmd+0x1a8>
    17d4:	91279000 	add	x0, x0, #0x9e4
    panic("syntax - missing )");
    17d8:	97fffd8d 	bl	e0c <panic>
  gettoken(ps, es, 0, 0);
    17dc:	d2800002 	mov	x2, #0x0                   	// #0
    17e0:	d2800003 	mov	x3, #0x0                   	// #0
    17e4:	aa1403e1 	mov	x1, x20
    17e8:	aa1303e0 	mov	x0, x19
    17ec:	97fffea0 	bl	126c <gettoken>
  cmd = parseline(ps, es);
    17f0:	aa1403e1 	mov	x1, x20
    17f4:	aa1303e0 	mov	x0, x19
    17f8:	97ffffbb 	bl	16e4 <parseline>
    17fc:	aa0003f5 	mov	x21, x0
  if(!peek(ps, es, ")"))
    1800:	90000002 	adrp	x2, 1000 <runcmd+0x1a8>
    1804:	91280042 	add	x2, x2, #0xa00
    1808:	aa1403e1 	mov	x1, x20
    180c:	aa1303e0 	mov	x0, x19
    1810:	97fffef1 	bl	13d4 <peek>
    1814:	35000080 	cbnz	w0, 1824 <parseblock+0x7c>
    panic("syntax - missing )");
    1818:	90000000 	adrp	x0, 1000 <runcmd+0x1a8>
    181c:	9127bc00 	add	x0, x0, #0x9ef
    1820:	17ffffee 	b	17d8 <parseblock+0x30>
  gettoken(ps, es, 0, 0);
    1824:	aa1403e1 	mov	x1, x20
    1828:	aa1303e0 	mov	x0, x19
    182c:	d2800003 	mov	x3, #0x0                   	// #0
    1830:	d2800002 	mov	x2, #0x0                   	// #0
    1834:	97fffe8e 	bl	126c <gettoken>
  cmd = parseredirs(cmd, ps, es);
    1838:	aa1403e2 	mov	x2, x20
    183c:	aa1303e1 	mov	x1, x19
    1840:	aa1503e0 	mov	x0, x21
}
    1844:	f94013f5 	ldr	x21, [sp, #32]
    1848:	a94153f3 	ldp	x19, x20, [sp, #16]
    184c:	a8c37bfd 	ldp	x29, x30, [sp], #48
  cmd = parseredirs(cmd, ps, es);
    1850:	17ffff03 	b	145c <parseredirs>

0000000000001854 <nulterminate>:

// NUL-terminate all the counted strings.
struct cmd*
nulterminate(struct cmd *cmd)
{
    1854:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1858:	910003fd 	mov	x29, sp
    185c:	f9000bf3 	str	x19, [sp, #16]
    1860:	aa0003f3 	mov	x19, x0
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
    1864:	b4000120 	cbz	x0, 1888 <nulterminate+0x34>
    return 0;

  switch(cmd->type){
    1868:	b9400000 	ldr	w0, [x0]
    186c:	71000c1f 	cmp	w0, #0x3
    1870:	54000360 	b.eq	18dc <nulterminate+0x88>  // b.none
    1874:	5400012c 	b.gt	1898 <nulterminate+0x44>
    1878:	7100041f 	cmp	w0, #0x1
    187c:	540001a0 	b.eq	18b0 <nulterminate+0x5c>  // b.none
    1880:	7100081f 	cmp	w0, #0x2
    1884:	54000220 	b.eq	18c8 <nulterminate+0x74>  // b.none
    bcmd = (struct backcmd*)cmd;
    nulterminate(bcmd->cmd);
    break;
  }
  return cmd;
}
    1888:	aa1303e0 	mov	x0, x19
    188c:	f9400bf3 	ldr	x19, [sp, #16]
    1890:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1894:	d65f03c0 	ret
  switch(cmd->type){
    1898:	7100101f 	cmp	w0, #0x4
    189c:	54000200 	b.eq	18dc <nulterminate+0x88>  // b.none
    18a0:	7100141f 	cmp	w0, #0x5
    18a4:	54ffff21 	b.ne	1888 <nulterminate+0x34>  // b.any
    nulterminate(bcmd->cmd);
    18a8:	f9400660 	ldr	x0, [x19, #8]
    18ac:	1400000f 	b	18e8 <nulterminate+0x94>
    18b0:	91002260 	add	x0, x19, #0x8
    for(i=0; ecmd->argv[i]; i++)
    18b4:	f8408401 	ldr	x1, [x0], #8
    18b8:	b4fffe81 	cbz	x1, 1888 <nulterminate+0x34>
      *ecmd->eargv[i] = 0;
    18bc:	f9402401 	ldr	x1, [x0, #72]
    18c0:	3900003f 	strb	wzr, [x1]
    for(i=0; ecmd->argv[i]; i++)
    18c4:	17fffffc 	b	18b4 <nulterminate+0x60>
    nulterminate(rcmd->cmd);
    18c8:	f9400660 	ldr	x0, [x19, #8]
    18cc:	97ffffe2 	bl	1854 <nulterminate>
    *rcmd->efile = 0;
    18d0:	f9400e60 	ldr	x0, [x19, #24]
    18d4:	3900001f 	strb	wzr, [x0]
    break;
    18d8:	17ffffec 	b	1888 <nulterminate+0x34>
    nulterminate(lcmd->left);
    18dc:	f9400660 	ldr	x0, [x19, #8]
    18e0:	97ffffdd 	bl	1854 <nulterminate>
    nulterminate(lcmd->right);
    18e4:	f9400a60 	ldr	x0, [x19, #16]
    nulterminate(bcmd->cmd);
    18e8:	97ffffdb 	bl	1854 <nulterminate>
    break;
    18ec:	17ffffe7 	b	1888 <nulterminate+0x34>

00000000000018f0 <parsecmd>:
{
    18f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    18f4:	910003fd 	mov	x29, sp
    18f8:	a90153f3 	stp	x19, x20, [sp, #16]
  es = s + strlen(s);
    18fc:	aa0003f3 	mov	x19, x0
{
    1900:	f90017e0 	str	x0, [sp, #40]
  es = s + strlen(s);
    1904:	97fffbe3 	bl	890 <strlen@plt>
    1908:	8b204273 	add	x19, x19, w0, uxtw
  cmd = parseline(&s, es);
    190c:	9100a3e0 	add	x0, sp, #0x28
    1910:	aa1303e1 	mov	x1, x19
    1914:	97ffff74 	bl	16e4 <parseline>
  peek(&s, es, "");
    1918:	aa1303e1 	mov	x1, x19
  cmd = parseline(&s, es);
    191c:	aa0003f4 	mov	x20, x0
  peek(&s, es, "");
    1920:	90000002 	adrp	x2, 1000 <runcmd+0x1a8>
    1924:	91295042 	add	x2, x2, #0xa54
    1928:	9100a3e0 	add	x0, sp, #0x28
    192c:	97fffeaa 	bl	13d4 <peek>
  if(s != es){
    1930:	f94017e2 	ldr	x2, [sp, #40]
    1934:	eb13005f 	cmp	x2, x19
    1938:	54000100 	b.eq	1958 <parsecmd+0x68>  // b.none
    fprintf(2, "leftovers: %s\n", s);
    193c:	90000001 	adrp	x1, 1000 <runcmd+0x1a8>
    1940:	91280821 	add	x1, x1, #0xa02
    1944:	52800040 	mov	w0, #0x2                   	// #2
    1948:	97fffb9e 	bl	7c0 <fprintf@plt>
    panic("syntax");
    194c:	90000000 	adrp	x0, 1000 <runcmd+0x1a8>
    1950:	91271800 	add	x0, x0, #0x9c6
    1954:	97fffd2e 	bl	e0c <panic>
  nulterminate(cmd);
    1958:	aa1403e0 	mov	x0, x20
    195c:	97ffffbe 	bl	1854 <nulterminate>
}
    1960:	aa1403e0 	mov	x0, x20
    1964:	a94153f3 	ldp	x19, x20, [sp, #16]
    1968:	a8c37bfd 	ldp	x29, x30, [sp], #48
    196c:	d65f03c0 	ret
