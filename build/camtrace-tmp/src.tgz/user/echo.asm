
user/_echo:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000278 <.plt>:
 278:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 27c:	b0000010 	adrp	x16, 1000 <main+0xd38>
 280:	f9424a11 	ldr	x17, [x16, #1168]
 284:	91124210 	add	x16, x16, #0x490
 288:	d61f0220 	br	x17
 28c:	d503201f 	nop
 290:	d503201f 	nop
 294:	d503201f 	nop

0000000000000298 <write@plt>:
 298:	b0000010 	adrp	x16, 1000 <main+0xd38>
 29c:	f9424e11 	ldr	x17, [x16, #1176]
 2a0:	91126210 	add	x16, x16, #0x498
 2a4:	d61f0220 	br	x17

00000000000002a8 <exit@plt>:
 2a8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2ac:	f9425211 	ldr	x17, [x16, #1184]
 2b0:	91128210 	add	x16, x16, #0x4a0
 2b4:	d61f0220 	br	x17

00000000000002b8 <strlen@plt>:
 2b8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2bc:	f9425611 	ldr	x17, [x16, #1192]
 2c0:	9112a210 	add	x16, x16, #0x4a8
 2c4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000002c8 <main>:
#include <uapi/stat.h>
#include "user/user.h"

int
main(int argc, char *argv[])
{
 2c8:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 2cc:	910003fd 	mov	x29, sp
 2d0:	a90153f3 	stp	x19, x20, [sp, #16]
  for(i = 1; i < argc; i++){
    write(1, argv[i], strlen(argv[i]));
    if(i + 1 < argc){
      write(1, " ", 1);
    } else {
      write(1, "\n", 1);
 2d4:	90000014 	adrp	x20, 0 <.plt-0x278>
 2d8:	910d5a94 	add	x20, x20, #0x356
{
 2dc:	a9025bf5 	stp	x21, x22, [sp, #32]
      write(1, " ", 1);
 2e0:	90000015 	adrp	x21, 0 <.plt-0x278>
 2e4:	910d52b5 	add	x21, x21, #0x354
{
 2e8:	2a0003f6 	mov	w22, w0
 2ec:	f9001bf7 	str	x23, [sp, #48]
 2f0:	aa0103f7 	mov	x23, x1
  for(i = 1; i < argc; i++){
 2f4:	d2800033 	mov	x19, #0x1                   	// #1
 2f8:	6b1302df 	cmp	w22, w19
 2fc:	5400006c 	b.gt	308 <main+0x40>
    }
  }
  exit(0);
 300:	52800000 	mov	w0, #0x0                   	// #0
 304:	97ffffe9 	bl	2a8 <exit@plt>
    write(1, argv[i], strlen(argv[i]));
 308:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
 30c:	f90027e1 	str	x1, [sp, #72]
 310:	aa0103e0 	mov	x0, x1
 314:	97ffffe9 	bl	2b8 <strlen@plt>
 318:	2a0003e2 	mov	w2, w0
 31c:	f94027e1 	ldr	x1, [sp, #72]
 320:	52800020 	mov	w0, #0x1                   	// #1
 324:	97ffffdd 	bl	298 <write@plt>
    if(i + 1 < argc){
 328:	11000660 	add	w0, w19, #0x1
      write(1, " ", 1);
 32c:	52800022 	mov	w2, #0x1                   	// #1
    if(i + 1 < argc){
 330:	6b0002df 	cmp	w22, w0
 334:	540000cd 	b.le	34c <main+0x84>
      write(1, " ", 1);
 338:	aa1503e1 	mov	x1, x21
      write(1, "\n", 1);
 33c:	2a0203e0 	mov	w0, w2
 340:	91000673 	add	x19, x19, #0x1
 344:	97ffffd5 	bl	298 <write@plt>
  for(i = 1; i < argc; i++){
 348:	17ffffec 	b	2f8 <main+0x30>
      write(1, "\n", 1);
 34c:	aa1403e1 	mov	x1, x20
 350:	17fffffb 	b	33c <main+0x74>
