
user/_insmod:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000003d0 <.plt>:
 3d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 3d4:	b0000010 	adrp	x16, 1000 <main+0xb80>
 3d8:	f943f211 	ldr	x17, [x16, #2016]
 3dc:	911f8210 	add	x16, x16, #0x7e0
 3e0:	d61f0220 	br	x17
 3e4:	d503201f 	nop
 3e8:	d503201f 	nop
 3ec:	d503201f 	nop

00000000000003f0 <printf@plt>:
 3f0:	b0000010 	adrp	x16, 1000 <main+0xb80>
 3f4:	f943f611 	ldr	x17, [x16, #2024]
 3f8:	911fa210 	add	x16, x16, #0x7e8
 3fc:	d61f0220 	br	x17

0000000000000400 <malloc@plt>:
 400:	b0000010 	adrp	x16, 1000 <main+0xb80>
 404:	f943fa11 	ldr	x17, [x16, #2032]
 408:	911fc210 	add	x16, x16, #0x7f0
 40c:	d61f0220 	br	x17

0000000000000410 <init_module@plt>:
 410:	b0000010 	adrp	x16, 1000 <main+0xb80>
 414:	f943fe11 	ldr	x17, [x16, #2040]
 418:	911fe210 	add	x16, x16, #0x7f8
 41c:	d61f0220 	br	x17

0000000000000420 <fstat@plt>:
 420:	b0000010 	adrp	x16, 1000 <main+0xb80>
 424:	f9440211 	ldr	x17, [x16, #2048]
 428:	91200210 	add	x16, x16, #0x800
 42c:	d61f0220 	br	x17

0000000000000430 <fprintf@plt>:
 430:	b0000010 	adrp	x16, 1000 <main+0xb80>
 434:	f9440611 	ldr	x17, [x16, #2056]
 438:	91202210 	add	x16, x16, #0x808
 43c:	d61f0220 	br	x17

0000000000000440 <read@plt>:
 440:	b0000010 	adrp	x16, 1000 <main+0xb80>
 444:	f9440a11 	ldr	x17, [x16, #2064]
 448:	91204210 	add	x16, x16, #0x810
 44c:	d61f0220 	br	x17

0000000000000450 <exit@plt>:
 450:	b0000010 	adrp	x16, 1000 <main+0xb80>
 454:	f9440e11 	ldr	x17, [x16, #2072]
 458:	91206210 	add	x16, x16, #0x818
 45c:	d61f0220 	br	x17

0000000000000460 <open@plt>:
 460:	b0000010 	adrp	x16, 1000 <main+0xb80>
 464:	f9441211 	ldr	x17, [x16, #2080]
 468:	91208210 	add	x16, x16, #0x820
 46c:	d61f0220 	br	x17

0000000000000470 <close@plt>:
 470:	b0000010 	adrp	x16, 1000 <main+0xb80>
 474:	f9441611 	ldr	x17, [x16, #2088]
 478:	9120a210 	add	x16, x16, #0x828
 47c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000480 <main>:

#define MAX_IMAGE (64 * 1024)

int
main(int argc, char *argv[])
{
 480:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 484:	910003fd 	mov	x29, sp
 488:	a90153f3 	stp	x19, x20, [sp, #16]
 48c:	a9025bf5 	stp	x21, x22, [sp, #32]
  if(argc != 2){
 490:	7100081f 	cmp	w0, #0x2
 494:	540000e0 	b.eq	4b0 <main+0x30>  // b.none
    fprintf(2, "usage: insmod PATH.ko\n");
 498:	90000001 	adrp	x1, 0 <.plt-0x3d0>
 49c:	91174021 	add	x1, x1, #0x5d0
 4a0:	52800040 	mov	w0, #0x2                   	// #2
 4a4:	97ffffe3 	bl	430 <fprintf@plt>
  }

  int fd = open(argv[1], 0);
  if(fd < 0){
    fprintf(2, "insmod: cannot open %s\n", argv[1]);
    exit(1);
 4a8:	52800020 	mov	w0, #0x1                   	// #1
 4ac:	97ffffe9 	bl	450 <exit@plt>
 4b0:	aa0103f3 	mov	x19, x1
  int fd = open(argv[1], 0);
 4b4:	2a0003f4 	mov	w20, w0
 4b8:	52800001 	mov	w1, #0x0                   	// #0
 4bc:	f9400660 	ldr	x0, [x19, #8]
 4c0:	97ffffe8 	bl	460 <open@plt>
 4c4:	2a0003f6 	mov	w22, w0
  if(fd < 0){
 4c8:	36f800e0 	tbz	w0, #31, 4e4 <main+0x64>
    fprintf(2, "insmod: cannot open %s\n", argv[1]);
 4cc:	90000001 	adrp	x1, 0 <.plt-0x3d0>
 4d0:	91179c21 	add	x1, x1, #0x5e7
 4d4:	f9400662 	ldr	x2, [x19, #8]
 4d8:	2a1403e0 	mov	w0, w20
 4dc:	97ffffd5 	bl	430 <fprintf@plt>
 4e0:	17fffff2 	b	4a8 <main+0x28>
  }

  struct stat st;
  if(fstat(fd, &st) < 0){
 4e4:	9100e3e1 	add	x1, sp, #0x38
 4e8:	97ffffce 	bl	420 <fstat@plt>
 4ec:	36f80080 	tbz	w0, #31, 4fc <main+0x7c>
    fprintf(2, "insmod: cannot stat %s\n", argv[1]);
 4f0:	90000001 	adrp	x1, 0 <.plt-0x3d0>
 4f4:	9117fc21 	add	x1, x1, #0x5ff
 4f8:	17fffff7 	b	4d4 <main+0x54>
    exit(1);
  }
  if(st.size == 0 || st.size > MAX_IMAGE){
 4fc:	f94027e0 	ldr	x0, [sp, #72]
 500:	d29fffe1 	mov	x1, #0xffff                	// #65535
 504:	d1000402 	sub	x2, x0, #0x1
 508:	eb01005f 	cmp	x2, x1
 50c:	54000109 	b.ls	52c <main+0xac>  // b.plast
    fprintf(2, "insmod: %s is %d bytes, out of range\n", argv[1], (int)st.size);
 510:	f9400662 	ldr	x2, [x19, #8]
 514:	2a0003e3 	mov	w3, w0
 518:	90000001 	adrp	x1, 0 <.plt-0x3d0>
 51c:	91185c21 	add	x1, x1, #0x617
 520:	2a1403e0 	mov	w0, w20
 524:	97ffffc3 	bl	430 <fprintf@plt>
    exit(1);
 528:	17ffffe0 	b	4a8 <main+0x28>
  }

  // Read the entire image into one contiguous buffer: the kernel loader
  // indexes the section, symbol and string tables by offset into this blob.
  char *image = malloc(st.size);
 52c:	97ffffb5 	bl	400 <malloc@plt>
 530:	aa0003f5 	mov	x21, x0
  if(image == 0){
 534:	b50003e0 	cbnz	x0, 5b0 <main+0x130>
    fprintf(2, "insmod: out of memory\n");
 538:	90000001 	adrp	x1, 0 <.plt-0x3d0>
 53c:	9118f421 	add	x1, x1, #0x63d
 540:	17ffffd8 	b	4a0 <main+0x20>
    exit(1);
  }
  int off = 0;
  while(off < st.size){
    int n = read(fd, image + off, st.size - off);
 544:	4b140042 	sub	w2, w2, w20
 548:	8b34c2a1 	add	x1, x21, w20, sxtw
 54c:	2a1603e0 	mov	w0, w22
 550:	97ffffbc 	bl	440 <read@plt>
    if(n <= 0){
 554:	7100001f 	cmp	w0, #0x0
 558:	540000cc 	b.gt	570 <main+0xf0>
      fprintf(2, "insmod: short read of %s\n", argv[1]);
 55c:	f9400662 	ldr	x2, [x19, #8]
 560:	90000001 	adrp	x1, 0 <.plt-0x3d0>
 564:	91195021 	add	x1, x1, #0x654
    off += n;
  }
  close(fd);

  if(init_module(image, st.size, "") < 0){
    fprintf(2, "insmod: %s rejected by the kernel\n", argv[1]);
 568:	52800040 	mov	w0, #0x2                   	// #2
 56c:	17ffffdc 	b	4dc <main+0x5c>
    off += n;
 570:	0b000294 	add	w20, w20, w0
  while(off < st.size){
 574:	f94027e2 	ldr	x2, [sp, #72]
 578:	eb34c05f 	cmp	x2, w20, sxtw
 57c:	54fffe48 	b.hi	544 <main+0xc4>  // b.pmore
  close(fd);
 580:	2a1603e0 	mov	w0, w22
 584:	97ffffbb 	bl	470 <close@plt>
  if(init_module(image, st.size, "") < 0){
 588:	f94027e1 	ldr	x1, [sp, #72]
 58c:	aa1503e0 	mov	x0, x21
 590:	90000002 	adrp	x2, 0 <.plt-0x3d0>
 594:	9118f042 	add	x2, x2, #0x63c
 598:	97ffff9e 	bl	410 <init_module@plt>
    fprintf(2, "insmod: %s rejected by the kernel\n", argv[1]);
 59c:	f9400662 	ldr	x2, [x19, #8]
  if(init_module(image, st.size, "") < 0){
 5a0:	36f800c0 	tbz	w0, #31, 5b8 <main+0x138>
    fprintf(2, "insmod: %s rejected by the kernel\n", argv[1]);
 5a4:	90000001 	adrp	x1, 0 <.plt-0x3d0>
 5a8:	9119b821 	add	x1, x1, #0x66e
 5ac:	17ffffef 	b	568 <main+0xe8>
  int off = 0;
 5b0:	52800014 	mov	w20, #0x0                   	// #0
 5b4:	17fffff0 	b	574 <main+0xf4>
    exit(1);
  }

  printf("insmod: loaded %s\n", argv[1]);
 5b8:	aa0203e1 	mov	x1, x2
 5bc:	90000000 	adrp	x0, 0 <.plt-0x3d0>
 5c0:	911a4400 	add	x0, x0, #0x691
 5c4:	97ffff8b 	bl	3f0 <printf@plt>
  exit(0);
 5c8:	52800000 	mov	w0, #0x0                   	// #0
 5cc:	17ffffb8 	b	4ac <main+0x2c>
