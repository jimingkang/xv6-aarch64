
user/_reboot:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000278 <.plt>:
 278:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 27c:	b0000010 	adrp	x16, 1000 <main+0xd38>
 280:	f9429611 	ldr	x17, [x16, #1320]
 284:	9114a210 	add	x16, x16, #0x528
 288:	d61f0220 	br	x17
 28c:	d503201f 	nop
 290:	d503201f 	nop
 294:	d503201f 	nop

0000000000000298 <fprintf@plt>:
 298:	b0000010 	adrp	x16, 1000 <main+0xd38>
 29c:	f9429a11 	ldr	x17, [x16, #1328]
 2a0:	9114c210 	add	x16, x16, #0x530
 2a4:	d61f0220 	br	x17

00000000000002a8 <reboot@plt>:
 2a8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2ac:	f9429e11 	ldr	x17, [x16, #1336]
 2b0:	9114e210 	add	x16, x16, #0x538
 2b4:	d61f0220 	br	x17

00000000000002b8 <exit@plt>:
 2b8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2bc:	f942a211 	ldr	x17, [x16, #1344]
 2c0:	91150210 	add	x16, x16, #0x540
 2c4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000002c8 <main>:
  return b;
}

int
main(int argc, char *argv[])
{
 2c8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 2cc:	910003fd 	mov	x29, sp
  int cmd = REBOOT_CMD_RESTART;

  if(argc > 0 && streq(base(argv[0]), "halt"))
 2d0:	7100001f 	cmp	w0, #0x0
 2d4:	540003ad 	b.le	348 <main+0x80>
 2d8:	f9400022 	ldr	x2, [x1]
  for(; *p; p++)
 2dc:	2a0003e3 	mov	w3, w0
  const char *b = p;
 2e0:	aa0203e0 	mov	x0, x2
  for(; *p; p++)
 2e4:	39400044 	ldrb	w4, [x2]
 2e8:	350003c4 	cbnz	w4, 360 <main+0x98>
  while(*a && *a == *b){ a++; b++; }
 2ec:	90000004 	adrp	x4, 0 <.plt-0x278>
 2f0:	910f0084 	add	x4, x4, #0x3c0
  for(; *p; p++)
 2f4:	d2800002 	mov	x2, #0x0                   	// #0
  while(*a && *a == *b){ a++; b++; }
 2f8:	38626806 	ldrb	w6, [x0, x2]
 2fc:	38626885 	ldrb	w5, [x4, x2]
 300:	34000386 	cbz	w6, 370 <main+0xa8>
 304:	91000442 	add	x2, x2, #0x1
 308:	6b0500df 	cmp	w6, w5
 30c:	54ffff60 	b.eq	2f8 <main+0x30>  // b.none
  int cmd = REBOOT_CMD_RESTART;
 310:	5288ace0 	mov	w0, #0x4567                	// #17767
 314:	72a02460 	movk	w0, #0x123, lsl #16
    cmd = REBOOT_CMD_HALT;
  if(argc == 2 && streq(argv[1], "-h"))
 318:	7100087f 	cmp	w3, #0x2
 31c:	54000401 	b.ne	39c <main+0xd4>  // b.any
 320:	f9400424 	ldr	x4, [x1, #8]
  while(*a && *a == *b){ a++; b++; }
 324:	90000001 	adrp	x1, 0 <.plt-0x278>
 328:	910f1421 	add	x1, x1, #0x3c5
 32c:	d2800000 	mov	x0, #0x0                   	// #0
 330:	38606883 	ldrb	w3, [x4, x0]
 334:	38606822 	ldrb	w2, [x1, x0]
 338:	340002a3 	cbz	w3, 38c <main+0xc4>
 33c:	91000400 	add	x0, x0, #0x1
 340:	6b02007f 	cmp	w3, w2
 344:	54ffff60 	b.eq	330 <main+0x68>  // b.none
    cmd = REBOOT_CMD_HALT;
  else if(argc != 1){
    fprintf(2, "usage: reboot [-h]\n");
 348:	90000001 	adrp	x1, 0 <.plt-0x278>
 34c:	910f2021 	add	x1, x1, #0x3c8
    exit(1);
  }

  if(reboot(cmd) < 0){
    fprintf(2, "reboot: failed\n");
 350:	52800040 	mov	w0, #0x2                   	// #2
 354:	97ffffd1 	bl	298 <fprintf@plt>
    exit(1);
 358:	52800020 	mov	w0, #0x1                   	// #1
 35c:	97ffffd7 	bl	2b8 <exit@plt>
      b = p + 1;
 360:	91000442 	add	x2, x2, #0x1
 364:	7100bc9f 	cmp	w4, #0x2f
 368:	9a821000 	csel	x0, x0, x2, ne	// ne = any
  for(; *p; p++)
 36c:	17ffffde 	b	2e4 <main+0x1c>
  int cmd = REBOOT_CMD_RESTART;
 370:	710000bf 	cmp	w5, #0x0
 374:	52802462 	mov	w2, #0x123                 	// #291
 378:	72b9bde2 	movk	w2, #0xcdef, lsl #16
 37c:	5288ace0 	mov	w0, #0x4567                	// #17767
 380:	72a02460 	movk	w0, #0x123, lsl #16
 384:	1a800040 	csel	w0, w2, w0, eq	// eq = none
 388:	17ffffe4 	b	318 <main+0x50>
  if(argc == 2 && streq(argv[1], "-h"))
 38c:	35fffde2 	cbnz	w2, 348 <main+0x80>
    cmd = REBOOT_CMD_HALT;
 390:	52802460 	mov	w0, #0x123                 	// #291
 394:	72b9bde0 	movk	w0, #0xcdef, lsl #16
 398:	14000003 	b	3a4 <main+0xdc>
  else if(argc != 1){
 39c:	7100047f 	cmp	w3, #0x1
 3a0:	54fffd41 	b.ne	348 <main+0x80>  // b.any
  if(reboot(cmd) < 0){
 3a4:	97ffffc1 	bl	2a8 <reboot@plt>
 3a8:	36f80080 	tbz	w0, #31, 3b8 <main+0xf0>
    fprintf(2, "reboot: failed\n");
 3ac:	90000001 	adrp	x1, 0 <.plt-0x278>
 3b0:	910f7021 	add	x1, x1, #0x3dc
 3b4:	17ffffe7 	b	350 <main+0x88>
  }
  exit(0);   // not reached
 3b8:	52800000 	mov	w0, #0x0                   	// #0
 3bc:	17ffffe8 	b	35c <main+0x94>
