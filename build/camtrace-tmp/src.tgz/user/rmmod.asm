
user/_rmmod:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002b8 <.plt>:
 2b8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2bc:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2c0:	f9429a11 	ldr	x17, [x16, #1328]
 2c4:	9114c210 	add	x16, x16, #0x530
 2c8:	d61f0220 	br	x17
 2cc:	d503201f 	nop
 2d0:	d503201f 	nop
 2d4:	d503201f 	nop

00000000000002d8 <printf@plt>:
 2d8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2dc:	f9429e11 	ldr	x17, [x16, #1336]
 2e0:	9114e210 	add	x16, x16, #0x538
 2e4:	d61f0220 	br	x17

00000000000002e8 <delete_module@plt>:
 2e8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2ec:	f942a211 	ldr	x17, [x16, #1344]
 2f0:	91150210 	add	x16, x16, #0x540
 2f4:	d61f0220 	br	x17

00000000000002f8 <fprintf@plt>:
 2f8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2fc:	f942a611 	ldr	x17, [x16, #1352]
 300:	91152210 	add	x16, x16, #0x548
 304:	d61f0220 	br	x17

0000000000000308 <exit@plt>:
 308:	b0000010 	adrp	x16, 1000 <main+0xce8>
 30c:	f942aa11 	ldr	x17, [x16, #1360]
 310:	91154210 	add	x16, x16, #0x550
 314:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000318 <main>:
#include <uapi/stat.h>
#include "user/user.h"

int
main(int argc, char *argv[])
{
 318:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 31c:	910003fd 	mov	x29, sp
 320:	a90153f3 	stp	x19, x20, [sp, #16]
  if(argc != 2){
 324:	7100081f 	cmp	w0, #0x2
 328:	540000e0 	b.eq	344 <main+0x2c>  // b.none
    fprintf(2, "usage: rmmod NAME        (NAME is the column in /proc/modules)\n");
 32c:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 330:	910e2021 	add	x1, x1, #0x388
 334:	52800040 	mov	w0, #0x2                   	// #2
 338:	97fffff0 	bl	2f8 <fprintf@plt>
    exit(1);
  }

  if(delete_module(argv[1]) < 0){
    fprintf(2, "rmmod: cannot unload %s\n", argv[1]);
    exit(1);
 33c:	52800020 	mov	w0, #0x1                   	// #1
 340:	97fffff2 	bl	308 <exit@plt>
 344:	2a0003f3 	mov	w19, w0
 348:	aa0103f4 	mov	x20, x1
  if(delete_module(argv[1]) < 0){
 34c:	f9400420 	ldr	x0, [x1, #8]
 350:	97ffffe6 	bl	2e8 <delete_module@plt>
    fprintf(2, "rmmod: cannot unload %s\n", argv[1]);
 354:	f9400682 	ldr	x2, [x20, #8]
  if(delete_module(argv[1]) < 0){
 358:	36f800c0 	tbz	w0, #31, 370 <main+0x58>
    fprintf(2, "rmmod: cannot unload %s\n", argv[1]);
 35c:	2a1303e0 	mov	w0, w19
 360:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 364:	910f2021 	add	x1, x1, #0x3c8
 368:	97ffffe4 	bl	2f8 <fprintf@plt>
 36c:	17fffff4 	b	33c <main+0x24>
  }

  printf("rmmod: unloaded %s\n", argv[1]);
 370:	aa0203e1 	mov	x1, x2
 374:	90000000 	adrp	x0, 0 <.plt-0x2b8>
 378:	910f8400 	add	x0, x0, #0x3e1
 37c:	97ffffd7 	bl	2d8 <printf@plt>
  exit(0);
 380:	52800000 	mov	w0, #0x0                   	// #0
 384:	17ffffef 	b	340 <main+0x28>
