
user/_taskset:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000370 <.plt>:
 370:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 374:	b0000010 	adrp	x16, 1000 <show+0x8f4>
 378:	f944d611 	ldr	x17, [x16, #2472]
 37c:	9126a210 	add	x16, x16, #0x9a8
 380:	d61f0220 	br	x17
 384:	d503201f 	nop
 388:	d503201f 	nop
 38c:	d503201f 	nop

0000000000000390 <printf@plt>:
 390:	b0000010 	adrp	x16, 1000 <show+0x8f4>
 394:	f944da11 	ldr	x17, [x16, #2480]
 398:	9126c210 	add	x16, x16, #0x9b0
 39c:	d61f0220 	br	x17

00000000000003a0 <fprintf@plt>:
 3a0:	b0000010 	adrp	x16, 1000 <show+0x8f4>
 3a4:	f944de11 	ldr	x17, [x16, #2488]
 3a8:	9126e210 	add	x16, x16, #0x9b8
 3ac:	d61f0220 	br	x17

00000000000003b0 <exec@plt>:
 3b0:	b0000010 	adrp	x16, 1000 <show+0x8f4>
 3b4:	f944e211 	ldr	x17, [x16, #2496]
 3b8:	91270210 	add	x16, x16, #0x9c0
 3bc:	d61f0220 	br	x17

00000000000003c0 <sched_getinfo@plt>:
 3c0:	b0000010 	adrp	x16, 1000 <show+0x8f4>
 3c4:	f944e611 	ldr	x17, [x16, #2504]
 3c8:	91272210 	add	x16, x16, #0x9c8
 3cc:	d61f0220 	br	x17

00000000000003d0 <strcmp@plt>:
 3d0:	b0000010 	adrp	x16, 1000 <show+0x8f4>
 3d4:	f944ea11 	ldr	x17, [x16, #2512]
 3d8:	91274210 	add	x16, x16, #0x9d0
 3dc:	d61f0220 	br	x17

00000000000003e0 <sched_setaffinity@plt>:
 3e0:	b0000010 	adrp	x16, 1000 <show+0x8f4>
 3e4:	f944ee11 	ldr	x17, [x16, #2520]
 3e8:	91276210 	add	x16, x16, #0x9d8
 3ec:	d61f0220 	br	x17

00000000000003f0 <exit@plt>:
 3f0:	b0000010 	adrp	x16, 1000 <show+0x8f4>
 3f4:	f944f211 	ldr	x17, [x16, #2528]
 3f8:	91278210 	add	x16, x16, #0x9e0
 3fc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000400 <main>:
  printf("pid %d's %s affinity mask: %x\n", si.pid, what, si.cpumask);
}

int
main(int argc, char *argv[])
{
 400:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
 404:	910003fd 	mov	x29, sp
 408:	a90153f3 	stp	x19, x20, [sp, #16]
 40c:	aa0103f3 	mov	x19, x1
 410:	a9025bf5 	stp	x21, x22, [sp, #32]
 414:	a90363f7 	stp	x23, x24, [sp, #48]
 418:	f90023f9 	str	x25, [sp, #64]
  int mask, pid;

  if(argc == 3 && strcmp(argv[1], "-p") == 0){
 41c:	71000c1f 	cmp	w0, #0x3
 420:	54000221 	b.ne	464 <main+0x64>  // b.any
 424:	f9400660 	ldr	x0, [x19, #8]
 428:	90000001 	adrp	x1, 0 <.plt-0x370>
 42c:	911ff021 	add	x1, x1, #0x7fc
 430:	97ffffe8 	bl	3d0 <strcmp@plt>
 434:	35000660 	cbnz	w0, 500 <main+0x100>
    if(!parse_num(argv[2], &pid))
 438:	f9400a60 	ldr	x0, [x19, #16]
 43c:	910183e1 	add	x1, sp, #0x60
 440:	9400006f 	bl	5fc <parse_num>
 444:	35000040 	cbnz	w0, 44c <main+0x4c>
      usage();
 448:	940000a9 	bl	6ec <usage>
    show(pid, "current");
 44c:	b94063e0 	ldr	w0, [sp, #96]
 450:	90000001 	adrp	x1, 0 <.plt-0x370>
 454:	911ffc21 	add	x1, x1, #0x7ff
    show(pid, "current");
    if(sched_setaffinity(pid, mask) < 0){
      fprintf(2, "taskset: failed to set pid %d's affinity to %x\n", pid, mask);
      exit(1);
    }
    show(pid, "new");
 458:	940000ad 	bl	70c <show>
    exit(0);
 45c:	52800000 	mov	w0, #0x0                   	// #0
 460:	14000021 	b	4e4 <main+0xe4>
  if(argc == 4 && strcmp(argv[1], "-p") == 0){
 464:	7100101f 	cmp	w0, #0x4
 468:	54000481 	b.ne	4f8 <main+0xf8>  // b.any
 46c:	f9400660 	ldr	x0, [x19, #8]
 470:	90000001 	adrp	x1, 0 <.plt-0x370>
 474:	911ff021 	add	x1, x1, #0x7fc
 478:	97ffffd6 	bl	3d0 <strcmp@plt>
 47c:	35000420 	cbnz	w0, 500 <main+0x100>
    if(!parse_num(argv[2], &mask) || !parse_num(argv[3], &pid))
 480:	f9400a60 	ldr	x0, [x19, #16]
 484:	910173e1 	add	x1, sp, #0x5c
 488:	9400005d 	bl	5fc <parse_num>
 48c:	34fffde0 	cbz	w0, 448 <main+0x48>
 490:	f9400e60 	ldr	x0, [x19, #24]
 494:	910183e1 	add	x1, sp, #0x60
 498:	94000059 	bl	5fc <parse_num>
 49c:	34fffd60 	cbz	w0, 448 <main+0x48>
    show(pid, "current");
 4a0:	b94063f3 	ldr	w19, [sp, #96]
 4a4:	90000001 	adrp	x1, 0 <.plt-0x370>
 4a8:	911ffc21 	add	x1, x1, #0x7ff
 4ac:	2a1303e0 	mov	w0, w19
 4b0:	94000097 	bl	70c <show>
    if(sched_setaffinity(pid, mask) < 0){
 4b4:	b9405ff4 	ldr	w20, [sp, #92]
 4b8:	2a1303e0 	mov	w0, w19
 4bc:	2a1403e1 	mov	w1, w20
 4c0:	97ffffc8 	bl	3e0 <sched_setaffinity@plt>
 4c4:	36f80120 	tbz	w0, #31, 4e8 <main+0xe8>
      fprintf(2, "taskset: failed to set pid %d's affinity to %x\n", pid, mask);
 4c8:	90000001 	adrp	x1, 0 <.plt-0x370>
 4cc:	91201c21 	add	x1, x1, #0x807
 4d0:	2a1403e3 	mov	w3, w20
 4d4:	2a1303e2 	mov	w2, w19
 4d8:	52800040 	mov	w0, #0x2                   	// #2
 4dc:	97ffffb1 	bl	3a0 <fprintf@plt>
      exit(1);
 4e0:	52800020 	mov	w0, #0x1                   	// #1
 4e4:	97ffffc3 	bl	3f0 <exit@plt>
    show(pid, "new");
 4e8:	90000001 	adrp	x1, 0 <.plt-0x370>
 4ec:	9120dc21 	add	x1, x1, #0x837
 4f0:	2a1303e0 	mov	w0, w19
 4f4:	17ffffd9 	b	458 <main+0x58>
  }
  if(argc < 3 || !parse_num(argv[1], &mask))
 4f8:	7100081f 	cmp	w0, #0x2
 4fc:	54fffa6d 	b.le	448 <main+0x48>
 500:	f9400660 	ldr	x0, [x19, #8]
 504:	910173e1 	add	x1, sp, #0x5c
 508:	9400003d 	bl	5fc <parse_num>
 50c:	2a0003f6 	mov	w22, w0
 510:	34fff9c0 	cbz	w0, 448 <main+0x48>
    usage();
  if(sched_setaffinity(0, mask) < 0){
 514:	b9405ff4 	ldr	w20, [sp, #92]
 518:	52800000 	mov	w0, #0x0                   	// #0
 51c:	2a1403e1 	mov	w1, w20
 520:	97ffffb0 	bl	3e0 <sched_setaffinity@plt>
 524:	36f800e0 	tbz	w0, #31, 540 <main+0x140>
    fprintf(2, "taskset: invalid mask %x\n", mask);
 528:	2a1403e2 	mov	w2, w20
 52c:	90000001 	adrp	x1, 0 <.plt-0x370>
 530:	9120ec21 	add	x1, x1, #0x83b
 534:	52800040 	mov	w0, #0x2                   	// #2
 538:	97ffff9a 	bl	3a0 <fprintf@plt>
    exit(1);
 53c:	17ffffe9 	b	4e0 <main+0xe0>
// exec() argv[0] the way sh does: as given if it has a '/', else /bin, then /.
static __attribute__((unused)) void
exec_cmd(char **argv)
{
  char path[64];
  char *name = argv[0];
 540:	f9400a75 	ldr	x21, [x19, #16]
  }
  exec_cmd(&argv[2]);
 544:	91004278 	add	x24, x19, #0x10
  int n;

  for(char *c = name; *c; c++)
 548:	aa1503e0 	mov	x0, x21
 54c:	39400001 	ldrb	w1, [x0]
 550:	35000301 	cbnz	w1, 5b0 <main+0x1b0>
 554:	90000002 	adrp	x2, 0 <.plt-0x370>
 558:	911fd842 	add	x2, x2, #0x7f6
 55c:	910183f4 	add	x20, sp, #0x60
 560:	52800017 	mov	w23, #0x0                   	// #0
    if(*c == '/'){
      exec(name, argv);
      return;
    }
  for(int pass = 0; pass < 2; pass++){
    const char *prefix = pass == 0 ? "/bin/" : "/";
 564:	90000019 	adrp	x25, 0 <.plt-0x370>
    n = 0;
    for(const char *c = prefix; *c; c++)
 568:	d2800000 	mov	x0, #0x0                   	// #0
 56c:	38606841 	ldrb	w1, [x2, x0]
 570:	350003a1 	cbnz	w1, 5e4 <main+0x1e4>
 574:	2a0003e2 	mov	w2, w0
      path[n++] = *c;
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 578:	cb2042a0 	sub	x0, x21, w0, uxtw
 57c:	38626801 	ldrb	w1, [x0, x2]
 580:	34000061 	cbz	w1, 58c <main+0x18c>
 584:	7100f85f 	cmp	w2, #0x3e
 588:	5400034d 	b.le	5f0 <main+0x1f0>
      path[n++] = *c;
    path[n] = 0;
 58c:	38224a9f 	strb	wzr, [x20, w2, uxtw]
    exec(path, argv);
 590:	aa1803e1 	mov	x1, x24
 594:	aa1403e0 	mov	x0, x20
 598:	97ffff86 	bl	3b0 <exec@plt>
    const char *prefix = pass == 0 ? "/bin/" : "/";
 59c:	911feb22 	add	x2, x25, #0x7fa
  for(int pass = 0; pass < 2; pass++){
 5a0:	710006ff 	cmp	w23, #0x1
 5a4:	54000100 	b.eq	5c4 <main+0x1c4>  // b.none
 5a8:	2a1603f7 	mov	w23, w22
 5ac:	17ffffef 	b	568 <main+0x168>
    if(*c == '/'){
 5b0:	7100bc3f 	cmp	w1, #0x2f
 5b4:	54000141 	b.ne	5dc <main+0x1dc>  // b.any
      exec(name, argv);
 5b8:	aa1803e1 	mov	x1, x24
 5bc:	aa1503e0 	mov	x0, x21
 5c0:	97ffff7c 	bl	3b0 <exec@plt>
  fprintf(2, "taskset: exec %s failed\n", argv[2]);
 5c4:	f9400a62 	ldr	x2, [x19, #16]
 5c8:	90000001 	adrp	x1, 0 <.plt-0x370>
 5cc:	91215421 	add	x1, x1, #0x855
 5d0:	52800040 	mov	w0, #0x2                   	// #2
 5d4:	97ffff73 	bl	3a0 <fprintf@plt>
  exit(1);
 5d8:	17ffffc2 	b	4e0 <main+0xe0>
  for(char *c = name; *c; c++)
 5dc:	91000400 	add	x0, x0, #0x1
 5e0:	17ffffdb 	b	54c <main+0x14c>
      path[n++] = *c;
 5e4:	38206a81 	strb	w1, [x20, x0]
    for(const char *c = prefix; *c; c++)
 5e8:	91000400 	add	x0, x0, #0x1
 5ec:	17ffffe0 	b	56c <main+0x16c>
      path[n++] = *c;
 5f0:	38226a81 	strb	w1, [x20, x2]
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 5f4:	91000442 	add	x2, x2, #0x1
 5f8:	17ffffe1 	b	57c <main+0x17c>

00000000000005fc <parse_num>:
{
 5fc:	aa0003e2 	mov	x2, x0
  if(*s == '-'){
 600:	39400000 	ldrb	w0, [x0]
 604:	7100b41f 	cmp	w0, #0x2d
 608:	540002c1 	b.ne	660 <parse_num+0x64>  // b.any
    s++;
 60c:	91000442 	add	x2, x2, #0x1
    neg = 1;
 610:	52800025 	mov	w5, #0x1                   	// #1
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 614:	39400040 	ldrb	w0, [x2]
 618:	7100c01f 	cmp	w0, #0x30
 61c:	540000c1 	b.ne	634 <parse_num+0x38>  // b.any
 620:	39400440 	ldrb	w0, [x2, #1]
 624:	121a7800 	and	w0, w0, #0xffffffdf
 628:	12001c00 	and	w0, w0, #0xff
 62c:	7101601f 	cmp	w0, #0x58
 630:	540001c0 	b.eq	668 <parse_num+0x6c>  // b.none
 634:	52800000 	mov	w0, #0x0                   	// #0
 638:	52800003 	mov	w3, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 63c:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
 640:	39400044 	ldrb	w4, [x2]
 644:	340001c4 	cbz	w4, 67c <parse_num+0x80>
      if(*s < '0' || *s > '9')
 648:	5100c084 	sub	w4, w4, #0x30
 64c:	12001c80 	and	w0, w4, #0xff
 650:	7100241f 	cmp	w0, #0x9
 654:	54000449 	b.ls	6dc <parse_num+0xe0>  // b.plast
      else return 0;
 658:	52800000 	mov	w0, #0x0                   	// #0
}
 65c:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
 660:	52800005 	mov	w5, #0x0                   	// #0
 664:	17ffffec 	b	614 <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
 668:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
 66c:	52800000 	mov	w0, #0x0                   	// #0
 670:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 674:	39400044 	ldrb	w4, [x2]
 678:	350000c4 	cbnz	w4, 690 <parse_num+0x94>
  if(!any)
 67c:	34ffff00 	cbz	w0, 65c <parse_num+0x60>
  *out = neg ? -v : v;
 680:	710000bf 	cmp	w5, #0x0
 684:	5a830463 	cneg	w3, w3, ne	// ne = any
 688:	b9000023 	str	w3, [x1]
  return 1;
 68c:	17fffff4 	b	65c <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 690:	5100c080 	sub	w0, w4, #0x30
 694:	12001c06 	and	w6, w0, #0xff
 698:	710024df 	cmp	w6, #0x9
 69c:	540000c9 	b.ls	6b4 <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 6a0:	51018480 	sub	w0, w4, #0x61
 6a4:	12001c00 	and	w0, w0, #0xff
 6a8:	7100141f 	cmp	w0, #0x5
 6ac:	540000c8 	b.hi	6c4 <parse_num+0xc8>  // b.pmore
 6b0:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
 6b4:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
 6b8:	91000442 	add	x2, x2, #0x1
 6bc:	52800020 	mov	w0, #0x1                   	// #1
 6c0:	17ffffed 	b	674 <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 6c4:	51010480 	sub	w0, w4, #0x41
 6c8:	12001c00 	and	w0, w0, #0xff
 6cc:	7100141f 	cmp	w0, #0x5
 6d0:	54fffc48 	b.hi	658 <parse_num+0x5c>  // b.pmore
 6d4:	5100dc80 	sub	w0, w4, #0x37
 6d8:	17fffff7 	b	6b4 <parse_num+0xb8>
      v = v * 10 + (*s - '0');
 6dc:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
 6e0:	91000442 	add	x2, x2, #0x1
 6e4:	52800020 	mov	w0, #0x1                   	// #1
 6e8:	17ffffd6 	b	640 <parse_num+0x44>

00000000000006ec <usage>:
{
 6ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: taskset -p PID\n"
 6f0:	90000001 	adrp	x1, 0 <.plt-0x370>
 6f4:	911db021 	add	x1, x1, #0x76c
{
 6f8:	910003fd 	mov	x29, sp
  fprintf(2, "usage: taskset -p PID\n"
 6fc:	52800040 	mov	w0, #0x2                   	// #2
 700:	97ffff28 	bl	3a0 <fprintf@plt>
  exit(1);
 704:	52800020 	mov	w0, #0x1                   	// #1
 708:	97ffff3a 	bl	3f0 <exit@plt>

000000000000070c <show>:
{
 70c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 710:	910003fd 	mov	x29, sp
 714:	f9000bf3 	str	x19, [sp, #16]
 718:	aa0103f3 	mov	x19, x1
  if(sched_getinfo(pid, &si) < 0){
 71c:	9100e3e1 	add	x1, sp, #0x38
{
 720:	b9002fe0 	str	w0, [sp, #44]
  if(sched_getinfo(pid, &si) < 0){
 724:	97ffff27 	bl	3c0 <sched_getinfo@plt>
 728:	b9402fe2 	ldr	w2, [sp, #44]
 72c:	36f800e0 	tbz	w0, #31, 748 <show+0x3c>
    fprintf(2, "taskset: no process %d\n", pid);
 730:	90000001 	adrp	x1, 0 <.plt-0x370>
 734:	911efc21 	add	x1, x1, #0x7bf
 738:	52800040 	mov	w0, #0x2                   	// #2
 73c:	97ffff19 	bl	3a0 <fprintf@plt>
    exit(1);
 740:	52800020 	mov	w0, #0x1                   	// #1
 744:	97ffff2b 	bl	3f0 <exit@plt>
  printf("pid %d's %s affinity mask: %x\n", si.pid, what, si.cpumask);
 748:	b9403be1 	ldr	w1, [sp, #56]
 74c:	aa1303e2 	mov	x2, x19
 750:	b9404be3 	ldr	w3, [sp, #72]
 754:	90000000 	adrp	x0, 0 <.plt-0x370>
 758:	911f5c00 	add	x0, x0, #0x7d7
 75c:	97ffff0d 	bl	390 <printf@plt>
}
 760:	f9400bf3 	ldr	x19, [sp, #16]
 764:	a8c67bfd 	ldp	x29, x30, [sp], #96
 768:	d65f03c0 	ret
