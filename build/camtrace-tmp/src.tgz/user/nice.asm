
user/_nice:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000330 <.plt>:
 330:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 334:	b0000010 	adrp	x16, 1000 <main+0xc50>
 338:	f943d611 	ldr	x17, [x16, #1960]
 33c:	911ea210 	add	x16, x16, #0x7a8
 340:	d61f0220 	br	x17
 344:	d503201f 	nop
 348:	d503201f 	nop
 34c:	d503201f 	nop

0000000000000350 <fprintf@plt>:
 350:	b0000010 	adrp	x16, 1000 <main+0xc50>
 354:	f943da11 	ldr	x17, [x16, #1968]
 358:	911ec210 	add	x16, x16, #0x7b0
 35c:	d61f0220 	br	x17

0000000000000360 <exec@plt>:
 360:	b0000010 	adrp	x16, 1000 <main+0xc50>
 364:	f943de11 	ldr	x17, [x16, #1976]
 368:	911ee210 	add	x16, x16, #0x7b8
 36c:	d61f0220 	br	x17

0000000000000370 <sched_getinfo@plt>:
 370:	b0000010 	adrp	x16, 1000 <main+0xc50>
 374:	f943e211 	ldr	x17, [x16, #1984]
 378:	911f0210 	add	x16, x16, #0x7c0
 37c:	d61f0220 	br	x17

0000000000000380 <strcmp@plt>:
 380:	b0000010 	adrp	x16, 1000 <main+0xc50>
 384:	f943e611 	ldr	x17, [x16, #1992]
 388:	911f2210 	add	x16, x16, #0x7c8
 38c:	d61f0220 	br	x17

0000000000000390 <setnice@plt>:
 390:	b0000010 	adrp	x16, 1000 <main+0xc50>
 394:	f943ea11 	ldr	x17, [x16, #2000]
 398:	911f4210 	add	x16, x16, #0x7d0
 39c:	d61f0220 	br	x17

00000000000003a0 <exit@plt>:
 3a0:	b0000010 	adrp	x16, 1000 <main+0xc50>
 3a4:	f943ee11 	ldr	x17, [x16, #2008]
 3a8:	911f6210 	add	x16, x16, #0x7d8
 3ac:	d61f0220 	br	x17

Disassembly of section .text:

00000000000003b0 <main>:
#include "user/user.h"
#include "user/schedutil.h"

int
main(int argc, char *argv[])
{
 3b0:	a9b47bfd 	stp	x29, x30, [sp, #-192]!
 3b4:	910003fd 	mov	x29, sp
 3b8:	a90153f3 	stp	x19, x20, [sp, #16]
 3bc:	a9025bf5 	stp	x21, x22, [sp, #32]
 3c0:	2a0003f6 	mov	w22, w0
 3c4:	aa0103f5 	mov	x21, x1
 3c8:	a90363f7 	stp	x23, x24, [sp, #48]
 3cc:	f90023f9 	str	x25, [sp, #64]
  int n = 10, i = 1;
  struct sched_info si;

  if(argc >= 3 && strcmp(argv[1], "-n") == 0){
 3d0:	7100081f 	cmp	w0, #0x2
 3d4:	5400084d 	b.le	4dc <main+0x12c>
 3d8:	f94006a0 	ldr	x0, [x21, #8]
 3dc:	90000001 	adrp	x1, 0 <.plt-0x330>
 3e0:	91184821 	add	x1, x1, #0x612
 3e4:	97ffffe7 	bl	380 <strcmp@plt>
 3e8:	2a0003f3 	mov	w19, w0
 3ec:	35000a20 	cbnz	w0, 530 <main+0x180>
    if(!parse_num(argv[2], &n))
 3f0:	f9400aa0 	ldr	x0, [x21, #16]
static __attribute__((unused)) int
parse_num(const char *s, int *out)
{
  int neg = 0, v = 0, any = 0;

  if(*s == '-'){
 3f4:	39400001 	ldrb	w1, [x0]
 3f8:	7100b43f 	cmp	w1, #0x2d
 3fc:	54000281 	b.ne	44c <main+0x9c>  // b.any
    neg = 1;
    s++;
 400:	91000400 	add	x0, x0, #0x1
    neg = 1;
 404:	52800023 	mov	w3, #0x1                   	// #1
  }
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 408:	39400001 	ldrb	w1, [x0]
 40c:	7100c03f 	cmp	w1, #0x30
 410:	54000601 	b.ne	4d0 <main+0x120>  // b.any
 414:	39400401 	ldrb	w1, [x0, #1]
 418:	121a7821 	and	w1, w1, #0xffffffdf
 41c:	12001c21 	and	w1, w1, #0xff
 420:	7101603f 	cmp	w1, #0x58
 424:	54000561 	b.ne	4d0 <main+0x120>  // b.any
    for(s += 2; *s; s++, any = 1){
 428:	91000800 	add	x0, x0, #0x2
  int neg = 0, v = 0, any = 0;
 42c:	52800002 	mov	w2, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 430:	39400001 	ldrb	w1, [x0]
 434:	35000101 	cbnz	w1, 454 <main+0xa4>
      if(*s < '0' || *s > '9')
        return 0;
      v = v * 10 + (*s - '0');
    }
  }
  if(!any)
 438:	34000e02 	cbz	w2, 5f8 <main+0x248>
    return 0;
  *out = neg ? -v : v;
 43c:	34000043 	cbz	w3, 444 <main+0x94>
 440:	4b1303f3 	neg	w19, w19
      goto usage;
    i = 3;
 444:	52800074 	mov	w20, #0x3                   	// #3
 448:	14000027 	b	4e4 <main+0x134>
  int neg = 0, v = 0, any = 0;
 44c:	52800003 	mov	w3, #0x0                   	// #0
 450:	17ffffee 	b	408 <main+0x58>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 454:	5100c022 	sub	w2, w1, #0x30
 458:	12001c44 	and	w4, w2, #0xff
 45c:	7100249f 	cmp	w4, #0x9
 460:	540000c8 	b.hi	478 <main+0xc8>  // b.pmore
 464:	2a0203e1 	mov	w1, w2
      v = v * 16 + d;
 468:	0b131033 	add	w19, w1, w19, lsl #4
    for(s += 2; *s; s++, any = 1){
 46c:	91000400 	add	x0, x0, #0x1
 470:	52800022 	mov	w2, #0x1                   	// #1
 474:	17ffffef 	b	430 <main+0x80>
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 478:	51018422 	sub	w2, w1, #0x61
 47c:	12001c42 	and	w2, w2, #0xff
 480:	7100145f 	cmp	w2, #0x5
 484:	54000068 	b.hi	490 <main+0xe0>  // b.pmore
 488:	51015c21 	sub	w1, w1, #0x57
 48c:	17fffff7 	b	468 <main+0xb8>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 490:	51010422 	sub	w2, w1, #0x41
 494:	12001c42 	and	w2, w2, #0xff
 498:	7100145f 	cmp	w2, #0x5
 49c:	54000ae8 	b.hi	5f8 <main+0x248>  // b.pmore
 4a0:	5100dc21 	sub	w1, w1, #0x37
 4a4:	17fffff1 	b	468 <main+0xb8>
      if(*s < '0' || *s > '9')
 4a8:	5100c021 	sub	w1, w1, #0x30
 4ac:	12001c22 	and	w2, w1, #0xff
 4b0:	7100245f 	cmp	w2, #0x9
 4b4:	54000a28 	b.hi	5f8 <main+0x248>  // b.pmore
      v = v * 10 + (*s - '0');
 4b8:	1b040673 	madd	w19, w19, w4, w1
    for(; *s; s++, any = 1){
 4bc:	91000400 	add	x0, x0, #0x1
 4c0:	52800022 	mov	w2, #0x1                   	// #1
 4c4:	39400001 	ldrb	w1, [x0]
 4c8:	35ffff01 	cbnz	w1, 4a8 <main+0xf8>
 4cc:	17ffffdb 	b	438 <main+0x88>
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 4d0:	52800002 	mov	w2, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 4d4:	52800144 	mov	w4, #0xa                   	// #10
 4d8:	17fffffb 	b	4c4 <main+0x114>
  int n = 10, i = 1;
 4dc:	52800153 	mov	w19, #0xa                   	// #10
 4e0:	52800034 	mov	w20, #0x1                   	// #1
  }
  if(i >= argc)
 4e4:	6b16029f 	cmp	w20, w22
 4e8:	5400088a 	b.ge	5f8 <main+0x248>  // b.tcont
    goto usage;
  if(sched_getinfo(0, &si) < 0 || setnice(0, si.nice + n) < 0){
 4ec:	910163e1 	add	x1, sp, #0x58
 4f0:	52800000 	mov	w0, #0x0                   	// #0
 4f4:	97ffff9f 	bl	370 <sched_getinfo@plt>
 4f8:	37f800c0 	tbnz	w0, #31, 510 <main+0x160>
 4fc:	b94067e1 	ldr	w1, [sp, #100]
 500:	52800000 	mov	w0, #0x0                   	// #0
 504:	0b010261 	add	w1, w19, w1
 508:	97ffffa2 	bl	390 <setnice@plt>
 50c:	36f80180 	tbz	w0, #31, 53c <main+0x18c>
    fprintf(2, "nice: invalid nice value %d\n", si.nice + n);
 510:	b94067e2 	ldr	w2, [sp, #100]
 514:	90000001 	adrp	x1, 0 <.plt-0x330>
 518:	91185421 	add	x1, x1, #0x615
 51c:	52800040 	mov	w0, #0x2                   	// #2
 520:	0b020262 	add	w2, w19, w2
 524:	97ffff8b 	bl	350 <fprintf@plt>
    exit(1);
  }
  exec_cmd(&argv[i]);
  fprintf(2, "nice: exec %s failed\n", argv[i]);
  exit(1);
 528:	52800020 	mov	w0, #0x1                   	// #1
 52c:	97ffff9d 	bl	3a0 <exit@plt>
  int n = 10, i = 1;
 530:	52800153 	mov	w19, #0xa                   	// #10
 534:	52800034 	mov	w20, #0x1                   	// #1
 538:	17ffffed 	b	4ec <main+0x13c>
  exec_cmd(&argv[i]);
 53c:	d37d0694 	ubfiz	x20, x20, #3, #2
 540:	8b1402b8 	add	x24, x21, x20
// exec() argv[0] the way sh does: as given if it has a '/', else /bin, then /.
static __attribute__((unused)) void
exec_cmd(char **argv)
{
  char path[64];
  char *name = argv[0];
 544:	f8746ab6 	ldr	x22, [x21, x20]
  int n;

  for(char *c = name; *c; c++)
 548:	aa1603e0 	mov	x0, x22
 54c:	39400001 	ldrb	w1, [x0]
 550:	350002e1 	cbnz	w1, 5ac <main+0x1fc>
 554:	90000002 	adrp	x2, 0 <.plt-0x330>
 558:	91183042 	add	x2, x2, #0x60c
 55c:	910203f3 	add	x19, sp, #0x80
 560:	52800017 	mov	w23, #0x0                   	// #0
    if(*c == '/'){
      exec(name, argv);
      return;
    }
  for(int pass = 0; pass < 2; pass++){
    const char *prefix = pass == 0 ? "/bin/" : "/";
 564:	90000019 	adrp	x25, 0 <.plt-0x330>
    n = 0;
    for(const char *c = prefix; *c; c++)
 568:	d2800000 	mov	x0, #0x0                   	// #0
 56c:	38606841 	ldrb	w1, [x2, x0]
 570:	35000381 	cbnz	w1, 5e0 <main+0x230>
 574:	2a0003e2 	mov	w2, w0
      path[n++] = *c;
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 578:	cb2042c0 	sub	x0, x22, w0, uxtw
 57c:	38626801 	ldrb	w1, [x0, x2]
 580:	34000061 	cbz	w1, 58c <main+0x1dc>
 584:	7100f85f 	cmp	w2, #0x3e
 588:	5400032d 	b.le	5ec <main+0x23c>
      path[n++] = *c;
    path[n] = 0;
    exec(path, argv);
 58c:	aa1803e1 	mov	x1, x24
 590:	aa1303e0 	mov	x0, x19
    path[n] = 0;
 594:	38224a7f 	strb	wzr, [x19, w2, uxtw]
    exec(path, argv);
 598:	97ffff72 	bl	360 <exec@plt>
    const char *prefix = pass == 0 ? "/bin/" : "/";
 59c:	91184322 	add	x2, x25, #0x610
  for(int pass = 0; pass < 2; pass++){
 5a0:	35000117 	cbnz	w23, 5c0 <main+0x210>
 5a4:	52800037 	mov	w23, #0x1                   	// #1
 5a8:	17fffff0 	b	568 <main+0x1b8>
    if(*c == '/'){
 5ac:	7100bc3f 	cmp	w1, #0x2f
 5b0:	54000141 	b.ne	5d8 <main+0x228>  // b.any
      exec(name, argv);
 5b4:	aa1803e1 	mov	x1, x24
 5b8:	aa1603e0 	mov	x0, x22
 5bc:	97ffff69 	bl	360 <exec@plt>
  fprintf(2, "nice: exec %s failed\n", argv[i]);
 5c0:	f8746aa2 	ldr	x2, [x21, x20]
 5c4:	90000001 	adrp	x1, 0 <.plt-0x330>
 5c8:	9118c821 	add	x1, x1, #0x632
 5cc:	52800040 	mov	w0, #0x2                   	// #2
 5d0:	97ffff60 	bl	350 <fprintf@plt>
 5d4:	17ffffd5 	b	528 <main+0x178>
  for(char *c = name; *c; c++)
 5d8:	91000400 	add	x0, x0, #0x1
 5dc:	17ffffdc 	b	54c <main+0x19c>
      path[n++] = *c;
 5e0:	38206a61 	strb	w1, [x19, x0]
    for(const char *c = prefix; *c; c++)
 5e4:	91000400 	add	x0, x0, #0x1
 5e8:	17ffffe1 	b	56c <main+0x1bc>
      path[n++] = *c;
 5ec:	38226a61 	strb	w1, [x19, x2]
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 5f0:	91000442 	add	x2, x2, #0x1
 5f4:	17ffffe2 	b	57c <main+0x1cc>
usage:
  fprintf(2, "usage: nice [-n N] CMD [ARG...]\n");
 5f8:	90000001 	adrp	x1, 0 <.plt-0x330>
 5fc:	91192021 	add	x1, x1, #0x648
 600:	52800040 	mov	w0, #0x2                   	// #2
 604:	97ffff53 	bl	350 <fprintf@plt>
  exit(1);
 608:	17ffffc8 	b	528 <main+0x178>
