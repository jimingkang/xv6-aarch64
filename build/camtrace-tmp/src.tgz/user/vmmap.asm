
user/_vmmap:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002b8 <.plt>:
 2b8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2bc:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2c0:	f9428211 	ldr	x17, [x16, #1280]
 2c4:	91140210 	add	x16, x16, #0x500
 2c8:	d61f0220 	br	x17
 2cc:	d503201f 	nop
 2d0:	d503201f 	nop
 2d4:	d503201f 	nop

00000000000002d8 <fprintf@plt>:
 2d8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2dc:	f9428611 	ldr	x17, [x16, #1288]
 2e0:	91142210 	add	x16, x16, #0x508
 2e4:	d61f0220 	br	x17

00000000000002e8 <vmdump@plt>:
 2e8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2ec:	f9428a11 	ldr	x17, [x16, #1296]
 2f0:	91144210 	add	x16, x16, #0x510
 2f4:	d61f0220 	br	x17

00000000000002f8 <exit@plt>:
 2f8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2fc:	f9428e11 	ldr	x17, [x16, #1304]
 300:	91146210 	add	x16, x16, #0x518
 304:	d61f0220 	br	x17

0000000000000308 <atoi@plt>:
 308:	b0000010 	adrp	x16, 1000 <main+0xce8>
 30c:	f9429211 	ldr	x17, [x16, #1312]
 310:	91148210 	add	x16, x16, #0x520
 314:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000318 <main>:
#include <uapi/types.h>
#include "user/user.h"

int
main(int argc, char **argv)
{
 318:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 31c:	910003fd 	mov	x29, sp
 320:	f9000bf3 	str	x19, [sp, #16]
  int pid = 0;
  if(argc > 2){
 324:	7100081f 	cmp	w0, #0x2
 328:	540000ed 	b.le	344 <main+0x2c>
    fprintf(2, "usage: vmmap [pid]\n");
 32c:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 330:	910e1021 	add	x1, x1, #0x384
 334:	52800040 	mov	w0, #0x2                   	// #2
 338:	97ffffe8 	bl	2d8 <fprintf@plt>
    exit(1);
 33c:	52800020 	mov	w0, #0x1                   	// #1
 340:	97ffffee 	bl	2f8 <exit@plt>
  }
  if(argc == 2){
 344:	54000101 	b.ne	364 <main+0x4c>  // b.any
    pid = atoi(argv[1]);
 348:	f9400420 	ldr	x0, [x1, #8]
 34c:	97ffffef 	bl	308 <atoi@plt>
    if(pid <= 0){
 350:	7100001f 	cmp	w0, #0x0
 354:	540000ac 	b.gt	368 <main+0x50>
      fprintf(2, "vmmap: invalid pid\n");
 358:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 35c:	910e6021 	add	x1, x1, #0x398
 360:	17fffff5 	b	334 <main+0x1c>
  int pid = 0;
 364:	52800000 	mov	w0, #0x0                   	// #0
      exit(1);
    }
  }
  if(vmdump(pid) < 0){
 368:	97ffffe0 	bl	2e8 <vmdump@plt>
 36c:	36f80080 	tbz	w0, #31, 37c <main+0x64>
    fprintf(2, "vmmap: process not found\n");
 370:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 374:	910eb021 	add	x1, x1, #0x3ac
 378:	17ffffef 	b	334 <main+0x1c>
    exit(1);
  }
  exit(0);
 37c:	52800000 	mov	w0, #0x0                   	// #0
 380:	17fffff0 	b	340 <main+0x28>
