
user/_wc:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000328 <.plt>:
 328:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 32c:	b0000010 	adrp	x16, 1000 <wc+0xbd4>
 330:	f9434a11 	ldr	x17, [x16, #1680]
 334:	911a4210 	add	x16, x16, #0x690
 338:	d61f0220 	br	x17
 33c:	d503201f 	nop
 340:	d503201f 	nop
 344:	d503201f 	nop

0000000000000348 <printf@plt>:
 348:	b0000010 	adrp	x16, 1000 <wc+0xbd4>
 34c:	f9434e11 	ldr	x17, [x16, #1688]
 350:	911a6210 	add	x16, x16, #0x698
 354:	d61f0220 	br	x17

0000000000000358 <read@plt>:
 358:	b0000010 	adrp	x16, 1000 <wc+0xbd4>
 35c:	f9435211 	ldr	x17, [x16, #1696]
 360:	911a8210 	add	x16, x16, #0x6a0
 364:	d61f0220 	br	x17

0000000000000368 <exit@plt>:
 368:	b0000010 	adrp	x16, 1000 <wc+0xbd4>
 36c:	f9435611 	ldr	x17, [x16, #1704]
 370:	911aa210 	add	x16, x16, #0x6a8
 374:	d61f0220 	br	x17

0000000000000378 <open@plt>:
 378:	b0000010 	adrp	x16, 1000 <wc+0xbd4>
 37c:	f9435a11 	ldr	x17, [x16, #1712]
 380:	911ac210 	add	x16, x16, #0x6b0
 384:	d61f0220 	br	x17

0000000000000388 <strchr@plt>:
 388:	b0000010 	adrp	x16, 1000 <wc+0xbd4>
 38c:	f9435e11 	ldr	x17, [x16, #1720]
 390:	911ae210 	add	x16, x16, #0x6b8
 394:	d61f0220 	br	x17

0000000000000398 <close@plt>:
 398:	b0000010 	adrp	x16, 1000 <wc+0xbd4>
 39c:	f9436211 	ldr	x17, [x16, #1728]
 3a0:	911b0210 	add	x16, x16, #0x6c0
 3a4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000003a8 <main>:
  printf("%d %d %d %s\n", l, w, c, name);
}

int
main(int argc, char *argv[])
{
 3a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 3ac:	910003fd 	mov	x29, sp
 3b0:	a90153f3 	stp	x19, x20, [sp, #16]
 3b4:	a9025bf5 	stp	x21, x22, [sp, #32]
  int fd, i;

  if(argc <= 1){
 3b8:	7100041f 	cmp	w0, #0x1
 3bc:	540000ec 	b.gt	3d8 <main+0x30>
    wc(0, "");
 3c0:	90000001 	adrp	x1, 0 <.plt-0x328>
 3c4:	9114c421 	add	x1, x1, #0x531
 3c8:	52800000 	mov	w0, #0x0                   	// #0
 3cc:	94000018 	bl	42c <wc>
      exit(1);
    }
    wc(fd, argv[i]);
    close(fd);
  }
  exit(0);
 3d0:	52800000 	mov	w0, #0x0                   	// #0
 3d4:	1400000e 	b	40c <main+0x64>
 3d8:	2a0003f4 	mov	w20, w0
 3dc:	aa0103f6 	mov	x22, x1
  if(argc <= 1){
 3e0:	d2800033 	mov	x19, #0x1                   	// #1
    if((fd = open(argv[i], 0)) < 0){
 3e4:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
 3e8:	52800001 	mov	w1, #0x0                   	// #0
 3ec:	97ffffe3 	bl	378 <open@plt>
 3f0:	2a0003f5 	mov	w21, w0
      printf("wc: cannot open %s\n", argv[i]);
 3f4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    if((fd = open(argv[i], 0)) < 0){
 3f8:	36f800c0 	tbz	w0, #31, 410 <main+0x68>
      printf("wc: cannot open %s\n", argv[i]);
 3fc:	90000000 	adrp	x0, 0 <.plt-0x328>
 400:	9114fc00 	add	x0, x0, #0x53f
 404:	97ffffd1 	bl	348 <printf@plt>
      exit(1);
 408:	52800020 	mov	w0, #0x1                   	// #1
 40c:	97ffffd7 	bl	368 <exit@plt>
    wc(fd, argv[i]);
 410:	94000007 	bl	42c <wc>
  for(i = 1; i < argc; i++){
 414:	91000673 	add	x19, x19, #0x1
    close(fd);
 418:	2a1503e0 	mov	w0, w21
 41c:	97ffffdf 	bl	398 <close@plt>
  for(i = 1; i < argc; i++){
 420:	6b13029f 	cmp	w20, w19
 424:	54fffe0c 	b.gt	3e4 <main+0x3c>
 428:	17ffffea 	b	3d0 <main+0x28>

000000000000042c <wc>:
{
 42c:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 430:	910003fd 	mov	x29, sp
 434:	a90153f3 	stp	x19, x20, [sp, #16]
  while((n = read(fd, buf, sizeof(buf))) > 0){
 438:	b0000013 	adrp	x19, 1000 <wc+0xbd4>
 43c:	911b2273 	add	x19, x19, #0x6c8
{
 440:	a9046bf9 	stp	x25, x26, [sp, #64]
      if(strchr(" \r\t\n\v", buf[i]))
 444:	9000001a 	adrp	x26, 0 <.plt-0x328>
 448:	9114735a 	add	x26, x26, #0x51c
{
 44c:	a90573fb 	stp	x27, x28, [sp, #80]
 450:	2a0003fb 	mov	w27, w0
 454:	aa0103fc 	mov	x28, x1
  inword = 0;
 458:	52800014 	mov	w20, #0x0                   	// #0
{
 45c:	a9025bf5 	stp	x21, x22, [sp, #32]
  l = w = c = 0;
 460:	52800016 	mov	w22, #0x0                   	// #0
{
 464:	a90363f7 	stp	x23, x24, [sp, #48]
  l = w = c = 0;
 468:	52800018 	mov	w24, #0x0                   	// #0
 46c:	52800017 	mov	w23, #0x0                   	// #0
  while((n = read(fd, buf, sizeof(buf))) > 0){
 470:	aa1303e1 	mov	x1, x19
 474:	2a1b03e0 	mov	w0, w27
 478:	52804002 	mov	w2, #0x200                 	// #512
 47c:	97ffffb7 	bl	358 <read@plt>
 480:	2a0003f9 	mov	w25, w0
 484:	7100001f 	cmp	w0, #0x0
 488:	540000ec 	b.gt	4a4 <wc+0x78>
  if(n < 0){
 48c:	540002e0 	b.eq	4e8 <wc+0xbc>  // b.none
    printf("wc: read error\n");
 490:	90000000 	adrp	x0, 0 <.plt-0x328>
 494:	91148800 	add	x0, x0, #0x522
 498:	97ffffac 	bl	348 <printf@plt>
    exit(1);
 49c:	52800020 	mov	w0, #0x1                   	// #1
 4a0:	97ffffb2 	bl	368 <exit@plt>
  while((n = read(fd, buf, sizeof(buf))) > 0){
 4a4:	d2800015 	mov	x21, #0x0                   	// #0
      if(buf[i] == '\n')
 4a8:	38756a61 	ldrb	w1, [x19, x21]
      if(strchr(" \r\t\n\v", buf[i]))
 4ac:	aa1a03e0 	mov	x0, x26
        l++;
 4b0:	7100283f 	cmp	w1, #0xa
 4b4:	1a9616d6 	cinc	w22, w22, eq	// eq = none
      if(strchr(" \r\t\n\v", buf[i]))
 4b8:	97ffffb4 	bl	388 <strchr@plt>
 4bc:	b5000120 	cbnz	x0, 4e0 <wc+0xb4>
      else if(!inword){
 4c0:	7100029f 	cmp	w20, #0x0
        inword = 1;
 4c4:	1a9716f7 	cinc	w23, w23, eq	// eq = none
 4c8:	1a9f1694 	csinc	w20, w20, wzr, ne	// ne = any
    for(i=0; i<n; i++){
 4cc:	910006b5 	add	x21, x21, #0x1
 4d0:	6b15033f 	cmp	w25, w21
 4d4:	54fffeac 	b.gt	4a8 <wc+0x7c>
 4d8:	0b180338 	add	w24, w25, w24
 4dc:	17ffffe5 	b	470 <wc+0x44>
        inword = 0;
 4e0:	52800014 	mov	w20, #0x0                   	// #0
 4e4:	17fffffa 	b	4cc <wc+0xa0>
}
 4e8:	a94153f3 	ldp	x19, x20, [sp, #16]
  printf("%d %d %d %s\n", l, w, c, name);
 4ec:	aa1c03e4 	mov	x4, x28
}
 4f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
  printf("%d %d %d %s\n", l, w, c, name);
 4f4:	2a1803e3 	mov	w3, w24
}
 4f8:	a94573fb 	ldp	x27, x28, [sp, #80]
  printf("%d %d %d %s\n", l, w, c, name);
 4fc:	2a1703e2 	mov	w2, w23
 500:	2a1603e1 	mov	w1, w22
 504:	90000000 	adrp	x0, 0 <.plt-0x328>
 508:	9114c800 	add	x0, x0, #0x532
}
 50c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 510:	a94363f7 	ldp	x23, x24, [sp, #48]
 514:	a8c67bfd 	ldp	x29, x30, [sp], #96
  printf("%d %d %d %s\n", l, w, c, name);
 518:	17ffff8c 	b	348 <printf@plt>
