
user/_netdns:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000338 <.plt>:
 338:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 33c:	b0000010 	adrp	x16, 1000 <main+0xc48>
 340:	f9436e11 	ldr	x17, [x16, #1752]
 344:	911b6210 	add	x16, x16, #0x6d8
 348:	d61f0220 	br	x17
 34c:	d503201f 	nop
 350:	d503201f 	nop
 354:	d503201f 	nop

0000000000000358 <printf@plt>:
 358:	b0000010 	adrp	x16, 1000 <main+0xc48>
 35c:	f9437211 	ldr	x17, [x16, #1760]
 360:	911b8210 	add	x16, x16, #0x6e0
 364:	d61f0220 	br	x17

0000000000000368 <udp_recv@plt>:
 368:	b0000010 	adrp	x16, 1000 <main+0xc48>
 36c:	f9437611 	ldr	x17, [x16, #1768]
 370:	911ba210 	add	x16, x16, #0x6e8
 374:	d61f0220 	br	x17

0000000000000378 <udp_bind@plt>:
 378:	b0000010 	adrp	x16, 1000 <main+0xc48>
 37c:	f9437a11 	ldr	x17, [x16, #1776]
 380:	911bc210 	add	x16, x16, #0x6f0
 384:	d61f0220 	br	x17

0000000000000388 <udp_send@plt>:
 388:	b0000010 	adrp	x16, 1000 <main+0xc48>
 38c:	f9437e11 	ldr	x17, [x16, #1784]
 390:	911be210 	add	x16, x16, #0x6f8
 394:	d61f0220 	br	x17

0000000000000398 <udp_unbind@plt>:
 398:	b0000010 	adrp	x16, 1000 <main+0xc48>
 39c:	f9438211 	ldr	x17, [x16, #1792]
 3a0:	911c0210 	add	x16, x16, #0x700
 3a4:	d61f0220 	br	x17

00000000000003a8 <exit@plt>:
 3a8:	b0000010 	adrp	x16, 1000 <main+0xc48>
 3ac:	f9438611 	ldr	x17, [x16, #1800]
 3b0:	911c2210 	add	x16, x16, #0x708
 3b4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000003b8 <main>:
  0x00, 0x01, 0x00, 0x01
};

int
main(void)
{
 3b8:	d10903ff 	sub	sp, sp, #0x240
  uchar response[512];
  uint32 src;
  uint16 sport;
  int n, answers;

  if(udp_bind(LOCAL_PORT) < 0){
 3bc:	5299e100 	mov	w0, #0xcf08                	// #53000
{
 3c0:	a9017bfd 	stp	x29, x30, [sp, #16]
 3c4:	910043fd 	add	x29, sp, #0x10
  if(udp_bind(LOCAL_PORT) < 0){
 3c8:	97ffffec 	bl	378 <udp_bind@plt>
 3cc:	36f800c0 	tbz	w0, #31, 3e4 <main+0x2c>
    printf("netdns: bind failed\n");
 3d0:	90000000 	adrp	x0, 0 <.plt-0x338>
 3d4:	91132000 	add	x0, x0, #0x4c8
 3d8:	97ffffe0 	bl	358 <printf@plt>
  printf("netdns: reply from %d.%d.%d.%d:%d len=%d answers=%d rcode=%d\n",
         (src >> 24) & 255, (src >> 16) & 255,
         (src >> 8) & 255, src & 255, sport, n, answers,
         response[3] & 0x0f);
  udp_unbind(LOCAL_PORT);
  exit((response[3] & 0x0f) == 0 && answers > 0 ? 0 : 1);
 3dc:	52800020 	mov	w0, #0x1                   	// #1
 3e0:	14000039 	b	4c4 <main+0x10c>
  if(udp_send(QEMU_DNS, LOCAL_PORT, 53, query, sizeof(query)) < 0){
 3e4:	b0000003 	adrp	x3, 1000 <main+0xc48>
 3e8:	911c4063 	add	x3, x3, #0x710
 3ec:	52804060 	mov	w0, #0x203                 	// #515
 3f0:	72a14000 	movk	w0, #0xa00, lsl #16
 3f4:	52800384 	mov	w4, #0x1c                  	// #28
 3f8:	528006a2 	mov	w2, #0x35                  	// #53
 3fc:	5299e101 	mov	w1, #0xcf08                	// #53000
 400:	97ffffe2 	bl	388 <udp_send@plt>
 404:	36f800e0 	tbz	w0, #31, 420 <main+0x68>
    printf("netdns: send failed (is make qemu-net in use?)\n");
 408:	90000000 	adrp	x0, 0 <.plt-0x338>
 40c:	91137400 	add	x0, x0, #0x4dd
 410:	97ffffd2 	bl	358 <printf@plt>
    udp_unbind(LOCAL_PORT);
 414:	5299e100 	mov	w0, #0xcf08                	// #53000
 418:	97ffffe0 	bl	398 <udp_unbind@plt>
    exit(1);
 41c:	17fffff0 	b	3dc <main+0x24>
  printf("netdns: query sent to 10.0.2.3:53, waiting...\n");
 420:	90000000 	adrp	x0, 0 <.plt-0x338>
 424:	91143400 	add	x0, x0, #0x50d
 428:	97ffffcc 	bl	358 <printf@plt>
  n = udp_recv(LOCAL_PORT, &src, &sport, response, sizeof(response));
 42c:	9100f3e1 	add	x1, sp, #0x3c
 430:	910103e3 	add	x3, sp, #0x40
 434:	9100ebe2 	add	x2, sp, #0x3a
 438:	52804004 	mov	w4, #0x200                 	// #512
 43c:	5299e100 	mov	w0, #0xcf08                	// #53000
 440:	97ffffca 	bl	368 <udp_recv@plt>
 444:	2a0003e1 	mov	w1, w0
  if(n < 12){
 448:	71002c1f 	cmp	w0, #0xb
 44c:	540000ac 	b.gt	460 <main+0xa8>
    printf("netdns: short response len=%d\n", n);
 450:	90000000 	adrp	x0, 0 <.plt-0x338>
 454:	9114f000 	add	x0, x0, #0x53c
 458:	97ffffc0 	bl	358 <printf@plt>
    exit(1);
 45c:	17ffffe0 	b	3dc <main+0x24>
  printf("netdns: reply from %d.%d.%d.%d:%d len=%d answers=%d rcode=%d\n",
 460:	b9403fe8 	ldr	w8, [sp, #60]
 464:	2a0103e6 	mov	w6, w1
 468:	79408fe7 	ldrh	w7, [sp, #70]
 46c:	90000000 	adrp	x0, 0 <.plt-0x338>
 470:	91156c00 	add	x0, x0, #0x55b
 474:	39410fe2 	ldrb	w2, [sp, #67]
 478:	794077e5 	ldrh	w5, [sp, #58]
 47c:	5ac004e7 	rev16	w7, w7
 480:	12000c42 	and	w2, w2, #0xf
 484:	12003ce7 	and	w7, w7, #0xffff
 488:	12001d04 	and	w4, w8, #0xff
 48c:	d3483d03 	ubfx	x3, x8, #8, #8
 490:	53187d01 	lsr	w1, w8, #24
 494:	b90003e2 	str	w2, [sp]
 498:	d3505d02 	ubfx	x2, x8, #16, #8
 49c:	b9002fe7 	str	w7, [sp, #44]
 4a0:	97ffffae 	bl	358 <printf@plt>
  udp_unbind(LOCAL_PORT);
 4a4:	5299e100 	mov	w0, #0xcf08                	// #53000
 4a8:	97ffffbc 	bl	398 <udp_unbind@plt>
  exit((response[3] & 0x0f) == 0 && answers > 0 ? 0 : 1);
 4ac:	39410fe0 	ldrb	w0, [sp, #67]
 4b0:	f2400c1f 	tst	x0, #0xf
 4b4:	54fff941 	b.ne	3dc <main+0x24>  // b.any
 4b8:	b9402fe7 	ldr	w7, [sp, #44]
 4bc:	710000ff 	cmp	w7, #0x0
 4c0:	1a9f17e0 	cset	w0, eq	// eq = none
 4c4:	97ffffb9 	bl	3a8 <exit@plt>
