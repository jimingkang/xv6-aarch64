
user/_login:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000500 <.plt>:
 500:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 504:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 508:	f9451611 	ldr	x17, [x16, #2600]
 50c:	9128a210 	add	x16, x16, #0xa28
 510:	d61f0220 	br	x17
 514:	d503201f 	nop
 518:	d503201f 	nop
 51c:	d503201f 	nop

0000000000000520 <printf@plt>:
 520:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 524:	f9451a11 	ldr	x17, [x16, #2608]
 528:	9128c210 	add	x16, x16, #0xa30
 52c:	d61f0220 	br	x17

0000000000000530 <gets@plt>:
 530:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 534:	f9451e11 	ldr	x17, [x16, #2616]
 538:	9128e210 	add	x16, x16, #0xa38
 53c:	d61f0220 	br	x17

0000000000000540 <sleep_ticks@plt>:
 540:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 544:	f9452211 	ldr	x17, [x16, #2624]
 548:	91290210 	add	x16, x16, #0xa40
 54c:	d61f0220 	br	x17

0000000000000550 <chdir@plt>:
 550:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 554:	f9452611 	ldr	x17, [x16, #2632]
 558:	91292210 	add	x16, x16, #0xa48
 55c:	d61f0220 	br	x17

0000000000000560 <exec@plt>:
 560:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 564:	f9452a11 	ldr	x17, [x16, #2640]
 568:	91294210 	add	x16, x16, #0xa50
 56c:	d61f0220 	br	x17

0000000000000570 <read@plt>:
 570:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 574:	f9452e11 	ldr	x17, [x16, #2648]
 578:	91296210 	add	x16, x16, #0xa58
 57c:	d61f0220 	br	x17

0000000000000580 <strncpy@plt>:
 580:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 584:	f9453211 	ldr	x17, [x16, #2656]
 588:	91298210 	add	x16, x16, #0xa60
 58c:	d61f0220 	br	x17

0000000000000590 <tty_attach@plt>:
 590:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 594:	f9453611 	ldr	x17, [x16, #2664]
 598:	9129a210 	add	x16, x16, #0xa68
 59c:	d61f0220 	br	x17

00000000000005a0 <strcmp@plt>:
 5a0:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 5a4:	f9453a11 	ldr	x17, [x16, #2672]
 5a8:	9129c210 	add	x16, x16, #0xa70
 5ac:	d61f0220 	br	x17

00000000000005b0 <exit@plt>:
 5b0:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 5b4:	f9453e11 	ldr	x17, [x16, #2680]
 5b8:	9129e210 	add	x16, x16, #0xa78
 5bc:	d61f0220 	br	x17

00000000000005c0 <strlen@plt>:
 5c0:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 5c4:	f9454211 	ldr	x17, [x16, #2688]
 5c8:	912a0210 	add	x16, x16, #0xa80
 5cc:	d61f0220 	br	x17

00000000000005d0 <open@plt>:
 5d0:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 5d4:	f9454611 	ldr	x17, [x16, #2696]
 5d8:	912a2210 	add	x16, x16, #0xa88
 5dc:	d61f0220 	br	x17

00000000000005e0 <strchr@plt>:
 5e0:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 5e4:	f9454a11 	ldr	x17, [x16, #2704]
 5e8:	912a4210 	add	x16, x16, #0xa90
 5ec:	d61f0220 	br	x17

00000000000005f0 <close@plt>:
 5f0:	b0000010 	adrp	x16, 1000 <chomp+0x7e8>
 5f4:	f9454e11 	ldr	x17, [x16, #2712]
 5f8:	912a6210 	add	x16, x16, #0xa98
 5fc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000600 <main>:
  return -1;
}

int
main(void)
{
 600:	d10d43ff 	sub	sp, sp, #0x350
  char name[32], password[32], home[64], shell[64];

  if(tty_attach(0) < 0){
 604:	52800000 	mov	w0, #0x0                   	// #0
{
 608:	a9007bfd 	stp	x29, x30, [sp]
 60c:	910003fd 	mov	x29, sp
 610:	a90153f3 	stp	x19, x20, [sp, #16]
 614:	a9025bf5 	stp	x21, x22, [sp, #32]
 618:	a90363f7 	stp	x23, x24, [sp, #48]
 61c:	f90023f9 	str	x25, [sp, #64]
  if(tty_attach(0) < 0){
 620:	97ffffdc 	bl	590 <tty_attach@plt>
 624:	36f800c0 	tbz	w0, #31, 63c <main+0x3c>
    printf("login: cannot acquire ttyS0\n");
 628:	90000000 	adrp	x0, 0 <.plt-0x500>
 62c:	91219000 	add	x0, x0, #0x864
 630:	97ffffbc 	bl	520 <printf@plt>
      if(home[0] && chdir(home) < 0)
        chdir("/");
      exec(shell, argv);
      exec("/bin/sh", argv);
      printf("login: cannot execute %s\n", shell);
      exit(1);
 634:	52800020 	mov	w0, #0x1                   	// #1
 638:	97ffffde 	bl	5b0 <exit@plt>
    printf("\nxv6-rpi3 login: ");
 63c:	90000018 	adrp	x24, 0 <.plt-0x500>
 640:	91220718 	add	x24, x24, #0x881
      field[i+1] = p;
 644:	910263f9 	add	x25, sp, #0x98
  if(tty_attach(0) < 0){
 648:	52800077 	mov	w23, #0x3                   	// #3
    printf("\nxv6-rpi3 login: ");
 64c:	aa1803e0 	mov	x0, x24
 650:	97ffffb4 	bl	520 <printf@plt>
    gets(name, sizeof(name));
 654:	52800401 	mov	w1, #0x20                  	// #32
 658:	910163e0 	add	x0, sp, #0x58
 65c:	97ffffb5 	bl	530 <gets@plt>
    chomp(name);
 660:	910163e0 	add	x0, sp, #0x58
 664:	9400006d 	bl	818 <chomp>
    printf("Password: ");
 668:	90000000 	adrp	x0, 0 <.plt-0x500>
 66c:	91224c00 	add	x0, x0, #0x893
 670:	97ffffac 	bl	520 <printf@plt>
    gets(password, sizeof(password));
 674:	52800401 	mov	w1, #0x20                  	// #32
 678:	9101e3e0 	add	x0, sp, #0x78
 67c:	97ffffad 	bl	530 <gets@plt>
    chomp(password);
 680:	9101e3e0 	add	x0, sp, #0x78
 684:	94000065 	bl	818 <chomp>
  fd = open("/etc/passwd", O_RDONLY);
 688:	90000000 	adrp	x0, 0 <.plt-0x500>
 68c:	91227800 	add	x0, x0, #0x89e
 690:	52800001 	mov	w1, #0x0                   	// #0
 694:	97ffffcf 	bl	5d0 <open@plt>
 698:	2a0003f4 	mov	w20, w0
  if(fd < 0)
 69c:	36f80120 	tbz	w0, #31, 6c0 <main+0xc0>
    }
    printf("Login incorrect\n");
 6a0:	90000000 	adrp	x0, 0 <.plt-0x500>
 6a4:	9122a800 	add	x0, x0, #0x8aa
 6a8:	97ffff9e 	bl	520 <printf@plt>
    sleep_ticks(20);
 6ac:	52800280 	mov	w0, #0x14                  	// #20
 6b0:	97ffffa4 	bl	540 <sleep_ticks@plt>
  for(int attempt = 0; attempt < 3; attempt++){
 6b4:	710006f7 	subs	w23, w23, #0x1
 6b8:	54fffca1 	b.ne	64c <main+0x4c>  // b.any
 6bc:	17ffffde 	b	634 <main+0x34>
  n = read(fd, buf, sizeof(buf) - 1);
 6c0:	910543f5 	add	x21, sp, #0x150
 6c4:	52803fe2 	mov	w2, #0x1ff                 	// #511
 6c8:	aa1503e1 	mov	x1, x21
 6cc:	97ffffa9 	bl	570 <read@plt>
 6d0:	2a0003f3 	mov	w19, w0
  close(fd);
 6d4:	2a1403e0 	mov	w0, w20
 6d8:	97ffffc6 	bl	5f0 <close@plt>
  if(n <= 0)
 6dc:	7100027f 	cmp	w19, #0x0
 6e0:	54fffe0d 	b.le	6a0 <main+0xa0>
  for(line = buf; *line; line = end){
 6e4:	aa1503f4 	mov	x20, x21
  buf[n] = 0;
 6e8:	38334abf 	strb	wzr, [x21, w19, uxtw]
  for(line = buf; *line; line = end){
 6ec:	39400280 	ldrb	w0, [x20]
 6f0:	34fffd80 	cbz	w0, 6a0 <main+0xa0>
    end = strchr(line, '\n');
 6f4:	aa1403e0 	mov	x0, x20
 6f8:	52800141 	mov	w1, #0xa                   	// #10
 6fc:	97ffffb9 	bl	5e0 <strchr@plt>
    if(end)
 700:	b4000120 	cbz	x0, 724 <main+0x124>
      *end++ = 0;
 704:	aa0003f3 	mov	x19, x0
 708:	3800167f 	strb	wzr, [x19], #1
    if(*line == 0 || *line == '#')
 70c:	39400280 	ldrb	w0, [x20]
 710:	71008c1f 	cmp	w0, #0x23
 714:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
 718:	540000e1 	b.ne	734 <main+0x134>  // b.any
  for(line = buf; *line; line = end){
 71c:	aa1303f4 	mov	x20, x19
 720:	17fffff3 	b	6ec <main+0xec>
      end = line + strlen(line);
 724:	aa1403e0 	mov	x0, x20
 728:	97ffffa6 	bl	5c0 <strlen@plt>
 72c:	8b204293 	add	x19, x20, w0, uxtw
 730:	17fffff7 	b	70c <main+0x10c>
    char *field[7], *p = line;
 734:	aa1403e0 	mov	x0, x20
    if(*line == 0 || *line == '#')
 738:	d2800036 	mov	x22, #0x1                   	// #1
      p = strchr(p, ':');
 73c:	52800741 	mov	w1, #0x3a                  	// #58
 740:	97ffffa8 	bl	5e0 <strchr@plt>
      if(p == 0){
 744:	b4fffec0 	cbz	x0, 71c <main+0x11c>
      *p++ = 0;
 748:	3800141f 	strb	wzr, [x0], #1
      field[i+1] = p;
 74c:	f8367b20 	str	x0, [x25, x22, lsl #3]
    for(int i = 0; i < 6; i++){
 750:	910006d6 	add	x22, x22, #0x1
 754:	f1001edf 	cmp	x22, #0x7
 758:	54ffff21 	b.ne	73c <main+0x13c>  // b.any
    if(valid && strcmp(field[0], name) == 0 &&
 75c:	910163e1 	add	x1, sp, #0x58
 760:	aa1403e0 	mov	x0, x20
 764:	97ffff8f 	bl	5a0 <strcmp@plt>
 768:	35fffda0 	cbnz	w0, 71c <main+0x11c>
       strcmp(field[1], password) == 0){
 76c:	f94053e0 	ldr	x0, [sp, #160]
 770:	9101e3e1 	add	x1, sp, #0x78
 774:	97ffff8b 	bl	5a0 <strcmp@plt>
    if(valid && strcmp(field[0], name) == 0 &&
 778:	35fffd20 	cbnz	w0, 71c <main+0x11c>
      strncpy(home, field[5], 63);
 77c:	f94063e1 	ldr	x1, [sp, #192]
 780:	910343f3 	add	x19, sp, #0xd0
 784:	528007e2 	mov	w2, #0x3f                  	// #63
 788:	aa1303e0 	mov	x0, x19
 78c:	97ffff7d 	bl	580 <strncpy@plt>
      home[63] = 0;
 790:	39043fff 	strb	wzr, [sp, #271]
      strncpy(shell, field[6], 63);
 794:	f94067e1 	ldr	x1, [sp, #200]
 798:	528007e2 	mov	w2, #0x3f                  	// #63
 79c:	910443e0 	add	x0, sp, #0x110
 7a0:	97ffff78 	bl	580 <strncpy@plt>
      shell[63] = 0;
 7a4:	39053fff 	strb	wzr, [sp, #335]
      char *argv[] = { "-sh", home, 0 };
 7a8:	90000000 	adrp	x0, 0 <.plt-0x500>
 7ac:	9122ec00 	add	x0, x0, #0x8bb
      printf("Welcome %s\n", name);
 7b0:	910163e1 	add	x1, sp, #0x58
      char *argv[] = { "-sh", home, 0 };
 7b4:	a9154fe0 	stp	x0, x19, [sp, #336]
      printf("Welcome %s\n", name);
 7b8:	90000000 	adrp	x0, 0 <.plt-0x500>
 7bc:	9122fc00 	add	x0, x0, #0x8bf
      char *argv[] = { "-sh", home, 0 };
 7c0:	f900b3ff 	str	xzr, [sp, #352]
      printf("Welcome %s\n", name);
 7c4:	97ffff57 	bl	520 <printf@plt>
      if(home[0] && chdir(home) < 0)
 7c8:	394343e0 	ldrb	w0, [sp, #208]
 7cc:	340000e0 	cbz	w0, 7e8 <main+0x1e8>
 7d0:	aa1303e0 	mov	x0, x19
 7d4:	97ffff5f 	bl	550 <chdir@plt>
 7d8:	36f80080 	tbz	w0, #31, 7e8 <main+0x1e8>
        chdir("/");
 7dc:	90000000 	adrp	x0, 0 <.plt-0x500>
 7e0:	91232c00 	add	x0, x0, #0x8cb
 7e4:	97ffff5b 	bl	550 <chdir@plt>
      exec(shell, argv);
 7e8:	aa1503e1 	mov	x1, x21
 7ec:	910443e0 	add	x0, sp, #0x110
 7f0:	97ffff5c 	bl	560 <exec@plt>
      exec("/bin/sh", argv);
 7f4:	aa1503e1 	mov	x1, x21
 7f8:	90000000 	adrp	x0, 0 <.plt-0x500>
 7fc:	91233400 	add	x0, x0, #0x8cd
 800:	97ffff58 	bl	560 <exec@plt>
      printf("login: cannot execute %s\n", shell);
 804:	910443e1 	add	x1, sp, #0x110
 808:	90000000 	adrp	x0, 0 <.plt-0x500>
 80c:	91235400 	add	x0, x0, #0x8d5
 810:	97ffff44 	bl	520 <printf@plt>
 814:	17ffff88 	b	634 <main+0x34>

0000000000000818 <chomp>:
{
 818:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 81c:	910003fd 	mov	x29, sp
 820:	f9000bf3 	str	x19, [sp, #16]
 824:	aa0003f3 	mov	x19, x0
  int n = strlen(s);
 828:	97ffff66 	bl	5c0 <strlen@plt>
  while(n > 0 && (s[n-1] == '\n' || s[n-1] == '\r'))
 82c:	93407c00 	sxtw	x0, w0
 830:	d1000661 	sub	x1, x19, #0x1
 834:	7100001f 	cmp	w0, #0x0
 838:	540000ad 	b.le	84c <chomp+0x34>
 83c:	38606822 	ldrb	w2, [x1, x0]
 840:	7100285f 	cmp	w2, #0xa
 844:	7a4d1844 	ccmp	w2, #0xd, #0x4, ne	// ne = any
 848:	54000080 	b.eq	858 <chomp+0x40>  // b.none
}
 84c:	f9400bf3 	ldr	x19, [sp, #16]
 850:	a8c27bfd 	ldp	x29, x30, [sp], #32
 854:	d65f03c0 	ret
    s[--n] = 0;
 858:	3820683f 	strb	wzr, [x1, x0]
 85c:	d1000400 	sub	x0, x0, #0x1
 860:	17fffff5 	b	834 <chomp+0x1c>
