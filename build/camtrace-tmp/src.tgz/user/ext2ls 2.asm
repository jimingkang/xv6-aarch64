
user/_ext2ls:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002b8 <.plt>:
 2b8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2bc:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2c0:	f942a611 	ldr	x17, [x16, #1352]
 2c4:	91152210 	add	x16, x16, #0x548
 2c8:	d61f0220 	br	x17
 2cc:	d503201f 	nop
 2d0:	d503201f 	nop
 2d4:	d503201f 	nop

00000000000002d8 <printf@plt>:
 2d8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2dc:	f942aa11 	ldr	x17, [x16, #1360]
 2e0:	91154210 	add	x16, x16, #0x550
 2e4:	d61f0220 	br	x17

00000000000002e8 <ext2readdir@plt>:
 2e8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2ec:	f942ae11 	ldr	x17, [x16, #1368]
 2f0:	91156210 	add	x16, x16, #0x558
 2f4:	d61f0220 	br	x17

00000000000002f8 <fprintf@plt>:
 2f8:	b0000010 	adrp	x16, 1000 <main+0xce8>
 2fc:	f942b211 	ldr	x17, [x16, #1376]
 300:	91158210 	add	x16, x16, #0x560
 304:	d61f0220 	br	x17

0000000000000308 <exit@plt>:
 308:	b0000010 	adrp	x16, 1000 <main+0xce8>
 30c:	f942b611 	ldr	x17, [x16, #1384]
 310:	9115a210 	add	x16, x16, #0x568
 314:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000318 <main>:
#include <uapi/ext2.h>
#include "user/user.h"

int
main(int argc, char **argv)
{
 318:	a9aa7bfd 	stp	x29, x30, [sp, #-352]!
 31c:	910003fd 	mov	x29, sp
 320:	a90153f3 	stp	x19, x20, [sp, #16]
 324:	a9025bf5 	stp	x21, x22, [sp, #32]
 328:	f9001bf7 	str	x23, [sp, #48]
  struct ext2_user_dirent de;
  char *path = argc > 1 ? argv[1] : "/";
 32c:	7100041f 	cmp	w0, #0x1
 330:	5400026d 	b.le	37c <main+0x64>
 334:	f9400433 	ldr	x19, [x1, #8]
  int i, r;
  for(i = 0; ; i++){
    r = ext2readdir(path, i, &de);
    if(r < 0){ fprintf(2, "ext2ls: cannot read %s (not mounted or not a directory)\n", path); exit(1); }
    if(r == 0) break;
    printf("%s%c %l bytes inode %d\n", de.name,
 338:	90000015 	adrp	x21, 0 <.plt-0x2b8>
 33c:	910fceb5 	add	x21, x21, #0x3f3
  for(i = 0; ; i++){
 340:	52800014 	mov	w20, #0x0                   	// #0
    printf("%s%c %l bytes inode %d\n", de.name,
 344:	52800417 	mov	w23, #0x20                  	// #32
 348:	528005f6 	mov	w22, #0x2f                  	// #47
    r = ext2readdir(path, i, &de);
 34c:	910123e2 	add	x2, sp, #0x48
 350:	2a1403e1 	mov	w1, w20
 354:	aa1303e0 	mov	x0, x19
 358:	97ffffe4 	bl	2e8 <ext2readdir@plt>
    if(r < 0){ fprintf(2, "ext2ls: cannot read %s (not mounted or not a directory)\n", path); exit(1); }
 35c:	36f80160 	tbz	w0, #31, 388 <main+0x70>
 360:	aa1303e2 	mov	x2, x19
 364:	90000001 	adrp	x1, 0 <.plt-0x2b8>
 368:	910ee821 	add	x1, x1, #0x3ba
 36c:	52800040 	mov	w0, #0x2                   	// #2
 370:	97ffffe2 	bl	2f8 <fprintf@plt>
 374:	52800020 	mov	w0, #0x1                   	// #1
           (de.mode & 0xf000) == 0x4000 ? '/' : ' ', de.size, de.inode);
  }
  exit(0);
 378:	97ffffe4 	bl	308 <exit@plt>
  char *path = argc > 1 ? argv[1] : "/";
 37c:	90000013 	adrp	x19, 0 <.plt-0x2b8>
 380:	910ee273 	add	x19, x19, #0x3b8
 384:	17ffffed 	b	338 <main+0x20>
    if(r == 0) break;
 388:	34ffff80 	cbz	w0, 378 <main+0x60>
    printf("%s%c %l bytes inode %d\n", de.name,
 38c:	7940b3e0 	ldrh	w0, [sp, #88]
 390:	91016fe1 	add	x1, sp, #0x5b
 394:	f9402be3 	ldr	x3, [sp, #80]
 398:	12140c00 	and	w0, w0, #0xf000
 39c:	b9404be4 	ldr	w4, [sp, #72]
 3a0:	7140101f 	cmp	w0, #0x4, lsl #12
 3a4:	1a9612e2 	csel	w2, w23, w22, ne	// ne = any
 3a8:	aa1503e0 	mov	x0, x21
  for(i = 0; ; i++){
 3ac:	11000694 	add	w20, w20, #0x1
    printf("%s%c %l bytes inode %d\n", de.name,
 3b0:	97ffffca 	bl	2d8 <printf@plt>
    r = ext2readdir(path, i, &de);
 3b4:	17ffffe6 	b	34c <main+0x34>
