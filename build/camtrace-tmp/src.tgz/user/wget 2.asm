
user/_wget:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000798 <.plt>:
 798:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 79c:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 7a0:	f9409e11 	ldr	x17, [x16, #312]
 7a4:	9104e210 	add	x16, x16, #0x138
 7a8:	d61f0220 	br	x17
 7ac:	d503201f 	nop
 7b0:	d503201f 	nop
 7b4:	d503201f 	nop

00000000000007b8 <strcpy@plt>:
 7b8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 7bc:	f940a211 	ldr	x17, [x16, #320]
 7c0:	91050210 	add	x16, x16, #0x140
 7c4:	d61f0220 	br	x17

00000000000007c8 <connect@plt>:
 7c8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 7cc:	f940a611 	ldr	x17, [x16, #328]
 7d0:	91052210 	add	x16, x16, #0x148
 7d4:	d61f0220 	br	x17

00000000000007d8 <memmove@plt>:
 7d8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 7dc:	f940aa11 	ldr	x17, [x16, #336]
 7e0:	91054210 	add	x16, x16, #0x150
 7e4:	d61f0220 	br	x17

00000000000007e8 <memcpy@plt>:
 7e8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 7ec:	f940ae11 	ldr	x17, [x16, #344]
 7f0:	91056210 	add	x16, x16, #0x158
 7f4:	d61f0220 	br	x17

00000000000007f8 <socket@plt>:
 7f8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 7fc:	f940b211 	ldr	x17, [x16, #352]
 800:	91058210 	add	x16, x16, #0x160
 804:	d61f0220 	br	x17

0000000000000808 <write@plt>:
 808:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 80c:	f940b611 	ldr	x17, [x16, #360]
 810:	9105a210 	add	x16, x16, #0x168
 814:	d61f0220 	br	x17

0000000000000818 <fprintf@plt>:
 818:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 81c:	f940ba11 	ldr	x17, [x16, #368]
 820:	9105c210 	add	x16, x16, #0x170
 824:	d61f0220 	br	x17

0000000000000828 <strcat@plt>:
 828:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 82c:	f940be11 	ldr	x17, [x16, #376]
 830:	9105e210 	add	x16, x16, #0x178
 834:	d61f0220 	br	x17

0000000000000838 <net_dns@plt>:
 838:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 83c:	f940c211 	ldr	x17, [x16, #384]
 840:	91060210 	add	x16, x16, #0x180
 844:	d61f0220 	br	x17

0000000000000848 <read@plt>:
 848:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 84c:	f940c611 	ldr	x17, [x16, #392]
 850:	91062210 	add	x16, x16, #0x188
 854:	d61f0220 	br	x17

0000000000000858 <strncpy@plt>:
 858:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 85c:	f940ca11 	ldr	x17, [x16, #400]
 860:	91064210 	add	x16, x16, #0x190
 864:	d61f0220 	br	x17

0000000000000868 <memset@plt>:
 868:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 86c:	f940ce11 	ldr	x17, [x16, #408]
 870:	91066210 	add	x16, x16, #0x198
 874:	d61f0220 	br	x17

0000000000000878 <udp_bind@plt>:
 878:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 87c:	f940d211 	ldr	x17, [x16, #416]
 880:	91068210 	add	x16, x16, #0x1a0
 884:	d61f0220 	br	x17

0000000000000888 <strcmp@plt>:
 888:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 88c:	f940d611 	ldr	x17, [x16, #424]
 890:	9106a210 	add	x16, x16, #0x1a8
 894:	d61f0220 	br	x17

0000000000000898 <udp_recv_timeout@plt>:
 898:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 89c:	f940da11 	ldr	x17, [x16, #432]
 8a0:	9106c210 	add	x16, x16, #0x1b0
 8a4:	d61f0220 	br	x17

00000000000008a8 <udp_send@plt>:
 8a8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 8ac:	f940de11 	ldr	x17, [x16, #440]
 8b0:	9106e210 	add	x16, x16, #0x1b8
 8b4:	d61f0220 	br	x17

00000000000008b8 <udp_unbind@plt>:
 8b8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 8bc:	f940e211 	ldr	x17, [x16, #448]
 8c0:	91070210 	add	x16, x16, #0x1c0
 8c4:	d61f0220 	br	x17

00000000000008c8 <clock_us@plt>:
 8c8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 8cc:	f940e611 	ldr	x17, [x16, #456]
 8d0:	91072210 	add	x16, x16, #0x1c8
 8d4:	d61f0220 	br	x17

00000000000008d8 <exit@plt>:
 8d8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 8dc:	f940ea11 	ldr	x17, [x16, #464]
 8e0:	91074210 	add	x16, x16, #0x1d0
 8e4:	d61f0220 	br	x17

00000000000008e8 <atoi@plt>:
 8e8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 8ec:	f940ee11 	ldr	x17, [x16, #472]
 8f0:	91076210 	add	x16, x16, #0x1d8
 8f4:	d61f0220 	br	x17

00000000000008f8 <strlen@plt>:
 8f8:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 8fc:	f940f211 	ldr	x17, [x16, #480]
 900:	91078210 	add	x16, x16, #0x1e0
 904:	d61f0220 	br	x17

0000000000000908 <open@plt>:
 908:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 90c:	f940f611 	ldr	x17, [x16, #488]
 910:	9107a210 	add	x16, x16, #0x1e8
 914:	d61f0220 	br	x17

0000000000000918 <strchr@plt>:
 918:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 91c:	f940fa11 	ldr	x17, [x16, #496]
 920:	9107c210 	add	x16, x16, #0x1f0
 924:	d61f0220 	br	x17

0000000000000928 <close@plt>:
 928:	d0000010 	adrp	x16, 2000 <_DYNAMIC>
 92c:	f940fe11 	ldr	x17, [x16, #504]
 930:	9107e210 	add	x16, x16, #0x1f8
 934:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000938 <main>:
  exit(1);
}

int
main(int argc, char *argv[])
{
     938:	d12dc3ff 	sub	sp, sp, #0xb70
     93c:	a9007bfd 	stp	x29, x30, [sp]
     940:	910003fd 	mov	x29, sp
     944:	a9025bf5 	stp	x21, x22, [sp, #32]
  const char *outname = 0, *src = 0;
  char namebuf[128];
  int r;

  for(int i = 1; i < argc; i++){
    if(strcmp(argv[i], "-q") == 0)
     948:	b0000016 	adrp	x22, 1000 <main+0x6c8>
     94c:	911f72d6 	add	x22, x22, #0x7dc
{
     950:	aa0103f5 	mov	x21, x1
     954:	a90363f7 	stp	x23, x24, [sp, #48]
      quiet = 1;
    else if(strcmp(argv[i], "-O") == 0 && i + 1 < argc)
     958:	b0000017 	adrp	x23, 1000 <main+0x6c8>
     95c:	911f7ef7 	add	x23, x23, #0x7df
{
     960:	a9046bf9 	stp	x25, x26, [sp, #64]
     964:	2a0003f9 	mov	w25, w0
  const char *outname = 0, *src = 0;
     968:	d280001a 	mov	x26, #0x0                   	// #0
{
     96c:	a90153f3 	stp	x19, x20, [sp, #16]
  for(int i = 1; i < argc; i++){
     970:	52800033 	mov	w19, #0x1                   	// #1
  const char *outname = 0, *src = 0;
     974:	d2800014 	mov	x20, #0x0                   	// #0
{
     978:	a90573fb 	stp	x27, x28, [sp, #80]
      quiet = 1;
     97c:	d000001b 	adrp	x27, 2000 <_DYNAMIC>
  for(int i = 1; i < argc; i++){
     980:	6b19027f 	cmp	w19, w25
     984:	5400022b 	b.lt	9c8 <main+0x90>  // b.tstop
    else if(src == 0)
      src = argv[i];
    else
      usage();
  }
  if(src == 0 || parse_url(src, &u) < 0)
     988:	b4000554 	cbz	x20, a30 <main+0xf8>
     98c:	910d03f7 	add	x23, sp, #0x340
     990:	aa1403e0 	mov	x0, x20
     994:	aa1703e1 	mov	x1, x23
     998:	940002e0 	bl	1518 <parse_url>
     99c:	3100041f 	cmn	w0, #0x1
     9a0:	54000480 	b.eq	a30 <main+0xf8>  // b.none
  if(!quiet){
     9a4:	d000001c 	adrp	x28, 2000 <_DYNAMIC>
     9a8:	91080398 	add	x24, x28, #0x200
  if(src == 0 || parse_url(src, &u) < 0)
     9ac:	528000c0 	mov	w0, #0x6                   	// #6
      n = n * 10 + (*s++ - '0');
     9b0:	5280015b 	mov	w27, #0xa                   	// #10
  if(src == 0 || parse_url(src, &u) < 0)
     9b4:	b9006be0 	str	w0, [sp, #104]
    usage();

  for(int hops = 0; hops <= MAXREDIR; hops++){
    if(outname == 0){
     9b8:	b500067a 	cbnz	x26, a84 <main+0x14c>
  for(const char *p = path; *p && *p != '?'; p++)
     9bc:	910f13e0 	add	x0, sp, #0x3c4
  const char *b = path;
     9c0:	aa0003e3 	mov	x3, x0
     9c4:	14000022 	b	a4c <main+0x114>
    if(strcmp(argv[i], "-q") == 0)
     9c8:	937d7e78 	sbfiz	x24, x19, #3, #32
     9cc:	8b33cebc 	add	x28, x21, w19, sxtw #3
     9d0:	aa1603e1 	mov	x1, x22
     9d4:	f8786aa0 	ldr	x0, [x21, x24]
     9d8:	97ffffac 	bl	888 <strcmp@plt>
     9dc:	350000a0 	cbnz	w0, 9f0 <main+0xb8>
      quiet = 1;
     9e0:	52800020 	mov	w0, #0x1                   	// #1
     9e4:	b9020360 	str	w0, [x27, #512]
  for(int i = 1; i < argc; i++){
     9e8:	11000673 	add	w19, w19, #0x1
     9ec:	17ffffe5 	b	980 <main+0x48>
    else if(strcmp(argv[i], "-O") == 0 && i + 1 < argc)
     9f0:	f8786aa0 	ldr	x0, [x21, x24]
     9f4:	aa1703e1 	mov	x1, x23
     9f8:	97ffffa4 	bl	888 <strcmp@plt>
     9fc:	350000e0 	cbnz	w0, a18 <main+0xe0>
     a00:	11000660 	add	w0, w19, #0x1
     a04:	6b19001f 	cmp	w0, w25
     a08:	5400008a 	b.ge	a18 <main+0xe0>  // b.tcont
      outname = argv[++i];
     a0c:	f940079a 	ldr	x26, [x28, #8]
     a10:	2a0003f3 	mov	w19, w0
     a14:	17fffff5 	b	9e8 <main+0xb0>
    else if(argv[i][0] == '-' && argv[i][1])
     a18:	f8786aa0 	ldr	x0, [x21, x24]
     a1c:	39400001 	ldrb	w1, [x0]
     a20:	7100b43f 	cmp	w1, #0x2d
     a24:	54000081 	b.ne	a34 <main+0xfc>  // b.any
     a28:	39400401 	ldrb	w1, [x0, #1]
     a2c:	34000041 	cbz	w1, a34 <main+0xfc>
      usage();
     a30:	94000284 	bl	1440 <usage>
    else if(src == 0)
     a34:	b5fffff4 	cbnz	x20, a30 <main+0xf8>
      src = argv[i];
     a38:	aa0003f4 	mov	x20, x0
     a3c:	17ffffeb 	b	9e8 <main+0xb0>
      b = p + 1;
     a40:	91000400 	add	x0, x0, #0x1
     a44:	7100bc3f 	cmp	w1, #0x2f
     a48:	9a801063 	csel	x3, x3, x0, ne	// ne = any
  for(const char *p = path; *p && *p != '?'; p++)
     a4c:	39400001 	ldrb	w1, [x0]
     a50:	7100fc3f 	cmp	w1, #0x3f
     a54:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
     a58:	54ffff41 	b.ne	a40 <main+0x108>  // b.any
  if(*b == 0 || *b == '?')
     a5c:	39400060 	ldrb	w0, [x3]
    return "index.html";
     a60:	b0000001 	adrp	x1, 1000 <main+0x6c8>
      strncpy(namebuf, default_name(u.path), sizeof(namebuf) - 1);
     a64:	911f4421 	add	x1, x1, #0x7d1
     a68:	52800fe2 	mov	w2, #0x7f                  	// #127
  if(*b == 0 || *b == '?')
     a6c:	7100fc1f 	cmp	w0, #0x3f
    return "index.html";
     a70:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
      strncpy(namebuf, default_name(u.path), sizeof(namebuf) - 1);
     a74:	910303e0 	add	x0, sp, #0xc0
     a78:	9a830021 	csel	x1, x1, x3, eq	// eq = none
     a7c:	97ffff77 	bl	858 <strncpy@plt>
      namebuf[sizeof(namebuf) - 1] = 0;
     a80:	3904ffff 	strb	wzr, [sp, #319]
    int n = 0, digits = 0;
     a84:	aa1703e1 	mov	x1, x23
     a88:	52800083 	mov	w3, #0x4                   	// #4
  uint32 v = 0;
     a8c:	52800013 	mov	w19, #0x0                   	// #0
    return "index.html";
     a90:	d2800000 	mov	x0, #0x0                   	// #0
    int n = 0, digits = 0;
     a94:	52800002 	mov	w2, #0x0                   	// #0
     a98:	14000003 	b	aa4 <main+0x16c>
      n = n * 10 + (*s++ - '0');
     a9c:	1b1b1442 	madd	w2, w2, w27, w5
    while(*s >= '0' && *s <= '9'){
     aa0:	91000400 	add	x0, x0, #0x1
     aa4:	38606824 	ldrb	w4, [x1, x0]
     aa8:	5100c085 	sub	w5, w4, #0x30
     aac:	12001ca6 	and	w6, w5, #0xff
     ab0:	710024df 	cmp	w6, #0x9
     ab4:	54ffff49 	b.ls	a9c <main+0x164>  // b.plast
    if(digits == 0 || n > 255)
     ab8:	7103fc5f 	cmp	w2, #0xff
     abc:	7a40d804 	ccmp	w0, #0x0, #0x4, le
     ac0:	540000a0 	b.eq	ad4 <main+0x19c>  // b.none
    v = (v << 8) | n;
     ac4:	2a132053 	orr	w19, w2, w19, lsl #8
    if(part < 3 && *s++ != '.')
     ac8:	71000463 	subs	w3, w3, #0x1
     acc:	54000141 	b.ne	af4 <main+0x1bc>  // b.any
  if(*s)
     ad0:	34001844 	cbz	w4, dd8 <main+0x4a0>
  if((server = net_dns()) == 0){
     ad4:	97ffff59 	bl	838 <net_dns@plt>
     ad8:	b90073e0 	str	w0, [sp, #112]
     adc:	35000160 	cbnz	w0, b08 <main+0x1d0>
    fprintf(2, "wget: no DNS server (run dhcp first?)\n");
     ae0:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     ae4:	911f8821 	add	x1, x1, #0x7e2
    fprintf(2, "wget: socket failed\n");
     ae8:	52800040 	mov	w0, #0x2                   	// #2
     aec:	97ffff4b 	bl	818 <fprintf@plt>
    }
    r = fetch(&u, outname ? outname : namebuf);
    if(r == 0)
      exit(0);
    if(r < 0)
     af0:	1400002a 	b	b98 <main+0x260>
    if(part < 3 && *s++ != '.')
     af4:	7100b89f 	cmp	w4, #0x2e
     af8:	54fffee1 	b.ne	ad4 <main+0x19c>  // b.any
     afc:	8b000021 	add	x1, x1, x0
     b00:	91000421 	add	x1, x1, #0x1
  for(int part = 0; part < 4; part++){
     b04:	17ffffe3 	b	a90 <main+0x158>
  id = (uint16)(clock_us() & 0xffff);
     b08:	97ffff70 	bl	8c8 <clock_us@plt>
  memset(q, 0, 12);
     b0c:	911723f3 	add	x19, sp, #0x5c8
  id = (uint16)(clock_us() & 0xffff);
     b10:	aa0003f4 	mov	x20, x0
  memset(q, 0, 12);
     b14:	52800182 	mov	w2, #0xc                   	// #12
     b18:	aa1303e0 	mov	x0, x19
     b1c:	52800001 	mov	w1, #0x0                   	// #0
  for(const char *p = host; *p; ){
     b20:	aa1703f6 	mov	x22, x23
  memset(q, 0, 12);
     b24:	97ffff51 	bl	868 <memset@plt>
  q[2] = 0x01;                 // RD: recursion desired
     b28:	52800020 	mov	w0, #0x1                   	// #1
  q[0] = id >> 8; q[1] = id;
     b2c:	5ac00694 	rev16	w20, w20
  qlen = 12;
     b30:	52800195 	mov	w21, #0xc                   	// #12
  q[0] = id >> 8; q[1] = id;
     b34:	790b93f4 	strh	w20, [sp, #1480]
  q[2] = 0x01;                 // RD: recursion desired
     b38:	39172be0 	strb	w0, [sp, #1482]
  q[5] = 1;                    // QDCOUNT = 1
     b3c:	391737e0 	strb	w0, [sp, #1485]
  for(const char *p = host; *p; ){
     b40:	394002c0 	ldrb	w0, [x22]
     b44:	93407ea1 	sxtw	x1, w21
     b48:	f9003fe1 	str	x1, [sp, #120]
     b4c:	110006b4 	add	w20, w21, #0x1
     b50:	35000280 	cbnz	w0, ba0 <main+0x268>
  q[qlen++] = 0; q[qlen++] = 1;   // QTYPE  A
     b54:	11000aa0 	add	w0, w21, #0x2
  q[qlen++] = 0;
     b58:	38216a7f 	strb	wzr, [x19, x1]
  q[qlen++] = 0; q[qlen++] = 1;   // QTYPE  A
     b5c:	3834ca7f 	strb	wzr, [x19, w20, sxtw]
     b60:	52800021 	mov	w1, #0x1                   	// #1
     b64:	3820ca61 	strb	w1, [x19, w0, sxtw]
     b68:	11000ea0 	add	w0, w21, #0x3
  q[qlen++] = 0; q[qlen++] = 1;   // QCLASS IN
     b6c:	3820ca7f 	strb	wzr, [x19, w0, sxtw]
     b70:	110012a0 	add	w0, w21, #0x4
     b74:	3820ca61 	strb	w1, [x19, w0, sxtw]
  if(udp_bind(DNS_PORT_LOCAL) < 0){
     b78:	5299e7a0 	mov	w0, #0xcf3d                	// #53053
     b7c:	97ffff3f 	bl	878 <udp_bind@plt>
     b80:	36f80460 	tbz	w0, #31, c0c <main+0x2d4>
    fprintf(2, "wget: cannot bind UDP %d\n", DNS_PORT_LOCAL);
     b84:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     b88:	91202421 	add	x1, x1, #0x809
     b8c:	5299e7a2 	mov	w2, #0xcf3d                	// #53053
     b90:	52800040 	mov	w0, #0x2                   	// #2
     b94:	97ffff21 	bl	818 <fprintf@plt>
      exit(1);
     b98:	52800020 	mov	w0, #0x1                   	// #1
     b9c:	14000208 	b	13bc <main+0xa84>
    const char *dot = strchr(p, '.');
     ba0:	aa1603e0 	mov	x0, x22
     ba4:	528005c1 	mov	w1, #0x2e                  	// #46
     ba8:	97ffff5c 	bl	918 <strchr@plt>
    int len = dot ? dot - p : (int)strlen(p);
     bac:	b4000280 	cbz	x0, bfc <main+0x2c4>
     bb0:	4b160019 	sub	w25, w0, w22
    if(len == 0 || len > 63 || qlen + len + 6 > (int)sizeof(q))
     bb4:	7100ff3f 	cmp	w25, #0x3f
     bb8:	7a40db24 	ccmp	w25, #0x0, #0x4, le
     bbc:	54fffee0 	b.eq	b98 <main+0x260>  // b.none
     bc0:	0b150324 	add	w4, w25, w21
     bc4:	7104989f 	cmp	w4, #0x126
     bc8:	54fffe8c 	b.gt	b98 <main+0x260>
    q[qlen++] = len;
     bcc:	f9403fe0 	ldr	x0, [sp, #120]
    memmove(q + qlen, p, len);
     bd0:	aa1603e1 	mov	x1, x22
    p += len;
     bd4:	8b39c2d6 	add	x22, x22, w25, sxtw
    memmove(q + qlen, p, len);
     bd8:	2a1903e2 	mov	w2, w25
    qlen += len;
     bdc:	0b140335 	add	w21, w25, w20
    q[qlen++] = len;
     be0:	38206a79 	strb	w25, [x19, x0]
    memmove(q + qlen, p, len);
     be4:	8b34c260 	add	x0, x19, w20, sxtw
     be8:	97fffefc 	bl	7d8 <memmove@plt>
    if(*p == '.')
     bec:	394002c0 	ldrb	w0, [x22]
      p++;
     bf0:	7100b81f 	cmp	w0, #0x2e
     bf4:	9a9616d6 	cinc	x22, x22, eq	// eq = none
     bf8:	17ffffd2 	b	b40 <main+0x208>
    int len = dot ? dot - p : (int)strlen(p);
     bfc:	aa1603e0 	mov	x0, x22
     c00:	97ffff3e 	bl	8f8 <strlen@plt>
     c04:	2a0003f9 	mov	w25, w0
     c08:	17ffffeb 	b	bb4 <main+0x27c>
  q[qlen++] = 0; q[qlen++] = 1;   // QCLASS IN
     c0c:	110016b4 	add	w20, w21, #0x5
     c10:	52800076 	mov	w22, #0x3                   	// #3
    if(udp_send(server, DNS_PORT_LOCAL, 53, q, qlen) < 0)
     c14:	b94073e0 	ldr	w0, [sp, #112]
     c18:	2a1403e4 	mov	w4, w20
     c1c:	aa1303e3 	mov	x3, x19
     c20:	528006a2 	mov	w2, #0x35                  	// #53
     c24:	5299e7a1 	mov	w1, #0xcf3d                	// #53053
     c28:	97ffff20 	bl	8a8 <udp_send@plt>
     c2c:	37f80260 	tbnz	w0, #31, c78 <main+0x340>
    n = udp_recv_timeout(DNS_PORT_LOCAL, &src, &sport, r, sizeof(r),
     c30:	912143e3 	add	x3, sp, #0x850
     c34:	910263e2 	add	x2, sp, #0x98
     c38:	910503e1 	add	x1, sp, #0x140
     c3c:	52800285 	mov	w5, #0x14                  	// #20
     c40:	52804004 	mov	w4, #0x200                 	// #512
     c44:	5299e7a0 	mov	w0, #0xcf3d                	// #53053
     c48:	97ffff14 	bl	898 <udp_recv_timeout@plt>
     c4c:	2a0003f9 	mov	w25, w0
    if(n >= 12 && r[0] == q[0] && r[1] == q[1])
     c50:	71002c1f 	cmp	w0, #0xb
     c54:	5400012d 	b.le	c78 <main+0x340>
     c58:	396143e1 	ldrb	w1, [sp, #2128]
     c5c:	395723e0 	ldrb	w0, [sp, #1480]
     c60:	6b00003f 	cmp	w1, w0
     c64:	540000a1 	b.ne	c78 <main+0x340>  // b.any
     c68:	396147e1 	ldrb	w1, [sp, #2129]
     c6c:	395727e0 	ldrb	w0, [sp, #1481]
     c70:	6b00003f 	cmp	w1, w0
     c74:	54000080 	b.eq	c84 <main+0x34c>  // b.none
  for(attempt = 0; attempt < 3; attempt++){
     c78:	710006d6 	subs	w22, w22, #0x1
     c7c:	54fffcc1 	b.ne	c14 <main+0x2dc>  // b.any
     c80:	12800019 	mov	w25, #0xffffffff            	// #-1
  udp_unbind(DNS_PORT_LOCAL);
     c84:	5299e7a0 	mov	w0, #0xcf3d                	// #53053
     c88:	97ffff0c 	bl	8b8 <udp_unbind@plt>
  if(n < 12 || (r[3] & 0x0f) != 0){
     c8c:	71002f3f 	cmp	w25, #0xb
     c90:	5400008d 	b.le	ca0 <main+0x368>
     c94:	39614fe0 	ldrb	w0, [sp, #2131]
     c98:	f2400c1f 	tst	x0, #0xf
     c9c:	540000e0 	b.eq	cb8 <main+0x380>  // b.none
    fprintf(2, "wget: cannot resolve %s\n", host);
     ca0:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     ca4:	91208c21 	add	x1, x1, #0x823
  fprintf(2, "wget: no A record for %s\n", host);
     ca8:	aa1703e2 	mov	x2, x23
     cac:	52800040 	mov	w0, #0x2                   	// #2
     cb0:	97fffeda 	bl	818 <fprintf@plt>
  return -1;
     cb4:	17ffffb9 	b	b98 <main+0x260>
  int qd = (r[4] << 8) | r[5];
     cb8:	7950abe2 	ldrh	w2, [sp, #2132]
    while(pos < n && r[pos] != 0){
     cbc:	912143e5 	add	x5, sp, #0x850
     cc0:	7950afe3 	ldrh	w3, [sp, #2134]
  for(int i = 0; i < qd; i++){
     cc4:	52800000 	mov	w0, #0x0                   	// #0
     cc8:	5ac00442 	rev16	w2, w2
  int pos = 12;
     ccc:	52800181 	mov	w1, #0xc                   	// #12
     cd0:	5ac00463 	rev16	w3, w3
     cd4:	12003c42 	and	w2, w2, #0xffff
  int an = (r[6] << 8) | r[7];
     cd8:	12003c63 	and	w3, w3, #0xffff
  for(int i = 0; i < qd; i++){
     cdc:	6b00005f 	cmp	w2, w0
     ce0:	5400016c 	b.gt	d0c <main+0x3d4>
      if((r[pos] & 0xc0) == 0xc0){ pos += 2; break; }
     ce4:	912143e2 	add	x2, sp, #0x850
  for(int i = 0; i < an && pos < n; i++){
     ce8:	52800005 	mov	w5, #0x0                   	// #0
     cec:	6b05007f 	cmp	w3, w5
     cf0:	7a41c324 	ccmp	w25, w1, #0x4, gt
     cf4:	5400030c 	b.gt	d54 <main+0x41c>
  fprintf(2, "wget: no A record for %s\n", host);
     cf8:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     cfc:	9120f021 	add	x1, x1, #0x83c
     d00:	17ffffea 	b	ca8 <main+0x370>
      pos += r[pos] + 1;
     d04:	11000484 	add	w4, w4, #0x1
     d08:	0b240021 	add	w1, w1, w4, uxtb
    while(pos < n && r[pos] != 0){
     d0c:	6b01033f 	cmp	w25, w1
     d10:	540000ed 	b.le	d2c <main+0x3f4>
     d14:	3861c8a4 	ldrb	w4, [x5, w1, sxtw]
     d18:	340000a4 	cbz	w4, d2c <main+0x3f4>
      if((r[pos] & 0xc0) == 0xc0){ pos++; break; }
     d1c:	121a0486 	and	w6, w4, #0xc0
     d20:	710300df 	cmp	w6, #0xc0
     d24:	54ffff01 	b.ne	d04 <main+0x3cc>  // b.any
     d28:	11000421 	add	w1, w1, #0x1
    pos += 5;
     d2c:	11001421 	add	w1, w1, #0x5
  for(int i = 0; i < qd; i++){
     d30:	11000400 	add	w0, w0, #0x1
     d34:	17ffffea 	b	cdc <main+0x3a4>
      if(r[pos] == 0){ pos++; break; }
     d38:	35000064 	cbnz	w4, d44 <main+0x40c>
     d3c:	11000421 	add	w1, w1, #0x1
     d40:	1400000a 	b	d68 <main+0x430>
      pos += r[pos] + 1;
     d44:	11000484 	add	w4, w4, #0x1
     d48:	0b240021 	add	w1, w1, w4, uxtb
    while(pos < n){
     d4c:	6b01033f 	cmp	w25, w1
     d50:	540000cd 	b.le	d68 <main+0x430>
      if((r[pos] & 0xc0) == 0xc0){ pos += 2; break; }
     d54:	3861c844 	ldrb	w4, [x2, w1, sxtw]
     d58:	121a0480 	and	w0, w4, #0xc0
     d5c:	7103001f 	cmp	w0, #0xc0
     d60:	54fffec1 	b.ne	d38 <main+0x400>  // b.any
     d64:	11000821 	add	w1, w1, #0x2
    if(pos + 10 > n)
     d68:	11002420 	add	w0, w1, #0x9
     d6c:	6b00033f 	cmp	w25, w0
     d70:	54fffc4d 	b.le	cf8 <main+0x3c0>
    int rdlen = (r[pos + 8] << 8) | r[pos + 9];
     d74:	11002024 	add	w4, w1, #0x8
     d78:	3860c840 	ldrb	w0, [x2, w0, sxtw]
    int type = (r[pos] << 8) | r[pos + 1];
     d7c:	11000427 	add	w7, w1, #0x1
    pos += 10;
     d80:	11002826 	add	w6, w1, #0xa
    int rdlen = (r[pos + 8] << 8) | r[pos + 9];
     d84:	3864c844 	ldrb	w4, [x2, w4, sxtw]
    int type = (r[pos] << 8) | r[pos + 1];
     d88:	3867c847 	ldrb	w7, [x2, w7, sxtw]
    int rdlen = (r[pos + 8] << 8) | r[pos + 9];
     d8c:	2a042004 	orr	w4, w0, w4, lsl #8
    int type = (r[pos] << 8) | r[pos + 1];
     d90:	3861c840 	ldrb	w0, [x2, w1, sxtw]
     d94:	2a0020e0 	orr	w0, w7, w0, lsl #8
    if(type == 1 && rdlen == 4 && pos + 4 <= n){
     d98:	7100041f 	cmp	w0, #0x1
     d9c:	7a440880 	ccmp	w4, #0x4, #0x0, eq	// eq = none
     da0:	54000561 	b.ne	e4c <main+0x514>  // b.any
     da4:	11003427 	add	w7, w1, #0xd
     da8:	6b07033f 	cmp	w25, w7
     dac:	5400050d 	b.le	e4c <main+0x514>
      *ip = ((uint32)r[pos] << 24) | ((uint32)r[pos + 1] << 16) |
     db0:	11002c20 	add	w0, w1, #0xb
            ((uint32)r[pos + 2] << 8) | r[pos + 3];
     db4:	11003021 	add	w1, w1, #0xc
      *ip = ((uint32)r[pos] << 24) | ((uint32)r[pos + 1] << 16) |
     db8:	3860c853 	ldrb	w19, [x2, w0, sxtw]
     dbc:	3866c840 	ldrb	w0, [x2, w6, sxtw]
     dc0:	53081c00 	lsl	w0, w0, #24
            ((uint32)r[pos + 2] << 8) | r[pos + 3];
     dc4:	2a134013 	orr	w19, w0, w19, lsl #16
     dc8:	3861c840 	ldrb	w0, [x2, w1, sxtw]
     dcc:	3867c841 	ldrb	w1, [x2, w7, sxtw]
     dd0:	2a002020 	orr	w0, w1, w0, lsl #8
     dd4:	2a000273 	orr	w19, w19, w0
  if(!quiet){
     dd8:	b9400300 	ldr	w0, [x24]
     ddc:	35000260 	cbnz	w0, e28 <main+0x4f0>
    fprintf(2, "Connecting to %s (", u->host);
     de0:	aa1703e2 	mov	x2, x23
     de4:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     de8:	91215821 	add	x1, x1, #0x856
     dec:	52800040 	mov	w0, #0x2                   	// #2
     df0:	97fffe8a 	bl	818 <fprintf@plt>
  fprintf(fd, "%d.%d.%d.%d", (ip >> 24) & 255, (ip >> 16) & 255,
     df4:	53187e62 	lsr	w2, w19, #24
     df8:	12001e65 	and	w5, w19, #0xff
     dfc:	d3483e64 	ubfx	x4, x19, #8, #8
     e00:	d3505e63 	ubfx	x3, x19, #16, #8
     e04:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     e08:	9121a421 	add	x1, x1, #0x869
     e0c:	52800040 	mov	w0, #0x2                   	// #2
     e10:	97fffe82 	bl	818 <fprintf@plt>
    fprintf(2, "):%d... ", u->port);
     e14:	b943c3e2 	ldr	w2, [sp, #960]
     e18:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     e1c:	9121d421 	add	x1, x1, #0x875
     e20:	52800040 	mov	w0, #0x2                   	// #2
     e24:	97fffe7d 	bl	818 <fprintf@plt>
  if((s = socket(AF_INET, SOCK_STREAM, 0)) < 0){
     e28:	52800002 	mov	w2, #0x0                   	// #0
     e2c:	52800021 	mov	w1, #0x1                   	// #1
     e30:	52800040 	mov	w0, #0x2                   	// #2
     e34:	97fffe71 	bl	7f8 <socket@plt>
     e38:	2a0003f4 	mov	w20, w0
     e3c:	36f800e0 	tbz	w0, #31, e58 <main+0x520>
    fprintf(2, "wget: socket failed\n");
     e40:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     e44:	9121f821 	add	x1, x1, #0x87e
     e48:	17ffff28 	b	ae8 <main+0x1b0>
    pos += rdlen;
     e4c:	0b060081 	add	w1, w4, w6
  for(int i = 0; i < an && pos < n; i++){
     e50:	110004a5 	add	w5, w5, #0x1
     e54:	17ffffa6 	b	cec <main+0x3b4>
  memset(&sa, 0, sizeof(sa));
     e58:	52800202 	mov	w2, #0x10                  	// #16
     e5c:	52800001 	mov	w1, #0x0                   	// #0
     e60:	910223e0 	add	x0, sp, #0x88
     e64:	97fffe81 	bl	868 <memset@plt>
  sa.sin_family = AF_INET;
     e68:	52800040 	mov	w0, #0x2                   	// #2
     e6c:	790113e0 	strh	w0, [sp, #136]
  sa.sin_port = htons16(u->port);
     e70:	b943c3e0 	ldr	w0, [sp, #960]
     e74:	5ac00a73 	rev	w19, w19
  if(connect(s, &sa, sizeof(sa)) < 0){
     e78:	910223e1 	add	x1, sp, #0x88
     e7c:	52800202 	mov	w2, #0x10                  	// #16
  return (v << 8) | (v >> 8);
     e80:	5ac00400 	rev16	w0, w0
  sa.sin_port = htons16(u->port);
     e84:	790117e0 	strh	w0, [sp, #138]
  if(connect(s, &sa, sizeof(sa)) < 0){
     e88:	2a1403e0 	mov	w0, w20
  sa.sin_addr.s_addr = htonl32(ip);
     e8c:	b9008ff3 	str	w19, [sp, #140]
  if(connect(s, &sa, sizeof(sa)) < 0){
     e90:	97fffe4e 	bl	7c8 <connect@plt>
     e94:	36f80100 	tbz	w0, #31, eb4 <main+0x57c>
    fprintf(2, "failed: connection refused or timed out\n");
     e98:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     e9c:	91224c21 	add	x1, x1, #0x893
    fprintf(2, "wget: bad or truncated response header\n");
     ea0:	52800040 	mov	w0, #0x2                   	// #2
     ea4:	97fffe5d 	bl	818 <fprintf@plt>
    close(s);
     ea8:	2a1403e0 	mov	w0, w20
     eac:	97fffe9f 	bl	928 <close@plt>
    if(r < 0)
     eb0:	17ffff3a 	b	b98 <main+0x260>
  if(!quiet)
     eb4:	b9400300 	ldr	w0, [x24]
     eb8:	350000a0 	cbnz	w0, ecc <main+0x594>
    fprintf(2, "connected.\n");
     ebc:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     ec0:	9122f021 	add	x1, x1, #0x8bc
     ec4:	52800040 	mov	w0, #0x2                   	// #2
     ec8:	97fffe54 	bl	818 <fprintf@plt>
  const char *parts[] = {
     ecc:	b0000000 	adrp	x0, 1000 <main+0x6c8>
     ed0:	91232000 	add	x0, x0, #0x8c8
     ed4:	910263f3 	add	x19, sp, #0x98
     ed8:	f9004fe0 	str	x0, [sp, #152]
     edc:	910f13e0 	add	x0, sp, #0x3c4
     ee0:	f90053e0 	str	x0, [sp, #160]
     ee4:	b0000000 	adrp	x0, 1000 <main+0x6c8>
     ee8:	91233400 	add	x0, x0, #0x8cd
     eec:	a90adfe0 	stp	x0, x23, [sp, #168]
     ef0:	f9005fff 	str	xzr, [sp, #184]
  req[0] = 0;
     ef4:	392143ff 	strb	wzr, [sp, #2128]
  for(int i = 0; parts[i]; i++)
     ef8:	f8408661 	ldr	x1, [x19], #8
     efc:	b5000261 	cbnz	x1, f48 <main+0x610>
  if(u->port != 80){
     f00:	b943c3e1 	ldr	w1, [sp, #960]
     f04:	7101403f 	cmp	w1, #0x50
     f08:	54000521 	b.ne	fac <main+0x674>  // b.any
  strcat(req, "\r\nUser-Agent: xv6-wget/1.0\r\nAccept: */*\r\n"
     f0c:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     f10:	91237c21 	add	x1, x1, #0x8df
     f14:	912143e0 	add	x0, sp, #0x850
     f18:	97fffe44 	bl	828 <strcat@plt>
  rl = strlen(req);
     f1c:	912143e0 	add	x0, sp, #0x850
     f20:	97fffe76 	bl	8f8 <strlen@plt>
  if(writeall(s, req, rl) < 0){
     f24:	2a0003e2 	mov	w2, w0
     f28:	912143e1 	add	x1, sp, #0x850
     f2c:	2a1403e0 	mov	w0, w20
     f30:	9400014c 	bl	1460 <writeall>
     f34:	3100041f 	cmn	w0, #0x1
     f38:	54000481 	b.ne	fc8 <main+0x690>  // b.any
    fprintf(2, "wget: send failed\n");
     f3c:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     f40:	91247821 	add	x1, x1, #0x91e
     f44:	17ffffd7 	b	ea0 <main+0x568>
    strcat(req, parts[i]);
     f48:	912143e0 	add	x0, sp, #0x850
     f4c:	97fffe37 	bl	828 <strcat@plt>
  for(int i = 0; parts[i]; i++)
     f50:	17ffffea 	b	ef8 <main+0x5c0>
    while(p){ t[tn++] = '0' + p % 10; p /= 10; }
     f54:	1adb0c22 	sdiv	w2, w1, w27
     f58:	1b1b8441 	msub	w1, w2, w27, w1
     f5c:	1100c021 	add	w1, w1, #0x30
     f60:	38236801 	strb	w1, [x0, x3]
     f64:	2a0203e1 	mov	w1, w2
     f68:	91000400 	add	x0, x0, #0x1
     f6c:	35ffff41 	cbnz	w1, f54 <main+0x61c>
     f70:	2a0003e2 	mov	w2, w0
    pbuf[k++] = ':';
     f74:	51000400 	sub	w0, w0, #0x1
     f78:	52800741 	mov	w1, #0x3a                  	// #58
     f7c:	910503e3 	add	x3, sp, #0x140
     f80:	93407c00 	sxtw	x0, w0
    while(tn) pbuf[k++] = t[--tn];
     f84:	911723e4 	add	x4, sp, #0x5c8
    pbuf[k++] = ':';
     f88:	390503e1 	strb	w1, [sp, #320]
    while(tn) pbuf[k++] = t[--tn];
     f8c:	aa0303e1 	mov	x1, x3
     f90:	3100041f 	cmn	w0, #0x1
     f94:	54000121 	b.ne	fb8 <main+0x680>  // b.any
    pbuf[k] = 0;
     f98:	11000440 	add	w0, w2, #0x1
     f9c:	3820683f 	strb	wzr, [x1, x0]
    strcat(req, pbuf);
     fa0:	912143e0 	add	x0, sp, #0x850
     fa4:	97fffe21 	bl	828 <strcat@plt>
     fa8:	17ffffd9 	b	f0c <main+0x5d4>
    while(p){ t[tn++] = '0' + p % 10; p /= 10; }
     fac:	911723e3 	add	x3, sp, #0x5c8
  if(u->port != 80){
     fb0:	d2800000 	mov	x0, #0x0                   	// #0
     fb4:	17ffffee 	b	f6c <main+0x634>
    while(tn) pbuf[k++] = t[--tn];
     fb8:	38646805 	ldrb	w5, [x0, x4]
     fbc:	d1000400 	sub	x0, x0, #0x1
     fc0:	38001c65 	strb	w5, [x3, #1]!
     fc4:	17fffff3 	b	f90 <main+0x658>
  if(!quiet)
     fc8:	b9400300 	ldr	w0, [x24]
     fcc:	350000a0 	cbnz	w0, fe0 <main+0x6a8>
    fprintf(2, "HTTP request sent, awaiting response... ");
     fd0:	b0000001 	adrp	x1, 1000 <main+0x6c8>
     fd4:	9124c421 	add	x1, x1, #0x931
     fd8:	52800040 	mov	w0, #0x2                   	// #2
     fdc:	97fffe0f 	bl	818 <fprintf@plt>
    int n = read(s, hdr + len, cap - 1 - len);
     fe0:	d0000015 	adrp	x21, 2000 <_DYNAMIC>
     fe4:	912812b5 	add	x21, x21, #0xa04
  int len = 0;
     fe8:	52800013 	mov	w19, #0x0                   	// #0
    int n = read(s, hdr + len, cap - 1 - len);
     fec:	5281fff9 	mov	w25, #0xfff                 	// #4095
     ff0:	4b130322 	sub	w2, w25, w19
     ff4:	8b33c2a1 	add	x1, x21, w19, sxtw
     ff8:	2a1403e0 	mov	w0, w20
     ffc:	97fffe13 	bl	848 <read@plt>
    if(n <= 0)
    1000:	7100001f 	cmp	w0, #0x0
    1004:	5400012d 	b.le	1028 <main+0x6f0>
    len += n;
    1008:	0b000273 	add	w19, w19, w0
    hdr[len] = 0;
    100c:	aa1503e0 	mov	x0, x21
    for(int i = 3; i < len; i++){
    1010:	52800076 	mov	w22, #0x3                   	// #3
    hdr[len] = 0;
    1014:	3833cabf 	strb	wzr, [x21, w19, sxtw]
    for(int i = 3; i < len; i++){
    1018:	6b16027f 	cmp	w19, w22
    101c:	540000cc 	b.gt	1034 <main+0x6fc>
  while(len < cap - 1){
    1020:	713ffa7f 	cmp	w19, #0xffe
    1024:	54fffe6d 	b.le	ff0 <main+0x6b8>
    fprintf(2, "wget: bad or truncated response header\n");
    1028:	90000001 	adrp	x1, 1000 <main+0x6c8>
    102c:	91256821 	add	x1, x1, #0x95a
    1030:	17ffff9c 	b	ea0 <main+0x568>
      if(hdr[i-3] == '\r' && hdr[i-2] == '\n' &&
    1034:	39400001 	ldrb	w1, [x0]
    1038:	7100343f 	cmp	w1, #0xd
    103c:	54000901 	b.ne	115c <main+0x824>  // b.any
    1040:	39400401 	ldrb	w1, [x0, #1]
    1044:	7100283f 	cmp	w1, #0xa
    1048:	540008a1 	b.ne	115c <main+0x824>  // b.any
    104c:	39400801 	ldrb	w1, [x0, #2]
    1050:	7100343f 	cmp	w1, #0xd
    1054:	54000841 	b.ne	115c <main+0x824>  // b.any
         hdr[i-1] == '\r' && hdr[i] == '\n'){
    1058:	39400c01 	ldrb	w1, [x0, #3]
    105c:	7100283f 	cmp	w1, #0xa
    1060:	540007e1 	b.ne	115c <main+0x824>  // b.any
  char *sp = strchr(hdr, ' ');
    1064:	aa1503e0 	mov	x0, x21
    1068:	52800401 	mov	w1, #0x20                  	// #32
    106c:	97fffe2b 	bl	918 <strchr@plt>
    1070:	aa0003e2 	mov	x2, x0
  status = sp ? atoi(sp + 1) : 0;
    1074:	b50007a0 	cbnz	x0, 1168 <main+0x830>
    1078:	52800019 	mov	w25, #0x0                   	// #0
  if(!quiet){
    107c:	b9400300 	ldr	w0, [x24]
    1080:	35000280 	cbnz	w0, 10d0 <main+0x798>
    char *eol = strchr(hdr, '\r');
    1084:	aa1503e0 	mov	x0, x21
    1088:	528001a1 	mov	w1, #0xd                   	// #13
    108c:	f9003be2 	str	x2, [sp, #112]
    1090:	97fffe22 	bl	918 <strchr@plt>
    if(sp && eol){ *eol = 0; fprintf(2, "%s\n", sp + 1); *eol = '\r'; }
    1094:	f9403be2 	ldr	x2, [sp, #112]
    char *eol = strchr(hdr, '\r');
    1098:	aa0003e3 	mov	x3, x0
    if(sp && eol){ *eol = 0; fprintf(2, "%s\n", sp + 1); *eol = '\r'; }
    109c:	f100005f 	cmp	x2, #0x0
    10a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    10a4:	54000160 	b.eq	10d0 <main+0x798>  // b.none
    10a8:	3900001f 	strb	wzr, [x0]
    10ac:	91000442 	add	x2, x2, #0x1
    10b0:	90000001 	adrp	x1, 1000 <main+0x6c8>
    10b4:	91282c21 	add	x1, x1, #0xa0b
    10b8:	52800040 	mov	w0, #0x2                   	// #2
    10bc:	f9003be3 	str	x3, [sp, #112]
    10c0:	97fffdd6 	bl	818 <fprintf@plt>
    10c4:	f9403be3 	ldr	x3, [sp, #112]
    10c8:	528001a0 	mov	w0, #0xd                   	// #13
    10cc:	39000060 	strb	w0, [x3]
  if(status >= 300 && status < 400 && header(hdr, "Location", loc, sizeof(loc)) == 0){
    10d0:	5104b320 	sub	w0, w25, #0x12c
    10d4:	71018c1f 	cmp	w0, #0x63
    10d8:	54000688 	b.hi	11a8 <main+0x870>  // b.pmore
    10dc:	90000000 	adrp	x0, 1000 <main+0x6c8>
    10e0:	91260800 	add	x0, x0, #0x982
    10e4:	910503e1 	add	x1, sp, #0x140
    10e8:	52804002 	mov	w2, #0x200                 	// #512
    10ec:	9400015b 	bl	1658 <header.constprop.0>
    10f0:	35000600 	cbnz	w0, 11b0 <main+0x878>
    close(s);
    10f4:	2a1403e0 	mov	w0, w20
    10f8:	97fffe0c 	bl	928 <close@plt>
    if(!quiet)
    10fc:	b9400300 	ldr	w0, [x24]
    1100:	350000c0 	cbnz	w0, 1118 <main+0x7e0>
      fprintf(2, "Location: %s [following]\n", loc);
    1104:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1108:	91262c21 	add	x1, x1, #0x98b
    110c:	910503e2 	add	x2, sp, #0x140
    1110:	52800040 	mov	w0, #0x2                   	// #2
    1114:	97fffdc1 	bl	818 <fprintf@plt>
    if(loc[0] == '/'){
    1118:	394503e0 	ldrb	w0, [sp, #320]
    111c:	7100bc1f 	cmp	w0, #0x2f
    1120:	54000301 	b.ne	1180 <main+0x848>  // b.any
      if(strlen(loc) >= sizeof(u->path))
    1124:	910503e0 	add	x0, sp, #0x140
    1128:	97fffdf4 	bl	8f8 <strlen@plt>
    112c:	7107fc1f 	cmp	w0, #0x1ff
    1130:	54ffd348 	b.hi	b98 <main+0x260>  // b.pmore
      strcpy(u->path, loc);
    1134:	910503e1 	add	x1, sp, #0x140
    1138:	910f13e0 	add	x0, sp, #0x3c4
    113c:	97fffd9f 	bl	7b8 <strcpy@plt>
  for(int hops = 0; hops <= MAXREDIR; hops++){
    1140:	b9406be0 	ldr	w0, [sp, #104]
    1144:	71000400 	subs	w0, w0, #0x1
    1148:	b9006be0 	str	w0, [sp, #104]
    114c:	54ffc361 	b.ne	9b8 <main+0x80>  // b.any
  }
  fprintf(2, "wget: too many redirects\n");
    1150:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1154:	9129c821 	add	x1, x1, #0xa72
    1158:	17fffe64 	b	ae8 <main+0x1b0>
    for(int i = 3; i < len; i++){
    115c:	110006d6 	add	w22, w22, #0x1
    1160:	91000400 	add	x0, x0, #0x1
    1164:	17ffffad 	b	1018 <main+0x6e0>
  status = sp ? atoi(sp + 1) : 0;
    1168:	91000400 	add	x0, x0, #0x1
    116c:	f9003be2 	str	x2, [sp, #112]
    1170:	97fffdde 	bl	8e8 <atoi@plt>
    1174:	2a0003f9 	mov	w25, w0
    1178:	f9403be2 	ldr	x2, [sp, #112]
    117c:	17ffffc0 	b	107c <main+0x744>
    if(parse_url(loc, &nu) < 0)
    1180:	911723e1 	add	x1, sp, #0x5c8
    1184:	910503e0 	add	x0, sp, #0x140
    1188:	940000e4 	bl	1518 <parse_url>
    118c:	3100041f 	cmn	w0, #0x1
    1190:	54ffd040 	b.eq	b98 <main+0x260>  // b.none
    *u = nu;
    1194:	911723e1 	add	x1, sp, #0x5c8
    1198:	910d03e0 	add	x0, sp, #0x340
    119c:	d2805082 	mov	x2, #0x284                 	// #644
    11a0:	97fffd92 	bl	7e8 <memcpy@plt>
    if(r < 0)
    11a4:	17ffffe7 	b	1140 <main+0x808>
  if(status != 200){
    11a8:	7103233f 	cmp	w25, #0xc8
    11ac:	540000e0 	b.eq	11c8 <main+0x890>  // b.none
    fprintf(2, "wget: server returned %d\n", status);
    11b0:	2a1903e2 	mov	w2, w25
    11b4:	90000001 	adrp	x1, 1000 <main+0x6c8>
    11b8:	91269421 	add	x1, x1, #0x9a5
    11bc:	52800040 	mov	w0, #0x2                   	// #2
    11c0:	97fffd96 	bl	818 <fprintf@plt>
    close(s);
    11c4:	17ffff39 	b	ea8 <main+0x570>
    11c8:	f100035f 	cmp	x26, #0x0
    11cc:	910303e0 	add	x0, sp, #0xc0
    11d0:	9a80135a 	csel	x26, x26, x0, ne	// ne = any
  if(header(hdr, "Content-Length", val, sizeof(val)) == 0)
    11d4:	911723e1 	add	x1, sp, #0x5c8
    11d8:	90000000 	adrp	x0, 1000 <main+0x6c8>
    11dc:	9126fc00 	add	x0, x0, #0x9bf
    11e0:	52800402 	mov	w2, #0x20                  	// #32
    11e4:	9400011d 	bl	1658 <header.constprop.0>
    11e8:	350004a0 	cbnz	w0, 127c <main+0x944>
    clen = atoi(val);
    11ec:	911723e0 	add	x0, sp, #0x5c8
    11f0:	97fffdbe 	bl	8e8 <atoi@plt>
    11f4:	93407c17 	sxtw	x23, w0
  if(!quiet){
    11f8:	b9420380 	ldr	w0, [x28, #512]
    11fc:	35000200 	cbnz	w0, 123c <main+0x904>
    fprintf(2, "Length: ");
    1200:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1204:	91273821 	add	x1, x1, #0x9ce
    1208:	52800040 	mov	w0, #0x2                   	// #2
    120c:	97fffd83 	bl	818 <fprintf@plt>
    if(clen >= 0) fprintf(2, "%d", (int)clen); else fprintf(2, "unspecified");
    1210:	b7f803b7 	tbnz	x23, #63, 1284 <main+0x94c>
    1214:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1218:	9121c821 	add	x1, x1, #0x872
    121c:	2a1703e2 	mov	w2, w23
    1220:	52800040 	mov	w0, #0x2                   	// #2
    1224:	97fffd7d 	bl	818 <fprintf@plt>
    fprintf(2, "\nSaving to: '%s'\n", outname);
    1228:	90000001 	adrp	x1, 1000 <main+0x6c8>
    122c:	91278c21 	add	x1, x1, #0x9e3
    1230:	aa1a03e2 	mov	x2, x26
    1234:	52800040 	mov	w0, #0x2                   	// #2
    1238:	97fffd78 	bl	818 <fprintf@plt>
  if(strcmp(outname, "-") == 0)
    123c:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1240:	9127d421 	add	x1, x1, #0x9f5
    1244:	aa1a03e0 	mov	x0, x26
    1248:	97fffd90 	bl	888 <strcmp@plt>
    124c:	34000260 	cbz	w0, 1298 <main+0x960>
  else if((out = open(outname, O_CREATE | O_WRONLY | O_TRUNC)) < 0){
    1250:	aa1a03e0 	mov	x0, x26
    1254:	5280c021 	mov	w1, #0x601                 	// #1537
    1258:	97fffdac 	bl	908 <open@plt>
    125c:	2a0003f9 	mov	w25, w0
    1260:	36f801e0 	tbz	w0, #31, 129c <main+0x964>
    fprintf(2, "wget: cannot create %s\n", outname);
    1264:	aa1a03e2 	mov	x2, x26
    1268:	90000001 	adrp	x1, 1000 <main+0x6c8>
    126c:	9127dc21 	add	x1, x1, #0x9f7
    1270:	52800040 	mov	w0, #0x2                   	// #2
    1274:	97fffd69 	bl	818 <fprintf@plt>
    1278:	17ffff0c 	b	ea8 <main+0x570>
  long total = 0, clen = -1;
    127c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    1280:	17ffffde 	b	11f8 <main+0x8c0>
    if(clen >= 0) fprintf(2, "%d", (int)clen); else fprintf(2, "unspecified");
    1284:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1288:	91275c21 	add	x1, x1, #0x9d7
    128c:	52800040 	mov	w0, #0x2                   	// #2
    1290:	97fffd62 	bl	818 <fprintf@plt>
    1294:	17ffffe5 	b	1228 <main+0x8f0>
    out = 1;
    1298:	52800039 	mov	w25, #0x1                   	// #1
  uint64 t0 = clock_us();
    129c:	97fffd8b 	bl	8c8 <clock_us@plt>
        *bodyoff = i + 1;
    12a0:	110006d6 	add	w22, w22, #0x1
  uint64 t0 = clock_us();
    12a4:	f9003be0 	str	x0, [sp, #112]
  if(have > bodyoff){
    12a8:	6b16027f 	cmp	w19, w22
    12ac:	540008ad 	b.le	13c0 <main+0xa88>
    if(writeall(out, hdr + bodyoff, have - bodyoff) < 0)
    12b0:	4b160262 	sub	w2, w19, w22
    12b4:	8b3642a1 	add	x1, x21, w22, uxtw
    12b8:	2a1903e0 	mov	w0, w25
    12bc:	94000069 	bl	1460 <writeall>
    12c0:	3100041f 	cmn	w0, #0x1
    12c4:	54000a80 	b.eq	1414 <main+0xadc>  // b.none
    total += have - bodyoff;
    12c8:	4b160273 	sub	w19, w19, w22
  while(clen < 0 || total < clen){
    12cc:	d37ffee0 	lsr	x0, x23, #63
    int n = read(s, buf, sizeof(buf));
    12d0:	91001316 	add	x22, x24, #0x4
  while(clen < 0 || total < clen){
    12d4:	12001c1b 	and	w27, w0, #0xff
  long next_report = 64 * 1024;
    12d8:	d2a00035 	mov	x21, #0x10000               	// #65536
      fprintf(2, "  %d KB\n", (int)(total / 1024));
    12dc:	90000000 	adrp	x0, 1000 <main+0x6c8>
    12e0:	9128c400 	add	x0, x0, #0xa31
    12e4:	f90037e0 	str	x0, [sp, #104]
  while(clen < 0 || total < clen){
    12e8:	7100037f 	cmp	w27, #0x0
    12ec:	fa5302e0 	ccmp	x23, x19, #0x0, eq	// eq = none
    12f0:	5400018d 	b.le	1320 <main+0x9e8>
    int n = read(s, buf, sizeof(buf));
    12f4:	52810002 	mov	w2, #0x800                 	// #2048
    12f8:	aa1603e1 	mov	x1, x22
    12fc:	2a1403e0 	mov	w0, w20
    1300:	97fffd52 	bl	848 <read@plt>
    1304:	2a0003e2 	mov	w2, w0
    if(n < 0){
    1308:	36f80600 	tbz	w0, #31, 13c8 <main+0xa90>
      fprintf(2, "\nwget: read error after %d bytes\n", (int)total);
    130c:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1310:	91283c21 	add	x1, x1, #0xa0f
    1314:	2a1303e2 	mov	w2, w19
    1318:	52800040 	mov	w0, #0x2                   	// #2
    131c:	97fffd3f 	bl	818 <fprintf@plt>
  close(s);
    1320:	2a1403e0 	mov	w0, w20
    1324:	97fffd81 	bl	928 <close@plt>
  if(out != 1)
    1328:	7100073f 	cmp	w25, #0x1
    132c:	54000060 	b.eq	1338 <main+0xa00>  // b.none
    close(out);
    1330:	2a1903e0 	mov	w0, w25
    1334:	97fffd7d 	bl	928 <close@plt>
  if(!quiet){
    1338:	b9420394 	ldr	w20, [x28, #512]
    133c:	35000394 	cbnz	w20, 13ac <main+0xa74>
    uint64 us = clock_us() - t0;
    1340:	97fffd62 	bl	8c8 <clock_us@plt>
    int kbs = us ? (int)(total * 1000000 / 1024 / us) : 0;
    1344:	f9403be1 	ldr	x1, [sp, #112]
    1348:	eb010000 	subs	x0, x0, x1
    134c:	540000e0 	b.eq	1368 <main+0xa30>  // b.none
    1350:	d2884814 	mov	x20, #0x4240                	// #16960
    1354:	f2a001f4 	movk	x20, #0xf, lsl #16
    1358:	d2808001 	mov	x1, #0x400                 	// #1024
    135c:	9b147e74 	mul	x20, x19, x20
    1360:	9ac10e94 	sdiv	x20, x20, x1
    1364:	9ac00a94 	udiv	x20, x20, x0
    fprintf(2, "'%s' saved [%d", outname, (int)total);
    1368:	90000001 	adrp	x1, 1000 <main+0x6c8>
    136c:	9128e821 	add	x1, x1, #0xa3a
    1370:	2a1303e3 	mov	w3, w19
    1374:	aa1a03e2 	mov	x2, x26
    1378:	52800040 	mov	w0, #0x2                   	// #2
    137c:	97fffd27 	bl	818 <fprintf@plt>
    if(clen >= 0) fprintf(2, "/%d", (int)clen);
    1380:	b7f800d7 	tbnz	x23, #63, 1398 <main+0xa60>
    1384:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1388:	91292421 	add	x1, x1, #0xa49
    138c:	2a1703e2 	mov	w2, w23
    1390:	52800040 	mov	w0, #0x2                   	// #2
    1394:	97fffd21 	bl	818 <fprintf@plt>
    fprintf(2, "] %d KB/s\n", kbs);
    1398:	90000001 	adrp	x1, 1000 <main+0x6c8>
    139c:	91293421 	add	x1, x1, #0xa4d
    13a0:	2a1403e2 	mov	w2, w20
    13a4:	52800040 	mov	w0, #0x2                   	// #2
    13a8:	97fffd1c 	bl	818 <fprintf@plt>
  return clen >= 0 && total != clen ? -1 : 0;
    13ac:	f10002ff 	cmp	x23, #0x0
    13b0:	fa53a2e4 	ccmp	x23, x19, #0x4, ge	// ge = tcont
    13b4:	54ffbf21 	b.ne	b98 <main+0x260>  // b.any
      exit(0);
    13b8:	52800000 	mov	w0, #0x0                   	// #0
      exit(1);
    13bc:	97fffd47 	bl	8d8 <exit@plt>
  long total = 0, clen = -1;
    13c0:	d2800013 	mov	x19, #0x0                   	// #0
    13c4:	17ffffc2 	b	12cc <main+0x994>
    if(n == 0)
    13c8:	34fffac0 	cbz	w0, 1320 <main+0x9e8>
    if(writeall(out, buf, n) < 0)
    13cc:	aa1603e1 	mov	x1, x22
    13d0:	2a1903e0 	mov	w0, w25
    13d4:	b9007be2 	str	w2, [sp, #120]
    13d8:	94000022 	bl	1460 <writeall>
    13dc:	3100041f 	cmn	w0, #0x1
    13e0:	540001a0 	b.eq	1414 <main+0xadc>  // b.none
    if(!quiet && total >= next_report){
    13e4:	b9400300 	ldr	w0, [x24]
    total += n;
    13e8:	b9407be2 	ldr	w2, [sp, #120]
    13ec:	8b224273 	add	x19, x19, w2, uxtw
    if(!quiet && total >= next_report){
    13f0:	35fff7c0 	cbnz	w0, 12e8 <main+0x9b0>
    13f4:	eb15027f 	cmp	x19, x21
    13f8:	54fff78b 	b.lt	12e8 <main+0x9b0>  // b.tstop
      fprintf(2, "  %d KB\n", (int)(total / 1024));
    13fc:	f94037e1 	ldr	x1, [sp, #104]
    1400:	d34aa662 	ubfx	x2, x19, #10, #32
      next_report += 64 * 1024;
    1404:	914042b5 	add	x21, x21, #0x10, lsl #12
      fprintf(2, "  %d KB\n", (int)(total / 1024));
    1408:	52800040 	mov	w0, #0x2                   	// #2
    140c:	97fffd03 	bl	818 <fprintf@plt>
      next_report += 64 * 1024;
    1410:	17ffffb6 	b	12e8 <main+0x9b0>
  fprintf(2, "wget: write to %s failed\n", outname);
    1414:	aa1a03e2 	mov	x2, x26
    1418:	90000001 	adrp	x1, 1000 <main+0x6c8>
    141c:	91296021 	add	x1, x1, #0xa58
    1420:	52800040 	mov	w0, #0x2                   	// #2
    1424:	97fffcfd 	bl	818 <fprintf@plt>
  close(s);
    1428:	2a1403e0 	mov	w0, w20
    142c:	97fffd3f 	bl	928 <close@plt>
  if(out != 1)
    1430:	7100073f 	cmp	w25, #0x1
    1434:	54ffbb20 	b.eq	b98 <main+0x260>  // b.none
    close(out);
    1438:	2a1903e0 	mov	w0, w25
    143c:	17fffe9c 	b	eac <main+0x574>

0000000000001440 <usage>:
{
    1440:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: wget [-q] [-O file] http://host[:port]/path\n");
    1444:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1448:	911d6021 	add	x1, x1, #0x758
{
    144c:	910003fd 	mov	x29, sp
  fprintf(2, "usage: wget [-q] [-O file] http://host[:port]/path\n");
    1450:	52800040 	mov	w0, #0x2                   	// #2
    1454:	97fffcf1 	bl	818 <fprintf@plt>
  exit(1);
    1458:	52800020 	mov	w0, #0x1                   	// #1
    145c:	97fffd1f 	bl	8d8 <exit@plt>

0000000000001460 <writeall>:
{
    1460:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1464:	910003fd 	mov	x29, sp
    1468:	a90153f3 	stp	x19, x20, [sp, #16]
    146c:	2a0203f4 	mov	w20, w2
  int done = 0;
    1470:	52800013 	mov	w19, #0x0                   	// #0
{
    1474:	a9025bf5 	stp	x21, x22, [sp, #32]
    1478:	2a0003f6 	mov	w22, w0
    147c:	aa0103f5 	mov	x21, x1
  while(done < n){
    1480:	6b14027f 	cmp	w19, w20
    1484:	540000cb 	b.lt	149c <writeall+0x3c>  // b.tstop
  return 0;
    1488:	52800000 	mov	w0, #0x0                   	// #0
}
    148c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1490:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1494:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1498:	d65f03c0 	ret
    int w = write(fd, buf + done, n - done);
    149c:	4b130282 	sub	w2, w20, w19
    14a0:	8b33c2a1 	add	x1, x21, w19, sxtw
    14a4:	2a1603e0 	mov	w0, w22
    14a8:	97fffcd8 	bl	808 <write@plt>
    if(w <= 0)
    14ac:	7100001f 	cmp	w0, #0x0
    14b0:	5400006d 	b.le	14bc <writeall+0x5c>
    done += w;
    14b4:	0b000273 	add	w19, w19, w0
    14b8:	17fffff2 	b	1480 <writeall+0x20>
      return -1;
    14bc:	12800000 	mov	w0, #0xffffffff            	// #-1
    14c0:	17fffff3 	b	148c <writeall+0x2c>

00000000000014c4 <strncaseeq>:
  for(int i = 0; i < n; i++){
    14c4:	d2800003 	mov	x3, #0x0                   	// #0
    14c8:	6b03005f 	cmp	w2, w3
    14cc:	540001ed 	b.le	1508 <strncaseeq+0x44>
    if(lower(a[i]) != lower(b[i]))
    14d0:	38636805 	ldrb	w5, [x0, x3]
  return c >= 'A' && c <= 'Z' ? c + 32 : c;
    14d4:	510104a4 	sub	w4, w5, #0x41
    14d8:	110080a6 	add	w6, w5, #0x20
    14dc:	7100689f 	cmp	w4, #0x1a
    if(lower(a[i]) != lower(b[i]))
    14e0:	38636824 	ldrb	w4, [x1, x3]
  return c >= 'A' && c <= 'Z' ? c + 32 : c;
    14e4:	1a8530c6 	csel	w6, w6, w5, cc	// cc = lo, ul, last
    14e8:	51010488 	sub	w8, w4, #0x41
    14ec:	11008087 	add	w7, w4, #0x20
    14f0:	7100691f 	cmp	w8, #0x1a
    14f4:	1a8430e4 	csel	w4, w7, w4, cc	// cc = lo, ul, last
    if(lower(a[i]) != lower(b[i]))
    14f8:	6b06009f 	cmp	w4, w6
    14fc:	540000a1 	b.ne	1510 <strncaseeq+0x4c>  // b.any
    if(a[i] == 0)
    1500:	91000463 	add	x3, x3, #0x1
    1504:	35fffe25 	cbnz	w5, 14c8 <strncaseeq+0x4>
      return 1;
    1508:	52800020 	mov	w0, #0x1                   	// #1
}
    150c:	d65f03c0 	ret
      return 0;
    1510:	52800000 	mov	w0, #0x0                   	// #0
    1514:	17fffffe 	b	150c <strncaseeq+0x48>

0000000000001518 <parse_url>:
{
    1518:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    151c:	aa0003e9 	mov	x9, x0
  if(strncaseeq(s, "https://", 8)){
    1520:	52800102 	mov	w2, #0x8                   	// #8
{
    1524:	910003fd 	mov	x29, sp
    1528:	a90153f3 	stp	x19, x20, [sp, #16]
    152c:	aa0103f3 	mov	x19, x1
  if(strncaseeq(s, "https://", 8)){
    1530:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1534:	911e3021 	add	x1, x1, #0x78c
{
    1538:	f90013f5 	str	x21, [sp, #32]
  if(strncaseeq(s, "https://", 8)){
    153c:	97ffffe2 	bl	14c4 <strncaseeq>
    1540:	34000160 	cbz	w0, 156c <parse_url+0x54>
    fprintf(2, "wget: https is not supported (no TLS); use http://\n");
    1544:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1548:	911e5421 	add	x1, x1, #0x795
    154c:	52800040 	mov	w0, #0x2                   	// #2
    1550:	97fffcb2 	bl	818 <fprintf@plt>
    return -1;
    1554:	12800015 	mov	w21, #0xffffffff            	// #-1
}
    1558:	2a1503e0 	mov	w0, w21
    155c:	f94013f5 	ldr	x21, [sp, #32]
    1560:	a94153f3 	ldp	x19, x20, [sp, #16]
    1564:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1568:	d65f03c0 	ret
  if(strncaseeq(s, "http://", 7))
    156c:	90000001 	adrp	x1, 1000 <main+0x6c8>
    1570:	911f2421 	add	x1, x1, #0x7c9
    1574:	528000e2 	mov	w2, #0x7                   	// #7
    1578:	2a0003f5 	mov	w21, w0
    157c:	aa0903e0 	mov	x0, x9
    1580:	97ffffd1 	bl	14c4 <strncaseeq>
    s += 7;
    1584:	91001d21 	add	x1, x9, #0x7
    1588:	7100001f 	cmp	w0, #0x0
  for(i = 0; *s && *s != ':' && *s != '/' && i < (int)sizeof(u->host) - 1; i++)
    158c:	b27fb7e3 	mov	x3, #0x7ffffffffffe        	// #140737488355326
    s += 7;
    1590:	9a891020 	csel	x0, x1, x9, ne	// ne = any
  for(i = 0; *s && *s != ':' && *s != '/' && i < (int)sizeof(u->host) - 1; i++)
    1594:	d2800002 	mov	x2, #0x0                   	// #0
    1598:	f2ff7fe3 	movk	x3, #0xfbff, lsl #48
    159c:	38626801 	ldrb	w1, [x0, x2]
    15a0:	7100e83f 	cmp	w1, #0x3a
    15a4:	540003c8 	b.hi	161c <parse_url+0x104>  // b.pmore
    15a8:	9ac12864 	asr	x4, x3, x1
    15ac:	37000384 	tbnz	w4, #0, 161c <parse_url+0x104>
  u->host[i] = 0;
    15b0:	38224a7f 	strb	wzr, [x19, w2, uxtw]
  if(i == 0)
    15b4:	34fffd02 	cbz	w2, 1554 <parse_url+0x3c>
  u->port = 80;
    15b8:	52800a01 	mov	w1, #0x50                  	// #80
    15bc:	b9008261 	str	w1, [x19, #128]
    15c0:	8b020014 	add	x20, x0, x2
  if(*s == ':'){
    15c4:	38626802 	ldrb	w2, [x0, x2]
    15c8:	7100e85f 	cmp	w2, #0x3a
    15cc:	540001c1 	b.ne	1604 <parse_url+0xec>  // b.any
    s++;
    15d0:	91000694 	add	x20, x20, #0x1
    u->port = atoi(s);
    15d4:	aa1403e0 	mov	x0, x20
    15d8:	97fffcc4 	bl	8e8 <atoi@plt>
    15dc:	b9008260 	str	w0, [x19, #128]
    while(*s >= '0' && *s <= '9')
    15e0:	39400282 	ldrb	w2, [x20]
    15e4:	5100c041 	sub	w1, w2, #0x30
    15e8:	12001c21 	and	w1, w1, #0xff
    15ec:	7100243f 	cmp	w1, #0x9
    15f0:	54000209 	b.ls	1630 <parse_url+0x118>  // b.plast
    if(u->port <= 0 || u->port > 65535)
    15f4:	51000401 	sub	w1, w0, #0x1
    15f8:	529fffc0 	mov	w0, #0xfffe                	// #65534
    15fc:	6b00003f 	cmp	w1, w0
    1600:	54fffaa8 	b.hi	1554 <parse_url+0x3c>  // b.pmore
  if(*s == 0)
    1604:	350001a2 	cbnz	w2, 1638 <parse_url+0x120>
    strcpy(u->path, "/");
    1608:	90000001 	adrp	x1, 1000 <main+0x6c8>
    160c:	911f3c21 	add	x1, x1, #0x7cf
    strcpy(u->path, s);
    1610:	91021260 	add	x0, x19, #0x84
    1614:	97fffc69 	bl	7b8 <strcpy@plt>
    1618:	17ffffd0 	b	1558 <parse_url+0x40>
  for(i = 0; *s && *s != ':' && *s != '/' && i < (int)sizeof(u->host) - 1; i++)
    161c:	f101fc5f 	cmp	x2, #0x7f
    1620:	54fffc80 	b.eq	15b0 <parse_url+0x98>  // b.none
    u->host[i] = *s++;
    1624:	38226a61 	strb	w1, [x19, x2]
  for(i = 0; *s && *s != ':' && *s != '/' && i < (int)sizeof(u->host) - 1; i++)
    1628:	91000442 	add	x2, x2, #0x1
    162c:	17ffffdc 	b	159c <parse_url+0x84>
      s++;
    1630:	91000694 	add	x20, x20, #0x1
    1634:	17ffffeb 	b	15e0 <parse_url+0xc8>
    if(*s != '/' || strlen(s) >= sizeof(u->path))
    1638:	7100bc5f 	cmp	w2, #0x2f
    163c:	54fff8c1 	b.ne	1554 <parse_url+0x3c>  // b.any
    1640:	aa1403e0 	mov	x0, x20
    1644:	97fffcad 	bl	8f8 <strlen@plt>
    1648:	7107fc1f 	cmp	w0, #0x1ff
    164c:	54fff848 	b.hi	1554 <parse_url+0x3c>  // b.pmore
    strcpy(u->path, s);
    1650:	aa1403e1 	mov	x1, x20
    1654:	17ffffef 	b	1610 <parse_url+0xf8>

0000000000001658 <header.constprop.0>:
header(const char *hdr, const char *name, char *out, int cap)
    1658:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    165c:	910003fd 	mov	x29, sp
    1660:	a90153f3 	stp	x19, x20, [sp, #16]
    1664:	aa0103f3 	mov	x19, x1
    1668:	a9025bf5 	stp	x21, x22, [sp, #32]
    166c:	2a0203f5 	mov	w21, w2
    1670:	f9001bf7 	str	x23, [sp, #48]
    1674:	aa0003f7 	mov	x23, x0
  int nl = strlen(name);
    1678:	97fffca0 	bl	8f8 <strlen@plt>
    167c:	93407c14 	sxtw	x20, w0
    1680:	aa1403f6 	mov	x22, x20
  const char *p = strchr(hdr, '\n');
    1684:	b0000000 	adrp	x0, 2000 <_DYNAMIC>
    1688:	91281000 	add	x0, x0, #0xa04
    168c:	52800141 	mov	w1, #0xa                   	// #10
    p = strchr(p, '\n');
    1690:	97fffca2 	bl	918 <strchr@plt>
  while(p && p[1]){
    1694:	b4000060 	cbz	x0, 16a0 <header.constprop.0+0x48>
    1698:	39400401 	ldrb	w1, [x0, #1]
    169c:	35000061 	cbnz	w1, 16a8 <header.constprop.0+0x50>
  return -1;
    16a0:	12800000 	mov	w0, #0xffffffff            	// #-1
    16a4:	14000020 	b	1724 <header.constprop.0+0xcc>
    p++;
    16a8:	91000409 	add	x9, x0, #0x1
    if(strncaseeq(p, name, nl) && p[nl] == ':'){
    16ac:	2a1603e2 	mov	w2, w22
    16b0:	aa1703e1 	mov	x1, x23
    16b4:	aa0903e0 	mov	x0, x9
    16b8:	97ffff83 	bl	14c4 <strncaseeq>
    16bc:	34000480 	cbz	w0, 174c <header.constprop.0+0xf4>
    16c0:	38746920 	ldrb	w0, [x9, x20]
    16c4:	7100e81f 	cmp	w0, #0x3a
    16c8:	54000421 	b.ne	174c <header.constprop.0+0xf4>  // b.any
      p += nl + 1;
    16cc:	91000694 	add	x20, x20, #0x1
    16d0:	8b140129 	add	x9, x9, x20
      while(*p == ' ' || *p == '\t')
    16d4:	39400120 	ldrb	w0, [x9]
    16d8:	7100801f 	cmp	w0, #0x20
    16dc:	7a491804 	ccmp	w0, #0x9, #0x4, ne	// ne = any
    16e0:	540002c0 	b.eq	1738 <header.constprop.0+0xe0>  // b.none
      while(*p && *p != '\r' && *p != '\n' && i < cap - 1)
    16e4:	52803fe0 	mov	w0, #0x1ff                 	// #511
    16e8:	710082bf 	cmp	w21, #0x20
    16ec:	528003e1 	mov	w1, #0x1f                  	// #31
    16f0:	92848024 	mov	x4, #0xffffffffffffdbfe    	// #-9218
    16f4:	1a800021 	csel	w1, w1, w0, eq	// eq = none
    16f8:	d2800000 	mov	x0, #0x0                   	// #0
    16fc:	38606922 	ldrb	w2, [x9, x0]
    1700:	8b000263 	add	x3, x19, x0
    1704:	7100345f 	cmp	w2, #0xd
    1708:	54000068 	b.hi	1714 <header.constprop.0+0xbc>  // b.pmore
    170c:	9ac22885 	asr	x5, x4, x2
    1710:	36000065 	tbz	w5, #0, 171c <header.constprop.0+0xc4>
    1714:	6b00003f 	cmp	w1, w0
    1718:	5400014c 	b.gt	1740 <header.constprop.0+0xe8>
      return 0;
    171c:	52800000 	mov	w0, #0x0                   	// #0
      out[i] = 0;
    1720:	3900007f 	strb	wzr, [x3]
}
    1724:	f9401bf7 	ldr	x23, [sp, #48]
    1728:	a94153f3 	ldp	x19, x20, [sp, #16]
    172c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1730:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1734:	d65f03c0 	ret
        p++;
    1738:	91000529 	add	x9, x9, #0x1
    173c:	17ffffe6 	b	16d4 <header.constprop.0+0x7c>
        out[i++] = *p++;
    1740:	38206a62 	strb	w2, [x19, x0]
    1744:	91000400 	add	x0, x0, #0x1
    1748:	17ffffed 	b	16fc <header.constprop.0+0xa4>
    p = strchr(p, '\n');
    174c:	aa0903e0 	mov	x0, x9
    1750:	52800141 	mov	w1, #0xa                   	// #10
    1754:	17ffffcf 	b	1690 <header.constprop.0+0x38>
