
user/_evtest:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002e8 <.plt>:
 2e8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2ec:	b0000010 	adrp	x16, 1000 <main+0xca8>
 2f0:	f9431211 	ldr	x17, [x16, #1568]
 2f4:	91188210 	add	x16, x16, #0x620
 2f8:	d61f0220 	br	x17
 2fc:	d503201f 	nop
 300:	d503201f 	nop
 304:	d503201f 	nop

0000000000000308 <printf@plt>:
 308:	b0000010 	adrp	x16, 1000 <main+0xca8>
 30c:	f9431611 	ldr	x17, [x16, #1576]
 310:	9118a210 	add	x16, x16, #0x628
 314:	d61f0220 	br	x17

0000000000000318 <read@plt>:
 318:	b0000010 	adrp	x16, 1000 <main+0xca8>
 31c:	f9431a11 	ldr	x17, [x16, #1584]
 320:	9118c210 	add	x16, x16, #0x630
 324:	d61f0220 	br	x17

0000000000000328 <exit@plt>:
 328:	b0000010 	adrp	x16, 1000 <main+0xca8>
 32c:	f9431e11 	ldr	x17, [x16, #1592]
 330:	9118e210 	add	x16, x16, #0x638
 334:	d61f0220 	br	x17

0000000000000338 <open@plt>:
 338:	b0000010 	adrp	x16, 1000 <main+0xca8>
 33c:	f9432211 	ldr	x17, [x16, #1600]
 340:	91190210 	add	x16, x16, #0x640
 344:	d61f0220 	br	x17

0000000000000348 <close@plt>:
 348:	b0000010 	adrp	x16, 1000 <main+0xca8>
 34c:	f9432611 	ldr	x17, [x16, #1608]
 350:	91192210 	add	x16, x16, #0x648
 354:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000358 <main>:
  int value;
};

int
main(int argc, char **argv)
{
 358:	a9b47bfd 	stp	x29, x30, [sp, #-192]!
 35c:	910003fd 	mov	x29, sp
 360:	a90153f3 	stp	x19, x20, [sp, #16]
 364:	a9025bf5 	stp	x21, x22, [sp, #32]
 368:	a90363f7 	stp	x23, x24, [sp, #48]
  char *path = argc > 1 ? argv[1] : "/dev/input/event0";
 36c:	7100041f 	cmp	w0, #0x1
 370:	540001ad 	b.le	3a4 <main+0x4c>
 374:	f9400433 	ldr	x19, [x1, #8]
  struct input_event events[16];
  int fd = open(path, O_RDONLY);
 378:	aa1303e0 	mov	x0, x19
 37c:	52800001 	mov	w1, #0x0                   	// #0
 380:	97ffffee 	bl	338 <open@plt>
 384:	2a0003f8 	mov	w24, w0
  if(fd < 0){
 388:	36f80140 	tbz	w0, #31, 3b0 <main+0x58>
    printf("evtest: cannot open %s (empty input slot?)\n", path);
 38c:	aa1303e1 	mov	x1, x19
 390:	90000000 	adrp	x0, 0 <.plt-0x2e8>
 394:	91111800 	add	x0, x0, #0x446
 398:	97ffffdc 	bl	308 <printf@plt>
    exit(1);
 39c:	52800020 	mov	w0, #0x1                   	// #1
      printf("event type=%d code=%d value=%d\n",
             ev->type, ev->code, ev->value);
    }
  }
  close(fd);
  exit(0);
 3a0:	97ffffe2 	bl	328 <exit@plt>
  char *path = argc > 1 ? argv[1] : "/dev/input/event0";
 3a4:	90000013 	adrp	x19, 0 <.plt-0x2e8>
 3a8:	9110d273 	add	x19, x19, #0x434
 3ac:	17fffff3 	b	378 <main+0x20>
      printf("event type=%d code=%d value=%d\n",
 3b0:	90000017 	adrp	x23, 0 <.plt-0x2e8>
 3b4:	911306f7 	add	x23, x23, #0x4c1
    int n = read(fd, events, sizeof(events));
 3b8:	910103f6 	add	x22, sp, #0x40
  printf("evtest: reading %s; unplug returns from blocked read\n", path);
 3bc:	aa1303e1 	mov	x1, x19
 3c0:	90000000 	adrp	x0, 0 <.plt-0x2e8>
 3c4:	9111c800 	add	x0, x0, #0x472
 3c8:	97ffffd0 	bl	308 <printf@plt>
    int n = read(fd, events, sizeof(events));
 3cc:	aa1603e1 	mov	x1, x22
 3d0:	2a1803e0 	mov	w0, w24
 3d4:	52801002 	mov	w2, #0x80                  	// #128
 3d8:	97ffffd0 	bl	318 <read@plt>
    if(n <= 0){
 3dc:	7100001f 	cmp	w0, #0x0
 3e0:	540001ad 	b.le	414 <main+0xbc>
 3e4:	121d7015 	and	w21, w0, #0xfffffff8
    for(int i = 0; i + (int)sizeof(events[0]) <= n;
 3e8:	52800014 	mov	w20, #0x0                   	// #0
 3ec:	6b15029f 	cmp	w20, w21
 3f0:	54fffee0 	b.eq	3cc <main+0x74>  // b.none
      struct input_event *ev = (struct input_event *)((char *)events + i);
 3f4:	8b3442c0 	add	x0, x22, w20, uxtw
      printf("event type=%d code=%d value=%d\n",
 3f8:	78744ac1 	ldrh	w1, [x22, w20, uxtw]
 3fc:	11002294 	add	w20, w20, #0x8
 400:	79400402 	ldrh	w2, [x0, #2]
 404:	b9400403 	ldr	w3, [x0, #4]
 408:	aa1703e0 	mov	x0, x23
 40c:	97ffffbf 	bl	308 <printf@plt>
        i += sizeof(events[0])){
 410:	17fffff7 	b	3ec <main+0x94>
      printf("evtest: %s disconnected\n", path);
 414:	aa1303e1 	mov	x1, x19
 418:	90000000 	adrp	x0, 0 <.plt-0x2e8>
 41c:	9112a000 	add	x0, x0, #0x4a8
 420:	97ffffba 	bl	308 <printf@plt>
  close(fd);
 424:	2a1803e0 	mov	w0, w24
 428:	97ffffc8 	bl	348 <close@plt>
  exit(0);
 42c:	52800000 	mov	w0, #0x0                   	// #0
 430:	17ffffdc 	b	3a0 <main+0x48>
