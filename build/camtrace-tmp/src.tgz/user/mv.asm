
user/_mv:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000278 <.plt>:
 278:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 27c:	b0000010 	adrp	x16, 1000 <main+0xd38>
 280:	f9424e11 	ldr	x17, [x16, #1176]
 284:	91126210 	add	x16, x16, #0x498
 288:	d61f0220 	br	x17
 28c:	d503201f 	nop
 290:	d503201f 	nop
 294:	d503201f 	nop

0000000000000298 <rename@plt>:
 298:	b0000010 	adrp	x16, 1000 <main+0xd38>
 29c:	f9425211 	ldr	x17, [x16, #1184]
 2a0:	91128210 	add	x16, x16, #0x4a0
 2a4:	d61f0220 	br	x17

00000000000002a8 <fprintf@plt>:
 2a8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2ac:	f9425611 	ldr	x17, [x16, #1192]
 2b0:	9112a210 	add	x16, x16, #0x4a8
 2b4:	d61f0220 	br	x17

00000000000002b8 <exit@plt>:
 2b8:	b0000010 	adrp	x16, 1000 <main+0xd38>
 2bc:	f9425a11 	ldr	x17, [x16, #1200]
 2c0:	9112c210 	add	x16, x16, #0x4b0
 2c4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000002c8 <main>:
#include <uapi/types.h>
#include "user/user.h"

int
main(int argc, char *argv[])
{
 2c8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 2cc:	910003fd 	mov	x29, sp
 2d0:	f9000bf3 	str	x19, [sp, #16]
  if(argc != 3){
 2d4:	71000c1f 	cmp	w0, #0x3
 2d8:	540000e0 	b.eq	2f4 <main+0x2c>  // b.none
    fprintf(2, "Usage: mv old-path new-path\n");
 2dc:	90000001 	adrp	x1, 0 <.plt-0x278>
 2e0:	910c9021 	add	x1, x1, #0x324
 2e4:	52800040 	mov	w0, #0x2                   	// #2
 2e8:	97fffff0 	bl	2a8 <fprintf@plt>
    exit(1);
  }
  if(rename(argv[1], argv[2]) < 0){
    fprintf(2, "mv: cannot rename %s to %s\n", argv[1], argv[2]);
    exit(1);
 2ec:	52800020 	mov	w0, #0x1                   	// #1
 2f0:	97fffff2 	bl	2b8 <exit@plt>
 2f4:	aa0103f3 	mov	x19, x1
  if(rename(argv[1], argv[2]) < 0){
 2f8:	a9408420 	ldp	x0, x1, [x1, #8]
 2fc:	97ffffe7 	bl	298 <rename@plt>
 300:	36f800e0 	tbz	w0, #31, 31c <main+0x54>
    fprintf(2, "mv: cannot rename %s to %s\n", argv[1], argv[2]);
 304:	a9408e62 	ldp	x2, x3, [x19, #8]
 308:	90000001 	adrp	x1, 0 <.plt-0x278>
 30c:	910d0421 	add	x1, x1, #0x341
 310:	52800040 	mov	w0, #0x2                   	// #2
 314:	97ffffe5 	bl	2a8 <fprintf@plt>
 318:	17fffff5 	b	2ec <main+0x24>
  }
  exit(0);
 31c:	52800000 	mov	w0, #0x0                   	// #0
 320:	17fffff4 	b	2f0 <main+0x28>
