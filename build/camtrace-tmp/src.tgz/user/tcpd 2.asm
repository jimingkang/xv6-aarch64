
user/_tcpd:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000004a0 <.plt>:
 4a0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 4a4:	b0000010 	adrp	x16, 1000 <main+0xa80>
 4a8:	f944e211 	ldr	x17, [x16, #2496]
 4ac:	91270210 	add	x16, x16, #0x9c0
 4b0:	d61f0220 	br	x17
 4b4:	d503201f 	nop
 4b8:	d503201f 	nop
 4bc:	d503201f 	nop

00000000000004c0 <socket_accept@plt>:
 4c0:	b0000010 	adrp	x16, 1000 <main+0xa80>
 4c4:	f944e611 	ldr	x17, [x16, #2504]
 4c8:	91272210 	add	x16, x16, #0x9c8
 4cc:	d61f0220 	br	x17

00000000000004d0 <printf@plt>:
 4d0:	b0000010 	adrp	x16, 1000 <main+0xa80>
 4d4:	f944ea11 	ldr	x17, [x16, #2512]
 4d8:	91274210 	add	x16, x16, #0x9d0
 4dc:	d61f0220 	br	x17

00000000000004e0 <epoll_wait@plt>:
 4e0:	b0000010 	adrp	x16, 1000 <main+0xa80>
 4e4:	f944ee11 	ldr	x17, [x16, #2520]
 4e8:	91276210 	add	x16, x16, #0x9d8
 4ec:	d61f0220 	br	x17

00000000000004f0 <epoll_ctl@plt>:
 4f0:	b0000010 	adrp	x16, 1000 <main+0xa80>
 4f4:	f944f211 	ldr	x17, [x16, #2528]
 4f8:	91278210 	add	x16, x16, #0x9e0
 4fc:	d61f0220 	br	x17

0000000000000500 <write@plt>:
 500:	b0000010 	adrp	x16, 1000 <main+0xa80>
 504:	f944f611 	ldr	x17, [x16, #2536]
 508:	9127a210 	add	x16, x16, #0x9e8
 50c:	d61f0220 	br	x17

0000000000000510 <read@plt>:
 510:	b0000010 	adrp	x16, 1000 <main+0xa80>
 514:	f944fa11 	ldr	x17, [x16, #2544]
 518:	9127c210 	add	x16, x16, #0x9f0
 51c:	d61f0220 	br	x17

0000000000000520 <epoll_create@plt>:
 520:	b0000010 	adrp	x16, 1000 <main+0xa80>
 524:	f944fe11 	ldr	x17, [x16, #2552]
 528:	9127e210 	add	x16, x16, #0x9f8
 52c:	d61f0220 	br	x17

0000000000000530 <socket_listen@plt>:
 530:	b0000010 	adrp	x16, 1000 <main+0xa80>
 534:	f9450211 	ldr	x17, [x16, #2560]
 538:	91280210 	add	x16, x16, #0xa00
 53c:	d61f0220 	br	x17

0000000000000540 <exit@plt>:
 540:	b0000010 	adrp	x16, 1000 <main+0xa80>
 544:	f9450611 	ldr	x17, [x16, #2568]
 548:	91282210 	add	x16, x16, #0xa08
 54c:	d61f0220 	br	x17

0000000000000550 <atoi@plt>:
 550:	b0000010 	adrp	x16, 1000 <main+0xa80>
 554:	f9450a11 	ldr	x17, [x16, #2576]
 558:	91284210 	add	x16, x16, #0xa10
 55c:	d61f0220 	br	x17

0000000000000560 <fcntl@plt>:
 560:	b0000010 	adrp	x16, 1000 <main+0xa80>
 564:	f9450e11 	ldr	x17, [x16, #2584]
 568:	91286210 	add	x16, x16, #0xa18
 56c:	d61f0220 	br	x17

0000000000000570 <close@plt>:
 570:	b0000010 	adrp	x16, 1000 <main+0xa80>
 574:	f9451211 	ldr	x17, [x16, #2592]
 578:	91288210 	add	x16, x16, #0xa20
 57c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000580 <main>:

// TCP byte-stream smoke test used before the SSH transport is enabled.
// From another machine: nc <wlan0-ip> 2222
int
main(int argc, char **argv)
{
 580:	a9a17bfd 	stp	x29, x30, [sp, #-496]!
 584:	910003fd 	mov	x29, sp
 588:	a90153f3 	stp	x19, x20, [sp, #16]
 58c:	a9025bf5 	stp	x21, x22, [sp, #32]
 590:	a90363f7 	stp	x23, x24, [sp, #48]
 594:	a9046bf9 	stp	x25, x26, [sp, #64]
  char buf[256];
  struct epoll_event event, events[8];
  int port = 2222, listener, epfd, n;
  if(argc > 1)
 598:	7100041f 	cmp	w0, #0x1
 59c:	540001ed 	b.le	5d8 <main+0x58>
    port = atoi(argv[1]);
 5a0:	f9400420 	ldr	x0, [x1, #8]
 5a4:	97ffffeb 	bl	550 <atoi@plt>
 5a8:	2a0003f4 	mov	w20, w0
  listener = socket_listen(port, 10);
 5ac:	2a1403e0 	mov	w0, w20
 5b0:	52800141 	mov	w1, #0xa                   	// #10
 5b4:	97ffffdf 	bl	530 <socket_listen@plt>
 5b8:	2a0003f3 	mov	w19, w0
  if(listener < 0){
 5bc:	36f80120 	tbz	w0, #31, 5e0 <main+0x60>
    printf("tcpd: cannot listen on %d\n", port);
 5c0:	90000000 	adrp	x0, 0 <.plt-0x4a0>
 5c4:	911e2000 	add	x0, x0, #0x788
 5c8:	2a1403e1 	mov	w1, w20
 5cc:	97ffffc1 	bl	4d0 <printf@plt>
    exit(1);
  }
  printf("tcpd: waiting on port %d\n", port);
  if(fcntl(listener, F_SETFL, O_NONBLOCK) < 0){
    printf("tcpd: cannot set listener non-blocking\n");
    exit(1);
 5d0:	52800020 	mov	w0, #0x1                   	// #1
 5d4:	97ffffdb 	bl	540 <exit@plt>
  int port = 2222, listener, epfd, n;
 5d8:	528115d4 	mov	w20, #0x8ae                 	// #2222
 5dc:	17fffff4 	b	5ac <main+0x2c>
  printf("tcpd: waiting on port %d\n", port);
 5e0:	2a1403e1 	mov	w1, w20
 5e4:	90000000 	adrp	x0, 0 <.plt-0x4a0>
 5e8:	911e8c00 	add	x0, x0, #0x7a3
 5ec:	97ffffb9 	bl	4d0 <printf@plt>
  if(fcntl(listener, F_SETFL, O_NONBLOCK) < 0){
 5f0:	2a1303e0 	mov	w0, w19
 5f4:	52810002 	mov	w2, #0x800                 	// #2048
 5f8:	52800081 	mov	w1, #0x4                   	// #4
 5fc:	97ffffd9 	bl	560 <fcntl@plt>
 600:	36f800a0 	tbz	w0, #31, 614 <main+0x94>
    printf("tcpd: cannot set listener non-blocking\n");
 604:	90000000 	adrp	x0, 0 <.plt-0x4a0>
 608:	911ef400 	add	x0, x0, #0x7bd
 60c:	97ffffb1 	bl	4d0 <printf@plt>
 610:	17fffff0 	b	5d0 <main+0x50>
  }
  epfd = epoll_create();
 614:	97ffffc3 	bl	520 <epoll_create@plt>
 618:	2a0003f6 	mov	w22, w0
  if(epfd < 0){
 61c:	36f800e0 	tbz	w0, #31, 638 <main+0xb8>
    printf("tcpd: epoll_create failed\n");
 620:	90000000 	adrp	x0, 0 <.plt-0x4a0>
 624:	911f9400 	add	x0, x0, #0x7e5
 628:	97ffffaa 	bl	4d0 <printf@plt>
        }
      }
    }
  }
  close(epfd);
  close(listener);
 62c:	2a1303e0 	mov	w0, w19
 630:	97ffffd0 	bl	570 <close@plt>
  exit(1);
 634:	17ffffe7 	b	5d0 <main+0x50>
  event.events = EPOLLIN;
 638:	52800034 	mov	w20, #0x1                   	// #1
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, listener, &event) < 0){
 63c:	910183e3 	add	x3, sp, #0x60
 640:	2a1303e2 	mov	w2, w19
 644:	2a1403e1 	mov	w1, w20
  event.events = EPOLLIN;
 648:	b90063f4 	str	w20, [sp, #96]
  event.data.fd = listener;
 64c:	b9006bf3 	str	w19, [sp, #104]
  if(epoll_ctl(epfd, EPOLL_CTL_ADD, listener, &event) < 0){
 650:	97ffffa8 	bl	4f0 <epoll_ctl@plt>
 654:	37f805a0 	tbnz	w0, #31, 708 <main+0x188>
          printf("tcpd: client fd=%d disconnected\n", fd);
 658:	90000017 	adrp	x23, 0 <.plt-0x4a0>
 65c:	91219ef7 	add	x23, x23, #0x867
        printf("tcpd: client connected listener-fd=%d connection-fd=%d\n",
 660:	90000018 	adrp	x24, 0 <.plt-0x4a0>
 664:	91207718 	add	x24, x24, #0x81d
    n = epoll_wait(epfd, events, 8, -1);
 668:	9101c3e1 	add	x1, sp, #0x70
 66c:	2a1603e0 	mov	w0, w22
 670:	12800003 	mov	w3, #0xffffffff            	// #-1
 674:	52800102 	mov	w2, #0x8                   	// #8
 678:	97ffff9a 	bl	4e0 <epoll_wait@plt>
 67c:	2a0003fa 	mov	w26, w0
    if(n < 0)
 680:	37f807e0 	tbnz	w0, #31, 77c <main+0x1fc>
 684:	9101c3f5 	add	x21, sp, #0x70
    for(int i = 0; i < n; i++){
 688:	52800019 	mov	w25, #0x0                   	// #0
 68c:	6b1a033f 	cmp	w25, w26
 690:	54fffec0 	b.eq	668 <main+0xe8>  // b.none
      int fd = events[i].data.fd;
 694:	b9400ab4 	ldr	w20, [x21, #8]
      if(fd == listener){
 698:	6b14027f 	cmp	w19, w20
 69c:	540003c1 	b.ne	714 <main+0x194>  // b.any
        int connection = socket_accept(listener);
 6a0:	2a1303e0 	mov	w0, w19
 6a4:	97ffff87 	bl	4c0 <socket_accept@plt>
 6a8:	2a0003f4 	mov	w20, w0
        if(connection < 0)
 6ac:	37f80280 	tbnz	w0, #31, 6fc <main+0x17c>
        printf("tcpd: client connected listener-fd=%d connection-fd=%d\n",
 6b0:	2a0003e2 	mov	w2, w0
 6b4:	2a1303e1 	mov	w1, w19
 6b8:	aa1803e0 	mov	x0, x24
 6bc:	97ffff85 	bl	4d0 <printf@plt>
        write(connection, "xv6 socket ready\n", 17);
 6c0:	52800222 	mov	w2, #0x11                  	// #17
 6c4:	2a1403e0 	mov	w0, w20
 6c8:	90000001 	adrp	x1, 0 <.plt-0x4a0>
 6cc:	91215421 	add	x1, x1, #0x855
 6d0:	97ffff8c 	bl	500 <write@plt>
        event.data.fd = connection;
 6d4:	b9006bf4 	str	w20, [sp, #104]
        event.events = EPOLLIN;
 6d8:	52800021 	mov	w1, #0x1                   	// #1
        if(epoll_ctl(epfd, EPOLL_CTL_ADD, connection, &event) < 0)
 6dc:	910183e3 	add	x3, sp, #0x60
 6e0:	2a1403e2 	mov	w2, w20
 6e4:	2a1603e0 	mov	w0, w22
        event.events = EPOLLIN;
 6e8:	b90063e1 	str	w1, [sp, #96]
        if(epoll_ctl(epfd, EPOLL_CTL_ADD, connection, &event) < 0)
 6ec:	97ffff81 	bl	4f0 <epoll_ctl@plt>
 6f0:	36f80060 	tbz	w0, #31, 6fc <main+0x17c>
          close(connection);
 6f4:	2a1403e0 	mov	w0, w20
 6f8:	97ffff9e 	bl	570 <close@plt>
    for(int i = 0; i < n; i++){
 6fc:	11000739 	add	w25, w25, #0x1
 700:	910042b5 	add	x21, x21, #0x10
 704:	17ffffe2 	b	68c <main+0x10c>
    printf("tcpd: cannot watch listener\n");
 708:	90000000 	adrp	x0, 0 <.plt-0x4a0>
 70c:	91200000 	add	x0, x0, #0x800
 710:	17ffffbf 	b	60c <main+0x8c>
        int got = read(fd, buf, sizeof(buf));
 714:	52802002 	mov	w2, #0x100                 	// #256
 718:	9103c3e1 	add	x1, sp, #0xf0
 71c:	2a1403e0 	mov	w0, w20
 720:	97ffff7c 	bl	510 <read@plt>
 724:	2a0003e2 	mov	w2, w0
        if(got <= 0 || write(fd, buf, got) != got){
 728:	7100001f 	cmp	w0, #0x0
 72c:	5400018c 	b.gt	75c <main+0x1dc>
          epoll_ctl(epfd, EPOLL_CTL_DEL, fd, 0);
 730:	2a1403e2 	mov	w2, w20
 734:	d2800003 	mov	x3, #0x0                   	// #0
 738:	52800041 	mov	w1, #0x2                   	// #2
 73c:	2a1603e0 	mov	w0, w22
 740:	97ffff6c 	bl	4f0 <epoll_ctl@plt>
          close(fd);
 744:	2a1403e0 	mov	w0, w20
 748:	97ffff8a 	bl	570 <close@plt>
          printf("tcpd: client fd=%d disconnected\n", fd);
 74c:	2a1403e1 	mov	w1, w20
 750:	aa1703e0 	mov	x0, x23
 754:	97ffff5f 	bl	4d0 <printf@plt>
 758:	17ffffe9 	b	6fc <main+0x17c>
        if(got <= 0 || write(fd, buf, got) != got){
 75c:	9103c3e1 	add	x1, sp, #0xf0
 760:	2a1403e0 	mov	w0, w20
 764:	b9005fe2 	str	w2, [sp, #92]
 768:	97ffff66 	bl	500 <write@plt>
 76c:	b9405fe2 	ldr	w2, [sp, #92]
 770:	6b02001f 	cmp	w0, w2
 774:	54fffde1 	b.ne	730 <main+0x1b0>  // b.any
 778:	17ffffe1 	b	6fc <main+0x17c>
  close(epfd);
 77c:	2a1603e0 	mov	w0, w22
 780:	97ffff7c 	bl	570 <close@plt>
 784:	17ffffaa 	b	62c <main+0xac>
