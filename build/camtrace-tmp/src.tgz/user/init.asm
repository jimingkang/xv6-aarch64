
user/_init:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000005f0 <.plt>:
 5f0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 5f4:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 5f8:	f940b611 	ldr	x17, [x16, #360]
 5fc:	9105a210 	add	x16, x16, #0x168
 600:	d61f0220 	br	x17
 604:	d503201f 	nop
 608:	d503201f 	nop
 60c:	d503201f 	nop

0000000000000610 <printf@plt>:
 610:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 614:	f940ba11 	ldr	x17, [x16, #368]
 618:	9105c210 	add	x16, x16, #0x170
 61c:	d61f0220 	br	x17

0000000000000620 <mknod@plt>:
 620:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 624:	f940be11 	ldr	x17, [x16, #376]
 628:	9105e210 	add	x16, x16, #0x178
 62c:	d61f0220 	br	x17

0000000000000630 <write@plt>:
 630:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 634:	f940c211 	ldr	x17, [x16, #384]
 638:	91060210 	add	x16, x16, #0x180
 63c:	d61f0220 	br	x17

0000000000000640 <exec@plt>:
 640:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 644:	f940c611 	ldr	x17, [x16, #392]
 648:	91062210 	add	x16, x16, #0x188
 64c:	d61f0220 	br	x17

0000000000000650 <wait@plt>:
 650:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 654:	f940ca11 	ldr	x17, [x16, #400]
 658:	91064210 	add	x16, x16, #0x190
 65c:	d61f0220 	br	x17

0000000000000660 <read@plt>:
 660:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 664:	f940ce11 	ldr	x17, [x16, #408]
 668:	91066210 	add	x16, x16, #0x198
 66c:	d61f0220 	br	x17

0000000000000670 <unlink@plt>:
 670:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 674:	f940d211 	ldr	x17, [x16, #416]
 678:	91068210 	add	x16, x16, #0x1a0
 67c:	d61f0220 	br	x17

0000000000000680 <fork@plt>:
 680:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 684:	f940d611 	ldr	x17, [x16, #424]
 688:	9106a210 	add	x16, x16, #0x1a8
 68c:	d61f0220 	br	x17

0000000000000690 <mount@plt>:
 690:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 694:	f940da11 	ldr	x17, [x16, #432]
 698:	9106c210 	add	x16, x16, #0x1b0
 69c:	d61f0220 	br	x17

00000000000006a0 <strcmp@plt>:
 6a0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 6a4:	f940de11 	ldr	x17, [x16, #440]
 6a8:	9106e210 	add	x16, x16, #0x1b8
 6ac:	d61f0220 	br	x17

00000000000006b0 <dup@plt>:
 6b0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 6b4:	f940e211 	ldr	x17, [x16, #448]
 6b8:	91070210 	add	x16, x16, #0x1c0
 6bc:	d61f0220 	br	x17

00000000000006c0 <exit@plt>:
 6c0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 6c4:	f940e611 	ldr	x17, [x16, #456]
 6c8:	91072210 	add	x16, x16, #0x1c8
 6cc:	d61f0220 	br	x17

00000000000006d0 <strlen@plt>:
 6d0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 6d4:	f940ea11 	ldr	x17, [x16, #464]
 6d8:	91074210 	add	x16, x16, #0x1d0
 6dc:	d61f0220 	br	x17

00000000000006e0 <open@plt>:
 6e0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 6e4:	f940ee11 	ldr	x17, [x16, #472]
 6e8:	91076210 	add	x16, x16, #0x1d8
 6ec:	d61f0220 	br	x17

00000000000006f0 <mkdir@plt>:
 6f0:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 6f4:	f940f211 	ldr	x17, [x16, #480]
 6f8:	91078210 	add	x16, x16, #0x1e0
 6fc:	d61f0220 	br	x17

0000000000000700 <close@plt>:
 700:	b0000010 	adrp	x16, 1000 <_DYNAMIC>
 704:	f940f611 	ldr	x17, [x16, #488]
 708:	9107a210 	add	x16, x16, #0x1e8
 70c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000710 <main>:
  }
}

int
main(void)
{
 710:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  int pid, wpid;

  // The kernel has mounted devtmpfs on /dev with a node for every driver
  // (see kernel/do_mounts.c).  Only if that is missing -- an old kernel or a
  // root without a /dev directory -- create static nodes on the root disk.
  unlink("/console");  // Remove the obsolete root-level compatibility node.
 714:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 718:	912f5000 	add	x0, x0, #0xbd4
{
 71c:	910003fd 	mov	x29, sp
 720:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("/console");  // Remove the obsolete root-level compatibility node.
 724:	97ffffd3 	bl	670 <unlink@plt>
  if(open("/dev/ttyS0", O_RDWR) < 0 &&
 728:	90000014 	adrp	x20, 0 <.plt-0x5f0>
 72c:	52800041 	mov	w1, #0x2                   	// #2
 730:	912f1680 	add	x0, x20, #0xbc5
 734:	97ffffeb 	bl	6e0 <open@plt>
 738:	36f80820 	tbz	w0, #31, 83c <main+0x12c>
     open("/dev/console", O_RDWR) < 0){
 73c:	90000013 	adrp	x19, 0 <.plt-0x5f0>
 740:	52800041 	mov	w1, #0x2                   	// #2
 744:	912f4260 	add	x0, x19, #0xbd0
 748:	97ffffe6 	bl	6e0 <open@plt>
  if(open("/dev/ttyS0", O_RDWR) < 0 &&
 74c:	36f80780 	tbz	w0, #31, 83c <main+0x12c>
    mkdir("dev");
 750:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 754:	912f7400 	add	x0, x0, #0xbdd
 758:	97ffffe6 	bl	6f0 <mkdir@plt>
    mkdir("dev/input");
 75c:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 760:	912f8400 	add	x0, x0, #0xbe1
 764:	97ffffe3 	bl	6f0 <mkdir@plt>
    mknod("dev/console", T_DEVICE, mkdev(CONSOLE, 0));
 768:	d2a00022 	mov	x2, #0x10000               	// #65536
 76c:	52800061 	mov	w1, #0x3                   	// #3
 770:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 774:	912f4400 	add	x0, x0, #0xbd1
 778:	97ffffaa 	bl	620 <mknod@plt>
    mknod("dev/tty", T_DEVICE, mkdev(TTY, 0));
 77c:	d2a00042 	mov	x2, #0x20000               	// #131072
 780:	52800061 	mov	w1, #0x3                   	// #3
 784:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 788:	912fac00 	add	x0, x0, #0xbeb
 78c:	97ffffa5 	bl	620 <mknod@plt>
    mknod("dev/ttyS0", T_DEVICE, mkdev(TTYS0, 0));
 790:	d2a00062 	mov	x2, #0x30000               	// #196608
 794:	52800061 	mov	w1, #0x3                   	// #3
 798:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 79c:	912f1800 	add	x0, x0, #0xbc6
 7a0:	97ffffa0 	bl	620 <mknod@plt>
    mknod("dev/input/event0", T_DEVICE, mkdev(INPUT, 0));
 7a4:	d2a00082 	mov	x2, #0x40000               	// #262144
 7a8:	52800061 	mov	w1, #0x3                   	// #3
 7ac:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 7b0:	912fcc00 	add	x0, x0, #0xbf3
 7b4:	97ffff9b 	bl	620 <mknod@plt>
    mknod("dev/input/event1", T_DEVICE, mkdev(INPUT, 1));
 7b8:	52800061 	mov	w1, #0x3                   	// #3
 7bc:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 7c0:	91301000 	add	x0, x0, #0xc04
 7c4:	d2800022 	mov	x2, #0x1                   	// #1
 7c8:	f2a00082 	movk	x2, #0x4, lsl #16
 7cc:	97ffff95 	bl	620 <mknod@plt>
    mknod("dev/input/event2", T_DEVICE, mkdev(INPUT, 2));
 7d0:	52800061 	mov	w1, #0x3                   	// #3
 7d4:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 7d8:	91305400 	add	x0, x0, #0xc15
 7dc:	d2800042 	mov	x2, #0x2                   	// #2
 7e0:	f2a00082 	movk	x2, #0x4, lsl #16
 7e4:	97ffff8f 	bl	620 <mknod@plt>
    mknod("dev/input/event3", T_DEVICE, mkdev(INPUT, 3));
 7e8:	52800061 	mov	w1, #0x3                   	// #3
 7ec:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 7f0:	91309800 	add	x0, x0, #0xc26
 7f4:	d2800062 	mov	x2, #0x3                   	// #3
 7f8:	f2a00082 	movk	x2, #0x4, lsl #16
 7fc:	97ffff89 	bl	620 <mknod@plt>
    mknod("dev/video0", T_DEVICE, mkdev(CAMERA, 0));
 800:	d2a000a2 	mov	x2, #0x50000               	// #327680
 804:	52800061 	mov	w1, #0x3                   	// #3
 808:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 80c:	9130dc00 	add	x0, x0, #0xc37
 810:	97ffff84 	bl	620 <mknod@plt>
    if(open("/dev/ttyS0", O_RDWR) < 0 &&
 814:	912f1680 	add	x0, x20, #0xbc5
 818:	52800041 	mov	w1, #0x2                   	// #2
 81c:	97ffffb1 	bl	6e0 <open@plt>
 820:	36f800e0 	tbz	w0, #31, 83c <main+0x12c>
       open("/dev/console", O_RDWR) < 0)
 824:	912f4260 	add	x0, x19, #0xbd0
 828:	52800041 	mov	w1, #0x2                   	// #2
 82c:	97ffffad 	bl	6e0 <open@plt>
    if(open("/dev/ttyS0", O_RDWR) < 0 &&
 830:	36f80060 	tbz	w0, #31, 83c <main+0x12c>
  printf("init: connecting Wi-Fi from /etc/wifi.conf\n");
  pid = fork();
  if(pid == 0){
    exec("/bin/wifi", wifi_argv);
    printf("init: exec /bin/wifi failed\n");
    exit(1);
 834:	52800020 	mov	w0, #0x1                   	// #1
 838:	97ffffa2 	bl	6c0 <exit@plt>
  dup(0);
 83c:	52800000 	mov	w0, #0x0                   	// #0
 840:	97ffff9c 	bl	6b0 <dup@plt>
  dup(0);
 844:	52800000 	mov	w0, #0x0                   	// #0
 848:	97ffff9a 	bl	6b0 <dup@plt>
  create_config("etc/hostname", "xv6-rpi3\n");
 84c:	90000001 	adrp	x1, 0 <.plt-0x5f0>
 850:	91310821 	add	x1, x1, #0xc42
 854:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 858:	91313000 	add	x0, x0, #0xc4c
 85c:	940000bb 	bl	b48 <create_config>
  create_config("etc/passwd", "root:xv6:0:0:root:/root:/bin/sh\n");
 860:	90000001 	adrp	x1, 0 <.plt-0x5f0>
 864:	91316421 	add	x1, x1, #0xc59
 868:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 86c:	9131e800 	add	x0, x0, #0xc7a
 870:	940000b6 	bl	b48 <create_config>
  create_config("etc/rc", "export PATH=/bin:/usr/bin:/:.\n");
 874:	90000001 	adrp	x1, 0 <.plt-0x5f0>
 878:	91321421 	add	x1, x1, #0xc85
 87c:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 880:	91329000 	add	x0, x0, #0xca4
 884:	940000b1 	bl	b48 <create_config>
  create_config("etc/fstab",
 888:	90000001 	adrp	x1, 0 <.plt-0x5f0>
 88c:	9132ac21 	add	x1, x1, #0xcab
 890:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 894:	912ed400 	add	x0, x0, #0xbb5
 898:	940000ac 	bl	b48 <create_config>
  create_config("etc/wifi.conf",
 89c:	90000001 	adrp	x1, 0 <.plt-0x5f0>
 8a0:	91348021 	add	x1, x1, #0xd20
 8a4:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 8a8:	91350800 	add	x0, x0, #0xd42
 8ac:	940000a7 	bl	b48 <create_config>
  mount_fstab();
 8b0:	94000050 	bl	9f0 <mount_fstab>
  char *wifi_argv[] = { "wifi", 0 };
 8b4:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 8b8:	91360400 	add	x0, x0, #0xd81
 8bc:	a9027fe0 	stp	x0, xzr, [sp, #32]
  printf("init: connecting Wi-Fi from /etc/wifi.conf\n");
 8c0:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 8c4:	91354000 	add	x0, x0, #0xd50
 8c8:	97ffff52 	bl	610 <printf@plt>
  pid = fork();
 8cc:	97ffff6d 	bl	680 <fork@plt>
  if(pid == 0){
 8d0:	7100001f 	cmp	w0, #0x0
 8d4:	35000120 	cbnz	w0, 8f8 <main+0x1e8>
    exec("/bin/wifi", wifi_argv);
 8d8:	910083e1 	add	x1, sp, #0x20
 8dc:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 8e0:	9135f000 	add	x0, x0, #0xd7c
 8e4:	97ffff57 	bl	640 <exec@plt>
    printf("init: exec /bin/wifi failed\n");
 8e8:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 8ec:	91361800 	add	x0, x0, #0xd86
 8f0:	97ffff48 	bl	610 <printf@plt>
 8f4:	17ffffd0 	b	834 <main+0x124>
  }
  if(pid > 0)
 8f8:	5400006d 	b.le	904 <main+0x1f4>
    wait(0);
 8fc:	d2800000 	mov	x0, #0x0                   	// #0
 900:	97ffff54 	bl	650 <wait@plt>
#endif

  for(;;){
    printf("init: starting local login on /dev/ttyS0\n");
 904:	90000013 	adrp	x19, 0 <.plt-0x5f0>
 908:	91368e73 	add	x19, x19, #0xda3
 90c:	aa1303e0 	mov	x0, x19
 910:	97ffff40 	bl	610 <printf@plt>
    pid = fork();
 914:	97ffff5b 	bl	680 <fork@plt>
 918:	2a0003f4 	mov	w20, w0
    if(pid < 0){
 91c:	36f80080 	tbz	w0, #31, 92c <main+0x21c>
      printf("init: fork failed\n");
 920:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 924:	91373400 	add	x0, x0, #0xdcd
 928:	17fffff2 	b	8f0 <main+0x1e0>
      exit(1);
    }
    if(pid == 0){
 92c:	35000120 	cbnz	w0, 950 <main+0x240>
      exec("/bin/login", argv);
 930:	b0000001 	adrp	x1, 1000 <_DYNAMIC>
 934:	9107c021 	add	x1, x1, #0x1f0
 938:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 93c:	91378000 	add	x0, x0, #0xde0
 940:	97ffff40 	bl	640 <exec@plt>
      printf("init: exec login failed\n");
 944:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 948:	9137ac00 	add	x0, x0, #0xdeb
 94c:	17ffffe9 	b	8f0 <main+0x1e0>
    }

    for(;;){
      // this call to wait() returns if the shell exits,
      // or if a parentless process exits.
      wpid = wait((int *) 0);
 950:	d2800000 	mov	x0, #0x0                   	// #0
 954:	97ffff3f 	bl	650 <wait@plt>
      if(wpid == pid){
 958:	6b00029f 	cmp	w20, w0
 95c:	54fffd80 	b.eq	90c <main+0x1fc>  // b.none
        // the shell exited; restart it.
        break;
      } else if(wpid < 0){
 960:	36ffff80 	tbz	w0, #31, 950 <main+0x240>
        printf("init: wait returned an error\n");
 964:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 968:	91381000 	add	x0, x0, #0xe04
 96c:	17ffffe1 	b	8f0 <main+0x1e0>

0000000000000970 <field>:
{
 970:	aa0003e3 	mov	x3, x0
  char *p = *cursor, *start;
 974:	f9400000 	ldr	x0, [x0]
  while(*p == ' ' || *p == '\t')
 978:	39400001 	ldrb	w1, [x0]
 97c:	7100803f 	cmp	w1, #0x20
 980:	7a491824 	ccmp	w1, #0x9, #0x4, ne	// ne = any
 984:	540001a0 	b.eq	9b8 <field+0x48>  // b.none
  if(*p == 0 || *p == '\n' || *p == '#'){
 988:	71008c3f 	cmp	w1, #0x23
 98c:	540001a9 	b.ls	9c0 <field+0x50>  // b.plast
  while(*p == ' ' || *p == '\t')
 990:	aa0003e1 	mov	x1, x0
  while(*p && *p != ' ' && *p != '\t' && *p != '\n')
 994:	39400022 	ldrb	w2, [x1]
 998:	121a7844 	and	w4, w2, #0xffffffdf
 99c:	34000244 	cbz	w4, 9e4 <field+0x74>
 9a0:	51002442 	sub	w2, w2, #0x9
 9a4:	12001c42 	and	w2, w2, #0xff
 9a8:	7100045f 	cmp	w2, #0x1
 9ac:	54000188 	b.hi	9dc <field+0x6c>  // b.pmore
    *p++ = 0;
 9b0:	3800143f 	strb	wzr, [x1], #1
 9b4:	1400000d 	b	9e8 <field+0x78>
    p++;
 9b8:	91000400 	add	x0, x0, #0x1
 9bc:	17ffffef 	b	978 <field+0x8>
 9c0:	d2808022 	mov	x2, #0x401                 	// #1025
 9c4:	f2c00102 	movk	x2, #0x8, lsl #32
 9c8:	9ac12441 	lsr	x1, x2, x1
 9cc:	3607fe21 	tbz	w1, #0, 990 <field+0x20>
  while(*p == ' ' || *p == '\t')
 9d0:	aa0003e1 	mov	x1, x0
 9d4:	d2800000 	mov	x0, #0x0                   	// #0
 9d8:	14000004 	b	9e8 <field+0x78>
    p++;
 9dc:	91000421 	add	x1, x1, #0x1
 9e0:	17ffffed 	b	994 <field+0x24>
  if(*p)
 9e4:	35fffe62 	cbnz	w2, 9b0 <field+0x40>
    *cursor = p;
 9e8:	f9000061 	str	x1, [x3]
}
 9ec:	d65f03c0 	ret

00000000000009f0 <mount_fstab>:
{
 9f0:	d10943ff 	sub	sp, sp, #0x250
  int fd = open("/etc/fstab", O_RDONLY);
 9f4:	90000000 	adrp	x0, 0 <.plt-0x5f0>
 9f8:	912ed000 	add	x0, x0, #0xbb4
 9fc:	52800001 	mov	w1, #0x0                   	// #0
{
 a00:	a9007bfd 	stp	x29, x30, [sp]
 a04:	910003fd 	mov	x29, sp
 a08:	a90153f3 	stp	x19, x20, [sp, #16]
 a0c:	a9025bf5 	stp	x21, x22, [sp, #32]
 a10:	a90363f7 	stp	x23, x24, [sp, #48]
  int fd = open("/etc/fstab", O_RDONLY);
 a14:	97ffff33 	bl	6e0 <open@plt>
  if(fd < 0)
 a18:	37f80260 	tbnz	w0, #31, a64 <mount_fstab+0x74>
  n = read(fd, buf, sizeof(buf) - 1);
 a1c:	910143f5 	add	x21, sp, #0x50
 a20:	52803fe2 	mov	w2, #0x1ff                 	// #511
 a24:	aa1503e1 	mov	x1, x21
 a28:	2a0003f4 	mov	w20, w0
 a2c:	97ffff0d 	bl	660 <read@plt>
 a30:	2a0003f3 	mov	w19, w0
  close(fd);
 a34:	2a1403e0 	mov	w0, w20
 a38:	97ffff32 	bl	700 <close@plt>
  if(n <= 0)
 a3c:	7100027f 	cmp	w19, #0x0
 a40:	5400012d 	b.le	a64 <mount_fstab+0x74>
  while(*p){
 a44:	aa1503e1 	mov	x1, x21
  buf[n] = 0;
 a48:	38334abf 	strb	wzr, [x21, w19, uxtw]
        int flags = strcmp(options, "ro") == 0 ? 1 : 0;
 a4c:	90000013 	adrp	x19, 0 <.plt-0x5f0>
 a50:	912efe73 	add	x19, x19, #0xbbf
  p = buf;
 a54:	f90027e1 	str	x1, [sp, #72]
  while(*p){
 a58:	f94027e0 	ldr	x0, [sp, #72]
 a5c:	39400000 	ldrb	w0, [x0]
 a60:	350000e0 	cbnz	w0, a7c <mount_fstab+0x8c>
}
 a64:	a9407bfd 	ldp	x29, x30, [sp]
 a68:	a94153f3 	ldp	x19, x20, [sp, #16]
 a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
 a70:	a94363f7 	ldp	x23, x24, [sp, #48]
 a74:	910943ff 	add	sp, sp, #0x250
 a78:	d65f03c0 	ret
    source = field(&p);
 a7c:	910123e0 	add	x0, sp, #0x48
 a80:	97ffffbc 	bl	970 <field>
 a84:	aa0003f5 	mov	x21, x0
    if(source){
 a88:	b4000400 	cbz	x0, b08 <mount_fstab+0x118>
      target = field(&p);
 a8c:	910123e0 	add	x0, sp, #0x48
 a90:	97ffffb8 	bl	970 <field>
 a94:	aa0003f6 	mov	x22, x0
      type = field(&p);
 a98:	910123e0 	add	x0, sp, #0x48
 a9c:	97ffffb5 	bl	970 <field>
 aa0:	aa0003f7 	mov	x23, x0
      options = field(&p);
 aa4:	910123e0 	add	x0, sp, #0x48
 aa8:	97ffffb2 	bl	970 <field>
      if(target && type && options){
 aac:	f10002df 	cmp	x22, #0x0
      options = field(&p);
 ab0:	aa0003f4 	mov	x20, x0
      if(target && type && options){
 ab4:	fa401ae4 	ccmp	x23, #0x0, #0x4, ne	// ne = any
 ab8:	54000280 	b.eq	b08 <mount_fstab+0x118>  // b.none
 abc:	b4000260 	cbz	x0, b08 <mount_fstab+0x118>
        int flags = strcmp(options, "ro") == 0 ? 1 : 0;
 ac0:	aa1303e1 	mov	x1, x19
 ac4:	97fffef7 	bl	6a0 <strcmp@plt>
        if(strcmp(options, "ro") == 0 || strcmp(options, "rw") == 0)
 ac8:	aa1303e1 	mov	x1, x19
        int flags = strcmp(options, "ro") == 0 ? 1 : 0;
 acc:	2a0003f8 	mov	w24, w0
        if(strcmp(options, "ro") == 0 || strcmp(options, "rw") == 0)
 ad0:	aa1403e0 	mov	x0, x20
 ad4:	97fffef3 	bl	6a0 <strcmp@plt>
 ad8:	340000c0 	cbz	w0, af0 <mount_fstab+0x100>
 adc:	90000001 	adrp	x1, 0 <.plt-0x5f0>
 ae0:	912f0821 	add	x1, x1, #0xbc2
 ae4:	aa1403e0 	mov	x0, x20
 ae8:	97fffeee 	bl	6a0 <strcmp@plt>
 aec:	350000e0 	cbnz	w0, b08 <mount_fstab+0x118>
        int flags = strcmp(options, "ro") == 0 ? 1 : 0;
 af0:	7100031f 	cmp	w24, #0x0
          mount(source, target, type, flags);
 af4:	aa1703e2 	mov	x2, x23
 af8:	1a9f17e3 	cset	w3, eq	// eq = none
 afc:	aa1603e1 	mov	x1, x22
 b00:	aa1503e0 	mov	x0, x21
 b04:	97fffee3 	bl	690 <mount@plt>
 b08:	f94027e2 	ldr	x2, [sp, #72]
{
 b0c:	52800003 	mov	w3, #0x0                   	// #0
    while(*p && *p != '\n')
 b10:	39400041 	ldrb	w1, [x2]
 b14:	aa0203e0 	mov	x0, x2
 b18:	2a0303e4 	mov	w4, w3
 b1c:	91000442 	add	x2, x2, #0x1
 b20:	7100003f 	cmp	w1, #0x0
 b24:	7a4a1824 	ccmp	w1, #0xa, #0x4, ne	// ne = any
 b28:	1a9f07e3 	cset	w3, ne	// ne = any
 b2c:	54ffff21 	b.ne	b10 <mount_fstab+0x120>  // b.any
 b30:	34000044 	cbz	w4, b38 <mount_fstab+0x148>
 b34:	f90027e0 	str	x0, [sp, #72]
    if(*p == '\n')
 b38:	7100283f 	cmp	w1, #0xa
 b3c:	54fff8e1 	b.ne	a58 <mount_fstab+0x68>  // b.any
      p++;
 b40:	91000401 	add	x1, x0, #0x1
 b44:	17ffffc4 	b	a54 <mount_fstab+0x64>

0000000000000b48 <create_config>:
{
 b48:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 b4c:	910003fd 	mov	x29, sp
 b50:	a90153f3 	stp	x19, x20, [sp, #16]
 b54:	aa0103f4 	mov	x20, x1
 b58:	aa0003f3 	mov	x19, x0
  int fd = open(path, O_RDONLY);
 b5c:	52800001 	mov	w1, #0x0                   	// #0
 b60:	97fffee0 	bl	6e0 <open@plt>
  if(fd >= 0){
 b64:	37f80080 	tbnz	w0, #31, b74 <create_config+0x2c>
}
 b68:	a94153f3 	ldp	x19, x20, [sp, #16]
 b6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    close(fd);
 b70:	17fffee4 	b	700 <close@plt>
  fd = open(path, O_CREATE | O_WRONLY);
 b74:	aa1303e0 	mov	x0, x19
 b78:	52804021 	mov	w1, #0x201                 	// #513
 b7c:	97fffed9 	bl	6e0 <open@plt>
 b80:	2a0003f3 	mov	w19, w0
  if(fd >= 0){
 b84:	37f80120 	tbnz	w0, #31, ba8 <create_config+0x60>
    write(fd, contents, strlen(contents));
 b88:	aa1403e0 	mov	x0, x20
 b8c:	97fffed1 	bl	6d0 <strlen@plt>
 b90:	aa1403e1 	mov	x1, x20
 b94:	2a0003e2 	mov	w2, w0
 b98:	2a1303e0 	mov	w0, w19
 b9c:	97fffea5 	bl	630 <write@plt>
    close(fd);
 ba0:	2a1303e0 	mov	w0, w19
 ba4:	17fffff1 	b	b68 <create_config+0x20>
}
 ba8:	a94153f3 	ldp	x19, x20, [sp, #16]
 bac:	a8c27bfd 	ldp	x29, x30, [sp], #32
 bb0:	d65f03c0 	ret
