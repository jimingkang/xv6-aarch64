
user/_camshot:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000528 <.plt>:
 528:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 52c:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 530:	f940fa11 	ldr	x17, [x16, #496]
 534:	9107c210 	add	x16, x16, #0x1f0
 538:	d61f0220 	br	x17
 53c:	d503201f 	nop
 540:	d503201f 	nop
 544:	d503201f 	nop

0000000000000548 <printf@plt>:
 548:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 54c:	f940fe11 	ldr	x17, [x16, #504]
 550:	9107e210 	add	x16, x16, #0x1f8
 554:	d61f0220 	br	x17

0000000000000558 <memmove@plt>:
 558:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 55c:	f9410211 	ldr	x17, [x16, #512]
 560:	91080210 	add	x16, x16, #0x200
 564:	d61f0220 	br	x17

0000000000000568 <malloc@plt>:
 568:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 56c:	f9410611 	ldr	x17, [x16, #520]
 570:	91082210 	add	x16, x16, #0x208
 574:	d61f0220 	br	x17

0000000000000578 <write@plt>:
 578:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 57c:	f9410a11 	ldr	x17, [x16, #528]
 580:	91084210 	add	x16, x16, #0x210
 584:	d61f0220 	br	x17

0000000000000588 <fprintf@plt>:
 588:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 58c:	f9410e11 	ldr	x17, [x16, #536]
 590:	91086210 	add	x16, x16, #0x218
 594:	d61f0220 	br	x17

0000000000000598 <read@plt>:
 598:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 59c:	f9411211 	ldr	x17, [x16, #544]
 5a0:	91088210 	add	x16, x16, #0x220
 5a4:	d61f0220 	br	x17

00000000000005a8 <memset@plt>:
 5a8:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 5ac:	f9411611 	ldr	x17, [x16, #552]
 5b0:	9108a210 	add	x16, x16, #0x228
 5b4:	d61f0220 	br	x17

00000000000005b8 <strcmp@plt>:
 5b8:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 5bc:	f9411a11 	ldr	x17, [x16, #560]
 5c0:	9108c210 	add	x16, x16, #0x230
 5c4:	d61f0220 	br	x17

00000000000005c8 <exit@plt>:
 5c8:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 5cc:	f9411e11 	ldr	x17, [x16, #568]
 5d0:	9108e210 	add	x16, x16, #0x238
 5d4:	d61f0220 	br	x17

00000000000005d8 <atoi@plt>:
 5d8:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 5dc:	f9412211 	ldr	x17, [x16, #576]
 5e0:	91090210 	add	x16, x16, #0x240
 5e4:	d61f0220 	br	x17

00000000000005e8 <strlen@plt>:
 5e8:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 5ec:	f9412611 	ldr	x17, [x16, #584]
 5f0:	91092210 	add	x16, x16, #0x248
 5f4:	d61f0220 	br	x17

00000000000005f8 <open@plt>:
 5f8:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 5fc:	f9412a11 	ldr	x17, [x16, #592]
 600:	91094210 	add	x16, x16, #0x250
 604:	d61f0220 	br	x17

0000000000000608 <mkdir@plt>:
 608:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 60c:	f9412e11 	ldr	x17, [x16, #600]
 610:	91096210 	add	x16, x16, #0x258
 614:	d61f0220 	br	x17

0000000000000618 <close@plt>:
 618:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 61c:	f9413211 	ldr	x17, [x16, #608]
 620:	91098210 	add	x16, x16, #0x260
 624:	d61f0220 	br	x17

0000000000000628 <free@plt>:
 628:	90000030 	adrp	x16, 4000 <qbase_c+0xf88>
 62c:	f9413611 	ldr	x17, [x16, #616]
 630:	9109a210 	add	x16, x16, #0x268
 634:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000638 <main>:
  exit(1);
}

int
main(int argc, char *argv[])
{
     638:	d10803ff 	sub	sp, sp, #0x200
     63c:	a9027bfd 	stp	x29, x30, [sp, #32]
     640:	910083fd 	add	x29, sp, #0x20
     644:	a90353f3 	stp	x19, x20, [sp, #48]
  char *out = "/boot/camera.bmp", *raw = 0, *in = 0;
     648:	d0000014 	adrp	x20, 2000 <jpeg_encode_to+0x80>
     64c:	9123be94 	add	x20, x20, #0x8ef
{
     650:	a9045bf5 	stp	x21, x22, [sp, #64]
  char *dir = "/mnt/ext2/video";
  int pattern = 0, wb = 1, half = 0, quality = 75, fd, n;
  int video = 0, frames = 30;
     654:	52800013 	mov	w19, #0x0                   	// #0
  int pattern = 0, wb = 1, half = 0, quality = 75, fd, n;
     658:	52800015 	mov	w21, #0x0                   	// #0
{
     65c:	a90563f7 	stp	x23, x24, [sp, #80]
     660:	aa0103f7 	mov	x23, x1
     664:	a9066bf9 	stp	x25, x26, [sp, #96]
     668:	2a0003fa 	mov	w26, w0

  printf("camshot: converter jpeg420-fast-v3 bmp-batch16\n");
     66c:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     670:	91240000 	add	x0, x0, #0x900
{
     674:	a90773fb 	stp	x27, x28, [sp, #112]
  printf("camshot: converter jpeg420-fast-v3 bmp-batch16\n");
     678:	97ffffb4 	bl	548 <printf@plt>
  int video = 0, frames = 30;
     67c:	528003c0 	mov	w0, #0x1e                  	// #30
     680:	b9009be0 	str	w0, [sp, #152]
  int pattern = 0, wb = 1, half = 0, quality = 75, fd, n;
     684:	52800960 	mov	w0, #0x4b                  	// #75
     688:	b90087e0 	str	w0, [sp, #132]
  char *dir = "/mnt/ext2/video";
     68c:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     690:	91237c00 	add	x0, x0, #0x8df
     694:	a90883ff 	stp	xzr, x0, [sp, #136]

  for(int i = 1; i < argc; i++){
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
     698:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     69c:	9124c000 	add	x0, x0, #0x930
  for(int i = 1; i < argc; i++){
     6a0:	52800039 	mov	w25, #0x1                   	// #1
  int pattern = 0, wb = 1, half = 0, quality = 75, fd, n;
     6a4:	5280001c 	mov	w28, #0x0                   	// #0
  char *out = "/boot/camera.bmp", *raw = 0, *in = 0;
     6a8:	f90053ff 	str	xzr, [sp, #160]
  int pattern = 0, wb = 1, half = 0, quality = 75, fd, n;
     6ac:	b900abf9 	str	w25, [sp, #168]
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
     6b0:	f9005be0 	str	x0, [sp, #176]
    else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc) quality = atoi(argv[++i]);
     6b4:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     6b8:	9124cc00 	add	x0, x0, #0x933
     6bc:	f9005fe0 	str	x0, [sp, #184]
  for(int i = 1; i < argc; i++){
     6c0:	6b1a033f 	cmp	w25, w26
     6c4:	5400038b 	b.lt	734 <main+0xfc>  // b.tstop
    else if(strcmp(argv[i], "-v") == 0) video = 1;
    else if(strcmp(argv[i], "-n") == 0 && i + 1 < argc) frames = atoi(argv[++i]);
    else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc) dir = argv[++i];
    else usage();
  }
  if(pattern < 0 || pattern > 3 || quality < 1 || quality > 100 || frames < 1)
     6c8:	b94087e0 	ldr	w0, [sp, #132]
     6cc:	51000400 	sub	w0, w0, #0x1
     6d0:	71018c1f 	cmp	w0, #0x63
     6d4:	7a439aa2 	ccmp	w21, #0x3, #0x2, ls	// ls = plast
     6d8:	54000e48 	b.hi	8a0 <main+0x268>  // b.pmore
     6dc:	b9409be0 	ldr	w0, [sp, #152]
     6e0:	7100001f 	cmp	w0, #0x0
     6e4:	54000ded 	b.le	8a0 <main+0x268>
    usage();
  if(video){
     6e8:	34002bb3 	cbz	w19, c5c <main+0x624>
    printf("camshot: recording %d frames -> %s\n", frames, dir);
     6ec:	f9404be2 	ldr	x2, [sp, #144]
     6f0:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     6f4:	91253800 	add	x0, x0, #0x94e
     6f8:	b9409be1 	ldr	w1, [sp, #152]
     6fc:	97ffff93 	bl	548 <printf@plt>
  mkdir(dir);                       // create the default directory if absent
     700:	f9404be0 	ldr	x0, [sp, #144]
     704:	97ffffc1 	bl	608 <mkdir@plt>
  uchar *frame = malloc(CAM_READ_MAX);
     708:	52800500 	mov	w0, #0x28                  	// #40
     70c:	72a00100 	movk	w0, #0x8, lsl #16
     710:	97ffff96 	bl	568 <malloc@plt>
     714:	aa0003f3 	mov	x19, x0
  if(frame == 0){
     718:	b5000d20 	cbnz	x0, 8bc <main+0x284>
    fprintf(2, "camshot: out of memory\n");
     71c:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     720:	9125c821 	add	x1, x1, #0x972
    fprintf(2, "camshot: cannot open /dev/video0\n");
     724:	52800040 	mov	w0, #0x2                   	// #2
     728:	97ffff98 	bl	588 <fprintf@plt>
    exit(1);
     72c:	52800020 	mov	w0, #0x1                   	// #1
     730:	97ffffa6 	bl	5c8 <exit@plt>
    if(strcmp(argv[i], "-o") == 0 && i + 1 < argc) out = argv[++i];
     734:	937d7f38 	sbfiz	x24, x25, #3, #32
     738:	8b39cefb 	add	x27, x23, w25, sxtw #3
     73c:	f9405be1 	ldr	x1, [sp, #176]
     740:	11000736 	add	w22, w25, #0x1
     744:	f8786ae0 	ldr	x0, [x23, x24]
     748:	97ffff9c 	bl	5b8 <strcmp@plt>
     74c:	350000e0 	cbnz	w0, 768 <main+0x130>
     750:	6b1a02df 	cmp	w22, w26
     754:	540000aa 	b.ge	768 <main+0x130>  // b.tcont
     758:	f9400774 	ldr	x20, [x27, #8]
    else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc) quality = atoi(argv[++i]);
     75c:	2a1603f9 	mov	w25, w22
  for(int i = 1; i < argc; i++){
     760:	11000739 	add	w25, w25, #0x1
     764:	17ffffd7 	b	6c0 <main+0x88>
    else if(strcmp(argv[i], "-q") == 0 && i + 1 < argc) quality = atoi(argv[++i]);
     768:	f8786ae0 	ldr	x0, [x23, x24]
     76c:	f9405fe1 	ldr	x1, [sp, #184]
     770:	97ffff92 	bl	5b8 <strcmp@plt>
     774:	350000e0 	cbnz	w0, 790 <main+0x158>
     778:	6b1a02df 	cmp	w22, w26
     77c:	540000aa 	b.ge	790 <main+0x158>  // b.tcont
     780:	f9400760 	ldr	x0, [x27, #8]
     784:	97ffff95 	bl	5d8 <atoi@plt>
     788:	b90087e0 	str	w0, [sp, #132]
     78c:	17fffff4 	b	75c <main+0x124>
    else if(strcmp(argv[i], "-r") == 0 && i + 1 < argc) raw = argv[++i];
     790:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     794:	9124d801 	add	x1, x0, #0x936
     798:	f8786ae0 	ldr	x0, [x23, x24]
     79c:	97ffff87 	bl	5b8 <strcmp@plt>
     7a0:	350000c0 	cbnz	w0, 7b8 <main+0x180>
     7a4:	6b1a02df 	cmp	w22, w26
     7a8:	5400008a 	b.ge	7b8 <main+0x180>  // b.tcont
     7ac:	f9400760 	ldr	x0, [x27, #8]
     7b0:	f90047e0 	str	x0, [sp, #136]
     7b4:	17ffffea 	b	75c <main+0x124>
    else if(strcmp(argv[i], "-i") == 0 && i + 1 < argc) in = argv[++i];
     7b8:	f8786ae0 	ldr	x0, [x23, x24]
     7bc:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     7c0:	9124e421 	add	x1, x1, #0x939
     7c4:	97ffff7d 	bl	5b8 <strcmp@plt>
     7c8:	350000c0 	cbnz	w0, 7e0 <main+0x1a8>
     7cc:	6b1a02df 	cmp	w22, w26
     7d0:	5400008a 	b.ge	7e0 <main+0x1a8>  // b.tcont
     7d4:	f9400760 	ldr	x0, [x27, #8]
     7d8:	f90053e0 	str	x0, [sp, #160]
     7dc:	17ffffe0 	b	75c <main+0x124>
    else if(strcmp(argv[i], "-t") == 0 && i + 1 < argc) pattern = atoi(argv[++i]);
     7e0:	f8786ae0 	ldr	x0, [x23, x24]
     7e4:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     7e8:	9124f021 	add	x1, x1, #0x93c
     7ec:	97ffff73 	bl	5b8 <strcmp@plt>
     7f0:	350000e0 	cbnz	w0, 80c <main+0x1d4>
     7f4:	6b1a02df 	cmp	w22, w26
     7f8:	540000aa 	b.ge	80c <main+0x1d4>  // b.tcont
     7fc:	f9400760 	ldr	x0, [x27, #8]
     800:	97ffff76 	bl	5d8 <atoi@plt>
     804:	2a0003f5 	mov	w21, w0
     808:	17ffffd5 	b	75c <main+0x124>
    else if(strcmp(argv[i], "-w") == 0) wb = 0;
     80c:	f8786ae0 	ldr	x0, [x23, x24]
     810:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     814:	9124fc21 	add	x1, x1, #0x93f
     818:	97ffff68 	bl	5b8 <strcmp@plt>
     81c:	34000440 	cbz	w0, 8a4 <main+0x26c>
    else if(strcmp(argv[i], "-s") == 0) half = 1;
     820:	f8786ae0 	ldr	x0, [x23, x24]
     824:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     828:	91250821 	add	x1, x1, #0x942
     82c:	97ffff63 	bl	5b8 <strcmp@plt>
     830:	340003e0 	cbz	w0, 8ac <main+0x274>
    else if(strcmp(argv[i], "-v") == 0) video = 1;
     834:	f8786ae0 	ldr	x0, [x23, x24]
     838:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     83c:	91251421 	add	x1, x1, #0x945
     840:	97ffff5e 	bl	5b8 <strcmp@plt>
     844:	34000380 	cbz	w0, 8b4 <main+0x27c>
    else if(strcmp(argv[i], "-n") == 0 && i + 1 < argc) frames = atoi(argv[++i]);
     848:	f8786ae0 	ldr	x0, [x23, x24]
     84c:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     850:	91252021 	add	x1, x1, #0x948
     854:	97ffff59 	bl	5b8 <strcmp@plt>
     858:	350000e0 	cbnz	w0, 874 <main+0x23c>
     85c:	6b1a02df 	cmp	w22, w26
     860:	540000aa 	b.ge	874 <main+0x23c>  // b.tcont
     864:	f9400760 	ldr	x0, [x27, #8]
     868:	97ffff5c 	bl	5d8 <atoi@plt>
     86c:	b9009be0 	str	w0, [sp, #152]
     870:	17ffffbb 	b	75c <main+0x124>
    else if(strcmp(argv[i], "-d") == 0 && i + 1 < argc) dir = argv[++i];
     874:	f8786ae0 	ldr	x0, [x23, x24]
     878:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     87c:	91252c21 	add	x1, x1, #0x94b
     880:	97ffff4e 	bl	5b8 <strcmp@plt>
     884:	350000e0 	cbnz	w0, 8a0 <main+0x268>
     888:	2a1603f9 	mov	w25, w22
     88c:	6b1a02df 	cmp	w22, w26
     890:	5400008a 	b.ge	8a0 <main+0x268>  // b.tcont
     894:	f9400760 	ldr	x0, [x27, #8]
     898:	f9004be0 	str	x0, [sp, #144]
     89c:	17ffffb1 	b	760 <main+0x128>
    else usage();
     8a0:	940002db 	bl	140c <usage>
    else if(strcmp(argv[i], "-w") == 0) wb = 0;
     8a4:	b900abff 	str	wzr, [sp, #168]
     8a8:	17ffffae 	b	760 <main+0x128>
    else if(strcmp(argv[i], "-s") == 0) half = 1;
     8ac:	5280003c 	mov	w28, #0x1                   	// #1
     8b0:	17ffffac 	b	760 <main+0x128>
    else if(strcmp(argv[i], "-v") == 0) video = 1;
     8b4:	52800033 	mov	w19, #0x1                   	// #1
     8b8:	17ffffaa 	b	760 <main+0x128>
  int fd = open("/dev/video0", O_RDWR);
     8bc:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     8c0:	91262800 	add	x0, x0, #0x98a
     8c4:	52800041 	mov	w1, #0x2                   	// #2
     8c8:	97ffff4c 	bl	5f8 <open@plt>
     8cc:	2a0003f7 	mov	w23, w0
  if(fd < 0){
     8d0:	36f80080 	tbz	w0, #31, 8e0 <main+0x2a8>
    fprintf(2, "camshot: cannot open /dev/video0\n");
     8d4:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     8d8:	91265821 	add	x1, x1, #0x996
     8dc:	17ffff92 	b	724 <main+0xec>
  char cmd[] = "pattern=0";
     8e0:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     8e4:	913aac21 	add	x1, x1, #0xeab
     8e8:	f9400022 	ldr	x2, [x1]
     8ec:	f90073e2 	str	x2, [sp, #224]
     8f0:	79401021 	ldrh	w1, [x1, #8]
  int control_result = write(fd, cmd, 9);
     8f4:	52800122 	mov	w2, #0x9                   	// #9
  char cmd[] = "pattern=0";
     8f8:	7901d3e1 	strh	w1, [sp, #232]
  cmd[8] = '0' + pattern;
     8fc:	1100c2a1 	add	w1, w21, #0x30
     900:	3903a3e1 	strb	w1, [sp, #232]
  int control_result = write(fd, cmd, 9);
     904:	910383e1 	add	x1, sp, #0xe0
     908:	97ffff1c 	bl	578 <write@plt>
  if(control_result != 9 && pattern){
     90c:	710002bf 	cmp	w21, #0x0
     910:	7a491804 	ccmp	w0, #0x9, #0x4, ne	// ne = any
     914:	54000100 	b.eq	934 <main+0x2fc>  // b.none
    cmd[8] = '0' + pattern;
    // Always send it, so a pattern left over from an interrupted run is
    // cleared; only a pattern that was asked for must be accepted.
    int control_result = write(fd, cmd, 9);
    if(control_result != 9 && pattern){
      fprintf(2, "camshot: pattern=%d control failed (write returned %d)\n",
     918:	2a0003e3 	mov	w3, w0
     91c:	2a1503e2 	mov	w2, w21
     920:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     924:	9126e021 	add	x1, x1, #0x9b8
     928:	52800040 	mov	w0, #0x2                   	// #2
     92c:	97ffff17 	bl	588 <fprintf@plt>
              pattern, control_result);
      exit(1);
     930:	17ffff7f 	b	72c <main+0xf4>
    printf("camshot: recording frame %d/%d...\n", i + 1, frames);
     934:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     938:	9127c000 	add	x0, x0, #0x9f0
     93c:	f9005be0 	str	x0, [sp, #176]
     940:	90000020 	adrp	x0, 4000 <qbase_c+0xf88>
     944:	9109c01a 	add	x26, x0, #0x270
  int ow = 0, oh = 0;
     948:	52800019 	mov	w25, #0x0                   	// #0
  for(int i = 0; i < frames; i++){
     94c:	52800014 	mov	w20, #0x0                   	// #0
       W % 4 || H % 2 || hdr->bytesperline < W * 10 / 8 ||
     950:	52800158 	mov	w24, #0xa                   	// #10
  int ow = 0, oh = 0;
     954:	b9008bff 	str	wzr, [sp, #136]
    printf("camshot: recording frame %d/%d...\n", i + 1, frames);
     958:	f9405be0 	ldr	x0, [sp, #176]
     95c:	b900a3f4 	str	w20, [sp, #160]
     960:	b9409be2 	ldr	w2, [sp, #152]
     964:	11000694 	add	w20, w20, #0x1
     968:	2a1403e1 	mov	w1, w20
     96c:	97fffef7 	bl	548 <printf@plt>
    int n = read(fd, frame, CAM_READ_MAX);
     970:	aa1303e1 	mov	x1, x19
     974:	2a1703e0 	mov	w0, w23
     978:	52800502 	mov	w2, #0x28                  	// #40
     97c:	72a00102 	movk	w2, #0x8, lsl #16
     980:	97ffff06 	bl	598 <read@plt>
     984:	2a0003e6 	mov	w6, w0
    if(n < (int)sizeof(*hdr) || hdr->magic != CAM_MAGIC){
     988:	71009c1f 	cmp	w0, #0x27
     98c:	540000cd 	b.le	9a4 <main+0x36c>
     990:	b9400260 	ldr	w0, [x19]
     994:	52882861 	mov	w1, #0x4143                	// #16707
     998:	72a629a1 	movk	w1, #0x314d, lsl #16
     99c:	6b01001f 	cmp	w0, w1
     9a0:	540002c0 	b.eq	9f8 <main+0x3c0>  // b.none
      fprintf(2, "camshot: frame %d capture failed\n", i + 1);
     9a4:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     9a8:	91284c21 	add	x1, x1, #0xa13
     9ac:	2a1403e2 	mov	w2, w20
     9b0:	52800040 	mov	w0, #0x2                   	// #2
     9b4:	97fffef5 	bl	588 <fprintf@plt>
  if(pattern){
     9b8:	340000f5 	cbz	w21, 9d4 <main+0x39c>
    cmd[8] = '0';
     9bc:	52800600 	mov	w0, #0x30                  	// #48
    write(fd, cmd, 9);
     9c0:	910383e1 	add	x1, sp, #0xe0
     9c4:	52800122 	mov	w2, #0x9                   	// #9
    cmd[8] = '0';
     9c8:	3903a3e0 	strb	w0, [sp, #232]
    write(fd, cmd, 9);
     9cc:	2a1703e0 	mov	w0, w23
     9d0:	97fffeea 	bl	578 <write@plt>
  close(fd);
     9d4:	2a1703e0 	mov	w0, w23
     9d8:	97ffff10 	bl	618 <close@plt>
  free(frame);
     9dc:	aa1303e0 	mov	x0, x19
     9e0:	97ffff12 	bl	628 <free@plt>
  if(px)
     9e4:	f9400740 	ldr	x0, [x26, #8]
     9e8:	b4000040 	cbz	x0, 9f0 <main+0x3b8>
    free(px);
     9ec:	97ffff0f 	bl	628 <free@plt>
  free(lines);
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
         ow, oh, seq, gain_r / 256, gain_r % 256 * 10 / 256,
         gain_b / 256, gain_b % 256 * 10 / 256,
         level / 256, level % 256 * 10 / 256, out);
  exit(0);
     9f0:	52800000 	mov	w0, #0x0                   	// #0
     9f4:	17ffff4f 	b	730 <main+0xf8>
    if(n != (int)(sizeof(*hdr) + hdr->data_bytes) || W < 4 || H < 4 ||
     9f8:	b9401661 	ldr	w1, [x19, #20]
    H = hdr->height;
     9fc:	29409267 	ldp	w7, w4, [x19, #4]
    if(n != (int)(sizeof(*hdr) + hdr->data_bytes) || W < 4 || H < 4 ||
     a00:	1100a020 	add	w0, w1, #0x28
    H = hdr->height;
     a04:	b9000344 	str	w4, [x26]
    W = hdr->width;
     a08:	b9001347 	str	w7, [x26, #16]
    if(n != (int)(sizeof(*hdr) + hdr->data_bytes) || W < 4 || H < 4 ||
     a0c:	6b0000df 	cmp	w6, w0
     a10:	54000281 	b.ne	a60 <main+0x428>  // b.any
     a14:	71000cff 	cmp	w7, #0x3
     a18:	5400024d 	b.le	a60 <main+0x428>
     a1c:	71000c9f 	cmp	w4, #0x3
     a20:	5400020d 	b.le	a60 <main+0x428>
       W % 4 || H % 2 || hdr->bytesperline < W * 10 / 8 ||
     a24:	120004e0 	and	w0, w7, #0x3
     a28:	12000082 	and	w2, w4, #0x1
     a2c:	2a020000 	orr	w0, w0, w2
     a30:	35000180 	cbnz	w0, a60 <main+0x428>
     a34:	1b187ce2 	mul	w2, w7, w24
     a38:	b9400e60 	ldr	w0, [x19, #12]
     a3c:	6b820c1f 	cmp	w0, w2, asr #3
     a40:	54000103 	b.cc	a60 <main+0x428>  // b.lo, b.ul, b.last
       hdr->data_bytes < hdr->bytesperline * H || set_bayer(hdr->format) < 0){
     a44:	1b007c80 	mul	w0, w4, w0
       W % 4 || H % 2 || hdr->bytesperline < W * 10 / 8 ||
     a48:	6b00003f 	cmp	w1, w0
     a4c:	540000a3 	b.cc	a60 <main+0x428>  // b.lo, b.ul, b.last
       hdr->data_bytes < hdr->bytesperline * H || set_bayer(hdr->format) < 0){
     a50:	b9401260 	ldr	w0, [x19, #16]
     a54:	9400025d 	bl	13c8 <set_bayer>
     a58:	3100041f 	cmn	w0, #0x1
     a5c:	54000121 	b.ne	a80 <main+0x448>  // b.any
      fprintf(2, "camshot: unsupported frame %d (%dx%d format %d, %d bytes)\n",
     a60:	b9401265 	ldr	w5, [x19, #16]
     a64:	2a0703e3 	mov	w3, w7
     a68:	2a1403e2 	mov	w2, w20
     a6c:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     a70:	9128d421 	add	x1, x1, #0xa35
     a74:	52800040 	mov	w0, #0x2                   	// #2
     a78:	97fffec4 	bl	588 <fprintf@plt>
      break;
     a7c:	17ffffcf 	b	9b8 <main+0x380>
    if(i == 0){
     a80:	b940a3e0 	ldr	w0, [sp, #160]
     a84:	35000140 	cbnz	w0, aac <main+0x474>
      ow = half ? W / 2 : W;
     a88:	34000c3c 	cbz	w28, c0c <main+0x5d4>
     a8c:	13017cf9 	asr	w25, w7, #1
      oh = half ? H / 2 : H;
     a90:	13017c80 	asr	w0, w4, #1
     a94:	b9008be0 	str	w0, [sp, #136]
      if((px = malloc(W * H * sizeof(ushort))) == 0){
     a98:	1b047ce0 	mul	w0, w7, w4
     a9c:	531f7800 	lsl	w0, w0, #1
     aa0:	97fffeb2 	bl	568 <malloc@plt>
     aa4:	f9000740 	str	x0, [x26, #8]
     aa8:	b4ffe3a0 	cbz	x0, 71c <main+0xe4>
    unpack_raw10(frame + sizeof(*hdr), hdr->bytesperline);
     aac:	b9400e61 	ldr	w1, [x19, #12]
     ab0:	9100a260 	add	x0, x19, #0x28
     ab4:	94000209 	bl	12d8 <unpack_raw10>
  if(pattern){
     ab8:	34000b15 	cbz	w21, c18 <main+0x5e0>
    *gain_r = *gain_b = 256;
     abc:	52802000 	mov	w0, #0x100                 	// #256
     ac0:	291a03e0 	stp	w0, w0, [sp, #208]
    *level = 256;
     ac4:	b900dbe0 	str	w0, [sp, #216]
    printf("camshot: sensor test pattern; fixed WB/level\n");
     ac8:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     acc:	9129c000 	add	x0, x0, #0xa70
     ad0:	97fffe9e 	bl	548 <printf@plt>
    struct convert conversion = { half, gain_r, gain_b, level };
     ad4:	b940d3e0 	ldr	w0, [sp, #208]
  memmove(buf, dir, dl);
     ad8:	910403f6 	add	x22, sp, #0x100
    struct convert conversion = { half, gain_r, gain_b, level };
     adc:	291e03fc 	stp	w28, w0, [sp, #240]
     ae0:	b940d7e0 	ldr	w0, [sp, #212]
     ae4:	b900fbe0 	str	w0, [sp, #248]
     ae8:	b940dbe0 	ldr	w0, [sp, #216]
     aec:	b900ffe0 	str	w0, [sp, #252]
  int n = 0, dl = strlen(dir);
     af0:	f9404be0 	ldr	x0, [sp, #144]
     af4:	97fffebd 	bl	5e8 <strlen@plt>
     af8:	2a0003e4 	mov	w4, w0
  memmove(buf, dir, dl);
     afc:	f9404be1 	ldr	x1, [sp, #144]
  if(dl > 200)
     b00:	7103201f 	cmp	w0, #0xc8
     b04:	52801903 	mov	w3, #0xc8                  	// #200
     b08:	1a83d01b 	csel	w27, w0, w3, le
  memmove(buf, dir, dl);
     b0c:	2a1b03e2 	mov	w2, w27
     b10:	aa1603e0 	mov	x0, x22
  if(dl > 200)
     b14:	b900bbe4 	str	w4, [sp, #184]
  memmove(buf, dir, dl);
     b18:	97fffe90 	bl	558 <memmove@plt>
  if(n == 0 || buf[n - 1] != '/')
     b1c:	b940bbe4 	ldr	w4, [sp, #184]
     b20:	93407f60 	sxtw	x0, w27
     b24:	340000a4 	cbz	w4, b38 <main+0x500>
     b28:	9103ffe1 	add	x1, sp, #0xff
     b2c:	38606821 	ldrb	w1, [x1, x0]
     b30:	7100bc3f 	cmp	w1, #0x2f
     b34:	54000080 	b.eq	b44 <main+0x50c>  // b.none
    buf[n++] = '/';
     b38:	1100077b 	add	w27, w27, #0x1
     b3c:	528005e1 	mov	w1, #0x2f                  	// #47
     b40:	38206ac1 	strb	w1, [x22, x0]
  memmove(buf + n, "frame", 5);
     b44:	8b3bc2c4 	add	x4, x22, w27, sxtw
     b48:	528000a2 	mov	w2, #0x5                   	// #5
     b4c:	aa0403e0 	mov	x0, x4
     b50:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     b54:	912a7821 	add	x1, x1, #0xa9e
     b58:	f9005fe4 	str	x4, [sp, #184]
     b5c:	97fffe7f 	bl	558 <memmove@plt>
    buf[n++] = '0' + (index / d) % 10;
     b60:	f9405fe4 	ldr	x4, [sp, #184]
  memmove(buf + n, "frame", 5);
     b64:	d2800001 	mov	x1, #0x0                   	// #0
  for(int d = 1000; d > 0; d /= 10)
     b68:	52807d02 	mov	w2, #0x3e8                 	// #1000
    buf[n++] = '0' + (index / d) % 10;
     b6c:	91001484 	add	x4, x4, #0x5
     b70:	b940a3e0 	ldr	w0, [sp, #160]
     b74:	1ac20805 	udiv	w5, w0, w2
  for(int d = 1000; d > 0; d /= 10)
     b78:	1ad80842 	udiv	w2, w2, w24
    buf[n++] = '0' + (index / d) % 10;
     b7c:	1ad808a0 	udiv	w0, w5, w24
     b80:	1b189400 	msub	w0, w0, w24, w5
     b84:	1100c000 	add	w0, w0, #0x30
     b88:	38216880 	strb	w0, [x4, x1]
  for(int d = 1000; d > 0; d /= 10)
     b8c:	91000421 	add	x1, x1, #0x1
     b90:	f100103f 	cmp	x1, #0x4
     b94:	54fffee1 	b.ne	b70 <main+0x538>  // b.any
  memmove(buf + n, ".jpg", 5);
     b98:	11002760 	add	w0, w27, #0x9
     b9c:	528000a2 	mov	w2, #0x5                   	// #5
     ba0:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     ba4:	912a9021 	add	x1, x1, #0xaa4
     ba8:	8b20c2c0 	add	x0, x22, w0, sxtw
     bac:	97fffe6b 	bl	558 <memmove@plt>
    int ofd = open(path, O_CREATE | O_WRONLY | O_TRUNC);
     bb0:	aa1603e0 	mov	x0, x22
     bb4:	5280c021 	mov	w1, #0x601                 	// #1537
     bb8:	97fffe90 	bl	5f8 <open@plt>
    uint jpeg_bytes = 0;
     bbc:	b900dfff 	str	wzr, [sp, #220]
    int ofd = open(path, O_CREATE | O_WRONLY | O_TRUNC);
     bc0:	2a0003fb 	mov	w27, w0
    if(ofd < 0 || jpeg_encode(ofd, ow, oh, quality, output_pixel,
     bc4:	37f80120 	tbnz	w0, #31, be8 <main+0x5b0>
     bc8:	29508be3 	ldp	w3, w2, [sp, #132]
     bcc:	b0000004 	adrp	x4, 1000 <main+0x9c8>
     bd0:	911a7084 	add	x4, x4, #0x69c
     bd4:	910373e6 	add	x6, sp, #0xdc
     bd8:	9103c3e5 	add	x5, sp, #0xf0
     bdc:	2a1903e1 	mov	w1, w25
     be0:	940006a7 	bl	267c <jpeg_encode>
     be4:	36f80260 	tbz	w0, #31, c30 <main+0x5f8>
      fprintf(2, "camshot: cannot write %s\n", path);
     be8:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     bec:	912aa421 	add	x1, x1, #0xaa9
     bf0:	aa1603e2 	mov	x2, x22
     bf4:	52800040 	mov	w0, #0x2                   	// #2
     bf8:	97fffe64 	bl	588 <fprintf@plt>
      if(ofd >= 0)
     bfc:	37ffedfb 	tbnz	w27, #31, 9b8 <main+0x380>
        close(ofd);
     c00:	2a1b03e0 	mov	w0, w27
     c04:	97fffe85 	bl	618 <close@plt>
     c08:	17ffff6c 	b	9b8 <main+0x380>
      ow = half ? W / 2 : W;
     c0c:	2a0703f9 	mov	w25, w7
      oh = half ? H / 2 : H;
     c10:	b9008be4 	str	w4, [sp, #136]
     c14:	17ffffa1 	b	a98 <main+0x460>
  printf("camshot: calculating white balance and level...\n");
     c18:	b940abe0 	ldr	w0, [sp, #168]
     c1c:	910363e3 	add	x3, sp, #0xd8
     c20:	910353e2 	add	x2, sp, #0xd4
     c24:	910343e1 	add	x1, sp, #0xd0
     c28:	94000219 	bl	148c <compute_wb_level.part.0>
     c2c:	17ffffaa 	b	ad4 <main+0x49c>
    close(ofd);
     c30:	2a1b03e0 	mov	w0, w27
     c34:	97fffe79 	bl	618 <close@plt>
    printf("camshot: saved %s (%d bytes)\n", path, jpeg_bytes);
     c38:	b940dfe2 	ldr	w2, [sp, #220]
     c3c:	aa1603e1 	mov	x1, x22
     c40:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     c44:	912b0c00 	add	x0, x0, #0xac3
     c48:	97fffe40 	bl	548 <printf@plt>
  for(int i = 0; i < frames; i++){
     c4c:	b9409be0 	ldr	w0, [sp, #152]
     c50:	6b14001f 	cmp	w0, w20
     c54:	54ffe821 	b.ne	958 <main+0x320>  // b.any
     c58:	17ffff58 	b	9b8 <main+0x380>
  uchar *frame = malloc(CAM_READ_MAX);
     c5c:	52800500 	mov	w0, #0x28                  	// #40
     c60:	72a00100 	movk	w0, #0x8, lsl #16
     c64:	97fffe41 	bl	568 <malloc@plt>
     c68:	aa0003f6 	mov	x22, x0
  if(frame == 0){
     c6c:	b4ffd580 	cbz	x0, 71c <main+0xe4>
  if(in){
     c70:	f94053e0 	ldr	x0, [sp, #160]
     c74:	b4000480 	cbz	x0, d04 <main+0x6cc>
    if((fd = open(in, O_RDONLY)) < 0){
     c78:	52800001 	mov	w1, #0x0                   	// #0
     c7c:	97fffe5f 	bl	5f8 <open@plt>
     c80:	2a0003f7 	mov	w23, w0
     c84:	37f80340 	tbnz	w0, #31, cec <main+0x6b4>
               (m = read(fd, frame + n, CAM_READ_MAX - n)) > 0; )
     c88:	52800518 	mov	w24, #0x28                  	// #40
     c8c:	72a00118 	movk	w24, #0x8, lsl #16
    for(int m; n < (int)CAM_READ_MAX &&
     c90:	528004fa 	mov	w26, #0x27                  	// #39
     c94:	72a0011a 	movk	w26, #0x8, lsl #16
               (m = read(fd, frame + n, CAM_READ_MAX - n)) > 0; )
     c98:	4b130302 	sub	w2, w24, w19
     c9c:	8b33c2c1 	add	x1, x22, w19, sxtw
     ca0:	2a1703e0 	mov	w0, w23
     ca4:	97fffe3d 	bl	598 <read@plt>
    for(int m; n < (int)CAM_READ_MAX &&
     ca8:	7100001f 	cmp	w0, #0x0
     cac:	5400008d 	b.le	cbc <main+0x684>
      n += m;
     cb0:	0b000273 	add	w19, w19, w0
    for(int m; n < (int)CAM_READ_MAX &&
     cb4:	6b1a027f 	cmp	w19, w26
     cb8:	54ffff0d 	b.le	c98 <main+0x660>
    close(fd);
     cbc:	2a1703e0 	mov	w0, w23
     cc0:	97fffe56 	bl	618 <close@plt>
  if(n < (int)sizeof(*hdr) || hdr->magic != CAM_MAGIC){
     cc4:	71009e7f 	cmp	w19, #0x27
     cc8:	540000cd 	b.le	ce0 <main+0x6a8>
     ccc:	b94002c1 	ldr	w1, [x22]
     cd0:	52882860 	mov	w0, #0x4143                	// #16707
     cd4:	72a629a0 	movk	w0, #0x314d, lsl #16
     cd8:	6b00003f 	cmp	w1, w0
     cdc:	540005e0 	b.eq	d98 <main+0x760>  // b.none
    fprintf(2, "camshot: capture failed (see kernel log)\n");
     ce0:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     ce4:	912c4421 	add	x1, x1, #0xb11
     ce8:	17fffe8f 	b	724 <main+0xec>
      fprintf(2, "camshot: cannot open %s\n", in);
     cec:	f94053e2 	ldr	x2, [sp, #160]
     cf0:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     cf4:	912b8421 	add	x1, x1, #0xae1
    fprintf(2, "camshot: cannot create %s\n", out);
     cf8:	52800040 	mov	w0, #0x2                   	// #2
     cfc:	97fffe23 	bl	588 <fprintf@plt>
    exit(1);
     d00:	17fffe8b 	b	72c <main+0xf4>
    if((fd = open("/dev/video0", O_RDWR)) < 0){
     d04:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     d08:	91262800 	add	x0, x0, #0x98a
     d0c:	52800041 	mov	w1, #0x2                   	// #2
     d10:	97fffe3a 	bl	5f8 <open@plt>
     d14:	2a0003f7 	mov	w23, w0
     d18:	37ffdde0 	tbnz	w0, #31, 8d4 <main+0x29c>
    char cmd[] = "pattern=0";
     d1c:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     d20:	913aac21 	add	x1, x1, #0xeab
     d24:	f9400022 	ldr	x2, [x1]
     d28:	f90083e2 	str	x2, [sp, #256]
     d2c:	79401021 	ldrh	w1, [x1, #8]
    int control_result = write(fd, cmd, 9);
     d30:	52800122 	mov	w2, #0x9                   	// #9
    char cmd[] = "pattern=0";
     d34:	790213e1 	strh	w1, [sp, #264]
    cmd[8] = '0' + pattern;
     d38:	1100c2a1 	add	w1, w21, #0x30
     d3c:	390423e1 	strb	w1, [sp, #264]
    int control_result = write(fd, cmd, 9);
     d40:	910403e1 	add	x1, sp, #0x100
     d44:	97fffe0d 	bl	578 <write@plt>
    if(control_result != 9 && pattern){
     d48:	710002bf 	cmp	w21, #0x0
     d4c:	7a491804 	ccmp	w0, #0x9, #0x4, ne	// ne = any
     d50:	54ffde41 	b.ne	918 <main+0x2e0>  // b.any
    printf("camshot: capturing...\n");
     d54:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     d58:	912be800 	add	x0, x0, #0xafa
     d5c:	97fffdfb 	bl	548 <printf@plt>
    n = read(fd, frame, CAM_READ_MAX);
     d60:	aa1603e1 	mov	x1, x22
     d64:	2a1703e0 	mov	w0, w23
     d68:	52800502 	mov	w2, #0x28                  	// #40
     d6c:	72a00102 	movk	w2, #0x8, lsl #16
     d70:	97fffe0a 	bl	598 <read@plt>
     d74:	2a0003f3 	mov	w19, w0
    if(pattern){
     d78:	34fffa35 	cbz	w21, cbc <main+0x684>
      cmd[8] = '0';
     d7c:	52800600 	mov	w0, #0x30                  	// #48
      write(fd, cmd, 9);
     d80:	910403e1 	add	x1, sp, #0x100
     d84:	52800122 	mov	w2, #0x9                   	// #9
      cmd[8] = '0';
     d88:	390423e0 	strb	w0, [sp, #264]
      write(fd, cmd, 9);
     d8c:	2a1703e0 	mov	w0, w23
     d90:	97fffdfa 	bl	578 <write@plt>
     d94:	17ffffca 	b	cbc <main+0x684>
  W = hdr->width;
     d98:	90000037 	adrp	x23, 4000 <qbase_c+0xf88>
     d9c:	9109c2f8 	add	x24, x23, #0x270
  if(n != (int)(sizeof(*hdr) + hdr->data_bytes) || W < 4 || H < 4 ||
     da0:	b94016c2 	ldr	w2, [x22, #20]
  H = hdr->height;
     da4:	29409ec6 	ldp	w6, w7, [x22, #4]
  if(n != (int)(sizeof(*hdr) + hdr->data_bytes) || W < 4 || H < 4 ||
     da8:	1100a040 	add	w0, w2, #0x28
  H = hdr->height;
     dac:	b90272e7 	str	w7, [x23, #624]
  W = hdr->width;
     db0:	b9001306 	str	w6, [x24, #16]
  if(n != (int)(sizeof(*hdr) + hdr->data_bytes) || W < 4 || H < 4 ||
     db4:	6b13001f 	cmp	w0, w19
     db8:	540002a1 	b.ne	e0c <main+0x7d4>  // b.any
     dbc:	71000cdf 	cmp	w6, #0x3
     dc0:	5400026d 	b.le	e0c <main+0x7d4>
     dc4:	71000cff 	cmp	w7, #0x3
     dc8:	5400022d 	b.le	e0c <main+0x7d4>
     W % 4 || H % 2 || hdr->bytesperline < W * 10 / 8 ||
     dcc:	120004c0 	and	w0, w6, #0x3
     dd0:	120000e1 	and	w1, w7, #0x1
     dd4:	2a010000 	orr	w0, w0, w1
     dd8:	350001a0 	cbnz	w0, e0c <main+0x7d4>
     ddc:	52800141 	mov	w1, #0xa                   	// #10
     de0:	b9400ec0 	ldr	w0, [x22, #12]
     de4:	1b017cc1 	mul	w1, w6, w1
     de8:	6b810c1f 	cmp	w0, w1, asr #3
     dec:	54000103 	b.cc	e0c <main+0x7d4>  // b.lo, b.ul, b.last
     hdr->data_bytes < hdr->bytesperline * H || set_bayer(hdr->format) < 0){
     df0:	1b007ce0 	mul	w0, w7, w0
     W % 4 || H % 2 || hdr->bytesperline < W * 10 / 8 ||
     df4:	6b00005f 	cmp	w2, w0
     df8:	540000a3 	b.cc	e0c <main+0x7d4>  // b.lo, b.ul, b.last
     hdr->data_bytes < hdr->bytesperline * H || set_bayer(hdr->format) < 0){
     dfc:	b94012c0 	ldr	w0, [x22, #16]
     e00:	94000172 	bl	13c8 <set_bayer>
     e04:	3100041f 	cmn	w0, #0x1
     e08:	54000141 	b.ne	e30 <main+0x7f8>  // b.any
    fprintf(2, "camshot: unsupported frame %dx%d format %d (%d bytes)\n",
     e0c:	b94012c4 	ldr	w4, [x22, #16]
     e10:	2a1303e5 	mov	w5, w19
     e14:	2a0703e3 	mov	w3, w7
     e18:	2a0603e2 	mov	w2, w6
     e1c:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     e20:	912cec21 	add	x1, x1, #0xb3b
     e24:	52800040 	mov	w0, #0x2                   	// #2
     e28:	97fffdd8 	bl	588 <fprintf@plt>
    exit(1);
     e2c:	17fffe40 	b	72c <main+0xf4>
  printf("camshot: frame received %dx%d, %d bytes\n", W, H, n);
     e30:	2a0603e1 	mov	w1, w6
     e34:	2a1303e3 	mov	w3, w19
     e38:	2a0703e2 	mov	w2, w7
     e3c:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     e40:	912dc800 	add	x0, x0, #0xb72
     e44:	97fffdc1 	bl	548 <printf@plt>
  if((px = malloc(W * H * sizeof(ushort))) == 0){
     e48:	b94272e1 	ldr	w1, [x23, #624]
     e4c:	b9401300 	ldr	w0, [x24, #16]
     e50:	1b017c00 	mul	w0, w0, w1
     e54:	531f7800 	lsl	w0, w0, #1
     e58:	97fffdc4 	bl	568 <malloc@plt>
     e5c:	f9000700 	str	x0, [x24, #8]
     e60:	b4ffc5e0 	cbz	x0, 71c <main+0xe4>
  if(raw){
     e64:	f94047e0 	ldr	x0, [sp, #136]
     e68:	b4000260 	cbz	x0, eb4 <main+0x87c>
    int rfd = open(raw, O_CREATE | O_WRONLY | O_TRUNC);
     e6c:	5280c021 	mov	w1, #0x601                 	// #1537
     e70:	97fffde2 	bl	5f8 <open@plt>
     e74:	2a0003fa 	mov	w26, w0
    if(rfd < 0 || write(rfd, frame, n) != n)
     e78:	37f800c0 	tbnz	w0, #31, e90 <main+0x858>
     e7c:	2a1303e2 	mov	w2, w19
     e80:	aa1603e1 	mov	x1, x22
     e84:	97fffdbd 	bl	578 <write@plt>
     e88:	6b13001f 	cmp	w0, w19
     e8c:	540009c0 	b.eq	fc4 <main+0x98c>  // b.none
      fprintf(2, "camshot: cannot write %s (%d bytes; native xv6 files are "
     e90:	f94047e2 	ldr	x2, [sp, #136]
     e94:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     e98:	912e6c21 	add	x1, x1, #0xb9b
     e9c:	2a1303e3 	mov	w3, w19
     ea0:	52800040 	mov	w0, #0x2                   	// #2
     ea4:	97fffdb9 	bl	588 <fprintf@plt>
    if(rfd >= 0)
     ea8:	37f8007a 	tbnz	w26, #31, eb4 <main+0x87c>
      close(rfd);
     eac:	2a1a03e0 	mov	w0, w26
     eb0:	97fffdda 	bl	618 <close@plt>
  uint seq = hdr->sequence;
     eb4:	b9401ac0 	ldr	w0, [x22, #24]
     eb8:	b90093e0 	str	w0, [sp, #144]
  printf("camshot: unpacking RAW10...\n");
     ebc:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     ec0:	91307000 	add	x0, x0, #0xc1c
     ec4:	97fffda1 	bl	548 <printf@plt>
  unpack_raw10(frame + sizeof(*hdr), hdr->bytesperline);
     ec8:	b9400ec1 	ldr	w1, [x22, #12]
     ecc:	9100a2c0 	add	x0, x22, #0x28
     ed0:	94000102 	bl	12d8 <unpack_raw10>
  free(frame);                      // hdr points into frame
     ed4:	aa1603e0 	mov	x0, x22
     ed8:	97fffdd4 	bl	628 <free@plt>
  if(pattern){
     edc:	34000815 	cbz	w21, fdc <main+0x9a4>
    *gain_r = *gain_b = 256;
     ee0:	52802000 	mov	w0, #0x100                 	// #256
     ee4:	291b03e0 	stp	w0, w0, [sp, #216]
    *level = 256;
     ee8:	b900e3e0 	str	w0, [sp, #224]
    printf("camshot: sensor test pattern; fixed WB/level\n");
     eec:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     ef0:	9129c000 	add	x0, x0, #0xa70
     ef4:	97fffd95 	bl	548 <printf@plt>
  int ow = half ? W / 2 : W, oh = half ? H / 2 : H;
     ef8:	b94272f6 	ldr	w22, [x23, #624]
     efc:	b9401315 	ldr	w21, [x24, #16]
     f00:	3400009c 	cbz	w28, f10 <main+0x8d8>
     f04:	52800040 	mov	w0, #0x2                   	// #2
     f08:	1ac00eb5 	sdiv	w21, w21, w0
     f0c:	1ac00ed6 	sdiv	w22, w22, w0
  struct convert conversion = { half, gain_r, gain_b, level };
     f10:	295b03fb 	ldp	w27, w0, [sp, #216]
     f14:	b9008be0 	str	w0, [sp, #136]
     f18:	b940e3f8 	ldr	w24, [sp, #224]
  if(endswith(out, ".jpg") || endswith(out, ".jpeg")){
     f1c:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     f20:	912a9021 	add	x1, x1, #0xaa4
  struct convert conversion = { half, gain_r, gain_b, level };
     f24:	2a0003e0 	mov	w0, w0
     f28:	291e6ffc 	stp	w28, w27, [sp, #240]
     f2c:	291f63e0 	stp	w0, w24, [sp, #248]
  if(endswith(out, ".jpg") || endswith(out, ".jpeg")){
     f30:	aa1403e0 	mov	x0, x20
     f34:	9400013e 	bl	142c <endswith>
     f38:	350000c0 	cbnz	w0, f50 <main+0x918>
     f3c:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     f40:	9130e421 	add	x1, x1, #0xc39
     f44:	aa1403e0 	mov	x0, x20
     f48:	94000139 	bl	142c <endswith>
     f4c:	340006c0 	cbz	w0, 1024 <main+0x9ec>
    printf("camshot: encoding baseline JPEG 4:2:0 quality=%d -> %s\n",
     f50:	b94087e1 	ldr	w1, [sp, #132]
     f54:	aa1403e2 	mov	x2, x20
     f58:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     f5c:	9130fc00 	add	x0, x0, #0xc3f
     f60:	97fffd7a 	bl	548 <printf@plt>
    int ofd = open(out, O_CREATE | O_WRONLY | O_TRUNC);
     f64:	aa1403e0 	mov	x0, x20
     f68:	5280c021 	mov	w1, #0x601                 	// #1537
     f6c:	97fffda3 	bl	5f8 <open@plt>
    uint jpeg_bytes = 0;
     f70:	b90103ff 	str	wzr, [sp, #256]
    int ofd = open(out, O_CREATE | O_WRONLY | O_TRUNC);
     f74:	2a0003f3 	mov	w19, w0
    if(ofd < 0 || jpeg_encode(ofd, ow, oh, quality, output_pixel,
     f78:	37f80140 	tbnz	w0, #31, fa0 <main+0x968>
     f7c:	b94087e3 	ldr	w3, [sp, #132]
     f80:	b0000004 	adrp	x4, 1000 <main+0x9c8>
     f84:	911a7084 	add	x4, x4, #0x69c
     f88:	910403e6 	add	x6, sp, #0x100
     f8c:	9103c3e5 	add	x5, sp, #0xf0
     f90:	2a1603e2 	mov	w2, w22
     f94:	2a1503e1 	mov	w1, w21
     f98:	940005b9 	bl	267c <jpeg_encode>
     f9c:	36f802c0 	tbz	w0, #31, ff4 <main+0x9bc>
      fprintf(2, "camshot: JPEG write failed: %s\n", out);
     fa0:	d0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
     fa4:	9131dc21 	add	x1, x1, #0xc77
     fa8:	aa1403e2 	mov	x2, x20
     fac:	52800040 	mov	w0, #0x2                   	// #2
     fb0:	97fffd76 	bl	588 <fprintf@plt>
      if(ofd >= 0)
     fb4:	37ffbbd3 	tbnz	w19, #31, 72c <main+0xf4>
        close(ofd);
     fb8:	2a1303e0 	mov	w0, w19
     fbc:	97fffd97 	bl	618 <close@plt>
      exit(1);
     fc0:	17fffddb 	b	72c <main+0xf4>
      printf("camshot: raw frame -> %s (%d bytes)\n", raw, n);
     fc4:	f94047e1 	ldr	x1, [sp, #136]
     fc8:	2a1303e2 	mov	w2, w19
     fcc:	d0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
     fd0:	912fdc00 	add	x0, x0, #0xbf7
     fd4:	97fffd5d 	bl	548 <printf@plt>
    if(rfd >= 0)
     fd8:	17ffffb5 	b	eac <main+0x874>
  printf("camshot: calculating white balance and level...\n");
     fdc:	b940abe0 	ldr	w0, [sp, #168]
     fe0:	910383e3 	add	x3, sp, #0xe0
     fe4:	910373e2 	add	x2, sp, #0xdc
     fe8:	910363e1 	add	x1, sp, #0xd8
     fec:	94000128 	bl	148c <compute_wb_level.part.0>
     ff0:	17ffffc2 	b	ef8 <main+0x8c0>
    close(ofd);
     ff4:	2a1303e0 	mov	w0, w19
     ff8:	97fffd88 	bl	618 <close@plt>
    printf("camshot: %dx%d frame %d, JPEG quality=%d, %d bytes -> %s\n",
     ffc:	b94087e4 	ldr	w4, [sp, #132]
    1000:	aa1403e6 	mov	x6, x20
    1004:	b94093e3 	ldr	w3, [sp, #144]
    1008:	2a1603e2 	mov	w2, w22
    100c:	b94103e5 	ldr	w5, [sp, #256]
    1010:	2a1503e1 	mov	w1, w21
    1014:	b0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
    1018:	91325c00 	add	x0, x0, #0xc97
    101c:	97fffd4b 	bl	548 <printf@plt>
    exit(0);
    1020:	17fffe74 	b	9f0 <main+0x3b8>
  if(!endswith(out, ".bmp")){
    1024:	b0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
    1028:	9123ec21 	add	x1, x1, #0x8fb
    102c:	aa1403e0 	mov	x0, x20
    1030:	940000ff 	bl	142c <endswith>
    1034:	35000080 	cbnz	w0, 1044 <main+0xa0c>
    fprintf(2, "camshot: output suffix must be .bmp, .jpg or .jpeg\n");
    1038:	b0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
    103c:	91334421 	add	x1, x1, #0xcd1
    1040:	17fffdb9 	b	724 <main+0xec>
  int row = (ow * 3 + 3) & ~3, img = row * oh;
    1044:	110006b3 	add	w19, w21, #0x1
  memset(bmp, 0, sizeof(bmp));
    1048:	528006c2 	mov	w2, #0x36                  	// #54
    104c:	52800001 	mov	w1, #0x0                   	// #0
    1050:	910403e0 	add	x0, sp, #0x100
  int row = (ow * 3 + 3) & ~3, img = row * oh;
    1054:	0b130673 	add	w19, w19, w19, lsl #1
  memset(bmp, 0, sizeof(bmp));
    1058:	97fffd54 	bl	5a8 <memset@plt>
  int row = (ow * 3 + 3) & ~3, img = row * oh;
    105c:	121e7673 	and	w19, w19, #0xfffffffc
  bmp[0] = 'B'; bmp[1] = 'M';
    1060:	5289a840 	mov	w0, #0x4d42                	// #19778
    1064:	790203e0 	strh	w0, [sp, #256]
  p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24;
    1068:	91040be0 	add	x0, sp, #0x102
    106c:	91042be1 	add	x1, sp, #0x10a
  int row = (ow * 3 + 3) & ~3, img = row * oh;
    1070:	1b137ed7 	mul	w23, w22, w19
  put32(bmp + 2, 54 + img);
    1074:	1100dafc 	add	w28, w23, #0x36
  p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24;
    1078:	b900001c 	str	w28, [x0]
    107c:	d28006c0 	mov	x0, #0x36                  	// #54
  printf("camshot: preparing output %s (%d bytes)...\n", out, 54 + img);
    1080:	2a1c03e2 	mov	w2, w28
  p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24;
    1084:	f2c00500 	movk	x0, #0x28, lsl #32
    1088:	f9000020 	str	x0, [x1]
    108c:	91044be0 	add	x0, sp, #0x112
    1090:	91049be1 	add	x1, sp, #0x126
    1094:	b9000015 	str	w21, [x0]
    1098:	91045be0 	add	x0, sp, #0x116
    109c:	b9000016 	str	w22, [x0]
  bmp[26] = 1;
    10a0:	52800020 	mov	w0, #0x1                   	// #1
    10a4:	39046be0 	strb	w0, [sp, #282]
  bmp[28] = 24;
    10a8:	52800300 	mov	w0, #0x18                  	// #24
    10ac:	390473e0 	strb	w0, [sp, #284]
  p[0] = v; p[1] = v >> 8; p[2] = v >> 16; p[3] = v >> 24;
    10b0:	91048be0 	add	x0, sp, #0x122
    10b4:	b9000017 	str	w23, [x0]
    10b8:	52816260 	mov	w0, #0xb13                 	// #2835
    10bc:	b9000020 	str	w0, [x1]
    10c0:	9104abe1 	add	x1, sp, #0x12a
    10c4:	b9000020 	str	w0, [x1]
  printf("camshot: preparing output %s (%d bytes)...\n", out, 54 + img);
    10c8:	aa1403e1 	mov	x1, x20
    10cc:	b0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
    10d0:	91341400 	add	x0, x0, #0xd05
    10d4:	97fffd1d 	bl	548 <printf@plt>
  int ofd = open(out, O_CREATE | O_WRONLY | O_TRUNC);
    10d8:	aa1403e0 	mov	x0, x20
    10dc:	5280c021 	mov	w1, #0x601                 	// #1537
    10e0:	97fffd46 	bl	5f8 <open@plt>
    10e4:	2a0003f7 	mov	w23, w0
  if(ofd < 0){
    10e8:	36f800a0 	tbz	w0, #31, 10fc <main+0xac4>
    fprintf(2, "camshot: cannot create %s\n", out);
    10ec:	b0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
    10f0:	9134c421 	add	x1, x1, #0xd31
    10f4:	aa1403e2 	mov	x2, x20
    10f8:	17ffff00 	b	cf8 <main+0x6c0>
  printf("camshot: output opened; writing BMP header...\n");
    10fc:	b0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
    1100:	91353000 	add	x0, x0, #0xd4c
    1104:	97fffd11 	bl	548 <printf@plt>
  if(write(ofd, bmp, 54) != 54){
    1108:	910403e1 	add	x1, sp, #0x100
    110c:	2a1703e0 	mov	w0, w23
    1110:	528006c2 	mov	w2, #0x36                  	// #54
    1114:	97fffd19 	bl	578 <write@plt>
    1118:	7100d81f 	cmp	w0, #0x36
    111c:	54000100 	b.eq	113c <main+0xb04>  // b.none
    fprintf(2, "camshot: cannot write BMP header to %s\n", out);
    1120:	b0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
    1124:	9135ec21 	add	x1, x1, #0xd7b
    1128:	aa1403e2 	mov	x2, x20
    112c:	52800040 	mov	w0, #0x2                   	// #2
    1130:	97fffd16 	bl	588 <fprintf@plt>
    close(ofd);
    1134:	2a1703e0 	mov	w0, w23
    1138:	17ffffa1 	b	fbc <main+0x984>
  uchar *lines = malloc(row * BMP_BATCH_ROWS);
    113c:	531c6e60 	lsl	w0, w19, #4
    1140:	97fffd0a 	bl	568 <malloc@plt>
    1144:	aa0003fa 	mov	x26, x0
  if(lines == 0){
    1148:	b50000c0 	cbnz	x0, 1160 <main+0xb28>
    fprintf(2, "camshot: out of memory for BMP output buffer\n");
    114c:	b0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
    1150:	91368c21 	add	x1, x1, #0xda3
    1154:	52800040 	mov	w0, #0x2                   	// #2
    1158:	97fffd0c 	bl	588 <fprintf@plt>
    115c:	17fffff6 	b	1134 <main+0xafc>
  printf("camshot: converting and writing %s (%d bytes)...\n", out,
    1160:	2a1c03e2 	mov	w2, w28
    1164:	aa1403e1 	mov	x1, x20
    1168:	b0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
    116c:	91374400 	add	x0, x0, #0xdd1
  for(int y = oh - 1; y >= 0; y--){
    1170:	510006d9 	sub	w25, w22, #0x1
  printf("camshot: converting and writing %s (%d bytes)...\n", out,
    1174:	97fffcf5 	bl	548 <printf@plt>
  int batch_rows = 0;
    1178:	52800007 	mov	w7, #0x0                   	// #0
  for(int y = oh - 1; y >= 0; y--){
    117c:	36f803d9 	tbz	w25, #31, 11f4 <main+0xbbc>
  close(ofd);
    1180:	2a1703e0 	mov	w0, w23
    1184:	97fffd25 	bl	618 <close@plt>
  free(lines);
    1188:	aa1a03e0 	mov	x0, x26
    118c:	97fffd27 	bl	628 <free@plt>
         level / 256, level % 256 * 10 / 256, out);
    1190:	12001f01 	and	w1, w24, #0xff
         gain_b / 256, gain_b % 256 * 10 / 256,
    1194:	52800142 	mov	w2, #0xa                   	// #10
    1198:	b9408be0 	ldr	w0, [sp, #136]
         ow, oh, seq, gain_r / 256, gain_r % 256 * 10 / 256,
    119c:	12001f65 	and	w5, w27, #0xff
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
    11a0:	b94093e3 	ldr	w3, [sp, #144]
    11a4:	53087f18 	lsr	w24, w24, #8
         level / 256, level % 256 * 10 / 256, out);
    11a8:	1b027c21 	mul	w1, w1, w2
         gain_b / 256, gain_b % 256 * 10 / 256,
    11ac:	12001c07 	and	w7, w0, #0xff
         ow, oh, seq, gain_r / 256, gain_r % 256 * 10 / 256,
    11b0:	1b027ca5 	mul	w5, w5, w2
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
    11b4:	b90003f8 	str	w24, [sp]
    11b8:	f9000bf4 	str	x20, [sp, #16]
    11bc:	53087f64 	lsr	w4, w27, #8
    11c0:	53087c21 	lsr	w1, w1, #8
         gain_b / 256, gain_b % 256 * 10 / 256,
    11c4:	1b027ce7 	mul	w7, w7, w2
  printf("camshot: %dx%d frame %d, WB R x%d.%d B x%d.%d, level x%d.%d -> %s\n",
    11c8:	b9000be1 	str	w1, [sp, #8]
    11cc:	53087ca5 	lsr	w5, w5, #8
    11d0:	b9408be1 	ldr	w1, [sp, #136]
    11d4:	2a1603e2 	mov	w2, w22
    11d8:	53087ce7 	lsr	w7, w7, #8
    11dc:	b0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
    11e0:	9139a000 	add	x0, x0, #0xe68
    11e4:	53087c26 	lsr	w6, w1, #8
    11e8:	2a1503e1 	mov	w1, w21
    11ec:	97fffcd7 	bl	548 <printf@plt>
    11f0:	17fffe00 	b	9f0 <main+0x3b8>
    uchar *line = lines + batch_rows * row;
    11f4:	1b137ce0 	mul	w0, w7, w19
    memset(line, 0, row);
    11f8:	52800001 	mov	w1, #0x0                   	// #0
    11fc:	2a1303e2 	mov	w2, w19
    uchar *line = lines + batch_rows * row;
    1200:	b90087e0 	str	w0, [sp, #132]
    1204:	b900a3e7 	str	w7, [sp, #160]
    1208:	8b20c346 	add	x6, x26, w0, sxtw
    memset(line, 0, row);
    120c:	f9004fe6 	str	x6, [sp, #152]
    1210:	aa0603e0 	mov	x0, x6
    1214:	97fffce5 	bl	5a8 <memset@plt>
    for(int x = 0; x < ow; x++){
    1218:	f9404fe6 	ldr	x6, [sp, #152]
    121c:	52800001 	mov	w1, #0x0                   	// #0
    1220:	b940a3e7 	ldr	w7, [sp, #160]
    1224:	6b0102bf 	cmp	w21, w1
    1228:	540002ac 	b.gt	127c <main+0xc44>
    batch_rows++;
    122c:	110004e7 	add	w7, w7, #0x1
    if((batch_rows == BMP_BATCH_ROWS || y == 0) &&
    1230:	7100033f 	cmp	w25, #0x0
    1234:	7a5018e4 	ccmp	w7, #0x10, #0x4, ne	// ne = any
    1238:	540004c1 	b.ne	12d0 <main+0xc98>  // b.any
       write(ofd, lines, batch_rows * row) != batch_rows * row){
    123c:	b94087e0 	ldr	w0, [sp, #132]
    1240:	aa1a03e1 	mov	x1, x26
    1244:	0b130002 	add	w2, w0, w19
    1248:	2a1703e0 	mov	w0, w23
    124c:	b90087e2 	str	w2, [sp, #132]
    1250:	97fffcca 	bl	578 <write@plt>
    if((batch_rows == BMP_BATCH_ROWS || y == 0) &&
    1254:	b94087e2 	ldr	w2, [sp, #132]
    1258:	6b00005f 	cmp	w2, w0
    125c:	54000380 	b.eq	12cc <main+0xc94>  // b.none
      fprintf(2, "camshot: write to %s failed (%d bytes; native xv6 files "
    1260:	2a1c03e3 	mov	w3, w28
    1264:	aa1403e2 	mov	x2, x20
    1268:	b0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
    126c:	91380c21 	add	x1, x1, #0xe03
    1270:	52800040 	mov	w0, #0x2                   	// #2
    1274:	97fffcc5 	bl	588 <fprintf@plt>
      exit(1);
    1278:	17fffd2d 	b	72c <main+0xf4>
      output_pixel(&conversion, x, y, &r, &g, &b);
    127c:	9103c3e0 	add	x0, sp, #0xf0
    1280:	910353e5 	add	x5, sp, #0xd4
    1284:	910343e4 	add	x4, sp, #0xd0
    1288:	91033fe3 	add	x3, sp, #0xcf
    128c:	2a1903e2 	mov	w2, w25
    1290:	b9009be1 	str	w1, [sp, #152]
    1294:	b900a3e7 	str	w7, [sp, #160]
    1298:	f90057e6 	str	x6, [sp, #168]
    129c:	94000100 	bl	169c <output_pixel>
      line[x * 3 + 0] = b;
    12a0:	f94057e6 	ldr	x6, [sp, #168]
    12a4:	394353e0 	ldrb	w0, [sp, #212]
    for(int x = 0; x < ow; x++){
    12a8:	b9409be1 	ldr	w1, [sp, #152]
    12ac:	91000cc6 	add	x6, x6, #0x3
      line[x * 3 + 0] = b;
    12b0:	381fd0c0 	sturb	w0, [x6, #-3]
      line[x * 3 + 1] = g;
    12b4:	394343e0 	ldrb	w0, [sp, #208]
    for(int x = 0; x < ow; x++){
    12b8:	11000421 	add	w1, w1, #0x1
      line[x * 3 + 1] = g;
    12bc:	381fe0c0 	sturb	w0, [x6, #-2]
      line[x * 3 + 2] = r;
    12c0:	39433fe0 	ldrb	w0, [sp, #207]
    12c4:	381ff0c0 	sturb	w0, [x6, #-1]
    for(int x = 0; x < ow; x++){
    12c8:	17ffffd6 	b	1220 <main+0xbe8>
      batch_rows = 0;
    12cc:	52800007 	mov	w7, #0x0                   	// #0
  for(int y = oh - 1; y >= 0; y--){
    12d0:	51000739 	sub	w25, w25, #0x1
    12d4:	17ffffaa 	b	117c <main+0xb44>

00000000000012d8 <unpack_raw10>:
  for(int y = 0; y < H; y++){
    12d8:	f0000003 	adrp	x3, 4000 <qbase_c+0xf88>
    12dc:	9109c062 	add	x2, x3, #0x270
    12e0:	d2800007 	mov	x7, #0x0                   	// #0
    12e4:	52800006 	mov	w6, #0x0                   	// #0
    12e8:	b942706b 	ldr	w11, [x3, #624]
        d[x + i] = v > BLACK ? v - BLACK : 0;
    12ec:	5280020d 	mov	w13, #0x10                  	// #16
    ushort *d = px + y * W;
    12f0:	f940044c 	ldr	x12, [x2, #8]
    12f4:	b940104a 	ldr	w10, [x2, #16]
  for(int y = 0; y < H; y++){
    12f8:	6b06017f 	cmp	w11, w6
    12fc:	5400004c 	b.gt	1304 <unpack_raw10+0x2c>
}
    1300:	d65f03c0 	ret
    const uchar *s = src + y * bpl;
    1304:	aa0003e5 	mov	x5, x0
    for(int x = 0; x < W; x += 4, s += 5){
    1308:	8b070589 	add	x9, x12, x7, lsl #1
    130c:	52800008 	mov	w8, #0x0                   	// #0
    1310:	6b08015f 	cmp	w10, w8
    1314:	540000ac 	b.gt	1328 <unpack_raw10+0x50>
  for(int y = 0; y < H; y++){
    1318:	110004c6 	add	w6, w6, #0x1
    131c:	8b21c000 	add	x0, x0, w1, sxtw
    1320:	8b2ac0e7 	add	x7, x7, w10, sxtw
    1324:	17fffff5 	b	12f8 <unpack_raw10+0x20>
        int v = (s[i] << 2) | ((lo >> (2 * i)) & 3);
    1328:	394010ae 	ldrb	w14, [x5, #4]
    132c:	d2800003 	mov	x3, #0x0                   	// #0
    1330:	386368a2 	ldrb	w2, [x5, x3]
    1334:	531f7864 	lsl	w4, w3, #1
    1338:	1ac429c4 	asr	w4, w14, w4
    133c:	12000484 	and	w4, w4, #0x3
    1340:	2a020882 	orr	w2, w4, w2, lsl #2
        d[x + i] = v > BLACK ? v - BLACK : 0;
    1344:	7100405f 	cmp	w2, #0x10
    1348:	1a8da042 	csel	w2, w2, w13, ge	// ge = tcont
    134c:	51004042 	sub	w2, w2, #0x10
    1350:	78237922 	strh	w2, [x9, x3, lsl #1]
      for(int i = 0; i < 4; i++){
    1354:	91000463 	add	x3, x3, #0x1
    1358:	f100107f 	cmp	x3, #0x4
    135c:	54fffea1 	b.ne	1330 <unpack_raw10+0x58>  // b.any
    for(int x = 0; x < W; x += 4, s += 5){
    1360:	11001108 	add	w8, w8, #0x4
    1364:	910014a5 	add	x5, x5, #0x5
    1368:	91002129 	add	x9, x9, #0x8
    136c:	17ffffe9 	b	1310 <unpack_raw10+0x38>

0000000000001370 <P>:
  if(x >= W) x = 2 * W - 2 - x;
    1370:	f0000005 	adrp	x5, 4000 <qbase_c+0xf88>
    1374:	9109c0a4 	add	x4, x5, #0x270
  if(x < 0) x = -x;
    1378:	7100001f 	cmp	w0, #0x0
    137c:	5a80a400 	cneg	w0, w0, lt	// lt = tstop
  if(x >= W) x = 2 * W - 2 - x;
    1380:	b9401083 	ldr	w3, [x4, #16]
    1384:	51000462 	sub	w2, w3, #0x1
    1388:	6b00007f 	cmp	w3, w0
    138c:	531f7842 	lsl	w2, w2, #1
    1390:	4b000042 	sub	w2, w2, w0
    1394:	1a82c000 	csel	w0, w0, w2, gt
  if(y >= H) y = 2 * H - 2 - y;
    1398:	b94270a2 	ldr	w2, [x5, #624]
  if(y < 0) y = -y;
    139c:	7100003f 	cmp	w1, #0x0
    13a0:	5a81a421 	cneg	w1, w1, lt	// lt = tstop
  if(y >= H) y = 2 * H - 2 - y;
    13a4:	6b02003f 	cmp	w1, w2
    13a8:	51000442 	sub	w2, w2, #0x1
    13ac:	531f7842 	lsl	w2, w2, #1
    13b0:	4b010042 	sub	w2, w2, w1
    13b4:	1a82b021 	csel	w1, w1, w2, lt	// lt = tstop
  return px[y * W + x];
    13b8:	1b010063 	madd	w3, w3, w1, w0
    13bc:	f9400480 	ldr	x0, [x4, #8]
}
    13c0:	7863d800 	ldrh	w0, [x0, w3, sxtw #1]
    13c4:	d65f03c0 	ret

00000000000013c8 <set_bayer>:
  if(format < CAM_FMT_SBGGR10P || format > CAM_FMT_SRGGB10P)
    13c8:	51000400 	sub	w0, w0, #0x1
    13cc:	71000c1f 	cmp	w0, #0x3
    13d0:	540001a8 	b.hi	1404 <set_bayer+0x3c>  // b.pmore
    bayer[i] = orders[format - CAM_FMT_SBGGR10P][i];
    13d4:	d37c7c00 	ubfiz	x0, x0, #4, #32
    13d8:	b0000002 	adrp	x2, 2000 <jpeg_encode_to+0x80>
    13dc:	913ae042 	add	x2, x2, #0xeb8
    13e0:	f0000001 	adrp	x1, 4000 <qbase_c+0xf88>
    13e4:	9109c021 	add	x1, x1, #0x270
    13e8:	8b000043 	add	x3, x2, x0
    13ec:	f8606840 	ldr	x0, [x2, x0]
    13f0:	f8014020 	stur	x0, [x1, #20]
    13f4:	f9400460 	ldr	x0, [x3, #8]
    13f8:	f801c020 	stur	x0, [x1, #28]
  return 0;
    13fc:	52800000 	mov	w0, #0x0                   	// #0
}
    1400:	d65f03c0 	ret
    return -1;
    1404:	12800000 	mov	w0, #0xffffffff            	// #-1
    1408:	17fffffe 	b	1400 <set_bayer+0x38>

000000000000140c <usage>:
{
    140c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: camshot [-o OUT.bmp|OUT.jpg] [-q QUALITY] "
    1410:	b0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
    1414:	911eb021 	add	x1, x1, #0x7ac
{
    1418:	910003fd 	mov	x29, sp
  fprintf(2, "usage: camshot [-o OUT.bmp|OUT.jpg] [-q QUALITY] "
    141c:	52800040 	mov	w0, #0x2                   	// #2
    1420:	97fffc5a 	bl	588 <fprintf@plt>
  exit(1);
    1424:	52800020 	mov	w0, #0x1                   	// #1
    1428:	97fffc68 	bl	5c8 <exit@plt>

000000000000142c <endswith>:
{
    142c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1430:	910003fd 	mov	x29, sp
    1434:	a90153f3 	stp	x19, x20, [sp, #16]
    1438:	aa0103f4 	mov	x20, x1
    143c:	f90013f5 	str	x21, [sp, #32]
    1440:	aa0003f5 	mov	x21, x0
  int n = strlen(path), m = strlen(suffix);
    1444:	97fffc69 	bl	5e8 <strlen@plt>
    1448:	93407c13 	sxtw	x19, w0
    144c:	aa1403e0 	mov	x0, x20
    1450:	97fffc66 	bl	5e8 <strlen@plt>
  return n >= m && strcmp(path + n - m, suffix) == 0;
    1454:	6b00027f 	cmp	w19, w0
    1458:	5400016b 	b.lt	1484 <endswith+0x58>  // b.tstop
    145c:	cb20c260 	sub	x0, x19, w0, sxtw
    1460:	aa1403e1 	mov	x1, x20
    1464:	8b0002a0 	add	x0, x21, x0
    1468:	97fffc54 	bl	5b8 <strcmp@plt>
    146c:	7100001f 	cmp	w0, #0x0
    1470:	1a9f17e0 	cset	w0, eq	// eq = none
}
    1474:	f94013f5 	ldr	x21, [sp, #32]
    1478:	a94153f3 	ldp	x19, x20, [sp, #16]
    147c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1480:	d65f03c0 	ret
  return n >= m && strcmp(path + n - m, suffix) == 0;
    1484:	52800000 	mov	w0, #0x0                   	// #0
    1488:	17fffffb 	b	1474 <endswith+0x48>

000000000000148c <compute_wb_level.part.0>:
compute_wb_level(int pattern, int wb, uint *gain_r, uint *gain_b, uint *level)
    148c:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    1490:	910003fd 	mov	x29, sp
    1494:	a90153f3 	stp	x19, x20, [sp, #16]
    1498:	aa0203f4 	mov	x20, x2
  for(int y = 0; y < H; y++){
    149c:	52800013 	mov	w19, #0x0                   	// #0
compute_wb_level(int pattern, int wb, uint *gain_r, uint *gain_b, uint *level)
    14a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    14a4:	aa0303f5 	mov	x21, x3
  memset(hist, 0, sizeof(hist));
    14a8:	f0000016 	adrp	x22, 4000 <qbase_c+0xf88>
    14ac:	910a52d6 	add	x22, x22, #0x294
compute_wb_level(int pattern, int wb, uint *gain_r, uint *gain_b, uint *level)
    14b0:	a90363f7 	stp	x23, x24, [sp, #48]
    14b4:	aa0103f7 	mov	x23, x1
  for(int y = 0; y < H; y++){
    14b8:	f0000018 	adrp	x24, 4000 <qbase_c+0xf88>
    14bc:	9109c318 	add	x24, x24, #0x270
compute_wb_level(int pattern, int wb, uint *gain_r, uint *gain_b, uint *level)
    14c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    14c4:	2a0003f9 	mov	w25, w0
  printf("camshot: calculating white balance and level...\n");
    14c8:	b0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
    14cc:	91216400 	add	x0, x0, #0x859
compute_wb_level(int pattern, int wb, uint *gain_r, uint *gain_b, uint *level)
    14d0:	f9002bfb 	str	x27, [sp, #80]
  printf("camshot: calculating white balance and level...\n");
    14d4:	97fffc1d 	bl	548 <printf@plt>
      sum[c] += value;
    14d8:	9101a3fa 	add	x26, sp, #0x68
  memset(hist, 0, sizeof(hist));
    14dc:	aa1603e0 	mov	x0, x22
  return bayer[(x & 1) + 2 * (y & 1)];
    14e0:	9100531b 	add	x27, x24, #0x14
  memset(hist, 0, sizeof(hist));
    14e4:	52820002 	mov	w2, #0x1000                	// #4096
    14e8:	52800001 	mov	w1, #0x0                   	// #0
  uint64 sum[3] = { 0, 0, 0 };
    14ec:	a906ffff 	stp	xzr, xzr, [sp, #104]
    14f0:	f9003fff 	str	xzr, [sp, #120]
  memset(hist, 0, sizeof(hist));
    14f4:	97fffc2d 	bl	5a8 <memset@plt>
  for(int y = 0; y < H; y++){
    14f8:	b9400302 	ldr	w2, [x24]
  uint want = (W * H / 2) / 100, seen = 0;
    14fc:	b9401306 	ldr	w6, [x24, #16]
  for(int y = 0; y < H; y++){
    1500:	6b02027f 	cmp	w19, w2
    1504:	540005aa 	b.ge	15b8 <compute_wb_level.part.0+0x12c>  // b.tcont
    1508:	f9400700 	ldr	x0, [x24, #8]
      int value = px[y * W + x];
    150c:	1b137cc1 	mul	w1, w6, w19
  return bayer[(x & 1) + 2 * (y & 1)];
    1510:	531f0268 	ubfiz	w8, w19, #1, #1
    1514:	8b21c401 	add	x1, x0, w1, sxtw #1
      int value = px[y * W + x];
    1518:	d2800000 	mov	x0, #0x0                   	// #0
    151c:	1400001c 	b	158c <compute_wb_level.part.0+0x100>
  return bayer[(x & 1) + 2 * (y & 1)];
    1520:	12000004 	and	w4, w0, #0x1
      int value = px[y * W + x];
    1524:	78607825 	ldrh	w5, [x1, x0, lsl #1]
  return bayer[(x & 1) + 2 * (y & 1)];
    1528:	0b080084 	add	w4, w4, w8
    152c:	2a0003e3 	mov	w3, w0
    1530:	b8645b64 	ldr	w4, [x27, w4, uxtw #2]
      if(c < R || c > B || value < 0 || value >= 1024){
    1534:	7100089f 	cmp	w4, #0x2
    1538:	54000068 	b.hi	1544 <compute_wb_level.part.0+0xb8>  // b.pmore
    153c:	710ffcbf 	cmp	w5, #0x3ff
    1540:	5400010d 	b.le	1560 <compute_wb_level.part.0+0xd4>
        fprintf(2, "camshot: corrupt mosaic row=%d col=%d c=%d value=%d\n",
    1544:	2a1303e2 	mov	w2, w19
    1548:	b0000001 	adrp	x1, 2000 <jpeg_encode_to+0x80>
    154c:	91222821 	add	x1, x1, #0x88a
    1550:	52800040 	mov	w0, #0x2                   	// #2
    1554:	97fffc0d 	bl	588 <fprintf@plt>
        exit(1);
    1558:	52800020 	mov	w0, #0x1                   	// #1
    155c:	97fffc1b 	bl	5c8 <exit@plt>
      sum[c] += value;
    1560:	d37d7c83 	ubfiz	x3, x4, #3, #32
    1564:	2a0503e7 	mov	w7, w5
    1568:	f8636b49 	ldr	x9, [x26, x3]
    156c:	8b254125 	add	x5, x9, w5, uxtw
    1570:	f8236b45 	str	x5, [x26, x3]
      if(c == G)
    1574:	7100049f 	cmp	w4, #0x1
    1578:	54000081 	b.ne	1588 <compute_wb_level.part.0+0xfc>  // b.any
        hist[value]++;
    157c:	b8677ac3 	ldr	w3, [x22, x7, lsl #2]
    1580:	11000463 	add	w3, w3, #0x1
    1584:	b8277ac3 	str	w3, [x22, x7, lsl #2]
    for(int x = 0; x < W; x++){
    1588:	91000400 	add	x0, x0, #0x1
    158c:	6b0000df 	cmp	w6, w0
    1590:	54fffc8c 	b.gt	1520 <compute_wb_level.part.0+0x94>
    if((y & 63) == 63)
    1594:	12001660 	and	w0, w19, #0x3f
    1598:	11000673 	add	w19, w19, #0x1
    159c:	7100fc1f 	cmp	w0, #0x3f
    15a0:	54fffac1 	b.ne	14f8 <compute_wb_level.part.0+0x6c>  // b.any
      printf("camshot: statistics %d/%d rows\n", y + 1, H);
    15a4:	2a1303e1 	mov	w1, w19
    15a8:	b0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
    15ac:	9122fc00 	add	x0, x0, #0x8bf
    15b0:	97fffbe6 	bl	548 <printf@plt>
  for(int y = 0; y < H; y++){
    15b4:	17ffffd1 	b	14f8 <compute_wb_level.part.0+0x6c>
  uint64 sum_r = sum[R], sum_g = sum[G], sum_b = sum[B];
    15b8:	a94683e1 	ldp	x1, x0, [sp, #104]
  *gain_r = *gain_b = 256;
    15bc:	52802004 	mov	w4, #0x100                 	// #256
    15c0:	b9000284 	str	w4, [x20]
    15c4:	b90002e4 	str	w4, [x23]
  uint64 sum_r = sum[R], sum_g = sum[G], sum_b = sum[B];
    15c8:	f9403fe3 	ldr	x3, [sp, #120]
  if(wb && sum_r && sum_b){
    15cc:	f100003f 	cmp	x1, #0x0
    15d0:	1a9f07e4 	cset	w4, ne	// ne = any
    15d4:	6a04033f 	tst	w25, w4
    15d8:	540002a0 	b.eq	162c <compute_wb_level.part.0+0x1a0>  // b.none
    15dc:	b4000283 	cbz	x3, 162c <compute_wb_level.part.0+0x1a0>
    *gain_r = (uint)(sum_g * 128 / sum_r);        // G counts 2 pixels
    15e0:	d379e000 	lsl	x0, x0, #7
    15e4:	9ac10801 	udiv	x1, x0, x1
    *gain_b = (uint)(sum_g * 128 / sum_b);
    15e8:	9ac30800 	udiv	x0, x0, x3
    if(*gain_r < 128) *gain_r = 128;
    15ec:	52801003 	mov	w3, #0x80                  	// #128
    *gain_r = (uint)(sum_g * 128 / sum_r);        // G counts 2 pixels
    15f0:	b90002e1 	str	w1, [x23]
    if(*gain_r > 1024) *gain_r = 1024;
    15f4:	52808001 	mov	w1, #0x400                 	// #1024
    *gain_b = (uint)(sum_g * 128 / sum_b);
    15f8:	b9000280 	str	w0, [x20]
    if(*gain_r < 128) *gain_r = 128;
    15fc:	b94002e4 	ldr	w4, [x23]
    1600:	6b03009f 	cmp	w4, w3
    1604:	1a832084 	csel	w4, w4, w3, cs	// cs = hs, nlast
    if(*gain_r > 1024) *gain_r = 1024;
    1608:	6b01009f 	cmp	w4, w1
    160c:	1a819084 	csel	w4, w4, w1, ls	// ls = plast
    1610:	b90002e4 	str	w4, [x23]
    if(*gain_b < 128) *gain_b = 128;
    1614:	b9400280 	ldr	w0, [x20]
    if(*gain_b > 1024) *gain_b = 1024;
    1618:	6b01001f 	cmp	w0, w1
    161c:	54000348 	b.hi	1684 <compute_wb_level.part.0+0x1f8>  // b.pmore
    if(*gain_b < 128) *gain_b = 128;
    1620:	6b03001f 	cmp	w0, w3
    1624:	1a832000 	csel	w0, w0, w3, cs	// cs = hs, nlast
    1628:	b9000280 	str	w0, [x20]
  uint want = (W * H / 2) / 100, seen = 0;
    162c:	1b067c42 	mul	w2, w2, w6
    1630:	52801900 	mov	w0, #0xc8                  	// #200
    1634:	d2807fe1 	mov	x1, #0x3ff                 	// #1023
    1638:	1ac00c42 	sdiv	w2, w2, w0
    163c:	52800000 	mov	w0, #0x0                   	// #0
  while(p99 > 0 && seen + hist[p99] < want)
    1640:	b8617ac3 	ldr	w3, [x22, x1, lsl #2]
    1644:	0b030000 	add	w0, w0, w3
    1648:	6b00005f 	cmp	w2, w0
    164c:	54000208 	b.hi	168c <compute_wb_level.part.0+0x200>  // b.pmore
  if(p99 < 128)
    1650:	7102003f 	cmp	w1, #0x80
    1654:	52801000 	mov	w0, #0x80                  	// #128
    1658:	1a80a021 	csel	w1, w1, w0, ge	// ge = tcont
  *level = 1023 * 256 / p99;                      // 8.8
    165c:	321827e0 	mov	w0, #0x3ff00               	// #261888
}
    1660:	f9402bfb 	ldr	x27, [sp, #80]
  *level = 1023 * 256 / p99;                      // 8.8
    1664:	1ac10800 	udiv	w0, w0, w1
    1668:	b90002a0 	str	w0, [x21]
}
    166c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1670:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1674:	a94363f7 	ldp	x23, x24, [sp, #48]
    1678:	a9446bf9 	ldp	x25, x26, [sp, #64]
    167c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    1680:	d65f03c0 	ret
    if(*gain_b > 1024) *gain_b = 1024;
    1684:	b9000281 	str	w1, [x20]
    1688:	17ffffe9 	b	162c <compute_wb_level.part.0+0x1a0>
  while(p99 > 0 && seen + hist[p99] < want)
    168c:	f1000421 	subs	x1, x1, #0x1
    1690:	54fffd81 	b.ne	1640 <compute_wb_level.part.0+0x1b4>  // b.any
    1694:	52800001 	mov	w1, #0x0                   	// #0
    1698:	17ffffee 	b	1650 <compute_wb_level.part.0+0x1c4>

000000000000169c <output_pixel>:
{
    169c:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    16a0:	aa0003ef 	mov	x15, x0
    16a4:	f000000e 	adrp	x14, 4000 <qbase_c+0xf88>
    16a8:	9109c1ce 	add	x14, x14, #0x270
    16ac:	910003fd 	mov	x29, sp
    16b0:	2a0103e9 	mov	w9, w1
    16b4:	a90153f3 	stp	x19, x20, [sp, #16]
    16b8:	2a0203ea 	mov	w10, w2
    16bc:	aa0303ed 	mov	x13, x3
    16c0:	a9025bf5 	stp	x21, x22, [sp, #32]
    16c4:	aa0403ec 	mov	x12, x4
    16c8:	aa0503eb 	mov	x11, x5
  if(c->half){
    16cc:	b9400000 	ldr	w0, [x0]
{
    16d0:	f9001bf7 	str	x23, [sp, #48]
  if(c->half){
    16d4:	34000720 	cbz	w0, 17b8 <output_pixel+0x11c>
      v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
    16d8:	531f7829 	lsl	w9, w1, #1
    16dc:	531f784a 	lsl	w10, w2, #1
    16e0:	910051ce 	add	x14, x14, #0x14
    16e4:	910103e7 	add	x7, sp, #0x40
    16e8:	d2800006 	mov	x6, #0x0                   	// #0
    int v[3] = { 0, 0, 0 };
    16ec:	f90023ff 	str	xzr, [sp, #64]
    16f0:	b9004bff 	str	wzr, [sp, #72]
      v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
    16f4:	120000c0 	and	w0, w6, #0x1
    16f8:	0b860541 	add	w1, w10, w6, asr #1
    16fc:	0b090000 	add	w0, w0, w9
    1700:	97ffff1c 	bl	1370 <P>
    1704:	b8a679c1 	ldrsw	x1, [x14, x6, lsl #2]
    for(int i = 0; i < 4; i++)
    1708:	910004c6 	add	x6, x6, #0x1
      v[bayer[i]] += P(2 * x + (i & 1), 2 * y + (i >> 1));
    170c:	d37ef421 	lsl	x1, x1, #2
    1710:	b86168e2 	ldr	w2, [x7, x1]
    1714:	0b000042 	add	w2, w2, w0
    1718:	b82168e2 	str	w2, [x7, x1]
    for(int i = 0; i < 4; i++)
    171c:	f10010df 	cmp	x6, #0x4
    1720:	54fffea1 	b.ne	16f4 <output_pixel+0x58>  // b.any
    g = v[G] / 2;
    1724:	294823e6 	ldp	w6, w8, [sp, #64]
    1728:	52800040 	mov	w0, #0x2                   	// #2
    b = v[B];
    172c:	b9404be7 	ldr	w7, [sp, #72]
    g = v[G] / 2;
    1730:	1ac00d08 	sdiv	w8, w8, w0
  uint lr = ((uint)r * c->gain_r / 256) * c->level / 256 / 4;
    1734:	294081e1 	ldp	w1, w0, [x15, #4]
    1738:	b9400de2 	ldr	w2, [x15, #12]
}
    173c:	a94153f3 	ldp	x19, x20, [sp, #16]
  uint lr = ((uint)r * c->gain_r / 256) * c->level / 256 / 4;
    1740:	1b017cc6 	mul	w6, w6, w1
  uint lb = ((uint)b * c->gain_b / 256) * c->level / 256 / 4;
    1744:	1b007ce7 	mul	w7, w7, w0
  *red = gamma22[lr > 255 ? 255 : lr];
    1748:	52801fe1 	mov	w1, #0xff                  	// #255
  uint lg = (uint)g * c->level / 256 / 4;
    174c:	1b027d08 	mul	w8, w8, w2
  *red = gamma22[lr > 255 ? 255 : lr];
    1750:	b0000000 	adrp	x0, 2000 <jpeg_encode_to+0x80>
    1754:	913ae000 	add	x0, x0, #0xeb8
  uint lr = ((uint)r * c->gain_r / 256) * c->level / 256 / 4;
    1758:	53087cc6 	lsr	w6, w6, #8
  uint lb = ((uint)b * c->gain_b / 256) * c->level / 256 / 4;
    175c:	53087ce7 	lsr	w7, w7, #8
  *red = gamma22[lr > 255 ? 255 : lr];
    1760:	91010000 	add	x0, x0, #0x40
  uint lg = (uint)g * c->level / 256 / 4;
    1764:	530a7d08 	lsr	w8, w8, #10
  uint lr = ((uint)r * c->gain_r / 256) * c->level / 256 / 4;
    1768:	1b027cc6 	mul	w6, w6, w2
  uint lb = ((uint)b * c->gain_b / 256) * c->level / 256 / 4;
    176c:	1b027ce7 	mul	w7, w7, w2
}
    1770:	a9425bf5 	ldp	x21, x22, [sp, #32]
  uint lr = ((uint)r * c->gain_r / 256) * c->level / 256 / 4;
    1774:	530a7cc6 	lsr	w6, w6, #10
  *red = gamma22[lr > 255 ? 255 : lr];
    1778:	6b0100df 	cmp	w6, w1
  uint lb = ((uint)b * c->gain_b / 256) * c->level / 256 / 4;
    177c:	530a7ce7 	lsr	w7, w7, #10
  *red = gamma22[lr > 255 ? 255 : lr];
    1780:	1a8190c6 	csel	w6, w6, w1, ls	// ls = plast
  *green = gamma22[lg > 255 ? 255 : lg];
    1784:	6b01011f 	cmp	w8, w1
    1788:	1a819108 	csel	w8, w8, w1, ls	// ls = plast
  *blue = gamma22[lb > 255 ? 255 : lb];
    178c:	6b0100ff 	cmp	w7, w1
    1790:	1a8190e7 	csel	w7, w7, w1, ls	// ls = plast
  *red = gamma22[lr > 255 ? 255 : lr];
    1794:	38666803 	ldrb	w3, [x0, x6]
  *green = gamma22[lg > 255 ? 255 : lg];
    1798:	38686802 	ldrb	w2, [x0, x8]
  *red = gamma22[lr > 255 ? 255 : lr];
    179c:	390001a3 	strb	w3, [x13]
  *blue = gamma22[lb > 255 ? 255 : lb];
    17a0:	38674800 	ldrb	w0, [x0, w7, uxtw]
  *green = gamma22[lg > 255 ? 255 : lg];
    17a4:	39000182 	strb	w2, [x12]
  *blue = gamma22[lb > 255 ? 255 : lb];
    17a8:	39000160 	strb	w0, [x11]
}
    17ac:	f9401bf7 	ldr	x23, [sp, #48]
    17b0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    17b4:	d65f03c0 	ret
  int cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
    17b8:	2a0203e1 	mov	w1, w2
    17bc:	11000532 	add	w18, w9, #0x1
    17c0:	51000520 	sub	w0, w9, #0x1
    17c4:	97fffeeb 	bl	1370 <P>
    17c8:	2a0a03e1 	mov	w1, w10
    17cc:	2a0003e7 	mov	w7, w0
    17d0:	2a1203e0 	mov	w0, w18
    17d4:	97fffee7 	bl	1370 <P>
    17d8:	51000541 	sub	w1, w10, #0x1
    17dc:	0b0000e7 	add	w7, w7, w0
    17e0:	2a0903e0 	mov	w0, w9
    17e4:	97fffee3 	bl	1370 <P>
    17e8:	11000541 	add	w1, w10, #0x1
    17ec:	0b0000e8 	add	w8, w7, w0
    17f0:	2a0003f3 	mov	w19, w0
    17f4:	2a0903e0 	mov	w0, w9
    17f8:	97fffede 	bl	1370 <P>
    17fc:	0b000108 	add	w8, w8, w0
  int diag  = (P(x-1,y-1) + P(x+1,y-1) + P(x-1,y+1) + P(x+1,y+1)) / 4;
    1800:	51000541 	sub	w1, w10, #0x1
  int cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
    1804:	2a0003f6 	mov	w22, w0
  int diag  = (P(x-1,y-1) + P(x+1,y-1) + P(x-1,y+1) + P(x+1,y+1)) / 4;
    1808:	51000520 	sub	w0, w9, #0x1
    180c:	97fffed9 	bl	1370 <P>
    1810:	51000541 	sub	w1, w10, #0x1
    1814:	2a0003e6 	mov	w6, w0
    1818:	2a1203e0 	mov	w0, w18
    181c:	97fffed5 	bl	1370 <P>
    1820:	11000541 	add	w1, w10, #0x1
    1824:	0b0000c6 	add	w6, w6, w0
    1828:	51000520 	sub	w0, w9, #0x1
    182c:	97fffed1 	bl	1370 <P>
    1830:	11000541 	add	w1, w10, #0x1
    1834:	0b0000c6 	add	w6, w6, w0
    1838:	2a1203e0 	mov	w0, w18
    183c:	97fffecd 	bl	1370 <P>
  int c = P(x, y);
    1840:	2a0a03e1 	mov	w1, w10
  int diag  = (P(x-1,y-1) + P(x+1,y-1) + P(x-1,y+1) + P(x+1,y+1)) / 4;
    1844:	0b0000c6 	add	w6, w6, w0
  return bayer[(x & 1) + 2 * (y & 1)];
    1848:	531f014a 	ubfiz	w10, w10, #1, #1
  int c = P(x, y);
    184c:	2a0903e0 	mov	w0, w9
  return bayer[(x & 1) + 2 * (y & 1)];
    1850:	12000129 	and	w9, w9, #0x1
    1854:	910051ce 	add	x14, x14, #0x14
    1858:	0b0a0129 	add	w9, w9, w10
  int c = P(x, y);
    185c:	97fffec5 	bl	1370 <P>
  int cross = (P(x-1,y) + P(x+1,y) + P(x,y-1) + P(x,y+1)) / 4;
    1860:	13027d08 	asr	w8, w8, #2
  int diag  = (P(x-1,y-1) + P(x+1,y-1) + P(x-1,y+1) + P(x+1,y+1)) / 4;
    1864:	13027cc6 	asr	w6, w6, #2
  return bayer[(x & 1) + 2 * (y & 1)];
    1868:	b86959c1 	ldr	w1, [x14, w9, uxtw #2]
  switch(colour(x, y)){
    186c:	340001e1 	cbz	w1, 18a8 <output_pixel+0x20c>
    1870:	7100083f 	cmp	w1, #0x2
    1874:	54000160 	b.eq	18a0 <output_pixel+0x204>  // b.none
  return bayer[(x & 1) + 2 * (y & 1)];
    1878:	12000241 	and	w1, w18, #0x1
  int vert  = (P(x,y-1) + P(x,y+1)) / 2;
    187c:	0b160273 	add	w19, w19, w22
  return bayer[(x & 1) + 2 * (y & 1)];
    1880:	0b0a0021 	add	w1, w1, w10
  int horiz = (P(x-1,y) + P(x+1,y)) / 2;
    1884:	13017ce7 	asr	w7, w7, #1
  int vert  = (P(x,y-1) + P(x,y+1)) / 2;
    1888:	13017e66 	asr	w6, w19, #1
    *g = c;
    188c:	2a0003e8 	mov	w8, w0
    if(colour(x + 1, y) == R){ *r = horiz; *b = vert; }
    1890:	b86159c1 	ldr	w1, [x14, w1, uxtw #2]
    1894:	35fff501 	cbnz	w1, 1734 <output_pixel+0x98>
    1898:	2a0603e0 	mov	w0, w6
    189c:	2a0703e6 	mov	w6, w7
  switch(colour(x, y)){
    18a0:	2a0003e7 	mov	w7, w0
    18a4:	17ffffa4 	b	1734 <output_pixel+0x98>
  case R: *r = c; *g = cross; *b = diag; break;
    18a8:	2a0603e7 	mov	w7, w6
    18ac:	2a0003e6 	mov	w6, w0
    18b0:	17ffffa1 	b	1734 <output_pixel+0x98>

00000000000018b4 <make_quant>:
}

static void
make_quant(uchar out[64], const uchar base[64], int quality)
{
  int scale = quality < 50 ? 5000 / quality : 200 - quality * 2;
    18b4:	7100c45f 	cmp	w2, #0x31
    18b8:	5400026c 	b.gt	1904 <make_quant+0x50>
    18bc:	52827104 	mov	w4, #0x1388                	// #5000
    18c0:	1ac20882 	udiv	w2, w4, w2
{
    18c4:	d2800004 	mov	x4, #0x0                   	// #0
  for(int i = 0; i < 64; i++){
    int q = (base[i] * scale + 50) / 100;
    if(q < 1) q = 1;
    if(q > 255) q = 255;
    18c8:	528c79a5 	mov	w5, #0x63cd                	// #25549
    int q = (base[i] * scale + 50) / 100;
    18cc:	52800c86 	mov	w6, #0x64                  	// #100
    18d0:	38646823 	ldrb	w3, [x1, x4]
    18d4:	1b027c63 	mul	w3, w3, w2
    if(q < 1) q = 1;
    18d8:	7100c47f 	cmp	w3, #0x31
    18dc:	540001cd 	b.le	1914 <make_quant+0x60>
    if(q > 255) q = 255;
    18e0:	6b05007f 	cmp	w3, w5
    18e4:	540001cc 	b.gt	191c <make_quant+0x68>
    int q = (base[i] * scale + 50) / 100;
    18e8:	1100c863 	add	w3, w3, #0x32
    18ec:	1ac60863 	udiv	w3, w3, w6
    out[i] = q;
    18f0:	38246803 	strb	w3, [x0, x4]
  for(int i = 0; i < 64; i++){
    18f4:	91000484 	add	x4, x4, #0x1
    18f8:	f101009f 	cmp	x4, #0x40
    18fc:	54fffea1 	b.ne	18d0 <make_quant+0x1c>  // b.any
  }
}
    1900:	d65f03c0 	ret
  int scale = quality < 50 ? 5000 / quality : 200 - quality * 2;
    1904:	52800c83 	mov	w3, #0x64                  	// #100
    1908:	4b020062 	sub	w2, w3, w2
    190c:	531f7842 	lsl	w2, w2, #1
    1910:	17ffffed 	b	18c4 <make_quant+0x10>
    if(q < 1) q = 1;
    1914:	52800023 	mov	w3, #0x1                   	// #1
    1918:	17fffff6 	b	18f0 <make_quant+0x3c>
    if(q > 255) q = 255;
    191c:	52801fe3 	mov	w3, #0xff                  	// #255
    1920:	17fffff4 	b	18f0 <make_quant+0x3c>

0000000000001924 <jflush>:
{
    1924:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1928:	910003fd 	mov	x29, sp
    192c:	a90153f3 	stp	x19, x20, [sp, #16]
    1930:	aa0003f3 	mov	x19, x0
  if(w->mem)
    1934:	f9400400 	ldr	x0, [x0, #8]
{
    1938:	f90013f5 	str	x21, [sp, #32]
  if(w->mem)
    193c:	b4000360 	cbz	x0, 19a8 <jflush+0x84>
    return w->error ? -1 : 0;   // memory mode: jbyte() wrote directly
    1940:	b9401660 	ldr	w0, [x19, #20]
    1944:	7100001f 	cmp	w0, #0x0
    1948:	5a9f03e0 	csetm	w0, ne	// ne = any
}
    194c:	f94013f5 	ldr	x21, [sp, #32]
    1950:	a94153f3 	ldp	x19, x20, [sp, #16]
    1954:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1958:	d65f03c0 	ret
    int n = write(w->fd, w->out + done, w->used - done);
    195c:	b9400260 	ldr	w0, [x19]
    1960:	4b140042 	sub	w2, w2, w20
    1964:	8b34c2a1 	add	x1, x21, w20, sxtw
    1968:	97fffb04 	bl	578 <write@plt>
    if(n <= 0){
    196c:	7100001f 	cmp	w0, #0x0
    1970:	540000ac 	b.gt	1984 <jflush+0x60>
      w->error = 1;
    1974:	52800020 	mov	w0, #0x1                   	// #1
    1978:	b9001660 	str	w0, [x19, #20]
      return -1;
    197c:	12800000 	mov	w0, #0xffffffff            	// #-1
    1980:	17fffff3 	b	194c <jflush+0x28>
    done += n;
    1984:	0b000294 	add	w20, w20, w0
  while(done < w->used){
    1988:	b9401e62 	ldr	w2, [x19, #28]
    198c:	6b02029f 	cmp	w20, w2
    1990:	54fffe6b 	b.lt	195c <jflush+0x38>  // b.tstop
  w->total += w->used;
    1994:	b9401a60 	ldr	w0, [x19, #24]
    1998:	0b020000 	add	w0, w0, w2
    199c:	29037e60 	stp	w0, wzr, [x19, #24]
  return 0;
    19a0:	52800000 	mov	w0, #0x0                   	// #0
    19a4:	17ffffea 	b	194c <jflush+0x28>
    int n = write(w->fd, w->out + done, w->used - done);
    19a8:	91008275 	add	x21, x19, #0x20
  int done = 0;
    19ac:	52800014 	mov	w20, #0x0                   	// #0
    19b0:	17fffff6 	b	1988 <jflush+0x64>

00000000000019b4 <jbyte>:
{
    19b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    19b8:	910003fd 	mov	x29, sp
    19bc:	a90153f3 	stp	x19, x20, [sp, #16]
    19c0:	2a0103f4 	mov	w20, w1
  if(w->error)
    19c4:	b9401401 	ldr	w1, [x0, #20]
    19c8:	35000141 	cbnz	w1, 19f0 <jbyte+0x3c>
  if(w->mem){
    19cc:	f9400401 	ldr	x1, [x0, #8]
    19d0:	aa0003f3 	mov	x19, x0
    19d4:	b40001c1 	cbz	x1, 1a0c <jbyte+0x58>
    if(w->total >= w->cap){
    19d8:	b9401002 	ldr	w2, [x0, #16]
    19dc:	b9401800 	ldr	w0, [x0, #24]
    19e0:	6b02001f 	cmp	w0, w2
    19e4:	540000c3 	b.cc	19fc <jbyte+0x48>  // b.lo, b.ul, b.last
      w->error = 1;
    19e8:	52800020 	mov	w0, #0x1                   	// #1
    19ec:	b9001660 	str	w0, [x19, #20]
}
    19f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    19f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    19f8:	d65f03c0 	ret
    w->mem[w->total++] = value;
    19fc:	11000402 	add	w2, w0, #0x1
    1a00:	b9001a62 	str	w2, [x19, #24]
    1a04:	38204834 	strb	w20, [x1, w0, uxtw]
    return;
    1a08:	17fffffa 	b	19f0 <jbyte+0x3c>
  if(w->used == OUTBUF && jflush(w) < 0)
    1a0c:	b9401c01 	ldr	w1, [x0, #28]
    1a10:	7140043f 	cmp	w1, #0x1, lsl #12
    1a14:	540000e0 	b.eq	1a30 <jbyte+0x7c>  // b.none
  w->out[w->used++] = value;
    1a18:	b9401e60 	ldr	w0, [x19, #28]
    1a1c:	11000401 	add	w1, w0, #0x1
    1a20:	b9001e61 	str	w1, [x19, #28]
    1a24:	8b20c260 	add	x0, x19, w0, sxtw
    1a28:	39008014 	strb	w20, [x0, #32]
    1a2c:	17fffff1 	b	19f0 <jbyte+0x3c>
  if(w->used == OUTBUF && jflush(w) < 0)
    1a30:	97ffffbd 	bl	1924 <jflush>
    1a34:	3100041f 	cmn	w0, #0x1
    1a38:	54ffff01 	b.ne	1a18 <jbyte+0x64>  // b.any
    1a3c:	17ffffed 	b	19f0 <jbyte+0x3c>

0000000000001a40 <jword>:
{
    1a40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a44:	910003fd 	mov	x29, sp
    1a48:	a90153f3 	stp	x19, x20, [sp, #16]
    1a4c:	aa0003f4 	mov	x20, x0
    1a50:	2a0103f3 	mov	w19, w1
  jbyte(w, value >> 8);
    1a54:	13087c21 	asr	w1, w1, #8
    1a58:	97ffffd7 	bl	19b4 <jbyte>
  jbyte(w, value);
    1a5c:	2a1303e1 	mov	w1, w19
    1a60:	aa1403e0 	mov	x0, x20
}
    1a64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1a68:	a8c27bfd 	ldp	x29, x30, [sp], #32
  jbyte(w, value);
    1a6c:	17ffffd2 	b	19b4 <jbyte>

0000000000001a70 <jmarker>:
{
    1a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1a74:	910003fd 	mov	x29, sp
    1a78:	f9000bf3 	str	x19, [sp, #16]
    1a7c:	2a0103f3 	mov	w19, w1
  jbyte(w, 0xff);
    1a80:	52801fe1 	mov	w1, #0xff                  	// #255
{
    1a84:	f90017e0 	str	x0, [sp, #40]
  jbyte(w, 0xff);
    1a88:	97ffffcb 	bl	19b4 <jbyte>
  jbyte(w, marker);
    1a8c:	f94017e0 	ldr	x0, [sp, #40]
    1a90:	2a1303e1 	mov	w1, w19
}
    1a94:	f9400bf3 	ldr	x19, [sp, #16]
    1a98:	a8c37bfd 	ldp	x29, x30, [sp], #48
  jbyte(w, marker);
    1a9c:	17ffffc6 	b	19b4 <jbyte>

0000000000001aa0 <put_bits>:
  if(count <= 0 || w->error)
    1aa0:	7100005f 	cmp	w2, #0x0
    1aa4:	540005ad 	b.le	1b58 <put_bits+0xb8>
{
    1aa8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1aac:	910003fd 	mov	x29, sp
    1ab0:	a90153f3 	stp	x19, x20, [sp, #16]
    1ab4:	aa0003f3 	mov	x19, x0
  if(count <= 0 || w->error)
    1ab8:	b9401400 	ldr	w0, [x0, #20]
{
    1abc:	f90013f5 	str	x21, [sp, #32]
  if(count <= 0 || w->error)
    1ac0:	350003a0 	cbnz	w0, 1b34 <put_bits+0x94>
  value &= (1U << count) - 1;
    1ac4:	12800015 	mov	w21, #0xffffffff            	// #-1
    1ac8:	1ac222a0 	lsl	w0, w21, w2
    1acc:	0a200021 	bic	w1, w1, w0
  w->bits = (w->bits << count) | value;
    1ad0:	b9502260 	ldr	w0, [x19, #4128]
    1ad4:	1ac22000 	lsl	w0, w0, w2
    1ad8:	2a000021 	orr	w1, w1, w0
  w->nbits += count;
    1adc:	b9502660 	ldr	w0, [x19, #4132]
  w->bits = (w->bits << count) | value;
    1ae0:	b9102261 	str	w1, [x19, #4128]
  w->nbits += count;
    1ae4:	0b000042 	add	w2, w2, w0
    1ae8:	b9102662 	str	w2, [x19, #4132]
  while(w->nbits >= 8){
    1aec:	71001c5f 	cmp	w2, #0x7
    1af0:	5400022d 	b.le	1b34 <put_bits+0x94>
    w->nbits -= 8;
    1af4:	51002042 	sub	w2, w2, #0x8
    entropy_byte(w, w->bits >> w->nbits);
    1af8:	b9502274 	ldr	w20, [x19, #4128]
    w->nbits -= 8;
    1afc:	b9102662 	str	w2, [x19, #4132]
  jbyte(w, value);
    1b00:	aa1303e0 	mov	x0, x19
    entropy_byte(w, w->bits >> w->nbits);
    1b04:	1ac22694 	lsr	w20, w20, w2
  jbyte(w, value);
    1b08:	2a1403e1 	mov	w1, w20
  if((value & 255) == 255)
    1b0c:	12001e94 	and	w20, w20, #0xff
  jbyte(w, value);
    1b10:	97ffffa9 	bl	19b4 <jbyte>
  if((value & 255) == 255)
    1b14:	7103fe9f 	cmp	w20, #0xff
    1b18:	54000081 	b.ne	1b28 <put_bits+0x88>  // b.any
    jbyte(w, 0);                    // JPEG byte stuffing
    1b1c:	aa1303e0 	mov	x0, x19
    1b20:	52800001 	mov	w1, #0x0                   	// #0
    1b24:	97ffffa4 	bl	19b4 <jbyte>
    if(w->nbits)
    1b28:	b9502662 	ldr	w2, [x19, #4132]
    1b2c:	350000c2 	cbnz	w2, 1b44 <put_bits+0xa4>
    1b30:	b910227f 	str	wzr, [x19, #4128]
}
    1b34:	f94013f5 	ldr	x21, [sp, #32]
    1b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    1b3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1b40:	d65f03c0 	ret
      w->bits &= (1U << w->nbits) - 1;
    1b44:	b9502260 	ldr	w0, [x19, #4128]
    1b48:	1ac222a1 	lsl	w1, w21, w2
    1b4c:	0a210000 	bic	w0, w0, w1
    1b50:	b9102260 	str	w0, [x19, #4128]
    1b54:	17ffffe6 	b	1aec <put_bits+0x4c>
    1b58:	d65f03c0 	ret

0000000000001b5c <encode_block>:
// AC uses one eight-bit code per useful baseline symbol: EOB, ZRL, then all
// (run 0..15, size 1..10) combinations.  162/256 of the code space is used.
static void
encode_block(struct jw *w, const short input[64], const uchar quant[64],
             int *previous_dc)
{
    1b5c:	d10883ff 	sub	sp, sp, #0x220
  o[2] = 15137 * a + 6270 * b;
    1b60:	52830fd1 	mov	w17, #0x187e                	// #6270
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1b64:	5286a6eb 	mov	w11, #0x3537                	// #13623
    1b68:	528471d0 	mov	w16, #0x238e                	// #9102
    1b6c:	52818f8d 	mov	w13, #0xc7c                 	// #3196
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    1b70:	1287d88c 	mov	w12, #0xffffc13b            	// #-16069
{
    1b74:	a9007bfd 	stp	x29, x30, [sp]
    1b78:	910003fd 	mov	x29, sp
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    1b7c:	128471af 	mov	w15, #0xffffdc72            	// #-9102
{
    1b80:	a90153f3 	stp	x19, x20, [sp, #16]
    1b84:	aa0003f3 	mov	x19, x0
  short coefficient[64];
  fdct_quant(input, quant, coefficient);
    1b88:	910483e0 	add	x0, sp, #0x120
{
    1b8c:	aa0003e9 	mov	x9, x0
    1b90:	a9025bf5 	stp	x21, x22, [sp, #32]
    1b94:	91020035 	add	x21, x1, #0x80
    1b98:	a90573fb 	stp	x27, x28, [sp, #80]
    1b9c:	aa0203fb 	mov	x27, x2
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1ba0:	5285a834 	mov	w20, #0x2d41                	// #11585
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    1ba4:	12818f76 	mov	w22, #0xfffff384            	// #-3196
{
    1ba8:	a90363f7 	stp	x23, x24, [sp, #48]
  o[6] = 6270 * a - 15137 * b;
    1bac:	12876418 	mov	w24, #0xffffc4df            	// #-15137
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1bb0:	5287d8b7 	mov	w23, #0x3ec5                	// #16069
{
    1bb4:	a9046bf9 	stp	x25, x26, [sp, #64]
  o[2] = 15137 * a + 6270 * b;
    1bb8:	52876439 	mov	w25, #0x3b21                	// #15137
  int s0 = x[0] + x[7], d0 = x[0] - x[7];
    1bbc:	79c01c24 	ldrsh	w4, [x1, #14]
  for(int y = 0; y < 8; y++)
    1bc0:	91004021 	add	x1, x1, #0x10
  int s0 = x[0] + x[7], d0 = x[0] - x[7];
    1bc4:	78df0026 	ldursh	w6, [x1, #-16]
  for(int y = 0; y < 8; y++)
    1bc8:	91008129 	add	x9, x9, #0x20
  int s1 = x[1] + x[6], d1 = x[1] - x[6];
    1bcc:	78df2027 	ldursh	w7, [x1, #-14]
  int s0 = x[0] + x[7], d0 = x[0] - x[7];
    1bd0:	0b0400c2 	add	w2, w6, w4
    1bd4:	4b0400c6 	sub	w6, w6, w4
  int s1 = x[1] + x[6], d1 = x[1] - x[6];
    1bd8:	78dfc024 	ldursh	w4, [x1, #-4]
  int s2 = x[2] + x[5], d2 = x[2] - x[5];
    1bdc:	78df4025 	ldursh	w5, [x1, #-12]
  int s1 = x[1] + x[6], d1 = x[1] - x[6];
    1be0:	0b0400fe 	add	w30, w7, w4
    1be4:	4b0400e7 	sub	w7, w7, w4
  int s2 = x[2] + x[5], d2 = x[2] - x[5];
    1be8:	78dfa024 	ldursh	w4, [x1, #-6]
  int s3 = x[3] + x[4], d3 = x[3] - x[4];
    1bec:	78df8028 	ldursh	w8, [x1, #-8]
  int s2 = x[2] + x[5], d2 = x[2] - x[5];
    1bf0:	0b0400bc 	add	w28, w5, w4
    1bf4:	4b0400a5 	sub	w5, w5, w4
  int s3 = x[3] + x[4], d3 = x[3] - x[4];
    1bf8:	78df6024 	ldursh	w4, [x1, #-10]
  int a = s0 - s3, b = s1 - s2;
    1bfc:	4b1c03ca 	sub	w10, w30, w28
  int s3 = x[3] + x[4], d3 = x[3] - x[4];
    1c00:	0b08009a 	add	w26, w4, w8
    1c04:	4b080084 	sub	w4, w4, w8
  int a = s0 - s3, b = s1 - s2;
    1c08:	4b1a0052 	sub	w18, w2, w26
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1c0c:	0b1e0048 	add	w8, w2, w30
  o[2] = 15137 * a + 6270 * b;
    1c10:	1b117d4e 	mul	w14, w10, w17
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1c14:	0b1c0108 	add	w8, w8, w28
  o[6] = 6270 * a - 15137 * b;
    1c18:	1b187d4a 	mul	w10, w10, w24
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1c1c:	0b1a0108 	add	w8, w8, w26
  o[2] = 15137 * a + 6270 * b;
    1c20:	1b193a4e 	madd	w14, w18, w25, w14
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1c24:	4b1e0042 	sub	w2, w2, w30
  o[6] = 6270 * a - 15137 * b;
    1c28:	1b112a4a 	madd	w10, w18, w17, w10
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1c2c:	4b1c0042 	sub	w2, w2, w28
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1c30:	1b0b7cf2 	mul	w18, w7, w11
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1c34:	0b1a0042 	add	w2, w2, w26
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1c38:	1b1748d2 	madd	w18, w6, w23, w18
    1c3c:	1b1048b2 	madd	w18, w5, w16, w18
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1c40:	1b147d08 	mul	w8, w8, w20
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1c44:	1b0d4892 	madd	w18, w4, w13, w18
    1c48:	293c4928 	stp	w8, w18, [x9, #-32]
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    1c4c:	1b167ce8 	mul	w8, w7, w22
    1c50:	1b0b20c8 	madd	w8, w6, w11, w8
    1c54:	1b0c20a8 	madd	w8, w5, w12, w8
    1c58:	1b0f2088 	madd	w8, w4, w15, w8
    1c5c:	293d212e 	stp	w14, w8, [x9, #-24]
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1c60:	1b0c7ce8 	mul	w8, w7, w12
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1c64:	1b0f7ce7 	mul	w7, w7, w15
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1c68:	1b1020c8 	madd	w8, w6, w16, w8
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1c6c:	1b0d1cc6 	madd	w6, w6, w13, w7
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1c70:	1b0d20a8 	madd	w8, w5, w13, w8
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1c74:	1b0b18a5 	madd	w5, w5, w11, w6
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1c78:	1b0b2088 	madd	w8, w4, w11, w8
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1c7c:	1b147c42 	mul	w2, w2, w20
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1c80:	1b0c1484 	madd	w4, w4, w12, w5
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1c84:	293e2122 	stp	w2, w8, [x9, #-16]
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1c88:	293f112a 	stp	w10, w4, [x9, #-8]
  for(int y = 0; y < 8; y++)
    1c8c:	eb0102bf 	cmp	x21, x1
    1c90:	54fff961 	b.ne	1bbc <encode_block+0x60>  // b.any
    1c94:	910283ea 	add	x10, sp, #0xa0
      long long sum = coefficient[v];
    1c98:	910183fc 	add	x28, sp, #0x60
  for(int y = 0; y < 8; y++)
    1c9c:	d2800009 	mov	x9, #0x0                   	// #0
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1ca0:	d285a83e 	mov	x30, #0x2d41                	// #11585
  o[2] = 15137 * a + 6270 * b;
    1ca4:	d2876437 	mov	x23, #0x3b21                	// #15137
    1ca8:	d2830fc2 	mov	x2, #0x187e                	// #6270
  o[6] = 6270 * a - 15137 * b;
    1cac:	92876418 	mov	x24, #0xffffffffffffc4df    	// #-15137
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1cb0:	d287d8b9 	mov	x25, #0x3ec5                	// #16069
    1cb4:	d286a6eb 	mov	x11, #0x3537                	// #13623
    1cb8:	d28471d4 	mov	x20, #0x238e                	// #9102
    1cbc:	d2818f8e 	mov	x14, #0xc7c                 	// #3196
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    1cc0:	92818f7a 	mov	x26, #0xfffffffffffff384    	// #-3196
    1cc4:	9287d88f 	mov	x15, #0xffffffffffffc13b    	// #-16069
    1cc8:	928471b5 	mov	x21, #0xffffffffffffdc72    	// #-9102
    1ccc:	d2a40016 	mov	x22, #0x20000000            	// #536870912
  long long s0 = (long long)x[0]  + x[56];
    1cd0:	b980e004 	ldrsw	x4, [x0, #224]
    1cd4:	b9800006 	ldrsw	x6, [x0]
  long long s1 = (long long)x[8]  + x[48];
    1cd8:	b9802007 	ldrsw	x7, [x0, #32]
  long long s0 = (long long)x[0]  + x[56];
    1cdc:	8b0400c1 	add	x1, x6, x4
  long long d0 = (long long)x[0]  - x[56];
    1ce0:	cb0400c6 	sub	x6, x6, x4
  long long s1 = (long long)x[8]  + x[48];
    1ce4:	b980c004 	ldrsw	x4, [x0, #192]
  long long s2 = (long long)x[16] + x[40];
    1ce8:	b9804005 	ldrsw	x5, [x0, #64]
  long long s1 = (long long)x[8]  + x[48];
    1cec:	8b0400f2 	add	x18, x7, x4
  long long d1 = (long long)x[8]  - x[48];
    1cf0:	cb0400e7 	sub	x7, x7, x4
  long long s2 = (long long)x[16] + x[40];
    1cf4:	b980a004 	ldrsw	x4, [x0, #160]
  long long s3 = (long long)x[24] + x[32];
    1cf8:	b9808008 	ldrsw	x8, [x0, #128]
  long long s2 = (long long)x[16] + x[40];
    1cfc:	8b0400b1 	add	x17, x5, x4
  long long d2 = (long long)x[16] - x[40];
    1d00:	cb0400a5 	sub	x5, x5, x4
  long long s3 = (long long)x[24] + x[32];
    1d04:	b9806004 	ldrsw	x4, [x0, #96]
  long long a = s0 - s3, b = s1 - s2;
    1d08:	cb11024d 	sub	x13, x18, x17
  long long s3 = (long long)x[24] + x[32];
    1d0c:	8b080090 	add	x16, x4, x8
  long long d3 = (long long)x[24] - x[32];
    1d10:	cb080084 	sub	x4, x4, x8
  long long a = s0 - s3, b = s1 - s2;
    1d14:	cb10002c 	sub	x12, x1, x16
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1d18:	8b120028 	add	x8, x1, x18
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1d1c:	cb120021 	sub	x1, x1, x18
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1d20:	8b110108 	add	x8, x8, x17
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1d24:	cb110021 	sub	x1, x1, x17
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1d28:	8b100108 	add	x8, x8, x16
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1d2c:	8b100021 	add	x1, x1, x16
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1d30:	9b1e7d08 	mul	x8, x8, x30
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1d34:	9b1e7c21 	mul	x1, x1, x30
  o[0] = 11585 * (s0 + s1 + s2 + s3);
    1d38:	f90033e8 	str	x8, [sp, #96]
  o[4] = 11585 * (s0 - s1 - s2 + s3);
    1d3c:	f90043e1 	str	x1, [sp, #128]
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1d40:	9b0b7ce1 	mul	x1, x7, x11
    1d44:	9b1904c1 	madd	x1, x6, x25, x1
  o[2] = 15137 * a + 6270 * b;
    1d48:	9b027da8 	mul	x8, x13, x2
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1d4c:	9b1404a1 	madd	x1, x5, x20, x1
    1d50:	9b0e0481 	madd	x1, x4, x14, x1
  o[2] = 15137 * a + 6270 * b;
    1d54:	9b172188 	madd	x8, x12, x23, x8
  o[1] = 16069*d0 + 13623*d1 +  9102*d2 +  3196*d3;
    1d58:	a906a3e1 	stp	x1, x8, [sp, #104]
  o[3] = 13623*d0 -  3196*d1 - 16069*d2 -  9102*d3;
    1d5c:	9b1a7ce1 	mul	x1, x7, x26
    1d60:	9b0b04c1 	madd	x1, x6, x11, x1
    1d64:	9b0f04a1 	madd	x1, x5, x15, x1
    1d68:	9b150481 	madd	x1, x4, x21, x1
    1d6c:	f9003fe1 	str	x1, [sp, #120]
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1d70:	9b0f7ce1 	mul	x1, x7, x15
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1d74:	9b157ce7 	mul	x7, x7, x21
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1d78:	9b1404c1 	madd	x1, x6, x20, x1
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1d7c:	9b0e1cc6 	madd	x6, x6, x14, x7
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1d80:	9b0e04a1 	madd	x1, x5, x14, x1
  o[6] = 6270 * a - 15137 * b;
    1d84:	9b187dad 	mul	x13, x13, x24
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1d88:	9b0b18a5 	madd	x5, x5, x11, x6
      int q = quant[v * 8 + u];
    1d8c:	8b090366 	add	x6, x27, x9
  o[5] =  9102*d0 - 16069*d1 +  3196*d2 + 13623*d3;
    1d90:	9b0b0481 	madd	x1, x4, x11, x1
  o[6] = 6270 * a - 15137 * b;
    1d94:	9b02358c 	madd	x12, x12, x2, x13
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1d98:	9b0f1484 	madd	x4, x4, x15, x5
    1d9c:	d2800005 	mov	x5, #0x0                   	// #0
    1da0:	a908b3e1 	stp	x1, x12, [sp, #136]
    1da4:	f9004fe4 	str	x4, [sp, #152]
      long long sum = coefficient[v];
    1da8:	f87c68a7 	ldr	x7, [x5, x28]
        value = (sum + ((long long)1 << 29)) >> 30;
    1dac:	8b1600e1 	add	x1, x7, x22
    1db0:	cb0702c4 	sub	x4, x22, x7
    1db4:	f10000ff 	cmp	x7, #0x0
      int q = quant[v * 8 + u];
    1db8:	386568c7 	ldrb	w7, [x6, x5]
        value = (sum + ((long long)1 << 29)) >> 30;
    1dbc:	935efc21 	asr	x1, x1, #30
    1dc0:	935efc84 	asr	x4, x4, #30
    1dc4:	5a84a424 	csneg	w4, w1, w4, ge	// ge = tcont
        value = (value + q / 2) / q;
    1dc8:	13017ce1 	asr	w1, w7, #1
      if(value >= 0)
    1dcc:	37f80824 	tbnz	w4, #31, 1ed0 <encode_block+0x374>
        value = (value + q / 2) / q;
    1dd0:	0b010084 	add	w4, w4, w1
    1dd4:	1ac70881 	udiv	w1, w4, w7
      output[v * 8 + u] = value;
    1dd8:	78257941 	strh	w1, [x10, x5, lsl #1]
    for(int v = 0; v < 8; v++){
    1ddc:	910020a5 	add	x5, x5, #0x8
    1de0:	f10100bf 	cmp	x5, #0x40
    1de4:	54fffe21 	b.ne	1da8 <encode_block+0x24c>  // b.any
  for(int u = 0; u < 8; u++){
    1de8:	91000529 	add	x9, x9, #0x1
    1dec:	91001000 	add	x0, x0, #0x4
    1df0:	9100094a 	add	x10, x10, #0x2
    1df4:	f100213f 	cmp	x9, #0x8
    1df8:	54fff6c1 	b.ne	1cd0 <encode_block+0x174>  // b.any

  int dc = coefficient[0];
  int diff = dc - *previous_dc;
    1dfc:	b9400060 	ldr	w0, [x3]
  *previous_dc = dc;
  int size = category(diff);
  if(size > 11) size = 11;
    1e00:	52800415 	mov	w21, #0x20                  	// #32
  int dc = coefficient[0];
    1e04:	79c143f4 	ldrsh	w20, [sp, #160]
  put_bits(w, size, 4);
    1e08:	52800082 	mov	w2, #0x4                   	// #4
  *previous_dc = dc;
    1e0c:	b9000074 	str	w20, [x3]
  uint v = value < 0 ? -value : value;
    1e10:	6b000294 	subs	w20, w20, w0
  if(size > 11) size = 11;
    1e14:	52800160 	mov	w0, #0xb                   	// #11
  uint v = value < 0 ? -value : value;
    1e18:	5a945696 	cneg	w22, w20, mi	// mi = first
    1e1c:	5ac012d6 	clz	w22, w22
  if(size > 11) size = 11;
    1e20:	4b1602b5 	sub	w21, w21, w22
    1e24:	71002ebf 	cmp	w21, #0xb
    1e28:	1a80d2b5 	csel	w21, w21, w0, le
  put_bits(w, size, 4);
    1e2c:	aa1303e0 	mov	x0, x19
    1e30:	2a1503e1 	mov	w1, w21
    1e34:	97ffff1b 	bl	1aa0 <put_bits>
  if(size)
    1e38:	710082df 	cmp	w22, #0x20
    1e3c:	54000140 	b.eq	1e64 <encode_block+0x308>  // b.none
  if(value >= 0)
    1e40:	7100029f 	cmp	w20, #0x0
  return value + (1U << size) - 1;
    1e44:	51000680 	sub	w0, w20, #0x1
    1e48:	52800021 	mov	w1, #0x1                   	// #1
    put_bits(w, amplitude(diff, size), size);
    1e4c:	2a1503e2 	mov	w2, w21
  return value + (1U << size) - 1;
    1e50:	1ad52021 	lsl	w1, w1, w21
    1e54:	0b000021 	add	w1, w1, w0
    put_bits(w, amplitude(diff, size), size);
    1e58:	1a81a281 	csel	w1, w20, w1, ge	// ge = tcont
    1e5c:	aa1303e0 	mov	x0, x19
    1e60:	97ffff10 	bl	1aa0 <put_bits>
  o[7] =  3196*d0 -  9102*d1 + 13623*d2 - 16069*d3;
    1e64:	d2800036 	mov	x22, #0x1                   	// #1

  int run = 0;
  for(int k = 1; k < 64; k++){
    int value = coefficient[zigzag[k]];
    1e68:	b0000017 	adrp	x23, 2000 <jpeg_encode_to+0x80>
    1e6c:	913fe2f7 	add	x23, x23, #0xff8
    if(value == 0){
      run++;
      continue;
    }
    while(run >= 16){
      put_bits(w, 1, 8);            // symbol index 1 is ZRL (0xf0)
    1e70:	2a1603f8 	mov	w24, w22
  int run = 0;
    1e74:	52800014 	mov	w20, #0x0                   	// #0
      run -= 16;
    }
    if(value > 1023) value = 1023;
    if(value < -1023) value = -1023;
    1e78:	12807fd9 	mov	w25, #0xfffffc01            	// #-1023
    if(value > 1023) value = 1023;
    1e7c:	52807ffa 	mov	w26, #0x3ff                 	// #1023
    int value = coefficient[zigzag[k]];
    1e80:	38766ae0 	ldrb	w0, [x23, x22]
    1e84:	910283e1 	add	x1, sp, #0xa0
    1e88:	78e0783c 	ldrsh	w28, [x1, x0, lsl #1]
    if(value == 0){
    1e8c:	3500035c 	cbnz	w28, 1ef4 <encode_block+0x398>
      run++;
    1e90:	11000694 	add	w20, w20, #0x1
  for(int k = 1; k < 64; k++){
    1e94:	910006d6 	add	x22, x22, #0x1
    1e98:	f10102df 	cmp	x22, #0x40
    1e9c:	54ffff21 	b.ne	1e80 <encode_block+0x324>  // b.any
    int code = 2 + run * 10 + size - 1;
    put_bits(w, code, 8);
    put_bits(w, amplitude(value, size), size);
    run = 0;
  }
  if(run)
    1ea0:	34000614 	cbz	w20, 1f60 <encode_block+0x404>
    put_bits(w, 0, 8);              // symbol index 0 is EOB
}
    1ea4:	a9407bfd 	ldp	x29, x30, [sp]
    put_bits(w, 0, 8);              // symbol index 0 is EOB
    1ea8:	aa1303e0 	mov	x0, x19
}
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    put_bits(w, 0, 8);              // symbol index 0 is EOB
    1eb0:	52800102 	mov	w2, #0x8                   	// #8
}
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    put_bits(w, 0, 8);              // symbol index 0 is EOB
    1eb8:	52800001 	mov	w1, #0x0                   	// #0
}
    1ebc:	a94363f7 	ldp	x23, x24, [sp, #48]
    1ec0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    1ec4:	a94573fb 	ldp	x27, x28, [sp, #80]
    1ec8:	910883ff 	add	sp, sp, #0x220
    put_bits(w, 0, 8);              // symbol index 0 is EOB
    1ecc:	17fffef5 	b	1aa0 <put_bits>
        value = -((-value + q / 2) / q);
    1ed0:	4b040021 	sub	w1, w1, w4
    1ed4:	1ac70821 	udiv	w1, w1, w7
    1ed8:	4b0103e1 	neg	w1, w1
    1edc:	17ffffbf 	b	1dd8 <encode_block+0x27c>
      run -= 16;
    1ee0:	51004294 	sub	w20, w20, #0x10
      put_bits(w, 1, 8);            // symbol index 1 is ZRL (0xf0)
    1ee4:	aa1303e0 	mov	x0, x19
    1ee8:	52800102 	mov	w2, #0x8                   	// #8
    1eec:	52800021 	mov	w1, #0x1                   	// #1
    1ef0:	97fffeec 	bl	1aa0 <put_bits>
    while(run >= 16){
    1ef4:	71003e9f 	cmp	w20, #0xf
    1ef8:	54ffff4c 	b.gt	1ee0 <encode_block+0x384>
    if(value < -1023) value = -1023;
    1efc:	310fff9f 	cmn	w28, #0x3ff
    1f00:	5280041b 	mov	w27, #0x20                  	// #32
    1f04:	1a99a395 	csel	w21, w28, w25, ge	// ge = tcont
    put_bits(w, code, 8);
    1f08:	52800102 	mov	w2, #0x8                   	// #8
    if(value > 1023) value = 1023;
    1f0c:	710ffebf 	cmp	w21, #0x3ff
    1f10:	1a9ad2b5 	csel	w21, w21, w26, le
  uint v = value < 0 ? -value : value;
    1f14:	710002bf 	cmp	w21, #0x0
    1f18:	5a95a6a0 	cneg	w0, w21, lt	// lt = tstop
    1f1c:	5ac01000 	clz	w0, w0
    1f20:	4b00037b 	sub	w27, w27, w0
    int code = 2 + run * 10 + size - 1;
    1f24:	52800140 	mov	w0, #0xa                   	// #10
    1f28:	1b006e81 	madd	w1, w20, w0, w27
    put_bits(w, code, 8);
    1f2c:	aa1303e0 	mov	x0, x19
    run = 0;
    1f30:	52800014 	mov	w20, #0x0                   	// #0
    put_bits(w, code, 8);
    1f34:	11000421 	add	w1, w1, #0x1
    1f38:	97fffeda 	bl	1aa0 <put_bits>
  if(value >= 0)
    1f3c:	7100039f 	cmp	w28, #0x0
  return value + (1U << size) - 1;
    1f40:	510006a0 	sub	w0, w21, #0x1
    1f44:	1adb2301 	lsl	w1, w24, w27
    1f48:	0b000021 	add	w1, w1, w0
    put_bits(w, amplitude(value, size), size);
    1f4c:	2a1b03e2 	mov	w2, w27
    1f50:	1a81a2a1 	csel	w1, w21, w1, ge	// ge = tcont
    1f54:	aa1303e0 	mov	x0, x19
    1f58:	97fffed2 	bl	1aa0 <put_bits>
    run = 0;
    1f5c:	17ffffce 	b	1e94 <encode_block+0x338>
}
    1f60:	a9407bfd 	ldp	x29, x30, [sp]
    1f64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f68:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1f6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    1f70:	a9446bf9 	ldp	x25, x26, [sp, #64]
    1f74:	a94573fb 	ldp	x27, x28, [sp, #80]
    1f78:	910883ff 	add	sp, sp, #0x220
    1f7c:	d65f03c0 	ret

0000000000001f80 <jpeg_encode_to>:
}

static int
jpeg_encode_to(struct jw *w, int width, int height, int quality,
               jpeg_pixel_fn pixel, void *arg, uint *written)
{
    1f80:	d116c3ff 	sub	sp, sp, #0x5b0
    1f84:	a9007bfd 	stp	x29, x30, [sp]
    1f88:	910003fd 	mov	x29, sp
    1f8c:	a90153f3 	stp	x19, x20, [sp, #16]
    1f90:	a9025bf5 	stp	x21, x22, [sp, #32]
    1f94:	a90363f7 	stp	x23, x24, [sp, #48]
    1f98:	aa0403f7 	mov	x23, x4
  uchar qy[64], qc[64];
  uchar rgb[16][16][3];
  short yblock[64], cb[64], cr[64];
  int pred_y = 0, pred_cb = 0, pred_cr = 0;

  if(width <= 0 || height <= 0 || width > 65535 ||
    1f9c:	529fffc4 	mov	w4, #0xfffe                	// #65534
{
    1fa0:	a9046bf9 	stp	x25, x26, [sp, #64]
    1fa4:	a90573fb 	stp	x27, x28, [sp, #80]
  if(width <= 0 || height <= 0 || width > 65535 ||
    1fa8:	5100043c 	sub	w28, w1, #0x1
    1fac:	5100045b 	sub	w27, w2, #0x1
{
    1fb0:	f90037e6 	str	x6, [sp, #104]
  if(width <= 0 || height <= 0 || width > 65535 ||
    1fb4:	6b04039f 	cmp	w28, w4
  int pred_y = 0, pred_cb = 0, pred_cr = 0;
    1fb8:	2914ffff 	stp	wzr, wzr, [sp, #164]
  if(width <= 0 || height <= 0 || width > 65535 ||
    1fbc:	7a449362 	ccmp	w27, w4, #0x2, ls	// ls = plast
  int pred_y = 0, pred_cb = 0, pred_cr = 0;
    1fc0:	b900afff 	str	wzr, [sp, #172]
  if(width <= 0 || height <= 0 || width > 65535 ||
    1fc4:	54000088 	b.hi	1fd4 <jpeg_encode_to+0x54>  // b.pmore
     height > 65535 || quality < 1 || quality > 100 || pixel == 0)
    1fc8:	51000464 	sub	w4, w3, #0x1
    1fcc:	71018c9f 	cmp	w4, #0x63
    1fd0:	54000149 	b.ls	1ff8 <jpeg_encode_to+0x78>  // b.plast
    return -1;
    1fd4:	12800000 	mov	w0, #0xffffffff            	// #-1
  if(jflush(w) < 0 || w->error)
    return -1;
  if(written)
    *written = w->total;
  return 0;
}
    1fd8:	a9407bfd 	ldp	x29, x30, [sp]
    1fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    1fe0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1fe4:	a94363f7 	ldp	x23, x24, [sp, #48]
    1fe8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    1fec:	a94573fb 	ldp	x27, x28, [sp, #80]
    1ff0:	9116c3ff 	add	sp, sp, #0x5b0
    1ff4:	d65f03c0 	ret
     height > 65535 || quality < 1 || quality > 100 || pixel == 0)
    1ff8:	b4fffef7 	cbz	x23, 1fd4 <jpeg_encode_to+0x54>
  make_quant(qy, qbase_y, quality);
    1ffc:	9102c3f9 	add	x25, sp, #0xb0
    2000:	90000016 	adrp	x22, 2000 <jpeg_encode_to+0x80>
    2004:	913fe2d6 	add	x22, x22, #0xff8
    2008:	2a0303e7 	mov	w7, w3
    200c:	aa0003f3 	mov	x19, x0
    2010:	2a0203f5 	mov	w21, w2
    2014:	aa1903e0 	mov	x0, x25
    2018:	2a0303e2 	mov	w2, w3
    201c:	2a0103f4 	mov	w20, w1
    2020:	910102c1 	add	x1, x22, #0x40
    2024:	f9003be5 	str	x5, [sp, #112]
    2028:	97fffe23 	bl	18b4 <make_quant>
  make_quant(qc, qbase_c, quality);
    202c:	2a0703e2 	mov	w2, w7
    2030:	9103c3f8 	add	x24, sp, #0xf0
    2034:	910202c1 	add	x1, x22, #0x80
    2038:	aa1803e0 	mov	x0, x24
    203c:	97fffe1e 	bl	18b4 <make_quant>
  jmarker(w, 0xd8);                 // SOI
    2040:	aa1303e0 	mov	x0, x19
    2044:	52801b01 	mov	w1, #0xd8                  	// #216
    2048:	97fffe8a 	bl	1a70 <jmarker>
  jmarker(w, 0xe0);                 // JFIF APP0
    204c:	aa1303e0 	mov	x0, x19
    2050:	52801c01 	mov	w1, #0xe0                  	// #224
    2054:	97fffe87 	bl	1a70 <jmarker>
  jbyte(w, 0);
    2058:	d280001a 	mov	x26, #0x0                   	// #0
  jword(w, 16);
    205c:	aa1303e0 	mov	x0, x19
    2060:	52800201 	mov	w1, #0x10                  	// #16
    2064:	97fffe77 	bl	1a40 <jword>
  jbyte(w, 'J'); jbyte(w, 'F'); jbyte(w, 'I'); jbyte(w, 'F'); jbyte(w, 0);
    2068:	aa1303e0 	mov	x0, x19
    206c:	52800941 	mov	w1, #0x4a                  	// #74
    2070:	97fffe51 	bl	19b4 <jbyte>
    2074:	aa1303e0 	mov	x0, x19
    2078:	528008c1 	mov	w1, #0x46                  	// #70
    207c:	97fffe4e 	bl	19b4 <jbyte>
    2080:	aa1303e0 	mov	x0, x19
    2084:	52800921 	mov	w1, #0x49                  	// #73
    2088:	97fffe4b 	bl	19b4 <jbyte>
    208c:	aa1303e0 	mov	x0, x19
    2090:	528008c1 	mov	w1, #0x46                  	// #70
    2094:	97fffe48 	bl	19b4 <jbyte>
    2098:	aa1303e0 	mov	x0, x19
    209c:	52800001 	mov	w1, #0x0                   	// #0
    20a0:	97fffe45 	bl	19b4 <jbyte>
  jbyte(w, 1); jbyte(w, 1); jbyte(w, 0);
    20a4:	aa1303e0 	mov	x0, x19
    20a8:	52800021 	mov	w1, #0x1                   	// #1
    20ac:	97fffe42 	bl	19b4 <jbyte>
    20b0:	aa1303e0 	mov	x0, x19
    20b4:	52800021 	mov	w1, #0x1                   	// #1
    20b8:	97fffe3f 	bl	19b4 <jbyte>
    20bc:	aa1303e0 	mov	x0, x19
    20c0:	52800001 	mov	w1, #0x0                   	// #0
    20c4:	97fffe3c 	bl	19b4 <jbyte>
  jword(w, 1); jword(w, 1); jbyte(w, 0); jbyte(w, 0);
    20c8:	aa1303e0 	mov	x0, x19
    20cc:	52800021 	mov	w1, #0x1                   	// #1
    20d0:	97fffe5c 	bl	1a40 <jword>
    20d4:	aa1303e0 	mov	x0, x19
    20d8:	52800021 	mov	w1, #0x1                   	// #1
    20dc:	97fffe59 	bl	1a40 <jword>
    20e0:	aa1303e0 	mov	x0, x19
    20e4:	52800001 	mov	w1, #0x0                   	// #0
    20e8:	97fffe33 	bl	19b4 <jbyte>
    20ec:	aa1303e0 	mov	x0, x19
    20f0:	52800001 	mov	w1, #0x0                   	// #0
    20f4:	97fffe30 	bl	19b4 <jbyte>
  jmarker(w, 0xdb);                 // two 8-bit quantization tables
    20f8:	aa1303e0 	mov	x0, x19
    20fc:	52801b61 	mov	w1, #0xdb                  	// #219
    2100:	97fffe5c 	bl	1a70 <jmarker>
  jword(w, 132);
    2104:	aa1303e0 	mov	x0, x19
    2108:	52801081 	mov	w1, #0x84                  	// #132
    210c:	97fffe4d 	bl	1a40 <jword>
  jbyte(w, 0);
    2110:	aa1303e0 	mov	x0, x19
    2114:	52800001 	mov	w1, #0x0                   	// #0
    2118:	97fffe27 	bl	19b4 <jbyte>
  for(int i = 0; i < 64; i++) jbyte(w, qy[zigzag[i]]);
    211c:	387a6ac0 	ldrb	w0, [x22, x26]
    2120:	9100075a 	add	x26, x26, #0x1
    2124:	38606b21 	ldrb	w1, [x25, x0]
    2128:	aa1303e0 	mov	x0, x19
    212c:	97fffe22 	bl	19b4 <jbyte>
    2130:	f101035f 	cmp	x26, #0x40
    2134:	54ffff41 	b.ne	211c <jpeg_encode_to+0x19c>  // b.any
  jbyte(w, 1);
    2138:	d280001a 	mov	x26, #0x0                   	// #0
    213c:	aa1303e0 	mov	x0, x19
    2140:	52800021 	mov	w1, #0x1                   	// #1
    2144:	97fffe1c 	bl	19b4 <jbyte>
  for(int i = 0; i < 64; i++) jbyte(w, qc[zigzag[i]]);
    2148:	387a6ac0 	ldrb	w0, [x22, x26]
    214c:	9100075a 	add	x26, x26, #0x1
    2150:	38606b01 	ldrb	w1, [x24, x0]
    2154:	aa1303e0 	mov	x0, x19
    2158:	97fffe17 	bl	19b4 <jbyte>
    215c:	f101035f 	cmp	x26, #0x40
    2160:	54ffff41 	b.ne	2148 <jpeg_encode_to+0x1c8>  // b.any
  jmarker(w, 0xc0);                 // baseline SOF, Y 2x2 and Cb/Cr 1x1
    2164:	aa1303e0 	mov	x0, x19
    2168:	52801801 	mov	w1, #0xc0                  	// #192
    216c:	97fffe41 	bl	1a70 <jmarker>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 4 ? 12 : 0);
    2170:	52800036 	mov	w22, #0x1                   	// #1
  jword(w, 17); jbyte(w, 8); jword(w, height); jword(w, width); jbyte(w, 3);
    2174:	aa1303e0 	mov	x0, x19
    2178:	52800221 	mov	w1, #0x11                  	// #17
    217c:	97fffe31 	bl	1a40 <jword>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 4 ? 12 : 0);
    2180:	52800198 	mov	w24, #0xc                   	// #12
  jword(w, 17); jbyte(w, 8); jword(w, height); jword(w, width); jbyte(w, 3);
    2184:	aa1303e0 	mov	x0, x19
    2188:	52800101 	mov	w1, #0x8                   	// #8
    218c:	97fffe0a 	bl	19b4 <jbyte>
    2190:	2a1503e1 	mov	w1, w21
    2194:	aa1303e0 	mov	x0, x19
    2198:	97fffe2a 	bl	1a40 <jword>
    219c:	2a1403e1 	mov	w1, w20
    21a0:	aa1303e0 	mov	x0, x19
    21a4:	97fffe27 	bl	1a40 <jword>
    21a8:	aa1303e0 	mov	x0, x19
    21ac:	52800061 	mov	w1, #0x3                   	// #3
    21b0:	97fffe01 	bl	19b4 <jbyte>
  jbyte(w, 1); jbyte(w, 0x22); jbyte(w, 0);
    21b4:	aa1303e0 	mov	x0, x19
    21b8:	52800021 	mov	w1, #0x1                   	// #1
    21bc:	97fffdfe 	bl	19b4 <jbyte>
    21c0:	aa1303e0 	mov	x0, x19
    21c4:	52800441 	mov	w1, #0x22                  	// #34
    21c8:	97fffdfb 	bl	19b4 <jbyte>
    21cc:	aa1303e0 	mov	x0, x19
    21d0:	52800001 	mov	w1, #0x0                   	// #0
    21d4:	97fffdf8 	bl	19b4 <jbyte>
  jbyte(w, 2); jbyte(w, 0x11); jbyte(w, 1);
    21d8:	aa1303e0 	mov	x0, x19
    21dc:	52800041 	mov	w1, #0x2                   	// #2
    21e0:	97fffdf5 	bl	19b4 <jbyte>
    21e4:	aa1303e0 	mov	x0, x19
    21e8:	52800221 	mov	w1, #0x11                  	// #17
    21ec:	97fffdf2 	bl	19b4 <jbyte>
    21f0:	aa1303e0 	mov	x0, x19
    21f4:	52800021 	mov	w1, #0x1                   	// #1
    21f8:	97fffdef 	bl	19b4 <jbyte>
  jbyte(w, 3); jbyte(w, 0x11); jbyte(w, 1);
    21fc:	aa1303e0 	mov	x0, x19
    2200:	52800061 	mov	w1, #0x3                   	// #3
    2204:	97fffdec 	bl	19b4 <jbyte>
    2208:	aa1303e0 	mov	x0, x19
    220c:	52800221 	mov	w1, #0x11                  	// #17
    2210:	97fffde9 	bl	19b4 <jbyte>
    2214:	aa1303e0 	mov	x0, x19
    2218:	52800021 	mov	w1, #0x1                   	// #1
    221c:	97fffde6 	bl	19b4 <jbyte>
  jmarker(w, 0xc4);                 // one DC and one AC Huffman table
    2220:	aa1303e0 	mov	x0, x19
    2224:	52801881 	mov	w1, #0xc4                  	// #196
    2228:	97fffe12 	bl	1a70 <jmarker>
  jword(w, 210);
    222c:	aa1303e0 	mov	x0, x19
    2230:	52801a41 	mov	w1, #0xd2                  	// #210
    2234:	97fffe03 	bl	1a40 <jword>
  jbyte(w, 0x00);                   // DC table 0
    2238:	52800001 	mov	w1, #0x0                   	// #0
    223c:	aa1303e0 	mov	x0, x19
    2240:	97fffddd 	bl	19b4 <jbyte>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 4 ? 12 : 0);
    2244:	52800001 	mov	w1, #0x0                   	// #0
    2248:	aa1303e0 	mov	x0, x19
    224c:	110006d6 	add	w22, w22, #0x1
    2250:	97fffdd9 	bl	19b4 <jbyte>
    2254:	710046df 	cmp	w22, #0x11
    2258:	54000981 	b.ne	2388 <jpeg_encode_to+0x408>  // b.any
  for(int i = 0; i < 12; i++) jbyte(w, i);
    225c:	52800016 	mov	w22, #0x0                   	// #0
    2260:	2a1603e1 	mov	w1, w22
    2264:	aa1303e0 	mov	x0, x19
    2268:	110006d6 	add	w22, w22, #0x1
    226c:	97fffdd2 	bl	19b4 <jbyte>
    2270:	710032df 	cmp	w22, #0xc
    2274:	54ffff61 	b.ne	2260 <jpeg_encode_to+0x2e0>  // b.any
  jbyte(w, 0x10);                   // AC table 0
    2278:	52800201 	mov	w1, #0x10                  	// #16
    227c:	aa1303e0 	mov	x0, x19
    2280:	97fffdcd 	bl	19b4 <jbyte>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 8 ? 162 : 0);
    2284:	52800036 	mov	w22, #0x1                   	// #1
    2288:	52800001 	mov	w1, #0x0                   	// #0
    228c:	52801458 	mov	w24, #0xa2                  	// #162
    2290:	aa1303e0 	mov	x0, x19
    2294:	110006d6 	add	w22, w22, #0x1
    2298:	97fffdc7 	bl	19b4 <jbyte>
    229c:	710046df 	cmp	w22, #0x11
    22a0:	540007a1 	b.ne	2394 <jpeg_encode_to+0x414>  // b.any
  jbyte(w, 0xf0);                   // ZRL
    22a4:	52800018 	mov	w24, #0x0                   	// #0
  jbyte(w, 0x00);                   // EOB
    22a8:	aa1303e0 	mov	x0, x19
    22ac:	52800001 	mov	w1, #0x0                   	// #0
    22b0:	97fffdc1 	bl	19b4 <jbyte>
  jbyte(w, 0xf0);                   // ZRL
    22b4:	aa1303e0 	mov	x0, x19
    22b8:	52801e01 	mov	w1, #0xf0                  	// #240
    22bc:	97fffdbe 	bl	19b4 <jbyte>
    for(int size = 1; size <= 10; size++)
    22c0:	52800036 	mov	w22, #0x1                   	// #1
      jbyte(w, (run << 4) | size);
    22c4:	2a160301 	orr	w1, w24, w22
    22c8:	aa1303e0 	mov	x0, x19
    for(int size = 1; size <= 10; size++)
    22cc:	110006d6 	add	w22, w22, #0x1
      jbyte(w, (run << 4) | size);
    22d0:	97fffdb9 	bl	19b4 <jbyte>
    for(int size = 1; size <= 10; size++)
    22d4:	71002edf 	cmp	w22, #0xb
    22d8:	54ffff61 	b.ne	22c4 <jpeg_encode_to+0x344>  // b.any
  for(int run = 0; run < 16; run++)
    22dc:	11004318 	add	w24, w24, #0x10
    22e0:	7104031f 	cmp	w24, #0x100
    22e4:	54fffee1 	b.ne	22c0 <jpeg_encode_to+0x340>  // b.any
  jmarker(w, 0xda);                 // SOS
    22e8:	aa1303e0 	mov	x0, x19
    22ec:	52801b41 	mov	w1, #0xda                  	// #218
    22f0:	97fffde0 	bl	1a70 <jmarker>
  for(int my = 0; my < height; my += 16){
    22f4:	52800016 	mov	w22, #0x0                   	// #0
  jword(w, 12); jbyte(w, 3);
    22f8:	aa1303e0 	mov	x0, x19
    22fc:	52800181 	mov	w1, #0xc                   	// #12
    2300:	97fffdd0 	bl	1a40 <jword>
    2304:	aa1303e0 	mov	x0, x19
    2308:	52800061 	mov	w1, #0x3                   	// #3
    230c:	97fffdaa 	bl	19b4 <jbyte>
  jbyte(w, 1); jbyte(w, 0x00);
    2310:	aa1303e0 	mov	x0, x19
    2314:	52800021 	mov	w1, #0x1                   	// #1
    2318:	97fffda7 	bl	19b4 <jbyte>
    231c:	aa1303e0 	mov	x0, x19
    2320:	52800001 	mov	w1, #0x0                   	// #0
    2324:	97fffda4 	bl	19b4 <jbyte>
  jbyte(w, 2); jbyte(w, 0x00);
    2328:	aa1303e0 	mov	x0, x19
    232c:	52800041 	mov	w1, #0x2                   	// #2
    2330:	97fffda1 	bl	19b4 <jbyte>
    2334:	aa1303e0 	mov	x0, x19
    2338:	52800001 	mov	w1, #0x0                   	// #0
    233c:	97fffd9e 	bl	19b4 <jbyte>
  jbyte(w, 3); jbyte(w, 0x00);
    2340:	aa1303e0 	mov	x0, x19
    2344:	52800061 	mov	w1, #0x3                   	// #3
    2348:	97fffd9b 	bl	19b4 <jbyte>
    234c:	aa1303e0 	mov	x0, x19
    2350:	52800001 	mov	w1, #0x0                   	// #0
    2354:	97fffd98 	bl	19b4 <jbyte>
  jbyte(w, 0); jbyte(w, 63); jbyte(w, 0);
    2358:	aa1303e0 	mov	x0, x19
    235c:	52800001 	mov	w1, #0x0                   	// #0
    2360:	97fffd95 	bl	19b4 <jbyte>
    2364:	aa1303e0 	mov	x0, x19
    2368:	528007e1 	mov	w1, #0x3f                  	// #63
    236c:	97fffd92 	bl	19b4 <jbyte>
    2370:	aa1303e0 	mov	x0, x19
    2374:	52800001 	mov	w1, #0x0                   	// #0
    2378:	97fffd8f 	bl	19b4 <jbyte>
    for(int mx = 0; mx < width; mx += 16){
    237c:	910ac3f8 	add	x24, sp, #0x2b0
    2380:	52800009 	mov	w9, #0x0                   	// #0
    2384:	140000a0 	b	2604 <jpeg_encode_to+0x684>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 4 ? 12 : 0);
    2388:	710012df 	cmp	w22, #0x4
    238c:	1a9813e1 	csel	w1, wzr, w24, ne	// ne = any
    2390:	17ffffae 	b	2248 <jpeg_encode_to+0x2c8>
  for(int len = 1; len <= 16; len++) jbyte(w, len == 8 ? 162 : 0);
    2394:	710022df 	cmp	w22, #0x8
    2398:	1a9813e1 	csel	w1, wzr, w24, ne	// ne = any
    239c:	17ffffbd 	b	2290 <jpeg_encode_to+0x310>
          pixel(arg, sx, sy, &rgb[y][x][0], &rgb[y][x][1], &rgb[y][x][2]);
    23a0:	f9403be0 	ldr	x0, [sp, #112]
          int sx = mx + x < width ? mx + x : width - 1;
    23a4:	6b1400df 	cmp	w6, w20
          pixel(arg, sx, sy, &rgb[y][x][0], &rgb[y][x][1], &rgb[y][x][2]);
    23a8:	b9007be6 	str	w6, [sp, #120]
    23ac:	1a9cb0c1 	csel	w1, w6, w28, lt	// lt = tstop
    23b0:	b90083e2 	str	w2, [sp, #128]
    23b4:	91000865 	add	x5, x3, #0x2
    23b8:	a9089fe3 	stp	x3, x7, [sp, #136]
    23bc:	91000464 	add	x4, x3, #0x1
    23c0:	291323e9 	stp	w9, w8, [sp, #152]
    23c4:	d63f02e0 	blr	x23
        for(int x = 0; x < 16; x++){
    23c8:	a9489fe3 	ldp	x3, x7, [sp, #136]
    23cc:	b9407be6 	ldr	w6, [sp, #120]
    23d0:	b94083e2 	ldr	w2, [sp, #128]
    23d4:	110004c6 	add	w6, w6, #0x1
    23d8:	295323e9 	ldp	w9, w8, [sp, #152]
    23dc:	6b06035f 	cmp	w26, w6
    23e0:	91000c63 	add	x3, x3, #0x3
    23e4:	54fffde1 	b.ne	23a0 <jpeg_encode_to+0x420>  // b.any
      for(int y = 0; y < 16; y++)
    23e8:	9100c0e7 	add	x7, x7, #0x30
    23ec:	11000508 	add	w8, w8, #0x1
    23f0:	f10c00ff 	cmp	x7, #0x300
    23f4:	54000780 	b.eq	24e4 <jpeg_encode_to+0x564>  // b.none
        for(int x = 0; x < 16; x++){
    23f8:	6b15011f 	cmp	w8, w21
    23fc:	8b1800e3 	add	x3, x7, x24
    2400:	1a9bb102 	csel	w2, w8, w27, lt	// lt = tstop
          int sy = my + y < height ? my + y : height - 1;
    2404:	2a0903e6 	mov	w6, w9
    2408:	17ffffe6 	b	23a0 <jpeg_encode_to+0x420>
              yblock[y * 8 + x] = ((77*p[0] + 150*p[1] + 29*p[2]) >> 8)-128;
    240c:	39400420 	ldrb	w0, [x1, #1]
            for(int x = 0; x < 8; x++){
    2410:	91000c21 	add	x1, x1, #0x3
              yblock[y * 8 + x] = ((77*p[0] + 150*p[1] + 29*p[2]) >> 8)-128;
    2414:	385fd02d 	ldurb	w13, [x1, #-3]
    2418:	1b077c00 	mul	w0, w0, w7
    241c:	1b0801ad 	madd	w13, w13, w8, w0
    2420:	385ff020 	ldurb	w0, [x1, #-1]
    2424:	1b063400 	madd	w0, w0, w6, w13
    2428:	13087c00 	asr	w0, w0, #8
    242c:	51020000 	sub	w0, w0, #0x80
    2430:	78237840 	strh	w0, [x2, x3, lsl #1]
            for(int x = 0; x < 8; x++){
    2434:	91000463 	add	x3, x3, #0x1
    2438:	f100207f 	cmp	x3, #0x8
    243c:	54fffe81 	b.ne	240c <jpeg_encode_to+0x48c>  // b.any
          for(int y = 0; y < 8; y++)
    2440:	1100216b 	add	w11, w11, #0x8
    2444:	9100c18c 	add	x12, x12, #0x30
    2448:	91004042 	add	x2, x2, #0x10
    244c:	7101017f 	cmp	w11, #0x40
    2450:	54000080 	b.eq	2460 <jpeg_encode_to+0x4e0>  // b.none
            for(int x = 0; x < 8; x++){
    2454:	8b0c01c1 	add	x1, x14, x12
          int sy = my + y < height ? my + y : height - 1;
    2458:	d2800003 	mov	x3, #0x0                   	// #0
    245c:	17ffffec 	b	240c <jpeg_encode_to+0x48c>
          encode_block(w, yblock, qy, &pred_y);
    2460:	910293e3 	add	x3, sp, #0xa4
    2464:	aa1903e2 	mov	x2, x25
    2468:	9104c3e1 	add	x1, sp, #0x130
    246c:	aa1303e0 	mov	x0, x19
    2470:	a90797e9 	stp	x9, x5, [sp, #120]
    2474:	f90047e4 	str	x4, [sp, #136]
    2478:	97fffdb9 	bl	1b5c <encode_block>
        for(int bx = 0; bx < 2; bx++){
    247c:	a94813e5 	ldp	x5, x4, [sp, #128]
    2480:	5280300a 	mov	w10, #0x180                 	// #384
    2484:	f100609f 	cmp	x4, #0x18
    2488:	54000160 	b.eq	24b4 <jpeg_encode_to+0x534>  // b.none
    248c:	f9403fe9 	ldr	x9, [sp, #120]
    2490:	d2800304 	mov	x4, #0x18                  	// #24
    2494:	528003a6 	mov	w6, #0x1d                  	// #29
    2498:	528012c7 	mov	w7, #0x96                  	// #150
    249c:	528009a8 	mov	w8, #0x4d                  	// #77
          for(int y = 0; y < 8; y++)
    24a0:	9104c3e2 	add	x2, sp, #0x130
          int sy = my + y < height ? my + y : height - 1;
    24a4:	aa0903ec 	mov	x12, x9
    24a8:	8b04030e 	add	x14, x24, x4
    24ac:	5280000b 	mov	w11, #0x0                   	// #0
    24b0:	17ffffe9 	b	2454 <jpeg_encode_to+0x4d4>
      for(int by = 0; by < 2; by++)
    24b4:	b4000285 	cbz	x5, 2504 <jpeg_encode_to+0x584>
    24b8:	9106c3e6 	add	x6, sp, #0x1b0
    24bc:	9108c3e5 	add	x5, sp, #0x230
    24c0:	d2800008 	mov	x8, #0x0                   	// #0
    24c4:	52800009 	mov	w9, #0x0                   	// #0
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    24c8:	1280054a 	mov	w10, #0xffffffd5            	// #-43
    24cc:	12800a8b 	mov	w11, #0xffffffab            	// #-85
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    24d0:	12800d4c 	mov	w12, #0xffffff95            	// #-107
    24d4:	1280028d 	mov	w13, #0xffffffeb            	// #-21
        for(int x = 0; x < 8; x++){
    24d8:	8b080307 	add	x7, x24, x8
          int sr = 0, sg = 0, sb = 0;
    24dc:	d2800001 	mov	x1, #0x0                   	// #0
    24e0:	1400002e 	b	2598 <jpeg_encode_to+0x618>
      for(int y = 0; y < 16; y++)
    24e4:	d2800005 	mov	x5, #0x0                   	// #0
    24e8:	5280300a 	mov	w10, #0x180                 	// #384
        for(int bx = 0; bx < 2; bx++){
    24ec:	9baa7ca9 	umull	x9, w5, w10
    24f0:	d2800004 	mov	x4, #0x0                   	// #0
              yblock[y * 8 + x] = ((77*p[0] + 150*p[1] + 29*p[2]) >> 8)-128;
    24f4:	528009a8 	mov	w8, #0x4d                  	// #77
    24f8:	528012c7 	mov	w7, #0x96                  	// #150
    24fc:	528003a6 	mov	w6, #0x1d                  	// #29
    2500:	17ffffe8 	b	24a0 <jpeg_encode_to+0x520>
      for(int by = 0; by < 2; by++)
    2504:	d2800025 	mov	x5, #0x1                   	// #1
    2508:	17fffff9 	b	24ec <jpeg_encode_to+0x56c>
          for(int dy = 0; dy < 2; dy++)
    250c:	52800024 	mov	w4, #0x1                   	// #1
              sr += p[0]; sg += p[1]; sb += p[2];
    2510:	394001cf 	ldrb	w15, [x14]
          for(int dy = 0; dy < 2; dy++)
    2514:	9100c1ce 	add	x14, x14, #0x30
              sr += p[0]; sg += p[1]; sb += p[2];
    2518:	385d11d0 	ldurb	w16, [x14, #-47]
    251c:	0b0301e3 	add	w3, w15, w3
    2520:	385d21cf 	ldurb	w15, [x14, #-46]
    2524:	0b020210 	add	w16, w16, w2
    2528:	385d41c2 	ldurb	w2, [x14, #-44]
    252c:	0b0001ef 	add	w15, w15, w0
    2530:	385d31c0 	ldurb	w0, [x14, #-45]
    2534:	0b100042 	add	w2, w2, w16
    2538:	0b030003 	add	w3, w0, w3
    253c:	385d51c0 	ldurb	w0, [x14, #-43]
    2540:	0b0f0000 	add	w0, w0, w15
          for(int dy = 0; dy < 2; dy++)
    2544:	34fffe44 	cbz	w4, 250c <jpeg_encode_to+0x58c>
          int r = (sr + 2) >> 2, g = (sg + 2) >> 2, b = (sb + 2) >> 2;
    2548:	11000842 	add	w2, w2, #0x2
    254c:	11000863 	add	w3, w3, #0x2
    2550:	11000800 	add	w0, w0, #0x2
        for(int x = 0; x < 8; x++){
    2554:	910018e7 	add	x7, x7, #0x6
          int r = (sr + 2) >> 2, g = (sg + 2) >> 2, b = (sb + 2) >> 2;
    2558:	13027c42 	asr	w2, w2, #2
    255c:	13027c63 	asr	w3, w3, #2
    2560:	13027c00 	asr	w0, w0, #2
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    2564:	1b0b7c4e 	mul	w14, w2, w11
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    2568:	1b0c7c42 	mul	w2, w2, w12
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    256c:	1b0a386e 	madd	w14, w3, w10, w14
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    2570:	0b031c43 	add	w3, w2, w3, lsl #7
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    2574:	0b001dce 	add	w14, w14, w0, lsl #7
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    2578:	1b0d0c00 	madd	w0, w0, w13, w3
          cb[y * 8 + x] = (-43*r - 85*g + 128*b) >> 8;
    257c:	13087dce 	asr	w14, w14, #8
    2580:	782168ce 	strh	w14, [x6, x1]
          cr[y * 8 + x] = (128*r - 107*g - 21*b) >> 8;
    2584:	13087c00 	asr	w0, w0, #8
    2588:	782168a0 	strh	w0, [x5, x1]
        for(int x = 0; x < 8; x++){
    258c:	91000821 	add	x1, x1, #0x2
    2590:	f100403f 	cmp	x1, #0x10
    2594:	540000e0 	b.eq	25b0 <jpeg_encode_to+0x630>  // b.none
          for(int dy = 0; dy < 2; dy++)
    2598:	aa0703ee 	mov	x14, x7
    259c:	52800004 	mov	w4, #0x0                   	// #0
          int sr = 0, sg = 0, sb = 0;
    25a0:	52800000 	mov	w0, #0x0                   	// #0
    25a4:	52800002 	mov	w2, #0x0                   	// #0
    25a8:	52800003 	mov	w3, #0x0                   	// #0
    25ac:	17ffffd9 	b	2510 <jpeg_encode_to+0x590>
      for(int y = 0; y < 8; y++)
    25b0:	11000929 	add	w9, w9, #0x2
    25b4:	910040c6 	add	x6, x6, #0x10
    25b8:	910040a5 	add	x5, x5, #0x10
    25bc:	91018108 	add	x8, x8, #0x60
    25c0:	7100413f 	cmp	w9, #0x10
    25c4:	54fff8a1 	b.ne	24d8 <jpeg_encode_to+0x558>  // b.any
      encode_block(w, cb, qc, &pred_cb);
    25c8:	9102a3e3 	add	x3, sp, #0xa8
    25cc:	9103c3e2 	add	x2, sp, #0xf0
    25d0:	9106c3e1 	add	x1, sp, #0x1b0
    25d4:	aa1303e0 	mov	x0, x19
    25d8:	b9007be4 	str	w4, [sp, #120]
    25dc:	97fffd60 	bl	1b5c <encode_block>
      encode_block(w, cr, qc, &pred_cr);
    25e0:	9102b3e3 	add	x3, sp, #0xac
    25e4:	9103c3e2 	add	x2, sp, #0xf0
    25e8:	9108c3e1 	add	x1, sp, #0x230
    25ec:	aa1303e0 	mov	x0, x19
    25f0:	97fffd5b 	bl	1b5c <encode_block>
    for(int mx = 0; mx < width; mx += 16){
    25f4:	b9407be4 	ldr	w4, [sp, #120]
    25f8:	2a1a03e9 	mov	w9, w26
    25fc:	6b1a029f 	cmp	w20, w26
    2600:	540000ad 	b.le	2614 <jpeg_encode_to+0x694>
      for(int y = 0; y < 16; y++)
    2604:	2a1603e8 	mov	w8, w22
        for(int x = 0; x < 16; x++){
    2608:	1100413a 	add	w26, w9, #0x10
          int sy = my + y < height ? my + y : height - 1;
    260c:	d2800007 	mov	x7, #0x0                   	// #0
    2610:	17ffff7a 	b	23f8 <jpeg_encode_to+0x478>
  for(int my = 0; my < height; my += 16){
    2614:	110042d6 	add	w22, w22, #0x10
    2618:	6b1602bf 	cmp	w21, w22
    261c:	54ffeb0c 	b.gt	237c <jpeg_encode_to+0x3fc>
  if(w->nbits)
    2620:	b9502660 	ldr	w0, [x19, #4132]
    2624:	340000e0 	cbz	w0, 2640 <jpeg_encode_to+0x6c0>
    put_bits(w, (1U << (8 - w->nbits)) - 1, 8 - w->nbits);
    2628:	52800102 	mov	w2, #0x8                   	// #8
    262c:	4b000042 	sub	w2, w2, w0
    2630:	aa1303e0 	mov	x0, x19
    2634:	1ac22081 	lsl	w1, w4, w2
    2638:	51000421 	sub	w1, w1, #0x1
    263c:	97fffd19 	bl	1aa0 <put_bits>
  jmarker(w, 0xd9);                // EOI
    2640:	52801b21 	mov	w1, #0xd9                  	// #217
    2644:	aa1303e0 	mov	x0, x19
    2648:	97fffd0a 	bl	1a70 <jmarker>
  if(jflush(w) < 0 || w->error)
    264c:	aa1303e0 	mov	x0, x19
    2650:	97fffcb5 	bl	1924 <jflush>
    2654:	3100041f 	cmn	w0, #0x1
    2658:	54ffcc00 	b.eq	1fd8 <jpeg_encode_to+0x58>  // b.none
    265c:	b9401660 	ldr	w0, [x19, #20]
    2660:	35ffcba0 	cbnz	w0, 1fd4 <jpeg_encode_to+0x54>
  if(written)
    2664:	f94037e1 	ldr	x1, [sp, #104]
    2668:	b4ffcb81 	cbz	x1, 1fd8 <jpeg_encode_to+0x58>
    *written = w->total;
    266c:	f94037e2 	ldr	x2, [sp, #104]
    2670:	b9401a61 	ldr	w1, [x19, #24]
    2674:	b9000041 	str	w1, [x2]
    2678:	17fffe58 	b	1fd8 <jpeg_encode_to+0x58>

000000000000267c <jpeg_encode>:
int
jpeg_encode(int fd, int width, int height, int quality,
            jpeg_pixel_fn pixel, void *arg, uint *written)
{
  struct jw w;
  if(fd < 0)
    267c:	37f803e0 	tbnz	w0, #31, 26f8 <jpeg_encode+0x7c>
{
    2680:	d282100c 	mov	x12, #0x1080                	// #4224
    2684:	cb2c63ff 	sub	sp, sp, x12
    2688:	a9007bfd 	stp	x29, x30, [sp]
    268c:	910003fd 	mov	x29, sp
    2690:	a90153f3 	stp	x19, x20, [sp, #16]
    2694:	2a0003f3 	mov	w19, w0
    2698:	2a0103f4 	mov	w20, w1
    return -1;
  memset(&w, 0, sizeof(w));
    269c:	910163e0 	add	x0, sp, #0x58
    26a0:	52800001 	mov	w1, #0x0                   	// #0
{
    26a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    26a8:	2a0303f6 	mov	w22, w3
    26ac:	2a0203f5 	mov	w21, w2
  memset(&w, 0, sizeof(w));
    26b0:	52820502 	mov	w2, #0x1028                	// #4136
    26b4:	a90397e4 	stp	x4, x5, [sp, #56]
    26b8:	f90027e6 	str	x6, [sp, #72]
    26bc:	97fff7bb 	bl	5a8 <memset@plt>
  w.fd = fd;
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    26c0:	a94397e4 	ldp	x4, x5, [sp, #56]
    26c4:	2a1603e3 	mov	w3, w22
    26c8:	f94027e6 	ldr	x6, [sp, #72]
    26cc:	2a1503e2 	mov	w2, w21
    26d0:	2a1403e1 	mov	w1, w20
    26d4:	910163e0 	add	x0, sp, #0x58
  w.fd = fd;
    26d8:	b9005bf3 	str	w19, [sp, #88]
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    26dc:	97fffe29 	bl	1f80 <jpeg_encode_to>
}
    26e0:	a9407bfd 	ldp	x29, x30, [sp]
    26e4:	d282100c 	mov	x12, #0x1080                	// #4224
    26e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    26ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    26f0:	8b2c63ff 	add	sp, sp, x12
    26f4:	d65f03c0 	ret
    return -1;
    26f8:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    26fc:	d65f03c0 	ret

0000000000002700 <jpeg_encode_mem>:
int
jpeg_encode_mem(uchar *dst, int cap, int width, int height, int quality,
                jpeg_pixel_fn pixel, void *arg, uint *written)
{
  struct jw w;
  if(dst == 0 || cap <= 0)
    2700:	f100001f 	cmp	x0, #0x0
    2704:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    2708:	540004ed 	b.le	27a4 <jpeg_encode_mem+0xa4>
{
    270c:	d282100c 	mov	x12, #0x1080                	// #4224
    2710:	cb2c63ff 	sub	sp, sp, x12
    2714:	a9007bfd 	stp	x29, x30, [sp]
    2718:	910003fd 	mov	x29, sp
    271c:	a90153f3 	stp	x19, x20, [sp, #16]
    2720:	aa0003f4 	mov	x20, x0
    2724:	2a0103f3 	mov	w19, w1
    return -1;
  memset(&w, 0, sizeof(w));
    2728:	910163e0 	add	x0, sp, #0x58
    272c:	52800001 	mov	w1, #0x0                   	// #0
{
    2730:	a9025bf5 	stp	x21, x22, [sp, #32]
    2734:	2a0303f6 	mov	w22, w3
    2738:	2a0203f5 	mov	w21, w2
  memset(&w, 0, sizeof(w));
    273c:	52820502 	mov	w2, #0x1028                	// #4136
{
    2740:	a90363f7 	stp	x23, x24, [sp, #48]
    2744:	aa0703f8 	mov	x24, x7
    2748:	aa0603f7 	mov	x23, x6
    274c:	b90047e4 	str	w4, [sp, #68]
    2750:	f90027e5 	str	x5, [sp, #72]
  memset(&w, 0, sizeof(w));
    2754:	97fff795 	bl	5a8 <memset@plt>
  w.fd = -1;
  w.mem = dst;
  w.cap = cap;
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    2758:	f94027e4 	ldr	x4, [sp, #72]
  w.fd = -1;
    275c:	12800000 	mov	w0, #0xffffffff            	// #-1
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    2760:	b94047e3 	ldr	w3, [sp, #68]
    2764:	aa1803e6 	mov	x6, x24
    2768:	aa1703e5 	mov	x5, x23
    276c:	2a1603e2 	mov	w2, w22
    2770:	2a1503e1 	mov	w1, w21
  w.fd = -1;
    2774:	b9005be0 	str	w0, [sp, #88]
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    2778:	910163e0 	add	x0, sp, #0x58
  w.mem = dst;
    277c:	f90033f4 	str	x20, [sp, #96]
  w.cap = cap;
    2780:	b9006bf3 	str	w19, [sp, #104]
  return jpeg_encode_to(&w, width, height, quality, pixel, arg, written);
    2784:	97fffdff 	bl	1f80 <jpeg_encode_to>
}
    2788:	a9407bfd 	ldp	x29, x30, [sp]
    278c:	d282100c 	mov	x12, #0x1080                	// #4224
    2790:	a94153f3 	ldp	x19, x20, [sp, #16]
    2794:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2798:	a94363f7 	ldp	x23, x24, [sp, #48]
    279c:	8b2c63ff 	add	sp, sp, x12
    27a0:	d65f03c0 	ret
    return -1;
    27a4:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    27a8:	d65f03c0 	ret
