
user/_clonetest:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000738 <.plt>:
 738:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 73c:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 740:	f9439211 	ldr	x17, [x16, #1824]
 744:	911c8210 	add	x16, x16, #0x720
 748:	d61f0220 	br	x17
 74c:	d503201f 	nop
 750:	d503201f 	nop
 754:	d503201f 	nop

0000000000000758 <waitpid@plt>:
 758:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 75c:	f9439611 	ldr	x17, [x16, #1832]
 760:	911ca210 	add	x16, x16, #0x728
 764:	d61f0220 	br	x17

0000000000000768 <printf@plt>:
 768:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 76c:	f9439a11 	ldr	x17, [x16, #1840]
 770:	911cc210 	add	x16, x16, #0x730
 774:	d61f0220 	br	x17

0000000000000778 <tjoin@plt>:
 778:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 77c:	f9439e11 	ldr	x17, [x16, #1848]
 780:	911ce210 	add	x16, x16, #0x738
 784:	d61f0220 	br	x17

0000000000000788 <malloc@plt>:
 788:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 78c:	f943a211 	ldr	x17, [x16, #1856]
 790:	911d0210 	add	x16, x16, #0x740
 794:	d61f0220 	br	x17

0000000000000798 <texit@plt>:
 798:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 79c:	f943a611 	ldr	x17, [x16, #1864]
 7a0:	911d2210 	add	x16, x16, #0x748
 7a4:	d61f0220 	br	x17

00000000000007a8 <fstat@plt>:
 7a8:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 7ac:	f943aa11 	ldr	x17, [x16, #1872]
 7b0:	911d4210 	add	x16, x16, #0x750
 7b4:	d61f0220 	br	x17

00000000000007b8 <sleep_ticks@plt>:
 7b8:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 7bc:	f943ae11 	ldr	x17, [x16, #1880]
 7c0:	911d6210 	add	x16, x16, #0x758
 7c4:	d61f0220 	br	x17

00000000000007c8 <chdir@plt>:
 7c8:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 7cc:	f943b211 	ldr	x17, [x16, #1888]
 7d0:	911d8210 	add	x16, x16, #0x760
 7d4:	d61f0220 	br	x17

00000000000007d8 <exec@plt>:
 7d8:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 7dc:	f943b611 	ldr	x17, [x16, #1896]
 7e0:	911da210 	add	x16, x16, #0x768
 7e4:	d61f0220 	br	x17

00000000000007e8 <unlink@plt>:
 7e8:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 7ec:	f943ba11 	ldr	x17, [x16, #1904]
 7f0:	911dc210 	add	x16, x16, #0x770
 7f4:	d61f0220 	br	x17

00000000000007f8 <fork@plt>:
 7f8:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 7fc:	f943be11 	ldr	x17, [x16, #1912]
 800:	911de210 	add	x16, x16, #0x778
 804:	d61f0220 	br	x17

0000000000000808 <strcmp@plt>:
 808:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 80c:	f943c211 	ldr	x17, [x16, #1920]
 810:	911e0210 	add	x16, x16, #0x780
 814:	d61f0220 	br	x17

0000000000000818 <getcwd@plt>:
 818:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 81c:	f943c611 	ldr	x17, [x16, #1928]
 820:	911e2210 	add	x16, x16, #0x788
 824:	d61f0220 	br	x17

0000000000000828 <vfork@plt>:
 828:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 82c:	f943ca11 	ldr	x17, [x16, #1936]
 830:	911e4210 	add	x16, x16, #0x790
 834:	d61f0220 	br	x17

0000000000000838 <exit@plt>:
 838:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 83c:	f943ce11 	ldr	x17, [x16, #1944]
 840:	911e6210 	add	x16, x16, #0x798
 844:	d61f0220 	br	x17

0000000000000848 <open@plt>:
 848:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 84c:	f943d211 	ldr	x17, [x16, #1952]
 850:	911e8210 	add	x16, x16, #0x7a0
 854:	d61f0220 	br	x17

0000000000000858 <clone@plt>:
 858:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 85c:	f943d611 	ldr	x17, [x16, #1960]
 860:	911ea210 	add	x16, x16, #0x7a8
 864:	d61f0220 	br	x17

0000000000000868 <thread_create@plt>:
 868:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 86c:	f943da11 	ldr	x17, [x16, #1968]
 870:	911ec210 	add	x16, x16, #0x7b0
 874:	d61f0220 	br	x17

0000000000000878 <mkdir@plt>:
 878:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 87c:	f943de11 	ldr	x17, [x16, #1976]
 880:	911ee210 	add	x16, x16, #0x7b8
 884:	d61f0220 	br	x17

0000000000000888 <close@plt>:
 888:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 88c:	f943e211 	ldr	x17, [x16, #1984]
 890:	911f0210 	add	x16, x16, #0x7c0
 894:	d61f0220 	br	x17

0000000000000898 <thread_join@plt>:
 898:	d0000010 	adrp	x16, 2000 <test_vfork+0x1004>
 89c:	f943e611 	ldr	x17, [x16, #1992]
 8a0:	911f2210 	add	x16, x16, #0x7c8
 8a4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000008a8 <main>:
        "reject unknown flags");
}

int
main(void)
{
     8a8:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
     8ac:	910003fd 	mov	x29, sp
     8b0:	a90153f3 	stp	x19, x20, [sp, #16]
     8b4:	a9025bf5 	stp	x21, x22, [sp, #32]
     8b8:	a90363f7 	stp	x23, x24, [sp, #48]
     8bc:	a9046bf9 	stp	x25, x26, [sp, #64]
  int pid = fork();
     8c0:	97ffffce 	bl	7f8 <fork@plt>
  if(pid == 0)
     8c4:	35000060 	cbnz	w0, 8d0 <main+0x28>
    exit(42);
     8c8:	52800540 	mov	w0, #0x2a                  	// #42
  unlink("/clonetest.d");
  if(failures == 0)
    printf("clonetest: OK\n");
  else
    printf("clonetest: %d FAILED\n", failures);
  exit(failures != 0);
     8cc:	97ffffdb 	bl	838 <exit@plt>
     8d0:	7100001f 	cmp	w0, #0x0
  check(pid > 0 && waitchild(pid) == 42, "fork() via SYS_fork");
     8d4:	540025cd 	b.le	d8c <main+0x4e4>
     8d8:	94000160 	bl	e58 <waitchild>
     8dc:	7100a81f 	cmp	w0, #0x2a
     8e0:	1a9f17e0 	cset	w0, eq	// eq = none
     8e4:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     8e8:	91097c21 	add	x1, x1, #0x25f
     8ec:	940001a0 	bl	f6c <check>
  int fd = -1, status = -1;
     8f0:	12800000 	mov	w0, #0xffffffff            	// #-1
  check(thread_create(&t, worker_open, &fd) == 0 &&
     8f4:	910163e2 	add	x2, sp, #0x58
     8f8:	90000001 	adrp	x1, 0 <.plt-0x738>
     8fc:	913b7021 	add	x1, x1, #0xedc
  int fd = -1, status = -1;
     900:	290b03e0 	stp	w0, w0, [sp, #88]
  check(thread_create(&t, worker_open, &fd) == 0 &&
     904:	910183e0 	add	x0, sp, #0x60
     908:	97ffffd8 	bl	868 <thread_create@plt>
     90c:	2a0003f3 	mov	w19, w0
     910:	35002420 	cbnz	w0, d94 <main+0x4ec>
        thread_join(&t, &status) > 0 && status == 0,
     914:	910173e1 	add	x1, sp, #0x5c
     918:	910183e0 	add	x0, sp, #0x60
     91c:	97ffffdf 	bl	898 <thread_join@plt>
  check(thread_create(&t, worker_open, &fd) == 0 &&
     920:	7100001f 	cmp	w0, #0x0
     924:	5400008d 	b.le	934 <main+0x8c>
     928:	b9405fe0 	ldr	w0, [sp, #92]
     92c:	7100001f 	cmp	w0, #0x0
     930:	1a9f17f3 	cset	w19, eq	// eq = none
     934:	2a1303e0 	mov	w0, w19
     938:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     93c:	9109cc21 	add	x1, x1, #0x273
     940:	9400018b 	bl	f6c <check>
  check(fd >= 0 && fd_valid(fd), "thread's open() visible to the process");
     944:	b9405be0 	ldr	w0, [sp, #88]
     948:	37f822a0 	tbnz	w0, #31, d9c <main+0x4f4>
     94c:	9400016f 	bl	f08 <fd_valid>
     950:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     954:	910a5021 	add	x1, x1, #0x294
     958:	94000185 	bl	f6c <check>
  if(fd >= 0)
     95c:	b9405be0 	ldr	w0, [sp, #88]
     960:	37f80040 	tbnz	w0, #31, 968 <main+0xc0>
    close(fd);
     964:	97ffffc9 	bl	888 <close@plt>
  pid = clone(child_open, stack_top(), CLONE_FILES | SIGCHLD, 0);
     968:	94000198 	bl	fc8 <stack_top>
     96c:	aa0003e1 	mov	x1, x0
     970:	d2800003 	mov	x3, #0x0                   	// #0
     974:	52808222 	mov	w2, #0x411                 	// #1041
     978:	90000013 	adrp	x19, 0 <.plt-0x738>
     97c:	913ac273 	add	x19, x19, #0xeb0
     980:	aa1303e0 	mov	x0, x19
     984:	97ffffb5 	bl	858 <clone@plt>
     988:	2a0003f4 	mov	w20, w0
  fd = waitchild(pid);
     98c:	94000133 	bl	e58 <waitchild>
  check(pid > 0 && fd >= 0 && fd < 100 && fd_valid(fd),
     990:	71018c1f 	cmp	w0, #0x63
  fd = waitchild(pid);
     994:	2a0003f5 	mov	w21, w0
  check(pid > 0 && fd >= 0 && fd < 100 && fd_valid(fd),
     998:	7a409a84 	ccmp	w20, #0x0, #0x4, ls	// ls = plast
     99c:	5400204d 	b.le	da4 <main+0x4fc>
     9a0:	9400015a 	bl	f08 <fd_valid>
     9a4:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     9a8:	910aec21 	add	x1, x1, #0x2bb
     9ac:	94000170 	bl	f6c <check>
  pid = clone(child_close, stack_top(), CLONE_FILES | SIGCHLD,
     9b0:	90000014 	adrp	x20, 0 <.plt-0x738>
     9b4:	913a5294 	add	x20, x20, #0xe94
     9b8:	94000184 	bl	fc8 <stack_top>
     9bc:	aa0003e1 	mov	x1, x0
     9c0:	93407ea3 	sxtw	x3, w21
     9c4:	52808222 	mov	w2, #0x411                 	// #1041
     9c8:	aa1403e0 	mov	x0, x20
     9cc:	97ffffa3 	bl	858 <clone@plt>
     9d0:	2a0003f6 	mov	w22, w0
  status = waitchild(pid);
     9d4:	94000121 	bl	e58 <waitchild>
  check(pid > 0 && status == 0 && !fd_valid(fd),
     9d8:	710002df 	cmp	w22, #0x0
     9dc:	7a40c800 	ccmp	w0, #0x0, #0x0, gt
     9e0:	54001e61 	b.ne	dac <main+0x504>  // b.any
     9e4:	2a1503e0 	mov	w0, w21
     9e8:	94000148 	bl	f08 <fd_valid>
     9ec:	52000000 	eor	w0, w0, #0x1
     9f0:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     9f4:	910ba421 	add	x1, x1, #0x2e9
     9f8:	9400015d 	bl	f6c <check>
  pid = clone(child_open, stack_top(), SIGCHLD, 0);
     9fc:	94000173 	bl	fc8 <stack_top>
     a00:	aa0003e1 	mov	x1, x0
     a04:	d2800003 	mov	x3, #0x0                   	// #0
     a08:	52800222 	mov	w2, #0x11                  	// #17
     a0c:	aa1303e0 	mov	x0, x19
     a10:	97ffff92 	bl	858 <clone@plt>
     a14:	2a0003f3 	mov	w19, w0
  fd = waitchild(pid);
     a18:	94000110 	bl	e58 <waitchild>
  check(pid > 0 && fd >= 0 && fd < 100 && !fd_valid(fd),
     a1c:	71018c1f 	cmp	w0, #0x63
     a20:	7a409a64 	ccmp	w19, #0x0, #0x4, ls	// ls = plast
     a24:	54001c8d 	b.le	db4 <main+0x50c>
     a28:	94000138 	bl	f08 <fd_valid>
     a2c:	52000000 	eor	w0, w0, #0x1
     a30:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     a34:	910c6421 	add	x1, x1, #0x319
     a38:	9400014d 	bl	f6c <check>
  fd = open("/clonetest.tmp", O_RDWR);
     a3c:	b0000016 	adrp	x22, 1000 <test_vfork+0x4>
     a40:	9105a2d6 	add	x22, x22, #0x168
     a44:	52800041 	mov	w1, #0x2                   	// #2
     a48:	aa1603e0 	mov	x0, x22
     a4c:	97ffff7f 	bl	848 <open@plt>
     a50:	2a0003f3 	mov	w19, w0
  pid = clone(child_close, stack_top(), SIGCHLD, (void *)(uint64)fd);
     a54:	9400015d 	bl	fc8 <stack_top>
     a58:	aa0003e1 	mov	x1, x0
     a5c:	52800222 	mov	w2, #0x11                  	// #17
     a60:	93407e63 	sxtw	x3, w19
     a64:	aa1403e0 	mov	x0, x20
     a68:	97ffff7c 	bl	858 <clone@plt>
  status = waitchild(pid);
     a6c:	940000fb 	bl	e58 <waitchild>
  check(fd >= 0 && status == 0 && fd_valid(fd),
     a70:	7100027f 	cmp	w19, #0x0
     a74:	7a40a800 	ccmp	w0, #0x0, #0x0, ge	// ge = tcont
     a78:	54001a21 	b.ne	dbc <main+0x514>  // b.any
     a7c:	2a1303e0 	mov	w0, w19
     a80:	94000122 	bl	f08 <fd_valid>
     a84:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     a88:	910d1821 	add	x1, x1, #0x346
     a8c:	94000138 	bl	f6c <check>
  mkdir("/clonetest.d");
     a90:	b0000014 	adrp	x20, 1000 <test_vfork+0x4>
     a94:	910de694 	add	x20, x20, #0x379
  close(fd);
     a98:	2a1303e0 	mov	w0, w19
     a9c:	97ffff7b 	bl	888 <close@plt>
  chdir("/");
     aa0:	b0000018 	adrp	x24, 1000 <test_vfork+0x4>
     aa4:	910e1b18 	add	x24, x24, #0x386
  mkdir("/clonetest.d");
     aa8:	aa1403e0 	mov	x0, x20
     aac:	97ffff73 	bl	878 <mkdir@plt>
  pid = clone(child_chdir, stack_top(), SIGCHLD, "/clonetest.d");
     ab0:	90000019 	adrp	x25, 0 <.plt-0x738>
     ab4:	913ca339 	add	x25, x25, #0xf28
  chdir("/");
     ab8:	aa1803e0 	mov	x0, x24
     abc:	97ffff43 	bl	7c8 <chdir@plt>
  pid = clone(child_chdir, stack_top(), SIGCHLD, "/clonetest.d");
     ac0:	d0000017 	adrp	x23, 2000 <test_vfork+0x1004>
     ac4:	911f42f3 	add	x19, x23, #0x7d0
     ac8:	94000140 	bl	fc8 <stack_top>
     acc:	aa1403e3 	mov	x3, x20
     ad0:	aa0003e1 	mov	x1, x0
     ad4:	52800222 	mov	w2, #0x11                  	// #17
     ad8:	aa1903e0 	mov	x0, x25
     adc:	97ffff5f 	bl	858 <clone@plt>
  check(waitchild(pid) == 0 && getcwd(cwd, sizeof(cwd)) &&
     ae0:	940000de 	bl	e58 <waitchild>
     ae4:	2a0003f5 	mov	w21, w0
     ae8:	350016e0 	cbnz	w0, dc4 <main+0x51c>
     aec:	91003260 	add	x0, x19, #0xc
     af0:	52801001 	mov	w1, #0x80                  	// #128
     af4:	97ffff49 	bl	818 <getcwd@plt>
     af8:	b40000c0 	cbz	x0, b10 <main+0x268>
        strcmp(cwd, "/") == 0, "no CLONE_FS: child's chdir() stays private");
     afc:	aa1803e1 	mov	x1, x24
     b00:	91003260 	add	x0, x19, #0xc
     b04:	97ffff41 	bl	808 <strcmp@plt>
  check(waitchild(pid) == 0 && getcwd(cwd, sizeof(cwd)) &&
     b08:	7100001f 	cmp	w0, #0x0
     b0c:	1a9f17f5 	cset	w21, eq	// eq = none
     b10:	2a1503e0 	mov	w0, w21
     b14:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     b18:	910e2021 	add	x1, x1, #0x388
     b1c:	94000114 	bl	f6c <check>
  pid = clone(child_chdir, stack_top(), CLONE_FS | SIGCHLD, "/clonetest.d");
     b20:	9400012a 	bl	fc8 <stack_top>
     b24:	aa0003e1 	mov	x1, x0
     b28:	aa1403e3 	mov	x3, x20
     b2c:	52804222 	mov	w2, #0x211                 	// #529
     b30:	aa1903e0 	mov	x0, x25
     b34:	97ffff49 	bl	858 <clone@plt>
  check(waitchild(pid) == 0 && getcwd(cwd, sizeof(cwd)) &&
     b38:	940000c8 	bl	e58 <waitchild>
     b3c:	2a0003f5 	mov	w21, w0
     b40:	35001460 	cbnz	w0, dcc <main+0x524>
     b44:	91003260 	add	x0, x19, #0xc
     b48:	52801001 	mov	w1, #0x80                  	// #128
     b4c:	97ffff33 	bl	818 <getcwd@plt>
     b50:	b40000c0 	cbz	x0, b68 <main+0x2c0>
        strcmp(cwd, "/clonetest.d") == 0,
     b54:	aa1403e1 	mov	x1, x20
     b58:	91003260 	add	x0, x19, #0xc
     b5c:	97ffff2b 	bl	808 <strcmp@plt>
  check(waitchild(pid) == 0 && getcwd(cwd, sizeof(cwd)) &&
     b60:	7100001f 	cmp	w0, #0x0
     b64:	1a9f17f5 	cset	w21, eq	// eq = none
     b68:	2a1503e0 	mov	w0, w21
     b6c:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     b70:	910ecc21 	add	x1, x1, #0x3b3
     b74:	940000fe 	bl	f6c <check>
  check(open("clonetest.rel", O_CREATE | O_RDWR) >= 0 &&
     b78:	b0000000 	adrp	x0, 1000 <test_vfork+0x4>
     b7c:	910f9c00 	add	x0, x0, #0x3e7
     b80:	52804041 	mov	w1, #0x202                 	// #514
     b84:	97ffff31 	bl	848 <open@plt>
     b88:	37f81260 	tbnz	w0, #31, dd4 <main+0x52c>
        unlink("/clonetest.d/clonetest.rel") == 0,
     b8c:	b0000000 	adrp	x0, 1000 <test_vfork+0x4>
     b90:	910f6800 	add	x0, x0, #0x3da
     b94:	97ffff15 	bl	7e8 <unlink@plt>
  check(open("clonetest.rel", O_CREATE | O_RDWR) >= 0 &&
     b98:	7100001f 	cmp	w0, #0x0
     b9c:	1a9f17e0 	cset	w0, eq	// eq = none
     ba0:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     ba4:	910fd421 	add	x1, x1, #0x3f5
     ba8:	940000f1 	bl	f6c <check>
  pid = clone(child_store, stack_top(), SIGCHLD, (void *)11);
     bac:	90000015 	adrp	x21, 0 <.plt-0x738>
     bb0:	913902b5 	add	x21, x21, #0xe40
  chdir("/");
     bb4:	aa1803e0 	mov	x0, x24
     bb8:	97ffff04 	bl	7c8 <chdir@plt>
  shared_word = 0;
     bbc:	b907d2ff 	str	wzr, [x23, #2000]
  pid = clone(child_store, stack_top(), SIGCHLD, (void *)11);
     bc0:	94000102 	bl	fc8 <stack_top>
     bc4:	aa0003e1 	mov	x1, x0
     bc8:	d2800163 	mov	x3, #0xb                   	// #11
     bcc:	52800222 	mov	w2, #0x11                  	// #17
     bd0:	aa1503e0 	mov	x0, x21
     bd4:	97ffff21 	bl	858 <clone@plt>
  check(waitchild(pid) == 0 && shared_word == 0,
     bd8:	940000a0 	bl	e58 <waitchild>
     bdc:	35001000 	cbnz	w0, ddc <main+0x534>
     be0:	b947d2e0 	ldr	w0, [x23, #2000]
     be4:	7100001f 	cmp	w0, #0x0
     be8:	1a9f17e0 	cset	w0, eq	// eq = none
     bec:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     bf0:	91109021 	add	x1, x1, #0x424
     bf4:	940000de 	bl	f6c <check>
  pid = clone(child_store, stack_top(), CLONE_VM | SIGCHLD, (void *)22);
     bf8:	940000f4 	bl	fc8 <stack_top>
     bfc:	aa0003e1 	mov	x1, x0
     c00:	d28002c3 	mov	x3, #0x16                  	// #22
     c04:	52802222 	mov	w2, #0x111                 	// #273
     c08:	aa1503e0 	mov	x0, x21
     c0c:	97ffff13 	bl	858 <clone@plt>
  check(waitchild(pid) == 0 && shared_word == 22,
     c10:	94000092 	bl	e58 <waitchild>
     c14:	35000e80 	cbnz	w0, de4 <main+0x53c>
     c18:	b947d2e0 	ldr	w0, [x23, #2000]
     c1c:	7100581f 	cmp	w0, #0x16
     c20:	1a9f17e0 	cset	w0, eq	// eq = none
     c24:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     c28:	91113421 	add	x1, x1, #0x44d
     c2c:	940000d0 	bl	f6c <check>
  pid = clone(child_store, stack_top(),
     c30:	940000e6 	bl	fc8 <stack_top>
     c34:	aa0003e1 	mov	x1, x0
     c38:	d2800423 	mov	x3, #0x21                  	// #33
     c3c:	aa1503e0 	mov	x0, x21
     c40:	5281e002 	mov	w2, #0xf00                 	// #3840
     c44:	72a00022 	movk	w2, #0x1, lsl #16
     c48:	97ffff04 	bl	858 <clone@plt>
     c4c:	2a0003f5 	mov	w21, w0
  check(pid > 0 && tjoin(pid, 0) == pid && shared_word == 33,
     c50:	7100001f 	cmp	w0, #0x0
     c54:	54000ccc 	b.gt	dec <main+0x544>
     c58:	52800000 	mov	w0, #0x0                   	// #0
     c5c:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     c60:	9111bc21 	add	x1, x1, #0x46f
     c64:	940000c2 	bl	f6c <check>
  pid = clone(child_tid, stack_top(),
     c68:	90000015 	adrp	x21, 0 <.plt-0x738>
     c6c:	913942b5 	add	x21, x21, #0xe50
     c70:	940000d6 	bl	fc8 <stack_top>
     c74:	aa0003e1 	mov	x1, x0
     c78:	91023266 	add	x6, x19, #0x8c
     c7c:	91024264 	add	x4, x19, #0x90
     c80:	aa1503e0 	mov	x0, x21
     c84:	52800005 	mov	w5, #0x0                   	// #0
     c88:	d2800003 	mov	x3, #0x0                   	// #0
     c8c:	52802222 	mov	w2, #0x111                 	// #273
     c90:	72a02202 	movk	w2, #0x110, lsl #16
     c94:	97fffef1 	bl	858 <clone@plt>
     c98:	2a0003f7 	mov	w23, w0
  check(pid > 0 && waitchild(pid) == 0 && ptid == pid && ctid == pid,
     c9c:	7100001f 	cmp	w0, #0x0
     ca0:	54000b6c 	b.gt	e0c <main+0x564>
     ca4:	52800000 	mov	w0, #0x0                   	// #0
     ca8:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     cac:	91126021 	add	x1, x1, #0x498
     cb0:	940000af 	bl	f6c <check>
  test_vfork();
     cb4:	940000d2 	bl	ffc <test_vfork>
  check(clone(child_tid, stack_top(), CLONE_THREAD | CLONE_VM, 0) < 0,
     cb8:	940000c4 	bl	fc8 <stack_top>
     cbc:	aa0003e1 	mov	x1, x0
     cc0:	d2800003 	mov	x3, #0x0                   	// #0
     cc4:	aa1503e0 	mov	x0, x21
     cc8:	52802002 	mov	w2, #0x100                 	// #256
     ccc:	72a00022 	movk	w2, #0x1, lsl #16
     cd0:	97fffee2 	bl	858 <clone@plt>
     cd4:	531f7c00 	lsr	w0, w0, #31
     cd8:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     cdc:	9112fc21 	add	x1, x1, #0x4bf
     ce0:	940000a3 	bl	f6c <check>
  check(clone(child_tid, stack_top(), CLONE_SIGHAND, 0) < 0,
     ce4:	940000b9 	bl	fc8 <stack_top>
     ce8:	aa0003e1 	mov	x1, x0
     cec:	d2800003 	mov	x3, #0x0                   	// #0
     cf0:	52810002 	mov	w2, #0x800                 	// #2048
     cf4:	aa1503e0 	mov	x0, x21
     cf8:	97fffed8 	bl	858 <clone@plt>
     cfc:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     d00:	9113a421 	add	x1, x1, #0x4e9
     d04:	531f7c00 	lsr	w0, w0, #31
     d08:	94000099 	bl	f6c <check>
  check(clone(child_tid, 0, CLONE_VM | SIGCHLD, 0) < 0,
     d0c:	d2800003 	mov	x3, #0x0                   	// #0
     d10:	52802222 	mov	w2, #0x111                 	// #273
     d14:	d2800001 	mov	x1, #0x0                   	// #0
     d18:	aa1503e0 	mov	x0, x21
     d1c:	97fffecf 	bl	858 <clone@plt>
     d20:	531f7c00 	lsr	w0, w0, #31
     d24:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     d28:	91143c21 	add	x1, x1, #0x50f
     d2c:	94000090 	bl	f6c <check>
  check(clone(child_tid, stack_top(), 0x80000000, 0) < 0,
     d30:	940000a6 	bl	fc8 <stack_top>
     d34:	aa0003e1 	mov	x1, x0
     d38:	d2800003 	mov	x3, #0x0                   	// #0
     d3c:	52b00002 	mov	w2, #0x80000000            	// #-2147483648
     d40:	aa1503e0 	mov	x0, x21
     d44:	97fffec5 	bl	858 <clone@plt>
     d48:	b0000001 	adrp	x1, 1000 <test_vfork+0x4>
     d4c:	9114bc21 	add	x1, x1, #0x52f
     d50:	531f7c00 	lsr	w0, w0, #31
     d54:	94000086 	bl	f6c <check>
  unlink("/clonetest.tmp");
     d58:	aa1603e0 	mov	x0, x22
     d5c:	97fffea3 	bl	7e8 <unlink@plt>
  unlink("/clonetest.d");
     d60:	aa1403e0 	mov	x0, x20
     d64:	97fffea1 	bl	7e8 <unlink@plt>
  if(failures == 0)
     d68:	b9400a61 	ldr	w1, [x19, #8]
     d6c:	35000621 	cbnz	w1, e30 <main+0x588>
    printf("clonetest: OK\n");
     d70:	b0000000 	adrp	x0, 1000 <test_vfork+0x4>
     d74:	91151000 	add	x0, x0, #0x544
     d78:	97fffe7c 	bl	768 <printf@plt>
  exit(failures != 0);
     d7c:	b9400a60 	ldr	w0, [x19, #8]
     d80:	7100001f 	cmp	w0, #0x0
     d84:	1a9f07e0 	cset	w0, ne	// ne = any
     d88:	17fffed1 	b	8cc <main+0x24>
  check(pid > 0 && waitchild(pid) == 42, "fork() via SYS_fork");
     d8c:	52800000 	mov	w0, #0x0                   	// #0
     d90:	17fffed5 	b	8e4 <main+0x3c>
  check(thread_create(&t, worker_open, &fd) == 0 &&
     d94:	52800013 	mov	w19, #0x0                   	// #0
     d98:	17fffee7 	b	934 <main+0x8c>
  check(fd >= 0 && fd_valid(fd), "thread's open() visible to the process");
     d9c:	52800000 	mov	w0, #0x0                   	// #0
     da0:	17fffeec 	b	950 <main+0xa8>
  check(pid > 0 && fd >= 0 && fd < 100 && fd_valid(fd),
     da4:	52800000 	mov	w0, #0x0                   	// #0
     da8:	17fffeff 	b	9a4 <main+0xfc>
  check(pid > 0 && status == 0 && !fd_valid(fd),
     dac:	52800000 	mov	w0, #0x0                   	// #0
     db0:	17ffff10 	b	9f0 <main+0x148>
  check(pid > 0 && fd >= 0 && fd < 100 && !fd_valid(fd),
     db4:	52800000 	mov	w0, #0x0                   	// #0
     db8:	17ffff1e 	b	a30 <main+0x188>
  check(fd >= 0 && status == 0 && fd_valid(fd),
     dbc:	52800000 	mov	w0, #0x0                   	// #0
     dc0:	17ffff31 	b	a84 <main+0x1dc>
  check(waitchild(pid) == 0 && getcwd(cwd, sizeof(cwd)) &&
     dc4:	52800015 	mov	w21, #0x0                   	// #0
     dc8:	17ffff52 	b	b10 <main+0x268>
  check(waitchild(pid) == 0 && getcwd(cwd, sizeof(cwd)) &&
     dcc:	52800015 	mov	w21, #0x0                   	// #0
     dd0:	17ffff66 	b	b68 <main+0x2c0>
  check(open("clonetest.rel", O_CREATE | O_RDWR) >= 0 &&
     dd4:	52800000 	mov	w0, #0x0                   	// #0
     dd8:	17ffff72 	b	ba0 <main+0x2f8>
  check(waitchild(pid) == 0 && shared_word == 0,
     ddc:	52800000 	mov	w0, #0x0                   	// #0
     de0:	17ffff83 	b	bec <main+0x344>
  check(waitchild(pid) == 0 && shared_word == 22,
     de4:	52800000 	mov	w0, #0x0                   	// #0
     de8:	17ffff8f 	b	c24 <main+0x37c>
  check(pid > 0 && tjoin(pid, 0) == pid && shared_word == 33,
     dec:	d2800001 	mov	x1, #0x0                   	// #0
     df0:	97fffe62 	bl	778 <tjoin@plt>
     df4:	6b0002bf 	cmp	w21, w0
     df8:	54fff301 	b.ne	c58 <main+0x3b0>  // b.any
     dfc:	b947d2e0 	ldr	w0, [x23, #2000]
     e00:	7100841f 	cmp	w0, #0x21
     e04:	1a9f17e0 	cset	w0, eq	// eq = none
     e08:	17ffff95 	b	c5c <main+0x3b4>
  check(pid > 0 && waitchild(pid) == 0 && ptid == pid && ctid == pid,
     e0c:	94000013 	bl	e58 <waitchild>
     e10:	35fff4a0 	cbnz	w0, ca4 <main+0x3fc>
     e14:	b9409261 	ldr	w1, [x19, #144]
     e18:	6b0102ff 	cmp	w23, w1
     e1c:	54fff461 	b.ne	ca8 <main+0x400>  // b.any
     e20:	b9408e60 	ldr	w0, [x19, #140]
     e24:	6b17001f 	cmp	w0, w23
     e28:	1a9f17e0 	cset	w0, eq	// eq = none
     e2c:	17ffff9f 	b	ca8 <main+0x400>
    printf("clonetest: %d FAILED\n", failures);
     e30:	b0000000 	adrp	x0, 1000 <test_vfork+0x4>
     e34:	91154c00 	add	x0, x0, #0x553
     e38:	97fffe4c 	bl	768 <printf@plt>
     e3c:	17ffffd0 	b	d7c <main+0x4d4>

0000000000000e40 <child_store>:
  shared_word = (int)(uint64)arg;
     e40:	d0000001 	adrp	x1, 2000 <test_vfork+0x1004>
     e44:	b907d020 	str	w0, [x1, #2000]
}
     e48:	52800000 	mov	w0, #0x0                   	// #0
     e4c:	d65f03c0 	ret

0000000000000e50 <child_tid>:
}
     e50:	52800000 	mov	w0, #0x0                   	// #0
     e54:	d65f03c0 	ret

0000000000000e58 <waitchild>:
{
     e58:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  if(waitpid(pid, &status, 0) != pid)
     e5c:	52800002 	mov	w2, #0x0                   	// #0
{
     e60:	910003fd 	mov	x29, sp
  if(waitpid(pid, &status, 0) != pid)
     e64:	9100b3e1 	add	x1, sp, #0x2c
{
     e68:	a90153f3 	stp	x19, x20, [sp, #16]
     e6c:	2a0003f4 	mov	w20, w0
  int status = -1;
     e70:	12800013 	mov	w19, #0xffffffff            	// #-1
     e74:	b9002ff3 	str	w19, [sp, #44]
  if(waitpid(pid, &status, 0) != pid)
     e78:	97fffe38 	bl	758 <waitpid@plt>
  return status;
     e7c:	6b14001f 	cmp	w0, w20
}
     e80:	b9402fe0 	ldr	w0, [sp, #44]
     e84:	1a930000 	csel	w0, w0, w19, eq	// eq = none
     e88:	a94153f3 	ldp	x19, x20, [sp, #16]
     e8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
     e90:	d65f03c0 	ret

0000000000000e94 <child_close>:
{
     e94:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
     e98:	910003fd 	mov	x29, sp
  return close((int)(uint64)arg) == 0 ? 0 : 1;
     e9c:	97fffe7b 	bl	888 <close@plt>
     ea0:	7100001f 	cmp	w0, #0x0
}
     ea4:	1a9f07e0 	cset	w0, ne	// ne = any
     ea8:	a8c17bfd 	ldp	x29, x30, [sp], #16
     eac:	d65f03c0 	ret

0000000000000eb0 <child_open>:
{
     eb0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  int fd = open("/clonetest.tmp", O_CREATE | O_RDWR);
     eb4:	52804041 	mov	w1, #0x202                 	// #514
     eb8:	b0000000 	adrp	x0, 1000 <test_vfork+0x4>
     ebc:	9105a000 	add	x0, x0, #0x168
{
     ec0:	910003fd 	mov	x29, sp
  int fd = open("/clonetest.tmp", O_CREATE | O_RDWR);
     ec4:	97fffe61 	bl	848 <open@plt>
  return fd < 0 ? 100 : fd;
     ec8:	7100001f 	cmp	w0, #0x0
}
     ecc:	52800c81 	mov	w1, #0x64                  	// #100
     ed0:	a8c17bfd 	ldp	x29, x30, [sp], #16
     ed4:	1a81a000 	csel	w0, w0, w1, ge	// ge = tcont
     ed8:	d65f03c0 	ret

0000000000000edc <worker_open>:
{
     edc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  *(int *)arg = open("/clonetest.tmp", O_CREATE | O_RDWR);
     ee0:	52804041 	mov	w1, #0x202                 	// #514
{
     ee4:	910003fd 	mov	x29, sp
     ee8:	f9000bf3 	str	x19, [sp, #16]
     eec:	aa0003f3 	mov	x19, x0
  *(int *)arg = open("/clonetest.tmp", O_CREATE | O_RDWR);
     ef0:	b0000000 	adrp	x0, 1000 <test_vfork+0x4>
     ef4:	9105a000 	add	x0, x0, #0x168
     ef8:	97fffe54 	bl	848 <open@plt>
     efc:	b9000260 	str	w0, [x19]
  texit(0);
     f00:	52800000 	mov	w0, #0x0                   	// #0
     f04:	97fffe25 	bl	798 <texit@plt>

0000000000000f08 <fd_valid>:
{
     f08:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
     f0c:	910003fd 	mov	x29, sp
  return fstat(fd, &st) == 0;
     f10:	910063e1 	add	x1, sp, #0x18
     f14:	97fffe25 	bl	7a8 <fstat@plt>
     f18:	7100001f 	cmp	w0, #0x0
}
     f1c:	1a9f17e0 	cset	w0, eq	// eq = none
     f20:	a8c37bfd 	ldp	x29, x30, [sp], #48
     f24:	d65f03c0 	ret

0000000000000f28 <child_chdir>:
{
     f28:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
     f2c:	910003fd 	mov	x29, sp
  return chdir((char *)arg) == 0 ? 0 : 1;
     f30:	97fffe26 	bl	7c8 <chdir@plt>
     f34:	7100001f 	cmp	w0, #0x0
}
     f38:	1a9f07e0 	cset	w0, ne	// ne = any
     f3c:	a8c17bfd 	ldp	x29, x30, [sp], #16
     f40:	d65f03c0 	ret

0000000000000f44 <child_slow>:
{
     f44:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  sleep_ticks(5);
     f48:	528000a0 	mov	w0, #0x5                   	// #5
{
     f4c:	910003fd 	mov	x29, sp
  sleep_ticks(5);
     f50:	97fffe1a 	bl	7b8 <sleep_ticks@plt>
  vfork_done_flag = 1;
     f54:	d0000000 	adrp	x0, 2000 <test_vfork+0x1004>
     f58:	52800021 	mov	w1, #0x1                   	// #1
}
     f5c:	a8c17bfd 	ldp	x29, x30, [sp], #16
  vfork_done_flag = 1;
     f60:	b907d401 	str	w1, [x0, #2004]
}
     f64:	528000e0 	mov	w0, #0x7                   	// #7
     f68:	d65f03c0 	ret

0000000000000f6c <check>:
{
     f6c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  printf("clonetest: %s %s\n", ok ? "ok  " : "FAIL", what);
     f70:	7100001f 	cmp	w0, #0x0
     f74:	b0000003 	adrp	x3, 1000 <test_vfork+0x4>
     f78:	9105dc63 	add	x3, x3, #0x177
     f7c:	b0000004 	adrp	x4, 1000 <test_vfork+0x4>
{
     f80:	910003fd 	mov	x29, sp
  printf("clonetest: %s %s\n", ok ? "ok  " : "FAIL", what);
     f84:	aa0103e2 	mov	x2, x1
     f88:	9105f081 	add	x1, x4, #0x17c
     f8c:	9a830021 	csel	x1, x1, x3, eq	// eq = none
{
     f90:	f9000bf3 	str	x19, [sp, #16]
     f94:	2a0003f3 	mov	w19, w0
  printf("clonetest: %s %s\n", ok ? "ok  " : "FAIL", what);
     f98:	b0000000 	adrp	x0, 1000 <test_vfork+0x4>
     f9c:	91060400 	add	x0, x0, #0x181
     fa0:	97fffdf2 	bl	768 <printf@plt>
  if(!ok)
     fa4:	350000d3 	cbnz	w19, fbc <check+0x50>
    failures++;
     fa8:	d0000000 	adrp	x0, 2000 <test_vfork+0x1004>
     fac:	911f4000 	add	x0, x0, #0x7d0
     fb0:	b9400801 	ldr	w1, [x0, #8]
     fb4:	11000421 	add	w1, w1, #0x1
     fb8:	b9000801 	str	w1, [x0, #8]
}
     fbc:	f9400bf3 	ldr	x19, [sp, #16]
     fc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
     fc4:	d65f03c0 	ret

0000000000000fc8 <stack_top>:
{
     fc8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  char *s = malloc(STACK);
     fcc:	52840000 	mov	w0, #0x2000                	// #8192
{
     fd0:	910003fd 	mov	x29, sp
  char *s = malloc(STACK);
     fd4:	97fffded 	bl	788 <malloc@plt>
  if(s == 0){
     fd8:	b50000c0 	cbnz	x0, ff0 <stack_top+0x28>
    printf("clonetest: malloc failed\n");
     fdc:	b0000000 	adrp	x0, 1000 <test_vfork+0x4>
     fe0:	91064c00 	add	x0, x0, #0x193
     fe4:	97fffde1 	bl	768 <printf@plt>
    exit(1);
     fe8:	52800020 	mov	w0, #0x1                   	// #1
     fec:	97fffe13 	bl	838 <exit@plt>
}
     ff0:	91400800 	add	x0, x0, #0x2, lsl #12
     ff4:	a8c17bfd 	ldp	x29, x30, [sp], #16
     ff8:	d65f03c0 	ret

0000000000000ffc <test_vfork>:
{
     ffc:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1000:	910003fd 	mov	x29, sp
    1004:	a90153f3 	stp	x19, x20, [sp, #16]
  vfork_done_flag = 0;
    1008:	b0000013 	adrp	x19, 2000 <test_vfork+0x1004>
    100c:	911f4273 	add	x19, x19, #0x7d0
    1010:	b900067f 	str	wzr, [x19, #4]
  pid = clone(child_slow, stack_top(), CLONE_VM | CLONE_VFORK | SIGCHLD, 0);
    1014:	97ffffed 	bl	fc8 <stack_top>
    1018:	d2800003 	mov	x3, #0x0                   	// #0
    101c:	aa0003e1 	mov	x1, x0
    1020:	52882222 	mov	w2, #0x4111                	// #16657
    1024:	f0ffffe0 	adrp	x0, 0 <.plt-0x738>
    1028:	913d1000 	add	x0, x0, #0xf44
    102c:	97fffe0b 	bl	858 <clone@plt>
    1030:	2a0003f4 	mov	w20, w0
  check(pid > 0 && vfork_done_flag == 1,
    1034:	7100001f 	cmp	w0, #0x0
    1038:	540004ed 	b.le	10d4 <test_vfork+0xd8>
    103c:	b9400660 	ldr	w0, [x19, #4]
    1040:	7100041f 	cmp	w0, #0x1
    1044:	1a9f17e0 	cset	w0, eq	// eq = none
    1048:	90000001 	adrp	x1, 1000 <test_vfork+0x4>
    104c:	9106b421 	add	x1, x1, #0x1ad
    1050:	97ffffc7 	bl	f6c <check>
  check(waitchild(pid) == 7, "CLONE_VFORK: exit status reaped");
    1054:	2a1403e0 	mov	w0, w20
    1058:	97ffff80 	bl	e58 <waitchild>
    105c:	71001c1f 	cmp	w0, #0x7
    1060:	1a9f17e0 	cset	w0, eq	// eq = none
    1064:	90000001 	adrp	x1, 1000 <test_vfork+0x4>
    1068:	91075821 	add	x1, x1, #0x1d6
    106c:	97ffffc0 	bl	f6c <check>
  vfork_done_flag = 0;
    1070:	b0000000 	adrp	x0, 2000 <test_vfork+0x1004>
    1074:	b907d41f 	str	wzr, [x0, #2004]
  pid = vfork();
    1078:	97fffdec 	bl	828 <vfork@plt>
    107c:	2a0003f3 	mov	w19, w0
  if(pid == 0){
    1080:	7100001f 	cmp	w0, #0x0
    1084:	350002c0 	cbnz	w0, 10dc <test_vfork+0xe0>
    char *argv[] = { "echo", "clonetest: vfork child exec'd echo", 0 };
    1088:	90000000 	adrp	x0, 1000 <test_vfork+0x4>
    108c:	91164000 	add	x0, x0, #0x590
    vfork_done_flag = 1;          // shared memory: parent sees this
    1090:	52800021 	mov	w1, #0x1                   	// #1
    char *argv[] = { "echo", "clonetest: vfork child exec'd echo", 0 };
    1094:	a9400c02 	ldp	x2, x3, [x0]
    1098:	a9028fe2 	stp	x2, x3, [sp, #40]
    109c:	f9400800 	ldr	x0, [x0, #16]
    10a0:	f9001fe0 	str	x0, [sp, #56]
    vfork_done_flag = 1;          // shared memory: parent sees this
    10a4:	b0000000 	adrp	x0, 2000 <test_vfork+0x1004>
    10a8:	b907d401 	str	w1, [x0, #2004]
    exec("/echo", argv);
    10ac:	9100a3e1 	add	x1, sp, #0x28
    10b0:	90000000 	adrp	x0, 1000 <test_vfork+0x4>
    10b4:	9107e800 	add	x0, x0, #0x1fa
    10b8:	97fffdc8 	bl	7d8 <exec@plt>
    exec("/bin/echo", argv);
    10bc:	9100a3e1 	add	x1, sp, #0x28
    10c0:	90000000 	adrp	x0, 1000 <test_vfork+0x4>
    10c4:	9107d800 	add	x0, x0, #0x1f6
    10c8:	97fffdc4 	bl	7d8 <exec@plt>
    exit(99);
    10cc:	52800c60 	mov	w0, #0x63                  	// #99
    exit(5);
    10d0:	97fffdda 	bl	838 <exit@plt>
  check(pid > 0 && vfork_done_flag == 1,
    10d4:	52800000 	mov	w0, #0x0                   	// #0
    10d8:	17ffffdc 	b	1048 <test_vfork+0x4c>
  check(pid > 0 && vfork_done_flag == 1, "vfork(): parent resumes after exec");
    10dc:	5400028d 	b.le	112c <test_vfork+0x130>
    10e0:	b0000000 	adrp	x0, 2000 <test_vfork+0x1004>
    10e4:	b947d400 	ldr	w0, [x0, #2004]
    10e8:	7100041f 	cmp	w0, #0x1
    10ec:	1a9f17e0 	cset	w0, eq	// eq = none
    10f0:	90000001 	adrp	x1, 1000 <test_vfork+0x4>
    10f4:	91080021 	add	x1, x1, #0x200
    10f8:	97ffff9d 	bl	f6c <check>
  status = waitchild(pid);
    10fc:	2a1303e0 	mov	w0, w19
    1100:	97ffff56 	bl	e58 <waitchild>
  check(status == 0, "vfork(): exec'd child exits normally");
    1104:	7100001f 	cmp	w0, #0x0
    1108:	1a9f17e0 	cset	w0, eq	// eq = none
    110c:	90000001 	adrp	x1, 1000 <test_vfork+0x4>
    1110:	91088c21 	add	x1, x1, #0x223
    1114:	97ffff96 	bl	f6c <check>
  pid = vfork();
    1118:	97fffdc4 	bl	828 <vfork@plt>
  if(pid == 0)
    111c:	7100001f 	cmp	w0, #0x0
    1120:	350000a0 	cbnz	w0, 1134 <test_vfork+0x138>
    exit(5);
    1124:	528000a0 	mov	w0, #0x5                   	// #5
    1128:	17ffffea 	b	10d0 <test_vfork+0xd4>
  check(pid > 0 && vfork_done_flag == 1, "vfork(): parent resumes after exec");
    112c:	52800000 	mov	w0, #0x0                   	// #0
    1130:	17fffff0 	b	10f0 <test_vfork+0xf4>
  check(pid > 0 && waitchild(pid) == 5, "vfork(): child exit(5)");
    1134:	5400014d 	b.le	115c <test_vfork+0x160>
    1138:	97ffff48 	bl	e58 <waitchild>
    113c:	7100141f 	cmp	w0, #0x5
    1140:	1a9f17e0 	cset	w0, eq	// eq = none
    1144:	90000001 	adrp	x1, 1000 <test_vfork+0x4>
    1148:	91092021 	add	x1, x1, #0x248
    114c:	97ffff88 	bl	f6c <check>
}
    1150:	a94153f3 	ldp	x19, x20, [sp, #16]
    1154:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1158:	d65f03c0 	ret
  check(pid > 0 && waitchild(pid) == 5, "vfork(): child exit(5)");
    115c:	52800000 	mov	w0, #0x0                   	// #0
    1160:	17fffff9 	b	1144 <test_vfork+0x148>
