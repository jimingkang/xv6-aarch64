
user/_chrt:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000370 <.plt>:
 370:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 374:	b0000010 	adrp	x16, 1000 <show+0x840>
 378:	f9457211 	ldr	x17, [x16, #2784]
 37c:	912b8210 	add	x16, x16, #0xae0
 380:	d61f0220 	br	x17
 384:	d503201f 	nop
 388:	d503201f 	nop
 38c:	d503201f 	nop

0000000000000390 <printf@plt>:
 390:	b0000010 	adrp	x16, 1000 <show+0x840>
 394:	f9457611 	ldr	x17, [x16, #2792]
 398:	912ba210 	add	x16, x16, #0xae8
 39c:	d61f0220 	br	x17

00000000000003a0 <sched_setscheduler@plt>:
 3a0:	b0000010 	adrp	x16, 1000 <show+0x840>
 3a4:	f9457a11 	ldr	x17, [x16, #2800]
 3a8:	912bc210 	add	x16, x16, #0xaf0
 3ac:	d61f0220 	br	x17

00000000000003b0 <fprintf@plt>:
 3b0:	b0000010 	adrp	x16, 1000 <show+0x840>
 3b4:	f9457e11 	ldr	x17, [x16, #2808]
 3b8:	912be210 	add	x16, x16, #0xaf8
 3bc:	d61f0220 	br	x17

00000000000003c0 <exec@plt>:
 3c0:	b0000010 	adrp	x16, 1000 <show+0x840>
 3c4:	f9458211 	ldr	x17, [x16, #2816]
 3c8:	912c0210 	add	x16, x16, #0xb00
 3cc:	d61f0220 	br	x17

00000000000003d0 <sched_getinfo@plt>:
 3d0:	b0000010 	adrp	x16, 1000 <show+0x840>
 3d4:	f9458611 	ldr	x17, [x16, #2824]
 3d8:	912c2210 	add	x16, x16, #0xb08
 3dc:	d61f0220 	br	x17

00000000000003e0 <strcmp@plt>:
 3e0:	b0000010 	adrp	x16, 1000 <show+0x840>
 3e4:	f9458a11 	ldr	x17, [x16, #2832]
 3e8:	912c4210 	add	x16, x16, #0xb10
 3ec:	d61f0220 	br	x17

00000000000003f0 <exit@plt>:
 3f0:	b0000010 	adrp	x16, 1000 <show+0x840>
 3f4:	f9458e11 	ldr	x17, [x16, #2840]
 3f8:	912c6210 	add	x16, x16, #0xb18
 3fc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000400 <main>:
  printf("pid %d's current scheduling priority: %d\n", si.pid, si.priority);
}

int
main(int argc, char *argv[])
{
 400:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
 404:	910003fd 	mov	x29, sp
 408:	a90153f3 	stp	x19, x20, [sp, #16]
 40c:	aa0103f4 	mov	x20, x1
  int policy = SCHED_RR, pflag = 0, i = 1, prio, pid;

  for(; i < argc && argv[i][0] == '-'; i++){
 410:	d2800033 	mov	x19, #0x1                   	// #1
{
 414:	a90363f7 	stp	x23, x24, [sp, #48]
    if(strcmp(argv[i], "-f") == 0) policy = SCHED_FIFO;
 418:	90000018 	adrp	x24, 0 <.plt-0x370>
 41c:	9124e718 	add	x24, x24, #0x939
{
 420:	2a0003f7 	mov	w23, w0
 424:	a9046bf9 	stp	x25, x26, [sp, #64]
    else if(strcmp(argv[i], "-r") == 0) policy = SCHED_RR;
 428:	90000019 	adrp	x25, 0 <.plt-0x370>
 42c:	9124f339 	add	x25, x25, #0x93c
{
 430:	a9025bf5 	stp	x21, x22, [sp, #32]
  int policy = SCHED_RR, pflag = 0, i = 1, prio, pid;
 434:	52800016 	mov	w22, #0x0                   	// #0
 438:	52800055 	mov	w21, #0x2                   	// #2
  for(; i < argc && argv[i][0] == '-'; i++){
 43c:	6b1302ff 	cmp	w23, w19
 440:	540000ad 	b.le	454 <main+0x54>
 444:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
 448:	39400001 	ldrb	w1, [x0]
 44c:	7100b43f 	cmp	w1, #0x2d
 450:	540001c0 	b.eq	488 <main+0x88>  // b.none
    else if(strcmp(argv[i], "-o") == 0) policy = SCHED_OTHER;
    else if(strcmp(argv[i], "-p") == 0) pflag = 1;
    else usage();
  }

  if(pflag && argc - i == 1){                 // chrt -p PID
 454:	4b1302f7 	sub	w23, w23, w19
 458:	2a1303f3 	mov	w19, w19
 45c:	340004d6 	cbz	w22, 4f4 <main+0xf4>
 460:	710006ff 	cmp	w23, #0x1
 464:	54000481 	b.ne	4f4 <main+0xf4>  // b.any
    if(!parse_num(argv[i], &pid))
 468:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
 46c:	910183e1 	add	x1, sp, #0x60
 470:	94000090 	bl	6b0 <parse_num>
 474:	340002c0 	cbz	w0, 4cc <main+0xcc>
      usage();
    show(pid);
 478:	b94063e0 	ldr	w0, [sp, #96]
    if(sched_setscheduler(pid, policy, prio) < 0){
      fprintf(2, "chrt: failed to set pid %d to %s priority %d\n",
              pid, policy_name(policy), prio);
      exit(1);
    }
    show(pid);
 47c:	940000d1 	bl	7c0 <show>
    exit(0);
 480:	52800000 	mov	w0, #0x0                   	// #0
 484:	1400003f 	b	580 <main+0x180>
    if(strcmp(argv[i], "-f") == 0) policy = SCHED_FIFO;
 488:	aa1803e1 	mov	x1, x24
 48c:	97ffffd5 	bl	3e0 <strcmp@plt>
 490:	34000200 	cbz	w0, 4d0 <main+0xd0>
    else if(strcmp(argv[i], "-r") == 0) policy = SCHED_RR;
 494:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
 498:	aa1903e1 	mov	x1, x25
 49c:	97ffffd1 	bl	3e0 <strcmp@plt>
 4a0:	34000200 	cbz	w0, 4e0 <main+0xe0>
    else if(strcmp(argv[i], "-o") == 0) policy = SCHED_OTHER;
 4a4:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
 4a8:	90000001 	adrp	x1, 0 <.plt-0x370>
 4ac:	9124fc21 	add	x1, x1, #0x93f
 4b0:	97ffffcc 	bl	3e0 <strcmp@plt>
 4b4:	34000100 	cbz	w0, 4d4 <main+0xd4>
    else if(strcmp(argv[i], "-p") == 0) pflag = 1;
 4b8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
 4bc:	90000001 	adrp	x1, 0 <.plt-0x370>
 4c0:	91250821 	add	x1, x1, #0x942
 4c4:	97ffffc7 	bl	3e0 <strcmp@plt>
 4c8:	34000100 	cbz	w0, 4e8 <main+0xe8>
    else usage();
 4cc:	940000b5 	bl	7a0 <usage>
    if(strcmp(argv[i], "-f") == 0) policy = SCHED_FIFO;
 4d0:	52800020 	mov	w0, #0x1                   	// #1
  for(; i < argc && argv[i][0] == '-'; i++){
 4d4:	91000673 	add	x19, x19, #0x1
  int policy = SCHED_RR, pflag = 0, i = 1, prio, pid;
 4d8:	2a0003f5 	mov	w21, w0
 4dc:	17ffffd8 	b	43c <main+0x3c>
    else if(strcmp(argv[i], "-r") == 0) policy = SCHED_RR;
 4e0:	52800040 	mov	w0, #0x2                   	// #2
 4e4:	17fffffc 	b	4d4 <main+0xd4>
    else if(strcmp(argv[i], "-p") == 0) pflag = 1;
 4e8:	2a1503e0 	mov	w0, w21
 4ec:	52800036 	mov	w22, #0x1                   	// #1
 4f0:	17fffff9 	b	4d4 <main+0xd4>
  if(argc - i < 2 || !parse_num(argv[i], &prio))
 4f4:	710006ff 	cmp	w23, #0x1
 4f8:	54fffead 	b.le	4cc <main+0xcc>
 4fc:	d37df273 	lsl	x19, x19, #3
 500:	910173e1 	add	x1, sp, #0x5c
 504:	f8736a80 	ldr	x0, [x20, x19]
 508:	9400006a 	bl	6b0 <parse_num>
 50c:	2a0003f7 	mov	w23, w0
 510:	34fffde0 	cbz	w0, 4cc <main+0xcc>
  if(pflag){                                  // chrt -x -p PRIO PID
 514:	34000436 	cbz	w22, 598 <main+0x198>
    if(!parse_num(argv[i + 1], &pid))
 518:	8b130293 	add	x19, x20, x19
 51c:	910183e1 	add	x1, sp, #0x60
 520:	f9400660 	ldr	x0, [x19, #8]
 524:	94000063 	bl	6b0 <parse_num>
 528:	34fffd20 	cbz	w0, 4cc <main+0xcc>
    if(sched_setscheduler(pid, policy, prio) < 0){
 52c:	294bcff4 	ldp	w20, w19, [sp, #92]
 530:	2a1503e1 	mov	w1, w21
 534:	2a1403e2 	mov	w2, w20
 538:	2a1303e0 	mov	w0, w19
 53c:	97ffff99 	bl	3a0 <sched_setscheduler@plt>
 540:	36f80280 	tbz	w0, #31, 590 <main+0x190>
}

static __attribute__((unused)) const char *
policy_name(int policy)
{
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 544:	710006bf 	cmp	w21, #0x1
 548:	540001e0 	b.eq	584 <main+0x184>  // b.none
  if(policy == SCHED_RR) return "SCHED_RR";
  return "SCHED_OTHER";
 54c:	71000abf 	cmp	w21, #0x2
 550:	90000000 	adrp	x0, 0 <.plt-0x370>
 554:	9122dc00 	add	x0, x0, #0x8b7
 558:	90000003 	adrp	x3, 0 <.plt-0x370>
 55c:	91230c63 	add	x3, x3, #0x8c3
 560:	9a800063 	csel	x3, x3, x0, eq	// eq = none
      fprintf(2, "chrt: failed to set pid %d to %s priority %d\n",
 564:	90000001 	adrp	x1, 0 <.plt-0x370>
 568:	91251421 	add	x1, x1, #0x945
 56c:	2a1403e4 	mov	w4, w20
 570:	2a1303e2 	mov	w2, w19
 574:	52800040 	mov	w0, #0x2                   	// #2
 578:	97ffff8e 	bl	3b0 <fprintf@plt>
      exit(1);
 57c:	52800020 	mov	w0, #0x1                   	// #1
 580:	97ffff9c 	bl	3f0 <exit@plt>
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 584:	90000003 	adrp	x3, 0 <.plt-0x370>
 588:	9122b063 	add	x3, x3, #0x8ac
 58c:	17fffff6 	b	564 <main+0x164>
    show(pid);
 590:	2a1303e0 	mov	w0, w19
 594:	17ffffba 	b	47c <main+0x7c>
  }

  // chrt -x PRIO CMD ...: change ourselves, then exec (attributes survive exec).
  if(sched_setscheduler(0, policy, prio) < 0){
 598:	b9405ff8 	ldr	w24, [sp, #92]
 59c:	2a1503e1 	mov	w1, w21
 5a0:	52800000 	mov	w0, #0x0                   	// #0
 5a4:	2a1803e2 	mov	w2, w24
 5a8:	97ffff7e 	bl	3a0 <sched_setscheduler@plt>
 5ac:	36f80240 	tbz	w0, #31, 5f4 <main+0x1f4>
 5b0:	710006bf 	cmp	w21, #0x1
 5b4:	540001a0 	b.eq	5e8 <main+0x1e8>  // b.none
  return "SCHED_OTHER";
 5b8:	71000abf 	cmp	w21, #0x2
 5bc:	90000001 	adrp	x1, 0 <.plt-0x370>
 5c0:	9122dc21 	add	x1, x1, #0x8b7
 5c4:	90000000 	adrp	x0, 0 <.plt-0x370>
 5c8:	91230c00 	add	x0, x0, #0x8c3
 5cc:	9a810002 	csel	x2, x0, x1, eq	// eq = none
    fprintf(2, "chrt: invalid %s priority %d\n", policy_name(policy), prio);
 5d0:	2a1803e3 	mov	w3, w24
 5d4:	90000001 	adrp	x1, 0 <.plt-0x370>
 5d8:	9125cc21 	add	x1, x1, #0x973
 5dc:	52800040 	mov	w0, #0x2                   	// #2
 5e0:	97ffff74 	bl	3b0 <fprintf@plt>
    exit(1);
 5e4:	17ffffe6 	b	57c <main+0x17c>
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 5e8:	90000002 	adrp	x2, 0 <.plt-0x370>
 5ec:	9122b042 	add	x2, x2, #0x8ac
 5f0:	17fffff8 	b	5d0 <main+0x1d0>
  }
  exec_cmd(&argv[i + 1]);
 5f4:	91002273 	add	x19, x19, #0x8
 5f8:	8b130299 	add	x25, x20, x19
// exec() argv[0] the way sh does: as given if it has a '/', else /bin, then /.
static __attribute__((unused)) void
exec_cmd(char **argv)
{
  char path[64];
  char *name = argv[0];
 5fc:	f8736a98 	ldr	x24, [x20, x19]
  int n;

  for(char *c = name; *c; c++)
 600:	aa1803e0 	mov	x0, x24
 604:	39400001 	ldrb	w1, [x0]
 608:	350002e1 	cbnz	w1, 664 <main+0x264>
 60c:	90000002 	adrp	x2, 0 <.plt-0x370>
 610:	9124cc42 	add	x2, x2, #0x933
 614:	910183f5 	add	x21, sp, #0x60
    if(*c == '/'){
      exec(name, argv);
      return;
    }
  for(int pass = 0; pass < 2; pass++){
    const char *prefix = pass == 0 ? "/bin/" : "/";
 618:	9000001a 	adrp	x26, 0 <.plt-0x370>
    n = 0;
    for(const char *c = prefix; *c; c++)
 61c:	d2800000 	mov	x0, #0x0                   	// #0
 620:	38606841 	ldrb	w1, [x2, x0]
 624:	350003a1 	cbnz	w1, 698 <main+0x298>
 628:	2a0003e2 	mov	w2, w0
      path[n++] = *c;
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 62c:	cb204300 	sub	x0, x24, w0, uxtw
 630:	38626801 	ldrb	w1, [x0, x2]
 634:	34000061 	cbz	w1, 640 <main+0x240>
 638:	7100f85f 	cmp	w2, #0x3e
 63c:	5400034d 	b.le	6a4 <main+0x2a4>
      path[n++] = *c;
    path[n] = 0;
 640:	38224abf 	strb	wzr, [x21, w2, uxtw]
    exec(path, argv);
 644:	aa1903e1 	mov	x1, x25
 648:	aa1503e0 	mov	x0, x21
 64c:	97ffff5d 	bl	3c0 <exec@plt>
    const char *prefix = pass == 0 ? "/bin/" : "/";
 650:	9124df42 	add	x2, x26, #0x937
  for(int pass = 0; pass < 2; pass++){
 654:	710006df 	cmp	w22, #0x1
 658:	54000100 	b.eq	678 <main+0x278>  // b.none
 65c:	2a1703f6 	mov	w22, w23
 660:	17ffffef 	b	61c <main+0x21c>
    if(*c == '/'){
 664:	7100bc3f 	cmp	w1, #0x2f
 668:	54000141 	b.ne	690 <main+0x290>  // b.any
      exec(name, argv);
 66c:	aa1903e1 	mov	x1, x25
 670:	aa1803e0 	mov	x0, x24
 674:	97ffff53 	bl	3c0 <exec@plt>
  fprintf(2, "chrt: exec %s failed\n", argv[i + 1]);
 678:	f8736a82 	ldr	x2, [x20, x19]
 67c:	90000001 	adrp	x1, 0 <.plt-0x370>
 680:	91264421 	add	x1, x1, #0x991
 684:	52800040 	mov	w0, #0x2                   	// #2
 688:	97ffff4a 	bl	3b0 <fprintf@plt>
  exit(1);
 68c:	17ffffbc 	b	57c <main+0x17c>
  for(char *c = name; *c; c++)
 690:	91000400 	add	x0, x0, #0x1
 694:	17ffffdc 	b	604 <main+0x204>
      path[n++] = *c;
 698:	38206aa1 	strb	w1, [x21, x0]
    for(const char *c = prefix; *c; c++)
 69c:	91000400 	add	x0, x0, #0x1
 6a0:	17ffffe0 	b	620 <main+0x220>
      path[n++] = *c;
 6a4:	38226aa1 	strb	w1, [x21, x2]
    for(char *c = name; *c && n < (int)sizeof(path) - 1; c++)
 6a8:	91000442 	add	x2, x2, #0x1
 6ac:	17ffffe1 	b	630 <main+0x230>

00000000000006b0 <parse_num>:
{
 6b0:	aa0003e2 	mov	x2, x0
  if(*s == '-'){
 6b4:	39400000 	ldrb	w0, [x0]
 6b8:	7100b41f 	cmp	w0, #0x2d
 6bc:	540002c1 	b.ne	714 <parse_num+0x64>  // b.any
    s++;
 6c0:	91000442 	add	x2, x2, #0x1
    neg = 1;
 6c4:	52800025 	mov	w5, #0x1                   	// #1
  if(s[0] == '0' && (s[1] == 'x' || s[1] == 'X')){
 6c8:	39400040 	ldrb	w0, [x2]
 6cc:	7100c01f 	cmp	w0, #0x30
 6d0:	540000c1 	b.ne	6e8 <parse_num+0x38>  // b.any
 6d4:	39400440 	ldrb	w0, [x2, #1]
 6d8:	121a7800 	and	w0, w0, #0xffffffdf
 6dc:	12001c00 	and	w0, w0, #0xff
 6e0:	7101601f 	cmp	w0, #0x58
 6e4:	540001c0 	b.eq	71c <parse_num+0x6c>  // b.none
 6e8:	52800000 	mov	w0, #0x0                   	// #0
 6ec:	52800003 	mov	w3, #0x0                   	// #0
      v = v * 10 + (*s - '0');
 6f0:	52800146 	mov	w6, #0xa                   	// #10
    for(; *s; s++, any = 1){
 6f4:	39400044 	ldrb	w4, [x2]
 6f8:	340001c4 	cbz	w4, 730 <parse_num+0x80>
      if(*s < '0' || *s > '9')
 6fc:	5100c084 	sub	w4, w4, #0x30
 700:	12001c80 	and	w0, w4, #0xff
 704:	7100241f 	cmp	w0, #0x9
 708:	54000449 	b.ls	790 <parse_num+0xe0>  // b.plast
      else return 0;
 70c:	52800000 	mov	w0, #0x0                   	// #0
}
 710:	d65f03c0 	ret
  int neg = 0, v = 0, any = 0;
 714:	52800005 	mov	w5, #0x0                   	// #0
 718:	17ffffec 	b	6c8 <parse_num+0x18>
    for(s += 2; *s; s++, any = 1){
 71c:	91000842 	add	x2, x2, #0x2
  int neg = 0, v = 0, any = 0;
 720:	52800000 	mov	w0, #0x0                   	// #0
 724:	52800003 	mov	w3, #0x0                   	// #0
    for(s += 2; *s; s++, any = 1){
 728:	39400044 	ldrb	w4, [x2]
 72c:	350000c4 	cbnz	w4, 744 <parse_num+0x94>
  if(!any)
 730:	34ffff00 	cbz	w0, 710 <parse_num+0x60>
  *out = neg ? -v : v;
 734:	710000bf 	cmp	w5, #0x0
 738:	5a830463 	cneg	w3, w3, ne	// ne = any
 73c:	b9000023 	str	w3, [x1]
  return 1;
 740:	17fffff4 	b	710 <parse_num+0x60>
      if(*s >= '0' && *s <= '9') d = *s - '0';
 744:	5100c080 	sub	w0, w4, #0x30
 748:	12001c06 	and	w6, w0, #0xff
 74c:	710024df 	cmp	w6, #0x9
 750:	540000c9 	b.ls	768 <parse_num+0xb8>  // b.plast
      else if(*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
 754:	51018480 	sub	w0, w4, #0x61
 758:	12001c00 	and	w0, w0, #0xff
 75c:	7100141f 	cmp	w0, #0x5
 760:	540000c8 	b.hi	778 <parse_num+0xc8>  // b.pmore
 764:	51015c80 	sub	w0, w4, #0x57
      v = v * 16 + d;
 768:	0b031003 	add	w3, w0, w3, lsl #4
    for(s += 2; *s; s++, any = 1){
 76c:	91000442 	add	x2, x2, #0x1
 770:	52800020 	mov	w0, #0x1                   	// #1
 774:	17ffffed 	b	728 <parse_num+0x78>
      else if(*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
 778:	51010480 	sub	w0, w4, #0x41
 77c:	12001c00 	and	w0, w0, #0xff
 780:	7100141f 	cmp	w0, #0x5
 784:	54fffc48 	b.hi	70c <parse_num+0x5c>  // b.pmore
 788:	5100dc80 	sub	w0, w4, #0x37
 78c:	17fffff7 	b	768 <parse_num+0xb8>
      v = v * 10 + (*s - '0');
 790:	1b061063 	madd	w3, w3, w6, w4
    for(; *s; s++, any = 1){
 794:	91000442 	add	x2, x2, #0x1
 798:	52800020 	mov	w0, #0x1                   	// #1
 79c:	17ffffd6 	b	6f4 <parse_num+0x44>

00000000000007a0 <usage>:
{
 7a0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  fprintf(2, "usage: chrt -p PID\n"
 7a4:	90000001 	adrp	x1, 0 <.plt-0x370>
 7a8:	91213021 	add	x1, x1, #0x84c
{
 7ac:	910003fd 	mov	x29, sp
  fprintf(2, "usage: chrt -p PID\n"
 7b0:	52800040 	mov	w0, #0x2                   	// #2
 7b4:	97fffeff 	bl	3b0 <fprintf@plt>
  exit(1);
 7b8:	52800020 	mov	w0, #0x1                   	// #1
 7bc:	97ffff0d 	bl	3f0 <exit@plt>

00000000000007c0 <show>:
{
 7c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
 7c4:	910003fd 	mov	x29, sp
  if(sched_getinfo(pid, &si) < 0){
 7c8:	9100a3e1 	add	x1, sp, #0x28
{
 7cc:	b9001fe0 	str	w0, [sp, #28]
  if(sched_getinfo(pid, &si) < 0){
 7d0:	97ffff00 	bl	3d0 <sched_getinfo@plt>
 7d4:	b9401fe2 	ldr	w2, [sp, #28]
 7d8:	36f800e0 	tbz	w0, #31, 7f4 <show+0x34>
    fprintf(2, "chrt: no process %d\n", pid);
 7dc:	90000001 	adrp	x1, 0 <.plt-0x370>
 7e0:	91233021 	add	x1, x1, #0x8cc
 7e4:	52800040 	mov	w0, #0x2                   	// #2
 7e8:	97fffef2 	bl	3b0 <fprintf@plt>
    exit(1);
 7ec:	52800020 	mov	w0, #0x1                   	// #1
 7f0:	97ffff00 	bl	3f0 <exit@plt>
  printf("pid %d's current scheduling policy: %s\n", si.pid,
 7f4:	29450fe1 	ldp	w1, w3, [sp, #40]
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 7f8:	7100047f 	cmp	w3, #0x1
 7fc:	54000220 	b.eq	840 <show+0x80>  // b.none
  return "SCHED_OTHER";
 800:	7100087f 	cmp	w3, #0x2
 804:	90000000 	adrp	x0, 0 <.plt-0x370>
 808:	9122dc00 	add	x0, x0, #0x8b7
 80c:	90000002 	adrp	x2, 0 <.plt-0x370>
 810:	91230c42 	add	x2, x2, #0x8c3
 814:	9a800042 	csel	x2, x2, x0, eq	// eq = none
 818:	90000000 	adrp	x0, 0 <.plt-0x370>
 81c:	91238400 	add	x0, x0, #0x8e1
 820:	97fffedc 	bl	390 <printf@plt>
  printf("pid %d's current scheduling priority: %d\n", si.pid, si.priority);
 824:	b9402be1 	ldr	w1, [sp, #40]
 828:	90000000 	adrp	x0, 0 <.plt-0x370>
 82c:	91242400 	add	x0, x0, #0x909
 830:	b94033e2 	ldr	w2, [sp, #48]
 834:	97fffed7 	bl	390 <printf@plt>
}
 838:	a8c57bfd 	ldp	x29, x30, [sp], #80
 83c:	d65f03c0 	ret
  if(policy == SCHED_FIFO) return "SCHED_FIFO";
 840:	90000002 	adrp	x2, 0 <.plt-0x370>
 844:	9122b042 	add	x2, x2, #0x8ac
 848:	17fffff4 	b	818 <show+0x58>
