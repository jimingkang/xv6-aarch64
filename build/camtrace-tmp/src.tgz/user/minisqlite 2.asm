
user/_minisqlite:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000500 <.plt>:
 500:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 504:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 508:	f945f211 	ldr	x17, [x16, #3040]
 50c:	912f8210 	add	x16, x16, #0xbe0
 510:	d61f0220 	br	x17
 514:	d503201f 	nop
 518:	d503201f 	nop
 51c:	d503201f 	nop

0000000000000520 <printf@plt>:
 520:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 524:	f945f611 	ldr	x17, [x16, #3048]
 528:	912fa210 	add	x16, x16, #0xbe8
 52c:	d61f0220 	br	x17

0000000000000530 <memcpy@plt>:
 530:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 534:	f945fa11 	ldr	x17, [x16, #3056]
 538:	912fc210 	add	x16, x16, #0xbf0
 53c:	d61f0220 	br	x17

0000000000000540 <ftruncate@plt>:
 540:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 544:	f945fe11 	ldr	x17, [x16, #3064]
 548:	912fe210 	add	x16, x16, #0xbf8
 54c:	d61f0220 	br	x17

0000000000000550 <memset@plt>:
 550:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 554:	f9460211 	ldr	x17, [x16, #3072]
 558:	91300210 	add	x16, x16, #0xc00
 55c:	d61f0220 	br	x17

0000000000000560 <strcmp@plt>:
 560:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 564:	f9460611 	ldr	x17, [x16, #3080]
 568:	91302210 	add	x16, x16, #0xc08
 56c:	d61f0220 	br	x17

0000000000000570 <fsync@plt>:
 570:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 574:	f9460a11 	ldr	x17, [x16, #3088]
 578:	91304210 	add	x16, x16, #0xc10
 57c:	d61f0220 	br	x17

0000000000000580 <pread@plt>:
 580:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 584:	f9460e11 	ldr	x17, [x16, #3096]
 588:	91306210 	add	x16, x16, #0xc18
 58c:	d61f0220 	br	x17

0000000000000590 <clock_us@plt>:
 590:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 594:	f9461211 	ldr	x17, [x16, #3104]
 598:	91308210 	add	x16, x16, #0xc20
 59c:	d61f0220 	br	x17

00000000000005a0 <exit@plt>:
 5a0:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 5a4:	f9461611 	ldr	x17, [x16, #3112]
 5a8:	9130a210 	add	x16, x16, #0xc28
 5ac:	d61f0220 	br	x17

00000000000005b0 <atoi@plt>:
 5b0:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 5b4:	f9461a11 	ldr	x17, [x16, #3120]
 5b8:	9130c210 	add	x16, x16, #0xc30
 5bc:	d61f0220 	br	x17

00000000000005c0 <open@plt>:
 5c0:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 5c4:	f9461e11 	ldr	x17, [x16, #3128]
 5c8:	9130e210 	add	x16, x16, #0xc38
 5cc:	d61f0220 	br	x17

00000000000005d0 <mkdir@plt>:
 5d0:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 5d4:	f9462211 	ldr	x17, [x16, #3136]
 5d8:	91310210 	add	x16, x16, #0xc40
 5dc:	d61f0220 	br	x17

00000000000005e0 <pwrite@plt>:
 5e0:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 5e4:	f9462611 	ldr	x17, [x16, #3144]
 5e8:	91312210 	add	x16, x16, #0xc48
 5ec:	d61f0220 	br	x17

00000000000005f0 <close@plt>:
 5f0:	d0000010 	adrp	x16, 2000 <get_value.constprop.0+0x9d4>
 5f4:	f9462a11 	ldr	x17, [x16, #3152]
 5f8:	91314210 	add	x16, x16, #0xc50
 5fc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000600 <main>:
  printf("                  recover|prepare KEY VALUE|stress [OPERATIONS]\n");
}

int
main(int argc, char **argv)
{
     600:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
     604:	910003fd 	mov	x29, sp
     608:	a90153f3 	stp	x19, x20, [sp, #16]
     60c:	a9025bf5 	stp	x21, x22, [sp, #32]
     610:	a90363f7 	stp	x23, x24, [sp, #48]
     614:	a9046bf9 	stp	x25, x26, [sp, #64]
     618:	a90573fb 	stp	x27, x28, [sp, #80]
  if(argc < 2){
     61c:	7100041f 	cmp	w0, #0x1
     620:	5400008c 	b.gt	630 <main+0x30>
    usage();
     624:	94000157 	bl	b80 <usage>
    exit(1);
     628:	52800020 	mov	w0, #0x1                   	// #1
    r = put_value((uint32)atoi(argv[2]), (uint64)atoi(argv[3]), 1);
  else if(strcmp(argv[1], "stress") == 0)
    r = stress_test(argc == 3 ? (uint)atoi(argv[2]) : 1000);
  else
    usage();
  exit(r < 0);
     62c:	97ffffdd 	bl	5a0 <exit@plt>
     630:	aa0103f4 	mov	x20, x1
  if(strcmp(argv[1], "init") == 0)
     634:	2a0003f3 	mov	w19, w0
     638:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     63c:	9125a421 	add	x1, x1, #0x969
     640:	f9400680 	ldr	x0, [x20, #8]
     644:	97ffffc7 	bl	560 <strcmp@plt>
     648:	35000080 	cbnz	w0, 658 <main+0x58>
    r = initialize();
     64c:	94000246 	bl	f64 <initialize>
    if(r == 0) r = scan_db(0);
     650:	2a0003f3 	mov	w19, w0
     654:	1400001d 	b	6c8 <main+0xc8>
  else if((strcmp(argv[1], "put") == 0 || strcmp(argv[1], "insert") == 0) && argc == 4){
     658:	f9400680 	ldr	x0, [x20, #8]
     65c:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     660:	9125b821 	add	x1, x1, #0x96e
     664:	97ffffbf 	bl	560 <strcmp@plt>
     668:	35000360 	cbnz	w0, 6d4 <main+0xd4>
     66c:	7100127f 	cmp	w19, #0x4
     670:	540003c1 	b.ne	6e8 <main+0xe8>  // b.any
    r = put_value((uint32)atoi(argv[2]), (uint64)atoi(argv[3]), 0);
     674:	f9400a80 	ldr	x0, [x20, #16]
     678:	97ffffce 	bl	5b0 <atoi@plt>
     67c:	2a0003f3 	mov	w19, w0
     680:	f9400e80 	ldr	x0, [x20, #24]
     684:	97ffffcb 	bl	5b0 <atoi@plt>
     688:	93407c01 	sxtw	x1, w0
     68c:	52800002 	mov	w2, #0x0                   	// #0
     690:	2a1303e0 	mov	w0, w19
     694:	94000339 	bl	1378 <put_value>
     698:	2a0003f3 	mov	w19, w0
    if(r == 0) printf("minisqlite: put key=%d value=%d\n", atoi(argv[2]), atoi(argv[3]));
     69c:	35000a00 	cbnz	w0, 7dc <main+0x1dc>
     6a0:	f9400a80 	ldr	x0, [x20, #16]
     6a4:	97ffffc3 	bl	5b0 <atoi@plt>
     6a8:	2a0003f5 	mov	w21, w0
     6ac:	f9400e80 	ldr	x0, [x20, #24]
     6b0:	97ffffc0 	bl	5b0 <atoi@plt>
     6b4:	2a0003e2 	mov	w2, w0
     6b8:	2a1503e1 	mov	w1, w21
     6bc:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     6c0:	9125e400 	add	x0, x0, #0x979
     6c4:	97ffff97 	bl	520 <printf@plt>
  exit(r < 0);
     6c8:	3100067f 	cmn	w19, #0x1
     6cc:	1a9f17e0 	cset	w0, eq	// eq = none
     6d0:	17ffffd7 	b	62c <main+0x2c>
  else if((strcmp(argv[1], "put") == 0 || strcmp(argv[1], "insert") == 0) && argc == 4){
     6d4:	f9400680 	ldr	x0, [x20, #8]
     6d8:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     6dc:	9125c821 	add	x1, x1, #0x972
     6e0:	97ffffa0 	bl	560 <strcmp@plt>
     6e4:	34fffc40 	cbz	w0, 66c <main+0x6c>
  } else if((strcmp(argv[1], "get") == 0 || strcmp(argv[1], "select") == 0) &&
     6e8:	f9400680 	ldr	x0, [x20, #8]
     6ec:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     6f0:	91266821 	add	x1, x1, #0x99a
     6f4:	97ffff9b 	bl	560 <strcmp@plt>
     6f8:	350002e0 	cbnz	w0, 754 <main+0x154>
     6fc:	71000e7f 	cmp	w19, #0x3
     700:	54000341 	b.ne	768 <main+0x168>  // b.any
            argc == 3 && strcmp(argv[2], "all") != 0){
     704:	f9400a80 	ldr	x0, [x20, #16]
     708:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     70c:	91269421 	add	x1, x1, #0x9a5
     710:	97ffff94 	bl	560 <strcmp@plt>
     714:	340002a0 	cbz	w0, 768 <main+0x168>
    r = get_value((uint32)atoi(argv[2]), &value);
     718:	f9400a80 	ldr	x0, [x20, #16]
    uint64 value = 0;
     71c:	f9003fff 	str	xzr, [sp, #120]
    r = get_value((uint32)atoi(argv[2]), &value);
     720:	97ffffa4 	bl	5b0 <atoi@plt>
     724:	9101e3e1 	add	x1, sp, #0x78
     728:	940003c1 	bl	162c <get_value.constprop.0>
     72c:	2a0003f3 	mov	w19, w0
    if(r == 0) printf("minisqlite: key=%d value=%l\n", atoi(argv[2]), value);
     730:	35000420 	cbnz	w0, 7b4 <main+0x1b4>
     734:	f9400a80 	ldr	x0, [x20, #16]
     738:	97ffff9e 	bl	5b0 <atoi@plt>
     73c:	2a0003e1 	mov	w1, w0
     740:	f9403fe2 	ldr	x2, [sp, #120]
     744:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     748:	9126a400 	add	x0, x0, #0x9a9
     74c:	97ffff75 	bl	520 <printf@plt>
     750:	17ffffde 	b	6c8 <main+0xc8>
  } else if((strcmp(argv[1], "get") == 0 || strcmp(argv[1], "select") == 0) &&
     754:	f9400680 	ldr	x0, [x20, #8]
     758:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     75c:	91267821 	add	x1, x1, #0x99e
     760:	97ffff80 	bl	560 <strcmp@plt>
     764:	34fffcc0 	cbz	w0, 6fc <main+0xfc>
  } else if(strcmp(argv[1], "delete") == 0 && argc == 3){
     768:	f9400680 	ldr	x0, [x20, #8]
     76c:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     770:	91279021 	add	x1, x1, #0x9e4
     774:	97ffff7b 	bl	560 <strcmp@plt>
     778:	35000360 	cbnz	w0, 7e4 <main+0x1e4>
     77c:	71000e7f 	cmp	w19, #0x3
     780:	54000321 	b.ne	7e4 <main+0x1e4>  // b.any
    r = delete_key((uint32)atoi(argv[2]));
     784:	f9400a80 	ldr	x0, [x20, #16]
     788:	97ffff8a 	bl	5b0 <atoi@plt>
     78c:	940002b7 	bl	1268 <delete_key>
     790:	2a0003f3 	mov	w19, w0
    if(r == 0) printf("minisqlite: deleted key=%d\n", atoi(argv[2]));
     794:	35000200 	cbnz	w0, 7d4 <main+0x1d4>
     798:	f9400a80 	ldr	x0, [x20, #16]
     79c:	97ffff85 	bl	5b0 <atoi@plt>
     7a0:	2a0003e1 	mov	w1, w0
     7a4:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     7a8:	9127ac00 	add	x0, x0, #0x9eb
    else if(r == 1) printf("minisqlite: key=%d not found\n", atoi(argv[2]));
     7ac:	97ffff5d 	bl	520 <printf@plt>
     7b0:	17ffffc6 	b	6c8 <main+0xc8>
    else if(r == 1) printf("minisqlite: key=%d not found\n", atoi(argv[2]));
     7b4:	7100041f 	cmp	w0, #0x1
     7b8:	54fff881 	b.ne	6c8 <main+0xc8>  // b.any
    else if(r == 1) printf("minisqlite: key=%d not found\n", atoi(argv[2]));
     7bc:	f9400a80 	ldr	x0, [x20, #16]
     7c0:	97ffff7c 	bl	5b0 <atoi@plt>
     7c4:	2a0003e1 	mov	w1, w0
     7c8:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     7cc:	91271800 	add	x0, x0, #0x9c6
     7d0:	17fffff7 	b	7ac <main+0x1ac>
     7d4:	7100041f 	cmp	w0, #0x1
     7d8:	54ffff20 	b.eq	7bc <main+0x1bc>  // b.none
    r = delete_key((uint32)atoi(argv[2]));
     7dc:	12800013 	mov	w19, #0xffffffff            	// #-1
     7e0:	17ffffba 	b	6c8 <main+0xc8>
  } else if(strcmp(argv[1], "scan") == 0 ||
     7e4:	f9400680 	ldr	x0, [x20, #8]
     7e8:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     7ec:	91281c21 	add	x1, x1, #0xa07
     7f0:	97ffff5c 	bl	560 <strcmp@plt>
     7f4:	35000080 	cbnz	w0, 804 <main+0x204>
    r = scan_db(1);
     7f8:	52800020 	mov	w0, #0x1                   	// #1
    if(r == 0) r = scan_db(0);
     7fc:	94000323 	bl	1488 <scan_db>
     800:	17ffff94 	b	650 <main+0x50>
            (strcmp(argv[1], "select") == 0 && argc == 3 && strcmp(argv[2], "all") == 0))
     804:	f9400680 	ldr	x0, [x20, #8]
     808:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     80c:	91267821 	add	x1, x1, #0x99e
     810:	97ffff54 	bl	560 <strcmp@plt>
  } else if(strcmp(argv[1], "scan") == 0 ||
     814:	35000100 	cbnz	w0, 834 <main+0x234>
            (strcmp(argv[1], "select") == 0 && argc == 3 && strcmp(argv[2], "all") == 0))
     818:	71000e7f 	cmp	w19, #0x3
     81c:	540000c1 	b.ne	834 <main+0x234>  // b.any
     820:	f9400a80 	ldr	x0, [x20, #16]
     824:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     828:	91269421 	add	x1, x1, #0x9a5
     82c:	97ffff4d 	bl	560 <strcmp@plt>
     830:	34fffe40 	cbz	w0, 7f8 <main+0x1f8>
  else if(strcmp(argv[1], "check") == 0)
     834:	f9400680 	ldr	x0, [x20, #8]
     838:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     83c:	91283021 	add	x1, x1, #0xa0c
     840:	97ffff48 	bl	560 <strcmp@plt>
     844:	34fffdc0 	cbz	w0, 7fc <main+0x1fc>
  else if(strcmp(argv[1], "recover") == 0){
     848:	f9400680 	ldr	x0, [x20, #8]
     84c:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     850:	91284821 	add	x1, x1, #0xa12
     854:	97ffff43 	bl	560 <strcmp@plt>
     858:	350000a0 	cbnz	w0, 86c <main+0x26c>
    r = recover_db(1);
     85c:	52800020 	mov	w0, #0x1                   	// #1
     860:	94000208 	bl	1080 <recover_db>
    if(r == 0) r = scan_db(0);
     864:	35fffbc0 	cbnz	w0, 7dc <main+0x1dc>
     868:	17ffffe5 	b	7fc <main+0x1fc>
  } else if(strcmp(argv[1], "prepare") == 0 && argc == 4)
     86c:	f9400680 	ldr	x0, [x20, #8]
     870:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     874:	91286821 	add	x1, x1, #0xa1a
     878:	97ffff3a 	bl	560 <strcmp@plt>
     87c:	350001a0 	cbnz	w0, 8b0 <main+0x2b0>
     880:	7100127f 	cmp	w19, #0x4
     884:	54000161 	b.ne	8b0 <main+0x2b0>  // b.any
    r = put_value((uint32)atoi(argv[2]), (uint64)atoi(argv[3]), 1);
     888:	f9400a80 	ldr	x0, [x20, #16]
     88c:	97ffff49 	bl	5b0 <atoi@plt>
     890:	2a0003f3 	mov	w19, w0
     894:	f9400e80 	ldr	x0, [x20, #24]
     898:	97ffff46 	bl	5b0 <atoi@plt>
     89c:	93407c01 	sxtw	x1, w0
     8a0:	52800022 	mov	w2, #0x1                   	// #1
     8a4:	2a1303e0 	mov	w0, w19
     8a8:	940002b4 	bl	1378 <put_value>
     8ac:	17ffff69 	b	650 <main+0x50>
  else if(strcmp(argv[1], "stress") == 0)
     8b0:	f9400680 	ldr	x0, [x20, #8]
     8b4:	b0000001 	adrp	x1, 1000 <initialize+0x9c>
     8b8:	91288821 	add	x1, x1, #0xa22
     8bc:	97ffff29 	bl	560 <strcmp@plt>
     8c0:	350010e0 	cbnz	w0, adc <main+0x4dc>
    r = stress_test(argc == 3 ? (uint)atoi(argv[2]) : 1000);
     8c4:	71000e7f 	cmp	w19, #0x3
     8c8:	54000c01 	b.ne	a48 <main+0x448>  // b.any
     8cc:	f9400a80 	ldr	x0, [x20, #16]
     8d0:	97ffff38 	bl	5b0 <atoi@plt>
    operations = 1000;
     8d4:	7100001f 	cmp	w0, #0x0
     8d8:	52807d01 	mov	w1, #0x3e8                 	// #1000
     8dc:	1a811015 	csel	w21, w0, w1, ne	// ne = any
  if(initialize() < 0)
     8e0:	940001a1 	bl	f64 <initialize>
     8e4:	2a0003f3 	mov	w19, w0
     8e8:	3100041f 	cmn	w0, #0x1
     8ec:	54ffeee0 	b.eq	6c8 <main+0xc8>  // b.none
  memset(expected_valid, 0, sizeof(expected_valid));
     8f0:	d0000013 	adrp	x19, 2000 <get_value.constprop.0+0x9d4>
     8f4:	91316273 	add	x19, x19, #0xc58
     8f8:	52804002 	mov	w2, #0x200                 	// #512
     8fc:	52800001 	mov	w1, #0x0                   	// #0
     900:	91010260 	add	x0, x19, #0x40
     904:	97ffff13 	bl	550 <memset@plt>
  memset(expected_value, 0, sizeof(expected_value));
     908:	52820002 	mov	w2, #0x1000                	// #4096
     90c:	52800001 	mov	w1, #0x0                   	// #0
     910:	d0000016 	adrp	x22, 2000 <get_value.constprop.0+0x9d4>
     914:	913a62d6 	add	x22, x22, #0xe98
     918:	aa1603e0 	mov	x0, x22
     91c:	97ffff0d 	bl	550 <memset@plt>
  uint64 start = clock_us();
     920:	97ffff1c 	bl	590 <clock_us@plt>
  uint32 rnd = 0x76015647U;
     924:	528ac8fb 	mov	w27, #0x5647                	// #22087
     928:	72aec03b 	movk	w27, #0x7601, lsl #16
  *state = *state * 1664525U + 1013904223U;
     92c:	528cc1b9 	mov	w25, #0x660d                	// #26125
     930:	72a00339 	movk	w25, #0x19, lsl #16
     934:	529e6bfa 	mov	w26, #0xf35f                	// #62303
     938:	72a78dda 	movk	w26, #0x3c6e, lsl #16
  uint64 start = clock_us();
     93c:	d2800017 	mov	x23, #0x0                   	// #0
    uint op = (r >> 16) % 10;
     940:	5280015c 	mov	w28, #0xa                   	// #10
  uint64 start = clock_us();
     944:	f90037e0 	str	x0, [sp, #104]
      printf("minisqlite: stress %d/%d transactions\n", i + 1, operations);
     948:	b0000018 	adrp	x24, 1000 <initialize+0x9c>
     94c:	9128a700 	add	x0, x24, #0xa29
     950:	f90033e0 	str	x0, [sp, #96]
  *state = *state * 1664525U + 1013904223U;
     954:	1b196b7b 	madd	w27, w27, w25, w26
    uint32 key = r % 512;
     958:	92402374 	and	x20, x27, #0x1ff
    uint op = (r >> 16) % 10;
     95c:	53107f61 	lsr	w1, w27, #16
     960:	1adc0820 	udiv	w0, w1, w28
     964:	1b1c8400 	msub	w0, w0, w28, w1
    if(op < 7){
     968:	7100181f 	cmp	w0, #0x6
     96c:	54000728 	b.hi	a50 <main+0x450>  // b.pmore
  *state = *state * 1664525U + 1013904223U;
     970:	1b196b61 	madd	w1, w27, w25, w26
      if(put_value(key, value, 0) < 0)
     974:	2a1403e0 	mov	w0, w20
     978:	52800002 	mov	w2, #0x0                   	// #0
  *state = *state * 1664525U + 1013904223U;
     97c:	aa0103fb 	mov	x27, x1
      uint64 value = ((uint64)i << 32) | next_random(&rnd);
     980:	aa178038 	orr	x24, x1, x23, lsl #32
      if(put_value(key, value, 0) < 0)
     984:	aa1803e1 	mov	x1, x24
     988:	9400027c 	bl	1378 <put_value>
     98c:	3100041f 	cmn	w0, #0x1
     990:	540007e0 	b.eq	a8c <main+0x48c>  // b.none
      expected_valid[key] = 1;
     994:	91010260 	add	x0, x19, #0x40
     998:	52800022 	mov	w2, #0x1                   	// #1
      expected_value[key] = value;
     99c:	f8347ad8 	str	x24, [x22, x20, lsl #3]
      expected_valid[key] = 1;
     9a0:	38346802 	strb	w2, [x0, x20]
    if((i + 1) % 100 == 0)
     9a4:	110006e1 	add	w1, w23, #0x1
     9a8:	52800c82 	mov	w2, #0x64                  	// #100
     9ac:	1ac20820 	udiv	w0, w1, w2
     9b0:	1b028400 	msub	w0, w0, w2, w1
     9b4:	35000080 	cbnz	w0, 9c4 <main+0x3c4>
      printf("minisqlite: stress %d/%d transactions\n", i + 1, operations);
     9b8:	f94033e0 	ldr	x0, [sp, #96]
     9bc:	2a1503e2 	mov	w2, w21
     9c0:	97fffed8 	bl	520 <printf@plt>
  for(uint i = 0; i < operations; i++){
     9c4:	910006f7 	add	x23, x23, #0x1
     9c8:	6b1702bf 	cmp	w21, w23
     9cc:	54fffc48 	b.hi	954 <main+0x354>  // b.pmore
    if((expected_valid[key] && (got != 0 || value != expected_value[key])) ||
     9d0:	91010273 	add	x19, x19, #0x40
  for(uint i = 0; i < operations; i++){
     9d4:	d2800014 	mov	x20, #0x0                   	// #0
    int got = get_value(key, &value);
     9d8:	9101e3e1 	add	x1, sp, #0x78
     9dc:	2a1403e0 	mov	w0, w20
    uint64 value = 0;
     9e0:	f9003fff 	str	xzr, [sp, #120]
    int got = get_value(key, &value);
     9e4:	94000312 	bl	162c <get_value.constprop.0>
    if((expected_valid[key] && (got != 0 || value != expected_value[key])) ||
     9e8:	38736a81 	ldrb	w1, [x20, x19]
     9ec:	34000741 	cbz	w1, ad4 <main+0x4d4>
     9f0:	350004e0 	cbnz	w0, a8c <main+0x48c>
     9f4:	f8747ac1 	ldr	x1, [x22, x20, lsl #3]
     9f8:	f9403fe0 	ldr	x0, [sp, #120]
     9fc:	eb00003f 	cmp	x1, x0
       (!expected_valid[key] && got != 1))
     a00:	54000461 	b.ne	a8c <main+0x48c>  // b.any
  for(uint key = 0; key < 512; key++){
     a04:	91000694 	add	x20, x20, #0x1
     a08:	f108029f 	cmp	x20, #0x200
     a0c:	54fffe61 	b.ne	9d8 <main+0x3d8>  // b.any
  if(scan_db(0) < 0)
     a10:	52800000 	mov	w0, #0x0                   	// #0
     a14:	9400029d 	bl	1488 <scan_db>
     a18:	3100041f 	cmn	w0, #0x1
     a1c:	54000380 	b.eq	a8c <main+0x48c>  // b.none
  uint64 elapsed = clock_us() - start;
     a20:	97fffedc 	bl	590 <clock_us@plt>
     a24:	aa0003e2 	mov	x2, x0
  printf("minisqlite: PASS %d transactions in %l us\n", operations, elapsed);
     a28:	f94037e1 	ldr	x1, [sp, #104]
     a2c:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     a30:	91294000 	add	x0, x0, #0xa50
    r = put_value((uint32)atoi(argv[2]), (uint64)atoi(argv[3]), 0);
     a34:	52800013 	mov	w19, #0x0                   	// #0
  printf("minisqlite: PASS %d transactions in %l us\n", operations, elapsed);
     a38:	cb010042 	sub	x2, x2, x1
     a3c:	2a1503e1 	mov	w1, w21
     a40:	97fffeb8 	bl	520 <printf@plt>
  return 0;
     a44:	17ffff21 	b	6c8 <main+0xc8>
    operations = 1000;
     a48:	52807d15 	mov	w21, #0x3e8                 	// #1000
     a4c:	17ffffa5 	b	8e0 <main+0x2e0>
    } else if(op < 9){
     a50:	7100241f 	cmp	w0, #0x9
     a54:	2a1403f8 	mov	w24, w20
     a58:	54000260 	b.eq	aa4 <main+0x4a4>  // b.none
      int got = get_value(key, &value);
     a5c:	9101e3e1 	add	x1, sp, #0x78
     a60:	2a1403e0 	mov	w0, w20
      uint64 value = 0;
     a64:	f9003fff 	str	xzr, [sp, #120]
      int got = get_value(key, &value);
     a68:	940002f1 	bl	162c <get_value.constprop.0>
      if((expected_valid[key] && (got != 0 || value != expected_value[key])) ||
     a6c:	91010261 	add	x1, x19, #0x40
     a70:	38786821 	ldrb	w1, [x1, x24]
     a74:	34000141 	cbz	w1, a9c <main+0x49c>
     a78:	350000a0 	cbnz	w0, a8c <main+0x48c>
     a7c:	f8787ac1 	ldr	x1, [x22, x24, lsl #3]
     a80:	f9403fe0 	ldr	x0, [sp, #120]
     a84:	eb00003f 	cmp	x1, x0
         (!expected_valid[key] && got != 1))
     a88:	54fff8e0 	b.eq	9a4 <main+0x3a4>  // b.none
  printf("minisqlite: FAIL during transaction/check\n");
     a8c:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     a90:	9129ec00 	add	x0, x0, #0xa7b
     a94:	97fffea3 	bl	520 <printf@plt>
  return -1;
     a98:	17ffff51 	b	7dc <main+0x1dc>
         (!expected_valid[key] && got != 1))
     a9c:	7100041f 	cmp	w0, #0x1
     aa0:	17fffffa 	b	a88 <main+0x488>
      int got = delete_key(key);
     aa4:	2a1403e0 	mov	w0, w20
     aa8:	940001f0 	bl	1268 <delete_key>
      if((expected_valid[key] && got != 0) || (!expected_valid[key] && got != 1))
     aac:	91010261 	add	x1, x19, #0x40
     ab0:	38786821 	ldrb	w1, [x1, x24]
     ab4:	340000a1 	cbz	w1, ac8 <main+0x4c8>
     ab8:	35fffea0 	cbnz	w0, a8c <main+0x48c>
      expected_valid[key] = 0;
     abc:	91010260 	add	x0, x19, #0x40
     ac0:	3838681f 	strb	wzr, [x0, x24]
     ac4:	17ffffb8 	b	9a4 <main+0x3a4>
      if((expected_valid[key] && got != 0) || (!expected_valid[key] && got != 1))
     ac8:	7100041f 	cmp	w0, #0x1
     acc:	54ffff80 	b.eq	abc <main+0x4bc>  // b.none
     ad0:	17ffffef 	b	a8c <main+0x48c>
       (!expected_valid[key] && got != 1))
     ad4:	7100041f 	cmp	w0, #0x1
     ad8:	17ffffca 	b	a00 <main+0x400>
    usage();
     adc:	94000029 	bl	b80 <usage>
     ae0:	17ffff3f 	b	7dc <main+0x1dc>

0000000000000ae4 <hash_bytes>:
{
     ae4:	aa0003e5 	mov	x5, x0
    h *= 16777619U;
     ae8:	52803264 	mov	w4, #0x193                 	// #403
     aec:	72a02004 	movk	w4, #0x100, lsl #16
  uint32 h = 2166136261U;
     af0:	5293b8a0 	mov	w0, #0x9dc5                	// #40389
     af4:	72b02380 	movk	w0, #0x811c, lsl #16
{
     af8:	d2800003 	mov	x3, #0x0                   	// #0
    h ^= p[i];
     afc:	386368a2 	ldrb	w2, [x5, x3]
  for(uint i = 0; i < n; i++){
     b00:	91000463 	add	x3, x3, #0x1
    h ^= p[i];
     b04:	4a000042 	eor	w2, w2, w0
    h *= 16777619U;
     b08:	1b047c40 	mul	w0, w2, w4
  for(uint i = 0; i < n; i++){
     b0c:	6b03003f 	cmp	w1, w3
     b10:	54ffff68 	b.hi	afc <hash_bytes+0x18>  // b.pmore
}
     b14:	d65f03c0 	ret

0000000000000b18 <valid_slot>:
{
     b18:	aa0003e6 	mov	x6, x0
     b1c:	d2800000 	mov	x0, #0x0                   	// #0
    if(p[i] != 0){
     b20:	386068c1 	ldrb	w1, [x6, x0]
     b24:	35000141 	cbnz	w1, b4c <valid_slot+0x34>
  for(uint i = 0; i < sizeof(*s); i++)
     b28:	91000400 	add	x0, x0, #0x1
     b2c:	f101001f 	cmp	x0, #0x40
     b30:	54ffff81 	b.ne	b20 <valid_slot+0x8>  // b.any
    return 1;
     b34:	52800020 	mov	w0, #0x1                   	// #1
}
     b38:	d65f03c0 	ret
  return (s->state == SLOT_FREE || s->state == SLOT_USED || s->state == SLOT_TOMB) &&
     b3c:	6b0000ff 	cmp	w7, w0
     b40:	1a9f17e0 	cset	w0, eq	// eq = none
}
     b44:	a8c17bfd 	ldp	x29, x30, [sp], #16
     b48:	d65f03c0 	ret
{
     b4c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  uint32 got = hash_bytes(s, sizeof(*s));
     b50:	52800801 	mov	w1, #0x40                  	// #64
     b54:	aa0603e0 	mov	x0, x6
{
     b58:	910003fd 	mov	x29, sp
  uint32 saved = s->checksum;
     b5c:	b94018c7 	ldr	w7, [x6, #24]
  s->checksum = 0;
     b60:	b90018df 	str	wzr, [x6, #24]
  uint32 got = hash_bytes(s, sizeof(*s));
     b64:	97ffffe0 	bl	ae4 <hash_bytes>
  return (s->state == SLOT_FREE || s->state == SLOT_USED || s->state == SLOT_TOMB) &&
     b68:	b94000c1 	ldr	w1, [x6]
  s->checksum = saved;
     b6c:	b90018c7 	str	w7, [x6, #24]
  return (s->state == SLOT_FREE || s->state == SLOT_USED || s->state == SLOT_TOMB) &&
     b70:	7100083f 	cmp	w1, #0x2
     b74:	54fffe49 	b.ls	b3c <valid_slot+0x24>  // b.plast
     b78:	52800000 	mov	w0, #0x0                   	// #0
     b7c:	17fffff2 	b	b44 <valid_slot+0x2c>

0000000000000b80 <usage>:
{
     b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  printf("usage: minisqlite init|put KEY VALUE|get KEY|delete KEY|scan|check\n");
     b84:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     b88:	911ba000 	add	x0, x0, #0x6e8
{
     b8c:	910003fd 	mov	x29, sp
  printf("usage: minisqlite init|put KEY VALUE|get KEY|delete KEY|scan|check\n");
     b90:	97fffe64 	bl	520 <printf@plt>
  printf("                  insert KEY VALUE|select KEY|select all\n");
     b94:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     b98:	911cb000 	add	x0, x0, #0x72c
     b9c:	97fffe61 	bl	520 <printf@plt>
}
     ba0:	a8c17bfd 	ldp	x29, x30, [sp], #16
  printf("                  recover|prepare KEY VALUE|stress [OPERATIONS]\n");
     ba4:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     ba8:	911d9800 	add	x0, x0, #0x766
     bac:	17fffe5d 	b	520 <printf@plt>

0000000000000bb0 <clear_wal>:
{
     bb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  int fd = open(WAL_PATH, O_CREATE | O_RDWR);
     bb4:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     bb8:	911e9c00 	add	x0, x0, #0x7a7
{
     bbc:	910003fd 	mov	x29, sp
  int fd = open(WAL_PATH, O_CREATE | O_RDWR);
     bc0:	52804041 	mov	w1, #0x202                 	// #514
{
     bc4:	a90153f3 	stp	x19, x20, [sp, #16]
  int fd = open(WAL_PATH, O_CREATE | O_RDWR);
     bc8:	97fffe7e 	bl	5c0 <open@plt>
  if(fd < 0)
     bcc:	37f80220 	tbnz	w0, #31, c10 <clear_wal+0x60>
     bd0:	2a0003f4 	mov	w20, w0
  int ok = ftruncate(fd, 0) == 0 && fsync(fd) == 0;
     bd4:	d2800001 	mov	x1, #0x0                   	// #0
     bd8:	97fffe5a 	bl	540 <ftruncate@plt>
     bdc:	35000160 	cbnz	w0, c08 <clear_wal+0x58>
     be0:	2a1403e0 	mov	w0, w20
     be4:	97fffe63 	bl	570 <fsync@plt>
     be8:	7100001f 	cmp	w0, #0x0
     bec:	1a9f17f3 	cset	w19, eq	// eq = none
  close(fd);
     bf0:	2a1403e0 	mov	w0, w20
     bf4:	97fffe7f 	bl	5f0 <close@plt>
  return ok ? 0 : -1;
     bf8:	51000660 	sub	w0, w19, #0x1
}
     bfc:	a94153f3 	ldp	x19, x20, [sp, #16]
     c00:	a8c27bfd 	ldp	x29, x30, [sp], #32
     c04:	d65f03c0 	ret
  int ok = ftruncate(fd, 0) == 0 && fsync(fd) == 0;
     c08:	52800013 	mov	w19, #0x0                   	// #0
     c0c:	17fffff9 	b	bf0 <clear_wal+0x40>
    return -1;
     c10:	12800000 	mov	w0, #0xffffffff            	// #-1
     c14:	17fffffa 	b	bfc <clear_wal+0x4c>

0000000000000c18 <find_key>:
{
     c18:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
     c1c:	910003fd 	mov	x29, sp
     c20:	a90363f7 	stp	x23, x24, [sp, #48]
  uint start = (key * 2654435761U) % TOTAL_SLOTS;
     c24:	528f3637 	mov	w23, #0x79b1                	// #31153
     c28:	72b3c6f7 	movk	w23, #0x9e37, lsl #16
{
     c2c:	2a0103f8 	mov	w24, w1
     c30:	a9025bf5 	stp	x21, x22, [sp, #32]
  uint start = (key * 2654435761U) % TOTAL_SLOTS;
     c34:	1b177c37 	mul	w23, w1, w23
  if(pread(fd, s, sizeof(*s), slot_offset(slotno)) != sizeof(*s))
     c38:	d0000015 	adrp	x21, 2000 <get_value.constprop.0+0x9d4>
     c3c:	913162b5 	add	x21, x21, #0xc58
{
     c40:	a9046bf9 	stp	x25, x26, [sp, #64]
     c44:	2a0003fa 	mov	w26, w0
     c48:	aa0303f9 	mov	x25, x3
     c4c:	a90573fb 	stp	x27, x28, [sp, #80]
     c50:	aa0203fb 	mov	x27, x2
  for(uint probe = 0; probe < TOTAL_SLOTS; probe++){
     c54:	5280001c 	mov	w28, #0x0                   	// #0
{
     c58:	a90153f3 	stp	x19, x20, [sp, #16]
  uint first_tomb = TOTAL_SLOTS;
     c5c:	52880014 	mov	w20, #0x4000                	// #16384
    uint pos = (start + probe) % TOTAL_SLOTS;
     c60:	0b1c02f3 	add	w19, w23, w28
     c64:	12003673 	and	w19, w19, #0x3fff
  if(pread(fd, s, sizeof(*s), slot_offset(slotno)) != sizeof(*s))
     c68:	aa1503e1 	mov	x1, x21
  return (uint64)PAGE_SIZE + (uint64)slotno * SLOT_SIZE;
     c6c:	11010263 	add	w3, w19, #0x40
  if(pread(fd, s, sizeof(*s), slot_offset(slotno)) != sizeof(*s))
     c70:	2a1a03e0 	mov	w0, w26
     c74:	52800802 	mov	w2, #0x40                  	// #64
     c78:	d37a3863 	ubfiz	x3, x3, #6, #15
     c7c:	97fffe41 	bl	580 <pread@plt>
     c80:	7101001f 	cmp	w0, #0x40
     c84:	54000140 	b.eq	cac <find_key+0x94>  // b.none
      return -1;
     c88:	12800016 	mov	w22, #0xffffffff            	// #-1
}
     c8c:	2a1603e0 	mov	w0, w22
     c90:	a94153f3 	ldp	x19, x20, [sp, #16]
     c94:	a9425bf5 	ldp	x21, x22, [sp, #32]
     c98:	a94363f7 	ldp	x23, x24, [sp, #48]
     c9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
     ca0:	a94573fb 	ldp	x27, x28, [sp, #80]
     ca4:	a8c67bfd 	ldp	x29, x30, [sp], #96
     ca8:	d65f03c0 	ret
  return valid_slot(s) ? 0 : -1;
     cac:	aa1503e0 	mov	x0, x21
     cb0:	97ffff9a 	bl	b18 <valid_slot>
     cb4:	2a0003f6 	mov	w22, w0
     cb8:	34fffe80 	cbz	w0, c88 <find_key+0x70>
    if(slotbuf.state == SLOT_USED && slotbuf.key == key){
     cbc:	b94002a0 	ldr	w0, [x21]
     cc0:	7100041f 	cmp	w0, #0x1
     cc4:	54000161 	b.ne	cf0 <find_key+0xd8>  // b.any
     cc8:	b94006a0 	ldr	w0, [x21, #4]
     ccc:	6b18001f 	cmp	w0, w24
     cd0:	54000181 	b.ne	d00 <find_key+0xe8>  // b.any
      *slotno = pos;
     cd4:	b9000373 	str	w19, [x27]
      if(found) *found = slotbuf;
     cd8:	b4fffdb9 	cbz	x25, c8c <find_key+0x74>
     cdc:	aa1503e1 	mov	x1, x21
     ce0:	aa1903e0 	mov	x0, x25
     ce4:	d2800802 	mov	x2, #0x40                  	// #64
     ce8:	97fffe12 	bl	530 <memcpy@plt>
     cec:	17ffffe8 	b	c8c <find_key+0x74>
    if(slotbuf.state == SLOT_TOMB && first_tomb == TOTAL_SLOTS)
     cf0:	7100081f 	cmp	w0, #0x2
     cf4:	54000141 	b.ne	d1c <find_key+0x104>  // b.any
      first_tomb = pos;
     cf8:	7140129f 	cmp	w20, #0x4, lsl #12
     cfc:	1a931294 	csel	w20, w20, w19, ne	// ne = any
  for(uint probe = 0; probe < TOTAL_SLOTS; probe++){
     d00:	1100079c 	add	w28, w28, #0x1
     d04:	7140139f 	cmp	w28, #0x4, lsl #12
     d08:	54fffac1 	b.ne	c60 <find_key+0x48>  // b.any
  if(first_tomb != TOTAL_SLOTS){
     d0c:	7140129f 	cmp	w20, #0x4, lsl #12
     d10:	54fffbc0 	b.eq	c88 <find_key+0x70>  // b.none
    *slotno = first_tomb;
     d14:	b9000374 	str	w20, [x27]
    return 0;
     d18:	14000005 	b	d2c <find_key+0x114>
    if(slotbuf.state == SLOT_FREE){
     d1c:	35ffff20 	cbnz	w0, d00 <find_key+0xe8>
      *slotno = first_tomb != TOTAL_SLOTS ? first_tomb : pos;
     d20:	7140129f 	cmp	w20, #0x4, lsl #12
     d24:	1a940273 	csel	w19, w19, w20, eq	// eq = none
     d28:	b9000373 	str	w19, [x27]
      return 0;
     d2c:	52800016 	mov	w22, #0x0                   	// #0
     d30:	17ffffd7 	b	c8c <find_key+0x74>

0000000000000d34 <read_header.constprop.0>:
read_header(int fd, struct db_header *h)
     d34:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  return pread(fd, h, sizeof(*h), 0) == sizeof(*h) && valid_header(h) ? 0 : -1;
     d38:	d2800003 	mov	x3, #0x0                   	// #0
     d3c:	52820002 	mov	w2, #0x1000                	// #4096
read_header(int fd, struct db_header *h)
     d40:	910003fd 	mov	x29, sp
     d44:	a90153f3 	stp	x19, x20, [sp, #16]
  return pread(fd, h, sizeof(*h), 0) == sizeof(*h) && valid_header(h) ? 0 : -1;
     d48:	b0000034 	adrp	x20, 5000 <pagebuf+0x168>
     d4c:	913a6293 	add	x19, x20, #0xe98
     d50:	aa1303e1 	mov	x1, x19
     d54:	97fffe0b 	bl	580 <pread@plt>
     d58:	7140041f 	cmp	w0, #0x1, lsl #12
     d5c:	540000a0 	b.eq	d70 <read_header.constprop.0+0x3c>  // b.none
     d60:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     d64:	a94153f3 	ldp	x19, x20, [sp, #16]
     d68:	a8c27bfd 	ldp	x29, x30, [sp], #32
     d6c:	d65f03c0 	ret
  uint32 got = hash_bytes(h, sizeof(*h));
     d70:	2a0003e1 	mov	w1, w0
  uint32 saved = h->checksum;
     d74:	b9402266 	ldr	w6, [x19, #32]
  uint32 got = hash_bytes(h, sizeof(*h));
     d78:	aa1303e0 	mov	x0, x19
  h->checksum = 0;
     d7c:	b900227f 	str	wzr, [x19, #32]
  uint32 got = hash_bytes(h, sizeof(*h));
     d80:	97ffff59 	bl	ae4 <hash_bytes>
  return h->magic == DB_MAGIC && h->version == DB_VERSION &&
     d84:	d2888841 	mov	x1, #0x4442                	// #17474
     d88:	f2a9aa61 	movk	x1, #0x4d53, lsl #16
  h->checksum = saved;
     d8c:	b9002266 	str	w6, [x19, #32]
  return h->magic == DB_MAGIC && h->version == DB_VERSION &&
     d90:	f9474e82 	ldr	x2, [x20, #3736]
     d94:	f2c00021 	movk	x1, #0x1, lsl #32
     d98:	eb01005f 	cmp	x2, x1
     d9c:	54fffe21 	b.ne	d60 <read_header.constprop.0+0x2c>  // b.any
         h->page_size == PAGE_SIZE && h->pages == DB_PAGES && saved == got;
     da0:	f9400662 	ldr	x2, [x19, #8]
     da4:	d2820001 	mov	x1, #0x1000                	// #4096
     da8:	f2c02001 	movk	x1, #0x100, lsl #32
     dac:	eb01005f 	cmp	x2, x1
     db0:	54fffd81 	b.ne	d60 <read_header.constprop.0+0x2c>  // b.any
     db4:	6b0000df 	cmp	w6, w0
     db8:	5a9f03e0 	csetm	w0, ne	// ne = any
  return pread(fd, h, sizeof(*h), 0) == sizeof(*h) && valid_header(h) ? 0 : -1;
     dbc:	17ffffea 	b	d64 <read_header.constprop.0+0x30>

0000000000000dc0 <commit_slot.constprop.0>:
commit_slot(int dbfd, uint slotno, struct db_slot *s, uint64 newcount,
     dc0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
     dc4:	910003fd 	mov	x29, sp
     dc8:	a90153f3 	stp	x19, x20, [sp, #16]
  memset(&walbuf, 0, sizeof(walbuf));
     dcc:	f0000014 	adrp	x20, 3000 <expected_value+0x168>
     dd0:	913a6293 	add	x19, x20, #0xe98
commit_slot(int dbfd, uint slotno, struct db_slot *s, uint64 newcount,
     dd4:	a9025bf5 	stp	x21, x22, [sp, #32]
     dd8:	2a0103f5 	mov	w21, w1
     ddc:	aa0203f6 	mov	x22, x2
  memset(&walbuf, 0, sizeof(walbuf));
     de0:	52800001 	mov	w1, #0x0                   	// #0
     de4:	52820002 	mov	w2, #0x1000                	// #4096
commit_slot(int dbfd, uint slotno, struct db_slot *s, uint64 newcount,
     de8:	a90363f7 	stp	x23, x24, [sp, #48]
     dec:	2a0003f8 	mov	w24, w0
  memset(&walbuf, 0, sizeof(walbuf));
     df0:	aa1303e0 	mov	x0, x19
commit_slot(int dbfd, uint slotno, struct db_slot *s, uint64 newcount,
     df4:	f90023f9 	str	x25, [sp, #64]
     df8:	2a0303f9 	mov	w25, w3
  memset(&walbuf, 0, sizeof(walbuf));
     dfc:	97fffdd5 	bl	550 <memset@plt>
  walbuf.magic = WAL_MAGIC;
     e00:	d28ae980 	mov	x0, #0x574c                	// #22348
     e04:	f2a9aa60 	movk	x0, #0x4d53, lsl #16
     e08:	f2c00020 	movk	x0, #0x1, lsl #32
     e0c:	f9074e80 	str	x0, [x20, #3736]
  walbuf.txid = s->txid;
     e10:	d0000014 	adrp	x20, 2000 <get_value.constprop.0+0x9d4>
     e14:	91316294 	add	x20, x20, #0xc58
  walbuf.page_index = slotno / SLOTS_PER_PAGE;
     e18:	53067ea1 	lsr	w1, w21, #6
  walbuf.committed = 1;
     e1c:	52800020 	mov	w0, #0x1                   	// #1
     e20:	29010660 	stp	w0, w1, [x19, #8]
  walbuf.slot_index = slotno % SLOTS_PER_PAGE;
     e24:	120016a0 	and	w0, w21, #0x3f
     e28:	b9001260 	str	w0, [x19, #16]
  walbuf.slot = *s;
     e2c:	d2800802 	mov	x2, #0x40                  	// #64
  walbuf.txid = s->txid;
     e30:	f9400a80 	ldr	x0, [x20, #16]
     e34:	a901da60 	stp	x0, x22, [x19, #24]
  walbuf.slot = *s;
     e38:	aa1403e1 	mov	x1, x20
     e3c:	9100a260 	add	x0, x19, #0x28
     e40:	97fffdbc 	bl	530 <memcpy@plt>
  w->checksum = hash_bytes(w, sizeof(*w));
     e44:	52820001 	mov	w1, #0x1000                	// #4096
     e48:	aa1303e0 	mov	x0, x19
  w->checksum = 0;
     e4c:	b9006a7f 	str	wzr, [x19, #104]
  w->checksum = hash_bytes(w, sizeof(*w));
     e50:	97ffff25 	bl	ae4 <hash_bytes>
  int wfd = open(WAL_PATH, O_CREATE | O_RDWR | O_TRUNC);
     e54:	5280c041 	mov	w1, #0x602                 	// #1538
  w->checksum = hash_bytes(w, sizeof(*w));
     e58:	b9006a60 	str	w0, [x19, #104]
  int wfd = open(WAL_PATH, O_CREATE | O_RDWR | O_TRUNC);
     e5c:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     e60:	911e9c00 	add	x0, x0, #0x7a7
     e64:	97fffdd7 	bl	5c0 <open@plt>
  if(wfd < 0 || pwrite(wfd, &walbuf, sizeof(walbuf), 0) != sizeof(walbuf) ||
     e68:	37f80160 	tbnz	w0, #31, e94 <commit_slot.constprop.0+0xd4>
     e6c:	aa1303e1 	mov	x1, x19
     e70:	2a0003f7 	mov	w23, w0
     e74:	d2800003 	mov	x3, #0x0                   	// #0
     e78:	52820002 	mov	w2, #0x1000                	// #4096
     e7c:	97fffdd9 	bl	5e0 <pwrite@plt>
     e80:	2a0003f3 	mov	w19, w0
     e84:	7140041f 	cmp	w0, #0x1, lsl #12
     e88:	54000140 	b.eq	eb0 <commit_slot.constprop.0+0xf0>  // b.none
    if(wfd >= 0) close(wfd);
     e8c:	2a1703e0 	mov	w0, w23
     e90:	97fffdd8 	bl	5f0 <close@plt>
    return -1;
     e94:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     e98:	f94023f9 	ldr	x25, [sp, #64]
     e9c:	a94153f3 	ldp	x19, x20, [sp, #16]
     ea0:	a9425bf5 	ldp	x21, x22, [sp, #32]
     ea4:	a94363f7 	ldp	x23, x24, [sp, #48]
     ea8:	a8c57bfd 	ldp	x29, x30, [sp], #80
     eac:	d65f03c0 	ret
     fsync(wfd) < 0){
     eb0:	2a1703e0 	mov	w0, w23
     eb4:	97fffdaf 	bl	570 <fsync@plt>
  if(wfd < 0 || pwrite(wfd, &walbuf, sizeof(walbuf), 0) != sizeof(walbuf) ||
     eb8:	37fffea0 	tbnz	w0, #31, e8c <commit_slot.constprop.0+0xcc>
  close(wfd);
     ebc:	2a1703e0 	mov	w0, w23
     ec0:	97fffdcc 	bl	5f0 <close@plt>
  if(stop_after_wal){
     ec4:	340000f9 	cbz	w25, ee0 <commit_slot.constprop.0+0x120>
    printf("minisqlite: WAL durable tx=%l; cut power now\n", s->txid);
     ec8:	f9400a81 	ldr	x1, [x20, #16]
     ecc:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     ed0:	911f1400 	add	x0, x0, #0x7c5
     ed4:	97fffd93 	bl	520 <printf@plt>
    return 0;
     ed8:	52800000 	mov	w0, #0x0                   	// #0
     edc:	17ffffef 	b	e98 <commit_slot.constprop.0+0xd8>
  return (uint64)PAGE_SIZE + (uint64)slotno * SLOT_SIZE;
     ee0:	d37a7ea3 	ubfiz	x3, x21, #6, #32
  if(pwrite(dbfd, s, sizeof(*s), slot_offset(slotno)) != sizeof(*s))
     ee4:	aa1403e1 	mov	x1, x20
     ee8:	91400463 	add	x3, x3, #0x1, lsl #12
     eec:	2a1803e0 	mov	w0, w24
     ef0:	52800802 	mov	w2, #0x40                  	// #64
     ef4:	97fffdbb 	bl	5e0 <pwrite@plt>
     ef8:	7101001f 	cmp	w0, #0x40
     efc:	54fffcc1 	b.ne	e94 <commit_slot.constprop.0+0xd4>  // b.any
  hdr.txid = s->txid;
     f00:	b0000026 	adrp	x6, 5000 <pagebuf+0x168>
     f04:	913a60c6 	add	x6, x6, #0xe98
     f08:	f9400a80 	ldr	x0, [x20, #16]
  h->checksum = hash_bytes(h, sizeof(*h));
     f0c:	2a1303e1 	mov	w1, w19
  hdr.txid = s->txid;
     f10:	a90158c0 	stp	x0, x22, [x6, #16]
  h->checksum = hash_bytes(h, sizeof(*h));
     f14:	aa0603e0 	mov	x0, x6
  h->checksum = 0;
     f18:	b90020df 	str	wzr, [x6, #32]
  h->checksum = hash_bytes(h, sizeof(*h));
     f1c:	97fffef2 	bl	ae4 <hash_bytes>
  if(pwrite(dbfd, &hdr, sizeof(hdr), 0) != sizeof(hdr) || fsync(dbfd) < 0)
     f20:	2a1303e2 	mov	w2, w19
     f24:	aa0603e1 	mov	x1, x6
     f28:	d2800003 	mov	x3, #0x0                   	// #0
  h->checksum = hash_bytes(h, sizeof(*h));
     f2c:	b90020c0 	str	w0, [x6, #32]
  if(pwrite(dbfd, &hdr, sizeof(hdr), 0) != sizeof(hdr) || fsync(dbfd) < 0)
     f30:	2a1803e0 	mov	w0, w24
     f34:	97fffdab 	bl	5e0 <pwrite@plt>
     f38:	7140041f 	cmp	w0, #0x1, lsl #12
     f3c:	54fffac1 	b.ne	e94 <commit_slot.constprop.0+0xd4>  // b.any
     f40:	2a1803e0 	mov	w0, w24
     f44:	97fffd8b 	bl	570 <fsync@plt>
     f48:	37fffa60 	tbnz	w0, #31, e94 <commit_slot.constprop.0+0xd4>
}
     f4c:	f94023f9 	ldr	x25, [sp, #64]
     f50:	a94153f3 	ldp	x19, x20, [sp, #16]
     f54:	a9425bf5 	ldp	x21, x22, [sp, #32]
     f58:	a94363f7 	ldp	x23, x24, [sp, #48]
     f5c:	a8c57bfd 	ldp	x29, x30, [sp], #80
  return clear_wal();
     f60:	17ffff14 	b	bb0 <clear_wal>

0000000000000f64 <initialize>:
{
     f64:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  mkdir(DB_DIR);
     f68:	b0000000 	adrp	x0, 1000 <initialize+0x9c>
     f6c:	911fcc00 	add	x0, x0, #0x7f3
{
     f70:	910003fd 	mov	x29, sp
     f74:	a90153f3 	stp	x19, x20, [sp, #16]
     f78:	a9025bf5 	stp	x21, x22, [sp, #32]
  mkdir(DB_DIR);
     f7c:	97fffd95 	bl	5d0 <mkdir@plt>
  int fd = open(DB_PATH, O_CREATE | O_RDWR | O_TRUNC);
     f80:	b0000016 	adrp	x22, 1000 <initialize+0x9c>
     f84:	912022d6 	add	x22, x22, #0x808
     f88:	5280c041 	mov	w1, #0x602                 	// #1538
     f8c:	aa1603e0 	mov	x0, x22
     f90:	97fffd8c 	bl	5c0 <open@plt>
  if(fd < 0)
     f94:	36f800c0 	tbz	w0, #31, fac <initialize+0x48>
    return -1;
     f98:	12800000 	mov	w0, #0xffffffff            	// #-1
}
     f9c:	a94153f3 	ldp	x19, x20, [sp, #16]
     fa0:	a9425bf5 	ldp	x21, x22, [sp, #32]
     fa4:	a8c37bfd 	ldp	x29, x30, [sp], #48
     fa8:	d65f03c0 	ret
  memset(&hdr, 0, sizeof(hdr));
     fac:	b0000033 	adrp	x19, 5000 <pagebuf+0x168>
     fb0:	913a6273 	add	x19, x19, #0xe98
     fb4:	52820002 	mov	w2, #0x1000                	// #4096
     fb8:	2a0003f5 	mov	w21, w0
     fbc:	52800001 	mov	w1, #0x0                   	// #0
     fc0:	aa1303e0 	mov	x0, x19
     fc4:	97fffd63 	bl	550 <memset@plt>
  h->checksum = 0;
     fc8:	b900227f 	str	wzr, [x19, #32]
  hdr.magic = DB_MAGIC;
     fcc:	d2888840 	mov	x0, #0x4442                	// #17474
     fd0:	f2a9aa60 	movk	x0, #0x4d53, lsl #16
     fd4:	d2820001 	mov	x1, #0x1000                	// #4096
     fd8:	f2c00020 	movk	x0, #0x1, lsl #32
     fdc:	f2c02001 	movk	x1, #0x100, lsl #32
     fe0:	a9000660 	stp	x0, x1, [x19]
  h->checksum = hash_bytes(h, sizeof(*h));
     fe4:	52820001 	mov	w1, #0x1000                	// #4096
     fe8:	aa1303e0 	mov	x0, x19
     fec:	97fffebe 	bl	ae4 <hash_bytes>
  int ok = ftruncate(fd, bytes) == 0 &&
     ff0:	d2820001 	mov	x1, #0x1000                	// #4096
     ff4:	f2a00201 	movk	x1, #0x10, lsl #16
  h->checksum = hash_bytes(h, sizeof(*h));
     ff8:	b9002260 	str	w0, [x19, #32]
  int ok = ftruncate(fd, bytes) == 0 &&
     ffc:	2a1503e0 	mov	w0, w21
    1000:	97fffd50 	bl	540 <ftruncate@plt>
    1004:	2a0003f4 	mov	w20, w0
           pwrite(fd, &hdr, sizeof(hdr), 0) == sizeof(hdr) && fsync(fd) == 0;
    1008:	35000380 	cbnz	w0, 1078 <initialize+0x114>
    100c:	aa1303e1 	mov	x1, x19
    1010:	2a1503e0 	mov	w0, w21
    1014:	d2800003 	mov	x3, #0x0                   	// #0
    1018:	52820002 	mov	w2, #0x1000                	// #4096
    101c:	97fffd71 	bl	5e0 <pwrite@plt>
  int ok = ftruncate(fd, bytes) == 0 &&
    1020:	7140041f 	cmp	w0, #0x1, lsl #12
    1024:	540000a1 	b.ne	1038 <initialize+0xd4>  // b.any
           pwrite(fd, &hdr, sizeof(hdr), 0) == sizeof(hdr) && fsync(fd) == 0;
    1028:	2a1503e0 	mov	w0, w21
    102c:	97fffd51 	bl	570 <fsync@plt>
    1030:	7100001f 	cmp	w0, #0x0
    1034:	1a9f17f4 	cset	w20, eq	// eq = none
  close(fd);
    1038:	2a1503e0 	mov	w0, w21
    103c:	97fffd6d 	bl	5f0 <close@plt>
  if(!ok || clear_wal() < 0)
    1040:	34fffad4 	cbz	w20, f98 <initialize+0x34>
    1044:	97fffedb 	bl	bb0 <clear_wal>
    1048:	3100041f 	cmn	w0, #0x1
    104c:	54fffa80 	b.eq	f9c <initialize+0x38>  // b.none
  printf("minisqlite: initialized %s pages=%d slots=%d bytes=%l\n",
    1050:	aa1603e1 	mov	x1, x22
    1054:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    1058:	91209400 	add	x0, x0, #0x825
    105c:	d2820004 	mov	x4, #0x1000                	// #4096
    1060:	f2a00204 	movk	x4, #0x10, lsl #16
    1064:	52880003 	mov	w3, #0x4000                	// #16384
    1068:	52802002 	mov	w2, #0x100                 	// #256
    106c:	97fffd2d 	bl	520 <printf@plt>
  return 0;
    1070:	52800000 	mov	w0, #0x0                   	// #0
    1074:	17ffffca 	b	f9c <initialize+0x38>
           pwrite(fd, &hdr, sizeof(hdr), 0) == sizeof(hdr) && fsync(fd) == 0;
    1078:	52800014 	mov	w20, #0x0                   	// #0
    107c:	17ffffef 	b	1038 <initialize+0xd4>

0000000000001080 <recover_db>:
{
    1080:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
  int wfd = open(WAL_PATH, O_RDONLY);
    1084:	52800001 	mov	w1, #0x0                   	// #0
{
    1088:	910003fd 	mov	x29, sp
    108c:	a90153f3 	stp	x19, x20, [sp, #16]
    1090:	a9025bf5 	stp	x21, x22, [sp, #32]
    1094:	2a0003f6 	mov	w22, w0
  int wfd = open(WAL_PATH, O_RDONLY);
    1098:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    109c:	911e9c00 	add	x0, x0, #0x7a7
{
    10a0:	f9001bf7 	str	x23, [sp, #48]
  int wfd = open(WAL_PATH, O_RDONLY);
    10a4:	97fffd47 	bl	5c0 <open@plt>
  if(wfd < 0)
    10a8:	37f80dc0 	tbnz	w0, #31, 1260 <recover_db+0x1e0>
  int n = pread(wfd, &walbuf, sizeof(walbuf), 0);
    10ac:	d0000015 	adrp	x21, 3000 <expected_value+0x168>
    10b0:	913a62b3 	add	x19, x21, #0xe98
    10b4:	aa1303e1 	mov	x1, x19
    10b8:	d2800003 	mov	x3, #0x0                   	// #0
    10bc:	52820002 	mov	w2, #0x1000                	// #4096
    10c0:	2a0003f7 	mov	w23, w0
    10c4:	97fffd2f 	bl	580 <pread@plt>
    10c8:	2a0003f4 	mov	w20, w0
  close(wfd);
    10cc:	2a1703e0 	mov	w0, w23
    10d0:	97fffd48 	bl	5f0 <close@plt>
  if(n == 0)
    10d4:	34000694 	cbz	w20, 11a4 <recover_db+0x124>
  if(n != sizeof(walbuf) || !valid_wal(&walbuf)){
    10d8:	7140069f 	cmp	w20, #0x1, lsl #12
    10dc:	54000461 	b.ne	1168 <recover_db+0xe8>  // b.any
  uint32 got = hash_bytes(w, sizeof(*w));
    10e0:	2a1403e1 	mov	w1, w20
  uint32 saved = w->checksum;
    10e4:	b9406a68 	ldr	w8, [x19, #104]
  uint32 got = hash_bytes(w, sizeof(*w));
    10e8:	aa1303e0 	mov	x0, x19
  w->checksum = 0;
    10ec:	b9006a7f 	str	wzr, [x19, #104]
  uint32 got = hash_bytes(w, sizeof(*w));
    10f0:	97fffe7d 	bl	ae4 <hash_bytes>
    10f4:	2a0003e9 	mov	w9, w0
  return w->magic == WAL_MAGIC && w->version == DB_VERSION &&
    10f8:	f9474ea1 	ldr	x1, [x21, #3736]
    10fc:	d28ae980 	mov	x0, #0x574c                	// #22348
    1100:	f2a9aa60 	movk	x0, #0x4d53, lsl #16
  w->checksum = saved;
    1104:	b9006a68 	str	w8, [x19, #104]
  return w->magic == WAL_MAGIC && w->version == DB_VERSION &&
    1108:	f2c00020 	movk	x0, #0x1, lsl #32
    110c:	eb00003f 	cmp	x1, x0
    1110:	540002c1 	b.ne	1168 <recover_db+0xe8>  // b.any
    1114:	f9400660 	ldr	x0, [x19, #8]
    1118:	9258dc00 	and	x0, x0, #0xffffff00ffffffff
         w->committed == 1 && w->page_index < DB_PAGES &&
    111c:	f100041f 	cmp	x0, #0x1
    1120:	54000241 	b.ne	1168 <recover_db+0xe8>  // b.any
    1124:	b9401260 	ldr	w0, [x19, #16]
    1128:	7100fc1f 	cmp	w0, #0x3f
    112c:	540001e8 	b.hi	1168 <recover_db+0xe8>  // b.pmore
         w->slot_index < SLOTS_PER_PAGE && valid_slot(&w->slot) && saved == got;
    1130:	d0000017 	adrp	x23, 3000 <expected_value+0x168>
    1134:	913b02e0 	add	x0, x23, #0xec0
    1138:	97fffe78 	bl	b18 <valid_slot>
    113c:	34000160 	cbz	w0, 1168 <recover_db+0xe8>
    1140:	6b09011f 	cmp	w8, w9
    1144:	54000121 	b.ne	1168 <recover_db+0xe8>  // b.any
  int dbfd = open(DB_PATH, O_RDWR);
    1148:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    114c:	91202000 	add	x0, x0, #0x808
    1150:	52800041 	mov	w1, #0x2                   	// #2
    1154:	97fffd1b 	bl	5c0 <open@plt>
    1158:	2a0003f5 	mov	w21, w0
  if(dbfd < 0 || read_header(dbfd, &hdr) < 0){
    115c:	36f80180 	tbz	w0, #31, 118c <recover_db+0x10c>
    return -1;
    1160:	12800014 	mov	w20, #0xffffffff            	// #-1
    1164:	14000010 	b	11a4 <recover_db+0x124>
    printf("minisqlite: ignoring incomplete/corrupt WAL (%d bytes)\n", n);
    1168:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    116c:	91217000 	add	x0, x0, #0x85c
    1170:	2a1403e1 	mov	w1, w20
    1174:	97fffceb 	bl	520 <printf@plt>
}
    1178:	f9401bf7 	ldr	x23, [sp, #48]
    117c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1180:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1184:	a8c47bfd 	ldp	x29, x30, [sp], #64
  return clear_wal();
    1188:	17fffe8a 	b	bb0 <clear_wal>
  if(dbfd < 0 || read_header(dbfd, &hdr) < 0){
    118c:	97fffeea 	bl	d34 <read_header.constprop.0>
    1190:	2a0003f4 	mov	w20, w0
    1194:	3100041f 	cmn	w0, #0x1
    1198:	54000121 	b.ne	11bc <recover_db+0x13c>  // b.any
    if(dbfd >= 0) close(dbfd);
    119c:	2a1503e0 	mov	w0, w21
    11a0:	97fffd14 	bl	5f0 <close@plt>
}
    11a4:	f9401bf7 	ldr	x23, [sp, #48]
    11a8:	2a1403e0 	mov	w0, w20
    11ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    11b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    11b4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    11b8:	d65f03c0 	ret
  uint slotno = walbuf.page_index * SLOTS_PER_PAGE + walbuf.slot_index;
    11bc:	29418263 	ldp	w3, w0, [x19, #12]
  if(pwrite(dbfd, &walbuf.slot, sizeof(walbuf.slot), slot_offset(slotno)) !=
    11c0:	913b02e1 	add	x1, x23, #0xec0
    11c4:	52800802 	mov	w2, #0x40                  	// #64
  return (uint64)PAGE_SIZE + (uint64)slotno * SLOT_SIZE;
    11c8:	0b031803 	add	w3, w0, w3, lsl #6
  if(pwrite(dbfd, &walbuf.slot, sizeof(walbuf.slot), slot_offset(slotno)) !=
    11cc:	2a1503e0 	mov	w0, w21
  return (uint64)PAGE_SIZE + (uint64)slotno * SLOT_SIZE;
    11d0:	91010063 	add	x3, x3, #0x40
  if(pwrite(dbfd, &walbuf.slot, sizeof(walbuf.slot), slot_offset(slotno)) !=
    11d4:	d37ae463 	lsl	x3, x3, #6
    11d8:	97fffd02 	bl	5e0 <pwrite@plt>
    11dc:	7101001f 	cmp	w0, #0x40
    11e0:	54000080 	b.eq	11f0 <recover_db+0x170>  // b.none
    close(dbfd);
    11e4:	2a1503e0 	mov	w0, w21
    11e8:	97fffd02 	bl	5f0 <close@plt>
    return -1;
    11ec:	17ffffdd 	b	1160 <recover_db+0xe0>
  hdr.txid = walbuf.txid;
    11f0:	90000026 	adrp	x6, 5000 <pagebuf+0x168>
    11f4:	913a60c6 	add	x6, x6, #0xe98
  hdr.count = walbuf.count;
    11f8:	a9418660 	ldp	x0, x1, [x19, #24]
  hdr.txid = walbuf.txid;
    11fc:	a90104c0 	stp	x0, x1, [x6, #16]
  h->checksum = hash_bytes(h, sizeof(*h));
    1200:	aa0603e0 	mov	x0, x6
    1204:	52820001 	mov	w1, #0x1000                	// #4096
  h->checksum = 0;
    1208:	b90020df 	str	wzr, [x6, #32]
  h->checksum = hash_bytes(h, sizeof(*h));
    120c:	97fffe36 	bl	ae4 <hash_bytes>
    1210:	b90020c0 	str	w0, [x6, #32]
  if(pwrite(dbfd, &hdr, sizeof(hdr), 0) != sizeof(hdr) || fsync(dbfd) < 0){
    1214:	2a0103e2 	mov	w2, w1
    1218:	2a1503e0 	mov	w0, w21
    121c:	aa0603e1 	mov	x1, x6
    1220:	d2800003 	mov	x3, #0x0                   	// #0
    1224:	97fffcef 	bl	5e0 <pwrite@plt>
    1228:	7140041f 	cmp	w0, #0x1, lsl #12
    122c:	54fffdc1 	b.ne	11e4 <recover_db+0x164>  // b.any
    1230:	2a1503e0 	mov	w0, w21
    1234:	97fffccf 	bl	570 <fsync@plt>
    1238:	37fffd60 	tbnz	w0, #31, 11e4 <recover_db+0x164>
  if(verbose)
    123c:	340000d6 	cbz	w22, 1254 <recover_db+0x1d4>
    printf("minisqlite: WAL REDO tx=%l page=%d slot=%d\n",
    1240:	f9400e61 	ldr	x1, [x19, #24]
    1244:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    1248:	91225000 	add	x0, x0, #0x894
    124c:	29418e62 	ldp	w2, w3, [x19, #12]
    1250:	97fffcb4 	bl	520 <printf@plt>
  close(dbfd);
    1254:	2a1503e0 	mov	w0, w21
    1258:	97fffce6 	bl	5f0 <close@plt>
    125c:	17ffffc7 	b	1178 <recover_db+0xf8>
    return 0;
    1260:	52800014 	mov	w20, #0x0                   	// #0
    1264:	17ffffd0 	b	11a4 <recover_db+0x124>

0000000000001268 <delete_key>:
{
    1268:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    126c:	910003fd 	mov	x29, sp
    1270:	a90153f3 	stp	x19, x20, [sp, #16]
    1274:	a9025bf5 	stp	x21, x22, [sp, #32]
    1278:	2a0003f5 	mov	w21, w0
  if(recover_db(0) < 0)
    127c:	52800000 	mov	w0, #0x0                   	// #0
    1280:	97ffff80 	bl	1080 <recover_db>
    1284:	3100041f 	cmn	w0, #0x1
    1288:	540000e1 	b.ne	12a4 <delete_key+0x3c>  // b.any
    return -1;
    128c:	12800013 	mov	w19, #0xffffffff            	// #-1
}
    1290:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1294:	2a1303e0 	mov	w0, w19
    1298:	a94153f3 	ldp	x19, x20, [sp, #16]
    129c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    12a0:	d65f03c0 	ret
  int fd = open(DB_PATH, O_RDWR);
    12a4:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    12a8:	91202000 	add	x0, x0, #0x808
    12ac:	52800041 	mov	w1, #0x2                   	// #2
    12b0:	97fffcc4 	bl	5c0 <open@plt>
    12b4:	2a0003f4 	mov	w20, w0
  if(fd < 0 || read_header(fd, &hdr) < 0){
    12b8:	37fffea0 	tbnz	w0, #31, 128c <delete_key+0x24>
    12bc:	97fffe9e 	bl	d34 <read_header.constprop.0>
    12c0:	3100041f 	cmn	w0, #0x1
    12c4:	54000081 	b.ne	12d4 <delete_key+0x6c>  // b.any
    if(fd >= 0) close(fd);
    12c8:	2a1403e0 	mov	w0, w20
    12cc:	97fffcc9 	bl	5f0 <close@plt>
    12d0:	17ffffef 	b	128c <delete_key+0x24>
  int found = find_key(fd, key, &slotno, &slotbuf);
    12d4:	b0000013 	adrp	x19, 2000 <get_value.constprop.0+0x9d4>
    12d8:	91316273 	add	x19, x19, #0xc58
    12dc:	aa1303e3 	mov	x3, x19
    12e0:	9100f3e2 	add	x2, sp, #0x3c
    12e4:	2a1503e1 	mov	w1, w21
    12e8:	2a1403e0 	mov	w0, w20
    12ec:	97fffe4b 	bl	c18 <find_key>
    12f0:	2a0003f6 	mov	w22, w0
  if(found <= 0){
    12f4:	7100041f 	cmp	w0, #0x1
    12f8:	540000e0 	b.eq	1314 <delete_key+0xac>  // b.none
    close(fd);
    12fc:	2a1403e0 	mov	w0, w20
    1300:	97fffcbc 	bl	5f0 <close@plt>
    return -1;
    1304:	710002df 	cmp	w22, #0x0
    1308:	12800013 	mov	w19, #0xffffffff            	// #-1
    130c:	1a9f1673 	csinc	w19, w19, wzr, ne	// ne = any
    1310:	17ffffe0 	b	1290 <delete_key+0x28>
  memset(&slotbuf, 0, sizeof(slotbuf));
    1314:	52800802 	mov	w2, #0x40                  	// #64
    1318:	aa1303e0 	mov	x0, x19
    131c:	52800001 	mov	w1, #0x0                   	// #0
    1320:	97fffc8c 	bl	550 <memset@plt>
  slotbuf.state = SLOT_TOMB;
    1324:	52800040 	mov	w0, #0x2                   	// #2
    1328:	29005660 	stp	w0, w21, [x19]
  slotbuf.txid = hdr.txid + 1;
    132c:	90000020 	adrp	x0, 5000 <pagebuf+0x168>
    1330:	913a6000 	add	x0, x0, #0xe98
  s->checksum = hash_bytes(s, sizeof(*s));
    1334:	52800801 	mov	w1, #0x40                  	// #64
  int r = commit_slot(fd, slotno, &slotbuf, hdr.count - 1, 0);
    1338:	a9411800 	ldp	x0, x6, [x0, #16]
  s->checksum = 0;
    133c:	b9001a7f 	str	wzr, [x19, #24]
  slotbuf.txid = hdr.txid + 1;
    1340:	91000400 	add	x0, x0, #0x1
    1344:	f9000a60 	str	x0, [x19, #16]
  s->checksum = hash_bytes(s, sizeof(*s));
    1348:	aa1303e0 	mov	x0, x19
    134c:	97fffde6 	bl	ae4 <hash_bytes>
  int r = commit_slot(fd, slotno, &slotbuf, hdr.count - 1, 0);
    1350:	b9403fe1 	ldr	w1, [sp, #60]
    1354:	d10004c2 	sub	x2, x6, #0x1
    1358:	52800003 	mov	w3, #0x0                   	// #0
  s->checksum = hash_bytes(s, sizeof(*s));
    135c:	b9001a60 	str	w0, [x19, #24]
  int r = commit_slot(fd, slotno, &slotbuf, hdr.count - 1, 0);
    1360:	2a1403e0 	mov	w0, w20
    1364:	97fffe97 	bl	dc0 <commit_slot.constprop.0>
    1368:	2a0003f3 	mov	w19, w0
  close(fd);
    136c:	2a1403e0 	mov	w0, w20
    1370:	97fffca0 	bl	5f0 <close@plt>
  return r;
    1374:	17ffffc7 	b	1290 <delete_key+0x28>

0000000000001378 <put_value>:
{
    1378:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    137c:	910003fd 	mov	x29, sp
    1380:	a90153f3 	stp	x19, x20, [sp, #16]
    1384:	a9025bf5 	stp	x21, x22, [sp, #32]
    1388:	2a0203f6 	mov	w22, w2
    138c:	a90363f7 	stp	x23, x24, [sp, #48]
    1390:	2a0003f8 	mov	w24, w0
    1394:	aa0103f7 	mov	x23, x1
  if(recover_db(0) < 0)
    1398:	52800000 	mov	w0, #0x0                   	// #0
    139c:	97ffff39 	bl	1080 <recover_db>
    13a0:	2a0003f3 	mov	w19, w0
    13a4:	3100041f 	cmn	w0, #0x1
    13a8:	540001a0 	b.eq	13dc <put_value+0x64>  // b.none
  int fd = open(DB_PATH, O_RDWR);
    13ac:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    13b0:	91202000 	add	x0, x0, #0x808
    13b4:	52800041 	mov	w1, #0x2                   	// #2
    13b8:	97fffc82 	bl	5c0 <open@plt>
    13bc:	2a0003f5 	mov	w21, w0
  if(fd < 0 || read_header(fd, &hdr) < 0){
    13c0:	37f80600 	tbnz	w0, #31, 1480 <put_value+0x108>
    13c4:	97fffe5c 	bl	d34 <read_header.constprop.0>
    13c8:	2a0003f3 	mov	w19, w0
    13cc:	3100041f 	cmn	w0, #0x1
    13d0:	54000121 	b.ne	13f4 <put_value+0x7c>  // b.any
  close(fd);
    13d4:	2a1503e0 	mov	w0, w21
    13d8:	97fffc86 	bl	5f0 <close@plt>
}
    13dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    13e0:	2a1303e0 	mov	w0, w19
    13e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    13e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    13ec:	a8c57bfd 	ldp	x29, x30, [sp], #80
    13f0:	d65f03c0 	ret
  int found = find_key(fd, key, &slotno, 0);
    13f4:	910133e2 	add	x2, sp, #0x4c
    13f8:	2a1803e1 	mov	w1, w24
    13fc:	2a1503e0 	mov	w0, w21
    1400:	d2800003 	mov	x3, #0x0                   	// #0
    1404:	97fffe05 	bl	c18 <find_key>
    1408:	2a0003f3 	mov	w19, w0
  if(found < 0){
    140c:	3100041f 	cmn	w0, #0x1
    1410:	54fffe20 	b.eq	13d4 <put_value+0x5c>  // b.none
  memset(&slotbuf, 0, sizeof(slotbuf));
    1414:	b0000014 	adrp	x20, 2000 <get_value.constprop.0+0x9d4>
    1418:	91316294 	add	x20, x20, #0xc58
    141c:	52800802 	mov	w2, #0x40                  	// #64
    1420:	52800001 	mov	w1, #0x0                   	// #0
    1424:	aa1403e0 	mov	x0, x20
    1428:	97fffc4a 	bl	550 <memset@plt>
  slotbuf.txid = hdr.txid + 1;
    142c:	90000026 	adrp	x6, 5000 <pagebuf+0x168>
    1430:	913a60c6 	add	x6, x6, #0xe98
  slotbuf.state = SLOT_USED;
    1434:	52800020 	mov	w0, #0x1                   	// #1
    1438:	29006280 	stp	w0, w24, [x20]
  s->checksum = hash_bytes(s, sizeof(*s));
    143c:	52800801 	mov	w1, #0x40                  	// #64
  s->checksum = 0;
    1440:	b9001a9f 	str	wzr, [x20, #24]
  slotbuf.txid = hdr.txid + 1;
    1444:	f94008c0 	ldr	x0, [x6, #16]
  uint64 count = hdr.count + (found ? 0 : 1);
    1448:	52000273 	eor	w19, w19, #0x1
  slotbuf.txid = hdr.txid + 1;
    144c:	91000400 	add	x0, x0, #0x1
    1450:	a9008297 	stp	x23, x0, [x20, #8]
  s->checksum = hash_bytes(s, sizeof(*s));
    1454:	aa1403e0 	mov	x0, x20
    1458:	97fffda3 	bl	ae4 <hash_bytes>
  int r = commit_slot(fd, slotno, &slotbuf, count, stop_after_wal);
    145c:	b9404fe1 	ldr	w1, [sp, #76]
  uint64 count = hdr.count + (found ? 0 : 1);
    1460:	f9400cc2 	ldr	x2, [x6, #24]
  int r = commit_slot(fd, slotno, &slotbuf, count, stop_after_wal);
    1464:	2a1603e3 	mov	w3, w22
  s->checksum = hash_bytes(s, sizeof(*s));
    1468:	b9001a80 	str	w0, [x20, #24]
  int r = commit_slot(fd, slotno, &slotbuf, count, stop_after_wal);
    146c:	2a1503e0 	mov	w0, w21
    1470:	8b020262 	add	x2, x19, x2
    1474:	97fffe53 	bl	dc0 <commit_slot.constprop.0>
    1478:	2a0003f3 	mov	w19, w0
    147c:	17ffffd6 	b	13d4 <put_value+0x5c>
    return -1;
    1480:	12800013 	mov	w19, #0xffffffff            	// #-1
    1484:	17ffffd6 	b	13dc <put_value+0x64>

0000000000001488 <scan_db>:
{
    1488:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    148c:	910003fd 	mov	x29, sp
    1490:	a90153f3 	stp	x19, x20, [sp, #16]
    1494:	a9025bf5 	stp	x21, x22, [sp, #32]
    1498:	a90363f7 	stp	x23, x24, [sp, #48]
    149c:	2a0003f8 	mov	w24, w0
  if(recover_db(0) < 0)
    14a0:	52800000 	mov	w0, #0x0                   	// #0
{
    14a4:	a9046bf9 	stp	x25, x26, [sp, #64]
    14a8:	a90573fb 	stp	x27, x28, [sp, #80]
  if(recover_db(0) < 0)
    14ac:	97fffef5 	bl	1080 <recover_db>
    14b0:	2a0003f3 	mov	w19, w0
    14b4:	3100041f 	cmn	w0, #0x1
    14b8:	54000100 	b.eq	14d8 <scan_db+0x50>  // b.none
  int fd = open(DB_PATH, O_RDONLY);
    14bc:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    14c0:	91202000 	add	x0, x0, #0x808
    14c4:	52800001 	mov	w1, #0x0                   	// #0
    14c8:	97fffc3e 	bl	5c0 <open@plt>
    14cc:	2a0003f4 	mov	w20, w0
  if(fd < 0 || read_header(fd, &hdr) < 0){
    14d0:	36f80140 	tbz	w0, #31, 14f8 <scan_db+0x70>
    return -1;
    14d4:	12800013 	mov	w19, #0xffffffff            	// #-1
}
    14d8:	2a1303e0 	mov	w0, w19
    14dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    14e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    14e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    14e8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    14ec:	a94573fb 	ldp	x27, x28, [sp, #80]
    14f0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    14f4:	d65f03c0 	ret
  if(fd < 0 || read_header(fd, &hdr) < 0){
    14f8:	97fffe0f 	bl	d34 <read_header.constprop.0>
    14fc:	2a0003f3 	mov	w19, w0
    1500:	3100041f 	cmn	w0, #0x1
    1504:	54000081 	b.ne	1514 <scan_db+0x8c>  // b.any
    if(fd >= 0) close(fd);
    1508:	2a1403e0 	mov	w0, w20
    150c:	97fffc39 	bl	5f0 <close@plt>
    1510:	17fffff2 	b	14d8 <scan_db+0x50>
    if(pread(fd, pagebuf, PAGE_SIZE, off) != PAGE_SIZE){
    1514:	f0000016 	adrp	x22, 4000 <walbuf+0x168>
    1518:	913a62d6 	add	x22, x22, #0xe98
          printf("key=%d value=%l tx=%l page=%d slot=%d\n", s->key,
    151c:	90000019 	adrp	x25, 1000 <initialize+0x9c>
    1520:	91241b39 	add	x25, x25, #0x906
  if(fd < 0 || read_header(fd, &hdr) < 0){
    1524:	d2800013 	mov	x19, #0x0                   	// #0
  uint64 used = 0, tomb = 0;
    1528:	d2800017 	mov	x23, #0x0                   	// #0
    152c:	d2800015 	mov	x21, #0x0                   	// #0
    uint64 off = (uint64)PAGE_SIZE + (uint64)page * PAGE_SIZE;
    1530:	11000663 	add	w3, w19, #0x1
    1534:	2a1303fa 	mov	w26, w19
    1538:	9100067b 	add	x27, x19, #0x1
    if(pread(fd, pagebuf, PAGE_SIZE, off) != PAGE_SIZE){
    153c:	aa1603e1 	mov	x1, x22
    1540:	d374cc63 	lsl	x3, x3, #12
    1544:	2a1403e0 	mov	w0, w20
    1548:	52820002 	mov	w2, #0x1000                	// #4096
    154c:	97fffc0d 	bl	580 <pread@plt>
    1550:	7140041f 	cmp	w0, #0x1, lsl #12
    1554:	54000100 	b.eq	1574 <scan_db+0xec>  // b.none
      printf("minisqlite: cannot read page=%d\n", page);
    1558:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    155c:	91230000 	add	x0, x0, #0x8c0
    1560:	2a1303e1 	mov	w1, w19
    1564:	97fffbef 	bl	520 <printf@plt>
        close(fd);
    1568:	2a1403e0 	mov	w0, w20
    156c:	97fffc21 	bl	5f0 <close@plt>
        return -1;
    1570:	17ffffd9 	b	14d4 <scan_db+0x4c>
    1574:	aa1603f3 	mov	x19, x22
    for(uint j = 0; j < SLOTS_PER_PAGE; j++){
    1578:	5280001c 	mov	w28, #0x0                   	// #0
      if(!valid_slot(s)){
    157c:	aa1303e0 	mov	x0, x19
    1580:	97fffd66 	bl	b18 <valid_slot>
    1584:	350000e0 	cbnz	w0, 15a0 <scan_db+0x118>
        printf("minisqlite: corrupt slot=%d page=%d\n", j, page);
    1588:	2a1a03e2 	mov	w2, w26
    158c:	2a1c03e1 	mov	w1, w28
    1590:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    1594:	91238400 	add	x0, x0, #0x8e1
    1598:	97fffbe2 	bl	520 <printf@plt>
    159c:	17fffff3 	b	1568 <scan_db+0xe0>
      if(s->state == SLOT_USED){
    15a0:	b9400260 	ldr	w0, [x19]
    15a4:	7100041f 	cmp	w0, #0x1
    15a8:	540003c1 	b.ne	1620 <scan_db+0x198>  // b.any
        used++;
    15ac:	910006b5 	add	x21, x21, #0x1
        if(print_rows)
    15b0:	340000f8 	cbz	w24, 15cc <scan_db+0x144>
          printf("key=%d value=%l tx=%l page=%d slot=%d\n", s->key,
    15b4:	a9408e62 	ldp	x2, x3, [x19, #8]
    15b8:	2a1c03e5 	mov	w5, w28
    15bc:	b9400661 	ldr	w1, [x19, #4]
    15c0:	2a1a03e4 	mov	w4, w26
    15c4:	aa1903e0 	mov	x0, x25
    15c8:	97fffbd6 	bl	520 <printf@plt>
    for(uint j = 0; j < SLOTS_PER_PAGE; j++){
    15cc:	1100079c 	add	w28, w28, #0x1
    15d0:	91010273 	add	x19, x19, #0x40
    15d4:	7101039f 	cmp	w28, #0x40
    15d8:	54fffd21 	b.ne	157c <scan_db+0xf4>  // b.any
  for(uint page = 0; page < DB_PAGES; page++){
    15dc:	aa1b03f3 	mov	x19, x27
    15e0:	f104037f 	cmp	x27, #0x100
    15e4:	54fffa61 	b.ne	1530 <scan_db+0xa8>  // b.any
  printf("minisqlite: tx=%l header-count=%l scanned=%l tombstones=%l\n",
    15e8:	90000033 	adrp	x19, 5000 <pagebuf+0x168>
    15ec:	913a6273 	add	x19, x19, #0xe98
  close(fd);
    15f0:	2a1403e0 	mov	w0, w20
    15f4:	97fffbff 	bl	5f0 <close@plt>
  printf("minisqlite: tx=%l header-count=%l scanned=%l tombstones=%l\n",
    15f8:	aa1703e4 	mov	x4, x23
    15fc:	aa1503e3 	mov	x3, x21
    1600:	a9410a61 	ldp	x1, x2, [x19, #16]
    1604:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    1608:	9124b400 	add	x0, x0, #0x92d
    160c:	97fffbc5 	bl	520 <printf@plt>
  return used == hdr.count ? 0 : -1;
    1610:	f9400e60 	ldr	x0, [x19, #24]
    1614:	eb15001f 	cmp	x0, x21
    1618:	5a9f03f3 	csetm	w19, ne	// ne = any
    161c:	17ffffaf 	b	14d8 <scan_db+0x50>
        tomb++;
    1620:	7100081f 	cmp	w0, #0x2
    1624:	9a9716f7 	cinc	x23, x23, eq	// eq = none
    1628:	17ffffe9 	b	15cc <scan_db+0x144>

000000000000162c <get_value.constprop.0>:
get_value(uint32 key, uint64 *value)
    162c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1630:	910003fd 	mov	x29, sp
    1634:	a90153f3 	stp	x19, x20, [sp, #16]
    1638:	aa0103f4 	mov	x20, x1
    163c:	f90013f5 	str	x21, [sp, #32]
    1640:	2a0003f5 	mov	w21, w0
  if(recover_db(0) < 0)
    1644:	52800000 	mov	w0, #0x0                   	// #0
    1648:	97fffe8e 	bl	1080 <recover_db>
    164c:	3100041f 	cmn	w0, #0x1
    1650:	54000180 	b.eq	1680 <get_value.constprop.0+0x54>  // b.none
  int fd = open(DB_PATH, O_RDONLY);
    1654:	90000000 	adrp	x0, 1000 <initialize+0x9c>
    1658:	91202000 	add	x0, x0, #0x808
    165c:	52800001 	mov	w1, #0x0                   	// #0
    1660:	97fffbd8 	bl	5c0 <open@plt>
    1664:	2a0003f3 	mov	w19, w0
  if(fd < 0 || read_header(fd, &hdr) < 0){
    1668:	37f800c0 	tbnz	w0, #31, 1680 <get_value.constprop.0+0x54>
    166c:	97fffdb2 	bl	d34 <read_header.constprop.0>
    1670:	3100041f 	cmn	w0, #0x1
    1674:	54000101 	b.ne	1694 <get_value.constprop.0+0x68>  // b.any
    if(fd >= 0) close(fd);
    1678:	2a1303e0 	mov	w0, w19
    167c:	97fffbdd 	bl	5f0 <close@plt>
    return -1;
    1680:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    1684:	f94013f5 	ldr	x21, [sp, #32]
    1688:	a94153f3 	ldp	x19, x20, [sp, #16]
    168c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1690:	d65f03c0 	ret
  int found = find_key(fd, key, &slotno, &slotbuf);
    1694:	2a1503e1 	mov	w1, w21
    1698:	9100f3e2 	add	x2, sp, #0x3c
    169c:	b0000003 	adrp	x3, 2000 <get_value.constprop.0+0x9d4>
    16a0:	91316063 	add	x3, x3, #0xc58
    16a4:	2a1303e0 	mov	w0, w19
    16a8:	97fffd5c 	bl	c18 <find_key>
    16ac:	2a0003f5 	mov	w21, w0
  close(fd);
    16b0:	2a1303e0 	mov	w0, w19
    16b4:	97fffbcf 	bl	5f0 <close@plt>
  if(found == 1){
    16b8:	b0000000 	adrp	x0, 2000 <get_value.constprop.0+0x9d4>
    16bc:	91316003 	add	x3, x0, #0xc58
    16c0:	710006bf 	cmp	w21, #0x1
    16c4:	540000a1 	b.ne	16d8 <get_value.constprop.0+0xac>  // b.any
    *value = slotbuf.value;
    16c8:	f9400460 	ldr	x0, [x3, #8]
    16cc:	f9000280 	str	x0, [x20]
    return 0;
    16d0:	52800000 	mov	w0, #0x0                   	// #0
    16d4:	17ffffec 	b	1684 <get_value.constprop.0+0x58>
    return -1;
    16d8:	710002bf 	cmp	w21, #0x0
    16dc:	12800000 	mov	w0, #0xffffffff            	// #-1
    16e0:	1a9f1400 	csinc	w0, w0, wzr, ne	// ne = any
    16e4:	17ffffe8 	b	1684 <get_value.constprop.0+0x58>
