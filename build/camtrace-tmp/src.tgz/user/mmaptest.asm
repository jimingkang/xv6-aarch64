
user/_mmaptest:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000006f8 <.plt>:
 6f8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 6fc:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 700:	f940ea11 	ldr	x17, [x16, #464]
 704:	91074210 	add	x16, x16, #0x1d0
 708:	d61f0220 	br	x17
 70c:	d503201f 	nop
 710:	d503201f 	nop
 714:	d503201f 	nop

0000000000000718 <strcpy@plt>:
 718:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 71c:	f940ee11 	ldr	x17, [x16, #472]
 720:	91076210 	add	x16, x16, #0x1d8
 724:	d61f0220 	br	x17

0000000000000728 <ioctl@plt>:
 728:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 72c:	f940f211 	ldr	x17, [x16, #480]
 730:	91078210 	add	x16, x16, #0x1e0
 734:	d61f0220 	br	x17

0000000000000738 <printf@plt>:
 738:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 73c:	f940f611 	ldr	x17, [x16, #488]
 740:	9107a210 	add	x16, x16, #0x1e8
 744:	d61f0220 	br	x17

0000000000000748 <memmove@plt>:
 748:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 74c:	f940fa11 	ldr	x17, [x16, #496]
 750:	9107c210 	add	x16, x16, #0x1f0
 754:	d61f0220 	br	x17

0000000000000758 <munmap@plt>:
 758:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 75c:	f940fe11 	ldr	x17, [x16, #504]
 760:	9107e210 	add	x16, x16, #0x1f8
 764:	d61f0220 	br	x17

0000000000000768 <sleep@plt>:
 768:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 76c:	f9410211 	ldr	x17, [x16, #512]
 770:	91080210 	add	x16, x16, #0x200
 774:	d61f0220 	br	x17

0000000000000778 <mmap@plt>:
 778:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 77c:	f9410611 	ldr	x17, [x16, #520]
 780:	91082210 	add	x16, x16, #0x208
 784:	d61f0220 	br	x17

0000000000000788 <pipe@plt>:
 788:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 78c:	f9410a11 	ldr	x17, [x16, #528]
 790:	91084210 	add	x16, x16, #0x210
 794:	d61f0220 	br	x17

0000000000000798 <write@plt>:
 798:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 79c:	f9410e11 	ldr	x17, [x16, #536]
 7a0:	91086210 	add	x16, x16, #0x218
 7a4:	d61f0220 	br	x17

00000000000007a8 <fstat@plt>:
 7a8:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 7ac:	f9411211 	ldr	x17, [x16, #544]
 7b0:	91088210 	add	x16, x16, #0x220
 7b4:	d61f0220 	br	x17

00000000000007b8 <wait@plt>:
 7b8:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 7bc:	f9411611 	ldr	x17, [x16, #552]
 7c0:	9108a210 	add	x16, x16, #0x228
 7c4:	d61f0220 	br	x17

00000000000007c8 <read@plt>:
 7c8:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 7cc:	f9411a11 	ldr	x17, [x16, #560]
 7d0:	9108c210 	add	x16, x16, #0x230
 7d4:	d61f0220 	br	x17

00000000000007d8 <unlink@plt>:
 7d8:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 7dc:	f9411e11 	ldr	x17, [x16, #568]
 7e0:	9108e210 	add	x16, x16, #0x238
 7e4:	d61f0220 	br	x17

00000000000007e8 <memcmp@plt>:
 7e8:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 7ec:	f9412211 	ldr	x17, [x16, #576]
 7f0:	91090210 	add	x16, x16, #0x240
 7f4:	d61f0220 	br	x17

00000000000007f8 <fork@plt>:
 7f8:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 7fc:	f9412611 	ldr	x17, [x16, #584]
 800:	91092210 	add	x16, x16, #0x248
 804:	d61f0220 	br	x17

0000000000000808 <strcmp@plt>:
 808:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 80c:	f9412a11 	ldr	x17, [x16, #592]
 810:	91094210 	add	x16, x16, #0x250
 814:	d61f0220 	br	x17

0000000000000818 <msync@plt>:
 818:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 81c:	f9412e11 	ldr	x17, [x16, #600]
 820:	91096210 	add	x16, x16, #0x258
 824:	d61f0220 	br	x17

0000000000000828 <vfork@plt>:
 828:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 82c:	f9413211 	ldr	x17, [x16, #608]
 830:	91098210 	add	x16, x16, #0x260
 834:	d61f0220 	br	x17

0000000000000838 <pread@plt>:
 838:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 83c:	f9413611 	ldr	x17, [x16, #616]
 840:	9109a210 	add	x16, x16, #0x268
 844:	d61f0220 	br	x17

0000000000000848 <exit@plt>:
 848:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 84c:	f9413a11 	ldr	x17, [x16, #624]
 850:	9109c210 	add	x16, x16, #0x270
 854:	d61f0220 	br	x17

0000000000000858 <open@plt>:
 858:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 85c:	f9413e11 	ldr	x17, [x16, #632]
 860:	9109e210 	add	x16, x16, #0x278
 864:	d61f0220 	br	x17

0000000000000868 <close@plt>:
 868:	f0000010 	adrp	x16, 3000 <make_file.constprop.0+0x1790>
 86c:	f9414211 	ldr	x17, [x16, #640]
 870:	910a0210 	add	x16, x16, #0x280
 874:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000878 <main>:
  return 0;
}

int
main(int argc, char **argv)
{
     878:	a9b77bfd 	stp	x29, x30, [sp, #-144]!
     87c:	910003fd 	mov	x29, sp
     880:	a90153f3 	stp	x19, x20, [sp, #16]
     884:	a9025bf5 	stp	x21, x22, [sp, #32]
     888:	a90363f7 	stp	x23, x24, [sp, #48]
     88c:	a9046bf9 	stp	x25, x26, [sp, #64]
  if(argc > 1 && strcmp(argv[1], "fb") == 0)
     890:	7100041f 	cmp	w0, #0x1
     894:	5400016d 	b.le	8c0 <main+0x48>
     898:	aa0103e2 	mov	x2, x1
     89c:	b0000001 	adrp	x1, 1000 <main+0x788>
     8a0:	912bd821 	add	x1, x1, #0xaf6
     8a4:	f9400440 	ldr	x0, [x2, #8]
     8a8:	97ffffd8 	bl	808 <strcmp@plt>
     8ac:	350000a0 	cbnz	w0, 8c0 <main+0x48>
    exit(test_fb() < 0);
     8b0:	9400036a 	bl	1658 <test_fb>
     8b4:	3100041f 	cmn	w0, #0x1
     8b8:	1a9f17e0 	cset	w0, eq	// eq = none
    exit(0);
     8bc:	97ffffe3 	bl	848 <exit@plt>
  char *p = mmap(0, 3 * PG, PROT_READ | PROT_WRITE,
     8c0:	d2860001 	mov	x1, #0x3000                	// #12288
     8c4:	d2800005 	mov	x5, #0x0                   	// #0
     8c8:	12800004 	mov	w4, #0xffffffff            	// #-1
     8cc:	52800443 	mov	w3, #0x22                  	// #34
     8d0:	52800062 	mov	w2, #0x3                   	// #3
     8d4:	d2800000 	mov	x0, #0x0                   	// #0
     8d8:	97ffffa8 	bl	778 <mmap@plt>
  int ok = p != MAP_FAILED;
     8dc:	b100041f 	cmn	x0, #0x1
  char *p = mmap(0, 3 * PG, PROT_READ | PROT_WRITE,
     8e0:	aa0003f3 	mov	x19, x0
  check(ok, "anon: mmap 3 pages");
     8e4:	b0000001 	adrp	x1, 1000 <main+0x788>
     8e8:	912be421 	add	x1, x1, #0xaf9
     8ec:	1a9f07e0 	cset	w0, ne	// ne = any
     8f0:	940002b2 	bl	13b8 <check>
  if(!ok)
     8f4:	b100067f 	cmn	x19, #0x1
     8f8:	54000e80 	b.eq	ac8 <main+0x250>  // b.none
  ok = p[0] == 0 && p[PG] == 0 && p[3 * PG - 1] == 0;
     8fc:	39400260 	ldrb	w0, [x19]
     900:	35000080 	cbnz	w0, 910 <main+0x98>
     904:	91400660 	add	x0, x19, #0x1, lsl #12
     908:	39400000 	ldrb	w0, [x0]
     90c:	34001620 	cbz	w0, bd0 <main+0x358>
     910:	52800000 	mov	w0, #0x0                   	// #0
     914:	d2800001 	mov	x1, #0x0                   	// #0
  return 'A' + i % 23;
     918:	528002e3 	mov	w3, #0x17                  	// #23
     91c:	1ac30822 	udiv	w2, w1, w3
     920:	1b038442 	msub	w2, w2, w3, w1
     924:	11010442 	add	w2, w2, #0x41
    p[i] = pattern(i);
     928:	38216a62 	strb	w2, [x19, x1]
  for(int i = 0; i < 3 * PG; i++)
     92c:	91000421 	add	x1, x1, #0x1
     930:	f1400c3f 	cmp	x1, #0x3, lsl #12
     934:	54ffff41 	b.ne	91c <main+0xa4>  // b.any
     938:	d2800001 	mov	x1, #0x0                   	// #0
  return 'A' + i % 23;
     93c:	528002e3 	mov	w3, #0x17                  	// #23
     940:	1ac30822 	udiv	w2, w1, w3
    if(p[i] != pattern(i))
     944:	38616a64 	ldrb	w4, [x19, x1]
  return 'A' + i % 23;
     948:	1b038442 	msub	w2, w2, w3, w1
  for(int i = 0; i < 3 * PG; i++)
     94c:	91000421 	add	x1, x1, #0x1
  return 'A' + i % 23;
     950:	11010442 	add	w2, w2, #0x41
    if(p[i] != pattern(i))
     954:	6b22009f 	cmp	w4, w2, uxtb
     958:	1a9f17e2 	cset	w2, eq	// eq = none
     95c:	0a020000 	and	w0, w0, w2
  for(int i = 0; i < 3 * PG; i++)
     960:	f1400c3f 	cmp	x1, #0x3, lsl #12
     964:	54fffee1 	b.ne	940 <main+0xc8>  // b.any
  check(munmap(p + PG, PG) == 0, "anon: munmap middle page");
     968:	91400675 	add	x21, x19, #0x1, lsl #12
  check(ok, "anon: zero-filled on first touch, then read back");
     96c:	b0000001 	adrp	x1, 1000 <main+0x788>
     970:	912c3021 	add	x1, x1, #0xb0c
     974:	94000291 	bl	13b8 <check>
  check(munmap(p + PG, PG) == 0, "anon: munmap middle page");
     978:	d2820001 	mov	x1, #0x1000                	// #4096
     97c:	aa1503e0 	mov	x0, x21
     980:	97ffff76 	bl	758 <munmap@plt>
     984:	7100001f 	cmp	w0, #0x0
     988:	1a9f17e0 	cset	w0, eq	// eq = none
     98c:	b0000001 	adrp	x1, 1000 <main+0x788>
     990:	912cf421 	add	x1, x1, #0xb3d
     994:	94000289 	bl	13b8 <check>
  check(p[0] == pattern(0) && p[2 * PG] == pattern(2 * PG),
     998:	39400260 	ldrb	w0, [x19]
     99c:	7101041f 	cmp	w0, #0x41
     9a0:	54001221 	b.ne	be4 <main+0x36c>  // b.any
     9a4:	91400a60 	add	x0, x19, #0x2, lsl #12
     9a8:	39400000 	ldrb	w0, [x0]
     9ac:	7101141f 	cmp	w0, #0x45
     9b0:	1a9f17e0 	cset	w0, eq	// eq = none
     9b4:	b0000001 	adrp	x1, 1000 <main+0x788>
     9b8:	912d5821 	add	x1, x1, #0xb56
     9bc:	9400027f 	bl	13b8 <check>
  check(child_faults(touch_read, p + PG), "anon: access to the hole faults");
     9c0:	b0000014 	adrp	x20, 1000 <main+0x788>
     9c4:	aa1503e1 	mov	x1, x21
     9c8:	910d5280 	add	x0, x20, #0x354
     9cc:	94000395 	bl	1820 <child_faults>
     9d0:	b0000001 	adrp	x1, 1000 <main+0x788>
     9d4:	912de821 	add	x1, x1, #0xb7a
     9d8:	94000278 	bl	13b8 <check>
  check(munmap(p, 3 * PG) == 0, "anon: munmap the rest");
     9dc:	aa1303e0 	mov	x0, x19
     9e0:	d2860001 	mov	x1, #0x3000                	// #12288
     9e4:	97ffff5d 	bl	758 <munmap@plt>
     9e8:	7100001f 	cmp	w0, #0x0
     9ec:	1a9f17e0 	cset	w0, eq	// eq = none
     9f0:	b0000001 	adrp	x1, 1000 <main+0x788>
     9f4:	912e6821 	add	x1, x1, #0xb9a
     9f8:	94000270 	bl	13b8 <check>
  check(child_faults(touch_read, p), "anon: access after munmap faults");
     9fc:	aa1303e1 	mov	x1, x19
     a00:	910d5280 	add	x0, x20, #0x354
     a04:	94000387 	bl	1820 <child_faults>
     a08:	b0000001 	adrp	x1, 1000 <main+0x788>
     a0c:	912ec021 	add	x1, x1, #0xbb0
     a10:	9400026a 	bl	13b8 <check>
  char *r = mmap(0, PG, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
     a14:	d2800005 	mov	x5, #0x0                   	// #0
     a18:	12800004 	mov	w4, #0xffffffff            	// #-1
     a1c:	52800443 	mov	w3, #0x22                  	// #34
     a20:	52800022 	mov	w2, #0x1                   	// #1
     a24:	d2820001 	mov	x1, #0x1000                	// #4096
     a28:	d2800000 	mov	x0, #0x0                   	// #0
     a2c:	97ffff53 	bl	778 <mmap@plt>
     a30:	aa0003f3 	mov	x19, x0
  check(r != MAP_FAILED && child_faults(touch_write, r),
     a34:	b100041f 	cmn	x0, #0x1
     a38:	54000da0 	b.eq	bec <main+0x374>  // b.none
     a3c:	b0000000 	adrp	x0, 1000 <main+0x788>
     a40:	910db000 	add	x0, x0, #0x36c
     a44:	aa1303e1 	mov	x1, x19
     a48:	94000376 	bl	1820 <child_faults>
     a4c:	b0000001 	adrp	x1, 1000 <main+0x788>
     a50:	912f4421 	add	x1, x1, #0xbd1
     a54:	94000259 	bl	13b8 <check>
  check(f == want, "anon: MAP_FIXED honours the address");
     a58:	d2c00414 	mov	x20, #0x2000000000          	// #137438953472
  munmap(r, PG);
     a5c:	aa1303e0 	mov	x0, x19
     a60:	d2820001 	mov	x1, #0x1000                	// #4096
     a64:	97ffff3d 	bl	758 <munmap@plt>
  char *f = mmap(want, PG, PROT_READ | PROT_WRITE,
     a68:	d2820001 	mov	x1, #0x1000                	// #4096
     a6c:	d2800005 	mov	x5, #0x0                   	// #0
     a70:	12800004 	mov	w4, #0xffffffff            	// #-1
     a74:	52800643 	mov	w3, #0x32                  	// #50
     a78:	52800062 	mov	w2, #0x3                   	// #3
     a7c:	d2c00400 	mov	x0, #0x2000000000          	// #137438953472
     a80:	97ffff3e 	bl	778 <mmap@plt>
  check(f == want, "anon: MAP_FIXED honours the address");
     a84:	eb14001f 	cmp	x0, x20
  char *f = mmap(want, PG, PROT_READ | PROT_WRITE,
     a88:	aa0003f3 	mov	x19, x0
  check(f == want, "anon: MAP_FIXED honours the address");
     a8c:	b0000001 	adrp	x1, 1000 <main+0x788>
     a90:	912fc421 	add	x1, x1, #0xbf1
     a94:	1a9f17e0 	cset	w0, eq	// eq = none
     a98:	94000248 	bl	13b8 <check>
  if(f == want){
     a9c:	eb14027f 	cmp	x19, x20
     aa0:	54000141 	b.ne	ac8 <main+0x250>  // b.any
    f[10] = 7;
     aa4:	528000e0 	mov	w0, #0x7                   	// #7
     aa8:	39002a60 	strb	w0, [x19, #10]
    check(f[10] == 7, "anon: MAP_FIXED page usable");
     aac:	b0000001 	adrp	x1, 1000 <main+0x788>
     ab0:	91305421 	add	x1, x1, #0xc15
     ab4:	52800020 	mov	w0, #0x1                   	// #1
     ab8:	94000240 	bl	13b8 <check>
    munmap(f, PG);
     abc:	aa1303e0 	mov	x0, x19
     ac0:	d2820001 	mov	x1, #0x1000                	// #4096
     ac4:	97ffff25 	bl	758 <munmap@plt>
  test_anon();
  test_fork();
     ac8:	94000252 	bl	1410 <test_fork>
  if(make_file(FILE1, size) < 0 || (fd = open(FILE1, O_RDONLY)) < 0){
     acc:	94000369 	bl	1870 <make_file.constprop.0>
     ad0:	3100041f 	cmn	w0, #0x1
     ad4:	54000100 	b.eq	af4 <main+0x27c>  // b.none
     ad8:	b0000014 	adrp	x20, 1000 <main+0x788>
     adc:	91253294 	add	x20, x20, #0x94c
     ae0:	aa1403e0 	mov	x0, x20
     ae4:	52800001 	mov	w1, #0x0                   	// #0
     ae8:	97ffff5c 	bl	858 <open@plt>
     aec:	2a0003f5 	mov	w21, w0
     af0:	36f80820 	tbz	w0, #31, bf4 <main+0x37c>
    check(0, "file private: create test file");
     af4:	b0000001 	adrp	x1, 1000 <main+0x788>
     af8:	9130c421 	add	x1, x1, #0xc31
     afc:	52800000 	mov	w0, #0x0                   	// #0
     b00:	9400022e 	bl	13b8 <check>
  if(make_file(FILE1, size) < 0 || (fd = open(FILE1, O_RDWR)) < 0){
     b04:	9400035b 	bl	1870 <make_file.constprop.0>
     b08:	3100041f 	cmn	w0, #0x1
     b0c:	54000100 	b.eq	b2c <main+0x2b4>  // b.none
     b10:	b0000015 	adrp	x21, 1000 <main+0x788>
     b14:	912532b5 	add	x21, x21, #0x94c
     b18:	aa1503e0 	mov	x0, x21
     b1c:	52800041 	mov	w1, #0x2                   	// #2
     b20:	97ffff4e 	bl	858 <open@plt>
     b24:	2a0003f3 	mov	w19, w0
     b28:	36f815e0 	tbz	w0, #31, de4 <main+0x56c>
    check(0, "file shared: create test file");
     b2c:	b0000001 	adrp	x1, 1000 <main+0x788>
     b30:	9135f421 	add	x1, x1, #0xd7d
     b34:	52800000 	mov	w0, #0x0                   	// #0
     b38:	94000220 	bl	13b8 <check>
  if((fd = open("/dev/zero", O_RDWR)) < 0){
     b3c:	b0000000 	adrp	x0, 1000 <main+0x788>
     b40:	913e6000 	add	x0, x0, #0xf98
     b44:	52800041 	mov	w1, #0x2                   	// #2
     b48:	97ffff44 	bl	858 <open@plt>
     b4c:	2a0003f4 	mov	w20, w0
     b50:	36f834a0 	tbz	w0, #31, 11e4 <main+0x96c>
    check(0, "dev/zero: open");
     b54:	b0000001 	adrp	x1, 1000 <main+0x788>
     b58:	913e8821 	add	x1, x1, #0xfa2
     b5c:	52800000 	mov	w0, #0x0                   	// #0
     b60:	94000216 	bl	13b8 <check>
  if((fd = open("/dev/mem", O_RDWR)) < 0){
     b64:	b0000000 	adrp	x0, 1000 <main+0x788>
     b68:	913fa400 	add	x0, x0, #0xfe9
     b6c:	52800041 	mov	w1, #0x2                   	// #2
     b70:	97ffff3a 	bl	858 <open@plt>
     b74:	2a0003f4 	mov	w20, w0
     b78:	36f83840 	tbz	w0, #31, 1280 <main+0xa08>
    check(0, "dev/mem: open");
     b7c:	b0000001 	adrp	x1, 1000 <main+0x788>
     b80:	913fc821 	add	x1, x1, #0xff2
     b84:	52800000 	mov	w0, #0x0                   	// #0
     b88:	9400020c 	bl	13b8 <check>
  test_file_private();
  test_file_shared();
  test_devices();
  test_fb();
     b8c:	940002b3 	bl	1658 <test_fb>
  printf("mmaptest: %s (%d failure%s)\n", failures ? "FAILED" : "OK",
     b90:	f0000013 	adrp	x19, 3000 <make_file.constprop.0+0x1790>
     b94:	b9428a62 	ldr	w2, [x19, #648]
     b98:	34003d42 	cbz	w2, 1340 <main+0xac8>
     b9c:	b0000001 	adrp	x1, 1000 <main+0x788>
     ba0:	912bb021 	add	x1, x1, #0xaec
     ba4:	7100045f 	cmp	w2, #0x1
     ba8:	54003d01 	b.ne	1348 <main+0xad0>  // b.any
     bac:	d0000003 	adrp	x3, 2000 <make_file.constprop.0+0x790>
     bb0:	91025863 	add	x3, x3, #0x96
     bb4:	d0000000 	adrp	x0, 2000 <make_file.constprop.0+0x790>
     bb8:	9101e800 	add	x0, x0, #0x7a
     bbc:	97fffedf 	bl	738 <printf@plt>
         failures, failures == 1 ? "" : "s");
  exit(failures != 0);
     bc0:	b9428a60 	ldr	w0, [x19, #648]
     bc4:	7100001f 	cmp	w0, #0x0
     bc8:	1a9f07e0 	cset	w0, ne	// ne = any
     bcc:	17ffff3c 	b	8bc <main+0x44>
  ok = p[0] == 0 && p[PG] == 0 && p[3 * PG - 1] == 0;
     bd0:	91400a60 	add	x0, x19, #0x2, lsl #12
     bd4:	397ffc00 	ldrb	w0, [x0, #4095]
     bd8:	7100001f 	cmp	w0, #0x0
     bdc:	1a9f17e0 	cset	w0, eq	// eq = none
     be0:	17ffff4d 	b	914 <main+0x9c>
  check(p[0] == pattern(0) && p[2 * PG] == pattern(2 * PG),
     be4:	52800000 	mov	w0, #0x0                   	// #0
     be8:	17ffff73 	b	9b4 <main+0x13c>
  check(r != MAP_FAILED && child_faults(touch_write, r),
     bec:	52800000 	mov	w0, #0x0                   	// #0
     bf0:	17ffff97 	b	a4c <main+0x1d4>
  char *p = mmap(0, 3 * PG, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
     bf4:	2a0003e4 	mov	w4, w0
     bf8:	d2860001 	mov	x1, #0x3000                	// #12288
     bfc:	d2800005 	mov	x5, #0x0                   	// #0
     c00:	52800043 	mov	w3, #0x2                   	// #2
     c04:	52800062 	mov	w2, #0x3                   	// #3
     c08:	d2800000 	mov	x0, #0x0                   	// #0
     c0c:	97fffedb 	bl	778 <mmap@plt>
     c10:	aa0003f3 	mov	x19, x0
  close(fd);                          // the mapping keeps the file
     c14:	2a1503e0 	mov	w0, w21
     c18:	97ffff14 	bl	868 <close@plt>
  check(p != MAP_FAILED, "file private: mmap O_RDONLY file, PROT_WRITE");
     c1c:	b100067f 	cmn	x19, #0x1
     c20:	b0000001 	adrp	x1, 1000 <main+0x788>
     c24:	91314021 	add	x1, x1, #0xc50
     c28:	1a9f07e0 	cset	w0, ne	// ne = any
     c2c:	940001e3 	bl	13b8 <check>
  if(p == MAP_FAILED)
     c30:	b100067f 	cmn	x19, #0x1
     c34:	54fff680 	b.eq	b04 <main+0x28c>  // b.none
     c38:	d2800001 	mov	x1, #0x0                   	// #0
  int size = 2 * PG + 100, fd, ok = 1;
     c3c:	52800020 	mov	w0, #0x1                   	// #1
  return 'A' + i % 23;
     c40:	528002e3 	mov	w3, #0x17                  	// #23
  for(int i = 0; i < size; i++)
     c44:	d2840c84 	mov	x4, #0x2064                	// #8292
  return 'A' + i % 23;
     c48:	1ac30822 	udiv	w2, w1, w3
    if(p[i] != pattern(i))
     c4c:	38616a65 	ldrb	w5, [x19, x1]
  return 'A' + i % 23;
     c50:	1b038442 	msub	w2, w2, w3, w1
  for(int i = 0; i < size; i++)
     c54:	91000421 	add	x1, x1, #0x1
  return 'A' + i % 23;
     c58:	11010442 	add	w2, w2, #0x41
    if(p[i] != pattern(i))
     c5c:	6b2200bf 	cmp	w5, w2, uxtb
     c60:	1a9f17e2 	cset	w2, eq	// eq = none
     c64:	0a020000 	and	w0, w0, w2
  for(int i = 0; i < size; i++)
     c68:	eb04003f 	cmp	x1, x4
     c6c:	54fffee1 	b.ne	c48 <main+0x3d0>  // b.any
  check(ok, "file private: contents match the file (after close(fd))");
     c70:	b0000001 	adrp	x1, 1000 <main+0x788>
     c74:	9131f421 	add	x1, x1, #0xc7d
     c78:	940001d0 	bl	13b8 <check>
  check(p[size] == 0 && p[3 * PG - 1] == 0,
     c7c:	91400a60 	add	x0, x19, #0x2, lsl #12
     c80:	39419001 	ldrb	w1, [x0, #100]
     c84:	35000a01 	cbnz	w1, dc4 <main+0x54c>
     c88:	397ffc00 	ldrb	w0, [x0, #4095]
     c8c:	7100001f 	cmp	w0, #0x0
     c90:	1a9f17e0 	cset	w0, eq	// eq = none
     c94:	b0000001 	adrp	x1, 1000 <main+0x788>
     c98:	9132d421 	add	x1, x1, #0xcb5
     c9c:	940001c7 	bl	13b8 <check>
  p[0] = 'z';
     ca0:	52800f40 	mov	w0, #0x7a                  	// #122
     ca4:	39000260 	strb	w0, [x19]
  munmap(p, 3 * PG);
     ca8:	d2860001 	mov	x1, #0x3000                	// #12288
     cac:	aa1303e0 	mov	x0, x19
     cb0:	97fffeaa 	bl	758 <munmap@plt>
  fd = open(FILE1, O_RDONLY);
     cb4:	52800001 	mov	w1, #0x0                   	// #0
     cb8:	aa1403e0 	mov	x0, x20
     cbc:	97fffee7 	bl	858 <open@plt>
     cc0:	2a0003f3 	mov	w19, w0
  check(read(fd, buf, 1) == 1 && buf[0] == pattern(0),
     cc4:	9101c3e1 	add	x1, sp, #0x70
     cc8:	52800022 	mov	w2, #0x1                   	// #1
     ccc:	97fffebf 	bl	7c8 <read@plt>
     cd0:	7100041f 	cmp	w0, #0x1
     cd4:	540007c1 	b.ne	dcc <main+0x554>  // b.any
     cd8:	3941c3e0 	ldrb	w0, [sp, #112]
     cdc:	7101041f 	cmp	w0, #0x41
     ce0:	1a9f17e0 	cset	w0, eq	// eq = none
     ce4:	b0000001 	adrp	x1, 1000 <main+0x788>
     ce8:	91337421 	add	x1, x1, #0xcdd
     cec:	940001b3 	bl	13b8 <check>
  close(fd);
     cf0:	2a1303e0 	mov	w0, w19
     cf4:	97fffedd 	bl	868 <close@plt>
  fd = open(FILE1, O_RDONLY);
     cf8:	aa1403e0 	mov	x0, x20
     cfc:	52800001 	mov	w1, #0x0                   	// #0
     d00:	97fffed6 	bl	858 <open@plt>
  p = mmap(0, PG, PROT_READ, MAP_PRIVATE, fd, PG);
     d04:	2a0003e4 	mov	w4, w0
     d08:	d2820005 	mov	x5, #0x1000                	// #4096
  fd = open(FILE1, O_RDONLY);
     d0c:	2a0003f3 	mov	w19, w0
  p = mmap(0, PG, PROT_READ, MAP_PRIVATE, fd, PG);
     d10:	aa0503e1 	mov	x1, x5
     d14:	52800043 	mov	w3, #0x2                   	// #2
     d18:	52800022 	mov	w2, #0x1                   	// #1
     d1c:	d2800000 	mov	x0, #0x0                   	// #0
     d20:	97fffe96 	bl	778 <mmap@plt>
     d24:	aa0003f4 	mov	x20, x0
  check(p != MAP_FAILED && p[0] == pattern(PG) && p[99] == pattern(PG + 99),
     d28:	b100041f 	cmn	x0, #0x1
     d2c:	54000080 	b.eq	d3c <main+0x4c4>  // b.none
     d30:	39400000 	ldrb	w0, [x0]
     d34:	71010c1f 	cmp	w0, #0x43
     d38:	540004e0 	b.eq	dd4 <main+0x55c>  // b.none
     d3c:	52800000 	mov	w0, #0x0                   	// #0
     d40:	b0000001 	adrp	x1, 1000 <main+0x788>
     d44:	91341c21 	add	x1, x1, #0xd07
     d48:	9400019c 	bl	13b8 <check>
  munmap(p, PG);
     d4c:	aa1403e0 	mov	x0, x20
     d50:	d2820001 	mov	x1, #0x1000                	// #4096
     d54:	97fffe81 	bl	758 <munmap@plt>
  check(mmap(0, PG, PROT_READ, MAP_PRIVATE, fd, 100) == MAP_FAILED,
     d58:	2a1303e4 	mov	w4, w19
     d5c:	d2800c85 	mov	x5, #0x64                  	// #100
     d60:	52800043 	mov	w3, #0x2                   	// #2
     d64:	52800022 	mov	w2, #0x1                   	// #1
     d68:	d2820001 	mov	x1, #0x1000                	// #4096
     d6c:	d2800000 	mov	x0, #0x0                   	// #0
     d70:	97fffe82 	bl	778 <mmap@plt>
     d74:	b100041f 	cmn	x0, #0x1
     d78:	1a9f17e0 	cset	w0, eq	// eq = none
     d7c:	b0000001 	adrp	x1, 1000 <main+0x788>
     d80:	91349421 	add	x1, x1, #0xd25
     d84:	9400018d 	bl	13b8 <check>
  check(mmap(0, PG, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0) == MAP_FAILED,
     d88:	2a1303e4 	mov	w4, w19
     d8c:	d2800005 	mov	x5, #0x0                   	// #0
     d90:	52800023 	mov	w3, #0x1                   	// #1
     d94:	52800062 	mov	w2, #0x3                   	// #3
     d98:	d2820001 	mov	x1, #0x1000                	// #4096
     d9c:	d2800000 	mov	x0, #0x0                   	// #0
     da0:	97fffe76 	bl	778 <mmap@plt>
     da4:	b100041f 	cmn	x0, #0x1
     da8:	b0000001 	adrp	x1, 1000 <main+0x788>
     dac:	91353421 	add	x1, x1, #0xd4d
     db0:	1a9f17e0 	cset	w0, eq	// eq = none
     db4:	94000181 	bl	13b8 <check>
  close(fd);
     db8:	2a1303e0 	mov	w0, w19
     dbc:	97fffeab 	bl	868 <close@plt>
     dc0:	17ffff51 	b	b04 <main+0x28c>
  check(p[size] == 0 && p[3 * PG - 1] == 0,
     dc4:	52800000 	mov	w0, #0x0                   	// #0
     dc8:	17ffffb3 	b	c94 <main+0x41c>
  check(read(fd, buf, 1) == 1 && buf[0] == pattern(0),
     dcc:	52800000 	mov	w0, #0x0                   	// #0
     dd0:	17ffffc5 	b	ce4 <main+0x46c>
  check(p != MAP_FAILED && p[0] == pattern(PG) && p[99] == pattern(PG + 99),
     dd4:	39418e80 	ldrb	w0, [x20, #99]
     dd8:	7101281f 	cmp	w0, #0x4a
     ddc:	1a9f17e0 	cset	w0, eq	// eq = none
     de0:	17ffffd8 	b	d40 <main+0x4c8>
  char *p = mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
     de4:	2a0003e4 	mov	w4, w0
     de8:	d2840c81 	mov	x1, #0x2064                	// #8292
     dec:	d2800005 	mov	x5, #0x0                   	// #0
     df0:	52800023 	mov	w3, #0x1                   	// #1
     df4:	52800062 	mov	w2, #0x3                   	// #3
     df8:	d2800000 	mov	x0, #0x0                   	// #0
     dfc:	97fffe5f 	bl	778 <mmap@plt>
  check(p != MAP_FAILED, "file shared: mmap");
     e00:	b100041f 	cmn	x0, #0x1
  char *p = mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
     e04:	aa0003f4 	mov	x20, x0
  check(p != MAP_FAILED, "file shared: mmap");
     e08:	b0000001 	adrp	x1, 1000 <main+0x788>
     e0c:	91366c21 	add	x1, x1, #0xd9b
     e10:	1a9f07e0 	cset	w0, ne	// ne = any
     e14:	94000169 	bl	13b8 <check>
  if(p == MAP_FAILED){
     e18:	b100069f 	cmn	x20, #0x1
     e1c:	54000081 	b.ne	e2c <main+0x5b4>  // b.any
    close(fd);
     e20:	2a1303e0 	mov	w0, w19
     e24:	97fffe91 	bl	868 <close@plt>
    return;
     e28:	17ffff45 	b	b3c <main+0x2c4>
  check(p[PG + 1] == pattern(PG + 1), "file shared: read through mapping");
     e2c:	91400680 	add	x0, x20, #0x1, lsl #12
     e30:	b0000001 	adrp	x1, 1000 <main+0x788>
     e34:	9136b421 	add	x1, x1, #0xdad
  memmove(p + 10, "msync-ok", 8);
     e38:	b0000016 	adrp	x22, 1000 <main+0x788>
     e3c:	91373ed6 	add	x22, x22, #0xdcf
  check(p[PG + 1] == pattern(PG + 1), "file shared: read through mapping");
     e40:	39400400 	ldrb	w0, [x0, #1]
     e44:	7101101f 	cmp	w0, #0x44
     e48:	1a9f17e0 	cset	w0, eq	// eq = none
     e4c:	9400015b 	bl	13b8 <check>
  memmove(p + 10, "msync-ok", 8);
     e50:	aa1603e1 	mov	x1, x22
     e54:	52800102 	mov	w2, #0x8                   	// #8
     e58:	91002a80 	add	x0, x20, #0xa
     e5c:	97fffe3b 	bl	748 <memmove@plt>
  check(msync(p, PG, MS_SYNC) == 0, "file shared: msync");
     e60:	52800082 	mov	w2, #0x4                   	// #4
     e64:	d2820001 	mov	x1, #0x1000                	// #4096
     e68:	aa1403e0 	mov	x0, x20
     e6c:	97fffe6b 	bl	818 <msync@plt>
     e70:	7100001f 	cmp	w0, #0x0
     e74:	b0000001 	adrp	x1, 1000 <main+0x788>
     e78:	91376021 	add	x1, x1, #0xdd8
     e7c:	1a9f17e0 	cset	w0, eq	// eq = none
     e80:	9400014e 	bl	13b8 <check>
  check(pread(fd, buf, 8, 10) == 8 && memcmp(buf, "msync-ok", 8) == 0,
     e84:	9101c3e1 	add	x1, sp, #0x70
     e88:	2a1303e0 	mov	w0, w19
     e8c:	d2800143 	mov	x3, #0xa                   	// #10
     e90:	52800102 	mov	w2, #0x8                   	// #8
     e94:	97fffe69 	bl	838 <pread@plt>
     e98:	7100201f 	cmp	w0, #0x8
     e9c:	54000c01 	b.ne	101c <main+0x7a4>  // b.any
     ea0:	2a0003e2 	mov	w2, w0
     ea4:	aa1603e1 	mov	x1, x22
     ea8:	9101c3e0 	add	x0, sp, #0x70
     eac:	97fffe4f 	bl	7e8 <memcmp@plt>
     eb0:	7100001f 	cmp	w0, #0x0
     eb4:	1a9f17e0 	cset	w0, eq	// eq = none
     eb8:	b0000001 	adrp	x1, 1000 <main+0x788>
     ebc:	9137ac21 	add	x1, x1, #0xdeb
  memmove(p + PG + 20, "munmap-ok", 9);
     ec0:	b0000016 	adrp	x22, 1000 <main+0x788>
     ec4:	91384ad6 	add	x22, x22, #0xe12
  check(pread(fd, buf, 8, 10) == 8 && memcmp(buf, "msync-ok", 8) == 0,
     ec8:	9400013c 	bl	13b8 <check>
  memmove(p + PG + 20, "munmap-ok", 9);
     ecc:	52800122 	mov	w2, #0x9                   	// #9
     ed0:	aa1603e1 	mov	x1, x22
     ed4:	d2820280 	mov	x0, #0x1014                	// #4116
     ed8:	8b000280 	add	x0, x20, x0
     edc:	97fffe1b 	bl	748 <memmove@plt>
  p[size - 1] = '!';
     ee0:	91400a80 	add	x0, x20, #0x2, lsl #12
     ee4:	52800421 	mov	w1, #0x21                  	// #33
     ee8:	39018c01 	strb	w1, [x0, #99]
  check(munmap(p, size) == 0, "file shared: munmap");
     eec:	d2840c81 	mov	x1, #0x2064                	// #8292
     ef0:	aa1403e0 	mov	x0, x20
     ef4:	97fffe19 	bl	758 <munmap@plt>
     ef8:	7100001f 	cmp	w0, #0x0
     efc:	1a9f17e0 	cset	w0, eq	// eq = none
     f00:	b0000001 	adrp	x1, 1000 <main+0x788>
     f04:	91387021 	add	x1, x1, #0xe1c
     f08:	9400012c 	bl	13b8 <check>
  check(pread(fd, buf, 9, PG + 20) == 9 && memcmp(buf, "munmap-ok", 9) == 0,
     f0c:	9101c3e1 	add	x1, sp, #0x70
     f10:	2a1303e0 	mov	w0, w19
     f14:	d2820283 	mov	x3, #0x1014                	// #4116
     f18:	52800122 	mov	w2, #0x9                   	// #9
     f1c:	97fffe47 	bl	838 <pread@plt>
     f20:	7100241f 	cmp	w0, #0x9
     f24:	54000801 	b.ne	1024 <main+0x7ac>  // b.any
     f28:	2a0003e2 	mov	w2, w0
     f2c:	aa1603e1 	mov	x1, x22
     f30:	9101c3e0 	add	x0, sp, #0x70
     f34:	97fffe2d 	bl	7e8 <memcmp@plt>
     f38:	7100001f 	cmp	w0, #0x0
     f3c:	1a9f17e0 	cset	w0, eq	// eq = none
     f40:	b0000001 	adrp	x1, 1000 <main+0x788>
     f44:	9138c021 	add	x1, x1, #0xe30
     f48:	9400011c 	bl	13b8 <check>
  check(pread(fd, buf, 1, size - 1) == 1 && buf[0] == '!',
     f4c:	9101c3e1 	add	x1, sp, #0x70
     f50:	2a1303e0 	mov	w0, w19
     f54:	d2840c63 	mov	x3, #0x2063                	// #8291
     f58:	52800022 	mov	w2, #0x1                   	// #1
     f5c:	97fffe37 	bl	838 <pread@plt>
     f60:	7100041f 	cmp	w0, #0x1
     f64:	54000641 	b.ne	102c <main+0x7b4>  // b.any
     f68:	3941c3e0 	ldrb	w0, [sp, #112]
     f6c:	7100841f 	cmp	w0, #0x21
     f70:	1a9f17e0 	cset	w0, eq	// eq = none
     f74:	b0000001 	adrp	x1, 1000 <main+0x788>
     f78:	91397821 	add	x1, x1, #0xe5e
     f7c:	9400010f 	bl	13b8 <check>
  check(fstat(fd, &st) == 0 && st.size == size,
     f80:	910163e1 	add	x1, sp, #0x58
     f84:	2a1303e0 	mov	w0, w19
     f88:	97fffe08 	bl	7a8 <fstat@plt>
     f8c:	35000540 	cbnz	w0, 1034 <main+0x7bc>
     f90:	f94037e1 	ldr	x1, [sp, #104]
     f94:	d2840c80 	mov	x0, #0x2064                	// #8292
     f98:	eb00003f 	cmp	x1, x0
     f9c:	1a9f17e0 	cset	w0, eq	// eq = none
     fa0:	b0000001 	adrp	x1, 1000 <main+0x788>
     fa4:	913a2821 	add	x1, x1, #0xe8a
     fa8:	94000104 	bl	13b8 <check>
  p = mmap(0, PG, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
     fac:	b0000014 	adrp	x20, 1000 <main+0x788>
     fb0:	913aae94 	add	x20, x20, #0xeab
     fb4:	2a1303e4 	mov	w4, w19
     fb8:	d2800005 	mov	x5, #0x0                   	// #0
     fbc:	52800023 	mov	w3, #0x1                   	// #1
     fc0:	52800062 	mov	w2, #0x3                   	// #3
     fc4:	d2820001 	mov	x1, #0x1000                	// #4096
     fc8:	d2800000 	mov	x0, #0x0                   	// #0
     fcc:	97fffdeb 	bl	778 <mmap@plt>
     fd0:	aa0003f7 	mov	x23, x0
  if(fork() == 0){
     fd4:	97fffe09 	bl	7f8 <fork@plt>
     fd8:	35000320 	cbnz	w0, 103c <main+0x7c4>
    int cfd = open(FILE1, O_RDWR);
     fdc:	52800041 	mov	w1, #0x2                   	// #2
     fe0:	aa1503e0 	mov	x0, x21
     fe4:	97fffe1d 	bl	858 <open@plt>
    char *q = mmap(0, PG, PROT_READ | PROT_WRITE, MAP_SHARED, cfd, 0);
     fe8:	2a0003e4 	mov	w4, w0
     fec:	d2800005 	mov	x5, #0x0                   	// #0
     ff0:	52800023 	mov	w3, #0x1                   	// #1
     ff4:	52800062 	mov	w2, #0x3                   	// #3
     ff8:	d2820001 	mov	x1, #0x1000                	// #4096
     ffc:	d2800000 	mov	x0, #0x0                   	// #0
    1000:	97fffdde 	bl	778 <mmap@plt>
    memmove(q + 100, "from-child", 10);
    1004:	aa1403e1 	mov	x1, x20
    1008:	91019000 	add	x0, x0, #0x64
    100c:	52800142 	mov	w2, #0xa                   	// #10
    1010:	97fffdce 	bl	748 <memmove@plt>
    exit(0);
    1014:	52800000 	mov	w0, #0x0                   	// #0
    1018:	17fffe29 	b	8bc <main+0x44>
  check(pread(fd, buf, 8, 10) == 8 && memcmp(buf, "msync-ok", 8) == 0,
    101c:	52800000 	mov	w0, #0x0                   	// #0
    1020:	17ffffa6 	b	eb8 <main+0x640>
  check(pread(fd, buf, 9, PG + 20) == 9 && memcmp(buf, "munmap-ok", 9) == 0,
    1024:	52800000 	mov	w0, #0x0                   	// #0
    1028:	17ffffc6 	b	f40 <main+0x6c8>
  check(pread(fd, buf, 1, size - 1) == 1 && buf[0] == '!',
    102c:	52800000 	mov	w0, #0x0                   	// #0
    1030:	17ffffd1 	b	f74 <main+0x6fc>
  check(fstat(fd, &st) == 0 && st.size == size,
    1034:	52800000 	mov	w0, #0x0                   	// #0
    1038:	17ffffda 	b	fa0 <main+0x728>
  wait(0);
    103c:	d2800000 	mov	x0, #0x0                   	// #0
    1040:	97fffdde 	bl	7b8 <wait@plt>
  check(memcmp(p + 100, "from-child", 10) == 0,
    1044:	52800142 	mov	w2, #0xa                   	// #10
    1048:	aa1403e1 	mov	x1, x20
    104c:	910192e0 	add	x0, x23, #0x64
    1050:	97fffde6 	bl	7e8 <memcmp@plt>
    1054:	7100001f 	cmp	w0, #0x0
    1058:	90000001 	adrp	x1, 1000 <main+0x788>
    105c:	913ad821 	add	x1, x1, #0xeb6
    1060:	1a9f17e0 	cset	w0, eq	// eq = none
    1064:	940000d5 	bl	13b8 <check>
  char *dst = mmap(0, PG, PROT_READ | PROT_WRITE,
    1068:	d2800005 	mov	x5, #0x0                   	// #0
    106c:	12800004 	mov	w4, #0xffffffff            	// #-1
    1070:	52800443 	mov	w3, #0x22                  	// #34
    1074:	52800062 	mov	w2, #0x3                   	// #3
    1078:	d2820001 	mov	x1, #0x1000                	// #4096
    107c:	d2800000 	mov	x0, #0x0                   	// #0
    1080:	97fffdbe 	bl	778 <mmap@plt>
    1084:	aa0003f8 	mov	x24, x0
  ok = pread(fd, dst, 64, 0) == 64 && memcmp(dst, p, 64) == 0;
    1088:	aa0003e1 	mov	x1, x0
    108c:	d2800003 	mov	x3, #0x0                   	// #0
    1090:	2a1303e0 	mov	w0, w19
    1094:	52800802 	mov	w2, #0x40                  	// #64
    1098:	97fffde8 	bl	838 <pread@plt>
    109c:	7101001f 	cmp	w0, #0x40
    10a0:	54000901 	b.ne	11c0 <main+0x948>  // b.any
    10a4:	2a0003e2 	mov	w2, w0
    10a8:	aa1703e1 	mov	x1, x23
    10ac:	aa1803e0 	mov	x0, x24
    10b0:	97fffdce 	bl	7e8 <memcmp@plt>
    10b4:	7100001f 	cmp	w0, #0x0
    10b8:	1a9f17e0 	cset	w0, eq	// eq = none
  check(ok, "file shared: read() into an untouched mapping");
    10bc:	90000001 	adrp	x1, 1000 <main+0x788>
    10c0:	913bb421 	add	x1, x1, #0xeed
  int out = open("mmaptest.out", O_CREATE | O_RDWR | O_TRUNC);
    10c4:	90000016 	adrp	x22, 1000 <main+0x788>
    10c8:	913c6ed6 	add	x22, x22, #0xf1b
  check(ok, "file shared: read() into an untouched mapping");
    10cc:	940000bb 	bl	13b8 <check>
  int out = open("mmaptest.out", O_CREATE | O_RDWR | O_TRUNC);
    10d0:	5280c041 	mov	w1, #0x602                 	// #1538
    10d4:	aa1603e0 	mov	x0, x22
    10d8:	97fffde0 	bl	858 <open@plt>
    10dc:	2a0003f9 	mov	w25, w0
  ok = write(out, p + 100, 10) == 10 && pread(out, buf, 10, 0) == 10 &&
    10e0:	910192e1 	add	x1, x23, #0x64
    10e4:	52800142 	mov	w2, #0xa                   	// #10
    10e8:	97fffdac 	bl	798 <write@plt>
    10ec:	7100281f 	cmp	w0, #0xa
    10f0:	54000101 	b.ne	1110 <main+0x898>  // b.any
    10f4:	2a0003e2 	mov	w2, w0
    10f8:	9101c3e1 	add	x1, sp, #0x70
    10fc:	2a1903e0 	mov	w0, w25
    1100:	d2800003 	mov	x3, #0x0                   	// #0
    1104:	97fffdcd 	bl	838 <pread@plt>
    1108:	7100281f 	cmp	w0, #0xa
    110c:	540005e0 	b.eq	11c8 <main+0x950>  // b.none
    1110:	52800000 	mov	w0, #0x0                   	// #0
  check(ok, "file shared: write() from a mapped buffer");
    1114:	90000001 	adrp	x1, 1000 <main+0x788>
    1118:	913ca021 	add	x1, x1, #0xf28
    111c:	940000a7 	bl	13b8 <check>
  close(out);
    1120:	2a1903e0 	mov	w0, w25
    1124:	97fffdd1 	bl	868 <close@plt>
  unlink("mmaptest.out");
    1128:	aa1603e0 	mov	x0, x22
    112c:	97fffdab 	bl	7d8 <unlink@plt>
  munmap(dst, PG);
    1130:	aa1803e0 	mov	x0, x24
    1134:	d2820001 	mov	x1, #0x1000                	// #4096
    1138:	97fffd88 	bl	758 <munmap@plt>
  munmap(p, PG);
    113c:	d2820001 	mov	x1, #0x1000                	// #4096
    1140:	aa1703e0 	mov	x0, x23
    1144:	97fffd85 	bl	758 <munmap@plt>
  close(fd);
    1148:	2a1303e0 	mov	w0, w19
    114c:	97fffdc7 	bl	868 <close@plt>
  check(child_faults(sigbus_child, 0), "file: access beyond EOF faults (SIGBUS)");
    1150:	d2800001 	mov	x1, #0x0                   	// #0
    1154:	90000000 	adrp	x0, 1000 <main+0x788>
    1158:	910de000 	add	x0, x0, #0x378
    115c:	940001b1 	bl	1820 <child_faults>
    1160:	90000001 	adrp	x1, 1000 <main+0x788>
    1164:	913d4821 	add	x1, x1, #0xf52
    1168:	94000094 	bl	13b8 <check>
  pipe(pfd);
    116c:	910143e0 	add	x0, sp, #0x50
    1170:	97fffd86 	bl	788 <pipe@plt>
  check(mmap(0, PG, PROT_READ, MAP_SHARED, pfd[0], 0) == MAP_FAILED,
    1174:	b94053e4 	ldr	w4, [sp, #80]
    1178:	52800023 	mov	w3, #0x1                   	// #1
    117c:	d2800005 	mov	x5, #0x0                   	// #0
    1180:	2a0303e2 	mov	w2, w3
    1184:	d2820001 	mov	x1, #0x1000                	// #4096
    1188:	d2800000 	mov	x0, #0x0                   	// #0
    118c:	97fffd7b 	bl	778 <mmap@plt>
    1190:	b100041f 	cmn	x0, #0x1
    1194:	1a9f17e0 	cset	w0, eq	// eq = none
    1198:	90000001 	adrp	x1, 1000 <main+0x788>
    119c:	913de821 	add	x1, x1, #0xf7a
    11a0:	94000086 	bl	13b8 <check>
  close(pfd[0]);
    11a4:	b94053e0 	ldr	w0, [sp, #80]
    11a8:	97fffdb0 	bl	868 <close@plt>
  close(pfd[1]);
    11ac:	b94057e0 	ldr	w0, [sp, #84]
    11b0:	97fffdae 	bl	868 <close@plt>
  unlink(FILE1);
    11b4:	aa1503e0 	mov	x0, x21
    11b8:	97fffd88 	bl	7d8 <unlink@plt>
    11bc:	17fffe60 	b	b3c <main+0x2c4>
  ok = pread(fd, dst, 64, 0) == 64 && memcmp(dst, p, 64) == 0;
    11c0:	52800000 	mov	w0, #0x0                   	// #0
    11c4:	17ffffbe 	b	10bc <main+0x844>
       memcmp(buf, "from-child", 10) == 0;
    11c8:	2a0003e2 	mov	w2, w0
    11cc:	aa1403e1 	mov	x1, x20
    11d0:	9101c3e0 	add	x0, sp, #0x70
    11d4:	97fffd85 	bl	7e8 <memcmp@plt>
  ok = write(out, p + 100, 10) == 10 && pread(out, buf, 10, 0) == 10 &&
    11d8:	7100001f 	cmp	w0, #0x0
    11dc:	1a9f17e0 	cset	w0, eq	// eq = none
    11e0:	17ffffcd 	b	1114 <main+0x89c>
    char *z = mmap(0, PG, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    11e4:	2a0003e4 	mov	w4, w0
    11e8:	d2800005 	mov	x5, #0x0                   	// #0
    11ec:	52800023 	mov	w3, #0x1                   	// #1
    11f0:	52800062 	mov	w2, #0x3                   	// #3
    11f4:	d2820001 	mov	x1, #0x1000                	// #4096
    11f8:	d2800000 	mov	x0, #0x0                   	// #0
    11fc:	97fffd5f 	bl	778 <mmap@plt>
    1200:	aa0003f3 	mov	x19, x0
    close(fd);
    1204:	2a1403e0 	mov	w0, w20
    1208:	97fffd98 	bl	868 <close@plt>
    check(z != MAP_FAILED && z[0] == 0 && z[PG - 1] == 0, "dev/zero: mmap");
    120c:	b100067f 	cmn	x19, #0x1
    1210:	54000060 	b.eq	121c <main+0x9a4>  // b.none
    1214:	39400260 	ldrb	w0, [x19]
    1218:	34000140 	cbz	w0, 1240 <main+0x9c8>
    121c:	52800000 	mov	w0, #0x0                   	// #0
    1220:	90000001 	adrp	x1, 1000 <main+0x788>
    1224:	913ec421 	add	x1, x1, #0xfb1
    1228:	94000064 	bl	13b8 <check>
    if(fork() == 0){
    122c:	97fffd73 	bl	7f8 <fork@plt>
    1230:	35000100 	cbnz	w0, 1250 <main+0x9d8>
      z[1] = 9;
    1234:	52800121 	mov	w1, #0x9                   	// #9
    1238:	39000661 	strb	w1, [x19, #1]
      exit(0);
    123c:	17fffda0 	b	8bc <main+0x44>
    check(z != MAP_FAILED && z[0] == 0 && z[PG - 1] == 0, "dev/zero: mmap");
    1240:	397ffe60 	ldrb	w0, [x19, #4095]
    1244:	7100001f 	cmp	w0, #0x0
    1248:	1a9f17e0 	cset	w0, eq	// eq = none
    124c:	17fffff5 	b	1220 <main+0x9a8>
    wait(&status);
    1250:	9101c3e0 	add	x0, sp, #0x70
    1254:	97fffd59 	bl	7b8 <wait@plt>
    check(z[1] == 9, "dev/zero: MAP_SHARED visible across fork");
    1258:	39400660 	ldrb	w0, [x19, #1]
    125c:	90000001 	adrp	x1, 1000 <main+0x788>
    1260:	913f0021 	add	x1, x1, #0xfc0
    1264:	7100241f 	cmp	w0, #0x9
    1268:	1a9f17e0 	cset	w0, eq	// eq = none
    126c:	94000053 	bl	13b8 <check>
    munmap(z, PG);
    1270:	aa1303e0 	mov	x0, x19
    1274:	d2820001 	mov	x1, #0x1000                	// #4096
    1278:	97fffd38 	bl	758 <munmap@plt>
    127c:	17fffe3a 	b	b64 <main+0x2ec>
    volatile uint32 *t = mmap(0, PG, PROT_READ, MAP_SHARED, fd, 0x3f003000);
    1280:	2a0003e4 	mov	w4, w0
    1284:	52800023 	mov	w3, #0x1                   	// #1
    1288:	d2820001 	mov	x1, #0x1000                	// #4096
    128c:	2a0303e2 	mov	w2, w3
    1290:	d2860005 	mov	x5, #0x3000                	// #12288
    1294:	f2a7e005 	movk	x5, #0x3f00, lsl #16
    1298:	d2800000 	mov	x0, #0x0                   	// #0
    129c:	97fffd37 	bl	778 <mmap@plt>
    check(t != MAP_FAILED, "dev/mem: mmap system timer registers");
    12a0:	b100041f 	cmn	x0, #0x1
    volatile uint32 *t = mmap(0, PG, PROT_READ, MAP_SHARED, fd, 0x3f003000);
    12a4:	aa0003f3 	mov	x19, x0
    check(t != MAP_FAILED, "dev/mem: mmap system timer registers");
    12a8:	b0000001 	adrp	x1, 2000 <make_file.constprop.0+0x790>
    12ac:	91000021 	add	x1, x1, #0x0
    12b0:	1a9f07e0 	cset	w0, ne	// ne = any
    12b4:	94000041 	bl	13b8 <check>
    if(t != MAP_FAILED){
    12b8:	b100067f 	cmn	x19, #0x1
    12bc:	54000240 	b.eq	1304 <main+0xa8c>  // b.none
      uint32 a = t[1];                // CLO
    12c0:	b9400676 	ldr	w22, [x19, #4]
      sleep(1);
    12c4:	52800020 	mov	w0, #0x1                   	// #1
    12c8:	97fffd28 	bl	768 <sleep@plt>
      uint32 b = t[1];
    12cc:	b9400675 	ldr	w21, [x19, #4]
      printf("     timer CLO %d -> %d\n", a, b);
    12d0:	2a1603e1 	mov	w1, w22
    12d4:	b0000000 	adrp	x0, 2000 <make_file.constprop.0+0x790>
    12d8:	91009400 	add	x0, x0, #0x25
    12dc:	2a1503e2 	mov	w2, w21
    12e0:	97fffd16 	bl	738 <printf@plt>
      check(b > a, "dev/mem: timer counter advances");
    12e4:	6b1502df 	cmp	w22, w21
    12e8:	b0000001 	adrp	x1, 2000 <make_file.constprop.0+0x790>
    12ec:	9100f821 	add	x1, x1, #0x3e
    12f0:	1a9f27e0 	cset	w0, cc	// cc = lo, ul, last
    12f4:	94000031 	bl	13b8 <check>
      munmap((void *)t, PG);
    12f8:	aa1303e0 	mov	x0, x19
    12fc:	d2820001 	mov	x1, #0x1000                	// #4096
    1300:	97fffd16 	bl	758 <munmap@plt>
    check(mmap(0, PG, PROT_READ, MAP_SHARED, fd, 0x100000) == MAP_FAILED,
    1304:	52800023 	mov	w3, #0x1                   	// #1
    1308:	2a1403e4 	mov	w4, w20
    130c:	2a0303e2 	mov	w2, w3
    1310:	d2a00205 	mov	x5, #0x100000              	// #1048576
    1314:	d2820001 	mov	x1, #0x1000                	// #4096
    1318:	d2800000 	mov	x0, #0x0                   	// #0
    131c:	97fffd17 	bl	778 <mmap@plt>
    1320:	b100041f 	cmn	x0, #0x1
    1324:	b0000001 	adrp	x1, 2000 <make_file.constprop.0+0x790>
    1328:	91017821 	add	x1, x1, #0x5e
    132c:	1a9f17e0 	cset	w0, eq	// eq = none
    1330:	94000022 	bl	13b8 <check>
    close(fd);
    1334:	2a1403e0 	mov	w0, w20
    1338:	97fffd4c 	bl	868 <close@plt>
    133c:	17fffe14 	b	b8c <main+0x314>
  printf("mmaptest: %s (%d failure%s)\n", failures ? "FAILED" : "OK",
    1340:	90000001 	adrp	x1, 1000 <main+0x788>
    1344:	912bcc21 	add	x1, x1, #0xaf3
    1348:	b0000003 	adrp	x3, 2000 <make_file.constprop.0+0x790>
    134c:	91017063 	add	x3, x3, #0x5c
    1350:	17fffe19 	b	bb4 <main+0x33c>

0000000000001354 <touch_read>:
{
    1354:	d10043ff 	sub	sp, sp, #0x10
  volatile char c = *(volatile char *)p;
    1358:	39400000 	ldrb	w0, [x0]
    135c:	39003fe0 	strb	w0, [sp, #15]
  (void)c;
    1360:	39403fe0 	ldrb	w0, [sp, #15]
}
    1364:	910043ff 	add	sp, sp, #0x10
    1368:	d65f03c0 	ret

000000000000136c <touch_write>:
  *(volatile char *)p = 1;
    136c:	52800021 	mov	w1, #0x1                   	// #1
    1370:	39000001 	strb	w1, [x0]
}
    1374:	d65f03c0 	ret

0000000000001378 <sigbus_child>:
{
    1378:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
  int fd = open(FILE1, O_RDONLY);
    137c:	52800001 	mov	w1, #0x0                   	// #0
    1380:	90000000 	adrp	x0, 1000 <main+0x788>
    1384:	91253000 	add	x0, x0, #0x94c
{
    1388:	910003fd 	mov	x29, sp
  int fd = open(FILE1, O_RDONLY);
    138c:	97fffd33 	bl	858 <open@plt>
  char *p = mmap(0, 4 * PG, PROT_READ, MAP_PRIVATE, fd, 0);
    1390:	d2800005 	mov	x5, #0x0                   	// #0
    1394:	2a0003e4 	mov	w4, w0
    1398:	52800043 	mov	w3, #0x2                   	// #2
    139c:	52800022 	mov	w2, #0x1                   	// #1
    13a0:	d2880001 	mov	x1, #0x4000                	// #16384
    13a4:	d2800000 	mov	x0, #0x0                   	// #0
    13a8:	97fffcf4 	bl	778 <mmap@plt>
  touch_read(p + 3 * PG);             // wholly beyond EOF
    13ac:	91400c00 	add	x0, x0, #0x3, lsl #12
}
    13b0:	a8c17bfd 	ldp	x29, x30, [sp], #16
  touch_read(p + 3 * PG);             // wholly beyond EOF
    13b4:	17ffffe8 	b	1354 <touch_read>

00000000000013b8 <check>:
{
    13b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  printf("%s %s\n", ok ? "PASS" : "FAIL", what);
    13bc:	7100001f 	cmp	w0, #0x0
    13c0:	90000003 	adrp	x3, 1000 <main+0x788>
    13c4:	91256463 	add	x3, x3, #0x959
    13c8:	90000004 	adrp	x4, 1000 <main+0x788>
{
    13cc:	910003fd 	mov	x29, sp
  printf("%s %s\n", ok ? "PASS" : "FAIL", what);
    13d0:	aa0103e2 	mov	x2, x1
    13d4:	91257881 	add	x1, x4, #0x95e
    13d8:	9a830021 	csel	x1, x1, x3, eq	// eq = none
{
    13dc:	f9000bf3 	str	x19, [sp, #16]
    13e0:	2a0003f3 	mov	w19, w0
  printf("%s %s\n", ok ? "PASS" : "FAIL", what);
    13e4:	90000000 	adrp	x0, 1000 <main+0x788>
    13e8:	91258c00 	add	x0, x0, #0x963
    13ec:	97fffcd3 	bl	738 <printf@plt>
  if(!ok)
    13f0:	350000b3 	cbnz	w19, 1404 <check+0x4c>
    failures++;
    13f4:	d0000001 	adrp	x1, 3000 <make_file.constprop.0+0x1790>
    13f8:	b9428820 	ldr	w0, [x1, #648]
    13fc:	11000400 	add	w0, w0, #0x1
    1400:	b9028820 	str	w0, [x1, #648]
}
    1404:	f9400bf3 	ldr	x19, [sp, #16]
    1408:	a8c27bfd 	ldp	x29, x30, [sp], #32
    140c:	d65f03c0 	ret

0000000000001410 <test_fork>:
{
    1410:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
  char *sh = mmap(0, PG, PROT_READ | PROT_WRITE,
    1414:	d2800005 	mov	x5, #0x0                   	// #0
    1418:	12800004 	mov	w4, #0xffffffff            	// #-1
{
    141c:	910003fd 	mov	x29, sp
  char *sh = mmap(0, PG, PROT_READ | PROT_WRITE,
    1420:	52800423 	mov	w3, #0x21                  	// #33
    1424:	52800062 	mov	w2, #0x3                   	// #3
    1428:	d2820001 	mov	x1, #0x1000                	// #4096
    142c:	d2800000 	mov	x0, #0x0                   	// #0
{
    1430:	f9000bf3 	str	x19, [sp, #16]
  char *sh = mmap(0, PG, PROT_READ | PROT_WRITE,
    1434:	97fffcd1 	bl	778 <mmap@plt>
  char *pr = mmap(0, PG, PROT_READ | PROT_WRITE,
    1438:	d2800005 	mov	x5, #0x0                   	// #0
    143c:	12800004 	mov	w4, #0xffffffff            	// #-1
    1440:	52800443 	mov	w3, #0x22                  	// #34
    1444:	52800062 	mov	w2, #0x3                   	// #3
    1448:	d2820001 	mov	x1, #0x1000                	// #4096
  char *sh = mmap(0, PG, PROT_READ | PROT_WRITE,
    144c:	f9001fe0 	str	x0, [sp, #56]
  char *pr = mmap(0, PG, PROT_READ | PROT_WRITE,
    1450:	d2800000 	mov	x0, #0x0                   	// #0
    1454:	97fffcc9 	bl	778 <mmap@plt>
    1458:	f90017e0 	str	x0, [sp, #40]
  if(sh == MAP_FAILED || pr == MAP_FAILED){
    145c:	f9401fe0 	ldr	x0, [sp, #56]
    1460:	b100041f 	cmn	x0, #0x1
    1464:	f94017e0 	ldr	x0, [sp, #40]
    1468:	ba411804 	ccmn	x0, #0x1, #0x4, ne	// ne = any
    146c:	54000101 	b.ne	148c <test_fork+0x7c>  // b.any
    check(0, "fork: mmap");
    1470:	90000001 	adrp	x1, 1000 <main+0x788>
    1474:	9125a821 	add	x1, x1, #0x96a
    1478:	52800000 	mov	w0, #0x0                   	// #0
    147c:	97ffffcf 	bl	13b8 <check>
}
    1480:	f9400bf3 	ldr	x19, [sp, #16]
    1484:	a8c57bfd 	ldp	x29, x30, [sp], #80
    1488:	d65f03c0 	ret
  strcpy(sh, "parent");
    148c:	f9401fe0 	ldr	x0, [sp, #56]
    1490:	90000013 	adrp	x19, 1000 <main+0x788>
    1494:	9125d661 	add	x1, x19, #0x975
    1498:	97fffca0 	bl	718 <strcpy@plt>
  strcpy(pr, "parent");
    149c:	f94017e0 	ldr	x0, [sp, #40]
    14a0:	9125d661 	add	x1, x19, #0x975
    14a4:	97fffc9d 	bl	718 <strcpy@plt>
  if(fork() == 0){
    14a8:	97fffcd4 	bl	7f8 <fork@plt>
    14ac:	35000140 	cbnz	w0, 14d4 <test_fork+0xc4>
    strcpy(sh, "child");
    14b0:	f9401fe0 	ldr	x0, [sp, #56]
    14b4:	90000013 	adrp	x19, 1000 <main+0x788>
    14b8:	9127ba61 	add	x1, x19, #0x9ee
    14bc:	97fffc97 	bl	718 <strcpy@plt>
    strcpy(pr, "child");
    14c0:	f94017e0 	ldr	x0, [sp, #40]
    14c4:	9127ba61 	add	x1, x19, #0x9ee
    14c8:	97fffc94 	bl	718 <strcpy@plt>
    exit(0);
    14cc:	52800000 	mov	w0, #0x0                   	// #0
    exit(0);
    14d0:	97fffcde 	bl	848 <exit@plt>
  wait(&status);
    14d4:	910133e0 	add	x0, sp, #0x4c
    14d8:	97fffcb8 	bl	7b8 <wait@plt>
  check(strcmp(sh, "child") == 0, "fork: MAP_SHARED|MAP_ANONYMOUS is shared");
    14dc:	f9401fe0 	ldr	x0, [sp, #56]
    14e0:	90000001 	adrp	x1, 1000 <main+0x788>
    14e4:	9127b821 	add	x1, x1, #0x9ee
    14e8:	97fffcc8 	bl	808 <strcmp@plt>
    14ec:	7100001f 	cmp	w0, #0x0
    14f0:	1a9f17e0 	cset	w0, eq	// eq = none
    14f4:	90000001 	adrp	x1, 1000 <main+0x788>
    14f8:	9125f021 	add	x1, x1, #0x97c
    14fc:	97ffffaf 	bl	13b8 <check>
  check(strcmp(pr, "parent") == 0, "fork: MAP_PRIVATE copy is private");
    1500:	f94017e0 	ldr	x0, [sp, #40]
    1504:	9125d661 	add	x1, x19, #0x975
    1508:	97fffcc0 	bl	808 <strcmp@plt>
    150c:	7100001f 	cmp	w0, #0x0
    1510:	1a9f17e0 	cset	w0, eq	// eq = none
    1514:	90000001 	adrp	x1, 1000 <main+0x788>
    1518:	91269421 	add	x1, x1, #0x9a5
    151c:	97ffffa7 	bl	13b8 <check>
  char *late = mmap(0, 2 * PG, PROT_READ | PROT_WRITE,
    1520:	d2800005 	mov	x5, #0x0                   	// #0
    1524:	12800004 	mov	w4, #0xffffffff            	// #-1
    1528:	52800423 	mov	w3, #0x21                  	// #33
    152c:	52800062 	mov	w2, #0x3                   	// #3
    1530:	d2840001 	mov	x1, #0x2000                	// #8192
    1534:	d2800000 	mov	x0, #0x0                   	// #0
    1538:	97fffc90 	bl	778 <mmap@plt>
    153c:	f9001be0 	str	x0, [sp, #48]
  if(fork() == 0){
    1540:	97fffcae 	bl	7f8 <fork@plt>
    1544:	350000c0 	cbnz	w0, 155c <test_fork+0x14c>
    late[PG + 5] = 42;
    1548:	f9401be1 	ldr	x1, [sp, #48]
    154c:	52800542 	mov	w2, #0x2a                  	// #42
    1550:	91400421 	add	x1, x1, #0x1, lsl #12
    1554:	39001422 	strb	w2, [x1, #5]
    1558:	17ffffde 	b	14d0 <test_fork+0xc0>
  wait(&status);
    155c:	910133e0 	add	x0, sp, #0x4c
    1560:	97fffc96 	bl	7b8 <wait@plt>
  check(late[PG + 5] == 42, "fork: shared page first faulted by the child");
    1564:	f9401be0 	ldr	x0, [sp, #48]
    1568:	90000001 	adrp	x1, 1000 <main+0x788>
    156c:	91271c21 	add	x1, x1, #0x9c7
    1570:	91400400 	add	x0, x0, #0x1, lsl #12
    1574:	39401400 	ldrb	w0, [x0, #5]
    1578:	7100a81f 	cmp	w0, #0x2a
    157c:	1a9f17e0 	cset	w0, eq	// eq = none
    1580:	97ffff8e 	bl	13b8 <check>
  int pid = vfork();
    1584:	97fffca9 	bl	828 <vfork@plt>
    1588:	2a0003f3 	mov	w19, w0
  if(pid == 0){
    158c:	35000120 	cbnz	w0, 15b0 <test_fork+0x1a0>
    pr[1] = 'v';
    1590:	f94017e2 	ldr	x2, [sp, #40]
    1594:	52800ec1 	mov	w1, #0x76                  	// #118
    1598:	39000441 	strb	w1, [x2, #1]
    late[PG + 6] = 43;
    159c:	52800562 	mov	w2, #0x2b                  	// #43
    15a0:	f9401be1 	ldr	x1, [sp, #48]
    15a4:	91400421 	add	x1, x1, #0x1, lsl #12
    15a8:	39001822 	strb	w2, [x1, #6]
    exit(0);
    15ac:	17ffffc9 	b	14d0 <test_fork+0xc0>
  wait(&status);
    15b0:	910133e0 	add	x0, sp, #0x4c
    15b4:	97fffc81 	bl	7b8 <wait@plt>
  check(pid > 0 && pr[1] == 'v' && late[PG + 6] == 43,
    15b8:	7100027f 	cmp	w19, #0x0
    15bc:	5400036c 	b.gt	1628 <test_fork+0x218>
    15c0:	52800000 	mov	w0, #0x0                   	// #0
    15c4:	90000001 	adrp	x1, 1000 <main+0x788>
    15c8:	9127d021 	add	x1, x1, #0x9f4
    15cc:	97ffff7b 	bl	13b8 <check>
  check(pr[0] == 'p' && late[PG + 5] == 42,
    15d0:	f94017e0 	ldr	x0, [sp, #40]
    15d4:	39400000 	ldrb	w0, [x0]
    15d8:	7101c01f 	cmp	w0, #0x70
    15dc:	540003a1 	b.ne	1650 <test_fork+0x240>  // b.any
    15e0:	f9401be0 	ldr	x0, [sp, #48]
    15e4:	91400400 	add	x0, x0, #0x1, lsl #12
    15e8:	39401400 	ldrb	w0, [x0, #5]
    15ec:	7100a81f 	cmp	w0, #0x2a
    15f0:	1a9f17e0 	cset	w0, eq	// eq = none
    15f4:	90000001 	adrp	x1, 1000 <main+0x788>
    15f8:	91287821 	add	x1, x1, #0xa1e
    15fc:	97ffff6f 	bl	13b8 <check>
  munmap(sh, PG);
    1600:	f9401fe0 	ldr	x0, [sp, #56]
    1604:	d2820001 	mov	x1, #0x1000                	// #4096
    1608:	97fffc54 	bl	758 <munmap@plt>
  munmap(pr, PG);
    160c:	f94017e0 	ldr	x0, [sp, #40]
    1610:	d2820001 	mov	x1, #0x1000                	// #4096
    1614:	97fffc51 	bl	758 <munmap@plt>
  munmap(late, 2 * PG);
    1618:	f9401be0 	ldr	x0, [sp, #48]
    161c:	d2840001 	mov	x1, #0x2000                	// #8192
    1620:	97fffc4e 	bl	758 <munmap@plt>
    1624:	17ffff97 	b	1480 <test_fork+0x70>
  check(pid > 0 && pr[1] == 'v' && late[PG + 6] == 43,
    1628:	f94017e0 	ldr	x0, [sp, #40]
    162c:	39400400 	ldrb	w0, [x0, #1]
    1630:	7101d81f 	cmp	w0, #0x76
    1634:	54fffc61 	b.ne	15c0 <test_fork+0x1b0>  // b.any
    1638:	f9401be0 	ldr	x0, [sp, #48]
    163c:	91400400 	add	x0, x0, #0x1, lsl #12
    1640:	39401800 	ldrb	w0, [x0, #6]
    1644:	7100ac1f 	cmp	w0, #0x2b
    1648:	1a9f17e0 	cset	w0, eq	// eq = none
    164c:	17ffffde 	b	15c4 <test_fork+0x1b4>
  check(pr[0] == 'p' && late[PG + 5] == 42,
    1650:	52800000 	mov	w0, #0x0                   	// #0
    1654:	17ffffe8 	b	15f4 <test_fork+0x1e4>

0000000000001658 <test_fb>:
{
    1658:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
  int fd = open("/dev/fb0", O_RDWR), ok;
    165c:	90000000 	adrp	x0, 1000 <main+0x788>
    1660:	91291c00 	add	x0, x0, #0xa47
{
    1664:	910003fd 	mov	x29, sp
  int fd = open("/dev/fb0", O_RDWR), ok;
    1668:	52800041 	mov	w1, #0x2                   	// #2
{
    166c:	a90153f3 	stp	x19, x20, [sp, #16]
  int fd = open("/dev/fb0", O_RDWR), ok;
    1670:	97fffc7a 	bl	858 <open@plt>
  if(fd < 0){
    1674:	36f80120 	tbz	w0, #31, 1698 <test_fb+0x40>
    check(0, "fb0: open");
    1678:	90000001 	adrp	x1, 1000 <main+0x788>
    167c:	91294021 	add	x1, x1, #0xa50
    1680:	52800000 	mov	w0, #0x0                   	// #0
    1684:	97ffff4d 	bl	13b8 <check>
    return -1;
    1688:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    168c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1690:	a8c87bfd 	ldp	x29, x30, [sp], #128
    1694:	d65f03c0 	ret
    1698:	2a0003f4 	mov	w20, w0
  ok = ioctl(fd, FBIOGET_VSCREENINFO, &var) == 0 &&
    169c:	9100a3e2 	add	x2, sp, #0x28
    16a0:	d288c001 	mov	x1, #0x4600                	// #17920
    16a4:	97fffc21 	bl	728 <ioctl@plt>
    16a8:	350001e0 	cbnz	w0, 16e4 <test_fb+0x8c>
       ioctl(fd, FBIOGET_FSCREENINFO, &fix) == 0;
    16ac:	910103e2 	add	x2, sp, #0x40
    16b0:	2a1403e0 	mov	w0, w20
    16b4:	d288c041 	mov	x1, #0x4602                	// #17922
    16b8:	97fffc1c 	bl	728 <ioctl@plt>
  ok = ioctl(fd, FBIOGET_VSCREENINFO, &var) == 0 &&
    16bc:	7100001f 	cmp	w0, #0x0
    16c0:	1a9f17f3 	cset	w19, eq	// eq = none
  check(ok, "fb0: FBIOGET_VSCREENINFO / FBIOGET_FSCREENINFO");
    16c4:	90000001 	adrp	x1, 1000 <main+0x788>
    16c8:	91296821 	add	x1, x1, #0xa5a
    16cc:	2a1303e0 	mov	w0, w19
    16d0:	97ffff3a 	bl	13b8 <check>
  if(!ok){
    16d4:	350000d3 	cbnz	w19, 16ec <test_fb+0x94>
    close(fd);
    16d8:	2a1403e0 	mov	w0, w20
    16dc:	97fffc63 	bl	868 <close@plt>
    return -1;
    16e0:	17ffffea 	b	1688 <test_fb+0x30>
  ok = ioctl(fd, FBIOGET_VSCREENINFO, &var) == 0 &&
    16e4:	52800013 	mov	w19, #0x0                   	// #0
    16e8:	17fffff7 	b	16c4 <test_fb+0x6c>
  printf("     fb0 %dx%d %d bpp, line %d, %d bytes\n", var.xres, var.yres,
    16ec:	29450be1 	ldp	w1, w2, [sp, #40]
    16f0:	90000000 	adrp	x0, 1000 <main+0x788>
    16f4:	912a2400 	add	x0, x0, #0xa89
    16f8:	b9403be3 	ldr	w3, [sp, #56]
    16fc:	294b13e5 	ldp	w5, w4, [sp, #88]
    1700:	97fffc0e 	bl	738 <printf@plt>
  uint32 *px = mmap(0, fix.smem_len, PROT_READ | PROT_WRITE, MAP_SHARED,
    1704:	b9405be1 	ldr	w1, [sp, #88]
    1708:	2a1403e4 	mov	w4, w20
    170c:	d2800005 	mov	x5, #0x0                   	// #0
    1710:	52800023 	mov	w3, #0x1                   	// #1
    1714:	52800062 	mov	w2, #0x3                   	// #3
    1718:	d2800000 	mov	x0, #0x0                   	// #0
    171c:	97fffc17 	bl	778 <mmap@plt>
    1720:	aa0003f3 	mov	x19, x0
  close(fd);
    1724:	2a1403e0 	mov	w0, w20
    1728:	97fffc50 	bl	868 <close@plt>
  check(px != MAP_FAILED, "fb0: mmap frame buffer");
    172c:	b100067f 	cmn	x19, #0x1
    1730:	90000001 	adrp	x1, 1000 <main+0x788>
    1734:	912acc21 	add	x1, x1, #0xab3
    1738:	1a9f07e0 	cset	w0, ne	// ne = any
    173c:	97ffff1f 	bl	13b8 <check>
  if(px == MAP_FAILED)
    1740:	b100067f 	cmn	x19, #0x1
    1744:	54fffa20 	b.eq	1688 <test_fb+0x30>  // b.none
  uint32 bars[] = { 0xffffff, 0xffff00, 0x00ffff, 0x00ff00,
    1748:	b2183fe0 	mov	x0, #0xffff0000ffff00      	// #72056494543077120
  int stride = fix.line_length / 4;
    174c:	b9405fe1 	ldr	w1, [sp, #92]
  uint32 bars[] = { 0xffffff, 0xffff00, 0x00ffff, 0x00ff00,
    1750:	f29fffe0 	movk	x0, #0xffff
    1754:	f90033e0 	str	x0, [sp, #96]
    1758:	d29fffe0 	mov	x0, #0xffff                	// #65535
      px[y * stride + x] = bars[x * 8 / var.xres];
    175c:	910183e7 	add	x7, sp, #0x60
  uint32 bars[] = { 0xffffff, 0xffff00, 0x00ffff, 0x00ff00,
    1760:	f2dfe000 	movk	x0, #0xff00, lsl #32
    1764:	f90037e0 	str	x0, [sp, #104]
    1768:	b2101fe0 	mov	x0, #0xff000000ff0000      	// #71776119077928960
  int stride = fix.line_length / 4;
    176c:	53027c21 	lsr	w1, w1, #2
  uint32 bars[] = { 0xffffff, 0xffff00, 0x00ffff, 0x00ff00,
    1770:	f2801fe0 	movk	x0, #0xff
  for(int y = 0; y < (int)var.yres; y++)
    1774:	52800002 	mov	w2, #0x0                   	// #0
    1778:	52800003 	mov	w3, #0x0                   	// #0
  uint32 bars[] = { 0xffffff, 0xffff00, 0x00ffff, 0x00ff00,
    177c:	f9003be0 	str	x0, [sp, #112]
    1780:	d2801fe0 	mov	x0, #0xff                  	// #255
    1784:	f9003fe0 	str	x0, [sp, #120]
  for(int y = 0; y < (int)var.yres; y++)
    1788:	b9402fe0 	ldr	w0, [sp, #44]
    178c:	6b03001f 	cmp	w0, w3
    1790:	540001ed 	b.le	17cc <test_fb+0x174>
    1794:	8b22ca66 	add	x6, x19, w2, sxtw #2
    1798:	d2800000 	mov	x0, #0x0                   	// #0
    179c:	14000006 	b	17b4 <test_fb+0x15c>
      px[y * stride + x] = bars[x * 8 / var.xres];
    17a0:	531d7004 	lsl	w4, w0, #3
    17a4:	1ac50884 	udiv	w4, w4, w5
    17a8:	b86478e4 	ldr	w4, [x7, x4, lsl #2]
    17ac:	b82078c4 	str	w4, [x6, x0, lsl #2]
    for(int x = 0; x < (int)var.xres; x++)
    17b0:	91000400 	add	x0, x0, #0x1
    17b4:	b9402be5 	ldr	w5, [sp, #40]
    17b8:	6b0000bf 	cmp	w5, w0
    17bc:	54ffff2c 	b.gt	17a0 <test_fb+0x148>
  for(int y = 0; y < (int)var.yres; y++)
    17c0:	11000463 	add	w3, w3, #0x1
    17c4:	0b010042 	add	w2, w2, w1
    17c8:	17fffff0 	b	1788 <test_fb+0x130>
  check(px[0] == 0xffffff && px[(var.yres - 1) * stride + var.xres - 1] == 0,
    17cc:	b9400263 	ldr	w3, [x19]
    17d0:	12bfe002 	mov	w2, #0xffffff              	// #16777215
    17d4:	6b02007f 	cmp	w3, w2
    17d8:	54000201 	b.ne	1818 <test_fb+0x1c0>  // b.any
    17dc:	b9402be2 	ldr	w2, [sp, #40]
    17e0:	51000400 	sub	w0, w0, #0x1
    17e4:	51000442 	sub	w2, w2, #0x1
    17e8:	1b010800 	madd	w0, w0, w1, w2
    17ec:	b8607a60 	ldr	w0, [x19, x0, lsl #2]
    17f0:	7100001f 	cmp	w0, #0x0
    17f4:	1a9f17e0 	cset	w0, eq	// eq = none
    17f8:	90000001 	adrp	x1, 1000 <main+0x788>
    17fc:	912b2821 	add	x1, x1, #0xaca
    1800:	97fffeee 	bl	13b8 <check>
  munmap(px, fix.smem_len);
    1804:	b9405be1 	ldr	w1, [sp, #88]
    1808:	aa1303e0 	mov	x0, x19
    180c:	97fffbd3 	bl	758 <munmap@plt>
  return 0;
    1810:	52800000 	mov	w0, #0x0                   	// #0
    1814:	17ffff9e 	b	168c <test_fb+0x34>
  check(px[0] == 0xffffff && px[(var.yres - 1) * stride + var.xres - 1] == 0,
    1818:	52800000 	mov	w0, #0x0                   	// #0
    181c:	17fffff7 	b	17f8 <test_fb+0x1a0>

0000000000001820 <child_faults>:
{
    1820:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1824:	910003fd 	mov	x29, sp
    1828:	a90153f3 	stp	x19, x20, [sp, #16]
    182c:	aa0003f3 	mov	x19, x0
    1830:	aa0103f4 	mov	x20, x1
  int pid = fork(), status = 0;
    1834:	97fffbf1 	bl	7f8 <fork@plt>
    1838:	b9002fff 	str	wzr, [sp, #44]
  if(pid == 0){
    183c:	350000a0 	cbnz	w0, 1850 <child_faults+0x30>
    fn(arg);
    1840:	aa1403e0 	mov	x0, x20
    1844:	d63f0260 	blr	x19
    exit(0);
    1848:	52800000 	mov	w0, #0x0                   	// #0
    184c:	97fffbff 	bl	848 <exit@plt>
  wait(&status);
    1850:	9100b3e0 	add	x0, sp, #0x2c
    1854:	97fffbd9 	bl	7b8 <wait@plt>
  return status != 0;
    1858:	b9402fe0 	ldr	w0, [sp, #44]
}
    185c:	a94153f3 	ldp	x19, x20, [sp, #16]
  return status != 0;
    1860:	7100001f 	cmp	w0, #0x0
}
    1864:	1a9f07e0 	cset	w0, ne	// ne = any
    1868:	a8c37bfd 	ldp	x29, x30, [sp], #48
    186c:	d65f03c0 	ret

0000000000001870 <make_file.constprop.0>:
make_file(char *name, int size)
    1870:	d10943ff 	sub	sp, sp, #0x250
    1874:	a9007bfd 	stp	x29, x30, [sp]
    1878:	910003fd 	mov	x29, sp
    187c:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink(name);
    1880:	90000013 	adrp	x19, 1000 <main+0x788>
    1884:	91253260 	add	x0, x19, #0x94c
make_file(char *name, int size)
    1888:	a9025bf5 	stp	x21, x22, [sp, #32]
    188c:	a90363f7 	stp	x23, x24, [sp, #48]
  unlink(name);
    1890:	97fffbd2 	bl	7d8 <unlink@plt>
  if((fd = open(name, O_CREATE | O_RDWR)) < 0)
    1894:	91253260 	add	x0, x19, #0x94c
    1898:	52804041 	mov	w1, #0x202                 	// #514
    189c:	97fffbef 	bl	858 <open@plt>
    18a0:	37f803a0 	tbnz	w0, #31, 1914 <make_file.constprop.0+0xa4>
    18a4:	2a0003f4 	mov	w20, w0
      buf[j] = pattern(i + j);
    18a8:	910143e1 	add	x1, sp, #0x50
    18ac:	52800013 	mov	w19, #0x0                   	// #0
    n = size - i < (int)sizeof(buf) ? size - i : (int)sizeof(buf);
    18b0:	52840c97 	mov	w23, #0x2064                	// #8292
    18b4:	52804018 	mov	w24, #0x200                 	// #512
  return 'A' + i % 23;
    18b8:	528002f5 	mov	w21, #0x17                  	// #23
  for(i = 0; i < size; i += n){
    18bc:	52840c76 	mov	w22, #0x2063                	// #8291
    n = size - i < (int)sizeof(buf) ? size - i : (int)sizeof(buf);
    18c0:	4b1302e2 	sub	w2, w23, w19
    18c4:	d2800000 	mov	x0, #0x0                   	// #0
    18c8:	7108005f 	cmp	w2, #0x200
    18cc:	1a98d042 	csel	w2, w2, w24, le
      buf[j] = pattern(i + j);
    18d0:	0b000264 	add	w4, w19, w0
  return 'A' + i % 23;
    18d4:	1ad50c83 	sdiv	w3, w4, w21
    18d8:	1b159063 	msub	w3, w3, w21, w4
    18dc:	11010463 	add	w3, w3, #0x41
      buf[j] = pattern(i + j);
    18e0:	38216803 	strb	w3, [x0, x1]
    for(int j = 0; j < n; j++)
    18e4:	91000400 	add	x0, x0, #0x1
    18e8:	6b00005f 	cmp	w2, w0
    18ec:	54ffff2c 	b.gt	18d0 <make_file.constprop.0+0x60>
    if(write(fd, buf, n) != n){
    18f0:	2a1403e0 	mov	w0, w20
    18f4:	b9004fe2 	str	w2, [sp, #76]
    18f8:	97fffba8 	bl	798 <write@plt>
    18fc:	b9404fe2 	ldr	w2, [sp, #76]
    1900:	910143e1 	add	x1, sp, #0x50
    1904:	6b00005f 	cmp	w2, w0
    1908:	54000140 	b.eq	1930 <make_file.constprop.0+0xc0>  // b.none
      close(fd);
    190c:	2a1403e0 	mov	w0, w20
    1910:	97fffbd6 	bl	868 <close@plt>
    return -1;
    1914:	12800000 	mov	w0, #0xffffffff            	// #-1
}
    1918:	a9407bfd 	ldp	x29, x30, [sp]
    191c:	a94153f3 	ldp	x19, x20, [sp, #16]
    1920:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1924:	a94363f7 	ldp	x23, x24, [sp, #48]
    1928:	910943ff 	add	sp, sp, #0x250
    192c:	d65f03c0 	ret
  for(i = 0; i < size; i += n){
    1930:	0b020273 	add	w19, w19, w2
    1934:	6b16027f 	cmp	w19, w22
    1938:	54fffc4d 	b.le	18c0 <make_file.constprop.0+0x50>
  close(fd);
    193c:	2a1403e0 	mov	w0, w20
    1940:	97fffbca 	bl	868 <close@plt>
  return 0;
    1944:	52800000 	mov	w0, #0x0                   	// #0
    1948:	17fffff4 	b	1918 <make_file.constprop.0+0xa8>
