
user/_wifi:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000003a0 <.plt>:
 3a0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 3a4:	b0000010 	adrp	x16, 1000 <value+0xac4>
 3a8:	f943fe11 	ldr	x17, [x16, #2040]
 3ac:	911fe210 	add	x16, x16, #0x7f8
 3b0:	d61f0220 	br	x17
 3b4:	d503201f 	nop
 3b8:	d503201f 	nop
 3bc:	d503201f 	nop

00000000000003c0 <printf@plt>:
 3c0:	b0000010 	adrp	x16, 1000 <value+0xac4>
 3c4:	f9440211 	ldr	x17, [x16, #2048]
 3c8:	91200210 	add	x16, x16, #0x800
 3cc:	d61f0220 	br	x17

00000000000003d0 <read@plt>:
 3d0:	b0000010 	adrp	x16, 1000 <value+0xac4>
 3d4:	f9440611 	ldr	x17, [x16, #2056]
 3d8:	91202210 	add	x16, x16, #0x808
 3dc:	d61f0220 	br	x17

00000000000003e0 <strncmp@plt>:
 3e0:	b0000010 	adrp	x16, 1000 <value+0xac4>
 3e4:	f9440a11 	ldr	x17, [x16, #2064]
 3e8:	91204210 	add	x16, x16, #0x810
 3ec:	d61f0220 	br	x17

00000000000003f0 <wifi_connect@plt>:
 3f0:	b0000010 	adrp	x16, 1000 <value+0xac4>
 3f4:	f9440e11 	ldr	x17, [x16, #2072]
 3f8:	91206210 	add	x16, x16, #0x818
 3fc:	d61f0220 	br	x17

0000000000000400 <exit@plt>:
 400:	b0000010 	adrp	x16, 1000 <value+0xac4>
 404:	f9441211 	ldr	x17, [x16, #2080]
 408:	91208210 	add	x16, x16, #0x820
 40c:	d61f0220 	br	x17

0000000000000410 <strlen@plt>:
 410:	b0000010 	adrp	x16, 1000 <value+0xac4>
 414:	f9441611 	ldr	x17, [x16, #2088]
 418:	9120a210 	add	x16, x16, #0x828
 41c:	d61f0220 	br	x17

0000000000000420 <open@plt>:
 420:	b0000010 	adrp	x16, 1000 <value+0xac4>
 424:	f9441a11 	ldr	x17, [x16, #2096]
 428:	9120c210 	add	x16, x16, #0x830
 42c:	d61f0220 	br	x17

0000000000000430 <close@plt>:
 430:	b0000010 	adrp	x16, 1000 <value+0xac4>
 434:	f9441e11 	ldr	x17, [x16, #2104]
 438:	9120e210 	add	x16, x16, #0x838
 43c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000440 <main>:
  return 0;
}

int
main(int argc, char **argv)
{
 440:	a9ad7bfd 	stp	x29, x30, [sp, #-304]!
 444:	910003fd 	mov	x29, sp
 448:	a90153f3 	stp	x19, x20, [sp, #16]
 44c:	f90013f5 	str	x21, [sp, #32]
  char config[256], *ssid, *psk;
  int fd, n;

  if(argc == 3){
 450:	71000c1f 	cmp	w0, #0x3
 454:	540001a1 	b.ne	488 <main+0x48>  // b.any
    ssid = argv[1];
    psk = argv[2];
 458:	a940d033 	ldp	x19, x20, [x1, #8]
    if(ssid == 0 || psk == 0){
      printf("wifi: expected ssid= and psk= in /etc/wifi.conf\n");
      exit(1);
    }
  }
  printf("wifi: connecting to %s\n", ssid);
 45c:	aa1303e1 	mov	x1, x19
 460:	90000000 	adrp	x0, 0 <.plt-0x3a0>
 464:	9119f000 	add	x0, x0, #0x67c
 468:	97ffffd6 	bl	3c0 <printf@plt>
  if(wifi_connect(ssid, psk) < 0){
 46c:	aa1403e1 	mov	x1, x20
 470:	aa1303e0 	mov	x0, x19
 474:	97ffffdf 	bl	3f0 <wifi_connect@plt>
 478:	36f80580 	tbz	w0, #31, 528 <main+0xe8>
    printf("wifi: association failed\n");
 47c:	90000000 	adrp	x0, 0 <.plt-0x3a0>
 480:	911a5000 	add	x0, x0, #0x694
 484:	14000009 	b	4a8 <main+0x68>
    fd = open("/etc/wifi.conf", O_RDONLY);
 488:	90000000 	adrp	x0, 0 <.plt-0x3a0>
 48c:	9117d000 	add	x0, x0, #0x5f4
 490:	52800001 	mov	w1, #0x0                   	// #0
 494:	97ffffe3 	bl	420 <open@plt>
 498:	2a0003f5 	mov	w21, w0
    if(fd < 0){
 49c:	36f800c0 	tbz	w0, #31, 4b4 <main+0x74>
      printf("wifi: usage: wifi SSID PASSPHRASE\n");
 4a0:	90000000 	adrp	x0, 0 <.plt-0x3a0>
 4a4:	91180c00 	add	x0, x0, #0x603
      printf("wifi: empty /etc/wifi.conf\n");
 4a8:	97ffffc6 	bl	3c0 <printf@plt>
      exit(1);
 4ac:	52800020 	mov	w0, #0x1                   	// #1
 4b0:	97ffffd4 	bl	400 <exit@plt>
    n = read(fd, config, sizeof(config) - 1);
 4b4:	9100c3f3 	add	x19, sp, #0x30
 4b8:	52801fe2 	mov	w2, #0xff                  	// #255
 4bc:	aa1303e1 	mov	x1, x19
 4c0:	97ffffc4 	bl	3d0 <read@plt>
 4c4:	2a0003f4 	mov	w20, w0
    close(fd);
 4c8:	2a1503e0 	mov	w0, w21
 4cc:	97ffffd9 	bl	430 <close@plt>
    if(n <= 0){
 4d0:	7100029f 	cmp	w20, #0x0
 4d4:	5400008c 	b.gt	4e4 <main+0xa4>
      printf("wifi: empty /etc/wifi.conf\n");
 4d8:	90000000 	adrp	x0, 0 <.plt-0x3a0>
 4dc:	91189800 	add	x0, x0, #0x626
 4e0:	17fffff2 	b	4a8 <main+0x68>
    psk = value(config, "psk");
 4e4:	aa1303e0 	mov	x0, x19
 4e8:	90000001 	adrp	x1, 0 <.plt-0x3a0>
 4ec:	91190821 	add	x1, x1, #0x642
    config[n] = 0;
 4f0:	38344a7f 	strb	wzr, [x19, w20, uxtw]
    psk = value(config, "psk");
 4f4:	94000012 	bl	53c <value>
 4f8:	aa0003f4 	mov	x20, x0
    ssid = value(config, "ssid");
 4fc:	90000001 	adrp	x1, 0 <.plt-0x3a0>
 500:	91191821 	add	x1, x1, #0x646
 504:	aa1303e0 	mov	x0, x19
 508:	9400000d 	bl	53c <value>
    if(ssid == 0 || psk == 0){
 50c:	f100001f 	cmp	x0, #0x0
    ssid = value(config, "ssid");
 510:	aa0003f3 	mov	x19, x0
    if(ssid == 0 || psk == 0){
 514:	fa401a84 	ccmp	x20, #0x0, #0x4, ne	// ne = any
 518:	54fffa21 	b.ne	45c <main+0x1c>  // b.any
      printf("wifi: expected ssid= and psk= in /etc/wifi.conf\n");
 51c:	90000000 	adrp	x0, 0 <.plt-0x3a0>
 520:	91192c00 	add	x0, x0, #0x64b
 524:	17ffffe1 	b	4a8 <main+0x68>
    exit(1);
  }
  printf("wifi: associated\n");
 528:	90000000 	adrp	x0, 0 <.plt-0x3a0>
 52c:	911ab800 	add	x0, x0, #0x6ae
 530:	97ffffa4 	bl	3c0 <printf@plt>
  exit(0);
 534:	52800000 	mov	w0, #0x0                   	// #0
 538:	17ffffde 	b	4b0 <main+0x70>

000000000000053c <value>:
{
 53c:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
 540:	910003fd 	mov	x29, sp
 544:	a90153f3 	stp	x19, x20, [sp, #16]
 548:	aa0003f3 	mov	x19, x0
  int n = strlen(name);
 54c:	aa0103e0 	mov	x0, x1
{
 550:	a9025bf5 	stp	x21, x22, [sp, #32]
 554:	aa0103f5 	mov	x21, x1
  int n = strlen(name);
 558:	97ffffae 	bl	410 <strlen@plt>
 55c:	93407c14 	sxtw	x20, w0
 560:	aa1403f6 	mov	x22, x20
  while(*p){
 564:	39400260 	ldrb	w0, [x19]
 568:	35000060 	cbnz	w0, 574 <value+0x38>
  return 0;
 56c:	d2800000 	mov	x0, #0x0                   	// #0
 570:	14000013 	b	5bc <value+0x80>
    if(strncmp(p, name, n) == 0 && p[n] == '='){
 574:	2a1603e2 	mov	w2, w22
 578:	aa1503e1 	mov	x1, x21
 57c:	aa1303e0 	mov	x0, x19
 580:	97ffff98 	bl	3e0 <strncmp@plt>
 584:	350002a0 	cbnz	w0, 5d8 <value+0x9c>
 588:	38746a60 	ldrb	w0, [x19, x20]
 58c:	7100f41f 	cmp	w0, #0x3d
 590:	54000241 	b.ne	5d8 <value+0x9c>  // b.any
      char *v = p + n + 1;
 594:	91000694 	add	x20, x20, #0x1
      while(*end && *end != '\n' && *end != '\r')
 598:	92848023 	mov	x3, #0xffffffffffffdbfe    	// #-9218
      char *v = p + n + 1;
 59c:	8b140260 	add	x0, x19, x20
      char *end = v;
 5a0:	aa0003e1 	mov	x1, x0
      while(*end && *end != '\n' && *end != '\r')
 5a4:	39400022 	ldrb	w2, [x1]
 5a8:	7100345f 	cmp	w2, #0xd
 5ac:	54000108 	b.hi	5cc <value+0x90>  // b.pmore
 5b0:	9ac22862 	asr	x2, x3, x2
 5b4:	370000c2 	tbnz	w2, #0, 5cc <value+0x90>
      *end = 0;
 5b8:	3900003f 	strb	wzr, [x1]
}
 5bc:	a94153f3 	ldp	x19, x20, [sp, #16]
 5c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
 5c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
 5c8:	d65f03c0 	ret
        end++;
 5cc:	91000421 	add	x1, x1, #0x1
 5d0:	17fffff5 	b	5a4 <value+0x68>
      p++;
 5d4:	91000673 	add	x19, x19, #0x1
    while(*p && *p != '\n')
 5d8:	39400260 	ldrb	w0, [x19]
 5dc:	7100001f 	cmp	w0, #0x0
 5e0:	7a4a1804 	ccmp	w0, #0xa, #0x4, ne	// ne = any
 5e4:	54ffff81 	b.ne	5d4 <value+0x98>  // b.any
      p++;
 5e8:	7100001f 	cmp	w0, #0x0
 5ec:	9a930673 	cinc	x19, x19, ne	// ne = any
 5f0:	17ffffdd 	b	564 <value+0x28>
