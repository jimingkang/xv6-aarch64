
user/_grind:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000758 <.plt>:
 758:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 75c:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 760:	f9428e11 	ldr	x17, [x16, #1304]
 764:	91146210 	add	x16, x16, #0x518
 768:	d61f0220 	br	x17
 76c:	d503201f 	nop
 770:	d503201f 	nop
 774:	d503201f 	nop

0000000000000778 <printf@plt>:
 778:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 77c:	f9429211 	ldr	x17, [x16, #1312]
 780:	91148210 	add	x16, x16, #0x520
 784:	d61f0220 	br	x17

0000000000000788 <getpid@plt>:
 788:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 78c:	f9429611 	ldr	x17, [x16, #1320]
 790:	9114a210 	add	x16, x16, #0x528
 794:	d61f0220 	br	x17

0000000000000798 <pipe@plt>:
 798:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 79c:	f9429a11 	ldr	x17, [x16, #1328]
 7a0:	9114c210 	add	x16, x16, #0x530
 7a4:	d61f0220 	br	x17

00000000000007a8 <write@plt>:
 7a8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 7ac:	f9429e11 	ldr	x17, [x16, #1336]
 7b0:	9114e210 	add	x16, x16, #0x538
 7b4:	d61f0220 	br	x17

00000000000007b8 <fstat@plt>:
 7b8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 7bc:	f942a211 	ldr	x17, [x16, #1344]
 7c0:	91150210 	add	x16, x16, #0x540
 7c4:	d61f0220 	br	x17

00000000000007c8 <fprintf@plt>:
 7c8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 7cc:	f942a611 	ldr	x17, [x16, #1352]
 7d0:	91152210 	add	x16, x16, #0x548
 7d4:	d61f0220 	br	x17

00000000000007d8 <kill@plt>:
 7d8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 7dc:	f942aa11 	ldr	x17, [x16, #1360]
 7e0:	91154210 	add	x16, x16, #0x550
 7e4:	d61f0220 	br	x17

00000000000007e8 <sleep_ticks@plt>:
 7e8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 7ec:	f942ae11 	ldr	x17, [x16, #1368]
 7f0:	91156210 	add	x16, x16, #0x558
 7f4:	d61f0220 	br	x17

00000000000007f8 <chdir@plt>:
 7f8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 7fc:	f942b211 	ldr	x17, [x16, #1376]
 800:	91158210 	add	x16, x16, #0x560
 804:	d61f0220 	br	x17

0000000000000808 <exec@plt>:
 808:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 80c:	f942b611 	ldr	x17, [x16, #1384]
 810:	9115a210 	add	x16, x16, #0x568
 814:	d61f0220 	br	x17

0000000000000818 <wait@plt>:
 818:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 81c:	f942ba11 	ldr	x17, [x16, #1392]
 820:	9115c210 	add	x16, x16, #0x570
 824:	d61f0220 	br	x17

0000000000000828 <read@plt>:
 828:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 82c:	f942be11 	ldr	x17, [x16, #1400]
 830:	9115e210 	add	x16, x16, #0x578
 834:	d61f0220 	br	x17

0000000000000838 <unlink@plt>:
 838:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 83c:	f942c211 	ldr	x17, [x16, #1408]
 840:	91160210 	add	x16, x16, #0x580
 844:	d61f0220 	br	x17

0000000000000848 <fork@plt>:
 848:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 84c:	f942c611 	ldr	x17, [x16, #1416]
 850:	91162210 	add	x16, x16, #0x588
 854:	d61f0220 	br	x17

0000000000000858 <sbrk@plt>:
 858:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 85c:	f942ca11 	ldr	x17, [x16, #1424]
 860:	91164210 	add	x16, x16, #0x590
 864:	d61f0220 	br	x17

0000000000000868 <strcmp@plt>:
 868:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 86c:	f942ce11 	ldr	x17, [x16, #1432]
 870:	91166210 	add	x16, x16, #0x598
 874:	d61f0220 	br	x17

0000000000000878 <dup@plt>:
 878:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 87c:	f942d211 	ldr	x17, [x16, #1440]
 880:	91168210 	add	x16, x16, #0x5a0
 884:	d61f0220 	br	x17

0000000000000888 <link@plt>:
 888:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 88c:	f942d611 	ldr	x17, [x16, #1448]
 890:	9116a210 	add	x16, x16, #0x5a8
 894:	d61f0220 	br	x17

0000000000000898 <exit@plt>:
 898:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 89c:	f942da11 	ldr	x17, [x16, #1456]
 8a0:	9116c210 	add	x16, x16, #0x5b0
 8a4:	d61f0220 	br	x17

00000000000008a8 <open@plt>:
 8a8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 8ac:	f942de11 	ldr	x17, [x16, #1464]
 8b0:	9116e210 	add	x16, x16, #0x5b8
 8b4:	d61f0220 	br	x17

00000000000008b8 <mkdir@plt>:
 8b8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 8bc:	f942e211 	ldr	x17, [x16, #1472]
 8c0:	91170210 	add	x16, x16, #0x5c0
 8c4:	d61f0220 	br	x17

00000000000008c8 <close@plt>:
 8c8:	d0000010 	adrp	x16, 2000 <iter+0xfa0>
 8cc:	f942e611 	ldr	x17, [x16, #1480]
 8d0:	91172210 	add	x16, x16, #0x5c8
 8d4:	d61f0220 	br	x17

Disassembly of section .text:

00000000000008d8 <main>:
  exit(0);
}

int
main()
{
     8d8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
     8dc:	910003fd 	mov	x29, sp
  while(1){
    int pid = fork();
     8e0:	97ffffda 	bl	848 <fork@plt>
    if(pid == 0){
     8e4:	35000040 	cbnz	w0, 8ec <main+0x14>
      iter();
     8e8:	940001de 	bl	1060 <iter>
     8ec:	7100001f 	cmp	w0, #0x0
      exit(0);
    }
    if(pid > 0){
     8f0:	5400006d 	b.le	8fc <main+0x24>
      wait(0);
     8f4:	d2800000 	mov	x0, #0x0                   	// #0
     8f8:	97ffffc8 	bl	818 <wait@plt>
    }
    sleep_ticks(20);
     8fc:	52800280 	mov	w0, #0x14                  	// #20
     900:	97ffffba 	bl	7e8 <sleep_ticks@plt>
  while(1){
     904:	17fffff7 	b	8e0 <main+0x8>

0000000000000908 <do_rand>:
{
     908:	aa0003e3 	mov	x3, x0
    x = (*ctx % 0x7ffffffe) + 1;
     90c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
     910:	f9400061 	ldr	x1, [x3]
     914:	9ac00822 	udiv	x2, x1, x0
     918:	9b008442 	msub	x2, x2, x0, x1
    lo = x % 127773;
     91c:	d29e63a1 	mov	x1, #0xf31d                	// #62237
     920:	f2a00021 	movk	x1, #0x1, lsl #16
    x = (*ctx % 0x7ffffffe) + 1;
     924:	91000442 	add	x2, x2, #0x1
    lo = x % 127773;
     928:	9ac10840 	udiv	x0, x2, x1
     92c:	9b018801 	msub	x1, x0, x1, x2
    x = 16807 * lo - 2836 * hi;
     930:	12816262 	mov	w2, #0xfffff4ec            	// #-2836
     934:	9b227c00 	smull	x0, w0, w2
     938:	528834e2 	mov	w2, #0x41a7                	// #16807
     93c:	9b220021 	smaddl	x1, w1, w2, x0
        x += 0x7fffffff;
     940:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    if (x < 0)
     944:	f100003f 	cmp	x1, #0x0
        x += 0x7fffffff;
     948:	8b000020 	add	x0, x1, x0
     94c:	9a80a021 	csel	x1, x1, x0, ge	// ge = tcont
    x--;
     950:	d1000420 	sub	x0, x1, #0x1
    *ctx = x;
     954:	f9000060 	str	x0, [x3]
}
     958:	d65f03c0 	ret

000000000000095c <rand>:
    return (do_rand(&rand_next));
     95c:	d0000000 	adrp	x0, 2000 <iter+0xfa0>
     960:	91174000 	add	x0, x0, #0x5d0
     964:	17ffffe9 	b	908 <do_rand>

0000000000000968 <go>:
{
     968:	a9b67bfd 	stp	x29, x30, [sp, #-160]!
     96c:	910003fd 	mov	x29, sp
     970:	a90153f3 	stp	x19, x20, [sp, #16]
     974:	2a0003f3 	mov	w19, w0
  mkdir("grindir");
     978:	b0000014 	adrp	x20, 1000 <go+0x698>
     97c:	91048294 	add	x20, x20, #0x120
  char *break0 = sbrk(0);
     980:	52800000 	mov	w0, #0x0                   	// #0
{
     984:	a9025bf5 	stp	x21, x22, [sp, #32]
     988:	a90363f7 	stp	x23, x24, [sp, #48]
     98c:	a9046bf9 	stp	x25, x26, [sp, #64]
     990:	a90573fb 	stp	x27, x28, [sp, #80]
  char *break0 = sbrk(0);
     994:	97ffffb1 	bl	858 <sbrk@plt>
     998:	aa0003fc 	mov	x28, x0
  mkdir("grindir");
     99c:	aa1403e0 	mov	x0, x20
     9a0:	97ffffc6 	bl	8b8 <mkdir@plt>
  if(chdir("grindir") != 0){
     9a4:	aa1403e0 	mov	x0, x20
     9a8:	97ffff94 	bl	7f8 <chdir@plt>
     9ac:	340000c0 	cbz	w0, 9c4 <go+0x5c>
    printf("grind: chdir grindir failed\n");
     9b0:	b0000000 	adrp	x0, 1000 <go+0x698>
     9b4:	9104a000 	add	x0, x0, #0x128
        printf("grind: fork failed\n");
     9b8:	97ffff70 	bl	778 <printf@plt>
        exit(1);
     9bc:	52800020 	mov	w0, #0x1                   	// #1
     9c0:	14000080 	b	bc0 <go+0x258>
  chdir("/");
     9c4:	b0000017 	adrp	x23, 1000 <go+0x698>
     9c8:	910516f7 	add	x23, x23, #0x145
     9cc:	aa1703e0 	mov	x0, x23
     9d0:	97ffff8a 	bl	7f8 <chdir@plt>
     9d4:	7100027f 	cmp	w19, #0x0
     9d8:	b0000001 	adrp	x1, 1000 <go+0x698>
     9dc:	91051c21 	add	x1, x1, #0x147
     9e0:	b0000000 	adrp	x0, 1000 <go+0x698>
     9e4:	91052400 	add	x0, x0, #0x149
     9e8:	b0000018 	adrp	x24, 1000 <go+0x698>
     9ec:	910d6318 	add	x24, x24, #0x358
     9f0:	9a801020 	csel	x0, x1, x0, ne	// ne = any
  uint64 iters = 0;
     9f4:	d2800016 	mov	x22, #0x0                   	// #0
  int fd = -1;
     9f8:	12800013 	mov	w19, #0xffffffff            	// #-1
    iters++;
     9fc:	d2803e9b 	mov	x27, #0x1f4                 	// #500
     a00:	f90033e0 	str	x0, [sp, #96]
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     a04:	b0000000 	adrp	x0, 1000 <go+0x698>
     a08:	910d2c00 	add	x0, x0, #0x34b
     a0c:	f90037e0 	str	x0, [sp, #104]
    iters++;
     a10:	910006d6 	add	x22, x22, #0x1
     a14:	9adb0ac0 	udiv	x0, x22, x27
     a18:	9b1bd800 	msub	x0, x0, x27, x22
    if((iters % 500) == 0)
     a1c:	b50000a0 	cbnz	x0, a30 <go+0xc8>
      write(1, which_child?"B":"A", 1);
     a20:	f94033e1 	ldr	x1, [sp, #96]
     a24:	52800022 	mov	w2, #0x1                   	// #1
     a28:	2a0203e0 	mov	w0, w2
     a2c:	97ffff5f 	bl	7a8 <write@plt>
    int what = rand() % 23;
     a30:	97ffffcb 	bl	95c <rand>
     a34:	528002e2 	mov	w2, #0x17                  	// #23
     a38:	1ac20c01 	sdiv	w1, w0, w2
     a3c:	1b028020 	msub	w0, w1, w2, w0
     a40:	51000400 	sub	w0, w0, #0x1
     a44:	7100541f 	cmp	w0, #0x15
     a48:	54fffe48 	b.hi	a10 <go+0xa8>  // b.pmore
     a4c:	78605b00 	ldrh	w0, [x24, w0, uxtw #1]
     a50:	10000061 	adr	x1, a5c <go+0xf4>
     a54:	8b20a820 	add	x0, x1, w0, sxth #2
     a58:	d61f0000 	br	x0
      close(open("grindir/../a", O_CREATE|O_RDWR));
     a5c:	b0000000 	adrp	x0, 1000 <go+0x698>
     a60:	9106a000 	add	x0, x0, #0x1a8
      close(open("grindir/../grindir/../b", O_CREATE|O_RDWR));
     a64:	52804041 	mov	w1, #0x202                 	// #514
     a68:	97ffff90 	bl	8a8 <open@plt>
     a6c:	97ffff97 	bl	8c8 <close@plt>
     a70:	17ffffe8 	b	a10 <go+0xa8>
     a74:	b0000000 	adrp	x0, 1000 <go+0x698>
     a78:	91052c00 	add	x0, x0, #0x14b
     a7c:	17fffffa 	b	a64 <go+0xfc>
      unlink("grindir/../a");
     a80:	b0000000 	adrp	x0, 1000 <go+0x698>
     a84:	9106a000 	add	x0, x0, #0x1a8
      unlink("c");
     a88:	97ffff6c 	bl	838 <unlink@plt>
     a8c:	17ffffe1 	b	a10 <go+0xa8>
      if(chdir("grindir") != 0){
     a90:	aa1403e0 	mov	x0, x20
     a94:	97ffff59 	bl	7f8 <chdir@plt>
     a98:	35fff8c0 	cbnz	w0, 9b0 <go+0x48>
      unlink("../b");
     a9c:	b0000000 	adrp	x0, 1000 <go+0x698>
     aa0:	9105c000 	add	x0, x0, #0x170
     aa4:	97ffff65 	bl	838 <unlink@plt>
      chdir("/");
     aa8:	aa1703e0 	mov	x0, x23
     aac:	97ffff53 	bl	7f8 <chdir@plt>
     ab0:	17ffffd8 	b	a10 <go+0xa8>
      close(fd);
     ab4:	2a1303e0 	mov	w0, w19
     ab8:	97ffff84 	bl	8c8 <close@plt>
      fd = open("/grindir/../a", O_CREATE|O_RDWR);
     abc:	b0000000 	adrp	x0, 1000 <go+0x698>
     ac0:	91069c00 	add	x0, x0, #0x1a7
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
     ac4:	52804041 	mov	w1, #0x202                 	// #514
     ac8:	97ffff78 	bl	8a8 <open@plt>
     acc:	2a0003f3 	mov	w19, w0
     ad0:	17ffffd0 	b	a10 <go+0xa8>
      close(fd);
     ad4:	2a1303e0 	mov	w0, w19
     ad8:	97ffff7c 	bl	8c8 <close@plt>
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
     adc:	b0000000 	adrp	x0, 1000 <go+0x698>
     ae0:	91058c00 	add	x0, x0, #0x163
     ae4:	17fffff8 	b	ac4 <go+0x15c>
      write(fd, buf, sizeof(buf));
     ae8:	2a1303e0 	mov	w0, w19
     aec:	d0000001 	adrp	x1, 2000 <iter+0xfa0>
     af0:	91176021 	add	x1, x1, #0x5d8
     af4:	52807ce2 	mov	w2, #0x3e7                 	// #999
     af8:	97ffff2c 	bl	7a8 <write@plt>
     afc:	17ffffc5 	b	a10 <go+0xa8>
      read(fd, buf, sizeof(buf));
     b00:	2a1303e0 	mov	w0, w19
     b04:	d0000001 	adrp	x1, 2000 <iter+0xfa0>
     b08:	91176021 	add	x1, x1, #0x5d8
     b0c:	52807ce2 	mov	w2, #0x3e7                 	// #999
     b10:	97ffff46 	bl	828 <read@plt>
     b14:	17ffffbf 	b	a10 <go+0xa8>
      mkdir("grindir/../a");
     b18:	b0000000 	adrp	x0, 1000 <go+0x698>
     b1c:	9106a000 	add	x0, x0, #0x1a8
     b20:	97ffff66 	bl	8b8 <mkdir@plt>
      close(open("a/../a/./a", O_CREATE|O_RDWR));
     b24:	52804041 	mov	w1, #0x202                 	// #514
     b28:	b0000000 	adrp	x0, 1000 <go+0x698>
     b2c:	9105d400 	add	x0, x0, #0x175
     b30:	97ffff5e 	bl	8a8 <open@plt>
     b34:	97ffff65 	bl	8c8 <close@plt>
      unlink("a/a");
     b38:	b0000000 	adrp	x0, 1000 <go+0x698>
     b3c:	91060000 	add	x0, x0, #0x180
     b40:	17ffffd2 	b	a88 <go+0x120>
      mkdir("/../b");
     b44:	b0000000 	adrp	x0, 1000 <go+0x698>
     b48:	9105bc00 	add	x0, x0, #0x16f
     b4c:	97ffff5b 	bl	8b8 <mkdir@plt>
      close(open("grindir/../b/b", O_CREATE|O_RDWR));
     b50:	52804041 	mov	w1, #0x202                 	// #514
     b54:	b0000000 	adrp	x0, 1000 <go+0x698>
     b58:	91061000 	add	x0, x0, #0x184
     b5c:	97ffff53 	bl	8a8 <open@plt>
     b60:	97ffff5a 	bl	8c8 <close@plt>
      unlink("b/b");
     b64:	b0000000 	adrp	x0, 1000 <go+0x698>
     b68:	91063c00 	add	x0, x0, #0x18f
     b6c:	17ffffc7 	b	a88 <go+0x120>
      unlink("b");
     b70:	b0000000 	adrp	x0, 1000 <go+0x698>
     b74:	9105cc00 	add	x0, x0, #0x173
     b78:	97ffff30 	bl	838 <unlink@plt>
      link("../grindir/./../a", "../b");
     b7c:	b0000001 	adrp	x1, 1000 <go+0x698>
     b80:	9105c021 	add	x1, x1, #0x170
     b84:	b0000000 	adrp	x0, 1000 <go+0x698>
     b88:	91064c00 	add	x0, x0, #0x193
      link(".././b", "/grindir/../a");
     b8c:	97ffff3f 	bl	888 <link@plt>
     b90:	17ffffa0 	b	a10 <go+0xa8>
      unlink("../grindir/../a");
     b94:	b0000000 	adrp	x0, 1000 <go+0x698>
     b98:	91069400 	add	x0, x0, #0x1a5
     b9c:	97ffff27 	bl	838 <unlink@plt>
      link(".././b", "/grindir/../a");
     ba0:	b0000001 	adrp	x1, 1000 <go+0x698>
     ba4:	91069c21 	add	x1, x1, #0x1a7
     ba8:	b0000000 	adrp	x0, 1000 <go+0x698>
     bac:	9106d400 	add	x0, x0, #0x1b5
     bb0:	17fffff7 	b	b8c <go+0x224>
      int pid = fork();
     bb4:	97ffff25 	bl	848 <fork@plt>
      if(pid == 0){
     bb8:	35000060 	cbnz	w0, bc4 <go+0x25c>
        exit(0);
     bbc:	52800000 	mov	w0, #0x0                   	// #0
     bc0:	97ffff36 	bl	898 <exit@plt>
      } else if(pid < 0){
     bc4:	36f804e0 	tbz	w0, #31, c60 <go+0x2f8>
        printf("grind: fork failed\n");
     bc8:	b0000000 	adrp	x0, 1000 <go+0x698>
     bcc:	9106f000 	add	x0, x0, #0x1bc
     bd0:	17ffff7a 	b	9b8 <go+0x50>
      int pid = fork();
     bd4:	97ffff1d 	bl	848 <fork@plt>
      if(pid == 0){
     bd8:	35ffff60 	cbnz	w0, bc4 <go+0x25c>
        fork();
     bdc:	97ffff1b 	bl	848 <fork@plt>
        fork();
     be0:	97ffff1a 	bl	848 <fork@plt>
        exit(0);
     be4:	17fffff6 	b	bbc <go+0x254>
      sbrk(6011);
     be8:	5282ef60 	mov	w0, #0x177b                	// #6011
        sbrk(-(sbrk(0) - break0));
     bec:	97ffff1b 	bl	858 <sbrk@plt>
     bf0:	17ffff88 	b	a10 <go+0xa8>
      if(sbrk(0) > break0)
     bf4:	52800000 	mov	w0, #0x0                   	// #0
     bf8:	97ffff18 	bl	858 <sbrk@plt>
     bfc:	eb1c001f 	cmp	x0, x28
     c00:	54fff089 	b.ls	a10 <go+0xa8>  // b.plast
        sbrk(-(sbrk(0) - break0));
     c04:	52800000 	mov	w0, #0x0                   	// #0
     c08:	97ffff14 	bl	858 <sbrk@plt>
     c0c:	4b000380 	sub	w0, w28, w0
     c10:	17fffff7 	b	bec <go+0x284>
      int pid = fork();
     c14:	97ffff0d 	bl	848 <fork@plt>
     c18:	2a0003f5 	mov	w21, w0
      if(pid == 0){
     c1c:	350000e0 	cbnz	w0, c38 <go+0x2d0>
        close(open("a", O_CREATE|O_RDWR));
     c20:	52804041 	mov	w1, #0x202                 	// #514
     c24:	b0000000 	adrp	x0, 1000 <go+0x698>
     c28:	91068c00 	add	x0, x0, #0x1a3
     c2c:	97ffff1f 	bl	8a8 <open@plt>
     c30:	97ffff26 	bl	8c8 <close@plt>
        exit(0);
     c34:	17ffffe2 	b	bbc <go+0x254>
      } else if(pid < 0){
     c38:	37fffc80 	tbnz	w0, #31, bc8 <go+0x260>
      if(chdir("../grindir/..") != 0){
     c3c:	b0000000 	adrp	x0, 1000 <go+0x698>
     c40:	91074000 	add	x0, x0, #0x1d0
     c44:	97fffeed 	bl	7f8 <chdir@plt>
     c48:	34000080 	cbz	w0, c58 <go+0x2f0>
        printf("grind: chdir failed\n");
     c4c:	b0000000 	adrp	x0, 1000 <go+0x698>
     c50:	91077800 	add	x0, x0, #0x1de
     c54:	17ffff59 	b	9b8 <go+0x50>
      kill(pid);
     c58:	2a1503e0 	mov	w0, w21
     c5c:	97fffedf 	bl	7d8 <kill@plt>
      wait(0);
     c60:	d2800000 	mov	x0, #0x0                   	// #0
     c64:	97fffeed 	bl	818 <wait@plt>
     c68:	17ffff6a 	b	a10 <go+0xa8>
      int pid = fork();
     c6c:	97fffef7 	bl	848 <fork@plt>
      if(pid == 0){
     c70:	35fffaa0 	cbnz	w0, bc4 <go+0x25c>
        kill(getpid());
     c74:	97fffec5 	bl	788 <getpid@plt>
     c78:	97fffed8 	bl	7d8 <kill@plt>
        exit(0);
     c7c:	17ffffd0 	b	bbc <go+0x254>
      if(pipe(fds) < 0){
     c80:	910223e0 	add	x0, sp, #0x88
     c84:	97fffec5 	bl	798 <pipe@plt>
     c88:	36f80080 	tbz	w0, #31, c98 <go+0x330>
        printf("grind: pipe failed\n");
     c8c:	b0000000 	adrp	x0, 1000 <go+0x698>
     c90:	9107cc00 	add	x0, x0, #0x1f3
     c94:	17ffff49 	b	9b8 <go+0x50>
      int pid = fork();
     c98:	97fffeec 	bl	848 <fork@plt>
      if(pid == 0){
     c9c:	350002e0 	cbnz	w0, cf8 <go+0x390>
        fork();
     ca0:	97fffeea 	bl	848 <fork@plt>
        fork();
     ca4:	97fffee9 	bl	848 <fork@plt>
        if(write(fds[1], "x", 1) != 1)
     ca8:	b9408fe0 	ldr	w0, [sp, #140]
     cac:	b0000001 	adrp	x1, 1000 <go+0x698>
     cb0:	91081c21 	add	x1, x1, #0x207
     cb4:	52800022 	mov	w2, #0x1                   	// #1
     cb8:	97fffebc 	bl	7a8 <write@plt>
     cbc:	7100041f 	cmp	w0, #0x1
     cc0:	54000080 	b.eq	cd0 <go+0x368>  // b.none
          printf("grind: pipe write failed\n");
     cc4:	b0000000 	adrp	x0, 1000 <go+0x698>
     cc8:	91082400 	add	x0, x0, #0x209
     ccc:	97fffeab 	bl	778 <printf@plt>
        if(read(fds[0], &c, 1) != 1)
     cd0:	b9408be0 	ldr	w0, [sp, #136]
     cd4:	910203e1 	add	x1, sp, #0x80
     cd8:	52800022 	mov	w2, #0x1                   	// #1
     cdc:	97fffed3 	bl	828 <read@plt>
     ce0:	7100041f 	cmp	w0, #0x1
     ce4:	54fff6c0 	b.eq	bbc <go+0x254>  // b.none
          printf("grind: pipe read failed\n");
     ce8:	b0000000 	adrp	x0, 1000 <go+0x698>
     cec:	91088c00 	add	x0, x0, #0x223
     cf0:	97fffea2 	bl	778 <printf@plt>
     cf4:	17ffffb2 	b	bbc <go+0x254>
      } else if(pid < 0){
     cf8:	37fff680 	tbnz	w0, #31, bc8 <go+0x260>
      close(fds[0]);
     cfc:	b9408be0 	ldr	w0, [sp, #136]
     d00:	97fffef2 	bl	8c8 <close@plt>
      close(fds[1]);
     d04:	b9408fe0 	ldr	w0, [sp, #140]
     d08:	97fffef0 	bl	8c8 <close@plt>
      wait(0);
     d0c:	17ffffd5 	b	c60 <go+0x2f8>
      int pid = fork();
     d10:	97fffece 	bl	848 <fork@plt>
      if(pid == 0){
     d14:	35fff580 	cbnz	w0, bc4 <go+0x25c>
        unlink("a");
     d18:	b0000013 	adrp	x19, 1000 <go+0x698>
     d1c:	91068e60 	add	x0, x19, #0x1a3
     d20:	97fffec6 	bl	838 <unlink@plt>
        mkdir("a");
     d24:	91068e60 	add	x0, x19, #0x1a3
     d28:	97fffee4 	bl	8b8 <mkdir@plt>
        chdir("a");
     d2c:	91068e60 	add	x0, x19, #0x1a3
     d30:	97fffeb2 	bl	7f8 <chdir@plt>
        unlink("../a");
     d34:	b0000000 	adrp	x0, 1000 <go+0x698>
     d38:	91068000 	add	x0, x0, #0x1a0
     d3c:	97fffebf 	bl	838 <unlink@plt>
        fd = open("x", O_CREATE|O_RDWR);
     d40:	b0000013 	adrp	x19, 1000 <go+0x698>
     d44:	52804041 	mov	w1, #0x202                 	// #514
     d48:	91081e60 	add	x0, x19, #0x207
     d4c:	97fffed7 	bl	8a8 <open@plt>
        unlink("x");
     d50:	91081e60 	add	x0, x19, #0x207
     d54:	97fffeb9 	bl	838 <unlink@plt>
        exit(0);
     d58:	17ffff99 	b	bbc <go+0x254>
      unlink("c");
     d5c:	b0000015 	adrp	x21, 1000 <go+0x698>
     d60:	9108f2a0 	add	x0, x21, #0x23c
     d64:	97fffeb5 	bl	838 <unlink@plt>
      int fd1 = open("c", O_CREATE|O_RDWR);
     d68:	9108f2a0 	add	x0, x21, #0x23c
     d6c:	52804041 	mov	w1, #0x202                 	// #514
     d70:	97fffece 	bl	8a8 <open@plt>
     d74:	2a0003f9 	mov	w25, w0
      if(fd1 < 0){
     d78:	36f80080 	tbz	w0, #31, d88 <go+0x420>
        printf("grind: create c failed\n");
     d7c:	b0000000 	adrp	x0, 1000 <go+0x698>
     d80:	9108f800 	add	x0, x0, #0x23e
     d84:	17ffff0d 	b	9b8 <go+0x50>
      if(write(fd1, "x", 1) != 1){
     d88:	b0000001 	adrp	x1, 1000 <go+0x698>
     d8c:	91081c21 	add	x1, x1, #0x207
     d90:	52800022 	mov	w2, #0x1                   	// #1
     d94:	97fffe85 	bl	7a8 <write@plt>
     d98:	7100041f 	cmp	w0, #0x1
     d9c:	54000080 	b.eq	dac <go+0x444>  // b.none
        printf("grind: write c failed\n");
     da0:	b0000000 	adrp	x0, 1000 <go+0x698>
     da4:	91095800 	add	x0, x0, #0x256
     da8:	17ffff04 	b	9b8 <go+0x50>
      if(fstat(fd1, &st) != 0){
     dac:	910223e1 	add	x1, sp, #0x88
     db0:	2a1903e0 	mov	w0, w25
     db4:	97fffe81 	bl	7b8 <fstat@plt>
     db8:	34000080 	cbz	w0, dc8 <go+0x460>
        printf("grind: fstat failed\n");
     dbc:	b0000000 	adrp	x0, 1000 <go+0x698>
     dc0:	9109b400 	add	x0, x0, #0x26d
     dc4:	17fffefd 	b	9b8 <go+0x50>
      if(st.size != 1){
     dc8:	f9404fe2 	ldr	x2, [sp, #152]
     dcc:	f100045f 	cmp	x2, #0x1
     dd0:	540000c0 	b.eq	de8 <go+0x480>  // b.none
        printf("grind: fstat reports wrong size %d\n", (int)st.size);
     dd4:	b0000000 	adrp	x0, 1000 <go+0x698>
     dd8:	910a0800 	add	x0, x0, #0x282
     ddc:	2a0203e1 	mov	w1, w2
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
     de0:	97fffe66 	bl	778 <printf@plt>
        exit(1);
     de4:	17fffef6 	b	9bc <go+0x54>
      if(st.ino > 200){
     de8:	b9408fe1 	ldr	w1, [sp, #140]
     dec:	7103203f 	cmp	w1, #0xc8
     df0:	540000a9 	b.ls	e04 <go+0x49c>  // b.plast
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
     df4:	b0000000 	adrp	x0, 1000 <go+0x698>
     df8:	910a9800 	add	x0, x0, #0x2a6
     dfc:	f90033e2 	str	x2, [sp, #96]
     e00:	17fffff8 	b	de0 <go+0x478>
      close(fd1);
     e04:	2a1903e0 	mov	w0, w25
     e08:	97fffeb0 	bl	8c8 <close@plt>
      unlink("c");
     e0c:	9108f2a0 	add	x0, x21, #0x23c
     e10:	17ffff1e 	b	a88 <go+0x120>
      if(pipe(aa) < 0){
     e14:	9101e3e0 	add	x0, sp, #0x78
     e18:	97fffe60 	bl	798 <pipe@plt>
     e1c:	36f800c0 	tbz	w0, #31, e34 <go+0x4cc>
        fprintf(2, "grind: pipe failed\n");
     e20:	b0000001 	adrp	x1, 1000 <go+0x698>
     e24:	9107cc21 	add	x1, x1, #0x1f3
          fprintf(2, "grind: dup failed\n");
     e28:	52800040 	mov	w0, #0x2                   	// #2
     e2c:	97fffe67 	bl	7c8 <fprintf@plt>
          exit(1);
     e30:	17fffee3 	b	9bc <go+0x54>
      if(pipe(bb) < 0){
     e34:	910203e0 	add	x0, sp, #0x80
     e38:	97fffe58 	bl	798 <pipe@plt>
     e3c:	37ffff20 	tbnz	w0, #31, e20 <go+0x4b8>
      int pid1 = fork();
     e40:	97fffe82 	bl	848 <fork@plt>
      if(pid1 == 0){
     e44:	35000440 	cbnz	w0, ecc <go+0x564>
        close(bb[0]);
     e48:	b94083e0 	ldr	w0, [sp, #128]
     e4c:	97fffe9f 	bl	8c8 <close@plt>
        close(bb[1]);
     e50:	b94087e0 	ldr	w0, [sp, #132]
     e54:	97fffe9d 	bl	8c8 <close@plt>
        close(aa[0]);
     e58:	b9407be0 	ldr	w0, [sp, #120]
     e5c:	97fffe9b 	bl	8c8 <close@plt>
        close(1);
     e60:	52800020 	mov	w0, #0x1                   	// #1
     e64:	97fffe99 	bl	8c8 <close@plt>
        if(dup(aa[1]) != 1){
     e68:	b9407fe0 	ldr	w0, [sp, #124]
     e6c:	97fffe83 	bl	878 <dup@plt>
     e70:	7100041f 	cmp	w0, #0x1
     e74:	54000080 	b.eq	e84 <go+0x51c>  // b.none
          fprintf(2, "grind: dup failed\n");
     e78:	b0000001 	adrp	x1, 1000 <go+0x698>
     e7c:	910b3821 	add	x1, x1, #0x2ce
     e80:	17ffffea 	b	e28 <go+0x4c0>
        close(aa[1]);
     e84:	b9407fe0 	ldr	w0, [sp, #124]
     e88:	97fffe90 	bl	8c8 <close@plt>
        char *args[3] = { "echo", "hi", 0 };
     e8c:	b0000000 	adrp	x0, 1000 <go+0x698>
     e90:	910e2000 	add	x0, x0, #0x388
        exec("/bin/echo", args);
     e94:	910223e1 	add	x1, sp, #0x88
        char *args[3] = { "echo", "hi", 0 };
     e98:	a9400c02 	ldp	x2, x3, [x0]
     e9c:	a9088fe2 	stp	x2, x3, [sp, #136]
     ea0:	f9400800 	ldr	x0, [x0, #16]
     ea4:	f9004fe0 	str	x0, [sp, #152]
        exec("/bin/echo", args);
     ea8:	b0000000 	adrp	x0, 1000 <go+0x698>
     eac:	910b8400 	add	x0, x0, #0x2e1
     eb0:	97fffe56 	bl	808 <exec@plt>
        fprintf(2, "grind: echo: not found\n");
     eb4:	b0000001 	adrp	x1, 1000 <go+0x698>
     eb8:	910bac21 	add	x1, x1, #0x2eb
     ebc:	52800040 	mov	w0, #0x2                   	// #2
     ec0:	97fffe42 	bl	7c8 <fprintf@plt>
        exit(2);
     ec4:	52800040 	mov	w0, #0x2                   	// #2
     ec8:	17ffff3e 	b	bc0 <go+0x258>
      } else if(pid1 < 0){
     ecc:	36f800e0 	tbz	w0, #31, ee8 <go+0x580>
        fprintf(2, "grind: fork failed\n");
     ed0:	b0000001 	adrp	x1, 1000 <go+0x698>
     ed4:	9106f021 	add	x1, x1, #0x1bc
     ed8:	52800040 	mov	w0, #0x2                   	// #2
     edc:	97fffe3b 	bl	7c8 <fprintf@plt>
        exit(3);
     ee0:	52800060 	mov	w0, #0x3                   	// #3
     ee4:	17ffff37 	b	bc0 <go+0x258>
      int pid2 = fork();
     ee8:	97fffe58 	bl	848 <fork@plt>
      if(pid2 == 0){
     eec:	350005a0 	cbnz	w0, fa0 <go+0x638>
        close(aa[1]);
     ef0:	b9407fe0 	ldr	w0, [sp, #124]
     ef4:	b0000013 	adrp	x19, 1000 <go+0x698>
     ef8:	910b3a73 	add	x19, x19, #0x2ce
     efc:	97fffe73 	bl	8c8 <close@plt>
        close(bb[0]);
     f00:	b94083e0 	ldr	w0, [sp, #128]
     f04:	97fffe71 	bl	8c8 <close@plt>
        close(0);
     f08:	52800000 	mov	w0, #0x0                   	// #0
     f0c:	97fffe6f 	bl	8c8 <close@plt>
        if(dup(aa[0]) != 0){
     f10:	b9407be0 	ldr	w0, [sp, #120]
     f14:	97fffe59 	bl	878 <dup@plt>
     f18:	340000c0 	cbz	w0, f30 <go+0x5c8>
          fprintf(2, "grind: dup failed\n");
     f1c:	aa1303e1 	mov	x1, x19
     f20:	52800040 	mov	w0, #0x2                   	// #2
     f24:	97fffe29 	bl	7c8 <fprintf@plt>
          exit(4);
     f28:	52800080 	mov	w0, #0x4                   	// #4
     f2c:	17ffff25 	b	bc0 <go+0x258>
        close(aa[0]);
     f30:	b9407be0 	ldr	w0, [sp, #120]
     f34:	97fffe65 	bl	8c8 <close@plt>
        close(1);
     f38:	52800020 	mov	w0, #0x1                   	// #1
     f3c:	97fffe63 	bl	8c8 <close@plt>
        if(dup(bb[1]) != 1){
     f40:	b94087e0 	ldr	w0, [sp, #132]
     f44:	97fffe4d 	bl	878 <dup@plt>
     f48:	7100041f 	cmp	w0, #0x1
     f4c:	540000c0 	b.eq	f64 <go+0x5fc>  // b.none
          fprintf(2, "grind: dup failed\n");
     f50:	aa1303e1 	mov	x1, x19
     f54:	52800040 	mov	w0, #0x2                   	// #2
     f58:	97fffe1c 	bl	7c8 <fprintf@plt>
          exit(5);
     f5c:	528000a0 	mov	w0, #0x5                   	// #5
     f60:	17ffff18 	b	bc0 <go+0x258>
        close(bb[1]);
     f64:	b94087e0 	ldr	w0, [sp, #132]
     f68:	97fffe58 	bl	8c8 <close@plt>
        char *args[2] = { "cat", 0 };
     f6c:	b0000000 	adrp	x0, 1000 <go+0x698>
     f70:	910c2000 	add	x0, x0, #0x308
        exec("/bin/cat", args);
     f74:	910223e1 	add	x1, sp, #0x88
        char *args[2] = { "cat", 0 };
     f78:	a908ffe0 	stp	x0, xzr, [sp, #136]
        exec("/bin/cat", args);
     f7c:	b0000000 	adrp	x0, 1000 <go+0x698>
     f80:	910c0c00 	add	x0, x0, #0x303
     f84:	97fffe21 	bl	808 <exec@plt>
        fprintf(2, "grind: cat: not found\n");
     f88:	b0000001 	adrp	x1, 1000 <go+0x698>
     f8c:	910c3021 	add	x1, x1, #0x30c
     f90:	52800040 	mov	w0, #0x2                   	// #2
     f94:	97fffe0d 	bl	7c8 <fprintf@plt>
        exit(6);
     f98:	528000c0 	mov	w0, #0x6                   	// #6
     f9c:	17ffff09 	b	bc0 <go+0x258>
      } else if(pid2 < 0){
     fa0:	36f800e0 	tbz	w0, #31, fbc <go+0x654>
        fprintf(2, "grind: fork failed\n");
     fa4:	b0000001 	adrp	x1, 1000 <go+0x698>
     fa8:	9106f021 	add	x1, x1, #0x1bc
     fac:	52800040 	mov	w0, #0x2                   	// #2
     fb0:	97fffe06 	bl	7c8 <fprintf@plt>
        exit(7);
     fb4:	528000e0 	mov	w0, #0x7                   	// #7
     fb8:	17ffff02 	b	bc0 <go+0x258>
      close(aa[0]);
     fbc:	b9407be0 	ldr	w0, [sp, #120]
     fc0:	97fffe42 	bl	8c8 <close@plt>
      close(aa[1]);
     fc4:	b9407fe0 	ldr	w0, [sp, #124]
     fc8:	97fffe40 	bl	8c8 <close@plt>
      close(bb[1]);
     fcc:	b94087e0 	ldr	w0, [sp, #132]
     fd0:	97fffe3e 	bl	8c8 <close@plt>
      char buf[4] = { 0, 0, 0, 0 };
     fd4:	b90073ff 	str	wzr, [sp, #112]
      read(bb[0], buf+0, 1);
     fd8:	b94083e0 	ldr	w0, [sp, #128]
     fdc:	9101c3e1 	add	x1, sp, #0x70
     fe0:	52800022 	mov	w2, #0x1                   	// #1
     fe4:	97fffe11 	bl	828 <read@plt>
      read(bb[0], buf+1, 1);
     fe8:	b94083e0 	ldr	w0, [sp, #128]
     fec:	9101c7e1 	add	x1, sp, #0x71
     ff0:	52800022 	mov	w2, #0x1                   	// #1
     ff4:	97fffe0d 	bl	828 <read@plt>
      read(bb[0], buf+2, 1);
     ff8:	b94083e0 	ldr	w0, [sp, #128]
     ffc:	9101cbe1 	add	x1, sp, #0x72
    1000:	52800022 	mov	w2, #0x1                   	// #1
    1004:	97fffe09 	bl	828 <read@plt>
      close(bb[0]);
    1008:	b94083e0 	ldr	w0, [sp, #128]
    100c:	97fffe2f 	bl	8c8 <close@plt>
      wait(&st1);
    1010:	9101d3e0 	add	x0, sp, #0x74
    1014:	97fffe01 	bl	818 <wait@plt>
      wait(&st2);
    1018:	910223e0 	add	x0, sp, #0x88
    101c:	97fffdff 	bl	818 <wait@plt>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
    1020:	b94077e0 	ldr	w0, [sp, #116]
    1024:	b9408be1 	ldr	w1, [sp, #136]
    1028:	2a010000 	orr	w0, w0, w1
    102c:	34000100 	cbz	w0, 104c <go+0x6e4>
        printf("grind: exec pipeline failed %d %d \"%s\"\n", st1, st2, buf);
    1030:	b94077e1 	ldr	w1, [sp, #116]
    1034:	9101c3e3 	add	x3, sp, #0x70
    1038:	b9408be2 	ldr	w2, [sp, #136]
    103c:	90000000 	adrp	x0, 1000 <go+0x698>
    1040:	910c8c00 	add	x0, x0, #0x323
    1044:	97fffdcd 	bl	778 <printf@plt>
    1048:	17fffe5d 	b	9bc <go+0x54>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
    104c:	f94037e1 	ldr	x1, [sp, #104]
    1050:	9101c3e0 	add	x0, sp, #0x70
    1054:	97fffe05 	bl	868 <strcmp@plt>
    1058:	34ffcdc0 	cbz	w0, a10 <go+0xa8>
    105c:	17fffff5 	b	1030 <go+0x6c8>

0000000000001060 <iter>:
{
    1060:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
  unlink("a");
    1064:	90000000 	adrp	x0, 1000 <go+0x698>
    1068:	91068c00 	add	x0, x0, #0x1a3
{
    106c:	910003fd 	mov	x29, sp
    1070:	a90153f3 	stp	x19, x20, [sp, #16]
  unlink("a");
    1074:	97fffdf1 	bl	838 <unlink@plt>
  unlink("b");
    1078:	90000000 	adrp	x0, 1000 <go+0x698>
    107c:	9105cc00 	add	x0, x0, #0x173
    1080:	97fffdee 	bl	838 <unlink@plt>
  int pid1 = fork();
    1084:	97fffdf1 	bl	848 <fork@plt>
  if(pid1 < 0){
    1088:	36f800c0 	tbz	w0, #31, 10a0 <iter+0x40>
    printf("grind: fork failed\n");
    108c:	90000000 	adrp	x0, 1000 <go+0x698>
    1090:	9106f000 	add	x0, x0, #0x1bc
    1094:	97fffdb9 	bl	778 <printf@plt>
    exit(1);
    1098:	52800020 	mov	w0, #0x1                   	// #1
  exit(0);
    109c:	97fffdff 	bl	898 <exit@plt>
    10a0:	2a0003f4 	mov	w20, w0
  if(pid1 == 0){
    10a4:	350000a0 	cbnz	w0, 10b8 <iter+0x58>
    rand_next = 31;
    10a8:	b0000001 	adrp	x1, 2000 <iter+0xfa0>
    10ac:	d28003e2 	mov	x2, #0x1f                  	// #31
    10b0:	f902e822 	str	x2, [x1, #1488]
    go(1);
    10b4:	97fffe2d 	bl	968 <go>
  int pid2 = fork();
    10b8:	97fffde4 	bl	848 <fork@plt>
    10bc:	2a0003f3 	mov	w19, w0
  if(pid2 < 0){
    10c0:	37fffe60 	tbnz	w0, #31, 108c <iter+0x2c>
  if(pid2 == 0){
    10c4:	350000c0 	cbnz	w0, 10dc <iter+0x7c>
    rand_next = 7177;
    10c8:	b0000000 	adrp	x0, 2000 <iter+0xfa0>
    10cc:	d2838121 	mov	x1, #0x1c09                	// #7177
    10d0:	f902e801 	str	x1, [x0, #1488]
    go(1);
    10d4:	52800020 	mov	w0, #0x1                   	// #1
    10d8:	17fffff7 	b	10b4 <iter+0x54>
  int st1 = -1;
    10dc:	12800000 	mov	w0, #0xffffffff            	// #-1
    10e0:	b9002be0 	str	w0, [sp, #40]
  wait(&st1);
    10e4:	9100a3e0 	add	x0, sp, #0x28
    10e8:	97fffdcc 	bl	818 <wait@plt>
  if(st1 != 0){
    10ec:	b9402be0 	ldr	w0, [sp, #40]
    10f0:	340000a0 	cbz	w0, 1104 <iter+0xa4>
    kill(pid1);
    10f4:	2a1403e0 	mov	w0, w20
    10f8:	97fffdb8 	bl	7d8 <kill@plt>
    kill(pid2);
    10fc:	2a1303e0 	mov	w0, w19
    1100:	97fffdb6 	bl	7d8 <kill@plt>
  int st2 = -1;
    1104:	12800000 	mov	w0, #0xffffffff            	// #-1
    1108:	b9002fe0 	str	w0, [sp, #44]
  wait(&st2);
    110c:	9100b3e0 	add	x0, sp, #0x2c
    1110:	97fffdc2 	bl	818 <wait@plt>
  exit(0);
    1114:	52800000 	mov	w0, #0x0                   	// #0
    1118:	17ffffe1 	b	109c <iter+0x3c>
