
user/_forktest:     file format elf64-littleaarch64


Disassembly of section .plt:

00000000000002e8 <.plt>:
 2e8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 2ec:	b0000010 	adrp	x16, 1000 <forktest+0xc70>
 2f0:	f942f211 	ldr	x17, [x16, #1504]
 2f4:	91178210 	add	x16, x16, #0x5e0
 2f8:	d61f0220 	br	x17
 2fc:	d503201f 	nop
 300:	d503201f 	nop
 304:	d503201f 	nop

0000000000000308 <write@plt>:
 308:	b0000010 	adrp	x16, 1000 <forktest+0xc70>
 30c:	f942f611 	ldr	x17, [x16, #1512]
 310:	9117a210 	add	x16, x16, #0x5e8
 314:	d61f0220 	br	x17

0000000000000318 <wait@plt>:
 318:	b0000010 	adrp	x16, 1000 <forktest+0xc70>
 31c:	f942fa11 	ldr	x17, [x16, #1520]
 320:	9117c210 	add	x16, x16, #0x5f0
 324:	d61f0220 	br	x17

0000000000000328 <fork@plt>:
 328:	b0000010 	adrp	x16, 1000 <forktest+0xc70>
 32c:	f942fe11 	ldr	x17, [x16, #1528]
 330:	9117e210 	add	x16, x16, #0x5f8
 334:	d61f0220 	br	x17

0000000000000338 <exit@plt>:
 338:	b0000010 	adrp	x16, 1000 <forktest+0xc70>
 33c:	f9430211 	ldr	x17, [x16, #1536]
 340:	91180210 	add	x16, x16, #0x600
 344:	d61f0220 	br	x17

0000000000000348 <strlen@plt>:
 348:	b0000010 	adrp	x16, 1000 <forktest+0xc70>
 34c:	f9430611 	ldr	x17, [x16, #1544]
 350:	91182210 	add	x16, x16, #0x608
 354:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000358 <main>:
  print("dynamic fork test OK\n");
}

int
main(void)
{
 358:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 35c:	910003fd 	mov	x29, sp
  forktest();
 360:	9400000c 	bl	390 <forktest>
  exit(0);
 364:	52800000 	mov	w0, #0x0                   	// #0
 368:	97fffff4 	bl	338 <exit@plt>

000000000000036c <print>:
{
 36c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 370:	910003fd 	mov	x29, sp
 374:	f9000fe0 	str	x0, [sp, #24]
  write(1, s, strlen(s));
 378:	97fffff4 	bl	348 <strlen@plt>
 37c:	f9400fe1 	ldr	x1, [sp, #24]
 380:	2a0003e2 	mov	w2, w0
}
 384:	a8c27bfd 	ldp	x29, x30, [sp], #32
  write(1, s, strlen(s));
 388:	52800020 	mov	w0, #0x1                   	// #1
 38c:	17ffffdf 	b	308 <write@plt>

0000000000000390 <forktest>:
{
 390:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
  print("fork test\n");
 394:	90000000 	adrp	x0, 0 <.plt-0x2e8>
 398:	9110e000 	add	x0, x0, #0x438
{
 39c:	910003fd 	mov	x29, sp
 3a0:	a90153f3 	stp	x19, x20, [sp, #16]
  for(n=0; n<N; n++){
 3a4:	52800013 	mov	w19, #0x0                   	// #0
  print("fork test\n");
 3a8:	97fffff1 	bl	36c <print>
    pid = fork();
 3ac:	97ffffdf 	bl	328 <fork@plt>
    if(pid < 0)
 3b0:	37f800c0 	tbnz	w0, #31, 3c8 <forktest+0x38>
    if(pid == 0)
 3b4:	35000040 	cbnz	w0, 3bc <forktest+0x2c>
      exit(1);
 3b8:	97ffffe0 	bl	338 <exit@plt>
  for(n=0; n<N; n++){
 3bc:	11000673 	add	w19, w19, #0x1
 3c0:	7102027f 	cmp	w19, #0x80
 3c4:	54ffff41 	b.ne	3ac <forktest+0x1c>  // b.any
  for(; n > 0; n--){
 3c8:	2a1303f4 	mov	w20, w19
    if(wait(0) < 0){
 3cc:	d2800000 	mov	x0, #0x0                   	// #0
  for(; n > 0; n--){
 3d0:	350000f4 	cbnz	w20, 3ec <forktest+0x5c>
  if(wait(0) != -1){
 3d4:	97ffffd1 	bl	318 <wait@plt>
 3d8:	3100041f 	cmn	w0, #0x1
 3dc:	540001a0 	b.eq	410 <forktest+0x80>  // b.none
    print("wait got too many\n");
 3e0:	90000000 	adrp	x0, 0 <.plt-0x2e8>
 3e4:	91115c00 	add	x0, x0, #0x457
 3e8:	14000005 	b	3fc <forktest+0x6c>
    if(wait(0) < 0){
 3ec:	97ffffcb 	bl	318 <wait@plt>
 3f0:	36f800c0 	tbz	w0, #31, 408 <forktest+0x78>
      print("wait stopped early\n");
 3f4:	90000000 	adrp	x0, 0 <.plt-0x2e8>
 3f8:	91110c00 	add	x0, x0, #0x443
 3fc:	97ffffdc 	bl	36c <print>
      exit(1);
 400:	52800020 	mov	w0, #0x1                   	// #1
 404:	17ffffed 	b	3b8 <forktest+0x28>
  for(; n > 0; n--){
 408:	51000694 	sub	w20, w20, #0x1
 40c:	17fffff0 	b	3cc <forktest+0x3c>
  if(created <= OLD_NPROC){
 410:	7101027f 	cmp	w19, #0x40
 414:	5400008c 	b.gt	424 <forktest+0x94>
    print("fork stopped at old static limit\n");
 418:	90000000 	adrp	x0, 0 <.plt-0x2e8>
 41c:	9111a800 	add	x0, x0, #0x46a
 420:	17fffff7 	b	3fc <forktest+0x6c>
}
 424:	a94153f3 	ldp	x19, x20, [sp, #16]
  print("dynamic fork test OK\n");
 428:	90000000 	adrp	x0, 0 <.plt-0x2e8>
 42c:	91123000 	add	x0, x0, #0x48c
}
 430:	a8c27bfd 	ldp	x29, x30, [sp], #32
  print("dynamic fork test OK\n");
 434:	17ffffce 	b	36c <print>
