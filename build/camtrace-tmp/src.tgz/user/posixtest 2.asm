
user/_posixtest:     file format elf64-littleaarch64


Disassembly of section .plt:

0000000000000bb8 <.plt>:
 bb8:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 bbc:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 bc0:	f9432e11 	ldr	x17, [x16, #1624]
 bc4:	91196210 	add	x16, x16, #0x658
 bc8:	d61f0220 	br	x17
 bcc:	d503201f 	nop
 bd0:	d503201f 	nop
 bd4:	d503201f 	nop

0000000000000bd8 <waitpid@plt>:
 bd8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 bdc:	f9433211 	ldr	x17, [x16, #1632]
 be0:	91198210 	add	x16, x16, #0x660
 be4:	d61f0220 	br	x17

0000000000000be8 <printf@plt>:
 be8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 bec:	f9433611 	ldr	x17, [x16, #1640]
 bf0:	9119a210 	add	x16, x16, #0x668
 bf4:	d61f0220 	br	x17

0000000000000bf8 <pthread_create@plt>:
 bf8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 bfc:	f9433a11 	ldr	x17, [x16, #1648]
 c00:	9119c210 	add	x16, x16, #0x670
 c04:	d61f0220 	br	x17

0000000000000c08 <snprintf@plt>:
 c08:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c0c:	f9433e11 	ldr	x17, [x16, #1656]
 c10:	9119e210 	add	x16, x16, #0x678
 c14:	d61f0220 	br	x17

0000000000000c18 <gettid@plt>:
 c18:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c1c:	f9434211 	ldr	x17, [x16, #1664]
 c20:	911a0210 	add	x16, x16, #0x680
 c24:	d61f0220 	br	x17

0000000000000c28 <getpid@plt>:
 c28:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c2c:	f9434611 	ldr	x17, [x16, #1672]
 c30:	911a2210 	add	x16, x16, #0x688
 c34:	d61f0220 	br	x17

0000000000000c38 <dup2@plt>:
 c38:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c3c:	f9434a11 	ldr	x17, [x16, #1680]
 c40:	911a4210 	add	x16, x16, #0x690
 c44:	d61f0220 	br	x17

0000000000000c48 <sem_destroy@plt>:
 c48:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c4c:	f9434e11 	ldr	x17, [x16, #1688]
 c50:	911a6210 	add	x16, x16, #0x698
 c54:	d61f0220 	br	x17

0000000000000c58 <sem_wait@plt>:
 c58:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c5c:	f9435211 	ldr	x17, [x16, #1696]
 c60:	911a8210 	add	x16, x16, #0x6a0
 c64:	d61f0220 	br	x17

0000000000000c68 <sem_post@plt>:
 c68:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c6c:	f9435611 	ldr	x17, [x16, #1704]
 c70:	911aa210 	add	x16, x16, #0x6a8
 c74:	d61f0220 	br	x17

0000000000000c78 <socket@plt>:
 c78:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c7c:	f9435a11 	ldr	x17, [x16, #1712]
 c80:	911ac210 	add	x16, x16, #0x6b0
 c84:	d61f0220 	br	x17

0000000000000c88 <lseek@plt>:
 c88:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c8c:	f9435e11 	ldr	x17, [x16, #1720]
 c90:	911ae210 	add	x16, x16, #0x6b8
 c94:	d61f0220 	br	x17

0000000000000c98 <pipe@plt>:
 c98:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 c9c:	f9436211 	ldr	x17, [x16, #1728]
 ca0:	911b0210 	add	x16, x16, #0x6c0
 ca4:	d61f0220 	br	x17

0000000000000ca8 <strrchr@plt>:
 ca8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 cac:	f9436611 	ldr	x17, [x16, #1736]
 cb0:	911b2210 	add	x16, x16, #0x6c8
 cb4:	d61f0220 	br	x17

0000000000000cb8 <calloc@plt>:
 cb8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 cbc:	f9436a11 	ldr	x17, [x16, #1744]
 cc0:	911b4210 	add	x16, x16, #0x6d0
 cc4:	d61f0220 	br	x17

0000000000000cc8 <write@plt>:
 cc8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 ccc:	f9436e11 	ldr	x17, [x16, #1752]
 cd0:	911b6210 	add	x16, x16, #0x6d8
 cd4:	d61f0220 	br	x17

0000000000000cd8 <fstat@plt>:
 cd8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 cdc:	f9437211 	ldr	x17, [x16, #1760]
 ce0:	911b8210 	add	x16, x16, #0x6e0
 ce4:	d61f0220 	br	x17

0000000000000ce8 <bind@plt>:
 ce8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 cec:	f9437611 	ldr	x17, [x16, #1768]
 cf0:	911ba210 	add	x16, x16, #0x6e8
 cf4:	d61f0220 	br	x17

0000000000000cf8 <sem_init@plt>:
 cf8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 cfc:	f9437a11 	ldr	x17, [x16, #1776]
 d00:	911bc210 	add	x16, x16, #0x6f0
 d04:	d61f0220 	br	x17

0000000000000d08 <strstr@plt>:
 d08:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d0c:	f9437e11 	ldr	x17, [x16, #1784]
 d10:	911be210 	add	x16, x16, #0x6f8
 d14:	d61f0220 	br	x17

0000000000000d18 <read@plt>:
 d18:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d1c:	f9438211 	ldr	x17, [x16, #1792]
 d20:	911c0210 	add	x16, x16, #0x700
 d24:	d61f0220 	br	x17

0000000000000d28 <unlink@plt>:
 d28:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d2c:	f9438611 	ldr	x17, [x16, #1800]
 d30:	911c2210 	add	x16, x16, #0x708
 d34:	d61f0220 	br	x17

0000000000000d38 <realloc@plt>:
 d38:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d3c:	f9438a11 	ldr	x17, [x16, #1808]
 d40:	911c4210 	add	x16, x16, #0x710
 d44:	d61f0220 	br	x17

0000000000000d48 <listen@plt>:
 d48:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d4c:	f9438e11 	ldr	x17, [x16, #1816]
 d50:	911c6210 	add	x16, x16, #0x718
 d54:	d61f0220 	br	x17

0000000000000d58 <fork@plt>:
 d58:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d5c:	f9439211 	ldr	x17, [x16, #1824]
 d60:	911c8210 	add	x16, x16, #0x720
 d64:	d61f0220 	br	x17

0000000000000d68 <isalpha@plt>:
 d68:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d6c:	f9439611 	ldr	x17, [x16, #1832]
 d70:	911ca210 	add	x16, x16, #0x728
 d74:	d61f0220 	br	x17

0000000000000d78 <memset@plt>:
 d78:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d7c:	f9439a11 	ldr	x17, [x16, #1840]
 d80:	911cc210 	add	x16, x16, #0x730
 d84:	d61f0220 	br	x17

0000000000000d88 <getppid@plt>:
 d88:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d8c:	f9439e11 	ldr	x17, [x16, #1848]
 d90:	911ce210 	add	x16, x16, #0x738
 d94:	d61f0220 	br	x17

0000000000000d98 <strcmp@plt>:
 d98:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 d9c:	f943a211 	ldr	x17, [x16, #1856]
 da0:	911d0210 	add	x16, x16, #0x740
 da4:	d61f0220 	br	x17

0000000000000da8 <pthread_mutex_unlock@plt>:
 da8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 dac:	f943a611 	ldr	x17, [x16, #1864]
 db0:	911d2210 	add	x16, x16, #0x748
 db4:	d61f0220 	br	x17

0000000000000db8 <getcwd@plt>:
 db8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 dbc:	f943aa11 	ldr	x17, [x16, #1872]
 dc0:	911d4210 	add	x16, x16, #0x750
 dc4:	d61f0220 	br	x17

0000000000000dc8 <isdigit@plt>:
 dc8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 dcc:	f943ae11 	ldr	x17, [x16, #1880]
 dd0:	911d6210 	add	x16, x16, #0x758
 dd4:	d61f0220 	br	x17

0000000000000dd8 <htons@plt>:
 dd8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 ddc:	f943b211 	ldr	x17, [x16, #1888]
 de0:	911d8210 	add	x16, x16, #0x760
 de4:	d61f0220 	br	x17

0000000000000de8 <pthread_mutex_destroy@plt>:
 de8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 dec:	f943b611 	ldr	x17, [x16, #1896]
 df0:	911da210 	add	x16, x16, #0x768
 df4:	d61f0220 	br	x17

0000000000000df8 <pthread_mutex_lock@plt>:
 df8:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 dfc:	f943ba11 	ldr	x17, [x16, #1904]
 e00:	911dc210 	add	x16, x16, #0x770
 e04:	d61f0220 	br	x17

0000000000000e08 <exit@plt>:
 e08:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 e0c:	f943be11 	ldr	x17, [x16, #1912]
 e10:	911de210 	add	x16, x16, #0x778
 e14:	d61f0220 	br	x17

0000000000000e18 <open@plt>:
 e18:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 e1c:	f943c211 	ldr	x17, [x16, #1920]
 e20:	911e0210 	add	x16, x16, #0x780
 e24:	d61f0220 	br	x17

0000000000000e28 <pthread_join@plt>:
 e28:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 e2c:	f943c611 	ldr	x17, [x16, #1928]
 e30:	911e2210 	add	x16, x16, #0x788
 e34:	d61f0220 	br	x17

0000000000000e38 <close@plt>:
 e38:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 e3c:	f943ca11 	ldr	x17, [x16, #1936]
 e40:	911e4210 	add	x16, x16, #0x790
 e44:	d61f0220 	br	x17

0000000000000e48 <free@plt>:
 e48:	d0000010 	adrp	x16, 2000 <worker+0xcfc>
 e4c:	f943ce11 	ldr	x17, [x16, #1944]
 e50:	911e6210 	add	x16, x16, #0x798
 e54:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000e58 <main>:
  return (void *)42;
}

int
main(void)
{
     e58:	a9ad7bfd 	stp	x29, x30, [sp, #-304]!
  pthread_t first, second;
  void *result = 0;
  struct stat status;
  sem_t semaphore;
  char buffer[6] = {0};
  int loops = 500;
     e5c:	52803e80 	mov	w0, #0x1f4                 	// #500
  char cwd[128], pipe_byte = 0;
  char formatted[32];
  char *dynamic, *large;
  struct sockaddr_in address;

  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
     e60:	52803482 	mov	w2, #0x1a4                 	// #420
{
     e64:	910003fd 	mov	x29, sp
  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
     e68:	5280c041 	mov	w1, #0x602                 	// #1538
{
     e6c:	a90153f3 	stp	x19, x20, [sp, #16]
  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
     e70:	b0000014 	adrp	x20, 1000 <main+0x1a8>
{
     e74:	a9025bf5 	stp	x21, x22, [sp, #32]
  char cwd[128], pipe_byte = 0;
     e78:	3900efff 	strb	wzr, [sp, #59]
  int loops = 500;
     e7c:	b9004be0 	str	w0, [sp, #72]
  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
     e80:	910dc280 	add	x0, x20, #0x370
  char buffer[6] = {0};
     e84:	b90053ff 	str	wzr, [sp, #80]
     e88:	7900abff 	strh	wzr, [sp, #84]
  void *result = 0;
     e8c:	f9002fff 	str	xzr, [sp, #88]
  fd = open("posix.tmp", O_CREAT | O_TRUNC | O_RDWR, 0644);
     e90:	97ffffe2 	bl	e18 <open@plt>
  if(fd < 0 || write(fd, "POSIX", 5) != 5 ||
     e94:	37f80400 	tbnz	w0, #31, f14 <main+0xbc>
     e98:	2a0003f3 	mov	w19, w0
     e9c:	b0000015 	adrp	x21, 1000 <main+0x1a8>
     ea0:	d28000a2 	mov	x2, #0x5                   	// #5
     ea4:	910deaa1 	add	x1, x21, #0x37a
     ea8:	97ffff88 	bl	cc8 <write@plt>
     eac:	aa0003f6 	mov	x22, x0
     eb0:	f100141f 	cmp	x0, #0x5
     eb4:	54000301 	b.ne	f14 <main+0xbc>  // b.any
     lseek(fd, 0, SEEK_SET) != 0 || read(fd, buffer, 5) != 5 ||
     eb8:	2a1303e0 	mov	w0, w19
     ebc:	52800002 	mov	w2, #0x0                   	// #0
     ec0:	d2800001 	mov	x1, #0x0                   	// #0
     ec4:	97ffff71 	bl	c88 <lseek@plt>
  if(fd < 0 || write(fd, "POSIX", 5) != 5 ||
     ec8:	b5000260 	cbnz	x0, f14 <main+0xbc>
     lseek(fd, 0, SEEK_SET) != 0 || read(fd, buffer, 5) != 5 ||
     ecc:	aa1603e2 	mov	x2, x22
     ed0:	910143e1 	add	x1, sp, #0x50
     ed4:	2a1303e0 	mov	w0, w19
     ed8:	97ffff90 	bl	d18 <read@plt>
     edc:	f100141f 	cmp	x0, #0x5
     ee0:	540001a1 	b.ne	f14 <main+0xbc>  // b.any
     strcmp(buffer, "POSIX") != 0 || fstat(fd, &status) < 0 ||
     ee4:	910deaa1 	add	x1, x21, #0x37a
     ee8:	910143e0 	add	x0, sp, #0x50
     eec:	97ffffab 	bl	d98 <strcmp@plt>
     lseek(fd, 0, SEEK_SET) != 0 || read(fd, buffer, 5) != 5 ||
     ef0:	35000120 	cbnz	w0, f14 <main+0xbc>
     strcmp(buffer, "POSIX") != 0 || fstat(fd, &status) < 0 ||
     ef4:	9101e3e1 	add	x1, sp, #0x78
     ef8:	2a1303e0 	mov	w0, w19
     efc:	97ffff77 	bl	cd8 <fstat@plt>
     f00:	37f800a0 	tbnz	w0, #31, f14 <main+0xbc>
     f04:	794103e0 	ldrh	w0, [sp, #128]
     f08:	12000800 	and	w0, w0, #0x7
     f0c:	7100081f 	cmp	w0, #0x2
     f10:	540000c0 	b.eq	f28 <main+0xd0>  // b.none
     !S_ISREG(status.st_mode)){
    printf("posixtest: file API failed\n");
     f14:	b0000000 	adrp	x0, 1000 <main+0x1a8>
     f18:	910e0000 	add	x0, x0, #0x380
     strstr("xv6-libc", "libc") == 0 || strrchr("a/b", '/') == 0 ||
     !isdigit('7') || !isalpha('x') ||
     snprintf(formatted, sizeof(formatted), "%s-%d", "libc", 86) != 7 ||
     strcmp(formatted, "libc-86") != 0 ||
     getcwd(cwd, sizeof(cwd)) == 0 || cwd[0] != '/'){
    printf("posixtest: libc/string/getcwd API failed\n");
     f1c:	97ffff33 	bl	be8 <printf@plt>
    exit(1);
     f20:	52800020 	mov	w0, #0x1                   	// #1
     f24:	97ffffb9 	bl	e08 <exit@plt>
  close(fd);
     f28:	2a1303e0 	mov	w0, w19
     f2c:	97ffffc3 	bl	e38 <close@plt>
  unlink("posix.tmp");
     f30:	910dc280 	add	x0, x20, #0x370
     f34:	97ffff7d 	bl	d28 <unlink@plt>
  dynamic = calloc(4, 4);
     f38:	d2800081 	mov	x1, #0x4                   	// #4
     f3c:	aa0103e0 	mov	x0, x1
     f40:	97ffff5e 	bl	cb8 <calloc@plt>
  if(dynamic == 0 || dynamic[0] != 0 ||
     f44:	b40005c0 	cbz	x0, ffc <main+0x1a4>
     f48:	39400001 	ldrb	w1, [x0]
     f4c:	35000581 	cbnz	w1, ffc <main+0x1a4>
     (dynamic = realloc(dynamic, 64)) == 0 ||
     f50:	d2800801 	mov	x1, #0x40                  	// #64
     f54:	97ffff79 	bl	d38 <realloc@plt>
     f58:	aa0003f5 	mov	x21, x0
  if(dynamic == 0 || dynamic[0] != 0 ||
     f5c:	b4000500 	cbz	x0, ffc <main+0x1a4>
     strstr("xv6-libc", "libc") == 0 || strrchr("a/b", '/') == 0 ||
     f60:	b0000013 	adrp	x19, 1000 <main+0x1a8>
     f64:	b0000000 	adrp	x0, 1000 <main+0x1a8>
     f68:	910e7000 	add	x0, x0, #0x39c
     f6c:	910e8261 	add	x1, x19, #0x3a0
     f70:	97ffff66 	bl	d08 <strstr@plt>
     (dynamic = realloc(dynamic, 64)) == 0 ||
     f74:	b4000440 	cbz	x0, ffc <main+0x1a4>
     strstr("xv6-libc", "libc") == 0 || strrchr("a/b", '/') == 0 ||
     f78:	b0000000 	adrp	x0, 1000 <main+0x1a8>
     f7c:	910e9400 	add	x0, x0, #0x3a5
     f80:	528005e1 	mov	w1, #0x2f                  	// #47
     f84:	97ffff49 	bl	ca8 <strrchr@plt>
     f88:	b40003a0 	cbz	x0, ffc <main+0x1a4>
     !isdigit('7') || !isalpha('x') ||
     f8c:	528006e0 	mov	w0, #0x37                  	// #55
     f90:	97ffff8e 	bl	dc8 <isdigit@plt>
     strstr("xv6-libc", "libc") == 0 || strrchr("a/b", '/') == 0 ||
     f94:	34000340 	cbz	w0, ffc <main+0x1a4>
     !isdigit('7') || !isalpha('x') ||
     f98:	52800f00 	mov	w0, #0x78                  	// #120
     f9c:	97ffff73 	bl	d68 <isalpha@plt>
     fa0:	340002e0 	cbz	w0, ffc <main+0x1a4>
     snprintf(formatted, sizeof(formatted), "%s-%d", "libc", 86) != 7 ||
     fa4:	910e8263 	add	x3, x19, #0x3a0
     fa8:	910243e0 	add	x0, sp, #0x90
     fac:	b0000002 	adrp	x2, 1000 <main+0x1a8>
     fb0:	910ea442 	add	x2, x2, #0x3a9
     fb4:	52800ac4 	mov	w4, #0x56                  	// #86
     fb8:	d2800401 	mov	x1, #0x20                  	// #32
     fbc:	97ffff13 	bl	c08 <snprintf@plt>
     fc0:	2a0003f4 	mov	w20, w0
     !isdigit('7') || !isalpha('x') ||
     fc4:	71001c1f 	cmp	w0, #0x7
     fc8:	540001a1 	b.ne	ffc <main+0x1a4>  // b.any
     strcmp(formatted, "libc-86") != 0 ||
     fcc:	b0000001 	adrp	x1, 1000 <main+0x1a8>
     fd0:	910ebc21 	add	x1, x1, #0x3af
     fd4:	910243e0 	add	x0, sp, #0x90
     fd8:	97ffff70 	bl	d98 <strcmp@plt>
     snprintf(formatted, sizeof(formatted), "%s-%d", "libc", 86) != 7 ||
     fdc:	35000100 	cbnz	w0, ffc <main+0x1a4>
     getcwd(cwd, sizeof(cwd)) == 0 || cwd[0] != '/'){
     fe0:	9102c3e0 	add	x0, sp, #0xb0
     fe4:	d2801001 	mov	x1, #0x80                  	// #128
     fe8:	97ffff74 	bl	db8 <getcwd@plt>
     strcmp(formatted, "libc-86") != 0 ||
     fec:	b4000080 	cbz	x0, ffc <main+0x1a4>
     getcwd(cwd, sizeof(cwd)) == 0 || cwd[0] != '/'){
     ff0:	3942c3e0 	ldrb	w0, [sp, #176]
     ff4:	7100bc1f 	cmp	w0, #0x2f
     ff8:	54000080 	b.eq	1008 <main+0x1b0>  // b.none
    printf("posixtest: libc/string/getcwd API failed\n");
     ffc:	b0000000 	adrp	x0, 1000 <main+0x1a8>
    1000:	910edc00 	add	x0, x0, #0x3b7
    1004:	17ffffc6 	b	f1c <main+0xc4>
  }
  free(dynamic);
    1008:	aa1503e0 	mov	x0, x21
    100c:	97ffff8f 	bl	e48 <free@plt>

  // The libc allocator keeps small objects in its reusable brk arena, but a
  // large miss follows ptmalloc's policy and gets an anonymous mmap VMA.
  // mmap() allocations live in the high user window on this port.
  large = calloc(1, 256 * 1024);
    1010:	d2a00081 	mov	x1, #0x40000               	// #262144
    1014:	d2800020 	mov	x0, #0x1                   	// #1
    1018:	97ffff28 	bl	cb8 <calloc@plt>
  if(large == 0 || (unsigned long)large < 0x0000001000000000UL ||
    101c:	b2408fe1 	mov	x1, #0xfffffffff           	// #68719476735
    1020:	eb01001f 	cmp	x0, x1
    1024:	540000c9 	b.ls	103c <main+0x1e4>  // b.plast
    1028:	39400001 	ldrb	w1, [x0]
    102c:	35000081 	cbnz	w1, 103c <main+0x1e4>
     large[0] != 0 || large[256 * 1024 - 1] != 0){
    1030:	9140fc01 	add	x1, x0, #0x3f, lsl #12
    1034:	397ffc22 	ldrb	w2, [x1, #4095]
    1038:	34000082 	cbz	w2, 1048 <main+0x1f0>
    printf("posixtest: large calloc mmap policy failed\n");
    103c:	90000000 	adrp	x0, 1000 <main+0x1a8>
    1040:	910f8400 	add	x0, x0, #0x3e1
    1044:	17ffffb6 	b	f1c <main+0xc4>
    exit(1);
  }
  large[0] = 'L';
    1048:	52800982 	mov	w2, #0x4c                  	// #76
    104c:	39000002 	strb	w2, [x0]
  large[256 * 1024 - 1] = 'R';
    1050:	52800a42 	mov	w2, #0x52                  	// #82
    1054:	393ffc22 	strb	w2, [x1, #4095]
  large = realloc(large, 512 * 1024);
    1058:	d2a00101 	mov	x1, #0x80000               	// #524288
    105c:	97ffff37 	bl	d38 <realloc@plt>
  if(large == 0 || large[0] != 'L' || large[256 * 1024 - 1] != 'R'){
    1060:	b4000100 	cbz	x0, 1080 <main+0x228>
    1064:	39400002 	ldrb	w2, [x0]
    1068:	7101305f 	cmp	w2, #0x4c
    106c:	540000a1 	b.ne	1080 <main+0x228>  // b.any
    1070:	9140fc01 	add	x1, x0, #0x3f, lsl #12
    1074:	397ffc21 	ldrb	w1, [x1, #4095]
    1078:	7101483f 	cmp	w1, #0x52
    107c:	54000080 	b.eq	108c <main+0x234>  // b.none
    printf("posixtest: large realloc failed\n");
    1080:	90000000 	adrp	x0, 1000 <main+0x1a8>
    1084:	91103400 	add	x0, x0, #0x40d
    1088:	17ffffa5 	b	f1c <main+0xc4>
    exit(1);
  }
  free(large);
    108c:	97ffff6f 	bl	e48 <free@plt>

  if(pipe(pipes) < 0 || dup2(pipes[1], 10) != 10 || close(pipes[1]) < 0 ||
    1090:	910183e0 	add	x0, sp, #0x60
    1094:	97ffff01 	bl	c98 <pipe@plt>
    1098:	37f80420 	tbnz	w0, #31, 111c <main+0x2c4>
    109c:	b94067e0 	ldr	w0, [sp, #100]
    10a0:	52800141 	mov	w1, #0xa                   	// #10
    10a4:	97fffee5 	bl	c38 <dup2@plt>
    10a8:	2a0003f3 	mov	w19, w0
    10ac:	7100281f 	cmp	w0, #0xa
    10b0:	54000361 	b.ne	111c <main+0x2c4>  // b.any
    10b4:	b94067e0 	ldr	w0, [sp, #100]
    10b8:	97ffff60 	bl	e38 <close@plt>
    10bc:	37f80300 	tbnz	w0, #31, 111c <main+0x2c4>
     write(10, "D", 1) != 1 || close(10) < 0 ||
    10c0:	2a1303e0 	mov	w0, w19
    10c4:	90000001 	adrp	x1, 1000 <main+0x1a8>
    10c8:	9110b821 	add	x1, x1, #0x42e
    10cc:	d2800022 	mov	x2, #0x1                   	// #1
    10d0:	97fffefe 	bl	cc8 <write@plt>
    10d4:	aa0003f5 	mov	x21, x0
  if(pipe(pipes) < 0 || dup2(pipes[1], 10) != 10 || close(pipes[1]) < 0 ||
    10d8:	f100041f 	cmp	x0, #0x1
    10dc:	54000201 	b.ne	111c <main+0x2c4>  // b.any
     write(10, "D", 1) != 1 || close(10) < 0 ||
    10e0:	2a1303e0 	mov	w0, w19
    10e4:	97ffff55 	bl	e38 <close@plt>
    10e8:	37f801a0 	tbnz	w0, #31, 111c <main+0x2c4>
     read(pipes[0], &pipe_byte, 1) != 1 || pipe_byte != 'D' ||
    10ec:	b94063e0 	ldr	w0, [sp, #96]
    10f0:	aa1503e2 	mov	x2, x21
    10f4:	9100efe1 	add	x1, sp, #0x3b
    10f8:	97ffff08 	bl	d18 <read@plt>
     write(10, "D", 1) != 1 || close(10) < 0 ||
    10fc:	f100041f 	cmp	x0, #0x1
    1100:	540000e1 	b.ne	111c <main+0x2c4>  // b.any
     read(pipes[0], &pipe_byte, 1) != 1 || pipe_byte != 'D' ||
    1104:	3940efe0 	ldrb	w0, [sp, #59]
    1108:	7101101f 	cmp	w0, #0x44
    110c:	54000081 	b.ne	111c <main+0x2c4>  // b.any
     close(pipes[0]) < 0){
    1110:	b94063e0 	ldr	w0, [sp, #96]
    1114:	97ffff49 	bl	e38 <close@plt>
     read(pipes[0], &pipe_byte, 1) != 1 || pipe_byte != 'D' ||
    1118:	36f80080 	tbz	w0, #31, 1128 <main+0x2d0>
    printf("posixtest: dup2 API failed\n");
    111c:	90000000 	adrp	x0, 1000 <main+0x1a8>
    1120:	9110c000 	add	x0, x0, #0x430
    1124:	17ffff7e 	b	f1c <main+0xc4>
    exit(1);
  }

  child = fork();
    1128:	97ffff0c 	bl	d58 <fork@plt>
    112c:	2a0003f3 	mov	w19, w0
  if(child == 0)
    1130:	35000100 	cbnz	w0, 1150 <main+0x2f8>
    exit(getppid() == getpid() ? 99 : 7);
    1134:	97ffff15 	bl	d88 <getppid@plt>
    1138:	2a0003f3 	mov	w19, w0
    113c:	97fffebb 	bl	c28 <getpid@plt>
    1140:	6b00027f 	cmp	w19, w0
    1144:	52800c60 	mov	w0, #0x63                  	// #99
    1148:	1a801280 	csel	w0, w20, w0, ne	// ne = any
    114c:	17ffff76 	b	f24 <main+0xcc>
  if(child < 0 || waitpid(child, &child_status, 0) != child ||
    1150:	37f80120 	tbnz	w0, #31, 1174 <main+0x31c>
    1154:	910133e1 	add	x1, sp, #0x4c
    1158:	52800002 	mov	w2, #0x0                   	// #0
    115c:	97fffe9f 	bl	bd8 <waitpid@plt>
    1160:	6b13001f 	cmp	w0, w19
    1164:	54000081 	b.ne	1174 <main+0x31c>  // b.any
     !WIFEXITED(child_status) || WEXITSTATUS(child_status) != 7){
    1168:	b9404fe0 	ldr	w0, [sp, #76]
    116c:	71001c1f 	cmp	w0, #0x7
    1170:	540000c0 	b.eq	1188 <main+0x330>  // b.none
    printf("posixtest: waitpid/getppid API failed status=%d\n", child_status);
    1174:	b9404fe1 	ldr	w1, [sp, #76]
    1178:	90000000 	adrp	x0, 1000 <main+0x1a8>
    117c:	91113000 	add	x0, x0, #0x44c
  if(pthread_create(&first, 0, worker, &loops) != 0 ||
     pthread_create(&second, 0, worker, &loops) != 0 ||
     pthread_join(first, &result) != 0 || result != (void *)42 ||
     pthread_join(second, &result) != 0 || result != (void *)42 ||
     counter != 1000){
    printf("posixtest: pthread API failed counter=%d\n", counter);
    1180:	97fffe9a 	bl	be8 <printf@plt>
    exit(1);
    1184:	17ffff67 	b	f20 <main+0xc8>
  if(sem_init(&semaphore, 0, 0) < 0 || sem_post(&semaphore) < 0 ||
    1188:	910113e0 	add	x0, sp, #0x44
    118c:	52800002 	mov	w2, #0x0                   	// #0
    1190:	52800001 	mov	w1, #0x0                   	// #0
    1194:	97fffed9 	bl	cf8 <sem_init@plt>
    1198:	37f80140 	tbnz	w0, #31, 11c0 <main+0x368>
    119c:	910113e0 	add	x0, sp, #0x44
    11a0:	97fffeb2 	bl	c68 <sem_post@plt>
    11a4:	37f800e0 	tbnz	w0, #31, 11c0 <main+0x368>
     sem_wait(&semaphore) < 0 || sem_destroy(&semaphore) < 0){
    11a8:	910113e0 	add	x0, sp, #0x44
    11ac:	97fffeab 	bl	c58 <sem_wait@plt>
  if(sem_init(&semaphore, 0, 0) < 0 || sem_post(&semaphore) < 0 ||
    11b0:	37f80080 	tbnz	w0, #31, 11c0 <main+0x368>
     sem_wait(&semaphore) < 0 || sem_destroy(&semaphore) < 0){
    11b4:	910113e0 	add	x0, sp, #0x44
    11b8:	97fffea4 	bl	c48 <sem_destroy@plt>
    11bc:	36f80080 	tbz	w0, #31, 11cc <main+0x374>
    printf("posixtest: semaphore API failed\n");
    11c0:	90000000 	adrp	x0, 1000 <main+0x1a8>
    11c4:	9111f400 	add	x0, x0, #0x47d
    11c8:	17ffff55 	b	f1c <main+0xc4>
  if(pthread_create(&first, 0, worker, &loops) != 0 ||
    11cc:	910123e3 	add	x3, sp, #0x48
    11d0:	9100f3e0 	add	x0, sp, #0x3c
    11d4:	90000014 	adrp	x20, 1000 <main+0x1a8>
    11d8:	d2800001 	mov	x1, #0x0                   	// #0
    11dc:	910c1282 	add	x2, x20, #0x304
    11e0:	b0000013 	adrp	x19, 2000 <worker+0xcfc>
    11e4:	911e8273 	add	x19, x19, #0x7a0
    11e8:	97fffe84 	bl	bf8 <pthread_create@plt>
    11ec:	35000300 	cbnz	w0, 124c <main+0x3f4>
     pthread_create(&second, 0, worker, &loops) != 0 ||
    11f0:	910123e3 	add	x3, sp, #0x48
    11f4:	910c1282 	add	x2, x20, #0x304
    11f8:	910103e0 	add	x0, sp, #0x40
    11fc:	d2800001 	mov	x1, #0x0                   	// #0
    1200:	97fffe7e 	bl	bf8 <pthread_create@plt>
  if(pthread_create(&first, 0, worker, &loops) != 0 ||
    1204:	35000240 	cbnz	w0, 124c <main+0x3f4>
     pthread_join(first, &result) != 0 || result != (void *)42 ||
    1208:	b9403fe0 	ldr	w0, [sp, #60]
    120c:	910163e1 	add	x1, sp, #0x58
    1210:	97ffff06 	bl	e28 <pthread_join@plt>
     pthread_create(&second, 0, worker, &loops) != 0 ||
    1214:	350001c0 	cbnz	w0, 124c <main+0x3f4>
     pthread_join(first, &result) != 0 || result != (void *)42 ||
    1218:	f9402fe0 	ldr	x0, [sp, #88]
    121c:	f100a81f 	cmp	x0, #0x2a
    1220:	54000161 	b.ne	124c <main+0x3f4>  // b.any
     pthread_join(second, &result) != 0 || result != (void *)42 ||
    1224:	b94043e0 	ldr	w0, [sp, #64]
    1228:	910163e1 	add	x1, sp, #0x58
    122c:	97fffeff 	bl	e28 <pthread_join@plt>
     pthread_join(first, &result) != 0 || result != (void *)42 ||
    1230:	350000e0 	cbnz	w0, 124c <main+0x3f4>
     pthread_join(second, &result) != 0 || result != (void *)42 ||
    1234:	f9402fe0 	ldr	x0, [sp, #88]
    1238:	f100a81f 	cmp	x0, #0x2a
    123c:	54000081 	b.ne	124c <main+0x3f4>  // b.any
    1240:	b9400660 	ldr	w0, [x19, #4]
    1244:	710fa01f 	cmp	w0, #0x3e8
    1248:	540000a0 	b.eq	125c <main+0x404>  // b.none
    printf("posixtest: pthread API failed counter=%d\n", counter);
    124c:	90000000 	adrp	x0, 1000 <main+0x1a8>
    1250:	91127800 	add	x0, x0, #0x49e
    1254:	b9400661 	ldr	w1, [x19, #4]
    1258:	17ffffca 	b	1180 <main+0x328>
  }
  pthread_mutex_destroy(&lock);
    125c:	aa1303e0 	mov	x0, x19
    1260:	97fffee2 	bl	de8 <pthread_mutex_destroy@plt>

  memset(&address, 0, sizeof(address));
    1264:	d2800202 	mov	x2, #0x10                  	// #16
    1268:	52800001 	mov	w1, #0x0                   	// #0
    126c:	9101a3e0 	add	x0, sp, #0x68
    1270:	97fffec2 	bl	d78 <memset@plt>
  address.sin_family = AF_INET;
    1274:	52800040 	mov	w0, #0x2                   	// #2
    1278:	7900d3e0 	strh	w0, [sp, #104]
  address.sin_port = htons(18080);
    127c:	5288d400 	mov	w0, #0x46a0                	// #18080
    1280:	97fffed6 	bl	dd8 <htons@plt>
  address.sin_addr.s_addr = INADDR_ANY;
  server = socket(AF_INET, SOCK_STREAM, 0);
    1284:	52800002 	mov	w2, #0x0                   	// #0
    1288:	52800021 	mov	w1, #0x1                   	// #1
  address.sin_port = htons(18080);
    128c:	7900d7e0 	strh	w0, [sp, #106]
  server = socket(AF_INET, SOCK_STREAM, 0);
    1290:	52800040 	mov	w0, #0x2                   	// #2
  address.sin_addr.s_addr = INADDR_ANY;
    1294:	b9006fff 	str	wzr, [sp, #108]
  server = socket(AF_INET, SOCK_STREAM, 0);
    1298:	97fffe78 	bl	c78 <socket@plt>
    129c:	2a0003f4 	mov	w20, w0
  if(server < 0 || bind(server, (struct sockaddr *)&address,
    12a0:	37f80120 	tbnz	w0, #31, 12c4 <main+0x46c>
    12a4:	9101a3e1 	add	x1, sp, #0x68
    12a8:	52800202 	mov	w2, #0x10                  	// #16
    12ac:	97fffe8f 	bl	ce8 <bind@plt>
    12b0:	37f800a0 	tbnz	w0, #31, 12c4 <main+0x46c>
                        sizeof(address)) < 0 || listen(server, 4) < 0){
    12b4:	2a1403e0 	mov	w0, w20
    12b8:	52800081 	mov	w1, #0x4                   	// #4
    12bc:	97fffea3 	bl	d48 <listen@plt>
    12c0:	36f80080 	tbz	w0, #31, 12d0 <main+0x478>
    printf("posixtest: socket/bind/listen API failed\n");
    12c4:	90000000 	adrp	x0, 1000 <main+0x1a8>
    12c8:	91132000 	add	x0, x0, #0x4c8
    12cc:	17ffff14 	b	f1c <main+0xc4>
    exit(1);
  }
  close(server);
    12d0:	2a1403e0 	mov	w0, w20
    12d4:	97fffed9 	bl	e38 <close@plt>
  printf("posixtest: PASS pid=%d tid=%d counter=%d\n",
    12d8:	97fffe54 	bl	c28 <getpid@plt>
    12dc:	2a0003f4 	mov	w20, w0
    12e0:	97fffe4e 	bl	c18 <gettid@plt>
    12e4:	2a0003e2 	mov	w2, w0
    12e8:	b9400663 	ldr	w3, [x19, #4]
    12ec:	2a1403e1 	mov	w1, w20
    12f0:	90000000 	adrp	x0, 1000 <main+0x1a8>
    12f4:	9113c800 	add	x0, x0, #0x4f2
    12f8:	97fffe3c 	bl	be8 <printf@plt>
         getpid(), gettid(), counter);
  exit(0);
    12fc:	52800000 	mov	w0, #0x0                   	// #0
    1300:	17ffff09 	b	f24 <main+0xcc>

0000000000001304 <worker>:
{
    1304:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1308:	910003fd 	mov	x29, sp
    130c:	a90153f3 	stp	x19, x20, [sp, #16]
    if(pthread_mutex_lock(&lock) != 0)
    1310:	b0000013 	adrp	x19, 2000 <worker+0xcfc>
    1314:	911e8273 	add	x19, x19, #0x7a0
{
    1318:	f90013f5 	str	x21, [sp, #32]
  for(int i = 0; i < loops; i++){
    131c:	52800014 	mov	w20, #0x0                   	// #0
  int loops = *(int *)argument;
    1320:	b9400015 	ldr	w21, [x0]
  for(int i = 0; i < loops; i++){
    1324:	6b15029f 	cmp	w20, w21
    1328:	540000cb 	b.lt	1340 <worker+0x3c>  // b.tstop
  return (void *)42;
    132c:	d2800540 	mov	x0, #0x2a                  	// #42
}
    1330:	f94013f5 	ldr	x21, [sp, #32]
    1334:	a94153f3 	ldp	x19, x20, [sp, #16]
    1338:	a8c37bfd 	ldp	x29, x30, [sp], #48
    133c:	d65f03c0 	ret
    if(pthread_mutex_lock(&lock) != 0)
    1340:	aa1303e0 	mov	x0, x19
    1344:	97fffead 	bl	df8 <pthread_mutex_lock@plt>
    1348:	35000100 	cbnz	w0, 1368 <worker+0x64>
    counter++;
    134c:	b9400660 	ldr	w0, [x19, #4]
  for(int i = 0; i < loops; i++){
    1350:	11000694 	add	w20, w20, #0x1
    counter++;
    1354:	11000400 	add	w0, w0, #0x1
    1358:	b9000660 	str	w0, [x19, #4]
    pthread_mutex_unlock(&lock);
    135c:	aa1303e0 	mov	x0, x19
    1360:	97fffe92 	bl	da8 <pthread_mutex_unlock@plt>
  for(int i = 0; i < loops; i++){
    1364:	17fffff0 	b	1324 <worker+0x20>
      return (void *)1;
    1368:	d2800020 	mov	x0, #0x1                   	// #1
    136c:	17fffff1 	b	1330 <worker+0x2c>
