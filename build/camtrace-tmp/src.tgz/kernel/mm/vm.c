#include <kernel/param.h>
#include <kernel/types.h>
#include "memlayout.h"
#include <kernel/elf.h>
#include "aarch64.h"
#include <kernel/defs.h>
#include <kernel/fs.h>
#include <kernel/spinlock.h>
#include <kernel/proc.h>
#include <kernel/mm.h>
#include <kernel/page.h>
#include <kernel/memblock.h>
#include <kernel/mm_trace.h>
#include <kernel/mmu_trace.h>

/*
 * the kernel's page table.
 */
pagetable_t kernel_pagetable;
struct cow_stat cow_stat;
static struct spinlock vm_dump_lock;
static int kernel_dumped;

extern char etext[];  // kernel.ld sets this to end of kernel code.

#define L2BLOCK (1UL << PXSHIFT(2))   // 2 MiB: one level-2 block descriptor

// Map one 2 MiB block at level 2 of the kernel page table.
static void
kvmmap_block(pagetable_t kpgtbl, uint64 va, uint64 pa, uint64 perm)
{
  pte_t *l1e = &kpgtbl[PX(1, va)];
  pagetable_t l2;
  pte_t *pte;

  if((*l1e & PTE_VALID) == 0){
    if((l2 = (pagetable_t)kalloc()) == 0)
      panic("kvmmap_block");
    memset(l2, 0, PGSIZE);
    *l1e = PA2PTE(V2P(l2)) | PTE_TABLE | PTE_VALID;
    if(MMUTRACE(1))
      mmu_trace_newtable(kpgtbl, va, 2, PX(1, va), V2P(l2));
  }
  l2 = (pagetable_t)P2V(PTE2PA(*l1e));
  pte = &l2[PX(2, va)];
  if(*pte & PTE_VALID)
    panic("kvmmap_block: remap");
  *pte = PA2PTE(pa) | perm | PTE_AF | PTE_VALID;   // bits[1:0] = 01: block
}

// Linear-map physical [start, end): 2 MiB blocks where aligned, 4 KiB pages
// at unaligned edges.
static void
kvmmap_linear(pagetable_t kpgtbl, uint64 start, uint64 end, uint64 perm)
{
  uint64 pa = start;

  while(pa < end){
    if((pa & (L2BLOCK - 1)) == 0 && pa + L2BLOCK <= end){
      kvmmap_block(kpgtbl, KERNBASE + pa, pa, perm);
      pa += L2BLOCK;
    } else {
      kvmmap(kpgtbl, KERNBASE + pa, pa, PGSIZE, perm);
      pa += PGSIZE;
    }
  }
}

// Make a direct-map page table for the kernel.
pagetable_t
kvmmake(void)
{
  pagetable_t kpgtbl;

  if(MMUTRACE(1))
    mmu_trace_kregion("BCM2837 peripherals", PERIPHERAL_BASE, PERIPHERAL_BASE_PA,
                      0x01000000, PTE_DEVICE | PTE_XN);
  kpgtbl = (pagetable_t) kalloc();
  memset(kpgtbl, 0, PGSIZE);
  if(MMUTRACE(1))
    mmu_trace_newtable(kpgtbl, 0, 1, -1, V2P(kpgtbl));

  // BCM2837 peripheral and ARM-local MMIO windows.
  kvmmap(kpgtbl, PERIPHERAL_BASE, PERIPHERAL_BASE_PA,
         0x01000000, PTE_DEVICE | PTE_XN);
  if(MMUTRACE(1))
    mmu_trace_kregion("ARM local (mailbox, timer)", LOCAL_BASE, LOCAL_BASE_PA, PGSIZE,
                      PTE_DEVICE | PTE_XN);
  kvmmap(kpgtbl, LOCAL_BASE, LOCAL_BASE_PA, PGSIZE,
         PTE_DEVICE | PTE_XN);

  // QEMU loads fs.img here; it is outside the allocator's RAM range.
  if(MMUTRACE(1))
    mmu_trace_kregion("ramdisk", RAMDISK, RAMDISK_PA, RAMDISK_SIZE, PTE_NORMAL | PTE_XN);
  kvmmap(kpgtbl, RAMDISK, RAMDISK_PA, RAMDISK_SIZE,
         PTE_NORMAL | PTE_XN);

  // Camera DMA buffer: non-cacheable normal memory (see memlayout.h).
  if(MMUTRACE(1))
    mmu_trace_kregion("camera DMA", CAMDMA, CAMDMA_PA, CAMDMA_SIZE, PTE_NORMAL_NC | PTE_XN);
  kvmmap(kpgtbl, CAMDMA, CAMDMA_PA, CAMDMA_SIZE, PTE_NORMAL_NC | PTE_XN);

  // Loadable-module arena: read/write/execute normal memory.  The loader
  // copies a .ko's text in and then the kernel runs it, so unlike every other
  // region above etext this one is left executable (no PTE_XN, no PTE_RO).
  if(MMUTRACE(1))
    mmu_trace_kregion("module arena", MODAREA, MODAREA_PA, MODAREA_SIZE, PTE_NORMAL);
  kvmmap(kpgtbl, MODAREA, MODAREA_PA, MODAREA_SIZE, PTE_NORMAL);

  // Raspberry Pi AArch64 secondary-core spin-table slots live at physical
  // 0xe0..0xf0.  Keep only page zero in the high direct map so CPU0 can
  // publish _entry after switching away from the bootstrap page table.
  if(MMUTRACE(1))
    mmu_trace_kregion("page 0 (spin table)", KERNBASE, 0, PGSIZE, PTE_NORMAL | PTE_XN);
  kvmmap(kpgtbl, KERNBASE, 0, PGSIZE, PTE_NORMAL | PTE_XN);

  // map kernel text executable and read-only.
  if(MMUTRACE(1))
    mmu_trace_kregion("kernel text", KERNLINK, V2P(KERNLINK), (uint64)etext-KERNLINK,
                      PTE_NORMAL | PTE_RO);
  kvmmap(kpgtbl, KERNLINK, V2P(KERNLINK), (uint64)etext-KERNLINK, PTE_NORMAL | PTE_RO);

  // map kernel data and the rest of the bootstrap window with 4 KiB pages.
  if(MMUTRACE(1))
    mmu_trace_kregion("kernel data+bss+early RAM", (uint64)etext, V2P(etext),
                      (uint64)P2V(EARLYTOP)-(uint64)etext, PTE_NORMAL | PTE_XN);
  kvmmap(kpgtbl, (uint64)etext, V2P(etext), (uint64)P2V(EARLYTOP)-(uint64)etext, PTE_NORMAL | PTE_XN);

  // Map every other byte of RAM memblock knows about (Linux map_mem()),
  // mostly with 2 MiB blocks: 1 GiB costs one L2 table instead of 512 L3
  // tables.  The carve-out window keeps the attributes mapped above.
  for(int i = 0; i < memblock.memory.cnt; i++){
    uint64 start = memblock.memory.regions[i].base;
    uint64 stop = start + memblock.memory.regions[i].size;
    if(start < EARLYTOP)
      start = EARLYTOP;
    if(start >= stop)
      continue;
    if(MMUTRACE(1))
      mmu_trace_kregion("linear map of RAM", KERNBASE + start, start, stop - start,
                        PTE_NORMAL | PTE_XN);
    if(start < CARVEOUT_END && stop > CARVEOUT_START){
      if(start < CARVEOUT_START)
        kvmmap_linear(kpgtbl, start, CARVEOUT_START, PTE_NORMAL | PTE_XN);
      if(stop > CARVEOUT_END)
        kvmmap_linear(kpgtbl, CARVEOUT_END, stop, PTE_NORMAL | PTE_XN);
    } else
      kvmmap_linear(kpgtbl, start, stop, PTE_NORMAL | PTE_XN);
  }

  return kpgtbl;
}

// Count how the linear map covers RAM (DirectMap4k / DirectMap2M in
// /proc/meminfo): walk the kernel page table over every memblock region.
void
kvm_directmap(uint64 *n4k, uint64 *n2m)
{
  *n4k = *n2m = 0;
  for(int i = 0; i < memblock.memory.cnt; i++){
    uint64 pa = memblock.memory.regions[i].base;
    uint64 stop = pa + memblock.memory.regions[i].size;
    while(pa < stop){
      uint64 va = KERNBASE + pa;
      pte_t l1e = kernel_pagetable[PX(1, va)], l2e, l3e;
      if((l1e & PTE_VALID) == 0 || (l1e & PTE_TABLE) == 0){
        pa = (pa + (1UL << 30)) & ~((1UL << 30) - 1);
        continue;
      }
      l2e = ((pagetable_t)P2V(PTE2PA(l1e)))[PX(2, va)];
      if((l2e & PTE_VALID) && (l2e & PTE_TABLE) == 0){
        (*n2m)++;
        pa = (pa + L2BLOCK) & ~(L2BLOCK - 1);
        continue;
      }
      if(l2e & PTE_VALID){
        l3e = ((pagetable_t)P2V(PTE2PA(l2e)))[PX(3, va)];
        if(l3e & PTE_VALID)
          (*n4k)++;
      }
      pa += PGSIZE;
    }
  }
}

// MM_TRACE: print the descriptors a translation of va goes through.
void
mm_trace_walk(pagetable_t pagetable, uint64 va)
{
  pte_t e1, e2 = 0, e3 = 0;

  if(!MM_TRACE || va >= MAXVA)
    return;
  e1 = pagetable[PX(1, va)];
  if((e1 & PTE_VALID) && (e1 & PTE_TABLE)){
    e2 = ((pagetable_t)P2V(PTE2PA(e1)))[PX(2, va)];
    if((e2 & PTE_VALID) && (e2 & PTE_TABLE))
      e3 = ((pagetable_t)P2V(PTE2PA(e2)))[PX(3, va)];
  }
  MMTRACE("walk: va %p  L1[%d]=%p L2[%d]=%p L3[%d]=%p -> pa %p\n", va,
          (int)PX(1, va), e1, (int)PX(2, va), e2, (int)PX(3, va), e3,
          (e3 & PTE_VALID) ? PTE2PA(e3) | (va & (PGSIZE - 1)) : 0);
}

// Initialize the one kernel_pagetable
void
kvminit(void)
{
  initlock(&vm_dump_lock, "vmdump");
  mmu_kvm_building = 1;
  kernel_pagetable = kvmmake();
  mmu_kvm_building = 0;
}

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
  w_ttbr1_el1(V2P(kernel_pagetable));
  w_ttbr0_el1(0);
  flush_tlb();
}

// Print the final kernel page table before the scheduler starts.  With a
// 39-bit VA, translation starts at architectural level 1 (there is no level
// 0 table).  Kernel RAM is direct-mapped a page at a time, including free
// allocator pages, so printing every L3 descriptor produces tens of thousands
// of misleading lines.  Coalesce adjacent leaves with equal attributes while
// retaining their L1/L2 ancestry.
void
kvmdump(void)
{
  // TTBR1 is shared by all CPUs.  A process VM dump may call kvmdump() again,
  // but the complete kernel L3 walk is intentionally emitted only once.
  acquire(&vm_dump_lock);
  if(kernel_dumped){
    release(&vm_dump_lock);
    return;
  }
  kernel_dumped = 1;
  release(&vm_dump_lock);

  printf("\n=== kernel page table ===\n");
  printf("L0: omitted (T1SZ=25 gives a 39-bit VA; walk starts at L1)\n");
  printf("TTBR1_EL1 -> L1 root: kva=%p pa=%p\n",
         (uint64)kernel_pagetable, V2P(kernel_pagetable));

  for(int i = 0; i < 512; i++){
    pte_t l1e = kernel_pagetable[i];
    if((l1e & PTE_VALID) == 0)
      continue;

    uint64 l1va = KERNBASE + ((uint64)i << PXSHIFT(1));
    if((l1e & PTE_TABLE) == 0){
      printf(" L1[%d] va=%p: unexpected block pte=%p\n",
             i, l1va, l1e);
      continue;
    }

    pagetable_t l2 = (pagetable_t)P2V(PTE2PA(l1e));
    printf(" L1[%d] va=%p pte=%p -> L2 kva=%p pa=%p\n",
           i, l1va, l1e, (uint64)l2, PTE2PA(l1e));

    for(int j = 0; j < 512; j++){
      pte_t l2e = l2[j];
      if((l2e & PTE_VALID) == 0)
        continue;

      uint64 va = l1va + ((uint64)j << PXSHIFT(2));
      if((l2e & PTE_TABLE) == 0){
        printf("  L2[%d] va=%p pte=%p BLOCK pa=%p flags=%p\n",
               j, va, l2e, PTE2PA(l2e), PTE_FLAGS(l2e));
        continue;
      }

      pagetable_t l3 = (pagetable_t)P2V(PTE2PA(l2e));
      int leaves = 0;
      for(int k = 0; k < 512; k++)
        if((l3[k] & (PTE_V | PTE_AF)) == (PTE_V | PTE_AF))
          leaves++;
      if(leaves == 0)
        continue;
      printf("  L2[%d] va=%p pte=%p -> L3 kva=%p pa=%p leaves=%d\n",
             j, va, l2e, (uint64)l3, PTE2PA(l2e), leaves);

      for(int k = 0; k < 512; ){
        pte_t l3e = l3[k];
        if((l3e & (PTE_V | PTE_AF)) != (PTE_V | PTE_AF)){
          k++;
          continue;
        }
        int first = k;
        int last = k;
        uint64 firstpa = PTE2PA(l3e);
        uint64 flags = PTE_FLAGS(l3e);
        while(last + 1 < 512){
          pte_t next = l3[last + 1];
          if((next & (PTE_V | PTE_AF)) != (PTE_V | PTE_AF) ||
             PTE_FLAGS(next) != flags ||
             PTE2PA(next) != firstpa + (uint64)(last + 1 - first) * PGSIZE)
            break;
          last++;
        }
        uint64 firstva = va + ((uint64)first << PXSHIFT(3));
        uint64 lastva = va + ((uint64)last << PXSHIFT(3));
        if(first == last)
          printf("   L3[%d] va=%p -> pa=%p flags=%p\n",
                 first, firstva, firstpa, flags);
        else
          printf("   L3[%d..%d] va=%p..%p -> pa=%p..%p pages=%d flags=%p\n",
                 first, last, firstva, lastva + PGSIZE - 1,
                 firstpa, firstpa + (uint64)(last - first + 1) * PGSIZE - 1,
                 last - first + 1, flags);
        k = last + 1;
      }
    }
  }
  printf("=== end kernel page table ===\n\n");
}

// Print a user page table when fork copies it or exec installs a new image.
// User address translation uses TTBR0 and the same 39-bit, three-level walk.
// Only accessible user leaves are data/code/heap/stack mappings.  Print those
// leaves and only the L2/L1 ancestors that lead to at least one such leaf.
static int
user_l3_leaves(pagetable_t l3)
{
  int n = 0;
  for(int k = 0; k < 512; k++){
    pte_t pte = l3[k];
    if((pte & (PTE_V | PTE_AF | PTE_U)) == (PTE_V | PTE_AF | PTE_U))
      n++;
  }
  return n;
}

static int
user_l2_leaves(pagetable_t l2)
{
  int n = 0;
  for(int j = 0; j < 512; j++){
    pte_t l2e = l2[j];
    if((l2e & PTE_VALID) == 0)
      continue;
    if((l2e & PTE_TABLE) == 0){
      if((l2e & PTE_U) != 0)
        n++;
      continue;
    }
    n += user_l3_leaves((pagetable_t)P2V(PTE2PA(l2e)));
  }
  return n;
}

void
uvmdump(pagetable_t root, int pid, char *name, char *event)
{
  printf("TTBR0 process pid=%d name=%s event=%s root-kva=%p root-pa=%p\n",
         pid, name ? name : "?", event ? event : "?",
         (uint64)root, V2P(root));

  for(int i = 0; i < 512; i++){
    pte_t l1e = root[i];
    if((l1e & PTE_VALID) == 0)
      continue;
    uint64 l1va = (uint64)i << PXSHIFT(1);
    if((l1e & PTE_TABLE) == 0){
      printf("  -> L1[%d] BLOCK va=%p -> pa=%p flags=%p\n",
             i, l1va, PTE2PA(l1e), PTE_FLAGS(l1e));
      continue;
    }

    pagetable_t l2 = (pagetable_t)P2V(PTE2PA(l1e));
    int l1leaves = user_l2_leaves(l2);
    if(l1leaves == 0)
      continue;
    printf(" L1[%d] va=%p pte=%p -> L2 kva=%p pa=%p user-leaves=%d\n",
           i, l1va, l1e, (uint64)l2, PTE2PA(l1e), l1leaves);
    for(int j = 0; j < 512; j++){
      pte_t l2e = l2[j];
      if((l2e & PTE_VALID) == 0)
        continue;
      uint64 l2va = l1va + ((uint64)j << PXSHIFT(2));
      if((l2e & PTE_TABLE) == 0){
        printf("  -> L1[%d] -> L2[%d] BLOCK va=%p -> pa=%p flags=%p\n",
               i, j, l2va, PTE2PA(l2e), PTE_FLAGS(l2e));
        continue;
      }

      pagetable_t l3 = (pagetable_t)P2V(PTE2PA(l2e));
      int l2leaves = user_l3_leaves(l3);
      if(l2leaves == 0)
        continue;
      printf("  L2[%d] va=%p pte=%p -> L3 kva=%p pa=%p user-leaves=%d\n",
             j, l2va, l2e, (uint64)l3, PTE2PA(l2e), l2leaves);
      for(int k = 0; k < 512; k++){
        pte_t l3e = l3[k];
        if((l3e & (PTE_V | PTE_AF | PTE_U)) !=
           (PTE_V | PTE_AF | PTE_U))
          continue;
        uint64 va = l2va + ((uint64)k << PXSHIFT(3));
        printf("   L3[%d] va=%p pte=%p -> pa=%p"
               " flags=%p %s %s %s%s\n",
               k, va, l3e, PTE2PA(l3e), PTE_FLAGS(l3e),
               (l3e & PTE_U) ? "user" : "kernel",
               (l3e & PTE_RO) ? "RO" : "RW",
               (l3e & PTE_UXN) ? "XN" : "X",
               (l3e & PTE_SHARED) ? " shared" : "");
      }
    }
  }
}

// Show the two different saved-register objects associated with a process.
// context is embedded in struct proc and is consumed by swtch(); trapframe is
// placed at the top of the process's dynamically allocated kernel stack and
// is consumed by the EL0 exception/return path.
void
procvmtrace(struct proc *p, char *event)
{
  struct context *c;
  struct trapframe *f;
  uint64 current_sp;

  if(p == 0 || p->vm == 0 || p->vm->pagetable == 0)
    return;
  c = &p->context;
  f = p->trapframe;
  asm volatile("mov %0, sp" : "=r" (current_sp));

  printf("\n=== process VM/context snapshot: %s ===\n",
         event ? event : "manual");
  printf("proc=%p pid=%d tgid=%d name=%s state=%d vm=%p\n",
         (uint64)p, p->pid, p->tgid, p->name, p->state, (uint64)p->vm);
  printf("kernel-stack: base=%p top=%p pa=%p\n",
         p->kstack, p->kstack + PGSIZE, p->kstack_pa);
  if(current_sp >= p->kstack && current_sp < p->kstack + PGSIZE)
    printf("current kernel sp=%p, stack-used=%d bytes (top-current-sp)\n",
           current_sp, (int)(p->kstack + PGSIZE - current_sp));
  else
    printf("caller kernel sp=%p (snapshot target is not the current task)\n",
           current_sp);
  printf("p->context=%p (embedded in struct proc), p->context.sp=%p\n",
         (uint64)c, c->sp);
  printf(" context: sp=%p x18=%p x19=%p x20=%p x21=%p x22=%p x23=%p\n",
         c->sp, c->x18, c->x19, c->x20, c->x21, c->x22, c->x23);
  printf("          x24=%p x25=%p x26=%p x27=%p x28=%p x29(fp)=%p x30(lr)=%p\n",
         c->x24, c->x25, c->x26, c->x27, c->x28, c->x29, c->x30);
  printf("p->trapframe(frame)=%p, offset-from-kstack-top=%d bytes\n",
         (uint64)f, f ? (int)((p->kstack + PGSIZE) - (uint64)f) : -1);
  if(f){
    printf(" frame: elr=%p spsr=%p user-sp=%p x29(fp)=%p x30(lr)=%p\n",
           f->elr, f->spsr, f->sp, f->x29, f->x30);
    printf("        x0=%p x1=%p x2=%p x3=%p x4=%p x5=%p x6=%p x7=%p\n",
           f->x0, f->x1, f->x2, f->x3, f->x4, f->x5, f->x6, f->x7);
    printf("        x8=%p x9=%p x10=%p x11=%p x12=%p x13=%p x14=%p x15=%p\n",
           f->x8, f->x9, f->x10, f->x11, f->x12, f->x13, f->x14, f->x15);
    printf("        x16=%p x17=%p x18=%p x19=%p x20=%p x21=%p x22=%p x23=%p\n",
           f->x16, f->x17, f->x18, f->x19, f->x20, f->x21, f->x22, f->x23);
    printf("        x24=%p x25=%p x26=%p x27=%p x28=%p\n",
           f->x24, f->x25, f->x26, f->x27, f->x28);
  }
  uvmdump(p->vm->pagetable, p->pid, p->name, event);
  printf("=== end process VM/context snapshot ===\n\n");
}

// Return the address of the PTE in page table pagetable
// that corresponds to virtual address va.  If alloc!=0,
// create any required page-table pages.
//
// This AArch64 configuration uses a 39-bit TTBR0 address space and three
// levels of 4KB page-table pages. Each table contains 512 64-bit descriptors.
// A user virtual address is split into four fields:
//   39..63 -- must be zero.
//   30..38 -- 9 bits of level-1 index.
//   21..29 -- 9 bits of level-2 index.
//   12..20 -- 9 bits of level-3 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
  pagetable_t root = pagetable;

  if(va >= MAXVA)
    panic("walk");

  for(int level = 1; level < 3; level++) {
    pte_t *pte = &pagetable[PX(level, va)];
    if((*pte & PTE_VALID) && (*pte & PTE_TABLE)) {
      pagetable = (pagetable_t)P2V(PTE2PA(*pte));
    } else if(*pte & PTE_VALID) {
      // A 2 MiB block of the kernel linear map: there is no L3 entry, and
      // allocating a table here would silently unmap the whole block.
      if(alloc)
        panic("walk: block");
      return 0;
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(V2P(pagetable)) | PTE_TABLE | PTE_VALID;
      MMTRACE("walk: va %p: new L%d table pa %p in L%d[%d]\n", va, level + 1,
              V2P(pagetable), level, (int)PX(level, va));
      if(MMUTRACE(1))
        mmu_trace_newtable(root, va, level + 1, PX(level, va), V2P(pagetable));
    }
  }
  return &pagetable[PX(3, va)];
}

// Look up a virtual address, return the physical address,
// or 0 if not mapped.
// Can only be used to look up user pages.
uint64
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    return 0;

  pte = walk(pagetable, va, 0);
  if(pte == 0)
    return 0;
  if((*pte & PTE_V) != PTE_V)
    return 0;
  if((*pte & PTE_AF) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}

// user virtual address to kernel virtual address
uint64
uva2ka(pagetable_t pagetable, uint64 va)
{
  uint64 pa = walkaddr(pagetable, va);
  if(pa == 0)
    return 0;
  // A device/framebuffer frame mapped by mmap() may have no kernel alias.
  if((*walk(pagetable, va, 0) & PTE_SPECIAL) && !pa_kernel_mapped(pa))
    return 0;

  return (uint64)P2V(pa);
}

// Make instructions written through the kernel's high direct mapping visible
// through the low EL0 mapping. AArch64 does not guarantee D/I coherence after
// loading executable bytes. Clean the data by its kernel VA, then invalidate
// every PE's I-cache in the inner-shareable domain: IC IVAU with the high
// kernel VA is insufficient for the low user-VA alias, while local-only
// IC IALLU is insufficient after the process migrates to another Cortex-A53.
void
uvmsync_icache(pagetable_t pagetable, uint64 sz)
{
  for(uint64 va = 0; va < PGROUNDUP(sz); va += PGSIZE){
    uint64 kva = uva2ka(pagetable, va);
    if(kva == 0)
      continue;
    for(uint64 p = kva; p < kva + PGSIZE; p += 64)
      asm volatile("dc cvau, %0" :: "r"(p) : "memory");
  }
  asm volatile("dsb ish" ::: "memory");
  asm volatile("ic ialluis\n\tdsb ish\n\tisb" ::: "memory");
}

// add a mapping to the kernel page table.
// only used when booting.
// does not flush TLB or enable paging.
void
kvmmap(pagetable_t kpgtbl, uint64 va, uint64 pa, uint64 sz, uint64 perm)
{
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    panic("kvmmap");
}

// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa. va and size might not
// be page-aligned. Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, uint64 perm)
{
  uint64 a, last;
  pte_t *pte;

  if(size == 0)
    panic("mappages: size");
  a = PGROUNDDOWN(va);
  last = PGROUNDDOWN(va + size - 1);
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
      return -1;
    if(*pte & PTE_AF)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_AF | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

// Remove npages of mappings starting from va. va must be page-aligned.
// Lazy brk makes unmapped holes normal, so absent leaves are skipped.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    if((pte = walk(pagetable, a, 0)) == 0)
      continue;
    if((*pte & PTE_V) != PTE_V)
      continue;
    if((*pte & PTE_AF) == 0)
      continue;
    // A shared page belongs to its cache, not to this address space.
    // A private page may still be shared copy-on-write with a fork relative:
    // drop this address space's reference; the last one frees the page.
    if(do_free && (*pte & PTE_SHARED) == 0){
      uint64 pa = PTE2PA(*pte);
      put_page(virt_to_page(P2V(pa)));
    }
    *pte = 0;
  }
}

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
  if(pagetable == 0)
    return 0;
  memset(pagetable, 0, PGSIZE);
  if(MMUTRACE_PAGES())
    mmu_trace_newtable(pagetable, 0, 1, -1, V2P(pagetable));
  return pagetable;
}

// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvminit(pagetable_t pagetable, uchar *src, uint sz)
{
  char *mem;

  if(sz >= PGSIZE)
    panic("inituvm: more than a page");
  mem = kalloc();
  memset(mem, 0, PGSIZE);
  mappages(pagetable, 0, PGSIZE, V2P(mem), PTE_NORMAL|PTE_U);
  memmove(mem, src, sz);
  if(MMUTRACE(2))
    printf("mmu: userinit: initcode %d bytes -> VA 0 (page pa %s), user root pa %s\n",
           (int)sz, mmu_hx(V2P(mem)), mmu_hx(V2P(pagetable)));
  uvmsync_icache(pagetable, sz);
}

// Allocate PTEs and physical memory to grow process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.
uint64
uvmalloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  char *mem;
  uint64 a;

  if(newsz < oldsz)
    return oldsz;

  oldsz = PGROUNDUP(oldsz);
  for(a = oldsz; a < newsz; a += PGSIZE){
    mem = kalloc();
    if(mem == 0){
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
    memset(mem, 0, PGSIZE);
    if(mappages(pagetable, a, PGSIZE, V2P(mem), PTE_NORMAL|PTE_U) != 0){
      kfree(mem);
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
    if(MMUTRACE_PAGES()){
      pte_t *pte = walk(pagetable, a, 0);
      char ab[80];
      myproc()->mmu_pages++;
      printf("mmu:   page: kalloc pa %s -> VA %s (L3[%d] = %s %s)\n", mmu_hx(V2P(mem)),
             mmu_hx(a), (int)PX(3, a), mmu_hx(*pte), mmu_attr_str(*pte, ab, sizeof(ab)));
    }
  }
  return newsz;
}

void
switchuvm(struct proc *p)
{
  if(p == 0)
    panic("switchuvm: no process");
  if(p->vm == 0 || p->vm->pagetable == 0)
    panic("switchuvm: no pagetable");

  w_ttbr0_el1(V2P(p->vm->pagetable));
  flush_tlb();
}

void
switchkvm(void)
{
  w_ttbr0_el1(0);
  flush_tlb();
}

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    return oldsz;

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
  // there are 2^9 = 512 PTEs in a page table.
  // printf("freeawlk %p\n", pagetable);
  for(int i = 0; i < 512; i++){
    pte_t pte = pagetable[i];
    // printf("pte%p %d\n", pte, i);
    if((pte & PTE_VALID) && (pte & PTE_TABLE) && !(pte & PTE_AF)){
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)P2V(child));
      pagetable[i] = 0;
    }
  }
  kfree((void*)pagetable);
}

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
  if(sz > 0)
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
}

// Given a parent process's page table, share its memory with a child's
// page table copy-on-write.  Every private page is mapped into the child at
// the same physical address and gains a reference (struct page->refcount);
// pages the user could write become read-only + PTE_COW in BOTH page tables,
// so whichever process stores first gets its own copy from cow_break().
// Read-only private pages (text, rodata, the stack guard) are simply shared.
// Caller holds the parent's vm->lock and flushes the parent's TLB entries.
// returns 0 on success, -1 on failure (the child's references are dropped).
int
uvmcopy(pagetable_t old, pagetable_t new, uint64 sz)
{
  pte_t *pte;
  uint64 pa, i;
  uint64 flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    if((pte = walk(old, i, 0)) == 0)
      continue;
    if((*pte & PTE_AF) == 0)
      continue;
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if(*pte & PTE_SHARED){
      // Read-only shared library text: the child maps the same page.
      if(mappages(new, i, PGSIZE, pa, flags | PTE_SHARED) != 0)
        goto err;
      continue;
    }
    if((*pte & PTE_SPECIAL) || (pa >> PGSHIFT) >= max_pfn){
      // Not a buddy-allocator page: no struct page to count, copy it.
      if((mem = kalloc()) == 0)
        goto err;
      memmove(mem, (char*)P2V(pa), PGSIZE);
      if(mappages(new, i, PGSIZE, V2P(mem), flags) != 0){
        kfree(mem);
        goto err;
      }
      continue;
    }
    if((*pte & PTE_U) && (*pte & PTE_RO) == 0)
      *pte |= PTE_RO | PTE_COW;           // parent: writable -> COW
    if(*pte & PTE_COW)
      flags |= PTE_RO | PTE_COW;
    if(mappages(new, i, PGSIZE, pa, flags) != 0)
      goto err;
    get_page(virt_to_page(P2V(pa)));
    cow_stat.shared++;
    if(MMUTRACE_PAGES()){
      myproc()->mmu_pages++;
      printf("mmu:   cow: VA %s pa %s now mapped by parent and child (refcount %d), %s\n",
             mmu_hx(i), mmu_hx(pa), page_count(virt_to_page(P2V(pa))),
             (flags & PTE_COW) ? "both PTEs RO+COW" :
             (flags & PTE_U) ? "read-only, shared as is" :
             "stack guard (no PTE_U), shared as is");
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
  return -1;
}

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
  if(pte == 0)
    panic("uvmclear");
  *pte &= ~PTE_U;
}

// Like uva2ka(), but only for a page EL0 may write.  The kernel writes user
// memory through its own direct mapping, which ignores the user PTE's AP bits,
// so copyout() must check them itself.  Otherwise read(fd, libc_text, n) would
// let one process overwrite the libc.so text page shared by every process.
static uint64
uva2ka_writable(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;

  if(va >= MAXVA)
    return 0;
  pte = walk(pagetable, va, 0);
  if(pte == 0 || (*pte & PTE_V) != PTE_V || (*pte & PTE_AF) == 0 ||
     (*pte & PTE_U) == 0 || (*pte & PTE_RO) != 0)
    return 0;
  if((*pte & PTE_SPECIAL) && !pa_kernel_mapped(PTE2PA(*pte)))
    return 0;
  return (uint64)P2V(PTE2PA(*pte));
}

// copyin()/copyout() found va absent or read-only.  If it lies in the lazy
// brk heap or an mmap() region, page it in (or mark a clean shared page dirty)
// like a user access would, and retry.  Not while a spinlock is held:
// demand paging may sleep, so syscall paths prefault such buffers.
static uint64
uva2ka_fault(pagetable_t pagetable, uint64 va, int write)
{
  struct proc *p = myproc();
  int locked;

  if(p == 0 || p->vm == 0 || p->vm->pagetable != pagetable)
    return 0;
  push_off();
  locked = mycpu()->noff > 1;
  pop_off();
  if(locked || handle_user_mm_fault(p->vm, va, FAULT_FLAG_KERNEL |
                                    (write ? FAULT_FLAG_WRITE : 0)) != 0)
    return 0;
  return write ? uva2ka_writable(pagetable, va) : uva2ka(pagetable, va);
}

// ---------------------------------------------------------------------------
// Copy-on-write
//
// Resolve a store to the page at va if it is a PTE_COW page (Linux
// do_wp_page).  With the last reference the page is simply made writable
// again; otherwise it is copied and the shared page loses one reference.
// Nothing here sleeps, so copyout() may call it with spinlocks held.
// lk protects the page table against other threads of the same address
// space (vm->lock); it is taken unless the caller already holds it.
// Returns 1 if va is now writable, 0 if va is not a COW page, -1 on OOM.
int
cow_break(pagetable_t pagetable, struct spinlock *lk, uint64 va)
{
  int locked = 0, r = 1;
  pte_t *pte;
  struct page *pg;
  uint64 pa;
  char *mem;

  if(va >= MAXVA)
    return 0;
  va = PGROUNDDOWN(va);
  if(lk && !holding(lk)){
    acquire(lk);
    locked = 1;
  }
  pte = walk(pagetable, va, 0);
  if(pte == 0 || (*pte & PTE_V) != PTE_V || (*pte & PTE_AF) == 0 ||
     (*pte & PTE_COW) == 0){
    r = 0;
    goto out;
  }
  pa = PTE2PA(*pte);
  pg = virt_to_page(P2V(pa));
  if(page_count(pg) == 1){
    // Every other sharer already copied or exited: reuse in place.
    *pte &= ~(PTE_RO | PTE_COW);
    flush_tlb();
    cow_stat.reused++;
    MMTRACE("cow: va %p last sharer, reuse pa %p in place\n", va, pa);
    goto out;
  }
  if((mem = kalloc()) == 0){
    r = -1;
    goto out;
  }
  memmove(mem, P2V(pa), PGSIZE);
  if((*pte & PTE_UXN) == 0){
    // Executable copy: make the new bytes visible to instruction fetch.
    for(uint64 p = (uint64)mem; p < (uint64)mem + PGSIZE; p += 64)
      asm volatile("dc cvau, %0" :: "r"(p) : "memory");
    asm volatile("dsb ish\n\tic ialluis\n\tdsb ish\n\tisb" ::: "memory");
  }
  *pte = PA2PTE(V2P(mem)) | (*pte & ~(PA2PTE(~0ULL) | PTE_RO | PTE_COW));
  // Every CPU must stop using the old translation before the reference is
  // dropped: the other sharer may free the page as soon as it is the last.
  flush_tlb();
  put_page(pg);
  cow_stat.copied++;
  MMTRACE("cow: va %p copied pa %p -> new pa %p\n", va, pa, V2P(mem));
 out:
  if(locked)
    release(lk);
  return r;
}

// The lock that guards pagetable's PTEs, if it is the current address space.
static struct spinlock *
uvm_lock(pagetable_t pagetable)
{
  struct proc *p = myproc();

  if(p && p->vm && p->vm->pagetable == pagetable)
    return &p->vm->lock;
  return 0;
}

// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error (unmapped or read-only destination).
//
// For the current address space each page is checked, made private
// (copy-on-write) and written under vm->lock, so another thread's fork()
// cannot turn it back into a shared page between the check and the copy.
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  struct spinlock *lk = uvm_lock(pagetable);
  int faulted = 0;

  while(len > 0){
    int locked = lk && !holding(lk);
    va0 = PGROUNDDOWN(dstva);
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    if(locked)
      acquire(lk);
    pa0 = uva2ka_writable(pagetable, va0);
    if(pa0 == 0 && cow_break(pagetable, lk, va0) > 0)
      pa0 = uva2ka_writable(pagetable, va0);
    if(pa0)
      memmove((void *)(pa0 + (dstva - va0)), src, n);
    if(locked)
      release(lk);
    if(pa0 == 0){
      // Absent or clean: demand paging may sleep, so it runs unlocked;
      // then retry this page once under the lock.
      if(faulted || uva2ka_fault(pagetable, va0, 1) == 0)
        return -1;
      faulted = 1;
      continue;
    }
    faulted = 0;
    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}

// Copy from user to kernel.
// Copy len bytes to dst from virtual address srcva in a given page table.
// Return 0 on success, -1 on error.
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = uva2ka(pagetable, va0);
    if(pa0 == 0 && (pa0 = uva2ka_fault(pagetable, va0, 0)) == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);

    len -= n;
    dst += n;
    srcva = va0 + PGSIZE;
  }
  return 0;
}

// Copy a null-terminated string from user to kernel.
// Copy bytes to dst from virtual address srcva in a given page table,
// until a '\0', or max.
// Return 0 on success, -1 on error.
int
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = uva2ka(pagetable, va0);
    if(pa0 == 0 && (pa0 = uva2ka_fault(pagetable, va0, 0)) == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    if(n > max)
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
        got_null = 1;
        break;
      } else {
        *dst = *p;
      }
      --n;
      --max;
      p++;
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    return 0;
  } else {
    return -1;
  }
}
