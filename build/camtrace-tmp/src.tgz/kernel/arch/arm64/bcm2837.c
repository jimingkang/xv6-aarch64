#include <kernel/types.h>
#include <kernel/param.h>
#include "memlayout.h"
#include "aarch64.h"

// BCM2837 legacy interrupt controller and ARM-local interrupt routing.
// The rest of the kernel keeps the old gic_* interface so trap.c stays small.

#define IRQ_PENDING_1       0x204
#define IRQ_PENDING_2       0x208
#define ENABLE_IRQS_1       0x210
#define ENABLE_IRQS_2       0x214
#define DISABLE_IRQS_1      0x21c
#define DISABLE_IRQS_2      0x220
#define DISABLE_BASIC_IRQS  0x224

#define CORE_TIMER_CONTROL(c) (0x40 + 4 * (c))
#define CORE_MBOX_CONTROL(c)  (0x50 + 4 * (c))
#define CORE_IRQ_SOURCE(c)    (0x60 + 4 * (c))
#define CORE_MBOX0_SET(c)     (0x80 + 0x10 * (c))   // write 1s to raise
#define CORE_MBOX0_CLR(c)     (0xc0 + 0x10 * (c))   // write 1s to clear
#define CORE_VIRTUAL_TIMER    (1 << 3)
#define CORE_MBOX0            (1 << 4)

static inline uint32
irqread(uint64 off)
{
  return *(volatile uint32 *)(IRQCTRL + off);
}

static inline void
irqwrite(uint64 off, uint32 value)
{
  *(volatile uint32 *)(IRQCTRL + off) = value;
}

static inline uint32
localread(uint64 off)
{
  return *(volatile uint32 *)(LOCAL_BASE + off);
}

static inline void
localwrite(uint64 off, uint32 value)
{
  *(volatile uint32 *)(LOCAL_BASE + off) = value;
}

void
gicv3init(void)
{
  // Start with all legacy GPU interrupts disabled, then enable the AUX
  // interrupt used by the BCM2837 Mini UART.
  irqwrite(DISABLE_IRQS_1, ~0U);
  irqwrite(DISABLE_IRQS_2, ~0U);
  irqwrite(DISABLE_BASIC_IRQS, ~0U);
  irqwrite(ENABLE_IRQS_1, (1U << UART0_IRQ) | (1U << DWC2_IRQ));
  irqwrite(ENABLE_IRQS_2, 1U << (SDIO_IRQ - 32));
}

void
gicv3inithart(void)
{
  int cpu = cpuid();
  localwrite(CORE_TIMER_CONTROL(cpu), CORE_VIRTUAL_TIMER);
  // Mailbox 0 of each core is the reschedule IPI (Linux uses it the same way
  // on BCM2836/7).  Clear anything stale before enabling its IRQ.
  localwrite(CORE_MBOX0_CLR(cpu), ~0U);
  localwrite(CORE_MBOX_CONTROL(cpu), 1);
}

// Ask `cpu` to run its scheduler soon.  The caller has already set
// cpus[cpu].need_resched; the write below is ordered after it.
void
send_resched_ipi(int cpu)
{
  asm volatile("dsb sy" ::: "memory");
  localwrite(CORE_MBOX0_SET(cpu), 1);
}

void
resched_ipi_ack(void)
{
  localwrite(CORE_MBOX0_CLR(cpuid()), ~0U);
}

uint32
gic_iar(void)
{
  int cpu = cpuid();

  uint32 local = localread(CORE_IRQ_SOURCE(cpu));
  if(local & CORE_VIRTUAL_TIMER)
    return TIMER0_IRQ;
  if(local & CORE_MBOX0)
    return IPI_RESCHED_IRQ;
  if(irqread(IRQ_PENDING_1) & (1U << UART0_IRQ))
    return UART0_IRQ;
  if(irqread(IRQ_PENDING_1) & (1U << DWC2_IRQ))
    return DWC2_IRQ;
  if(irqread(IRQ_PENDING_2) & (1U << (SDIO_IRQ - 32)))
    return SDIO_IRQ;
  if(irqread(IRQ_PENDING_2) & (1U << (CSI1_IRQ - 32)))
    return CSI1_IRQ;
  if(irqread(IRQ_PENDING_1))
    return 1023;
  return 1023;
}

int
gic_iar_irq(uint32 iar)
{
  return iar;
}

void
gic_eoi(uint32 iar)
{
  (void)iar;
  // BCM2837 interrupt sources are acknowledged at the source device.
}

int
gic_int_enabled(uint32 intid)
{
  if(intid == UART0_IRQ || intid == DWC2_IRQ || intid == SDIO_IRQ ||
     intid == CSI1_IRQ)
    return 1;
  if(intid == TIMER0_IRQ || intid == IPI_RESCHED_IRQ)
    return 1;
  return 0;
}

// Enable one more legacy GPU interrupt after its driver has probed.
void
bcm2837_enable_irq(int irq)
{
  if(irq < 32)
    irqwrite(ENABLE_IRQS_1, 1U << irq);
  else if(irq < 64)
    irqwrite(ENABLE_IRQS_2, 1U << (irq - 32));
}

void
bcm2837_disable_irq(int irq)
{
  if(irq < 32)
    irqwrite(DISABLE_IRQS_1, 1U << irq);
  else if(irq < 64)
    irqwrite(DISABLE_IRQS_2, 1U << (irq - 32));
}
