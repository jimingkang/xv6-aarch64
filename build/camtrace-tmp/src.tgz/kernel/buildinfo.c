const char kernel_build_time[] = "2026-11-18 22:18:44 UTC";
const char kernel_build_rev[] = "rpi3-lock 4163a5f+dirty";
